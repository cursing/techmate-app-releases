(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function e(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(i){if(i.ep)return;i.ep=!0;const r=e(i);fetch(i.href,r)}})();var rh={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $p=function(n){const t=[];let e=0;for(let s=0;s<n.length;s++){let i=n.charCodeAt(s);i<128?t[e++]=i:i<2048?(t[e++]=i>>6|192,t[e++]=i&63|128):(i&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++s)&1023),t[e++]=i>>18|240,t[e++]=i>>12&63|128,t[e++]=i>>6&63|128,t[e++]=i&63|128):(t[e++]=i>>12|224,t[e++]=i>>6&63|128,t[e++]=i&63|128)}return t},d_=function(n){const t=[];let e=0,s=0;for(;e<n.length;){const i=n[e++];if(i<128)t[s++]=String.fromCharCode(i);else if(i>191&&i<224){const r=n[e++];t[s++]=String.fromCharCode((i&31)<<6|r&63)}else if(i>239&&i<365){const r=n[e++],o=n[e++],a=n[e++],l=((i&7)<<18|(r&63)<<12|(o&63)<<6|a&63)-65536;t[s++]=String.fromCharCode(55296+(l>>10)),t[s++]=String.fromCharCode(56320+(l&1023))}else{const r=n[e++],o=n[e++];t[s++]=String.fromCharCode((i&15)<<12|(r&63)<<6|o&63)}}return t.join("")},Vp={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,t){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const e=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let i=0;i<n.length;i+=3){const r=n[i],o=i+1<n.length,a=o?n[i+1]:0,l=i+2<n.length,u=l?n[i+2]:0,h=r>>2,p=(r&3)<<4|a>>4;let m=(a&15)<<2|u>>6,I=u&63;l||(I=64,o||(m=64)),s.push(e[h],e[p],e[m],e[I])}return s.join("")},encodeString(n,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(n):this.encodeByteArray($p(n),t)},decodeString(n,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(n):d_(this.decodeStringToByteArray(n,t))},decodeStringToByteArray(n,t){this.init_();const e=t?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let i=0;i<n.length;){const r=e[n.charAt(i++)],a=i<n.length?e[n.charAt(i)]:0;++i;const u=i<n.length?e[n.charAt(i)]:64;++i;const p=i<n.length?e[n.charAt(i)]:64;if(++i,r==null||a==null||u==null||p==null)throw new h_;const m=r<<2|a>>4;if(s.push(m),u!==64){const I=a<<4&240|u>>2;if(s.push(I),p!==64){const E=u<<6&192|p;s.push(E)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class h_ extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const f_=function(n){const t=$p(n);return Vp.encodeByteArray(t,!0)},Np=function(n){return f_(n).replace(/\./g,"")},xp=function(n){try{return Vp.decodeString(n,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function p_(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const m_=()=>p_().__FIREBASE_DEFAULTS__,g_=()=>{if(typeof process>"u"||typeof rh>"u")return;const n=rh.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},y_=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=n&&xp(n[1]);return t&&JSON.parse(t)},Pa=()=>{try{return m_()||g_()||y_()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},v_=n=>{var t,e;return(e=(t=Pa())===null||t===void 0?void 0:t.emulatorHosts)===null||e===void 0?void 0:e[n]},Op=()=>{var n;return(n=Pa())===null||n===void 0?void 0:n.config},Mp=n=>{var t;return(t=Pa())===null||t===void 0?void 0:t[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class __{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}wrapCallback(t){return(e,s)=>{e?this.reject(e):this.resolve(s),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(e):t(e,s))}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bt(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function b_(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Bt())}function w_(){var n;const t=(n=Pa())===null||n===void 0?void 0:n.forceEnvironment;if(t==="node")return!0;if(t==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function I_(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function E_(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function T_(){const n=Bt();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function Lp(){return!w_()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function Fp(){try{return typeof indexedDB=="object"}catch{return!1}}function A_(){return new Promise((n,t)=>{try{let e=!0;const s="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(s);i.onsuccess=()=>{i.result.close(),e||self.indexedDB.deleteDatabase(s),n(!0)},i.onupgradeneeded=()=>{e=!1},i.onerror=()=>{var r;t(((r=i.error)===null||r===void 0?void 0:r.message)||"")}}catch(e){t(e)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const S_="FirebaseError";class dn extends Error{constructor(t,e,s){super(e),this.code=t,this.customData=s,this.name=S_,Object.setPrototypeOf(this,dn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,zr.prototype.create)}}class zr{constructor(t,e,s){this.service=t,this.serviceName=e,this.errors=s}create(t,...e){const s=e[0]||{},i=`${this.service}/${t}`,r=this.errors[t],o=r?k_(r,s):"Error",a=`${this.serviceName}: ${o} (${i}).`;return new dn(i,a,s)}}function k_(n,t){return n.replace(R_,(e,s)=>{const i=t[s];return i!=null?String(i):`<${s}?>`})}const R_=/\{\$([^}]+)}/g;function P_(n){for(const t in n)if(Object.prototype.hasOwnProperty.call(n,t))return!1;return!0}function Ir(n,t){if(n===t)return!0;const e=Object.keys(n),s=Object.keys(t);for(const i of e){if(!s.includes(i))return!1;const r=n[i],o=t[i];if(oh(r)&&oh(o)){if(!Ir(r,o))return!1}else if(r!==o)return!1}for(const i of s)if(!e.includes(i))return!1;return!0}function oh(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gr(n){const t=[];for(const[e,s]of Object.entries(n))Array.isArray(s)?s.forEach(i=>{t.push(encodeURIComponent(e)+"="+encodeURIComponent(i))}):t.push(encodeURIComponent(e)+"="+encodeURIComponent(s));return t.length?"&"+t.join("&"):""}function ir(n){const t={};return n.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[i,r]=s.split("=");t[decodeURIComponent(i)]=decodeURIComponent(r)}}),t}function rr(n){const t=n.indexOf("?");if(!t)return"";const e=n.indexOf("#",t);return n.substring(t,e>0?e:void 0)}function C_(n,t){const e=new D_(n,t);return e.subscribe.bind(e)}class D_{constructor(t,e){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=e,this.task.then(()=>{t(this)}).catch(s=>{this.error(s)})}next(t){this.forEachObserver(e=>{e.next(t)})}error(t){this.forEachObserver(e=>{e.error(t)}),this.close(t)}complete(){this.forEachObserver(t=>{t.complete()}),this.close()}subscribe(t,e,s){let i;if(t===void 0&&e===void 0&&s===void 0)throw new Error("Missing Observer.");$_(t,["next","error","complete"])?i=t:i={next:t,error:e,complete:s},i.next===void 0&&(i.next=Dc),i.error===void 0&&(i.error=Dc),i.complete===void 0&&(i.complete=Dc);const r=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),r}unsubscribeOne(t){this.observers===void 0||this.observers[t]===void 0||(delete this.observers[t],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(t){if(!this.finalized)for(let e=0;e<this.observers.length;e++)this.sendOne(e,t)}sendOne(t,e){this.task.then(()=>{if(this.observers!==void 0&&this.observers[t]!==void 0)try{e(this.observers[t])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(t){this.finalized||(this.finalized=!0,t!==void 0&&(this.finalError=t),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function $_(n,t){if(typeof n!="object"||n===null)return!1;for(const e of t)if(e in n&&typeof n[e]=="function")return!0;return!1}function Dc(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wt(n){return n&&n._delegate?n._delegate:n}class ps{constructor(t,e,s){this.name=t,this.instanceFactory=e,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ns="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V_{constructor(t,e){this.name=t,this.container=e,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const e=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(e)){const s=new __;if(this.instancesDeferred.set(e,s),this.isInitialized(e)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:e});i&&s.resolve(i)}catch{}}return this.instancesDeferred.get(e).promise}getImmediate(t){var e;const s=this.normalizeInstanceIdentifier(t==null?void 0:t.identifier),i=(e=t==null?void 0:t.optional)!==null&&e!==void 0?e:!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(r){if(i)return null;throw r}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(x_(t))try{this.getOrInitializeService({instanceIdentifier:ns})}catch{}for(const[e,s]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(e);try{const r=this.getOrInitializeService({instanceIdentifier:i});s.resolve(r)}catch{}}}}clearInstance(t=ns){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(e=>"INTERNAL"in e).map(e=>e.INTERNAL.delete()),...t.filter(e=>"_delete"in e).map(e=>e._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=ns){return this.instances.has(t)}getOptions(t=ns){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:e={}}=t,s=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:s,options:e});for(const[r,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(r);s===a&&o.resolve(i)}return i}onInit(t,e){var s;const i=this.normalizeInstanceIdentifier(e),r=(s=this.onInitCallbacks.get(i))!==null&&s!==void 0?s:new Set;r.add(t),this.onInitCallbacks.set(i,r);const o=this.instances.get(i);return o&&t(o,i),()=>{r.delete(t)}}invokeOnInitCallbacks(t,e){const s=this.onInitCallbacks.get(e);if(s)for(const i of s)try{i(t,e)}catch{}}getOrInitializeService({instanceIdentifier:t,options:e={}}){let s=this.instances.get(t);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:N_(t),options:e}),this.instances.set(t,s),this.instancesOptions.set(t,e),this.invokeOnInitCallbacks(s,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,s)}catch{}return s||null}normalizeInstanceIdentifier(t=ns){return this.component?this.component.multipleInstances?t:ns:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function N_(n){return n===ns?void 0:n}function x_(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class O_{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const e=this.getProvider(t.name);if(e.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);e.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const e=new V_(t,this);return this.providers.set(t,e),e}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ot;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(ot||(ot={}));const M_={debug:ot.DEBUG,verbose:ot.VERBOSE,info:ot.INFO,warn:ot.WARN,error:ot.ERROR,silent:ot.SILENT},L_=ot.INFO,F_={[ot.DEBUG]:"log",[ot.VERBOSE]:"log",[ot.INFO]:"info",[ot.WARN]:"warn",[ot.ERROR]:"error"},U_=(n,t,...e)=>{if(t<n.logLevel)return;const s=new Date().toISOString(),i=F_[t];if(i)console[i](`[${s}]  ${n.name}:`,...e);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class Bl{constructor(t){this.name=t,this._logLevel=L_,this._logHandler=U_,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in ot))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?M_[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,ot.DEBUG,...t),this._logHandler(this,ot.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,ot.VERBOSE,...t),this._logHandler(this,ot.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,ot.INFO,...t),this._logHandler(this,ot.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,ot.WARN,...t),this._logHandler(this,ot.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,ot.ERROR,...t),this._logHandler(this,ot.ERROR,...t)}}const q_=(n,t)=>t.some(e=>n instanceof e);let ah,ch;function B_(){return ah||(ah=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function j_(){return ch||(ch=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Up=new WeakMap,Xc=new WeakMap,qp=new WeakMap,$c=new WeakMap,jl=new WeakMap;function z_(n){const t=new Promise((e,s)=>{const i=()=>{n.removeEventListener("success",r),n.removeEventListener("error",o)},r=()=>{e(Pn(n.result)),i()},o=()=>{s(n.error),i()};n.addEventListener("success",r),n.addEventListener("error",o)});return t.then(e=>{e instanceof IDBCursor&&Up.set(e,n)}).catch(()=>{}),jl.set(t,n),t}function G_(n){if(Xc.has(n))return;const t=new Promise((e,s)=>{const i=()=>{n.removeEventListener("complete",r),n.removeEventListener("error",o),n.removeEventListener("abort",o)},r=()=>{e(),i()},o=()=>{s(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",r),n.addEventListener("error",o),n.addEventListener("abort",o)});Xc.set(n,t)}let Zc={get(n,t,e){if(n instanceof IDBTransaction){if(t==="done")return Xc.get(n);if(t==="objectStoreNames")return n.objectStoreNames||qp.get(n);if(t==="store")return e.objectStoreNames[1]?void 0:e.objectStore(e.objectStoreNames[0])}return Pn(n[t])},set(n,t,e){return n[t]=e,!0},has(n,t){return n instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in n}};function K_(n){Zc=n(Zc)}function W_(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...e){const s=n.call(Vc(this),t,...e);return qp.set(s,t.sort?t.sort():[t]),Pn(s)}:j_().includes(n)?function(...t){return n.apply(Vc(this),t),Pn(Up.get(this))}:function(...t){return Pn(n.apply(Vc(this),t))}}function H_(n){return typeof n=="function"?W_(n):(n instanceof IDBTransaction&&G_(n),q_(n,B_())?new Proxy(n,Zc):n)}function Pn(n){if(n instanceof IDBRequest)return z_(n);if($c.has(n))return $c.get(n);const t=H_(n);return t!==n&&($c.set(n,t),jl.set(t,n)),t}const Vc=n=>jl.get(n);function Q_(n,t,{blocked:e,upgrade:s,blocking:i,terminated:r}={}){const o=indexedDB.open(n,t),a=Pn(o);return s&&o.addEventListener("upgradeneeded",l=>{s(Pn(o.result),l.oldVersion,l.newVersion,Pn(o.transaction),l)}),e&&o.addEventListener("blocked",l=>e(l.oldVersion,l.newVersion,l)),a.then(l=>{r&&l.addEventListener("close",()=>r()),i&&l.addEventListener("versionchange",u=>i(u.oldVersion,u.newVersion,u))}).catch(()=>{}),a}const J_=["get","getKey","getAll","getAllKeys","count"],Y_=["put","add","delete","clear"],Nc=new Map;function lh(n,t){if(!(n instanceof IDBDatabase&&!(t in n)&&typeof t=="string"))return;if(Nc.get(t))return Nc.get(t);const e=t.replace(/FromIndex$/,""),s=t!==e,i=Y_.includes(e);if(!(e in(s?IDBIndex:IDBObjectStore).prototype)||!(i||J_.includes(e)))return;const r=async function(o,...a){const l=this.transaction(o,i?"readwrite":"readonly");let u=l.store;return s&&(u=u.index(a.shift())),(await Promise.all([u[e](...a),i&&l.done]))[0]};return Nc.set(t,r),r}K_(n=>({...n,get:(t,e,s)=>lh(t,e)||n.get(t,e,s),has:(t,e)=>!!lh(t,e)||n.has(t,e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class X_{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(e=>{if(Z_(e)){const s=e.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(e=>e).join(" ")}}function Z_(n){const t=n.getComponent();return(t==null?void 0:t.type)==="VERSION"}const tl="@firebase/app",uh="0.10.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ms=new Bl("@firebase/app"),tb="@firebase/app-compat",eb="@firebase/analytics-compat",nb="@firebase/analytics",sb="@firebase/app-check-compat",ib="@firebase/app-check",rb="@firebase/auth",ob="@firebase/auth-compat",ab="@firebase/database",cb="@firebase/database-compat",lb="@firebase/functions",ub="@firebase/functions-compat",db="@firebase/installations",hb="@firebase/installations-compat",fb="@firebase/messaging",pb="@firebase/messaging-compat",mb="@firebase/performance",gb="@firebase/performance-compat",yb="@firebase/remote-config",vb="@firebase/remote-config-compat",_b="@firebase/storage",bb="@firebase/storage-compat",wb="@firebase/firestore",Ib="@firebase/vertexai-preview",Eb="@firebase/firestore-compat",Tb="firebase",Ab="10.12.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const el="[DEFAULT]",Sb={[tl]:"fire-core",[tb]:"fire-core-compat",[nb]:"fire-analytics",[eb]:"fire-analytics-compat",[ib]:"fire-app-check",[sb]:"fire-app-check-compat",[rb]:"fire-auth",[ob]:"fire-auth-compat",[ab]:"fire-rtdb",[cb]:"fire-rtdb-compat",[lb]:"fire-fn",[ub]:"fire-fn-compat",[db]:"fire-iid",[hb]:"fire-iid-compat",[fb]:"fire-fcm",[pb]:"fire-fcm-compat",[mb]:"fire-perf",[gb]:"fire-perf-compat",[yb]:"fire-rc",[vb]:"fire-rc-compat",[_b]:"fire-gcs",[bb]:"fire-gcs-compat",[wb]:"fire-fst",[Eb]:"fire-fst-compat",[Ib]:"fire-vertex","fire-js":"fire-js",[Tb]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ta=new Map,kb=new Map,nl=new Map;function dh(n,t){try{n.container.addComponent(t)}catch(e){ms.debug(`Component ${t.name} failed to register with FirebaseApp ${n.name}`,e)}}function ii(n){const t=n.name;if(nl.has(t))return ms.debug(`There were multiple attempts to register component ${t}.`),!1;nl.set(t,n);for(const e of ta.values())dh(e,n);for(const e of kb.values())dh(e,n);return!0}function zl(n,t){const e=n.container.getProvider("heartbeat").getImmediate({optional:!0});return e&&e.triggerHeartbeat(),n.container.getProvider(t)}function en(n){return n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rb={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Cn=new zr("app","Firebase",Rb);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pb{constructor(t,e,s){this._isDeleted=!1,this._options=Object.assign({},t),this._config=Object.assign({},e),this._name=e.name,this._automaticDataCollectionEnabled=e.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new ps("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw Cn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ti=Ab;function Bp(n,t={}){let e=n;typeof t!="object"&&(t={name:t});const s=Object.assign({name:el,automaticDataCollectionEnabled:!1},t),i=s.name;if(typeof i!="string"||!i)throw Cn.create("bad-app-name",{appName:String(i)});if(e||(e=Op()),!e)throw Cn.create("no-options");const r=ta.get(i);if(r){if(Ir(e,r.options)&&Ir(s,r.config))return r;throw Cn.create("duplicate-app",{appName:i})}const o=new O_(i);for(const l of nl.values())o.addComponent(l);const a=new Pb(e,s,o);return ta.set(i,a),a}function Cb(n=el){const t=ta.get(n);if(!t&&n===el&&Op())return Bp();if(!t)throw Cn.create("no-app",{appName:n});return t}function Dn(n,t,e){var s;let i=(s=Sb[n])!==null&&s!==void 0?s:n;e&&(i+=`-${e}`);const r=i.match(/\s|\//),o=t.match(/\s|\//);if(r||o){const a=[`Unable to register library "${i}" with version "${t}":`];r&&a.push(`library name "${i}" contains illegal characters (whitespace or "/")`),r&&o&&a.push("and"),o&&a.push(`version name "${t}" contains illegal characters (whitespace or "/")`),ms.warn(a.join(" "));return}ii(new ps(`${i}-version`,()=>({library:i,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Db="firebase-heartbeat-database",$b=1,Er="firebase-heartbeat-store";let xc=null;function jp(){return xc||(xc=Q_(Db,$b,{upgrade:(n,t)=>{switch(t){case 0:try{n.createObjectStore(Er)}catch(e){console.warn(e)}}}}).catch(n=>{throw Cn.create("idb-open",{originalErrorMessage:n.message})})),xc}async function Vb(n){try{const e=(await jp()).transaction(Er),s=await e.objectStore(Er).get(zp(n));return await e.done,s}catch(t){if(t instanceof dn)ms.warn(t.message);else{const e=Cn.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});ms.warn(e.message)}}}async function hh(n,t){try{const s=(await jp()).transaction(Er,"readwrite");await s.objectStore(Er).put(t,zp(n)),await s.done}catch(e){if(e instanceof dn)ms.warn(e.message);else{const s=Cn.create("idb-set",{originalErrorMessage:e==null?void 0:e.message});ms.warn(s.message)}}}function zp(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nb=1024,xb=30*24*60*60*1e3;class Ob{constructor(t){this.container=t,this._heartbeatsCache=null;const e=this.container.getProvider("app").getImmediate();this._storage=new Lb(e),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var t,e;const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=fh();if(!(((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(o=>o.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:i}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(o=>{const a=new Date(o.date).valueOf();return Date.now()-a<=xb}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var t;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const e=fh(),{heartbeatsToSend:s,unsentEntries:i}=Mb(this._heartbeatsCache.heartbeats),r=Np(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=e,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),r}}function fh(){return new Date().toISOString().substring(0,10)}function Mb(n,t=Nb){const e=[];let s=n.slice();for(const i of n){const r=e.find(o=>o.agent===i.agent);if(r){if(r.dates.push(i.date),ph(e)>t){r.dates.pop();break}}else if(e.push({agent:i.agent,dates:[i.date]}),ph(e)>t){e.pop();break}s=s.slice(1)}return{heartbeatsToSend:e,unsentEntries:s}}class Lb{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Fp()?A_().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const e=await Vb(this.app);return e!=null&&e.heartbeats?e:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(t){var e;if(await this._canUseIndexedDBPromise){const i=await this.read();return hh(this.app,{lastSentHeartbeatDate:(e=t.lastSentHeartbeatDate)!==null&&e!==void 0?e:i.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){var e;if(await this._canUseIndexedDBPromise){const i=await this.read();return hh(this.app,{lastSentHeartbeatDate:(e=t.lastSentHeartbeatDate)!==null&&e!==void 0?e:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...t.heartbeats]})}else return}}function ph(n){return Np(JSON.stringify({version:2,heartbeats:n})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fb(n){ii(new ps("platform-logger",t=>new X_(t),"PRIVATE")),ii(new ps("heartbeat",t=>new Ob(t),"PRIVATE")),Dn(tl,uh,n),Dn(tl,uh,"esm2017"),Dn("fire-js","")}Fb("");var Ub="firebase",qb="10.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Dn(Ub,qb,"app");function Gl(n,t){var e={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&t.indexOf(s)<0&&(e[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var i=0,s=Object.getOwnPropertySymbols(n);i<s.length;i++)t.indexOf(s[i])<0&&Object.prototype.propertyIsEnumerable.call(n,s[i])&&(e[s[i]]=n[s[i]]);return e}function Gp(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Bb=Gp,Kp=new zr("auth","Firebase",Gp());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ea=new Bl("@firebase/auth");function jb(n,...t){ea.logLevel<=ot.WARN&&ea.warn(`Auth (${Ti}): ${n}`,...t)}function Oo(n,...t){ea.logLevel<=ot.ERROR&&ea.error(`Auth (${Ti}): ${n}`,...t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Me(n,...t){throw Kl(n,...t)}function Ge(n,...t){return Kl(n,...t)}function Wp(n,t,e){const s=Object.assign(Object.assign({},Bb()),{[t]:e});return new zr("auth","Firebase",s).create(t,{appName:n.name})}function $n(n){return Wp(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Kl(n,...t){if(typeof n!="string"){const e=t[0],s=[...t.slice(1)];return s[0]&&(s[0].appName=n.name),n._errorFactory.create(e,...s)}return Kp.create(n,...t)}function tt(n,t,...e){if(!n)throw Kl(t,...e)}function nn(n){const t="INTERNAL ASSERTION FAILED: "+n;throw Oo(t),new Error(t)}function cn(n,t){n||nn(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sl(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function zb(){return mh()==="http:"||mh()==="https:"}function mh(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gb(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(zb()||I_()||"connection"in navigator)?navigator.onLine:!0}function Kb(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kr{constructor(t,e){this.shortDelay=t,this.longDelay=e,cn(e>t,"Short delay should be less than long delay!"),this.isMobile=b_()||E_()}get(){return Gb()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wl(n,t){cn(n.emulator,"Emulator should always be set here");const{url:e}=n.emulator;return t?`${e}${t.startsWith("/")?t.slice(1):t}`:e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hp{static initialize(t,e,s){this.fetchImpl=t,e&&(this.headersImpl=e),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;nn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;nn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;nn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wb={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hb=new Kr(3e4,6e4);function As(n,t){return n.tenantId&&!t.tenantId?Object.assign(Object.assign({},t),{tenantId:n.tenantId}):t}async function Gn(n,t,e,s,i={}){return Qp(n,i,async()=>{let r={},o={};s&&(t==="GET"?o=s:r={body:JSON.stringify(s)});const a=Gr(Object.assign({key:n.config.apiKey},o)).slice(1),l=await n._getAdditionalHeaders();return l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode),Hp.fetch()(Jp(n,n.config.apiHost,e,a),Object.assign({method:t,headers:l,referrerPolicy:"no-referrer"},r))})}async function Qp(n,t,e){n._canInitEmulator=!1;const s=Object.assign(Object.assign({},Wb),t);try{const i=new Jb(n),r=await Promise.race([e(),i.promise]);i.clearNetworkTimeout();const o=await r.json();if("needConfirmation"in o)throw Ao(n,"account-exists-with-different-credential",o);if(r.ok&&!("errorMessage"in o))return o;{const a=r.ok?o.errorMessage:o.error.message,[l,u]=a.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw Ao(n,"credential-already-in-use",o);if(l==="EMAIL_EXISTS")throw Ao(n,"email-already-in-use",o);if(l==="USER_DISABLED")throw Ao(n,"user-disabled",o);const h=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw Wp(n,h,u);Me(n,h)}}catch(i){if(i instanceof dn)throw i;Me(n,"network-request-failed",{message:String(i)})}}async function Ca(n,t,e,s,i={}){const r=await Gn(n,t,e,s,i);return"mfaPendingCredential"in r&&Me(n,"multi-factor-auth-required",{_serverResponse:r}),r}function Jp(n,t,e,s){const i=`${t}${e}?${s}`;return n.config.emulator?Wl(n.config,i):`${n.config.apiScheme}://${i}`}function Qb(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class Jb{constructor(t){this.auth=t,this.timer=null,this.promise=new Promise((e,s)=>{this.timer=setTimeout(()=>s(Ge(this.auth,"network-request-failed")),Hb.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function Ao(n,t,e){const s={appName:n.name};e.email&&(s.email=e.email),e.phoneNumber&&(s.phoneNumber=e.phoneNumber);const i=Ge(n,t,s);return i.customData._tokenResponse=e,i}function gh(n){return n!==void 0&&n.enterprise!==void 0}class Yb{constructor(t){if(this.siteKey="",this.recaptchaEnforcementState=[],t.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=t.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=t.recaptchaEnforcementState}getProviderEnforcementState(t){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const e of this.recaptchaEnforcementState)if(e.provider&&e.provider===t)return Qb(e.enforcementState);return null}isProviderEnabled(t){return this.getProviderEnforcementState(t)==="ENFORCE"||this.getProviderEnforcementState(t)==="AUDIT"}}async function Xb(n,t){return Gn(n,"GET","/v2/recaptchaConfig",As(n,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Zb(n,t){return Gn(n,"POST","/v1/accounts:delete",t)}async function Yp(n,t){return Gn(n,"POST","/v1/accounts:lookup",t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dr(n){if(n)try{const t=new Date(Number(n));if(!isNaN(t.getTime()))return t.toUTCString()}catch{}}async function tw(n,t=!1){const e=Wt(n),s=await e.getIdToken(t),i=Hl(s);tt(i&&i.exp&&i.auth_time&&i.iat,e.auth,"internal-error");const r=typeof i.firebase=="object"?i.firebase:void 0,o=r==null?void 0:r.sign_in_provider;return{claims:i,token:s,authTime:dr(Oc(i.auth_time)),issuedAtTime:dr(Oc(i.iat)),expirationTime:dr(Oc(i.exp)),signInProvider:o||null,signInSecondFactor:(r==null?void 0:r.sign_in_second_factor)||null}}function Oc(n){return Number(n)*1e3}function Hl(n){const[t,e,s]=n.split(".");if(t===void 0||e===void 0||s===void 0)return Oo("JWT malformed, contained fewer than 3 sections"),null;try{const i=xp(e);return i?JSON.parse(i):(Oo("Failed to decode base64 JWT payload"),null)}catch(i){return Oo("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function yh(n){const t=Hl(n);return tt(t,"internal-error"),tt(typeof t.exp<"u","internal-error"),tt(typeof t.iat<"u","internal-error"),Number(t.exp)-Number(t.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Tr(n,t,e=!1){if(e)return t;try{return await t}catch(s){throw s instanceof dn&&ew(s)&&n.auth.currentUser===n&&await n.auth.signOut(),s}}function ew({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nw{constructor(t){this.user=t,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(t){var e;if(t){const s=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),s}else{this.errorBackoff=3e4;const i=((e=this.user.stsTokenManager.expirationTime)!==null&&e!==void 0?e:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(t=!1){if(!this.isRunning)return;const e=this.getInterval(t);this.timerId=setTimeout(async()=>{await this.iteration()},e)}async iteration(){try{await this.user.getIdToken(!0)}catch(t){(t==null?void 0:t.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class il{constructor(t,e){this.createdAt=t,this.lastLoginAt=e,this._initializeTime()}_initializeTime(){this.lastSignInTime=dr(this.lastLoginAt),this.creationTime=dr(this.createdAt)}_copy(t){this.createdAt=t.createdAt,this.lastLoginAt=t.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function na(n){var t;const e=n.auth,s=await n.getIdToken(),i=await Tr(n,Yp(e,{idToken:s}));tt(i==null?void 0:i.users.length,e,"internal-error");const r=i.users[0];n._notifyReloadListener(r);const o=!((t=r.providerUserInfo)===null||t===void 0)&&t.length?Xp(r.providerUserInfo):[],a=iw(n.providerData,o),l=n.isAnonymous,u=!(n.email&&r.passwordHash)&&!(a!=null&&a.length),h=l?u:!1,p={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:a,metadata:new il(r.createdAt,r.lastLoginAt),isAnonymous:h};Object.assign(n,p)}async function sw(n){const t=Wt(n);await na(t),await t.auth._persistUserIfCurrent(t),t.auth._notifyListenersIfCurrent(t)}function iw(n,t){return[...n.filter(s=>!t.some(i=>i.providerId===s.providerId)),...t]}function Xp(n){return n.map(t=>{var{providerId:e}=t,s=Gl(t,["providerId"]);return{providerId:e,uid:s.rawId||"",displayName:s.displayName||null,email:s.email||null,phoneNumber:s.phoneNumber||null,photoURL:s.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function rw(n,t){const e=await Qp(n,{},async()=>{const s=Gr({grant_type:"refresh_token",refresh_token:t}).slice(1),{tokenApiHost:i,apiKey:r}=n.config,o=Jp(n,i,"/v1/token",`key=${r}`),a=await n._getAdditionalHeaders();return a["Content-Type"]="application/x-www-form-urlencoded",Hp.fetch()(o,{method:"POST",headers:a,body:s})});return{accessToken:e.access_token,expiresIn:e.expires_in,refreshToken:e.refresh_token}}async function ow(n,t){return Gn(n,"POST","/v2/accounts:revokeToken",As(n,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ys{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(t){tt(t.idToken,"internal-error"),tt(typeof t.idToken<"u","internal-error"),tt(typeof t.refreshToken<"u","internal-error");const e="expiresIn"in t&&typeof t.expiresIn<"u"?Number(t.expiresIn):yh(t.idToken);this.updateTokensAndExpiration(t.idToken,t.refreshToken,e)}updateFromIdToken(t){tt(t.length!==0,"internal-error");const e=yh(t);this.updateTokensAndExpiration(t,null,e)}async getToken(t,e=!1){return!e&&this.accessToken&&!this.isExpired?this.accessToken:(tt(this.refreshToken,t,"user-token-expired"),this.refreshToken?(await this.refresh(t,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(t,e){const{accessToken:s,refreshToken:i,expiresIn:r}=await rw(t,e);this.updateTokensAndExpiration(s,i,Number(r))}updateTokensAndExpiration(t,e,s){this.refreshToken=e||null,this.accessToken=t||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(t,e){const{refreshToken:s,accessToken:i,expirationTime:r}=e,o=new Ys;return s&&(tt(typeof s=="string","internal-error",{appName:t}),o.refreshToken=s),i&&(tt(typeof i=="string","internal-error",{appName:t}),o.accessToken=i),r&&(tt(typeof r=="number","internal-error",{appName:t}),o.expirationTime=r),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(t){this.accessToken=t.accessToken,this.refreshToken=t.refreshToken,this.expirationTime=t.expirationTime}_clone(){return Object.assign(new Ys,this.toJSON())}_performRefresh(){return nn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yn(n,t){tt(typeof n=="string"||typeof n>"u","internal-error",{appName:t})}class sn{constructor(t){var{uid:e,auth:s,stsTokenManager:i}=t,r=Gl(t,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new nw(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=s,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new il(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(t){const e=await Tr(this,this.stsTokenManager.getToken(this.auth,t));return tt(e,this.auth,"internal-error"),this.accessToken!==e&&(this.accessToken=e,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),e}getIdTokenResult(t){return tw(this,t)}reload(){return sw(this)}_assign(t){this!==t&&(tt(this.uid===t.uid,this.auth,"internal-error"),this.displayName=t.displayName,this.photoURL=t.photoURL,this.email=t.email,this.emailVerified=t.emailVerified,this.phoneNumber=t.phoneNumber,this.isAnonymous=t.isAnonymous,this.tenantId=t.tenantId,this.providerData=t.providerData.map(e=>Object.assign({},e)),this.metadata._copy(t.metadata),this.stsTokenManager._assign(t.stsTokenManager))}_clone(t){const e=new sn(Object.assign(Object.assign({},this),{auth:t,stsTokenManager:this.stsTokenManager._clone()}));return e.metadata._copy(this.metadata),e}_onReload(t){tt(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=t,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(t){this.reloadListener?this.reloadListener(t):this.reloadUserInfo=t}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(t,e=!1){let s=!1;t.idToken&&t.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(t),s=!0),e&&await na(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(en(this.auth.app))return Promise.reject($n(this.auth));const t=await this.getIdToken();return await Tr(this,Zb(this.auth,{idToken:t})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(t=>Object.assign({},t)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(t,e){var s,i,r,o,a,l,u,h;const p=(s=e.displayName)!==null&&s!==void 0?s:void 0,m=(i=e.email)!==null&&i!==void 0?i:void 0,I=(r=e.phoneNumber)!==null&&r!==void 0?r:void 0,E=(o=e.photoURL)!==null&&o!==void 0?o:void 0,$=(a=e.tenantId)!==null&&a!==void 0?a:void 0,R=(l=e._redirectEventId)!==null&&l!==void 0?l:void 0,B=(u=e.createdAt)!==null&&u!==void 0?u:void 0,H=(h=e.lastLoginAt)!==null&&h!==void 0?h:void 0,{uid:K,emailVerified:st,isAnonymous:x,providerData:L,stsTokenManager:b}=e;tt(K&&b,t,"internal-error");const y=Ys.fromJSON(this.name,b);tt(typeof K=="string",t,"internal-error"),yn(p,t.name),yn(m,t.name),tt(typeof st=="boolean",t,"internal-error"),tt(typeof x=="boolean",t,"internal-error"),yn(I,t.name),yn(E,t.name),yn($,t.name),yn(R,t.name),yn(B,t.name),yn(H,t.name);const v=new sn({uid:K,auth:t,email:m,emailVerified:st,displayName:p,isAnonymous:x,photoURL:E,phoneNumber:I,tenantId:$,stsTokenManager:y,createdAt:B,lastLoginAt:H});return L&&Array.isArray(L)&&(v.providerData=L.map(w=>Object.assign({},w))),R&&(v._redirectEventId=R),v}static async _fromIdTokenResponse(t,e,s=!1){const i=new Ys;i.updateFromServerResponse(e);const r=new sn({uid:e.localId,auth:t,stsTokenManager:i,isAnonymous:s});return await na(r),r}static async _fromGetAccountInfoResponse(t,e,s){const i=e.users[0];tt(i.localId!==void 0,"internal-error");const r=i.providerUserInfo!==void 0?Xp(i.providerUserInfo):[],o=!(i.email&&i.passwordHash)&&!(r!=null&&r.length),a=new Ys;a.updateFromIdToken(s);const l=new sn({uid:i.localId,auth:t,stsTokenManager:a,isAnonymous:o}),u={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:r,metadata:new il(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(r!=null&&r.length)};return Object.assign(l,u),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vh=new Map;function rn(n){cn(n instanceof Function,"Expected a class definition");let t=vh.get(n);return t?(cn(t instanceof n,"Instance stored in cache mismatched with class"),t):(t=new n,vh.set(n,t),t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zp{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(t,e){this.storage[t]=e}async _get(t){const e=this.storage[t];return e===void 0?null:e}async _remove(t){delete this.storage[t]}_addListener(t,e){}_removeListener(t,e){}}Zp.type="NONE";const _h=Zp;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mo(n,t,e){return`firebase:${n}:${t}:${e}`}class Xs{constructor(t,e,s){this.persistence=t,this.auth=e,this.userKey=s;const{config:i,name:r}=this.auth;this.fullUserKey=Mo(this.userKey,i.apiKey,r),this.fullPersistenceKey=Mo("persistence",i.apiKey,r),this.boundEventHandler=e._onStorageEvent.bind(e),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(t){return this.persistence._set(this.fullUserKey,t.toJSON())}async getCurrentUser(){const t=await this.persistence._get(this.fullUserKey);return t?sn._fromJSON(this.auth,t):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(t){if(this.persistence===t)return;const e=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=t,e)return this.setCurrentUser(e)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(t,e,s="authUser"){if(!e.length)return new Xs(rn(_h),t,s);const i=(await Promise.all(e.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let r=i[0]||rn(_h);const o=Mo(s,t.config.apiKey,t.name);let a=null;for(const u of e)try{const h=await u._get(o);if(h){const p=sn._fromJSON(t,h);u!==r&&(a=p),r=u;break}}catch{}const l=i.filter(u=>u._shouldAllowMigration);return!r._shouldAllowMigration||!l.length?new Xs(r,t,s):(r=l[0],a&&await r._set(o,a.toJSON()),await Promise.all(e.map(async u=>{if(u!==r)try{await u._remove(o)}catch{}})),new Xs(r,t,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bh(n){const t=n.toLowerCase();if(t.includes("opera/")||t.includes("opr/")||t.includes("opios/"))return"Opera";if(nm(t))return"IEMobile";if(t.includes("msie")||t.includes("trident/"))return"IE";if(t.includes("edge/"))return"Edge";if(tm(t))return"Firefox";if(t.includes("silk/"))return"Silk";if(im(t))return"Blackberry";if(rm(t))return"Webos";if(Ql(t))return"Safari";if((t.includes("chrome/")||em(t))&&!t.includes("edge/"))return"Chrome";if(sm(t))return"Android";{const e=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=n.match(e);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function tm(n=Bt()){return/firefox\//i.test(n)}function Ql(n=Bt()){const t=n.toLowerCase();return t.includes("safari/")&&!t.includes("chrome/")&&!t.includes("crios/")&&!t.includes("android")}function em(n=Bt()){return/crios\//i.test(n)}function nm(n=Bt()){return/iemobile/i.test(n)}function sm(n=Bt()){return/android/i.test(n)}function im(n=Bt()){return/blackberry/i.test(n)}function rm(n=Bt()){return/webos/i.test(n)}function Da(n=Bt()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function aw(n=Bt()){var t;return Da(n)&&!!(!((t=window.navigator)===null||t===void 0)&&t.standalone)}function cw(){return T_()&&document.documentMode===10}function om(n=Bt()){return Da(n)||sm(n)||rm(n)||im(n)||/windows phone/i.test(n)||nm(n)}function lw(){try{return!!(window&&window!==window.top)}catch{return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function am(n,t=[]){let e;switch(n){case"Browser":e=bh(Bt());break;case"Worker":e=`${bh(Bt())}-${n}`;break;default:e=n}const s=t.length?t.join(","):"FirebaseCore-web";return`${e}/JsCore/${Ti}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uw{constructor(t){this.auth=t,this.queue=[]}pushCallback(t,e){const s=r=>new Promise((o,a)=>{try{const l=t(r);o(l)}catch(l){a(l)}});s.onAbort=e,this.queue.push(s);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(t){if(this.auth.currentUser===t)return;const e=[];try{for(const s of this.queue)await s(t),s.onAbort&&e.push(s.onAbort)}catch(s){e.reverse();for(const i of e)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function dw(n,t={}){return Gn(n,"GET","/v2/passwordPolicy",As(n,t))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hw=6;class fw{constructor(t){var e,s,i,r;const o=t.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(e=o.minPasswordLength)!==null&&e!==void 0?e:hw,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=t.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(s=t.allowedNonAlphanumericCharacters)===null||s===void 0?void 0:s.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(r=t.forceUpgradeOnSignin)!==null&&r!==void 0?r:!1,this.schemaVersion=t.schemaVersion}validatePassword(t){var e,s,i,r,o,a;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(t,l),this.validatePasswordCharacterOptions(t,l),l.isValid&&(l.isValid=(e=l.meetsMinPasswordLength)!==null&&e!==void 0?e:!0),l.isValid&&(l.isValid=(s=l.meetsMaxPasswordLength)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(i=l.containsLowercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(r=l.containsUppercaseLetter)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(o=l.containsNumericCharacter)!==null&&o!==void 0?o:!0),l.isValid&&(l.isValid=(a=l.containsNonAlphanumericCharacter)!==null&&a!==void 0?a:!0),l}validatePasswordLengthOptions(t,e){const s=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;s&&(e.meetsMinPasswordLength=t.length>=s),i&&(e.meetsMaxPasswordLength=t.length<=i)}validatePasswordCharacterOptions(t,e){this.updatePasswordCharacterOptionsStatuses(e,!1,!1,!1,!1);let s;for(let i=0;i<t.length;i++)s=t.charAt(i),this.updatePasswordCharacterOptionsStatuses(e,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(t,e,s,i,r){this.customStrengthOptions.containsLowercaseLetter&&(t.containsLowercaseLetter||(t.containsLowercaseLetter=e)),this.customStrengthOptions.containsUppercaseLetter&&(t.containsUppercaseLetter||(t.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(t.containsNumericCharacter||(t.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(t.containsNonAlphanumericCharacter||(t.containsNonAlphanumericCharacter=r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pw{constructor(t,e,s,i){this.app=t,this.heartbeatServiceProvider=e,this.appCheckServiceProvider=s,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new wh(this),this.idTokenSubscription=new wh(this),this.beforeStateQueue=new uw(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Kp,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=t.name,this.clientVersion=i.sdkClientVersion}_initializeWithPersistence(t,e){return e&&(this._popupRedirectResolver=rn(e)),this._initializationPromise=this.queue(async()=>{var s,i;if(!this._deleted&&(this.persistenceManager=await Xs.create(this,t),!this._deleted)){if(!((s=this._popupRedirectResolver)===null||s===void 0)&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(e),this.lastNotifiedUid=((i=this.currentUser)===null||i===void 0?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const t=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!t)){if(this.currentUser&&t&&this.currentUser.uid===t.uid){this._currentUser._assign(t),await this.currentUser.getIdToken();return}await this._updateCurrentUser(t,!0)}}async initializeCurrentUserFromIdToken(t){try{const e=await Yp(this,{idToken:t}),s=await sn._fromGetAccountInfoResponse(this,e,t);await this.directlySetCurrentUser(s)}catch(e){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",e),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(t){var e;if(en(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(a,a))}):this.directlySetCurrentUser(null)}const s=await this.assertedPersistence.getCurrentUser();let i=s,r=!1;if(t&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(e=this.redirectUser)===null||e===void 0?void 0:e._redirectEventId,a=i==null?void 0:i._redirectEventId,l=await this.tryRedirectSignIn(t);(!o||o===a)&&(l!=null&&l.user)&&(i=l.user,r=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(i)}catch(o){i=s,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return tt(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(t){let e=null;try{e=await this._popupRedirectResolver._completeRedirectFn(this,t,!0)}catch{await this._setRedirectUser(null)}return e}async reloadAndSetCurrentUserOrClear(t){try{await na(t)}catch(e){if((e==null?void 0:e.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(t)}useDeviceLanguage(){this.languageCode=Kb()}async _delete(){this._deleted=!0}async updateCurrentUser(t){if(en(this.app))return Promise.reject($n(this));const e=t?Wt(t):null;return e&&tt(e.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(e&&e._clone(this))}async _updateCurrentUser(t,e=!1){if(!this._deleted)return t&&tt(this.tenantId===t.tenantId,this,"tenant-id-mismatch"),e||await this.beforeStateQueue.runMiddleware(t),this.queue(async()=>{await this.directlySetCurrentUser(t),this.notifyAuthListeners()})}async signOut(){return en(this.app)?Promise.reject($n(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(t){return en(this.app)?Promise.reject($n(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(rn(t))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(t){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const e=this._getPasswordPolicyInternal();return e.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):e.validatePassword(t)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const t=await dw(this),e=new fw(t);this.tenantId===null?this._projectPasswordPolicy=e:this._tenantPasswordPolicies[this.tenantId]=e}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(t){this._errorFactory=new zr("auth","Firebase",t())}onAuthStateChanged(t,e,s){return this.registerStateListener(this.authStateSubscription,t,e,s)}beforeAuthStateChanged(t,e){return this.beforeStateQueue.pushCallback(t,e)}onIdTokenChanged(t,e,s){return this.registerStateListener(this.idTokenSubscription,t,e,s)}authStateReady(){return new Promise((t,e)=>{if(this.currentUser)t();else{const s=this.onAuthStateChanged(()=>{s(),t()},e)}})}async revokeAccessToken(t){if(this.currentUser){const e=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:t,idToken:e};this.tenantId!=null&&(s.tenantId=this.tenantId),await ow(this,s)}}toJSON(){var t;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(t=this._currentUser)===null||t===void 0?void 0:t.toJSON()}}async _setRedirectUser(t,e){const s=await this.getOrInitRedirectPersistenceManager(e);return t===null?s.removeCurrentUser():s.setCurrentUser(t)}async getOrInitRedirectPersistenceManager(t){if(!this.redirectPersistenceManager){const e=t&&rn(t)||this._popupRedirectResolver;tt(e,this,"argument-error"),this.redirectPersistenceManager=await Xs.create(this,[rn(e._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(t){var e,s;return this._isInitialized&&await this.queue(async()=>{}),((e=this._currentUser)===null||e===void 0?void 0:e._redirectEventId)===t?this._currentUser:((s=this.redirectUser)===null||s===void 0?void 0:s._redirectEventId)===t?this.redirectUser:null}async _persistUserIfCurrent(t){if(t===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(t))}_notifyListenersIfCurrent(t){t===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t,e;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const s=(e=(t=this.currentUser)===null||t===void 0?void 0:t.uid)!==null&&e!==void 0?e:null;this.lastNotifiedUid!==s&&(this.lastNotifiedUid=s,this.authStateSubscription.next(this.currentUser))}registerStateListener(t,e,s,i){if(this._deleted)return()=>{};const r=typeof e=="function"?e:e.next.bind(e);let o=!1;const a=this._isInitialized?Promise.resolve():this._initializationPromise;if(tt(a,this,"internal-error"),a.then(()=>{o||r(this.currentUser)}),typeof e=="function"){const l=t.addObserver(e,s,i);return()=>{o=!0,l()}}else{const l=t.addObserver(e);return()=>{o=!0,l()}}}async directlySetCurrentUser(t){this.currentUser&&this.currentUser!==t&&this._currentUser._stopProactiveRefresh(),t&&this.isProactiveRefreshEnabled&&t._startProactiveRefresh(),this.currentUser=t,t?await this.assertedPersistence.setCurrentUser(t):await this.assertedPersistence.removeCurrentUser()}queue(t){return this.operations=this.operations.then(t,t),this.operations}get assertedPersistence(){return tt(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(t){!t||this.frameworks.includes(t)||(this.frameworks.push(t),this.frameworks.sort(),this.clientVersion=am(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var t;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const s=await((t=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||t===void 0?void 0:t.getHeartbeatsHeader());s&&(e["X-Firebase-Client"]=s);const i=await this._getAppCheckToken();return i&&(e["X-Firebase-AppCheck"]=i),e}async _getAppCheckToken(){var t;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||t===void 0?void 0:t.getToken());return e!=null&&e.error&&jb(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function Ai(n){return Wt(n)}class wh{constructor(t){this.auth=t,this.observer=null,this.addObserver=C_(e=>this.observer=e)}get next(){return tt(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let $a={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function mw(n){$a=n}function cm(n){return $a.loadJS(n)}function gw(){return $a.recaptchaEnterpriseScript}function yw(){return $a.gapiScript}function vw(n){return`__${n}${Math.floor(Math.random()*1e6)}`}const _w="recaptcha-enterprise",bw="NO_RECAPTCHA";class ww{constructor(t){this.type=_w,this.auth=Ai(t)}async verify(t="verify",e=!1){async function s(r){if(!e){if(r.tenantId==null&&r._agentRecaptchaConfig!=null)return r._agentRecaptchaConfig.siteKey;if(r.tenantId!=null&&r._tenantRecaptchaConfigs[r.tenantId]!==void 0)return r._tenantRecaptchaConfigs[r.tenantId].siteKey}return new Promise(async(o,a)=>{Xb(r,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)a(new Error("recaptcha Enterprise site key undefined"));else{const u=new Yb(l);return r.tenantId==null?r._agentRecaptchaConfig=u:r._tenantRecaptchaConfigs[r.tenantId]=u,o(u.siteKey)}}).catch(l=>{a(l)})})}function i(r,o,a){const l=window.grecaptcha;gh(l)?l.enterprise.ready(()=>{l.enterprise.execute(r,{action:t}).then(u=>{o(u)}).catch(()=>{o(bw)})}):a(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((r,o)=>{s(this.auth).then(a=>{if(!e&&gh(window.grecaptcha))i(a,r,o);else{if(typeof window>"u"){o(new Error("RecaptchaVerifier is only supported in browser"));return}let l=gw();l.length!==0&&(l+=a),cm(l).then(()=>{i(a,r,o)}).catch(u=>{o(u)})}}).catch(a=>{o(a)})})}}async function Ih(n,t,e,s=!1){const i=new ww(n);let r;try{r=await i.verify(e)}catch{r=await i.verify(e,!0)}const o=Object.assign({},t);return s?Object.assign(o,{captchaResp:r}):Object.assign(o,{captchaResponse:r}),Object.assign(o,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(o,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),o}async function Eh(n,t,e,s){var i;if(!((i=n._getRecaptchaConfig())===null||i===void 0)&&i.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const r=await Ih(n,t,e,e==="getOobCode");return s(n,r)}else return s(n,t).catch(async r=>{if(r.code==="auth/missing-recaptcha-token"){console.log(`${e} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const o=await Ih(n,t,e,e==="getOobCode");return s(n,o)}else return Promise.reject(r)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Iw(n,t){const e=zl(n,"auth");if(e.isInitialized()){const i=e.getImmediate(),r=e.getOptions();if(Ir(r,t??{}))return i;Me(i,"already-initialized")}return e.initialize({options:t})}function Ew(n,t){const e=(t==null?void 0:t.persistence)||[],s=(Array.isArray(e)?e:[e]).map(rn);t!=null&&t.errorMap&&n._updateErrorMap(t.errorMap),n._initializeWithPersistence(s,t==null?void 0:t.popupRedirectResolver)}function Tw(n,t,e){const s=Ai(n);tt(s._canInitEmulator,s,"emulator-config-failed"),tt(/^https?:\/\//.test(t),s,"invalid-emulator-scheme");const i=!1,r=lm(t),{host:o,port:a}=Aw(t),l=a===null?"":`:${a}`;s.config.emulator={url:`${r}//${o}${l}/`},s.settings.appVerificationDisabledForTesting=!0,s.emulatorConfig=Object.freeze({host:o,port:a,protocol:r.replace(":",""),options:Object.freeze({disableWarnings:i})}),Sw()}function lm(n){const t=n.indexOf(":");return t<0?"":n.substr(0,t+1)}function Aw(n){const t=lm(n),e=/(\/\/)?([^?#/]+)/.exec(n.substr(t.length));if(!e)return{host:"",port:null};const s=e[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(s);if(i){const r=i[1];return{host:r,port:Th(s.substr(r.length+1))}}else{const[r,o]=s.split(":");return{host:r,port:Th(o)}}}function Th(n){if(!n)return null;const t=Number(n);return isNaN(t)?null:t}function Sw(){function n(){const t=document.createElement("p"),e=t.style;t.innerText="Running in emulator mode. Do not use with production credentials.",e.position="fixed",e.width="100%",e.backgroundColor="#ffffff",e.border=".1em solid #000000",e.color="#b50000",e.bottom="0px",e.left="0px",e.margin="0px",e.zIndex="10000",e.textAlign="center",t.classList.add("firebase-emulator-warning"),document.body.appendChild(t)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jl{constructor(t,e){this.providerId=t,this.signInMethod=e}toJSON(){return nn("not implemented")}_getIdTokenResponse(t){return nn("not implemented")}_linkToIdToken(t,e){return nn("not implemented")}_getReauthenticationResolver(t){return nn("not implemented")}}async function kw(n,t){return Gn(n,"POST","/v1/accounts:signUp",t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rw(n,t){return Ca(n,"POST","/v1/accounts:signInWithPassword",As(n,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Pw(n,t){return Ca(n,"POST","/v1/accounts:signInWithEmailLink",As(n,t))}async function Cw(n,t){return Ca(n,"POST","/v1/accounts:signInWithEmailLink",As(n,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ar extends Jl{constructor(t,e,s,i=null){super("password",s),this._email=t,this._password=e,this._tenantId=i}static _fromEmailAndPassword(t,e){return new Ar(t,e,"password")}static _fromEmailAndCode(t,e,s=null){return new Ar(t,e,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(t){const e=typeof t=="string"?JSON.parse(t):t;if(e!=null&&e.email&&(e!=null&&e.password)){if(e.signInMethod==="password")return this._fromEmailAndPassword(e.email,e.password);if(e.signInMethod==="emailLink")return this._fromEmailAndCode(e.email,e.password,e.tenantId)}return null}async _getIdTokenResponse(t){switch(this.signInMethod){case"password":const e={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Eh(t,e,"signInWithPassword",Rw);case"emailLink":return Pw(t,{email:this._email,oobCode:this._password});default:Me(t,"internal-error")}}async _linkToIdToken(t,e){switch(this.signInMethod){case"password":const s={idToken:e,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Eh(t,s,"signUpPassword",kw);case"emailLink":return Cw(t,{idToken:e,email:this._email,oobCode:this._password});default:Me(t,"internal-error")}}_getReauthenticationResolver(t){return this._getIdTokenResponse(t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Zs(n,t){return Ca(n,"POST","/v1/accounts:signInWithIdp",As(n,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dw="http://localhost";class gs extends Jl{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(t){const e=new gs(t.providerId,t.signInMethod);return t.idToken||t.accessToken?(t.idToken&&(e.idToken=t.idToken),t.accessToken&&(e.accessToken=t.accessToken),t.nonce&&!t.pendingToken&&(e.nonce=t.nonce),t.pendingToken&&(e.pendingToken=t.pendingToken)):t.oauthToken&&t.oauthTokenSecret?(e.accessToken=t.oauthToken,e.secret=t.oauthTokenSecret):Me("argument-error"),e}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(t){const e=typeof t=="string"?JSON.parse(t):t,{providerId:s,signInMethod:i}=e,r=Gl(e,["providerId","signInMethod"]);if(!s||!i)return null;const o=new gs(s,i);return o.idToken=r.idToken||void 0,o.accessToken=r.accessToken||void 0,o.secret=r.secret,o.nonce=r.nonce,o.pendingToken=r.pendingToken||null,o}_getIdTokenResponse(t){const e=this.buildRequest();return Zs(t,e)}_linkToIdToken(t,e){const s=this.buildRequest();return s.idToken=e,Zs(t,s)}_getReauthenticationResolver(t){const e=this.buildRequest();return e.autoCreate=!1,Zs(t,e)}buildRequest(){const t={requestUri:Dw,returnSecureToken:!0};if(this.pendingToken)t.pendingToken=this.pendingToken;else{const e={};this.idToken&&(e.id_token=this.idToken),this.accessToken&&(e.access_token=this.accessToken),this.secret&&(e.oauth_token_secret=this.secret),e.providerId=this.providerId,this.nonce&&!this.pendingToken&&(e.nonce=this.nonce),t.postBody=Gr(e)}return t}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $w(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function Vw(n){const t=ir(rr(n)).link,e=t?ir(rr(t)).deep_link_id:null,s=ir(rr(n)).deep_link_id;return(s?ir(rr(s)).link:null)||s||e||t||n}class Yl{constructor(t){var e,s,i,r,o,a;const l=ir(rr(t)),u=(e=l.apiKey)!==null&&e!==void 0?e:null,h=(s=l.oobCode)!==null&&s!==void 0?s:null,p=$w((i=l.mode)!==null&&i!==void 0?i:null);tt(u&&h&&p,"argument-error"),this.apiKey=u,this.operation=p,this.code=h,this.continueUrl=(r=l.continueUrl)!==null&&r!==void 0?r:null,this.languageCode=(o=l.languageCode)!==null&&o!==void 0?o:null,this.tenantId=(a=l.tenantId)!==null&&a!==void 0?a:null}static parseLink(t){const e=Vw(t);try{return new Yl(e)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Si{constructor(){this.providerId=Si.PROVIDER_ID}static credential(t,e){return Ar._fromEmailAndPassword(t,e)}static credentialWithLink(t,e){const s=Yl.parseLink(e);return tt(s,"argument-error"),Ar._fromEmailAndCode(t,s.code,s.tenantId)}}Si.PROVIDER_ID="password";Si.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Si.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class um{constructor(t){this.providerId=t,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(t){this.defaultLanguageCode=t}setCustomParameters(t){return this.customParameters=t,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wr extends um{constructor(){super(...arguments),this.scopes=[]}addScope(t){return this.scopes.includes(t)||this.scopes.push(t),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class En extends Wr{constructor(){super("facebook.com")}static credential(t){return gs._fromParams({providerId:En.PROVIDER_ID,signInMethod:En.FACEBOOK_SIGN_IN_METHOD,accessToken:t})}static credentialFromResult(t){return En.credentialFromTaggedObject(t)}static credentialFromError(t){return En.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t||!("oauthAccessToken"in t)||!t.oauthAccessToken)return null;try{return En.credential(t.oauthAccessToken)}catch{return null}}}En.FACEBOOK_SIGN_IN_METHOD="facebook.com";En.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tn extends Wr{constructor(){super("google.com"),this.addScope("profile")}static credential(t,e){return gs._fromParams({providerId:Tn.PROVIDER_ID,signInMethod:Tn.GOOGLE_SIGN_IN_METHOD,idToken:t,accessToken:e})}static credentialFromResult(t){return Tn.credentialFromTaggedObject(t)}static credentialFromError(t){return Tn.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{oauthIdToken:e,oauthAccessToken:s}=t;if(!e&&!s)return null;try{return Tn.credential(e,s)}catch{return null}}}Tn.GOOGLE_SIGN_IN_METHOD="google.com";Tn.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class An extends Wr{constructor(){super("github.com")}static credential(t){return gs._fromParams({providerId:An.PROVIDER_ID,signInMethod:An.GITHUB_SIGN_IN_METHOD,accessToken:t})}static credentialFromResult(t){return An.credentialFromTaggedObject(t)}static credentialFromError(t){return An.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t||!("oauthAccessToken"in t)||!t.oauthAccessToken)return null;try{return An.credential(t.oauthAccessToken)}catch{return null}}}An.GITHUB_SIGN_IN_METHOD="github.com";An.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sn extends Wr{constructor(){super("twitter.com")}static credential(t,e){return gs._fromParams({providerId:Sn.PROVIDER_ID,signInMethod:Sn.TWITTER_SIGN_IN_METHOD,oauthToken:t,oauthTokenSecret:e})}static credentialFromResult(t){return Sn.credentialFromTaggedObject(t)}static credentialFromError(t){return Sn.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{oauthAccessToken:e,oauthTokenSecret:s}=t;if(!e||!s)return null;try{return Sn.credential(e,s)}catch{return null}}}Sn.TWITTER_SIGN_IN_METHOD="twitter.com";Sn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ri{constructor(t){this.user=t.user,this.providerId=t.providerId,this._tokenResponse=t._tokenResponse,this.operationType=t.operationType}static async _fromIdTokenResponse(t,e,s,i=!1){const r=await sn._fromIdTokenResponse(t,s,i),o=Ah(s);return new ri({user:r,providerId:o,_tokenResponse:s,operationType:e})}static async _forOperation(t,e,s){await t._updateTokensIfNecessary(s,!0);const i=Ah(s);return new ri({user:t,providerId:i,_tokenResponse:s,operationType:e})}}function Ah(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sa extends dn{constructor(t,e,s,i){var r;super(e.code,e.message),this.operationType=s,this.user=i,Object.setPrototypeOf(this,sa.prototype),this.customData={appName:t.name,tenantId:(r=t.tenantId)!==null&&r!==void 0?r:void 0,_serverResponse:e.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(t,e,s,i){return new sa(t,e,s,i)}}function dm(n,t,e,s){return(t==="reauthenticate"?e._getReauthenticationResolver(n):e._getIdTokenResponse(n)).catch(r=>{throw r.code==="auth/multi-factor-auth-required"?sa._fromErrorAndOperation(n,r,t,s):r})}async function Nw(n,t,e=!1){const s=await Tr(n,t._linkToIdToken(n.auth,await n.getIdToken()),e);return ri._forOperation(n,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xw(n,t,e=!1){const{auth:s}=n;if(en(s.app))return Promise.reject($n(s));const i="reauthenticate";try{const r=await Tr(n,dm(s,i,t,n),e);tt(r.idToken,s,"internal-error");const o=Hl(r.idToken);tt(o,s,"internal-error");const{sub:a}=o;return tt(n.uid===a,s,"user-mismatch"),ri._forOperation(n,i,r)}catch(r){throw(r==null?void 0:r.code)==="auth/user-not-found"&&Me(s,"user-mismatch"),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function hm(n,t,e=!1){if(en(n.app))return Promise.reject($n(n));const s="signIn",i=await dm(n,s,t),r=await ri._fromIdTokenResponse(n,s,i);return e||await n._updateCurrentUser(r.user),r}async function Ow(n,t){return hm(Ai(n),t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Mw(n){const t=Ai(n);t._getPasswordPolicyInternal()&&await t._updatePasswordPolicy()}function Lw(n,t,e){return en(n.app)?Promise.reject($n(n)):Ow(Wt(n),Si.credential(t,e)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&Mw(n),s})}function Fw(n,t,e,s){return Wt(n).onIdTokenChanged(t,e,s)}function Uw(n,t,e){return Wt(n).beforeAuthStateChanged(t,e)}function qw(n,t,e,s){return Wt(n).onAuthStateChanged(t,e,s)}function Bw(n){return Wt(n).signOut()}const ia="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fm{constructor(t,e){this.storageRetriever=t,this.type=e}_isAvailable(){try{return this.storage?(this.storage.setItem(ia,"1"),this.storage.removeItem(ia),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(t,e){return this.storage.setItem(t,JSON.stringify(e)),Promise.resolve()}_get(t){const e=this.storage.getItem(t);return Promise.resolve(e?JSON.parse(e):null)}_remove(t){return this.storage.removeItem(t),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jw(){const n=Bt();return Ql(n)||Da(n)}const zw=1e3,Gw=10;class pm extends fm{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(t,e)=>this.onStorageEvent(t,e),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=jw()&&lw(),this.fallbackToPolling=om(),this._shouldAllowMigration=!0}forAllChangedKeys(t){for(const e of Object.keys(this.listeners)){const s=this.storage.getItem(e),i=this.localCache[e];s!==i&&t(e,i,s)}}onStorageEvent(t,e=!1){if(!t.key){this.forAllChangedKeys((o,a,l)=>{this.notifyListeners(o,l)});return}const s=t.key;if(e?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const o=this.storage.getItem(s);if(t.newValue!==o)t.newValue!==null?this.storage.setItem(s,t.newValue):this.storage.removeItem(s);else if(this.localCache[s]===t.newValue&&!e)return}const i=()=>{const o=this.storage.getItem(s);!e&&this.localCache[s]===o||this.notifyListeners(s,o)},r=this.storage.getItem(s);cw()&&r!==t.newValue&&t.newValue!==t.oldValue?setTimeout(i,Gw):i()}notifyListeners(t,e){this.localCache[t]=e;const s=this.listeners[t];if(s)for(const i of Array.from(s))i(e&&JSON.parse(e))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((t,e,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:t,oldValue:e,newValue:s}),!0)})},zw)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(t,e){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[t]||(this.listeners[t]=new Set,this.localCache[t]=this.storage.getItem(t)),this.listeners[t].add(e)}_removeListener(t,e){this.listeners[t]&&(this.listeners[t].delete(e),this.listeners[t].size===0&&delete this.listeners[t]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(t,e){await super._set(t,e),this.localCache[t]=JSON.stringify(e)}async _get(t){const e=await super._get(t);return this.localCache[t]=JSON.stringify(e),e}async _remove(t){await super._remove(t),delete this.localCache[t]}}pm.type="LOCAL";const Kw=pm;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mm extends fm{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(t,e){}_removeListener(t,e){}}mm.type="SESSION";const gm=mm;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ww(n){return Promise.all(n.map(async t=>{try{return{fulfilled:!0,value:await t}}catch(e){return{fulfilled:!1,reason:e}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Va{constructor(t){this.eventTarget=t,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(t){const e=this.receivers.find(i=>i.isListeningto(t));if(e)return e;const s=new Va(t);return this.receivers.push(s),s}isListeningto(t){return this.eventTarget===t}async handleEvent(t){const e=t,{eventId:s,eventType:i,data:r}=e.data,o=this.handlersMap[i];if(!(o!=null&&o.size))return;e.ports[0].postMessage({status:"ack",eventId:s,eventType:i});const a=Array.from(o).map(async u=>u(e.origin,r)),l=await Ww(a);e.ports[0].postMessage({status:"done",eventId:s,eventType:i,response:l})}_subscribe(t,e){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[t]||(this.handlersMap[t]=new Set),this.handlersMap[t].add(e)}_unsubscribe(t,e){this.handlersMap[t]&&e&&this.handlersMap[t].delete(e),(!e||this.handlersMap[t].size===0)&&delete this.handlersMap[t],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Va.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xl(n="",t=10){let e="";for(let s=0;s<t;s++)e+=Math.floor(Math.random()*10);return n+e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hw{constructor(t){this.target=t,this.handlers=new Set}removeMessageHandler(t){t.messageChannel&&(t.messageChannel.port1.removeEventListener("message",t.onMessage),t.messageChannel.port1.close()),this.handlers.delete(t)}async _send(t,e,s=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let r,o;return new Promise((a,l)=>{const u=Xl("",20);i.port1.start();const h=setTimeout(()=>{l(new Error("unsupported_event"))},s);o={messageChannel:i,onMessage(p){const m=p;if(m.data.eventId===u)switch(m.data.status){case"ack":clearTimeout(h),r=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(r),a(m.data.response);break;default:clearTimeout(h),clearTimeout(r),l(new Error("invalid_response"));break}}},this.handlers.add(o),i.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:t,eventId:u,data:e},[i.port2])}).finally(()=>{o&&this.removeMessageHandler(o)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ke(){return window}function Qw(n){Ke().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ym(){return typeof Ke().WorkerGlobalScope<"u"&&typeof Ke().importScripts=="function"}async function Jw(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function Yw(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function Xw(){return ym()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vm="firebaseLocalStorageDb",Zw=1,ra="firebaseLocalStorage",_m="fbase_key";class Hr{constructor(t){this.request=t}toPromise(){return new Promise((t,e)=>{this.request.addEventListener("success",()=>{t(this.request.result)}),this.request.addEventListener("error",()=>{e(this.request.error)})})}}function Na(n,t){return n.transaction([ra],t?"readwrite":"readonly").objectStore(ra)}function tI(){const n=indexedDB.deleteDatabase(vm);return new Hr(n).toPromise()}function rl(){const n=indexedDB.open(vm,Zw);return new Promise((t,e)=>{n.addEventListener("error",()=>{e(n.error)}),n.addEventListener("upgradeneeded",()=>{const s=n.result;try{s.createObjectStore(ra,{keyPath:_m})}catch(i){e(i)}}),n.addEventListener("success",async()=>{const s=n.result;s.objectStoreNames.contains(ra)?t(s):(s.close(),await tI(),t(await rl()))})})}async function Sh(n,t,e){const s=Na(n,!0).put({[_m]:t,value:e});return new Hr(s).toPromise()}async function eI(n,t){const e=Na(n,!1).get(t),s=await new Hr(e).toPromise();return s===void 0?null:s.value}function kh(n,t){const e=Na(n,!0).delete(t);return new Hr(e).toPromise()}const nI=800,sI=3;class bm{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await rl(),this.db)}async _withRetries(t){let e=0;for(;;)try{const s=await this._openDb();return await t(s)}catch(s){if(e++>sI)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return ym()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Va._getInstance(Xw()),this.receiver._subscribe("keyChanged",async(t,e)=>({keyProcessed:(await this._poll()).includes(e.key)})),this.receiver._subscribe("ping",async(t,e)=>["keyChanged"])}async initializeSender(){var t,e;if(this.activeServiceWorker=await Jw(),!this.activeServiceWorker)return;this.sender=new Hw(this.activeServiceWorker);const s=await this.sender._send("ping",{},800);s&&!((t=s[0])===null||t===void 0)&&t.fulfilled&&!((e=s[0])===null||e===void 0)&&e.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(t){if(!(!this.sender||!this.activeServiceWorker||Yw()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:t},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const t=await rl();return await Sh(t,ia,"1"),await kh(t,ia),!0}catch{}return!1}async _withPendingWrite(t){this.pendingWrites++;try{await t()}finally{this.pendingWrites--}}async _set(t,e){return this._withPendingWrite(async()=>(await this._withRetries(s=>Sh(s,t,e)),this.localCache[t]=e,this.notifyServiceWorker(t)))}async _get(t){const e=await this._withRetries(s=>eI(s,t));return this.localCache[t]=e,e}async _remove(t){return this._withPendingWrite(async()=>(await this._withRetries(e=>kh(e,t)),delete this.localCache[t],this.notifyServiceWorker(t)))}async _poll(){const t=await this._withRetries(i=>{const r=Na(i,!1).getAll();return new Hr(r).toPromise()});if(!t)return[];if(this.pendingWrites!==0)return[];const e=[],s=new Set;if(t.length!==0)for(const{fbase_key:i,value:r}of t)s.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(r)&&(this.notifyListeners(i,r),e.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!s.has(i)&&(this.notifyListeners(i,null),e.push(i));return e}notifyListeners(t,e){this.localCache[t]=e;const s=this.listeners[t];if(s)for(const i of Array.from(s))i(e)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),nI)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(t,e){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[t]||(this.listeners[t]=new Set,this._get(t)),this.listeners[t].add(e)}_removeListener(t,e){this.listeners[t]&&(this.listeners[t].delete(e),this.listeners[t].size===0&&delete this.listeners[t]),Object.keys(this.listeners).length===0&&this.stopPolling()}}bm.type="LOCAL";const iI=bm;new Kr(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rI(n,t){return t?rn(t):(tt(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zl extends Jl{constructor(t){super("custom","custom"),this.params=t}_getIdTokenResponse(t){return Zs(t,this._buildIdpRequest())}_linkToIdToken(t,e){return Zs(t,this._buildIdpRequest(e))}_getReauthenticationResolver(t){return Zs(t,this._buildIdpRequest())}_buildIdpRequest(t){const e={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return t&&(e.idToken=t),e}}function oI(n){return hm(n.auth,new Zl(n),n.bypassAuthState)}function aI(n){const{auth:t,user:e}=n;return tt(e,t,"internal-error"),xw(e,new Zl(n),n.bypassAuthState)}async function cI(n){const{auth:t,user:e}=n;return tt(e,t,"internal-error"),Nw(e,new Zl(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wm{constructor(t,e,s,i,r=!1){this.auth=t,this.resolver=s,this.user=i,this.bypassAuthState=r,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(e)?e:[e]}execute(){return new Promise(async(t,e)=>{this.pendingPromise={resolve:t,reject:e};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(t){const{urlResponse:e,sessionId:s,postBody:i,tenantId:r,error:o,type:a}=t;if(o){this.reject(o);return}const l={auth:this.auth,requestUri:e,sessionId:s,tenantId:r||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(a)(l))}catch(u){this.reject(u)}}onError(t){this.reject(t)}getIdpTask(t){switch(t){case"signInViaPopup":case"signInViaRedirect":return oI;case"linkViaPopup":case"linkViaRedirect":return cI;case"reauthViaPopup":case"reauthViaRedirect":return aI;default:Me(this.auth,"internal-error")}}resolve(t){cn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(t),this.unregisterAndCleanUp()}reject(t){cn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(t),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lI=new Kr(2e3,1e4);class Qs extends wm{constructor(t,e,s,i,r){super(t,e,i,r),this.provider=s,this.authWindow=null,this.pollId=null,Qs.currentPopupAction&&Qs.currentPopupAction.cancel(),Qs.currentPopupAction=this}async executeNotNull(){const t=await this.execute();return tt(t,this.auth,"internal-error"),t}async onExecution(){cn(this.filter.length===1,"Popup operations only handle one event");const t=Xl();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],t),this.authWindow.associatedEvent=t,this.resolver._originValidation(this.auth).catch(e=>{this.reject(e)}),this.resolver._isIframeWebStorageSupported(this.auth,e=>{e||this.reject(Ge(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var t;return((t=this.authWindow)===null||t===void 0?void 0:t.associatedEvent)||null}cancel(){this.reject(Ge(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,Qs.currentPopupAction=null}pollUserCancellation(){const t=()=>{var e,s;if(!((s=(e=this.authWindow)===null||e===void 0?void 0:e.window)===null||s===void 0)&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Ge(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(t,lI.get())};t()}}Qs.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uI="pendingRedirect",Lo=new Map;class dI extends wm{constructor(t,e,s=!1){super(t,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],e,void 0,s),this.eventId=null}async execute(){let t=Lo.get(this.auth._key());if(!t){try{const s=await hI(this.resolver,this.auth)?await super.execute():null;t=()=>Promise.resolve(s)}catch(e){t=()=>Promise.reject(e)}Lo.set(this.auth._key(),t)}return this.bypassAuthState||Lo.set(this.auth._key(),()=>Promise.resolve(null)),t()}async onAuthEvent(t){if(t.type==="signInViaRedirect")return super.onAuthEvent(t);if(t.type==="unknown"){this.resolve(null);return}if(t.eventId){const e=await this.auth._redirectUserForId(t.eventId);if(e)return this.user=e,super.onAuthEvent(t);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function hI(n,t){const e=mI(t),s=pI(n);if(!await s._isAvailable())return!1;const i=await s._get(e)==="true";return await s._remove(e),i}function fI(n,t){Lo.set(n._key(),t)}function pI(n){return rn(n._redirectPersistence)}function mI(n){return Mo(uI,n.config.apiKey,n.name)}async function gI(n,t,e=!1){if(en(n.app))return Promise.reject($n(n));const s=Ai(n),i=rI(s,t),o=await new dI(s,i,e).execute();return o&&!e&&(delete o.user._redirectEventId,await s._persistUserIfCurrent(o.user),await s._setRedirectUser(null,t)),o}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yI=10*60*1e3;class vI{constructor(t){this.auth=t,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(t){this.consumers.add(t),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,t)&&(this.sendToConsumer(this.queuedRedirectEvent,t),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(t){this.consumers.delete(t)}onEvent(t){if(this.hasEventBeenHandled(t))return!1;let e=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(t,s)&&(e=!0,this.sendToConsumer(t,s),this.saveEventToCache(t))}),this.hasHandledPotentialRedirect||!_I(t)||(this.hasHandledPotentialRedirect=!0,e||(this.queuedRedirectEvent=t,e=!0)),e}sendToConsumer(t,e){var s;if(t.error&&!Im(t)){const i=((s=t.error.code)===null||s===void 0?void 0:s.split("auth/")[1])||"internal-error";e.onError(Ge(this.auth,i))}else e.onAuthEvent(t)}isEventForConsumer(t,e){const s=e.eventId===null||!!t.eventId&&t.eventId===e.eventId;return e.filter.includes(t.type)&&s}hasEventBeenHandled(t){return Date.now()-this.lastProcessedEventTime>=yI&&this.cachedEventUids.clear(),this.cachedEventUids.has(Rh(t))}saveEventToCache(t){this.cachedEventUids.add(Rh(t)),this.lastProcessedEventTime=Date.now()}}function Rh(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(t=>t).join("-")}function Im({type:n,error:t}){return n==="unknown"&&(t==null?void 0:t.code)==="auth/no-auth-event"}function _I(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Im(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function bI(n,t={}){return Gn(n,"GET","/v1/projects",t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wI=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,II=/^https?/;async function EI(n){if(n.config.emulator)return;const{authorizedDomains:t}=await bI(n);for(const e of t)try{if(TI(e))return}catch{}Me(n,"unauthorized-domain")}function TI(n){const t=sl(),{protocol:e,hostname:s}=new URL(t);if(n.startsWith("chrome-extension://")){const o=new URL(n);return o.hostname===""&&s===""?e==="chrome-extension:"&&n.replace("chrome-extension://","")===t.replace("chrome-extension://",""):e==="chrome-extension:"&&o.hostname===s}if(!II.test(e))return!1;if(wI.test(n))return s===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const AI=new Kr(3e4,6e4);function Ph(){const n=Ke().___jsl;if(n!=null&&n.H){for(const t of Object.keys(n.H))if(n.H[t].r=n.H[t].r||[],n.H[t].L=n.H[t].L||[],n.H[t].r=[...n.H[t].L],n.CP)for(let e=0;e<n.CP.length;e++)n.CP[e]=null}}function SI(n){return new Promise((t,e)=>{var s,i,r;function o(){Ph(),gapi.load("gapi.iframes",{callback:()=>{t(gapi.iframes.getContext())},ontimeout:()=>{Ph(),e(Ge(n,"network-request-failed"))},timeout:AI.get()})}if(!((i=(s=Ke().gapi)===null||s===void 0?void 0:s.iframes)===null||i===void 0)&&i.Iframe)t(gapi.iframes.getContext());else if(!((r=Ke().gapi)===null||r===void 0)&&r.load)o();else{const a=vw("iframefcb");return Ke()[a]=()=>{gapi.load?o():e(Ge(n,"network-request-failed"))},cm(`${yw()}?onload=${a}`).catch(l=>e(l))}}).catch(t=>{throw Fo=null,t})}let Fo=null;function kI(n){return Fo=Fo||SI(n),Fo}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const RI=new Kr(5e3,15e3),PI="__/auth/iframe",CI="emulator/auth/iframe",DI={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},$I=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function VI(n){const t=n.config;tt(t.authDomain,n,"auth-domain-config-required");const e=t.emulator?Wl(t,CI):`https://${n.config.authDomain}/${PI}`,s={apiKey:t.apiKey,appName:n.name,v:Ti},i=$I.get(n.config.apiHost);i&&(s.eid=i);const r=n._getFrameworks();return r.length&&(s.fw=r.join(",")),`${e}?${Gr(s).slice(1)}`}async function NI(n){const t=await kI(n),e=Ke().gapi;return tt(e,n,"internal-error"),t.open({where:document.body,url:VI(n),messageHandlersFilter:e.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:DI,dontclear:!0},s=>new Promise(async(i,r)=>{await s.restyle({setHideOnLeave:!1});const o=Ge(n,"network-request-failed"),a=Ke().setTimeout(()=>{r(o)},RI.get());function l(){Ke().clearTimeout(a),i(s)}s.ping(l).then(l,()=>{r(o)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xI={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},OI=500,MI=600,LI="_blank",FI="http://localhost";class Ch{constructor(t){this.window=t,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function UI(n,t,e,s=OI,i=MI){const r=Math.max((window.screen.availHeight-i)/2,0).toString(),o=Math.max((window.screen.availWidth-s)/2,0).toString();let a="";const l=Object.assign(Object.assign({},xI),{width:s.toString(),height:i.toString(),top:r,left:o}),u=Bt().toLowerCase();e&&(a=em(u)?LI:e),tm(u)&&(t=t||FI,l.scrollbars="yes");const h=Object.entries(l).reduce((m,[I,E])=>`${m}${I}=${E},`,"");if(aw(u)&&a!=="_self")return qI(t||"",a),new Ch(null);const p=window.open(t||"",a,h);tt(p,n,"popup-blocked");try{p.focus()}catch{}return new Ch(p)}function qI(n,t){const e=document.createElement("a");e.href=n,e.target=t;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),e.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const BI="__/auth/handler",jI="emulator/auth/handler",zI=encodeURIComponent("fac");async function Dh(n,t,e,s,i,r){tt(n.config.authDomain,n,"auth-domain-config-required"),tt(n.config.apiKey,n,"invalid-api-key");const o={apiKey:n.config.apiKey,appName:n.name,authType:e,redirectUrl:s,v:Ti,eventId:i};if(t instanceof um){t.setDefaultLanguage(n.languageCode),o.providerId=t.providerId||"",P_(t.getCustomParameters())||(o.customParameters=JSON.stringify(t.getCustomParameters()));for(const[h,p]of Object.entries({}))o[h]=p}if(t instanceof Wr){const h=t.getScopes().filter(p=>p!=="");h.length>0&&(o.scopes=h.join(","))}n.tenantId&&(o.tid=n.tenantId);const a=o;for(const h of Object.keys(a))a[h]===void 0&&delete a[h];const l=await n._getAppCheckToken(),u=l?`#${zI}=${encodeURIComponent(l)}`:"";return`${GI(n)}?${Gr(a).slice(1)}${u}`}function GI({config:n}){return n.emulator?Wl(n,jI):`https://${n.authDomain}/${BI}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mc="webStorageSupport";class KI{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=gm,this._completeRedirectFn=gI,this._overrideRedirectResult=fI}async _openPopup(t,e,s,i){var r;cn((r=this.eventManagers[t._key()])===null||r===void 0?void 0:r.manager,"_initialize() not called before _openPopup()");const o=await Dh(t,e,s,sl(),i);return UI(t,o,Xl())}async _openRedirect(t,e,s,i){await this._originValidation(t);const r=await Dh(t,e,s,sl(),i);return Qw(r),new Promise(()=>{})}_initialize(t){const e=t._key();if(this.eventManagers[e]){const{manager:i,promise:r}=this.eventManagers[e];return i?Promise.resolve(i):(cn(r,"If manager is not set, promise should be"),r)}const s=this.initAndGetManager(t);return this.eventManagers[e]={promise:s},s.catch(()=>{delete this.eventManagers[e]}),s}async initAndGetManager(t){const e=await NI(t),s=new vI(t);return e.register("authEvent",i=>(tt(i==null?void 0:i.authEvent,t,"invalid-auth-event"),{status:s.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[t._key()]={manager:s},this.iframes[t._key()]=e,s}_isIframeWebStorageSupported(t,e){this.iframes[t._key()].send(Mc,{type:Mc},i=>{var r;const o=(r=i==null?void 0:i[0])===null||r===void 0?void 0:r[Mc];o!==void 0&&e(!!o),Me(t,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(t){const e=t._key();return this.originValidationPromises[e]||(this.originValidationPromises[e]=EI(t)),this.originValidationPromises[e]}get _shouldInitProactively(){return om()||Ql()||Da()}}const WI=KI;var $h="@firebase/auth",Vh="1.7.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HI{constructor(t){this.auth=t,this.internalListeners=new Map}getUid(){var t;return this.assertAuthConfigured(),((t=this.auth.currentUser)===null||t===void 0?void 0:t.uid)||null}async getToken(t){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(t)}:null}addAuthTokenListener(t){if(this.assertAuthConfigured(),this.internalListeners.has(t))return;const e=this.auth.onIdTokenChanged(s=>{t((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(t,e),this.updateProactiveRefresh()}removeAuthTokenListener(t){this.assertAuthConfigured();const e=this.internalListeners.get(t);e&&(this.internalListeners.delete(t),e(),this.updateProactiveRefresh())}assertAuthConfigured(){tt(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function QI(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function JI(n){ii(new ps("auth",(t,{options:e})=>{const s=t.getProvider("app").getImmediate(),i=t.getProvider("heartbeat"),r=t.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=s.options;tt(o&&!o.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:o,authDomain:a,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:am(n)},u=new pw(s,i,r,l);return Ew(u,e),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((t,e,s)=>{t.getProvider("auth-internal").initialize()})),ii(new ps("auth-internal",t=>{const e=Ai(t.getProvider("auth").getImmediate());return(s=>new HI(s))(e)},"PRIVATE").setInstantiationMode("EXPLICIT")),Dn($h,Vh,QI(n)),Dn($h,Vh,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const YI=5*60,XI=Mp("authIdTokenMaxAge")||YI;let Nh=null;const ZI=n=>async t=>{const e=t&&await t.getIdTokenResult(),s=e&&(new Date().getTime()-Date.parse(e.issuedAtTime))/1e3;if(s&&s>XI)return;const i=e==null?void 0:e.token;Nh!==i&&(Nh=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function tE(n=Cb()){const t=zl(n,"auth");if(t.isInitialized())return t.getImmediate();const e=Iw(n,{popupRedirectResolver:WI,persistence:[iI,Kw,gm]}),s=Mp("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const r=new URL(s,location.origin);if(location.origin===r.origin){const o=ZI(r.toString());Uw(e,o,()=>o(e.currentUser)),Fw(e,a=>o(a))}}const i=v_("auth");return i&&Tw(e,`http://${i}`),e}function eE(){var n,t;return(t=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&t!==void 0?t:document}mw({loadJS(n){return new Promise((t,e)=>{const s=document.createElement("script");s.setAttribute("src",n),s.onload=t,s.onerror=i=>{const r=Ge("internal-error");r.customData=i,e(r)},s.type="text/javascript",s.charset="UTF-8",eE().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});JI("Browser");var xh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var us,Em;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function t(b,y){function v(){}v.prototype=y.prototype,b.D=y.prototype,b.prototype=new v,b.prototype.constructor=b,b.C=function(w,T,S){for(var _=Array(arguments.length-2),ge=2;ge<arguments.length;ge++)_[ge-2]=arguments[ge];return y.prototype[T].apply(w,_)}}function e(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}t(s,e),s.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(b,y,v){v||(v=0);var w=Array(16);if(typeof y=="string")for(var T=0;16>T;++T)w[T]=y.charCodeAt(v++)|y.charCodeAt(v++)<<8|y.charCodeAt(v++)<<16|y.charCodeAt(v++)<<24;else for(T=0;16>T;++T)w[T]=y[v++]|y[v++]<<8|y[v++]<<16|y[v++]<<24;y=b.g[0],v=b.g[1],T=b.g[2];var S=b.g[3],_=y+(S^v&(T^S))+w[0]+3614090360&4294967295;y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+w[1]+3905402710&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+w[2]+606105819&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+w[3]+3250441966&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(S^v&(T^S))+w[4]+4118548399&4294967295,y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+w[5]+1200080426&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+w[6]+2821735955&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+w[7]+4249261313&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(S^v&(T^S))+w[8]+1770035416&4294967295,y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+w[9]+2336552879&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+w[10]+4294925233&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+w[11]+2304563134&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(S^v&(T^S))+w[12]+1804603682&4294967295,y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+w[13]+4254626195&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+w[14]+2792965006&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+w[15]+1236535329&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(T^S&(v^T))+w[1]+4129170786&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+w[6]+3225465664&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+w[11]+643717713&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+w[0]+3921069994&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(T^S&(v^T))+w[5]+3593408605&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+w[10]+38016083&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+w[15]+3634488961&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+w[4]+3889429448&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(T^S&(v^T))+w[9]+568446438&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+w[14]+3275163606&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+w[3]+4107603335&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+w[8]+1163531501&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(T^S&(v^T))+w[13]+2850285829&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+w[2]+4243563512&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+w[7]+1735328473&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+w[12]+2368359562&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(v^T^S)+w[5]+4294588738&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+w[8]+2272392833&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+w[11]+1839030562&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+w[14]+4259657740&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(v^T^S)+w[1]+2763975236&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+w[4]+1272893353&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+w[7]+4139469664&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+w[10]+3200236656&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(v^T^S)+w[13]+681279174&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+w[0]+3936430074&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+w[3]+3572445317&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+w[6]+76029189&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(v^T^S)+w[9]+3654602809&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+w[12]+3873151461&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+w[15]+530742520&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+w[2]+3299628645&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(T^(v|~S))+w[0]+4096336452&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+w[7]+1126891415&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+w[14]+2878612391&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+w[5]+4237533241&4294967295,v=T+(_<<21&4294967295|_>>>11),_=y+(T^(v|~S))+w[12]+1700485571&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+w[3]+2399980690&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+w[10]+4293915773&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+w[1]+2240044497&4294967295,v=T+(_<<21&4294967295|_>>>11),_=y+(T^(v|~S))+w[8]+1873313359&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+w[15]+4264355552&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+w[6]+2734768916&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+w[13]+1309151649&4294967295,v=T+(_<<21&4294967295|_>>>11),_=y+(T^(v|~S))+w[4]+4149444226&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+w[11]+3174756917&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+w[2]+718787259&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+w[9]+3951481745&4294967295,b.g[0]=b.g[0]+y&4294967295,b.g[1]=b.g[1]+(T+(_<<21&4294967295|_>>>11))&4294967295,b.g[2]=b.g[2]+T&4294967295,b.g[3]=b.g[3]+S&4294967295}s.prototype.u=function(b,y){y===void 0&&(y=b.length);for(var v=y-this.blockSize,w=this.B,T=this.h,S=0;S<y;){if(T==0)for(;S<=v;)i(this,b,S),S+=this.blockSize;if(typeof b=="string"){for(;S<y;)if(w[T++]=b.charCodeAt(S++),T==this.blockSize){i(this,w),T=0;break}}else for(;S<y;)if(w[T++]=b[S++],T==this.blockSize){i(this,w),T=0;break}}this.h=T,this.o+=y},s.prototype.v=function(){var b=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);b[0]=128;for(var y=1;y<b.length-8;++y)b[y]=0;var v=8*this.o;for(y=b.length-8;y<b.length;++y)b[y]=v&255,v/=256;for(this.u(b),b=Array(16),y=v=0;4>y;++y)for(var w=0;32>w;w+=8)b[v++]=this.g[y]>>>w&255;return b};function r(b,y){var v=a;return Object.prototype.hasOwnProperty.call(v,b)?v[b]:v[b]=y(b)}function o(b,y){this.h=y;for(var v=[],w=!0,T=b.length-1;0<=T;T--){var S=b[T]|0;w&&S==y||(v[T]=S,w=!1)}this.g=v}var a={};function l(b){return-128<=b&&128>b?r(b,function(y){return new o([y|0],0>y?-1:0)}):new o([b|0],0>b?-1:0)}function u(b){if(isNaN(b)||!isFinite(b))return p;if(0>b)return R(u(-b));for(var y=[],v=1,w=0;b>=v;w++)y[w]=b/v|0,v*=4294967296;return new o(y,0)}function h(b,y){if(b.length==0)throw Error("number format error: empty string");if(y=y||10,2>y||36<y)throw Error("radix out of range: "+y);if(b.charAt(0)=="-")return R(h(b.substring(1),y));if(0<=b.indexOf("-"))throw Error('number format error: interior "-" character');for(var v=u(Math.pow(y,8)),w=p,T=0;T<b.length;T+=8){var S=Math.min(8,b.length-T),_=parseInt(b.substring(T,T+S),y);8>S?(S=u(Math.pow(y,S)),w=w.j(S).add(u(_))):(w=w.j(v),w=w.add(u(_)))}return w}var p=l(0),m=l(1),I=l(16777216);n=o.prototype,n.m=function(){if($(this))return-R(this).m();for(var b=0,y=1,v=0;v<this.g.length;v++){var w=this.i(v);b+=(0<=w?w:4294967296+w)*y,y*=4294967296}return b},n.toString=function(b){if(b=b||10,2>b||36<b)throw Error("radix out of range: "+b);if(E(this))return"0";if($(this))return"-"+R(this).toString(b);for(var y=u(Math.pow(b,6)),v=this,w="";;){var T=st(v,y).g;v=B(v,T.j(y));var S=((0<v.g.length?v.g[0]:v.h)>>>0).toString(b);if(v=T,E(v))return S+w;for(;6>S.length;)S="0"+S;w=S+w}},n.i=function(b){return 0>b?0:b<this.g.length?this.g[b]:this.h};function E(b){if(b.h!=0)return!1;for(var y=0;y<b.g.length;y++)if(b.g[y]!=0)return!1;return!0}function $(b){return b.h==-1}n.l=function(b){return b=B(this,b),$(b)?-1:E(b)?0:1};function R(b){for(var y=b.g.length,v=[],w=0;w<y;w++)v[w]=~b.g[w];return new o(v,~b.h).add(m)}n.abs=function(){return $(this)?R(this):this},n.add=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],w=0,T=0;T<=y;T++){var S=w+(this.i(T)&65535)+(b.i(T)&65535),_=(S>>>16)+(this.i(T)>>>16)+(b.i(T)>>>16);w=_>>>16,S&=65535,_&=65535,v[T]=_<<16|S}return new o(v,v[v.length-1]&-2147483648?-1:0)};function B(b,y){return b.add(R(y))}n.j=function(b){if(E(this)||E(b))return p;if($(this))return $(b)?R(this).j(R(b)):R(R(this).j(b));if($(b))return R(this.j(R(b)));if(0>this.l(I)&&0>b.l(I))return u(this.m()*b.m());for(var y=this.g.length+b.g.length,v=[],w=0;w<2*y;w++)v[w]=0;for(w=0;w<this.g.length;w++)for(var T=0;T<b.g.length;T++){var S=this.i(w)>>>16,_=this.i(w)&65535,ge=b.i(T)>>>16,Fe=b.i(T)&65535;v[2*w+2*T]+=_*Fe,H(v,2*w+2*T),v[2*w+2*T+1]+=S*Fe,H(v,2*w+2*T+1),v[2*w+2*T+1]+=_*ge,H(v,2*w+2*T+1),v[2*w+2*T+2]+=S*ge,H(v,2*w+2*T+2)}for(w=0;w<y;w++)v[w]=v[2*w+1]<<16|v[2*w];for(w=y;w<2*y;w++)v[w]=0;return new o(v,0)};function H(b,y){for(;(b[y]&65535)!=b[y];)b[y+1]+=b[y]>>>16,b[y]&=65535,y++}function K(b,y){this.g=b,this.h=y}function st(b,y){if(E(y))throw Error("division by zero");if(E(b))return new K(p,p);if($(b))return y=st(R(b),y),new K(R(y.g),R(y.h));if($(y))return y=st(b,R(y)),new K(R(y.g),y.h);if(30<b.g.length){if($(b)||$(y))throw Error("slowDivide_ only works with positive integers.");for(var v=m,w=y;0>=w.l(b);)v=x(v),w=x(w);var T=L(v,1),S=L(w,1);for(w=L(w,2),v=L(v,2);!E(w);){var _=S.add(w);0>=_.l(b)&&(T=T.add(v),S=_),w=L(w,1),v=L(v,1)}return y=B(b,T.j(y)),new K(T,y)}for(T=p;0<=b.l(y);){for(v=Math.max(1,Math.floor(b.m()/y.m())),w=Math.ceil(Math.log(v)/Math.LN2),w=48>=w?1:Math.pow(2,w-48),S=u(v),_=S.j(y);$(_)||0<_.l(b);)v-=w,S=u(v),_=S.j(y);E(S)&&(S=m),T=T.add(S),b=B(b,_)}return new K(T,b)}n.A=function(b){return st(this,b).h},n.and=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],w=0;w<y;w++)v[w]=this.i(w)&b.i(w);return new o(v,this.h&b.h)},n.or=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],w=0;w<y;w++)v[w]=this.i(w)|b.i(w);return new o(v,this.h|b.h)},n.xor=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],w=0;w<y;w++)v[w]=this.i(w)^b.i(w);return new o(v,this.h^b.h)};function x(b){for(var y=b.g.length+1,v=[],w=0;w<y;w++)v[w]=b.i(w)<<1|b.i(w-1)>>>31;return new o(v,b.h)}function L(b,y){var v=y>>5;y%=32;for(var w=b.g.length-v,T=[],S=0;S<w;S++)T[S]=0<y?b.i(S+v)>>>y|b.i(S+v+1)<<32-y:b.i(S+v);return new o(T,b.h)}s.prototype.digest=s.prototype.v,s.prototype.reset=s.prototype.s,s.prototype.update=s.prototype.u,Em=s,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.A,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=u,o.fromString=h,us=o}).apply(typeof xh<"u"?xh:typeof self<"u"?self:typeof window<"u"?window:{});var So=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Tm,Am,or,Sm,Uo,ol,km,Rm,Pm;(function(){var n,t=typeof Object.defineProperties=="function"?Object.defineProperty:function(c,d,f){return c==Array.prototype||c==Object.prototype||(c[d]=f.value),c};function e(c){c=[typeof globalThis=="object"&&globalThis,c,typeof window=="object"&&window,typeof self=="object"&&self,typeof So=="object"&&So];for(var d=0;d<c.length;++d){var f=c[d];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var s=e(this);function i(c,d){if(d)t:{var f=s;c=c.split(".");for(var g=0;g<c.length-1;g++){var k=c[g];if(!(k in f))break t;f=f[k]}c=c[c.length-1],g=f[c],d=d(g),d!=g&&d!=null&&t(f,c,{configurable:!0,writable:!0,value:d})}}function r(c,d){c instanceof String&&(c+="");var f=0,g=!1,k={next:function(){if(!g&&f<c.length){var D=f++;return{value:d(D,c[D]),done:!1}}return g=!0,{done:!0,value:void 0}}};return k[Symbol.iterator]=function(){return k},k}i("Array.prototype.values",function(c){return c||function(){return r(this,function(d,f){return f})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},a=this||self;function l(c){var d=typeof c;return d=d!="object"?d:c?Array.isArray(c)?"array":d:"null",d=="array"||d=="object"&&typeof c.length=="number"}function u(c){var d=typeof c;return d=="object"&&c!=null||d=="function"}function h(c,d,f){return c.call.apply(c.bind,arguments)}function p(c,d,f){if(!c)throw Error();if(2<arguments.length){var g=Array.prototype.slice.call(arguments,2);return function(){var k=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(k,g),c.apply(d,k)}}return function(){return c.apply(d,arguments)}}function m(c,d,f){return m=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?h:p,m.apply(null,arguments)}function I(c,d){var f=Array.prototype.slice.call(arguments,1);return function(){var g=f.slice();return g.push.apply(g,arguments),c.apply(this,g)}}function E(c,d){function f(){}f.prototype=d.prototype,c.aa=d.prototype,c.prototype=new f,c.prototype.constructor=c,c.Qb=function(g,k,D){for(var M=Array(arguments.length-2),It=2;It<arguments.length;It++)M[It-2]=arguments[It];return d.prototype[k].apply(g,M)}}function $(c){const d=c.length;if(0<d){const f=Array(d);for(let g=0;g<d;g++)f[g]=c[g];return f}return[]}function R(c,d){for(let f=1;f<arguments.length;f++){const g=arguments[f];if(l(g)){const k=c.length||0,D=g.length||0;c.length=k+D;for(let M=0;M<D;M++)c[k+M]=g[M]}else c.push(g)}}class B{constructor(d,f){this.i=d,this.j=f,this.h=0,this.g=null}get(){let d;return 0<this.h?(this.h--,d=this.g,this.g=d.next,d.next=null):d=this.i(),d}}function H(c){return/^[\s\xa0]*$/.test(c)}function K(){var c=a.navigator;return c&&(c=c.userAgent)?c:""}function st(c){return st[" "](c),c}st[" "]=function(){};var x=K().indexOf("Gecko")!=-1&&!(K().toLowerCase().indexOf("webkit")!=-1&&K().indexOf("Edge")==-1)&&!(K().indexOf("Trident")!=-1||K().indexOf("MSIE")!=-1)&&K().indexOf("Edge")==-1;function L(c,d,f){for(const g in c)d.call(f,c[g],g,c)}function b(c,d){for(const f in c)d.call(void 0,c[f],f,c)}function y(c){const d={};for(const f in c)d[f]=c[f];return d}const v="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function w(c,d){let f,g;for(let k=1;k<arguments.length;k++){g=arguments[k];for(f in g)c[f]=g[f];for(let D=0;D<v.length;D++)f=v[D],Object.prototype.hasOwnProperty.call(g,f)&&(c[f]=g[f])}}function T(c){var d=1;c=c.split(":");const f=[];for(;0<d&&c.length;)f.push(c.shift()),d--;return c.length&&f.push(c.join(":")),f}function S(c){a.setTimeout(()=>{throw c},0)}function _(){var c=ac;let d=null;return c.g&&(d=c.g,c.g=c.g.next,c.g||(c.h=null),d.next=null),d}class ge{constructor(){this.h=this.g=null}add(d,f){const g=Fe.get();g.set(d,f),this.h?this.h.next=g:this.g=g,this.h=g}}var Fe=new B(()=>new Cv,c=>c.reset());class Cv{constructor(){this.next=this.g=this.h=null}set(d,f){this.h=d,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let Vi,Ni=!1,ac=new ge,rd=()=>{const c=a.Promise.resolve(void 0);Vi=()=>{c.then(Dv)}};var Dv=()=>{for(var c;c=_();){try{c.h.call(c.g)}catch(f){S(f)}var d=Fe;d.j(c),100>d.h&&(d.h++,c.next=d.g,d.g=c)}Ni=!1};function fn(){this.s=this.s,this.C=this.C}fn.prototype.s=!1,fn.prototype.ma=function(){this.s||(this.s=!0,this.N())},fn.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function te(c,d){this.type=c,this.g=this.target=d,this.defaultPrevented=!1}te.prototype.h=function(){this.defaultPrevented=!0};var $v=function(){if(!a.addEventListener||!Object.defineProperty)return!1;var c=!1,d=Object.defineProperty({},"passive",{get:function(){c=!0}});try{const f=()=>{};a.addEventListener("test",f,d),a.removeEventListener("test",f,d)}catch{}return c}();function xi(c,d){if(te.call(this,c?c.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,c){var f=this.type=c.type,g=c.changedTouches&&c.changedTouches.length?c.changedTouches[0]:null;if(this.target=c.target||c.srcElement,this.g=d,d=c.relatedTarget){if(x){t:{try{st(d.nodeName);var k=!0;break t}catch{}k=!1}k||(d=null)}}else f=="mouseover"?d=c.fromElement:f=="mouseout"&&(d=c.toElement);this.relatedTarget=d,g?(this.clientX=g.clientX!==void 0?g.clientX:g.pageX,this.clientY=g.clientY!==void 0?g.clientY:g.pageY,this.screenX=g.screenX||0,this.screenY=g.screenY||0):(this.clientX=c.clientX!==void 0?c.clientX:c.pageX,this.clientY=c.clientY!==void 0?c.clientY:c.pageY,this.screenX=c.screenX||0,this.screenY=c.screenY||0),this.button=c.button,this.key=c.key||"",this.ctrlKey=c.ctrlKey,this.altKey=c.altKey,this.shiftKey=c.shiftKey,this.metaKey=c.metaKey,this.pointerId=c.pointerId||0,this.pointerType=typeof c.pointerType=="string"?c.pointerType:Vv[c.pointerType]||"",this.state=c.state,this.i=c,c.defaultPrevented&&xi.aa.h.call(this)}}E(xi,te);var Vv={2:"touch",3:"pen",4:"mouse"};xi.prototype.h=function(){xi.aa.h.call(this);var c=this.i;c.preventDefault?c.preventDefault():c.returnValue=!1};var oo="closure_listenable_"+(1e6*Math.random()|0),Nv=0;function xv(c,d,f,g,k){this.listener=c,this.proxy=null,this.src=d,this.type=f,this.capture=!!g,this.ha=k,this.key=++Nv,this.da=this.fa=!1}function ao(c){c.da=!0,c.listener=null,c.proxy=null,c.src=null,c.ha=null}function co(c){this.src=c,this.g={},this.h=0}co.prototype.add=function(c,d,f,g,k){var D=c.toString();c=this.g[D],c||(c=this.g[D]=[],this.h++);var M=lc(c,d,g,k);return-1<M?(d=c[M],f||(d.fa=!1)):(d=new xv(d,this.src,D,!!g,k),d.fa=f,c.push(d)),d};function cc(c,d){var f=d.type;if(f in c.g){var g=c.g[f],k=Array.prototype.indexOf.call(g,d,void 0),D;(D=0<=k)&&Array.prototype.splice.call(g,k,1),D&&(ao(d),c.g[f].length==0&&(delete c.g[f],c.h--))}}function lc(c,d,f,g){for(var k=0;k<c.length;++k){var D=c[k];if(!D.da&&D.listener==d&&D.capture==!!f&&D.ha==g)return k}return-1}var uc="closure_lm_"+(1e6*Math.random()|0),dc={};function od(c,d,f,g,k){if(Array.isArray(d)){for(var D=0;D<d.length;D++)od(c,d[D],f,g,k);return null}return f=ld(f),c&&c[oo]?c.K(d,f,u(g)?!!g.capture:!1,k):Ov(c,d,f,!1,g,k)}function Ov(c,d,f,g,k,D){if(!d)throw Error("Invalid event type");var M=u(k)?!!k.capture:!!k,It=fc(c);if(It||(c[uc]=It=new co(c)),f=It.add(d,f,g,M,D),f.proxy)return f;if(g=Mv(),f.proxy=g,g.src=c,g.listener=f,c.addEventListener)$v||(k=M),k===void 0&&(k=!1),c.addEventListener(d.toString(),g,k);else if(c.attachEvent)c.attachEvent(cd(d.toString()),g);else if(c.addListener&&c.removeListener)c.addListener(g);else throw Error("addEventListener and attachEvent are unavailable.");return f}function Mv(){function c(f){return d.call(c.src,c.listener,f)}const d=Lv;return c}function ad(c,d,f,g,k){if(Array.isArray(d))for(var D=0;D<d.length;D++)ad(c,d[D],f,g,k);else g=u(g)?!!g.capture:!!g,f=ld(f),c&&c[oo]?(c=c.i,d=String(d).toString(),d in c.g&&(D=c.g[d],f=lc(D,f,g,k),-1<f&&(ao(D[f]),Array.prototype.splice.call(D,f,1),D.length==0&&(delete c.g[d],c.h--)))):c&&(c=fc(c))&&(d=c.g[d.toString()],c=-1,d&&(c=lc(d,f,g,k)),(f=-1<c?d[c]:null)&&hc(f))}function hc(c){if(typeof c!="number"&&c&&!c.da){var d=c.src;if(d&&d[oo])cc(d.i,c);else{var f=c.type,g=c.proxy;d.removeEventListener?d.removeEventListener(f,g,c.capture):d.detachEvent?d.detachEvent(cd(f),g):d.addListener&&d.removeListener&&d.removeListener(g),(f=fc(d))?(cc(f,c),f.h==0&&(f.src=null,d[uc]=null)):ao(c)}}}function cd(c){return c in dc?dc[c]:dc[c]="on"+c}function Lv(c,d){if(c.da)c=!0;else{d=new xi(d,this);var f=c.listener,g=c.ha||c.src;c.fa&&hc(c),c=f.call(g,d)}return c}function fc(c){return c=c[uc],c instanceof co?c:null}var pc="__closure_events_fn_"+(1e9*Math.random()>>>0);function ld(c){return typeof c=="function"?c:(c[pc]||(c[pc]=function(d){return c.handleEvent(d)}),c[pc])}function ee(){fn.call(this),this.i=new co(this),this.M=this,this.F=null}E(ee,fn),ee.prototype[oo]=!0,ee.prototype.removeEventListener=function(c,d,f,g){ad(this,c,d,f,g)};function le(c,d){var f,g=c.F;if(g)for(f=[];g;g=g.F)f.push(g);if(c=c.M,g=d.type||d,typeof d=="string")d=new te(d,c);else if(d instanceof te)d.target=d.target||c;else{var k=d;d=new te(g,c),w(d,k)}if(k=!0,f)for(var D=f.length-1;0<=D;D--){var M=d.g=f[D];k=lo(M,g,!0,d)&&k}if(M=d.g=c,k=lo(M,g,!0,d)&&k,k=lo(M,g,!1,d)&&k,f)for(D=0;D<f.length;D++)M=d.g=f[D],k=lo(M,g,!1,d)&&k}ee.prototype.N=function(){if(ee.aa.N.call(this),this.i){var c=this.i,d;for(d in c.g){for(var f=c.g[d],g=0;g<f.length;g++)ao(f[g]);delete c.g[d],c.h--}}this.F=null},ee.prototype.K=function(c,d,f,g){return this.i.add(String(c),d,!1,f,g)},ee.prototype.L=function(c,d,f,g){return this.i.add(String(c),d,!0,f,g)};function lo(c,d,f,g){if(d=c.i.g[String(d)],!d)return!0;d=d.concat();for(var k=!0,D=0;D<d.length;++D){var M=d[D];if(M&&!M.da&&M.capture==f){var It=M.listener,Yt=M.ha||M.src;M.fa&&cc(c.i,M),k=It.call(Yt,g)!==!1&&k}}return k&&!g.defaultPrevented}function ud(c,d,f){if(typeof c=="function")f&&(c=m(c,f));else if(c&&typeof c.handleEvent=="function")c=m(c.handleEvent,c);else throw Error("Invalid listener argument");return 2147483647<Number(d)?-1:a.setTimeout(c,d||0)}function dd(c){c.g=ud(()=>{c.g=null,c.i&&(c.i=!1,dd(c))},c.l);const d=c.h;c.h=null,c.m.apply(null,d)}class Fv extends fn{constructor(d,f){super(),this.m=d,this.l=f,this.h=null,this.i=!1,this.g=null}j(d){this.h=arguments,this.g?this.i=!0:dd(this)}N(){super.N(),this.g&&(a.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Oi(c){fn.call(this),this.h=c,this.g={}}E(Oi,fn);var hd=[];function fd(c){L(c.g,function(d,f){this.g.hasOwnProperty(f)&&hc(d)},c),c.g={}}Oi.prototype.N=function(){Oi.aa.N.call(this),fd(this)},Oi.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var mc=a.JSON.stringify,Uv=a.JSON.parse,qv=class{stringify(c){return a.JSON.stringify(c,void 0)}parse(c){return a.JSON.parse(c,void 0)}};function gc(){}gc.prototype.h=null;function pd(c){return c.h||(c.h=c.i())}function md(){}var Mi={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function yc(){te.call(this,"d")}E(yc,te);function vc(){te.call(this,"c")}E(vc,te);var Yn={},gd=null;function uo(){return gd=gd||new ee}Yn.La="serverreachability";function yd(c){te.call(this,Yn.La,c)}E(yd,te);function Li(c){const d=uo();le(d,new yd(d))}Yn.STAT_EVENT="statevent";function vd(c,d){te.call(this,Yn.STAT_EVENT,c),this.stat=d}E(vd,te);function ue(c){const d=uo();le(d,new vd(d,c))}Yn.Ma="timingevent";function _d(c,d){te.call(this,Yn.Ma,c),this.size=d}E(_d,te);function Fi(c,d){if(typeof c!="function")throw Error("Fn must not be null and must be a function");return a.setTimeout(function(){c()},d)}function Ui(){this.g=!0}Ui.prototype.xa=function(){this.g=!1};function Bv(c,d,f,g,k,D){c.info(function(){if(c.g)if(D)for(var M="",It=D.split("&"),Yt=0;Yt<It.length;Yt++){var mt=It[Yt].split("=");if(1<mt.length){var ne=mt[0];mt=mt[1];var se=ne.split("_");M=2<=se.length&&se[1]=="type"?M+(ne+"="+mt+"&"):M+(ne+"=redacted&")}}else M=null;else M=D;return"XMLHTTP REQ ("+g+") [attempt "+k+"]: "+d+`
`+f+`
`+M})}function jv(c,d,f,g,k,D,M){c.info(function(){return"XMLHTTP RESP ("+g+") [ attempt "+k+"]: "+d+`
`+f+`
`+D+" "+M})}function Ds(c,d,f,g){c.info(function(){return"XMLHTTP TEXT ("+d+"): "+Gv(c,f)+(g?" "+g:"")})}function zv(c,d){c.info(function(){return"TIMEOUT: "+d})}Ui.prototype.info=function(){};function Gv(c,d){if(!c.g)return d;if(!d)return null;try{var f=JSON.parse(d);if(f){for(c=0;c<f.length;c++)if(Array.isArray(f[c])){var g=f[c];if(!(2>g.length)){var k=g[1];if(Array.isArray(k)&&!(1>k.length)){var D=k[0];if(D!="noop"&&D!="stop"&&D!="close")for(var M=1;M<k.length;M++)k[M]=""}}}}return mc(f)}catch{return d}}var ho={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},bd={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},_c;function fo(){}E(fo,gc),fo.prototype.g=function(){return new XMLHttpRequest},fo.prototype.i=function(){return{}},_c=new fo;function pn(c,d,f,g){this.j=c,this.i=d,this.l=f,this.R=g||1,this.U=new Oi(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new wd}function wd(){this.i=null,this.g="",this.h=!1}var Id={},bc={};function wc(c,d,f){c.L=1,c.v=yo(Ye(d)),c.m=f,c.P=!0,Ed(c,null)}function Ed(c,d){c.F=Date.now(),po(c),c.A=Ye(c.v);var f=c.A,g=c.R;Array.isArray(g)||(g=[String(g)]),Md(f.i,"t",g),c.C=0,f=c.j.J,c.h=new wd,c.g=eh(c.j,f?d:null,!c.m),0<c.O&&(c.M=new Fv(m(c.Y,c,c.g),c.O)),d=c.U,f=c.g,g=c.ca;var k="readystatechange";Array.isArray(k)||(k&&(hd[0]=k.toString()),k=hd);for(var D=0;D<k.length;D++){var M=od(f,k[D],g||d.handleEvent,!1,d.h||d);if(!M)break;d.g[M.key]=M}d=c.H?y(c.H):{},c.m?(c.u||(c.u="POST"),d["Content-Type"]="application/x-www-form-urlencoded",c.g.ea(c.A,c.u,c.m,d)):(c.u="GET",c.g.ea(c.A,c.u,null,d)),Li(),Bv(c.i,c.u,c.A,c.l,c.R,c.m)}pn.prototype.ca=function(c){c=c.target;const d=this.M;d&&Xe(c)==3?d.j():this.Y(c)},pn.prototype.Y=function(c){try{if(c==this.g)t:{const se=Xe(this.g);var d=this.g.Ba();const Ns=this.g.Z();if(!(3>se)&&(se!=3||this.g&&(this.h.h||this.g.oa()||zd(this.g)))){this.J||se!=4||d==7||(d==8||0>=Ns?Li(3):Li(2)),Ic(this);var f=this.g.Z();this.X=f;e:if(Td(this)){var g=zd(this.g);c="";var k=g.length,D=Xe(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){Xn(this),qi(this);var M="";break e}this.h.i=new a.TextDecoder}for(d=0;d<k;d++)this.h.h=!0,c+=this.h.i.decode(g[d],{stream:!(D&&d==k-1)});g.length=0,this.h.g+=c,this.C=0,M=this.h.g}else M=this.g.oa();if(this.o=f==200,jv(this.i,this.u,this.A,this.l,this.R,se,f),this.o){if(this.T&&!this.K){e:{if(this.g){var It,Yt=this.g;if((It=Yt.g?Yt.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!H(It)){var mt=It;break e}}mt=null}if(f=mt)Ds(this.i,this.l,f,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,Ec(this,f);else{this.o=!1,this.s=3,ue(12),Xn(this),qi(this);break t}}if(this.P){f=!0;let Ce;for(;!this.J&&this.C<M.length;)if(Ce=Kv(this,M),Ce==bc){se==4&&(this.s=4,ue(14),f=!1),Ds(this.i,this.l,null,"[Incomplete Response]");break}else if(Ce==Id){this.s=4,ue(15),Ds(this.i,this.l,M,"[Invalid Chunk]"),f=!1;break}else Ds(this.i,this.l,Ce,null),Ec(this,Ce);if(Td(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),se!=4||M.length!=0||this.h.h||(this.s=1,ue(16),f=!1),this.o=this.o&&f,!f)Ds(this.i,this.l,M,"[Invalid Chunked Response]"),Xn(this),qi(this);else if(0<M.length&&!this.W){this.W=!0;var ne=this.j;ne.g==this&&ne.ba&&!ne.M&&(ne.j.info("Great, no buffering proxy detected. Bytes received: "+M.length),Pc(ne),ne.M=!0,ue(11))}}else Ds(this.i,this.l,M,null),Ec(this,M);se==4&&Xn(this),this.o&&!this.J&&(se==4?Yd(this.j,this):(this.o=!1,po(this)))}else l_(this.g),f==400&&0<M.indexOf("Unknown SID")?(this.s=3,ue(12)):(this.s=0,ue(13)),Xn(this),qi(this)}}}catch{}finally{}};function Td(c){return c.g?c.u=="GET"&&c.L!=2&&c.j.Ca:!1}function Kv(c,d){var f=c.C,g=d.indexOf(`
`,f);return g==-1?bc:(f=Number(d.substring(f,g)),isNaN(f)?Id:(g+=1,g+f>d.length?bc:(d=d.slice(g,g+f),c.C=g+f,d)))}pn.prototype.cancel=function(){this.J=!0,Xn(this)};function po(c){c.S=Date.now()+c.I,Ad(c,c.I)}function Ad(c,d){if(c.B!=null)throw Error("WatchDog timer not null");c.B=Fi(m(c.ba,c),d)}function Ic(c){c.B&&(a.clearTimeout(c.B),c.B=null)}pn.prototype.ba=function(){this.B=null;const c=Date.now();0<=c-this.S?(zv(this.i,this.A),this.L!=2&&(Li(),ue(17)),Xn(this),this.s=2,qi(this)):Ad(this,this.S-c)};function qi(c){c.j.G==0||c.J||Yd(c.j,c)}function Xn(c){Ic(c);var d=c.M;d&&typeof d.ma=="function"&&d.ma(),c.M=null,fd(c.U),c.g&&(d=c.g,c.g=null,d.abort(),d.ma())}function Ec(c,d){try{var f=c.j;if(f.G!=0&&(f.g==c||Tc(f.h,c))){if(!c.K&&Tc(f.h,c)&&f.G==3){try{var g=f.Da.g.parse(d)}catch{g=null}if(Array.isArray(g)&&g.length==3){var k=g;if(k[0]==0){t:if(!f.u){if(f.g)if(f.g.F+3e3<c.F)Io(f),bo(f);else break t;Rc(f),ue(18)}}else f.za=k[1],0<f.za-f.T&&37500>k[2]&&f.F&&f.v==0&&!f.C&&(f.C=Fi(m(f.Za,f),6e3));if(1>=Rd(f.h)&&f.ca){try{f.ca()}catch{}f.ca=void 0}}else ts(f,11)}else if((c.K||f.g==c)&&Io(f),!H(d))for(k=f.Da.g.parse(d),d=0;d<k.length;d++){let mt=k[d];if(f.T=mt[0],mt=mt[1],f.G==2)if(mt[0]=="c"){f.K=mt[1],f.ia=mt[2];const ne=mt[3];ne!=null&&(f.la=ne,f.j.info("VER="+f.la));const se=mt[4];se!=null&&(f.Aa=se,f.j.info("SVER="+f.Aa));const Ns=mt[5];Ns!=null&&typeof Ns=="number"&&0<Ns&&(g=1.5*Ns,f.L=g,f.j.info("backChannelRequestTimeoutMs_="+g)),g=f;const Ce=c.g;if(Ce){const To=Ce.g?Ce.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(To){var D=g.h;D.g||To.indexOf("spdy")==-1&&To.indexOf("quic")==-1&&To.indexOf("h2")==-1||(D.j=D.l,D.g=new Set,D.h&&(Ac(D,D.h),D.h=null))}if(g.D){const Cc=Ce.g?Ce.g.getResponseHeader("X-HTTP-Session-Id"):null;Cc&&(g.ya=Cc,St(g.I,g.D,Cc))}}f.G=3,f.l&&f.l.ua(),f.ba&&(f.R=Date.now()-c.F,f.j.info("Handshake RTT: "+f.R+"ms")),g=f;var M=c;if(g.qa=th(g,g.J?g.ia:null,g.W),M.K){Pd(g.h,M);var It=M,Yt=g.L;Yt&&(It.I=Yt),It.B&&(Ic(It),po(It)),g.g=M}else Qd(g);0<f.i.length&&wo(f)}else mt[0]!="stop"&&mt[0]!="close"||ts(f,7);else f.G==3&&(mt[0]=="stop"||mt[0]=="close"?mt[0]=="stop"?ts(f,7):kc(f):mt[0]!="noop"&&f.l&&f.l.ta(mt),f.v=0)}}Li(4)}catch{}}var Wv=class{constructor(c,d){this.g=c,this.map=d}};function Sd(c){this.l=c||10,a.PerformanceNavigationTiming?(c=a.performance.getEntriesByType("navigation"),c=0<c.length&&(c[0].nextHopProtocol=="hq"||c[0].nextHopProtocol=="h2")):c=!!(a.chrome&&a.chrome.loadTimes&&a.chrome.loadTimes()&&a.chrome.loadTimes().wasFetchedViaSpdy),this.j=c?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function kd(c){return c.h?!0:c.g?c.g.size>=c.j:!1}function Rd(c){return c.h?1:c.g?c.g.size:0}function Tc(c,d){return c.h?c.h==d:c.g?c.g.has(d):!1}function Ac(c,d){c.g?c.g.add(d):c.h=d}function Pd(c,d){c.h&&c.h==d?c.h=null:c.g&&c.g.has(d)&&c.g.delete(d)}Sd.prototype.cancel=function(){if(this.i=Cd(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const c of this.g.values())c.cancel();this.g.clear()}};function Cd(c){if(c.h!=null)return c.i.concat(c.h.D);if(c.g!=null&&c.g.size!==0){let d=c.i;for(const f of c.g.values())d=d.concat(f.D);return d}return $(c.i)}function Hv(c){if(c.V&&typeof c.V=="function")return c.V();if(typeof Map<"u"&&c instanceof Map||typeof Set<"u"&&c instanceof Set)return Array.from(c.values());if(typeof c=="string")return c.split("");if(l(c)){for(var d=[],f=c.length,g=0;g<f;g++)d.push(c[g]);return d}d=[],f=0;for(g in c)d[f++]=c[g];return d}function Qv(c){if(c.na&&typeof c.na=="function")return c.na();if(!c.V||typeof c.V!="function"){if(typeof Map<"u"&&c instanceof Map)return Array.from(c.keys());if(!(typeof Set<"u"&&c instanceof Set)){if(l(c)||typeof c=="string"){var d=[];c=c.length;for(var f=0;f<c;f++)d.push(f);return d}d=[],f=0;for(const g in c)d[f++]=g;return d}}}function Dd(c,d){if(c.forEach&&typeof c.forEach=="function")c.forEach(d,void 0);else if(l(c)||typeof c=="string")Array.prototype.forEach.call(c,d,void 0);else for(var f=Qv(c),g=Hv(c),k=g.length,D=0;D<k;D++)d.call(void 0,g[D],f&&f[D],c)}var $d=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Jv(c,d){if(c){c=c.split("&");for(var f=0;f<c.length;f++){var g=c[f].indexOf("="),k=null;if(0<=g){var D=c[f].substring(0,g);k=c[f].substring(g+1)}else D=c[f];d(D,k?decodeURIComponent(k.replace(/\+/g," ")):"")}}}function Zn(c){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,c instanceof Zn){this.h=c.h,mo(this,c.j),this.o=c.o,this.g=c.g,go(this,c.s),this.l=c.l;var d=c.i,f=new zi;f.i=d.i,d.g&&(f.g=new Map(d.g),f.h=d.h),Vd(this,f),this.m=c.m}else c&&(d=String(c).match($d))?(this.h=!1,mo(this,d[1]||"",!0),this.o=Bi(d[2]||""),this.g=Bi(d[3]||"",!0),go(this,d[4]),this.l=Bi(d[5]||"",!0),Vd(this,d[6]||"",!0),this.m=Bi(d[7]||"")):(this.h=!1,this.i=new zi(null,this.h))}Zn.prototype.toString=function(){var c=[],d=this.j;d&&c.push(ji(d,Nd,!0),":");var f=this.g;return(f||d=="file")&&(c.push("//"),(d=this.o)&&c.push(ji(d,Nd,!0),"@"),c.push(encodeURIComponent(String(f)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.s,f!=null&&c.push(":",String(f))),(f=this.l)&&(this.g&&f.charAt(0)!="/"&&c.push("/"),c.push(ji(f,f.charAt(0)=="/"?Zv:Xv,!0))),(f=this.i.toString())&&c.push("?",f),(f=this.m)&&c.push("#",ji(f,e_)),c.join("")};function Ye(c){return new Zn(c)}function mo(c,d,f){c.j=f?Bi(d,!0):d,c.j&&(c.j=c.j.replace(/:$/,""))}function go(c,d){if(d){if(d=Number(d),isNaN(d)||0>d)throw Error("Bad port number "+d);c.s=d}else c.s=null}function Vd(c,d,f){d instanceof zi?(c.i=d,n_(c.i,c.h)):(f||(d=ji(d,t_)),c.i=new zi(d,c.h))}function St(c,d,f){c.i.set(d,f)}function yo(c){return St(c,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),c}function Bi(c,d){return c?d?decodeURI(c.replace(/%25/g,"%2525")):decodeURIComponent(c):""}function ji(c,d,f){return typeof c=="string"?(c=encodeURI(c).replace(d,Yv),f&&(c=c.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c):null}function Yv(c){return c=c.charCodeAt(0),"%"+(c>>4&15).toString(16)+(c&15).toString(16)}var Nd=/[#\/\?@]/g,Xv=/[#\?:]/g,Zv=/[#\?]/g,t_=/[#\?@]/g,e_=/#/g;function zi(c,d){this.h=this.g=null,this.i=c||null,this.j=!!d}function mn(c){c.g||(c.g=new Map,c.h=0,c.i&&Jv(c.i,function(d,f){c.add(decodeURIComponent(d.replace(/\+/g," ")),f)}))}n=zi.prototype,n.add=function(c,d){mn(this),this.i=null,c=$s(this,c);var f=this.g.get(c);return f||this.g.set(c,f=[]),f.push(d),this.h+=1,this};function xd(c,d){mn(c),d=$s(c,d),c.g.has(d)&&(c.i=null,c.h-=c.g.get(d).length,c.g.delete(d))}function Od(c,d){return mn(c),d=$s(c,d),c.g.has(d)}n.forEach=function(c,d){mn(this),this.g.forEach(function(f,g){f.forEach(function(k){c.call(d,k,g,this)},this)},this)},n.na=function(){mn(this);const c=Array.from(this.g.values()),d=Array.from(this.g.keys()),f=[];for(let g=0;g<d.length;g++){const k=c[g];for(let D=0;D<k.length;D++)f.push(d[g])}return f},n.V=function(c){mn(this);let d=[];if(typeof c=="string")Od(this,c)&&(d=d.concat(this.g.get($s(this,c))));else{c=Array.from(this.g.values());for(let f=0;f<c.length;f++)d=d.concat(c[f])}return d},n.set=function(c,d){return mn(this),this.i=null,c=$s(this,c),Od(this,c)&&(this.h-=this.g.get(c).length),this.g.set(c,[d]),this.h+=1,this},n.get=function(c,d){return c?(c=this.V(c),0<c.length?String(c[0]):d):d};function Md(c,d,f){xd(c,d),0<f.length&&(c.i=null,c.g.set($s(c,d),$(f)),c.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const c=[],d=Array.from(this.g.keys());for(var f=0;f<d.length;f++){var g=d[f];const D=encodeURIComponent(String(g)),M=this.V(g);for(g=0;g<M.length;g++){var k=D;M[g]!==""&&(k+="="+encodeURIComponent(String(M[g]))),c.push(k)}}return this.i=c.join("&")};function $s(c,d){return d=String(d),c.j&&(d=d.toLowerCase()),d}function n_(c,d){d&&!c.j&&(mn(c),c.i=null,c.g.forEach(function(f,g){var k=g.toLowerCase();g!=k&&(xd(this,g),Md(this,k,f))},c)),c.j=d}function s_(c,d){const f=new Ui;if(a.Image){const g=new Image;g.onload=I(gn,f,"TestLoadImage: loaded",!0,d,g),g.onerror=I(gn,f,"TestLoadImage: error",!1,d,g),g.onabort=I(gn,f,"TestLoadImage: abort",!1,d,g),g.ontimeout=I(gn,f,"TestLoadImage: timeout",!1,d,g),a.setTimeout(function(){g.ontimeout&&g.ontimeout()},1e4),g.src=c}else d(!1)}function i_(c,d){const f=new Ui,g=new AbortController,k=setTimeout(()=>{g.abort(),gn(f,"TestPingServer: timeout",!1,d)},1e4);fetch(c,{signal:g.signal}).then(D=>{clearTimeout(k),D.ok?gn(f,"TestPingServer: ok",!0,d):gn(f,"TestPingServer: server error",!1,d)}).catch(()=>{clearTimeout(k),gn(f,"TestPingServer: error",!1,d)})}function gn(c,d,f,g,k){try{k&&(k.onload=null,k.onerror=null,k.onabort=null,k.ontimeout=null),g(f)}catch{}}function r_(){this.g=new qv}function o_(c,d,f){const g=f||"";try{Dd(c,function(k,D){let M=k;u(k)&&(M=mc(k)),d.push(g+D+"="+encodeURIComponent(M))})}catch(k){throw d.push(g+"type="+encodeURIComponent("_badmap")),k}}function Gi(c){this.l=c.Ub||null,this.j=c.eb||!1}E(Gi,gc),Gi.prototype.g=function(){return new vo(this.l,this.j)},Gi.prototype.i=function(c){return function(){return c}}({});function vo(c,d){ee.call(this),this.D=c,this.o=d,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}E(vo,ee),n=vo.prototype,n.open=function(c,d){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=c,this.A=d,this.readyState=1,Wi(this)},n.send=function(c){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const d={headers:this.u,method:this.B,credentials:this.m,cache:void 0};c&&(d.body=c),(this.D||a).fetch(new Request(this.A,d)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,Ki(this)),this.readyState=0},n.Sa=function(c){if(this.g&&(this.l=c,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=c.headers,this.readyState=2,Wi(this)),this.g&&(this.readyState=3,Wi(this),this.g)))if(this.responseType==="arraybuffer")c.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof a.ReadableStream<"u"&&"body"in c){if(this.j=c.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;Ld(this)}else c.text().then(this.Ra.bind(this),this.ga.bind(this))};function Ld(c){c.j.read().then(c.Pa.bind(c)).catch(c.ga.bind(c))}n.Pa=function(c){if(this.g){if(this.o&&c.value)this.response.push(c.value);else if(!this.o){var d=c.value?c.value:new Uint8Array(0);(d=this.v.decode(d,{stream:!c.done}))&&(this.response=this.responseText+=d)}c.done?Ki(this):Wi(this),this.readyState==3&&Ld(this)}},n.Ra=function(c){this.g&&(this.response=this.responseText=c,Ki(this))},n.Qa=function(c){this.g&&(this.response=c,Ki(this))},n.ga=function(){this.g&&Ki(this)};function Ki(c){c.readyState=4,c.l=null,c.j=null,c.v=null,Wi(c)}n.setRequestHeader=function(c,d){this.u.append(c,d)},n.getResponseHeader=function(c){return this.h&&this.h.get(c.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const c=[],d=this.h.entries();for(var f=d.next();!f.done;)f=f.value,c.push(f[0]+": "+f[1]),f=d.next();return c.join(`\r
`)};function Wi(c){c.onreadystatechange&&c.onreadystatechange.call(c)}Object.defineProperty(vo.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(c){this.m=c?"include":"same-origin"}});function Fd(c){let d="";return L(c,function(f,g){d+=g,d+=":",d+=f,d+=`\r
`}),d}function Sc(c,d,f){t:{for(g in f){var g=!1;break t}g=!0}g||(f=Fd(f),typeof c=="string"?f!=null&&encodeURIComponent(String(f)):St(c,d,f))}function $t(c){ee.call(this),this.headers=new Map,this.o=c||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}E($t,ee);var a_=/^https?$/i,c_=["POST","PUT"];n=$t.prototype,n.Ha=function(c){this.J=c},n.ea=function(c,d,f,g){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+c);d=d?d.toUpperCase():"GET",this.D=c,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():_c.g(),this.v=this.o?pd(this.o):pd(_c),this.g.onreadystatechange=m(this.Ea,this);try{this.B=!0,this.g.open(d,String(c),!0),this.B=!1}catch(D){Ud(this,D);return}if(c=f||"",f=new Map(this.headers),g)if(Object.getPrototypeOf(g)===Object.prototype)for(var k in g)f.set(k,g[k]);else if(typeof g.keys=="function"&&typeof g.get=="function")for(const D of g.keys())f.set(D,g.get(D));else throw Error("Unknown input type for opt_headers: "+String(g));g=Array.from(f.keys()).find(D=>D.toLowerCase()=="content-type"),k=a.FormData&&c instanceof a.FormData,!(0<=Array.prototype.indexOf.call(c_,d,void 0))||g||k||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[D,M]of f)this.g.setRequestHeader(D,M);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{jd(this),this.u=!0,this.g.send(c),this.u=!1}catch(D){Ud(this,D)}};function Ud(c,d){c.h=!1,c.g&&(c.j=!0,c.g.abort(),c.j=!1),c.l=d,c.m=5,qd(c),_o(c)}function qd(c){c.A||(c.A=!0,le(c,"complete"),le(c,"error"))}n.abort=function(c){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=c||7,le(this,"complete"),le(this,"abort"),_o(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),_o(this,!0)),$t.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?Bd(this):this.bb())},n.bb=function(){Bd(this)};function Bd(c){if(c.h&&typeof o<"u"&&(!c.v[1]||Xe(c)!=4||c.Z()!=2)){if(c.u&&Xe(c)==4)ud(c.Ea,0,c);else if(le(c,"readystatechange"),Xe(c)==4){c.h=!1;try{const M=c.Z();t:switch(M){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var d=!0;break t;default:d=!1}var f;if(!(f=d)){var g;if(g=M===0){var k=String(c.D).match($d)[1]||null;!k&&a.self&&a.self.location&&(k=a.self.location.protocol.slice(0,-1)),g=!a_.test(k?k.toLowerCase():"")}f=g}if(f)le(c,"complete"),le(c,"success");else{c.m=6;try{var D=2<Xe(c)?c.g.statusText:""}catch{D=""}c.l=D+" ["+c.Z()+"]",qd(c)}}finally{_o(c)}}}}function _o(c,d){if(c.g){jd(c);const f=c.g,g=c.v[0]?()=>{}:null;c.g=null,c.v=null,d||le(c,"ready");try{f.onreadystatechange=g}catch{}}}function jd(c){c.I&&(a.clearTimeout(c.I),c.I=null)}n.isActive=function(){return!!this.g};function Xe(c){return c.g?c.g.readyState:0}n.Z=function(){try{return 2<Xe(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(c){if(this.g){var d=this.g.responseText;return c&&d.indexOf(c)==0&&(d=d.substring(c.length)),Uv(d)}};function zd(c){try{if(!c.g)return null;if("response"in c.g)return c.g.response;switch(c.H){case"":case"text":return c.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in c.g)return c.g.mozResponseArrayBuffer}return null}catch{return null}}function l_(c){const d={};c=(c.g&&2<=Xe(c)&&c.g.getAllResponseHeaders()||"").split(`\r
`);for(let g=0;g<c.length;g++){if(H(c[g]))continue;var f=T(c[g]);const k=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const D=d[k]||[];d[k]=D,D.push(f)}b(d,function(g){return g.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function Hi(c,d,f){return f&&f.internalChannelParams&&f.internalChannelParams[c]||d}function Gd(c){this.Aa=0,this.i=[],this.j=new Ui,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=Hi("failFast",!1,c),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=Hi("baseRetryDelayMs",5e3,c),this.cb=Hi("retryDelaySeedMs",1e4,c),this.Wa=Hi("forwardChannelMaxRetries",2,c),this.wa=Hi("forwardChannelRequestTimeoutMs",2e4,c),this.pa=c&&c.xmlHttpFactory||void 0,this.Xa=c&&c.Tb||void 0,this.Ca=c&&c.useFetchStreams||!1,this.L=void 0,this.J=c&&c.supportsCrossDomainXhr||!1,this.K="",this.h=new Sd(c&&c.concurrentRequestLimit),this.Da=new r_,this.P=c&&c.fastHandshake||!1,this.O=c&&c.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=c&&c.Rb||!1,c&&c.xa&&this.j.xa(),c&&c.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&c&&c.detectBufferingProxy||!1,this.ja=void 0,c&&c.longPollingTimeout&&0<c.longPollingTimeout&&(this.ja=c.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=Gd.prototype,n.la=8,n.G=1,n.connect=function(c,d,f,g){ue(0),this.W=c,this.H=d||{},f&&g!==void 0&&(this.H.OSID=f,this.H.OAID=g),this.F=this.X,this.I=th(this,null,this.W),wo(this)};function kc(c){if(Kd(c),c.G==3){var d=c.U++,f=Ye(c.I);if(St(f,"SID",c.K),St(f,"RID",d),St(f,"TYPE","terminate"),Qi(c,f),d=new pn(c,c.j,d),d.L=2,d.v=yo(Ye(f)),f=!1,a.navigator&&a.navigator.sendBeacon)try{f=a.navigator.sendBeacon(d.v.toString(),"")}catch{}!f&&a.Image&&(new Image().src=d.v,f=!0),f||(d.g=eh(d.j,null),d.g.ea(d.v)),d.F=Date.now(),po(d)}Zd(c)}function bo(c){c.g&&(Pc(c),c.g.cancel(),c.g=null)}function Kd(c){bo(c),c.u&&(a.clearTimeout(c.u),c.u=null),Io(c),c.h.cancel(),c.s&&(typeof c.s=="number"&&a.clearTimeout(c.s),c.s=null)}function wo(c){if(!kd(c.h)&&!c.s){c.s=!0;var d=c.Ga;Vi||rd(),Ni||(Vi(),Ni=!0),ac.add(d,c),c.B=0}}function u_(c,d){return Rd(c.h)>=c.h.j-(c.s?1:0)?!1:c.s?(c.i=d.D.concat(c.i),!0):c.G==1||c.G==2||c.B>=(c.Va?0:c.Wa)?!1:(c.s=Fi(m(c.Ga,c,d),Xd(c,c.B)),c.B++,!0)}n.Ga=function(c){if(this.s)if(this.s=null,this.G==1){if(!c){this.U=Math.floor(1e5*Math.random()),c=this.U++;const k=new pn(this,this.j,c);let D=this.o;if(this.S&&(D?(D=y(D),w(D,this.S)):D=this.S),this.m!==null||this.O||(k.H=D,D=null),this.P)t:{for(var d=0,f=0;f<this.i.length;f++){e:{var g=this.i[f];if("__data__"in g.map&&(g=g.map.__data__,typeof g=="string")){g=g.length;break e}g=void 0}if(g===void 0)break;if(d+=g,4096<d){d=f;break t}if(d===4096||f===this.i.length-1){d=f+1;break t}}d=1e3}else d=1e3;d=Hd(this,k,d),f=Ye(this.I),St(f,"RID",c),St(f,"CVER",22),this.D&&St(f,"X-HTTP-Session-Id",this.D),Qi(this,f),D&&(this.O?d="headers="+encodeURIComponent(String(Fd(D)))+"&"+d:this.m&&Sc(f,this.m,D)),Ac(this.h,k),this.Ua&&St(f,"TYPE","init"),this.P?(St(f,"$req",d),St(f,"SID","null"),k.T=!0,wc(k,f,null)):wc(k,f,d),this.G=2}}else this.G==3&&(c?Wd(this,c):this.i.length==0||kd(this.h)||Wd(this))};function Wd(c,d){var f;d?f=d.l:f=c.U++;const g=Ye(c.I);St(g,"SID",c.K),St(g,"RID",f),St(g,"AID",c.T),Qi(c,g),c.m&&c.o&&Sc(g,c.m,c.o),f=new pn(c,c.j,f,c.B+1),c.m===null&&(f.H=c.o),d&&(c.i=d.D.concat(c.i)),d=Hd(c,f,1e3),f.I=Math.round(.5*c.wa)+Math.round(.5*c.wa*Math.random()),Ac(c.h,f),wc(f,g,d)}function Qi(c,d){c.H&&L(c.H,function(f,g){St(d,g,f)}),c.l&&Dd({},function(f,g){St(d,g,f)})}function Hd(c,d,f){f=Math.min(c.i.length,f);var g=c.l?m(c.l.Na,c.l,c):null;t:{var k=c.i;let D=-1;for(;;){const M=["count="+f];D==-1?0<f?(D=k[0].g,M.push("ofs="+D)):D=0:M.push("ofs="+D);let It=!0;for(let Yt=0;Yt<f;Yt++){let mt=k[Yt].g;const ne=k[Yt].map;if(mt-=D,0>mt)D=Math.max(0,k[Yt].g-100),It=!1;else try{o_(ne,M,"req"+mt+"_")}catch{g&&g(ne)}}if(It){g=M.join("&");break t}}}return c=c.i.splice(0,f),d.D=c,g}function Qd(c){if(!c.g&&!c.u){c.Y=1;var d=c.Fa;Vi||rd(),Ni||(Vi(),Ni=!0),ac.add(d,c),c.v=0}}function Rc(c){return c.g||c.u||3<=c.v?!1:(c.Y++,c.u=Fi(m(c.Fa,c),Xd(c,c.v)),c.v++,!0)}n.Fa=function(){if(this.u=null,Jd(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var c=2*this.R;this.j.info("BP detection timer enabled: "+c),this.A=Fi(m(this.ab,this),c)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,ue(10),bo(this),Jd(this))};function Pc(c){c.A!=null&&(a.clearTimeout(c.A),c.A=null)}function Jd(c){c.g=new pn(c,c.j,"rpc",c.Y),c.m===null&&(c.g.H=c.o),c.g.O=0;var d=Ye(c.qa);St(d,"RID","rpc"),St(d,"SID",c.K),St(d,"AID",c.T),St(d,"CI",c.F?"0":"1"),!c.F&&c.ja&&St(d,"TO",c.ja),St(d,"TYPE","xmlhttp"),Qi(c,d),c.m&&c.o&&Sc(d,c.m,c.o),c.L&&(c.g.I=c.L);var f=c.g;c=c.ia,f.L=1,f.v=yo(Ye(d)),f.m=null,f.P=!0,Ed(f,c)}n.Za=function(){this.C!=null&&(this.C=null,bo(this),Rc(this),ue(19))};function Io(c){c.C!=null&&(a.clearTimeout(c.C),c.C=null)}function Yd(c,d){var f=null;if(c.g==d){Io(c),Pc(c),c.g=null;var g=2}else if(Tc(c.h,d))f=d.D,Pd(c.h,d),g=1;else return;if(c.G!=0){if(d.o)if(g==1){f=d.m?d.m.length:0,d=Date.now()-d.F;var k=c.B;g=uo(),le(g,new _d(g,f)),wo(c)}else Qd(c);else if(k=d.s,k==3||k==0&&0<d.X||!(g==1&&u_(c,d)||g==2&&Rc(c)))switch(f&&0<f.length&&(d=c.h,d.i=d.i.concat(f)),k){case 1:ts(c,5);break;case 4:ts(c,10);break;case 3:ts(c,6);break;default:ts(c,2)}}}function Xd(c,d){let f=c.Ta+Math.floor(Math.random()*c.cb);return c.isActive()||(f*=2),f*d}function ts(c,d){if(c.j.info("Error code "+d),d==2){var f=m(c.fb,c),g=c.Xa;const k=!g;g=new Zn(g||"//www.google.com/images/cleardot.gif"),a.location&&a.location.protocol=="http"||mo(g,"https"),yo(g),k?s_(g.toString(),f):i_(g.toString(),f)}else ue(2);c.G=0,c.l&&c.l.sa(d),Zd(c),Kd(c)}n.fb=function(c){c?(this.j.info("Successfully pinged google.com"),ue(2)):(this.j.info("Failed to ping google.com"),ue(1))};function Zd(c){if(c.G=0,c.ka=[],c.l){const d=Cd(c.h);(d.length!=0||c.i.length!=0)&&(R(c.ka,d),R(c.ka,c.i),c.h.i.length=0,$(c.i),c.i.length=0),c.l.ra()}}function th(c,d,f){var g=f instanceof Zn?Ye(f):new Zn(f);if(g.g!="")d&&(g.g=d+"."+g.g),go(g,g.s);else{var k=a.location;g=k.protocol,d=d?d+"."+k.hostname:k.hostname,k=+k.port;var D=new Zn(null);g&&mo(D,g),d&&(D.g=d),k&&go(D,k),f&&(D.l=f),g=D}return f=c.D,d=c.ya,f&&d&&St(g,f,d),St(g,"VER",c.la),Qi(c,g),g}function eh(c,d,f){if(d&&!c.J)throw Error("Can't create secondary domain capable XhrIo object.");return d=c.Ca&&!c.pa?new $t(new Gi({eb:f})):new $t(c.pa),d.Ha(c.J),d}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function nh(){}n=nh.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function Eo(){}Eo.prototype.g=function(c,d){return new we(c,d)};function we(c,d){ee.call(this),this.g=new Gd(d),this.l=c,this.h=d&&d.messageUrlParams||null,c=d&&d.messageHeaders||null,d&&d.clientProtocolHeaderRequired&&(c?c["X-Client-Protocol"]="webchannel":c={"X-Client-Protocol":"webchannel"}),this.g.o=c,c=d&&d.initMessageHeaders||null,d&&d.messageContentType&&(c?c["X-WebChannel-Content-Type"]=d.messageContentType:c={"X-WebChannel-Content-Type":d.messageContentType}),d&&d.va&&(c?c["X-WebChannel-Client-Profile"]=d.va:c={"X-WebChannel-Client-Profile":d.va}),this.g.S=c,(c=d&&d.Sb)&&!H(c)&&(this.g.m=c),this.v=d&&d.supportsCrossDomainXhr||!1,this.u=d&&d.sendRawJson||!1,(d=d&&d.httpSessionIdParam)&&!H(d)&&(this.g.D=d,c=this.h,c!==null&&d in c&&(c=this.h,d in c&&delete c[d])),this.j=new Vs(this)}E(we,ee),we.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},we.prototype.close=function(){kc(this.g)},we.prototype.o=function(c){var d=this.g;if(typeof c=="string"){var f={};f.__data__=c,c=f}else this.u&&(f={},f.__data__=mc(c),c=f);d.i.push(new Wv(d.Ya++,c)),d.G==3&&wo(d)},we.prototype.N=function(){this.g.l=null,delete this.j,kc(this.g),delete this.g,we.aa.N.call(this)};function sh(c){yc.call(this),c.__headers__&&(this.headers=c.__headers__,this.statusCode=c.__status__,delete c.__headers__,delete c.__status__);var d=c.__sm__;if(d){t:{for(const f in d){c=f;break t}c=void 0}(this.i=c)&&(c=this.i,d=d!==null&&c in d?d[c]:void 0),this.data=d}else this.data=c}E(sh,yc);function ih(){vc.call(this),this.status=1}E(ih,vc);function Vs(c){this.g=c}E(Vs,nh),Vs.prototype.ua=function(){le(this.g,"a")},Vs.prototype.ta=function(c){le(this.g,new sh(c))},Vs.prototype.sa=function(c){le(this.g,new ih)},Vs.prototype.ra=function(){le(this.g,"b")},Eo.prototype.createWebChannel=Eo.prototype.g,we.prototype.send=we.prototype.o,we.prototype.open=we.prototype.m,we.prototype.close=we.prototype.close,Pm=function(){return new Eo},Rm=function(){return uo()},km=Yn,ol={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},ho.NO_ERROR=0,ho.TIMEOUT=8,ho.HTTP_ERROR=6,Uo=ho,bd.COMPLETE="complete",Sm=bd,md.EventType=Mi,Mi.OPEN="a",Mi.CLOSE="b",Mi.ERROR="c",Mi.MESSAGE="d",ee.prototype.listen=ee.prototype.K,or=md,Am=Gi,$t.prototype.listenOnce=$t.prototype.L,$t.prototype.getLastError=$t.prototype.Ka,$t.prototype.getLastErrorCode=$t.prototype.Ba,$t.prototype.getStatus=$t.prototype.Z,$t.prototype.getResponseJson=$t.prototype.Oa,$t.prototype.getResponseText=$t.prototype.oa,$t.prototype.send=$t.prototype.ea,$t.prototype.setWithCredentials=$t.prototype.Ha,Tm=$t}).apply(typeof So<"u"?So:typeof self<"u"?self:typeof window<"u"?window:{});const Oh="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class re{constructor(t){this.uid=t}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(t){return t.uid===this.uid}}re.UNAUTHENTICATED=new re(null),re.GOOGLE_CREDENTIALS=new re("google-credentials-uid"),re.FIRST_PARTY=new re("first-party-uid"),re.MOCK_USER=new re("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ki="10.12.1";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ys=new Bl("@firebase/firestore");function js(){return ys.logLevel}function N(n,...t){if(ys.logLevel<=ot.DEBUG){const e=t.map(tu);ys.debug(`Firestore (${ki}): ${n}`,...e)}}function Lt(n,...t){if(ys.logLevel<=ot.ERROR){const e=t.map(tu);ys.error(`Firestore (${ki}): ${n}`,...e)}}function Sr(n,...t){if(ys.logLevel<=ot.WARN){const e=t.map(tu);ys.warn(`Firestore (${ki}): ${n}`,...e)}}function tu(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(e){return JSON.stringify(e)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function G(n="Unexpected state"){const t=`FIRESTORE (${ki}) INTERNAL ASSERTION FAILED: `+n;throw Lt(t),new Error(t)}function X(n,t){n||G()}function W(n,t){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const V={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class U extends dn{constructor(t,e){super(t,e),this.code=t,this.message=e,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vn{constructor(){this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nE{constructor(t,e){this.user=e,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${t}`)}}class sE{getToken(){return Promise.resolve(null)}invalidateToken(){}start(t,e){t.enqueueRetryable(()=>e(re.UNAUTHENTICATED))}shutdown(){}}class iE{constructor(t){this.t=t,this.currentUser=re.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(t,e){let s=this.i;const i=l=>this.i!==s?(s=this.i,e(l)):Promise.resolve();let r=new Vn;this.o=()=>{this.i++,this.currentUser=this.u(),r.resolve(),r=new Vn,t.enqueueRetryable(()=>i(this.currentUser))};const o=()=>{const l=r;t.enqueueRetryable(async()=>{await l.promise,await i(this.currentUser)})},a=l=>{N("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),o()};this.t.onInit(l=>a(l)),setTimeout(()=>{if(!this.auth){const l=this.t.getImmediate({optional:!0});l?a(l):(N("FirebaseAuthCredentialsProvider","Auth not yet detected"),r.resolve(),r=new Vn)}},0),o()}getToken(){const t=this.i,e=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(e).then(s=>this.i!==t?(N("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(X(typeof s.accessToken=="string"),new nE(s.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const t=this.auth&&this.auth.getUid();return X(t===null||typeof t=="string"),new re(t)}}class rE{constructor(t,e,s){this.l=t,this.h=e,this.P=s,this.type="FirstParty",this.user=re.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const t=this.T();return t&&this.I.set("Authorization",t),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class oE{constructor(t,e,s){this.l=t,this.h=e,this.P=s}getToken(){return Promise.resolve(new rE(this.l,this.h,this.P))}start(t,e){t.enqueueRetryable(()=>e(re.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class aE{constructor(t){this.value=t,this.type="AppCheck",this.headers=new Map,t&&t.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class cE{constructor(t){this.A=t,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(t,e){const s=r=>{r.error!=null&&N("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${r.error.message}`);const o=r.token!==this.R;return this.R=r.token,N("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?e(r.token):Promise.resolve()};this.o=r=>{t.enqueueRetryable(()=>s(r))};const i=r=>{N("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=r,this.appCheck.addTokenListener(this.o)};this.A.onInit(r=>i(r)),setTimeout(()=>{if(!this.appCheck){const r=this.A.getImmediate({optional:!0});r?i(r):N("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const t=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(t).then(e=>e?(X(typeof e.token=="string"),this.R=e.token,new aE(e.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lE(n){const t=typeof self<"u"&&(self.crypto||self.msCrypto),e=new Uint8Array(n);if(t&&typeof t.getRandomValues=="function")t.getRandomValues(e);else for(let s=0;s<n;s++)e[s]=Math.floor(256*Math.random());return e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cm{static newId(){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",e=Math.floor(256/t.length)*t.length;let s="";for(;s.length<20;){const i=lE(40);for(let r=0;r<i.length;++r)s.length<20&&i[r]<e&&(s+=t.charAt(i[r]%t.length))}return s}}function nt(n,t){return n<t?-1:n>t?1:0}function oi(n,t,e){return n.length===t.length&&n.every((s,i)=>e(s,t[i]))}function Dm(n){return n+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dt{constructor(t,e){if(this.seconds=t,this.nanoseconds=e,e<0)throw new U(V.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(e>=1e9)throw new U(V.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(t<-62135596800)throw new U(V.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t);if(t>=253402300800)throw new U(V.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t)}static now(){return Dt.fromMillis(Date.now())}static fromDate(t){return Dt.fromMillis(t.getTime())}static fromMillis(t){const e=Math.floor(t/1e3),s=Math.floor(1e6*(t-1e3*e));return new Dt(e,s)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(t){return this.seconds===t.seconds?nt(this.nanoseconds,t.nanoseconds):nt(this.seconds,t.seconds)}isEqual(t){return t.seconds===this.seconds&&t.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const t=this.seconds- -62135596800;return String(t).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Z{constructor(t){this.timestamp=t}static fromTimestamp(t){return new Z(t)}static min(){return new Z(new Dt(0,0))}static max(){return new Z(new Dt(253402300799,999999999))}compareTo(t){return this.timestamp._compareTo(t.timestamp)}isEqual(t){return this.timestamp.isEqual(t.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kr{constructor(t,e,s){e===void 0?e=0:e>t.length&&G(),s===void 0?s=t.length-e:s>t.length-e&&G(),this.segments=t,this.offset=e,this.len=s}get length(){return this.len}isEqual(t){return kr.comparator(this,t)===0}child(t){const e=this.segments.slice(this.offset,this.limit());return t instanceof kr?t.forEach(s=>{e.push(s)}):e.push(t),this.construct(e)}limit(){return this.offset+this.length}popFirst(t){return t=t===void 0?1:t,this.construct(this.segments,this.offset+t,this.length-t)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(t){return this.segments[this.offset+t]}isEmpty(){return this.length===0}isPrefixOf(t){if(t.length<this.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}isImmediateParentOf(t){if(this.length+1!==t.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}forEach(t){for(let e=this.offset,s=this.limit();e<s;e++)t(this.segments[e])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(t,e){const s=Math.min(t.length,e.length);for(let i=0;i<s;i++){const r=t.get(i),o=e.get(i);if(r<o)return-1;if(r>o)return 1}return t.length<e.length?-1:t.length>e.length?1:0}}class vt extends kr{construct(t,e,s){return new vt(t,e,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...t){const e=[];for(const s of t){if(s.indexOf("//")>=0)throw new U(V.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);e.push(...s.split("/").filter(i=>i.length>0))}return new vt(e)}static emptyPath(){return new vt([])}}const uE=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Ct extends kr{construct(t,e,s){return new Ct(t,e,s)}static isValidIdentifier(t){return uE.test(t)}canonicalString(){return this.toArray().map(t=>(t=t.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Ct.isValidIdentifier(t)||(t="`"+t+"`"),t)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new Ct(["__name__"])}static fromServerFormat(t){const e=[];let s="",i=0;const r=()=>{if(s.length===0)throw new U(V.INVALID_ARGUMENT,`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);e.push(s),s=""};let o=!1;for(;i<t.length;){const a=t[i];if(a==="\\"){if(i+1===t.length)throw new U(V.INVALID_ARGUMENT,"Path has trailing escape character: "+t);const l=t[i+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new U(V.INVALID_ARGUMENT,"Path has invalid escape sequence: "+t);s+=l,i+=2}else a==="`"?(o=!o,i++):a!=="."||o?(s+=a,i++):(r(),i++)}if(r(),o)throw new U(V.INVALID_ARGUMENT,"Unterminated ` in path: "+t);return new Ct(e)}static emptyPath(){return new Ct([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{constructor(t){this.path=t}static fromPath(t){return new q(vt.fromString(t))}static fromName(t){return new q(vt.fromString(t).popFirst(5))}static empty(){return new q(vt.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(t){return this.path.length>=2&&this.path.get(this.path.length-2)===t}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(t){return t!==null&&vt.comparator(this.path,t.path)===0}toString(){return this.path.toString()}static comparator(t,e){return vt.comparator(t.path,e.path)}static isDocumentKey(t){return t.length%2==0}static fromSegments(t){return new q(new vt(t.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oa{constructor(t,e,s,i){this.indexId=t,this.collectionGroup=e,this.fields=s,this.indexState=i}}function al(n){return n.fields.find(t=>t.kind===2)}function ss(n){return n.fields.filter(t=>t.kind!==2)}oa.UNKNOWN_ID=-1;class qo{constructor(t,e){this.fieldPath=t,this.kind=e}}class Rr{constructor(t,e){this.sequenceNumber=t,this.offset=e}static empty(){return new Rr(0,Se.min())}}function $m(n,t){const e=n.toTimestamp().seconds,s=n.toTimestamp().nanoseconds+1,i=Z.fromTimestamp(s===1e9?new Dt(e+1,0):new Dt(e,s));return new Se(i,q.empty(),t)}function Vm(n){return new Se(n.readTime,n.key,-1)}class Se{constructor(t,e,s){this.readTime=t,this.documentKey=e,this.largestBatchId=s}static min(){return new Se(Z.min(),q.empty(),-1)}static max(){return new Se(Z.max(),q.empty(),-1)}}function eu(n,t){let e=n.readTime.compareTo(t.readTime);return e!==0?e:(e=q.comparator(n.documentKey,t.documentKey),e!==0?e:nt(n.largestBatchId,t.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nm="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class xm{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(t){this.onCommittedListeners.push(t)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(t=>t())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Kn(n){if(n.code!==V.FAILED_PRECONDITION||n.message!==Nm)throw n;N("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P{constructor(t){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,t(e=>{this.isDone=!0,this.result=e,this.nextCallback&&this.nextCallback(e)},e=>{this.isDone=!0,this.error=e,this.catchCallback&&this.catchCallback(e)})}catch(t){return this.next(void 0,t)}next(t,e){return this.callbackAttached&&G(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(e,this.error):this.wrapSuccess(t,this.result):new P((s,i)=>{this.nextCallback=r=>{this.wrapSuccess(t,r).next(s,i)},this.catchCallback=r=>{this.wrapFailure(e,r).next(s,i)}})}toPromise(){return new Promise((t,e)=>{this.next(t,e)})}wrapUserFunction(t){try{const e=t();return e instanceof P?e:P.resolve(e)}catch(e){return P.reject(e)}}wrapSuccess(t,e){return t?this.wrapUserFunction(()=>t(e)):P.resolve(e)}wrapFailure(t,e){return t?this.wrapUserFunction(()=>t(e)):P.reject(e)}static resolve(t){return new P((e,s)=>{e(t)})}static reject(t){return new P((e,s)=>{s(t)})}static waitFor(t){return new P((e,s)=>{let i=0,r=0,o=!1;t.forEach(a=>{++i,a.next(()=>{++r,o&&r===i&&e()},l=>s(l))}),o=!0,r===i&&e()})}static or(t){let e=P.resolve(!1);for(const s of t)e=e.next(i=>i?P.resolve(i):s());return e}static forEach(t,e){const s=[];return t.forEach((i,r)=>{s.push(e.call(this,i,r))}),this.waitFor(s)}static mapArray(t,e){return new P((s,i)=>{const r=t.length,o=new Array(r);let a=0;for(let l=0;l<r;l++){const u=l;e(t[u]).next(h=>{o[u]=h,++a,a===r&&s(o)},h=>i(h))}})}static doWhile(t,e){return new P((s,i)=>{const r=()=>{t()===!0?e().next(()=>{r()},i):s()};r()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xa{constructor(t,e){this.action=t,this.transaction=e,this.aborted=!1,this.V=new Vn,this.transaction.oncomplete=()=>{this.V.resolve()},this.transaction.onabort=()=>{e.error?this.V.reject(new hr(t,e.error)):this.V.resolve()},this.transaction.onerror=s=>{const i=nu(s.target.error);this.V.reject(new hr(t,i))}}static open(t,e,s,i){try{return new xa(e,t.transaction(i,s))}catch(r){throw new hr(e,r)}}get m(){return this.V.promise}abort(t){t&&this.V.reject(t),this.aborted||(N("SimpleDb","Aborting transaction:",t?t.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}g(){const t=this.transaction;this.aborted||typeof t.commit!="function"||t.commit()}store(t){const e=this.transaction.objectStore(t);return new hE(e)}}class Nn{constructor(t,e,s){this.name=t,this.version=e,this.p=s,Nn.S(Bt())===12.2&&Lt("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(t){return N("SimpleDb","Removing database:",t),is(window.indexedDB.deleteDatabase(t)).toPromise()}static D(){if(!Fp())return!1;if(Nn.C())return!0;const t=Bt(),e=Nn.S(t),s=0<e&&e<10,i=Om(t),r=0<i&&i<4.5;return!(t.indexOf("MSIE ")>0||t.indexOf("Trident/")>0||t.indexOf("Edge/")>0||s||r)}static C(){var t;return typeof process<"u"&&((t=process.__PRIVATE_env)===null||t===void 0?void 0:t.v)==="YES"}static F(t,e){return t.store(e)}static S(t){const e=t.match(/i(?:phone|pad|pod) os ([\d_]+)/i),s=e?e[1].split("_").slice(0,2).join("."):"-1";return Number(s)}async M(t){return this.db||(N("SimpleDb","Opening database:",this.name),this.db=await new Promise((e,s)=>{const i=indexedDB.open(this.name,this.version);i.onsuccess=r=>{const o=r.target.result;e(o)},i.onblocked=()=>{s(new hr(t,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},i.onerror=r=>{const o=r.target.error;o.name==="VersionError"?s(new U(V.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):o.name==="InvalidStateError"?s(new U(V.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+o)):s(new hr(t,o))},i.onupgradeneeded=r=>{N("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',r.oldVersion);const o=r.target.result;this.p.O(o,i.transaction,r.oldVersion,this.version).next(()=>{N("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.N&&(this.db.onversionchange=e=>this.N(e)),this.db}L(t){this.N=t,this.db&&(this.db.onversionchange=e=>t(e))}async runTransaction(t,e,s,i){const r=e==="readonly";let o=0;for(;;){++o;try{this.db=await this.M(t);const a=xa.open(this.db,t,r?"readonly":"readwrite",s),l=i(a).next(u=>(a.g(),u)).catch(u=>(a.abort(u),P.reject(u))).toPromise();return l.catch(()=>{}),await a.m,l}catch(a){const l=a,u=l.name!=="FirebaseError"&&o<3;if(N("SimpleDb","Transaction failed with error:",l.message,"Retrying:",u),this.close(),!u)return Promise.reject(l)}}}close(){this.db&&this.db.close(),this.db=void 0}}function Om(n){const t=n.match(/Android ([\d.]+)/i),e=t?t[1].split(".").slice(0,2).join("."):"-1";return Number(e)}class dE{constructor(t){this.B=t,this.k=!1,this.q=null}get isDone(){return this.k}get K(){return this.q}set cursor(t){this.B=t}done(){this.k=!0}$(t){this.q=t}delete(){return is(this.B.delete())}}class hr extends U{constructor(t,e){super(V.UNAVAILABLE,`IndexedDB transaction '${t}' failed: ${e}`),this.name="IndexedDbTransactionError"}}function Wn(n){return n.name==="IndexedDbTransactionError"}class hE{constructor(t){this.store=t}put(t,e){let s;return e!==void 0?(N("SimpleDb","PUT",this.store.name,t,e),s=this.store.put(e,t)):(N("SimpleDb","PUT",this.store.name,"<auto-key>",t),s=this.store.put(t)),is(s)}add(t){return N("SimpleDb","ADD",this.store.name,t,t),is(this.store.add(t))}get(t){return is(this.store.get(t)).next(e=>(e===void 0&&(e=null),N("SimpleDb","GET",this.store.name,t,e),e))}delete(t){return N("SimpleDb","DELETE",this.store.name,t),is(this.store.delete(t))}count(){return N("SimpleDb","COUNT",this.store.name),is(this.store.count())}U(t,e){const s=this.options(t,e),i=s.index?this.store.index(s.index):this.store;if(typeof i.getAll=="function"){const r=i.getAll(s.range);return new P((o,a)=>{r.onerror=l=>{a(l.target.error)},r.onsuccess=l=>{o(l.target.result)}})}{const r=this.cursor(s),o=[];return this.W(r,(a,l)=>{o.push(l)}).next(()=>o)}}G(t,e){const s=this.store.getAll(t,e===null?void 0:e);return new P((i,r)=>{s.onerror=o=>{r(o.target.error)},s.onsuccess=o=>{i(o.target.result)}})}j(t,e){N("SimpleDb","DELETE ALL",this.store.name);const s=this.options(t,e);s.H=!1;const i=this.cursor(s);return this.W(i,(r,o,a)=>a.delete())}J(t,e){let s;e?s=t:(s={},e=t);const i=this.cursor(s);return this.W(i,e)}Y(t){const e=this.cursor({});return new P((s,i)=>{e.onerror=r=>{const o=nu(r.target.error);i(o)},e.onsuccess=r=>{const o=r.target.result;o?t(o.primaryKey,o.value).next(a=>{a?o.continue():s()}):s()}})}W(t,e){const s=[];return new P((i,r)=>{t.onerror=o=>{r(o.target.error)},t.onsuccess=o=>{const a=o.target.result;if(!a)return void i();const l=new dE(a),u=e(a.primaryKey,a.value,l);if(u instanceof P){const h=u.catch(p=>(l.done(),P.reject(p)));s.push(h)}l.isDone?i():l.K===null?a.continue():a.continue(l.K)}}).next(()=>P.waitFor(s))}options(t,e){let s;return t!==void 0&&(typeof t=="string"?s=t:e=t),{index:s,range:e}}cursor(t){let e="next";if(t.reverse&&(e="prev"),t.index){const s=this.store.index(t.index);return t.H?s.openKeyCursor(t.range,e):s.openCursor(t.range,e)}return this.store.openCursor(t.range,e)}}function is(n){return new P((t,e)=>{n.onsuccess=s=>{const i=s.target.result;t(i)},n.onerror=s=>{const i=nu(s.target.error);e(i)}})}let Mh=!1;function nu(n){const t=Nn.S(Bt());if(t>=12.2&&t<13){const e="An internal error was encountered in the Indexed Database server";if(n.message.indexOf(e)>=0){const s=new U("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${e}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Mh||(Mh=!0,setTimeout(()=>{throw s},0)),s}}return n}class fE{constructor(t,e){this.asyncQueue=t,this.Z=e,this.task=null}start(){this.X(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}X(t){N("IndexBackfiller",`Scheduled in ${t}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",t,async()=>{this.task=null;try{N("IndexBackfiller",`Documents written: ${await this.Z.ee()}`)}catch(e){Wn(e)?N("IndexBackfiller","Ignoring IndexedDB error during index backfill: ",e):await Kn(e)}await this.X(6e4)})}}class pE{constructor(t,e){this.localStore=t,this.persistence=e}async ee(t=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",e=>this.te(e,t))}te(t,e){const s=new Set;let i=e,r=!0;return P.doWhile(()=>r===!0&&i>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(t).next(o=>{if(o!==null&&!s.has(o))return N("IndexBackfiller",`Processing collection: ${o}`),this.ne(t,o,i).next(a=>{i-=a,s.add(o)});r=!1})).next(()=>e-i)}ne(t,e,s){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(t,e).next(i=>this.localStore.localDocuments.getNextDocuments(t,e,i,s).next(r=>{const o=r.changes;return this.localStore.indexManager.updateIndexEntries(t,o).next(()=>this.re(i,r)).next(a=>(N("IndexBackfiller",`Updating offset: ${a}`),this.localStore.indexManager.updateCollectionGroup(t,e,a))).next(()=>o.size)}))}re(t,e){let s=t;return e.changes.forEach((i,r)=>{const o=Vm(r);eu(o,s)>0&&(s=o)}),new Se(s.readTime,s.documentKey,Math.max(e.batchId,t.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _e{constructor(t,e){this.previousValue=t,e&&(e.sequenceNumberHandler=s=>this.ie(s),this.se=s=>e.writeSequenceNumber(s))}ie(t){return this.previousValue=Math.max(t,this.previousValue),this.previousValue}next(){const t=++this.previousValue;return this.se&&this.se(t),t}}_e.oe=-1;function Oa(n){return n==null}function Pr(n){return n===0&&1/n==-1/0}function Mm(n){return typeof n=="number"&&Number.isInteger(n)&&!Pr(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fe(n){let t="";for(let e=0;e<n.length;e++)t.length>0&&(t=Lh(t)),t=mE(n.get(e),t);return Lh(t)}function mE(n,t){let e=t;const s=n.length;for(let i=0;i<s;i++){const r=n.charAt(i);switch(r){case"\0":e+="";break;case"":e+="";break;default:e+=r}}return e}function Lh(n){return n+""}function Be(n){const t=n.length;if(X(t>=2),t===2)return X(n.charAt(0)===""&&n.charAt(1)===""),vt.emptyPath();const e=t-2,s=[];let i="";for(let r=0;r<t;){const o=n.indexOf("",r);switch((o<0||o>e)&&G(),n.charAt(o+1)){case"":const a=n.substring(r,o);let l;i.length===0?l=a:(i+=a,l=i,i=""),s.push(l);break;case"":i+=n.substring(r,o),i+="\0";break;case"":i+=n.substring(r,o+1);break;default:G()}r=o+2}return new vt(s)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fh=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bo(n,t){return[n,fe(t)]}function Lm(n,t,e){return[n,fe(t),e]}const gE={},yE=["prefixPath","collectionGroup","readTime","documentId"],vE=["prefixPath","collectionGroup","documentId"],_E=["collectionGroup","readTime","prefixPath","documentId"],bE=["canonicalId","targetId"],wE=["targetId","path"],IE=["path","targetId"],EE=["collectionId","parent"],TE=["indexId","uid"],AE=["uid","sequenceNumber"],SE=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],kE=["indexId","uid","orderedDocumentKey"],RE=["userId","collectionPath","documentId"],PE=["userId","collectionPath","largestBatchId"],CE=["userId","collectionGroup","largestBatchId"],Fm=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],DE=[...Fm,"documentOverlays"],Um=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],qm=Um,Bm=[...qm,"indexConfiguration","indexState","indexEntries"],$E=Bm;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cl extends xm{constructor(t,e){super(),this._e=t,this.currentSequenceNumber=e}}function Jt(n,t){const e=W(n);return Nn.F(e._e,t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uh(n){let t=0;for(const e in n)Object.prototype.hasOwnProperty.call(n,e)&&t++;return t}function Ss(n,t){for(const e in n)Object.prototype.hasOwnProperty.call(n,e)&&t(e,n[e])}function jm(n){for(const t in n)if(Object.prototype.hasOwnProperty.call(n,t))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class At{constructor(t,e){this.comparator=t,this.root=e||Zt.EMPTY}insert(t,e){return new At(this.comparator,this.root.insert(t,e,this.comparator).copy(null,null,Zt.BLACK,null,null))}remove(t){return new At(this.comparator,this.root.remove(t,this.comparator).copy(null,null,Zt.BLACK,null,null))}get(t){let e=this.root;for(;!e.isEmpty();){const s=this.comparator(t,e.key);if(s===0)return e.value;s<0?e=e.left:s>0&&(e=e.right)}return null}indexOf(t){let e=0,s=this.root;for(;!s.isEmpty();){const i=this.comparator(t,s.key);if(i===0)return e+s.left.size;i<0?s=s.left:(e+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(t){return this.root.inorderTraversal(t)}forEach(t){this.inorderTraversal((e,s)=>(t(e,s),!1))}toString(){const t=[];return this.inorderTraversal((e,s)=>(t.push(`${e}:${s}`),!1)),`{${t.join(", ")}}`}reverseTraversal(t){return this.root.reverseTraversal(t)}getIterator(){return new ko(this.root,null,this.comparator,!1)}getIteratorFrom(t){return new ko(this.root,t,this.comparator,!1)}getReverseIterator(){return new ko(this.root,null,this.comparator,!0)}getReverseIteratorFrom(t){return new ko(this.root,t,this.comparator,!0)}}class ko{constructor(t,e,s,i){this.isReverse=i,this.nodeStack=[];let r=1;for(;!t.isEmpty();)if(r=e?s(t.key,e):1,e&&i&&(r*=-1),r<0)t=this.isReverse?t.left:t.right;else{if(r===0){this.nodeStack.push(t);break}this.nodeStack.push(t),t=this.isReverse?t.right:t.left}}getNext(){let t=this.nodeStack.pop();const e={key:t.key,value:t.value};if(this.isReverse)for(t=t.left;!t.isEmpty();)this.nodeStack.push(t),t=t.right;else for(t=t.right;!t.isEmpty();)this.nodeStack.push(t),t=t.left;return e}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const t=this.nodeStack[this.nodeStack.length-1];return{key:t.key,value:t.value}}}class Zt{constructor(t,e,s,i,r){this.key=t,this.value=e,this.color=s??Zt.RED,this.left=i??Zt.EMPTY,this.right=r??Zt.EMPTY,this.size=this.left.size+1+this.right.size}copy(t,e,s,i,r){return new Zt(t??this.key,e??this.value,s??this.color,i??this.left,r??this.right)}isEmpty(){return!1}inorderTraversal(t){return this.left.inorderTraversal(t)||t(this.key,this.value)||this.right.inorderTraversal(t)}reverseTraversal(t){return this.right.reverseTraversal(t)||t(this.key,this.value)||this.left.reverseTraversal(t)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(t,e,s){let i=this;const r=s(t,i.key);return i=r<0?i.copy(null,null,null,i.left.insert(t,e,s),null):r===0?i.copy(null,e,null,null,null):i.copy(null,null,null,null,i.right.insert(t,e,s)),i.fixUp()}removeMin(){if(this.left.isEmpty())return Zt.EMPTY;let t=this;return t.left.isRed()||t.left.left.isRed()||(t=t.moveRedLeft()),t=t.copy(null,null,null,t.left.removeMin(),null),t.fixUp()}remove(t,e){let s,i=this;if(e(t,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(t,e),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),e(t,i.key)===0){if(i.right.isEmpty())return Zt.EMPTY;s=i.right.min(),i=i.copy(s.key,s.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(t,e))}return i.fixUp()}isRed(){return this.color}fixUp(){let t=this;return t.right.isRed()&&!t.left.isRed()&&(t=t.rotateLeft()),t.left.isRed()&&t.left.left.isRed()&&(t=t.rotateRight()),t.left.isRed()&&t.right.isRed()&&(t=t.colorFlip()),t}moveRedLeft(){let t=this.colorFlip();return t.right.left.isRed()&&(t=t.copy(null,null,null,null,t.right.rotateRight()),t=t.rotateLeft(),t=t.colorFlip()),t}moveRedRight(){let t=this.colorFlip();return t.left.left.isRed()&&(t=t.rotateRight(),t=t.colorFlip()),t}rotateLeft(){const t=this.copy(null,null,Zt.RED,null,this.right.left);return this.right.copy(null,null,this.color,t,null)}rotateRight(){const t=this.copy(null,null,Zt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,t)}colorFlip(){const t=this.left.copy(null,null,!this.left.color,null,null),e=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,t,e)}checkMaxDepth(){const t=this.check();return Math.pow(2,t)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw G();const t=this.left.check();if(t!==this.right.check())throw G();return t+(this.isRed()?0:1)}}Zt.EMPTY=null,Zt.RED=!0,Zt.BLACK=!1;Zt.EMPTY=new class{constructor(){this.size=0}get key(){throw G()}get value(){throw G()}get color(){throw G()}get left(){throw G()}get right(){throw G()}copy(t,e,s,i,r){return this}insert(t,e,s){return new Zt(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(t){this.comparator=t,this.data=new At(this.comparator)}has(t){return this.data.get(t)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(t){return this.data.indexOf(t)}forEach(t){this.data.inorderTraversal((e,s)=>(t(e),!1))}forEachInRange(t,e){const s=this.data.getIteratorFrom(t[0]);for(;s.hasNext();){const i=s.getNext();if(this.comparator(i.key,t[1])>=0)return;e(i.key)}}forEachWhile(t,e){let s;for(s=e!==void 0?this.data.getIteratorFrom(e):this.data.getIterator();s.hasNext();)if(!t(s.getNext().key))return}firstAfterOrEqual(t){const e=this.data.getIteratorFrom(t);return e.hasNext()?e.getNext().key:null}getIterator(){return new qh(this.data.getIterator())}getIteratorFrom(t){return new qh(this.data.getIteratorFrom(t))}add(t){return this.copy(this.data.remove(t).insert(t,!0))}delete(t){return this.has(t)?this.copy(this.data.remove(t)):this}isEmpty(){return this.data.isEmpty()}unionWith(t){let e=this;return e.size<t.size&&(e=t,t=this),t.forEach(s=>{e=e.add(s)}),e}isEqual(t){if(!(t instanceof wt)||this.size!==t.size)return!1;const e=this.data.getIterator(),s=t.data.getIterator();for(;e.hasNext();){const i=e.getNext().key,r=s.getNext().key;if(this.comparator(i,r)!==0)return!1}return!0}toArray(){const t=[];return this.forEach(e=>{t.push(e)}),t}toString(){const t=[];return this.forEach(e=>t.push(e)),"SortedSet("+t.toString()+")"}copy(t){const e=new wt(this.comparator);return e.data=t,e}}class qh{constructor(t){this.iter=t}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function xs(n){return n.hasNext()?n.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class be{constructor(t){this.fields=t,t.sort(Ct.comparator)}static empty(){return new be([])}unionWith(t){let e=new wt(Ct.comparator);for(const s of this.fields)e=e.add(s);for(const s of t)e=e.add(s);return new be(e.toArray())}covers(t){for(const e of this.fields)if(e.isPrefixOf(t))return!0;return!1}isEqual(t){return oi(this.fields,t.fields,(e,s)=>e.isEqual(s))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zm extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qt{constructor(t){this.binaryString=t}static fromBase64String(t){const e=function(i){try{return atob(i)}catch(r){throw typeof DOMException<"u"&&r instanceof DOMException?new zm("Invalid base64 string: "+r):r}}(t);return new Qt(e)}static fromUint8Array(t){const e=function(i){let r="";for(let o=0;o<i.length;++o)r+=String.fromCharCode(i[o]);return r}(t);return new Qt(e)}[Symbol.iterator](){let t=0;return{next:()=>t<this.binaryString.length?{value:this.binaryString.charCodeAt(t++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(e){return btoa(e)}(this.binaryString)}toUint8Array(){return function(e){const s=new Uint8Array(e.length);for(let i=0;i<e.length;i++)s[i]=e.charCodeAt(i);return s}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(t){return nt(this.binaryString,t.binaryString)}isEqual(t){return this.binaryString===t.binaryString}}Qt.EMPTY_BYTE_STRING=new Qt("");const VE=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function ln(n){if(X(!!n),typeof n=="string"){let t=0;const e=VE.exec(n);if(X(!!e),e[1]){let i=e[1];i=(i+"000000000").substr(0,9),t=Number(i)}const s=new Date(n);return{seconds:Math.floor(s.getTime()/1e3),nanos:t}}return{seconds:xt(n.seconds),nanos:xt(n.nanos)}}function xt(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function qn(n){return typeof n=="string"?Qt.fromBase64String(n):Qt.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function su(n){var t,e;return((e=(((t=n==null?void 0:n.mapValue)===null||t===void 0?void 0:t.fields)||{}).__type__)===null||e===void 0?void 0:e.stringValue)==="server_timestamp"}function iu(n){const t=n.mapValue.fields.__previous_value__;return su(t)?iu(t):t}function Cr(n){const t=ln(n.mapValue.fields.__local_write_time__.timestampValue);return new Dt(t.seconds,t.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NE{constructor(t,e,s,i,r,o,a,l,u){this.databaseId=t,this.appId=e,this.persistenceKey=s,this.host=i,this.ssl=r,this.forceLongPolling=o,this.autoDetectLongPolling=a,this.longPollingOptions=l,this.useFetchStreams=u}}class vs{constructor(t,e){this.projectId=t,this.database=e||"(default)"}static empty(){return new vs("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(t){return t instanceof vs&&t.projectId===this.projectId&&t.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rn={mapValue:{fields:{__type__:{stringValue:"__max__"}}}},jo={nullValue:"NULL_VALUE"};function _s(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?su(n)?4:Gm(n)?9007199254740991:10:G()}function Qe(n,t){if(n===t)return!0;const e=_s(n);if(e!==_s(t))return!1;switch(e){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===t.booleanValue;case 4:return Cr(n).isEqual(Cr(t));case 3:return function(i,r){if(typeof i.timestampValue=="string"&&typeof r.timestampValue=="string"&&i.timestampValue.length===r.timestampValue.length)return i.timestampValue===r.timestampValue;const o=ln(i.timestampValue),a=ln(r.timestampValue);return o.seconds===a.seconds&&o.nanos===a.nanos}(n,t);case 5:return n.stringValue===t.stringValue;case 6:return function(i,r){return qn(i.bytesValue).isEqual(qn(r.bytesValue))}(n,t);case 7:return n.referenceValue===t.referenceValue;case 8:return function(i,r){return xt(i.geoPointValue.latitude)===xt(r.geoPointValue.latitude)&&xt(i.geoPointValue.longitude)===xt(r.geoPointValue.longitude)}(n,t);case 2:return function(i,r){if("integerValue"in i&&"integerValue"in r)return xt(i.integerValue)===xt(r.integerValue);if("doubleValue"in i&&"doubleValue"in r){const o=xt(i.doubleValue),a=xt(r.doubleValue);return o===a?Pr(o)===Pr(a):isNaN(o)&&isNaN(a)}return!1}(n,t);case 9:return oi(n.arrayValue.values||[],t.arrayValue.values||[],Qe);case 10:return function(i,r){const o=i.mapValue.fields||{},a=r.mapValue.fields||{};if(Uh(o)!==Uh(a))return!1;for(const l in o)if(o.hasOwnProperty(l)&&(a[l]===void 0||!Qe(o[l],a[l])))return!1;return!0}(n,t);default:return G()}}function Dr(n,t){return(n.values||[]).find(e=>Qe(e,t))!==void 0}function Bn(n,t){if(n===t)return 0;const e=_s(n),s=_s(t);if(e!==s)return nt(e,s);switch(e){case 0:case 9007199254740991:return 0;case 1:return nt(n.booleanValue,t.booleanValue);case 2:return function(r,o){const a=xt(r.integerValue||r.doubleValue),l=xt(o.integerValue||o.doubleValue);return a<l?-1:a>l?1:a===l?0:isNaN(a)?isNaN(l)?0:-1:1}(n,t);case 3:return Bh(n.timestampValue,t.timestampValue);case 4:return Bh(Cr(n),Cr(t));case 5:return nt(n.stringValue,t.stringValue);case 6:return function(r,o){const a=qn(r),l=qn(o);return a.compareTo(l)}(n.bytesValue,t.bytesValue);case 7:return function(r,o){const a=r.split("/"),l=o.split("/");for(let u=0;u<a.length&&u<l.length;u++){const h=nt(a[u],l[u]);if(h!==0)return h}return nt(a.length,l.length)}(n.referenceValue,t.referenceValue);case 8:return function(r,o){const a=nt(xt(r.latitude),xt(o.latitude));return a!==0?a:nt(xt(r.longitude),xt(o.longitude))}(n.geoPointValue,t.geoPointValue);case 9:return function(r,o){const a=r.values||[],l=o.values||[];for(let u=0;u<a.length&&u<l.length;++u){const h=Bn(a[u],l[u]);if(h)return h}return nt(a.length,l.length)}(n.arrayValue,t.arrayValue);case 10:return function(r,o){if(r===Rn.mapValue&&o===Rn.mapValue)return 0;if(r===Rn.mapValue)return 1;if(o===Rn.mapValue)return-1;const a=r.fields||{},l=Object.keys(a),u=o.fields||{},h=Object.keys(u);l.sort(),h.sort();for(let p=0;p<l.length&&p<h.length;++p){const m=nt(l[p],h[p]);if(m!==0)return m;const I=Bn(a[l[p]],u[h[p]]);if(I!==0)return I}return nt(l.length,h.length)}(n.mapValue,t.mapValue);default:throw G()}}function Bh(n,t){if(typeof n=="string"&&typeof t=="string"&&n.length===t.length)return nt(n,t);const e=ln(n),s=ln(t),i=nt(e.seconds,s.seconds);return i!==0?i:nt(e.nanos,s.nanos)}function ai(n){return ll(n)}function ll(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(e){const s=ln(e);return`time(${s.seconds},${s.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(e){return qn(e).toBase64()}(n.bytesValue):"referenceValue"in n?function(e){return q.fromName(e).toString()}(n.referenceValue):"geoPointValue"in n?function(e){return`geo(${e.latitude},${e.longitude})`}(n.geoPointValue):"arrayValue"in n?function(e){let s="[",i=!0;for(const r of e.values||[])i?i=!1:s+=",",s+=ll(r);return s+"]"}(n.arrayValue):"mapValue"in n?function(e){const s=Object.keys(e.fields||{}).sort();let i="{",r=!0;for(const o of s)r?r=!1:i+=",",i+=`${o}:${ll(e.fields[o])}`;return i+"}"}(n.mapValue):G()}function $r(n,t){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${t.path.canonicalString()}`}}function ul(n){return!!n&&"integerValue"in n}function Vr(n){return!!n&&"arrayValue"in n}function jh(n){return!!n&&"nullValue"in n}function zh(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function zo(n){return!!n&&"mapValue"in n}function fr(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const t={mapValue:{fields:{}}};return Ss(n.mapValue.fields,(e,s)=>t.mapValue.fields[e]=fr(s)),t}if(n.arrayValue){const t={arrayValue:{values:[]}};for(let e=0;e<(n.arrayValue.values||[]).length;++e)t.arrayValue.values[e]=fr(n.arrayValue.values[e]);return t}return Object.assign({},n)}function Gm(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}function xE(n){return"nullValue"in n?jo:"booleanValue"in n?{booleanValue:!1}:"integerValue"in n||"doubleValue"in n?{doubleValue:NaN}:"timestampValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in n?{stringValue:""}:"bytesValue"in n?{bytesValue:""}:"referenceValue"in n?$r(vs.empty(),q.empty()):"geoPointValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in n?{arrayValue:{}}:"mapValue"in n?{mapValue:{}}:G()}function OE(n){return"nullValue"in n?{booleanValue:!1}:"booleanValue"in n?{doubleValue:NaN}:"integerValue"in n||"doubleValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in n?{stringValue:""}:"stringValue"in n?{bytesValue:""}:"bytesValue"in n?$r(vs.empty(),q.empty()):"referenceValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in n?{arrayValue:{}}:"arrayValue"in n?{mapValue:{}}:"mapValue"in n?Rn:G()}function Gh(n,t){const e=Bn(n.value,t.value);return e!==0?e:n.inclusive&&!t.inclusive?-1:!n.inclusive&&t.inclusive?1:0}function Kh(n,t){const e=Bn(n.value,t.value);return e!==0?e:n.inclusive&&!t.inclusive?1:!n.inclusive&&t.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oe{constructor(t){this.value=t}static empty(){return new oe({mapValue:{}})}field(t){if(t.isEmpty())return this.value;{let e=this.value;for(let s=0;s<t.length-1;++s)if(e=(e.mapValue.fields||{})[t.get(s)],!zo(e))return null;return e=(e.mapValue.fields||{})[t.lastSegment()],e||null}}set(t,e){this.getFieldsMap(t.popLast())[t.lastSegment()]=fr(e)}setAll(t){let e=Ct.emptyPath(),s={},i=[];t.forEach((o,a)=>{if(!e.isImmediateParentOf(a)){const l=this.getFieldsMap(e);this.applyChanges(l,s,i),s={},i=[],e=a.popLast()}o?s[a.lastSegment()]=fr(o):i.push(a.lastSegment())});const r=this.getFieldsMap(e);this.applyChanges(r,s,i)}delete(t){const e=this.field(t.popLast());zo(e)&&e.mapValue.fields&&delete e.mapValue.fields[t.lastSegment()]}isEqual(t){return Qe(this.value,t.value)}getFieldsMap(t){let e=this.value;e.mapValue.fields||(e.mapValue={fields:{}});for(let s=0;s<t.length;++s){let i=e.mapValue.fields[t.get(s)];zo(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},e.mapValue.fields[t.get(s)]=i),e=i}return e.mapValue.fields}applyChanges(t,e,s){Ss(e,(i,r)=>t[i]=r);for(const i of s)delete t[i]}clone(){return new oe(fr(this.value))}}function Km(n){const t=[];return Ss(n.fields,(e,s)=>{const i=new Ct([e]);if(zo(s)){const r=Km(s.mapValue).fields;if(r.length===0)t.push(i);else for(const o of r)t.push(i.child(o))}else t.push(i)}),new be(t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ot{constructor(t,e,s,i,r,o,a){this.key=t,this.documentType=e,this.version=s,this.readTime=i,this.createTime=r,this.data=o,this.documentState=a}static newInvalidDocument(t){return new Ot(t,0,Z.min(),Z.min(),Z.min(),oe.empty(),0)}static newFoundDocument(t,e,s,i){return new Ot(t,1,e,Z.min(),s,i,0)}static newNoDocument(t,e){return new Ot(t,2,e,Z.min(),Z.min(),oe.empty(),0)}static newUnknownDocument(t,e){return new Ot(t,3,e,Z.min(),Z.min(),oe.empty(),2)}convertToFoundDocument(t,e){return!this.createTime.isEqual(Z.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=t),this.version=t,this.documentType=1,this.data=e,this.documentState=0,this}convertToNoDocument(t){return this.version=t,this.documentType=2,this.data=oe.empty(),this.documentState=0,this}convertToUnknownDocument(t){return this.version=t,this.documentType=3,this.data=oe.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=Z.min(),this}setReadTime(t){return this.readTime=t,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(t){return t instanceof Ot&&this.key.isEqual(t.key)&&this.version.isEqual(t.version)&&this.documentType===t.documentType&&this.documentState===t.documentState&&this.data.isEqual(t.data)}mutableCopy(){return new Ot(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ci{constructor(t,e){this.position=t,this.inclusive=e}}function Wh(n,t,e){let s=0;for(let i=0;i<n.position.length;i++){const r=t[i],o=n.position[i];if(r.field.isKeyField()?s=q.comparator(q.fromName(o.referenceValue),e.key):s=Bn(o,e.data.field(r.field)),r.dir==="desc"&&(s*=-1),s!==0)break}return s}function Hh(n,t){if(n===null)return t===null;if(t===null||n.inclusive!==t.inclusive||n.position.length!==t.position.length)return!1;for(let e=0;e<n.position.length;e++)if(!Qe(n.position[e],t.position[e]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aa{constructor(t,e="asc"){this.field=t,this.dir=e}}function ME(n,t){return n.dir===t.dir&&n.field.isEqual(t.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wm{}class at extends Wm{constructor(t,e,s){super(),this.field=t,this.op=e,this.value=s}static create(t,e,s){return t.isKeyField()?e==="in"||e==="not-in"?this.createKeyFieldInFilter(t,e,s):new LE(t,e,s):e==="array-contains"?new qE(t,s):e==="in"?new Zm(t,s):e==="not-in"?new BE(t,s):e==="array-contains-any"?new jE(t,s):new at(t,e,s)}static createKeyFieldInFilter(t,e,s){return e==="in"?new FE(t,s):new UE(t,s)}matches(t){const e=t.data.field(this.field);return this.op==="!="?e!==null&&this.matchesComparison(Bn(e,this.value)):e!==null&&_s(this.value)===_s(e)&&this.matchesComparison(Bn(e,this.value))}matchesComparison(t){switch(this.op){case"<":return t<0;case"<=":return t<=0;case"==":return t===0;case"!=":return t!==0;case">":return t>0;case">=":return t>=0;default:return G()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class bt extends Wm{constructor(t,e){super(),this.filters=t,this.op=e,this.ae=null}static create(t,e){return new bt(t,e)}matches(t){return li(this)?this.filters.find(e=>!e.matches(t))===void 0:this.filters.find(e=>e.matches(t))!==void 0}getFlattenedFilters(){return this.ae!==null||(this.ae=this.filters.reduce((t,e)=>t.concat(e.getFlattenedFilters()),[])),this.ae}getFilters(){return Object.assign([],this.filters)}}function li(n){return n.op==="and"}function dl(n){return n.op==="or"}function ru(n){return Hm(n)&&li(n)}function Hm(n){for(const t of n.filters)if(t instanceof bt)return!1;return!0}function hl(n){if(n instanceof at)return n.field.canonicalString()+n.op.toString()+ai(n.value);if(ru(n))return n.filters.map(t=>hl(t)).join(",");{const t=n.filters.map(e=>hl(e)).join(",");return`${n.op}(${t})`}}function Qm(n,t){return n instanceof at?function(s,i){return i instanceof at&&s.op===i.op&&s.field.isEqual(i.field)&&Qe(s.value,i.value)}(n,t):n instanceof bt?function(s,i){return i instanceof bt&&s.op===i.op&&s.filters.length===i.filters.length?s.filters.reduce((r,o,a)=>r&&Qm(o,i.filters[a]),!0):!1}(n,t):void G()}function Jm(n,t){const e=n.filters.concat(t);return bt.create(e,n.op)}function Ym(n){return n instanceof at?function(e){return`${e.field.canonicalString()} ${e.op} ${ai(e.value)}`}(n):n instanceof bt?function(e){return e.op.toString()+" {"+e.getFilters().map(Ym).join(" ,")+"}"}(n):"Filter"}class LE extends at{constructor(t,e,s){super(t,e,s),this.key=q.fromName(s.referenceValue)}matches(t){const e=q.comparator(t.key,this.key);return this.matchesComparison(e)}}class FE extends at{constructor(t,e){super(t,"in",e),this.keys=Xm("in",e)}matches(t){return this.keys.some(e=>e.isEqual(t.key))}}class UE extends at{constructor(t,e){super(t,"not-in",e),this.keys=Xm("not-in",e)}matches(t){return!this.keys.some(e=>e.isEqual(t.key))}}function Xm(n,t){var e;return(((e=t.arrayValue)===null||e===void 0?void 0:e.values)||[]).map(s=>q.fromName(s.referenceValue))}class qE extends at{constructor(t,e){super(t,"array-contains",e)}matches(t){const e=t.data.field(this.field);return Vr(e)&&Dr(e.arrayValue,this.value)}}class Zm extends at{constructor(t,e){super(t,"in",e)}matches(t){const e=t.data.field(this.field);return e!==null&&Dr(this.value.arrayValue,e)}}class BE extends at{constructor(t,e){super(t,"not-in",e)}matches(t){if(Dr(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const e=t.data.field(this.field);return e!==null&&!Dr(this.value.arrayValue,e)}}class jE extends at{constructor(t,e){super(t,"array-contains-any",e)}matches(t){const e=t.data.field(this.field);return!(!Vr(e)||!e.arrayValue.values)&&e.arrayValue.values.some(s=>Dr(this.value.arrayValue,s))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zE{constructor(t,e=null,s=[],i=[],r=null,o=null,a=null){this.path=t,this.collectionGroup=e,this.orderBy=s,this.filters=i,this.limit=r,this.startAt=o,this.endAt=a,this.ue=null}}function fl(n,t=null,e=[],s=[],i=null,r=null,o=null){return new zE(n,t,e,s,i,r,o)}function bs(n){const t=W(n);if(t.ue===null){let e=t.path.canonicalString();t.collectionGroup!==null&&(e+="|cg:"+t.collectionGroup),e+="|f:",e+=t.filters.map(s=>hl(s)).join(","),e+="|ob:",e+=t.orderBy.map(s=>function(r){return r.field.canonicalString()+r.dir}(s)).join(","),Oa(t.limit)||(e+="|l:",e+=t.limit),t.startAt&&(e+="|lb:",e+=t.startAt.inclusive?"b:":"a:",e+=t.startAt.position.map(s=>ai(s)).join(",")),t.endAt&&(e+="|ub:",e+=t.endAt.inclusive?"a:":"b:",e+=t.endAt.position.map(s=>ai(s)).join(",")),t.ue=e}return t.ue}function Qr(n,t){if(n.limit!==t.limit||n.orderBy.length!==t.orderBy.length)return!1;for(let e=0;e<n.orderBy.length;e++)if(!ME(n.orderBy[e],t.orderBy[e]))return!1;if(n.filters.length!==t.filters.length)return!1;for(let e=0;e<n.filters.length;e++)if(!Qm(n.filters[e],t.filters[e]))return!1;return n.collectionGroup===t.collectionGroup&&!!n.path.isEqual(t.path)&&!!Hh(n.startAt,t.startAt)&&Hh(n.endAt,t.endAt)}function ca(n){return q.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function la(n,t){return n.filters.filter(e=>e instanceof at&&e.field.isEqual(t))}function Qh(n,t,e){let s=jo,i=!0;for(const r of la(n,t)){let o=jo,a=!0;switch(r.op){case"<":case"<=":o=xE(r.value);break;case"==":case"in":case">=":o=r.value;break;case">":o=r.value,a=!1;break;case"!=":case"not-in":o=jo}Gh({value:s,inclusive:i},{value:o,inclusive:a})<0&&(s=o,i=a)}if(e!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(t)){const o=e.position[r];Gh({value:s,inclusive:i},{value:o,inclusive:e.inclusive})<0&&(s=o,i=e.inclusive);break}}return{value:s,inclusive:i}}function Jh(n,t,e){let s=Rn,i=!0;for(const r of la(n,t)){let o=Rn,a=!0;switch(r.op){case">=":case">":o=OE(r.value),a=!1;break;case"==":case"in":case"<=":o=r.value;break;case"<":o=r.value,a=!1;break;case"!=":case"not-in":o=Rn}Kh({value:s,inclusive:i},{value:o,inclusive:a})>0&&(s=o,i=a)}if(e!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(t)){const o=e.position[r];Kh({value:s,inclusive:i},{value:o,inclusive:e.inclusive})>0&&(s=o,i=e.inclusive);break}}return{value:s,inclusive:i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jr{constructor(t,e=null,s=[],i=[],r=null,o="F",a=null,l=null){this.path=t,this.collectionGroup=e,this.explicitOrderBy=s,this.filters=i,this.limit=r,this.limitType=o,this.startAt=a,this.endAt=l,this.ce=null,this.le=null,this.he=null,this.startAt,this.endAt}}function tg(n,t,e,s,i,r,o,a){return new Jr(n,t,e,s,i,r,o,a)}function Ma(n){return new Jr(n)}function Yh(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function eg(n){return n.collectionGroup!==null}function pr(n){const t=W(n);if(t.ce===null){t.ce=[];const e=new Set;for(const r of t.explicitOrderBy)t.ce.push(r),e.add(r.field.canonicalString());const s=t.explicitOrderBy.length>0?t.explicitOrderBy[t.explicitOrderBy.length-1].dir:"asc";(function(o){let a=new wt(Ct.comparator);return o.filters.forEach(l=>{l.getFlattenedFilters().forEach(u=>{u.isInequality()&&(a=a.add(u.field))})}),a})(t).forEach(r=>{e.has(r.canonicalString())||r.isKeyField()||t.ce.push(new aa(r,s))}),e.has(Ct.keyField().canonicalString())||t.ce.push(new aa(Ct.keyField(),s))}return t.ce}function Te(n){const t=W(n);return t.le||(t.le=GE(t,pr(n))),t.le}function GE(n,t){if(n.limitType==="F")return fl(n.path,n.collectionGroup,t,n.filters,n.limit,n.startAt,n.endAt);{t=t.map(i=>{const r=i.dir==="desc"?"asc":"desc";return new aa(i.field,r)});const e=n.endAt?new ci(n.endAt.position,n.endAt.inclusive):null,s=n.startAt?new ci(n.startAt.position,n.startAt.inclusive):null;return fl(n.path,n.collectionGroup,t,n.filters,n.limit,e,s)}}function pl(n,t){const e=n.filters.concat([t]);return new Jr(n.path,n.collectionGroup,n.explicitOrderBy.slice(),e,n.limit,n.limitType,n.startAt,n.endAt)}function ml(n,t,e){return new Jr(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),t,e,n.startAt,n.endAt)}function La(n,t){return Qr(Te(n),Te(t))&&n.limitType===t.limitType}function ng(n){return`${bs(Te(n))}|lt:${n.limitType}`}function zs(n){return`Query(target=${function(e){let s=e.path.canonicalString();return e.collectionGroup!==null&&(s+=" collectionGroup="+e.collectionGroup),e.filters.length>0&&(s+=`, filters: [${e.filters.map(i=>Ym(i)).join(", ")}]`),Oa(e.limit)||(s+=", limit: "+e.limit),e.orderBy.length>0&&(s+=`, orderBy: [${e.orderBy.map(i=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(i)).join(", ")}]`),e.startAt&&(s+=", startAt: ",s+=e.startAt.inclusive?"b:":"a:",s+=e.startAt.position.map(i=>ai(i)).join(",")),e.endAt&&(s+=", endAt: ",s+=e.endAt.inclusive?"a:":"b:",s+=e.endAt.position.map(i=>ai(i)).join(",")),`Target(${s})`}(Te(n))}; limitType=${n.limitType})`}function Yr(n,t){return t.isFoundDocument()&&function(s,i){const r=i.key.path;return s.collectionGroup!==null?i.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(r):q.isDocumentKey(s.path)?s.path.isEqual(r):s.path.isImmediateParentOf(r)}(n,t)&&function(s,i){for(const r of pr(s))if(!r.field.isKeyField()&&i.data.field(r.field)===null)return!1;return!0}(n,t)&&function(s,i){for(const r of s.filters)if(!r.matches(i))return!1;return!0}(n,t)&&function(s,i){return!(s.startAt&&!function(o,a,l){const u=Wh(o,a,l);return o.inclusive?u<=0:u<0}(s.startAt,pr(s),i)||s.endAt&&!function(o,a,l){const u=Wh(o,a,l);return o.inclusive?u>=0:u>0}(s.endAt,pr(s),i))}(n,t)}function sg(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function ig(n){return(t,e)=>{let s=!1;for(const i of pr(n)){const r=KE(i,t,e);if(r!==0)return r;s=s||i.field.isKeyField()}return 0}}function KE(n,t,e){const s=n.field.isKeyField()?q.comparator(t.key,e.key):function(r,o,a){const l=o.data.field(r),u=a.data.field(r);return l!==null&&u!==null?Bn(l,u):G()}(n.field,t,e);switch(n.dir){case"asc":return s;case"desc":return-1*s;default:return G()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hn{constructor(t,e){this.mapKeyFn=t,this.equalsFn=e,this.inner={},this.innerSize=0}get(t){const e=this.mapKeyFn(t),s=this.inner[e];if(s!==void 0){for(const[i,r]of s)if(this.equalsFn(i,t))return r}}has(t){return this.get(t)!==void 0}set(t,e){const s=this.mapKeyFn(t),i=this.inner[s];if(i===void 0)return this.inner[s]=[[t,e]],void this.innerSize++;for(let r=0;r<i.length;r++)if(this.equalsFn(i[r][0],t))return void(i[r]=[t,e]);i.push([t,e]),this.innerSize++}delete(t){const e=this.mapKeyFn(t),s=this.inner[e];if(s===void 0)return!1;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],t))return s.length===1?delete this.inner[e]:s.splice(i,1),this.innerSize--,!0;return!1}forEach(t){Ss(this.inner,(e,s)=>{for(const[i,r]of s)t(i,r)})}isEmpty(){return jm(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const WE=new At(q.comparator);function Ee(){return WE}const rg=new At(q.comparator);function ar(...n){let t=rg;for(const e of n)t=t.insert(e.key,e);return t}function og(n){let t=rg;return n.forEach((e,s)=>t=t.insert(e,s.overlayedDocument)),t}function je(){return mr()}function ag(){return mr()}function mr(){return new Hn(n=>n.toString(),(n,t)=>n.isEqual(t))}const HE=new At(q.comparator),QE=new wt(q.comparator);function rt(...n){let t=QE;for(const e of n)t=t.add(e);return t}const JE=new wt(nt);function ou(){return JE}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cg(n,t){if(n.useProto3Json){if(isNaN(t))return{doubleValue:"NaN"};if(t===1/0)return{doubleValue:"Infinity"};if(t===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Pr(t)?"-0":t}}function lg(n){return{integerValue:""+n}}function YE(n,t){return Mm(t)?lg(t):cg(n,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fa{constructor(){this._=void 0}}function XE(n,t,e){return n instanceof Nr?function(i,r){const o={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return r&&su(r)&&(r=iu(r)),r&&(o.fields.__previous_value__=r),{mapValue:o}}(e,t):n instanceof ui?dg(n,t):n instanceof di?hg(n,t):function(i,r){const o=ug(i,r),a=Xh(o)+Xh(i.Pe);return ul(o)&&ul(i.Pe)?lg(a):cg(i.serializer,a)}(n,t)}function ZE(n,t,e){return n instanceof ui?dg(n,t):n instanceof di?hg(n,t):e}function ug(n,t){return n instanceof xr?function(s){return ul(s)||function(r){return!!r&&"doubleValue"in r}(s)}(t)?t:{integerValue:0}:null}class Nr extends Fa{}class ui extends Fa{constructor(t){super(),this.elements=t}}function dg(n,t){const e=fg(t);for(const s of n.elements)e.some(i=>Qe(i,s))||e.push(s);return{arrayValue:{values:e}}}class di extends Fa{constructor(t){super(),this.elements=t}}function hg(n,t){let e=fg(t);for(const s of n.elements)e=e.filter(i=>!Qe(i,s));return{arrayValue:{values:e}}}class xr extends Fa{constructor(t,e){super(),this.serializer=t,this.Pe=e}}function Xh(n){return xt(n.integerValue||n.doubleValue)}function fg(n){return Vr(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tT{constructor(t,e){this.field=t,this.transform=e}}function eT(n,t){return n.field.isEqual(t.field)&&function(s,i){return s instanceof ui&&i instanceof ui||s instanceof di&&i instanceof di?oi(s.elements,i.elements,Qe):s instanceof xr&&i instanceof xr?Qe(s.Pe,i.Pe):s instanceof Nr&&i instanceof Nr}(n.transform,t.transform)}class nT{constructor(t,e){this.version=t,this.transformResults=e}}class he{constructor(t,e){this.updateTime=t,this.exists=e}static none(){return new he}static exists(t){return new he(void 0,t)}static updateTime(t){return new he(t)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(t){return this.exists===t.exists&&(this.updateTime?!!t.updateTime&&this.updateTime.isEqual(t.updateTime):!t.updateTime)}}function Go(n,t){return n.updateTime!==void 0?t.isFoundDocument()&&t.version.isEqual(n.updateTime):n.exists===void 0||n.exists===t.isFoundDocument()}class Ua{}function pg(n,t){if(!n.hasLocalMutations||t&&t.fields.length===0)return null;if(t===null)return n.isNoDocument()?new qa(n.key,he.none()):new Ri(n.key,n.data,he.none());{const e=n.data,s=oe.empty();let i=new wt(Ct.comparator);for(let r of t.fields)if(!i.has(r)){let o=e.field(r);o===null&&r.length>1&&(r=r.popLast(),o=e.field(r)),o===null?s.delete(r):s.set(r,o),i=i.add(r)}return new hn(n.key,s,new be(i.toArray()),he.none())}}function sT(n,t,e){n instanceof Ri?function(i,r,o){const a=i.value.clone(),l=tf(i.fieldTransforms,r,o.transformResults);a.setAll(l),r.convertToFoundDocument(o.version,a).setHasCommittedMutations()}(n,t,e):n instanceof hn?function(i,r,o){if(!Go(i.precondition,r))return void r.convertToUnknownDocument(o.version);const a=tf(i.fieldTransforms,r,o.transformResults),l=r.data;l.setAll(mg(i)),l.setAll(a),r.convertToFoundDocument(o.version,l).setHasCommittedMutations()}(n,t,e):function(i,r,o){r.convertToNoDocument(o.version).setHasCommittedMutations()}(0,t,e)}function gr(n,t,e,s){return n instanceof Ri?function(r,o,a,l){if(!Go(r.precondition,o))return a;const u=r.value.clone(),h=ef(r.fieldTransforms,l,o);return u.setAll(h),o.convertToFoundDocument(o.version,u).setHasLocalMutations(),null}(n,t,e,s):n instanceof hn?function(r,o,a,l){if(!Go(r.precondition,o))return a;const u=ef(r.fieldTransforms,l,o),h=o.data;return h.setAll(mg(r)),h.setAll(u),o.convertToFoundDocument(o.version,h).setHasLocalMutations(),a===null?null:a.unionWith(r.fieldMask.fields).unionWith(r.fieldTransforms.map(p=>p.field))}(n,t,e,s):function(r,o,a){return Go(r.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):a}(n,t,e)}function iT(n,t){let e=null;for(const s of n.fieldTransforms){const i=t.data.field(s.field),r=ug(s.transform,i||null);r!=null&&(e===null&&(e=oe.empty()),e.set(s.field,r))}return e||null}function Zh(n,t){return n.type===t.type&&!!n.key.isEqual(t.key)&&!!n.precondition.isEqual(t.precondition)&&!!function(s,i){return s===void 0&&i===void 0||!(!s||!i)&&oi(s,i,(r,o)=>eT(r,o))}(n.fieldTransforms,t.fieldTransforms)&&(n.type===0?n.value.isEqual(t.value):n.type!==1||n.data.isEqual(t.data)&&n.fieldMask.isEqual(t.fieldMask))}class Ri extends Ua{constructor(t,e,s,i=[]){super(),this.key=t,this.value=e,this.precondition=s,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class hn extends Ua{constructor(t,e,s,i,r=[]){super(),this.key=t,this.data=e,this.fieldMask=s,this.precondition=i,this.fieldTransforms=r,this.type=1}getFieldMask(){return this.fieldMask}}function mg(n){const t=new Map;return n.fieldMask.fields.forEach(e=>{if(!e.isEmpty()){const s=n.data.field(e);t.set(e,s)}}),t}function tf(n,t,e){const s=new Map;X(n.length===e.length);for(let i=0;i<e.length;i++){const r=n[i],o=r.transform,a=t.data.field(r.field);s.set(r.field,ZE(o,a,e[i]))}return s}function ef(n,t,e){const s=new Map;for(const i of n){const r=i.transform,o=e.data.field(i.field);s.set(i.field,XE(r,o,t))}return s}class qa extends Ua{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class gg extends Ua{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class au{constructor(t,e,s,i){this.batchId=t,this.localWriteTime=e,this.baseMutations=s,this.mutations=i}applyToRemoteDocument(t,e){const s=e.mutationResults;for(let i=0;i<this.mutations.length;i++){const r=this.mutations[i];r.key.isEqual(t.key)&&sT(r,t,s[i])}}applyToLocalView(t,e){for(const s of this.baseMutations)s.key.isEqual(t.key)&&(e=gr(s,t,e,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(t.key)&&(e=gr(s,t,e,this.localWriteTime));return e}applyToLocalDocumentSet(t,e){const s=ag();return this.mutations.forEach(i=>{const r=t.get(i.key),o=r.overlayedDocument;let a=this.applyToLocalView(o,r.mutatedFields);a=e.has(i.key)?null:a;const l=pg(o,a);l!==null&&s.set(i.key,l),o.isValidDocument()||o.convertToNoDocument(Z.min())}),s}keys(){return this.mutations.reduce((t,e)=>t.add(e.key),rt())}isEqual(t){return this.batchId===t.batchId&&oi(this.mutations,t.mutations,(e,s)=>Zh(e,s))&&oi(this.baseMutations,t.baseMutations,(e,s)=>Zh(e,s))}}class cu{constructor(t,e,s,i){this.batch=t,this.commitVersion=e,this.mutationResults=s,this.docVersions=i}static from(t,e,s){X(t.mutations.length===s.length);let i=function(){return HE}();const r=t.mutations;for(let o=0;o<r.length;o++)i=i.insert(r[o].key,s[o].version);return new cu(t,e,s,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lu{constructor(t,e){this.largestBatchId=t,this.mutation=e}getKey(){return this.mutation.key}isEqual(t){return t!==null&&this.mutation===t.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rT{constructor(t,e){this.count=t,this.unchangedNames=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ft,ht;function oT(n){switch(n){default:return G();case V.CANCELLED:case V.UNKNOWN:case V.DEADLINE_EXCEEDED:case V.RESOURCE_EXHAUSTED:case V.INTERNAL:case V.UNAVAILABLE:case V.UNAUTHENTICATED:return!1;case V.INVALID_ARGUMENT:case V.NOT_FOUND:case V.ALREADY_EXISTS:case V.PERMISSION_DENIED:case V.FAILED_PRECONDITION:case V.ABORTED:case V.OUT_OF_RANGE:case V.UNIMPLEMENTED:case V.DATA_LOSS:return!0}}function yg(n){if(n===void 0)return Lt("GRPC error has no .code"),V.UNKNOWN;switch(n){case Ft.OK:return V.OK;case Ft.CANCELLED:return V.CANCELLED;case Ft.UNKNOWN:return V.UNKNOWN;case Ft.DEADLINE_EXCEEDED:return V.DEADLINE_EXCEEDED;case Ft.RESOURCE_EXHAUSTED:return V.RESOURCE_EXHAUSTED;case Ft.INTERNAL:return V.INTERNAL;case Ft.UNAVAILABLE:return V.UNAVAILABLE;case Ft.UNAUTHENTICATED:return V.UNAUTHENTICATED;case Ft.INVALID_ARGUMENT:return V.INVALID_ARGUMENT;case Ft.NOT_FOUND:return V.NOT_FOUND;case Ft.ALREADY_EXISTS:return V.ALREADY_EXISTS;case Ft.PERMISSION_DENIED:return V.PERMISSION_DENIED;case Ft.FAILED_PRECONDITION:return V.FAILED_PRECONDITION;case Ft.ABORTED:return V.ABORTED;case Ft.OUT_OF_RANGE:return V.OUT_OF_RANGE;case Ft.UNIMPLEMENTED:return V.UNIMPLEMENTED;case Ft.DATA_LOSS:return V.DATA_LOSS;default:return G()}}(ht=Ft||(Ft={}))[ht.OK=0]="OK",ht[ht.CANCELLED=1]="CANCELLED",ht[ht.UNKNOWN=2]="UNKNOWN",ht[ht.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",ht[ht.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",ht[ht.NOT_FOUND=5]="NOT_FOUND",ht[ht.ALREADY_EXISTS=6]="ALREADY_EXISTS",ht[ht.PERMISSION_DENIED=7]="PERMISSION_DENIED",ht[ht.UNAUTHENTICATED=16]="UNAUTHENTICATED",ht[ht.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",ht[ht.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",ht[ht.ABORTED=10]="ABORTED",ht[ht.OUT_OF_RANGE=11]="OUT_OF_RANGE",ht[ht.UNIMPLEMENTED=12]="UNIMPLEMENTED",ht[ht.INTERNAL=13]="INTERNAL",ht[ht.UNAVAILABLE=14]="UNAVAILABLE",ht[ht.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function aT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cT=new us([4294967295,4294967295],0);function nf(n){const t=aT().encode(n),e=new Em;return e.update(t),new Uint8Array(e.digest())}function sf(n){const t=new DataView(n.buffer),e=t.getUint32(0,!0),s=t.getUint32(4,!0),i=t.getUint32(8,!0),r=t.getUint32(12,!0);return[new us([e,s],0),new us([i,r],0)]}class uu{constructor(t,e,s){if(this.bitmap=t,this.padding=e,this.hashCount=s,e<0||e>=8)throw new cr(`Invalid padding: ${e}`);if(s<0)throw new cr(`Invalid hash count: ${s}`);if(t.length>0&&this.hashCount===0)throw new cr(`Invalid hash count: ${s}`);if(t.length===0&&e!==0)throw new cr(`Invalid padding when bitmap length is 0: ${e}`);this.Ie=8*t.length-e,this.Te=us.fromNumber(this.Ie)}Ee(t,e,s){let i=t.add(e.multiply(us.fromNumber(s)));return i.compare(cT)===1&&(i=new us([i.getBits(0),i.getBits(1)],0)),i.modulo(this.Te).toNumber()}de(t){return(this.bitmap[Math.floor(t/8)]&1<<t%8)!=0}mightContain(t){if(this.Ie===0)return!1;const e=nf(t),[s,i]=sf(e);for(let r=0;r<this.hashCount;r++){const o=this.Ee(s,i,r);if(!this.de(o))return!1}return!0}static create(t,e,s){const i=t%8==0?0:8-t%8,r=new Uint8Array(Math.ceil(t/8)),o=new uu(r,i,e);return s.forEach(a=>o.insert(a)),o}insert(t){if(this.Ie===0)return;const e=nf(t),[s,i]=sf(e);for(let r=0;r<this.hashCount;r++){const o=this.Ee(s,i,r);this.Ae(o)}}Ae(t){const e=Math.floor(t/8),s=t%8;this.bitmap[e]|=1<<s}}class cr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xr{constructor(t,e,s,i,r){this.snapshotVersion=t,this.targetChanges=e,this.targetMismatches=s,this.documentUpdates=i,this.resolvedLimboDocuments=r}static createSynthesizedRemoteEventForCurrentChange(t,e,s){const i=new Map;return i.set(t,Zr.createSynthesizedTargetChangeForCurrentChange(t,e,s)),new Xr(Z.min(),i,new At(nt),Ee(),rt())}}class Zr{constructor(t,e,s,i,r){this.resumeToken=t,this.current=e,this.addedDocuments=s,this.modifiedDocuments=i,this.removedDocuments=r}static createSynthesizedTargetChangeForCurrentChange(t,e,s){return new Zr(s,e,rt(),rt(),rt())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ko{constructor(t,e,s,i){this.Re=t,this.removedTargetIds=e,this.key=s,this.Ve=i}}class vg{constructor(t,e){this.targetId=t,this.me=e}}class _g{constructor(t,e,s=Qt.EMPTY_BYTE_STRING,i=null){this.state=t,this.targetIds=e,this.resumeToken=s,this.cause=i}}class rf{constructor(){this.fe=0,this.ge=af(),this.pe=Qt.EMPTY_BYTE_STRING,this.ye=!1,this.we=!0}get current(){return this.ye}get resumeToken(){return this.pe}get Se(){return this.fe!==0}get be(){return this.we}De(t){t.approximateByteSize()>0&&(this.we=!0,this.pe=t)}Ce(){let t=rt(),e=rt(),s=rt();return this.ge.forEach((i,r)=>{switch(r){case 0:t=t.add(i);break;case 2:e=e.add(i);break;case 1:s=s.add(i);break;default:G()}}),new Zr(this.pe,this.ye,t,e,s)}ve(){this.we=!1,this.ge=af()}Fe(t,e){this.we=!0,this.ge=this.ge.insert(t,e)}Me(t){this.we=!0,this.ge=this.ge.remove(t)}xe(){this.fe+=1}Oe(){this.fe-=1,X(this.fe>=0)}Ne(){this.we=!0,this.ye=!0}}class lT{constructor(t){this.Le=t,this.Be=new Map,this.ke=Ee(),this.qe=of(),this.Qe=new At(nt)}Ke(t){for(const e of t.Re)t.Ve&&t.Ve.isFoundDocument()?this.$e(e,t.Ve):this.Ue(e,t.key,t.Ve);for(const e of t.removedTargetIds)this.Ue(e,t.key,t.Ve)}We(t){this.forEachTarget(t,e=>{const s=this.Ge(e);switch(t.state){case 0:this.ze(e)&&s.De(t.resumeToken);break;case 1:s.Oe(),s.Se||s.ve(),s.De(t.resumeToken);break;case 2:s.Oe(),s.Se||this.removeTarget(e);break;case 3:this.ze(e)&&(s.Ne(),s.De(t.resumeToken));break;case 4:this.ze(e)&&(this.je(e),s.De(t.resumeToken));break;default:G()}})}forEachTarget(t,e){t.targetIds.length>0?t.targetIds.forEach(e):this.Be.forEach((s,i)=>{this.ze(i)&&e(i)})}He(t){const e=t.targetId,s=t.me.count,i=this.Je(e);if(i){const r=i.target;if(ca(r))if(s===0){const o=new q(r.path);this.Ue(e,o,Ot.newNoDocument(o,Z.min()))}else X(s===1);else{const o=this.Ye(e);if(o!==s){const a=this.Ze(t),l=a?this.Xe(a,t,o):1;if(l!==0){this.je(e);const u=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Qe=this.Qe.insert(e,u)}}}}}Ze(t){const e=t.me.unchangedNames;if(!e||!e.bits)return null;const{bits:{bitmap:s="",padding:i=0},hashCount:r=0}=e;let o,a;try{o=qn(s).toUint8Array()}catch(l){if(l instanceof zm)return Sr("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{a=new uu(o,i,r)}catch(l){return Sr(l instanceof cr?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return a.Ie===0?null:a}Xe(t,e,s){return e.me.count===s-this.nt(t,e.targetId)?0:2}nt(t,e){const s=this.Le.getRemoteKeysForTarget(e);let i=0;return s.forEach(r=>{const o=this.Le.tt(),a=`projects/${o.projectId}/databases/${o.database}/documents/${r.path.canonicalString()}`;t.mightContain(a)||(this.Ue(e,r,null),i++)}),i}rt(t){const e=new Map;this.Be.forEach((r,o)=>{const a=this.Je(o);if(a){if(r.current&&ca(a.target)){const l=new q(a.target.path);this.ke.get(l)!==null||this.it(o,l)||this.Ue(o,l,Ot.newNoDocument(l,t))}r.be&&(e.set(o,r.Ce()),r.ve())}});let s=rt();this.qe.forEach((r,o)=>{let a=!0;o.forEachWhile(l=>{const u=this.Je(l);return!u||u.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)}),a&&(s=s.add(r))}),this.ke.forEach((r,o)=>o.setReadTime(t));const i=new Xr(t,e,this.Qe,this.ke,s);return this.ke=Ee(),this.qe=of(),this.Qe=new At(nt),i}$e(t,e){if(!this.ze(t))return;const s=this.it(t,e.key)?2:0;this.Ge(t).Fe(e.key,s),this.ke=this.ke.insert(e.key,e),this.qe=this.qe.insert(e.key,this.st(e.key).add(t))}Ue(t,e,s){if(!this.ze(t))return;const i=this.Ge(t);this.it(t,e)?i.Fe(e,1):i.Me(e),this.qe=this.qe.insert(e,this.st(e).delete(t)),s&&(this.ke=this.ke.insert(e,s))}removeTarget(t){this.Be.delete(t)}Ye(t){const e=this.Ge(t).Ce();return this.Le.getRemoteKeysForTarget(t).size+e.addedDocuments.size-e.removedDocuments.size}xe(t){this.Ge(t).xe()}Ge(t){let e=this.Be.get(t);return e||(e=new rf,this.Be.set(t,e)),e}st(t){let e=this.qe.get(t);return e||(e=new wt(nt),this.qe=this.qe.insert(t,e)),e}ze(t){const e=this.Je(t)!==null;return e||N("WatchChangeAggregator","Detected inactive target",t),e}Je(t){const e=this.Be.get(t);return e&&e.Se?null:this.Le.ot(t)}je(t){this.Be.set(t,new rf),this.Le.getRemoteKeysForTarget(t).forEach(e=>{this.Ue(t,e,null)})}it(t,e){return this.Le.getRemoteKeysForTarget(t).has(e)}}function of(){return new At(q.comparator)}function af(){return new At(q.comparator)}const uT={asc:"ASCENDING",desc:"DESCENDING"},dT={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},hT={and:"AND",or:"OR"};class fT{constructor(t,e){this.databaseId=t,this.useProto3Json=e}}function gl(n,t){return n.useProto3Json||Oa(t)?t:{value:t}}function hi(n,t){return n.useProto3Json?`${new Date(1e3*t.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+t.nanoseconds).slice(-9)}Z`:{seconds:""+t.seconds,nanos:t.nanoseconds}}function bg(n,t){return n.useProto3Json?t.toBase64():t.toUint8Array()}function pT(n,t){return hi(n,t.toTimestamp())}function pe(n){return X(!!n),Z.fromTimestamp(function(e){const s=ln(e);return new Dt(s.seconds,s.nanos)}(n))}function du(n,t){return yl(n,t).canonicalString()}function yl(n,t){const e=function(i){return new vt(["projects",i.projectId,"databases",i.database])}(n).child("documents");return t===void 0?e:e.child(t)}function wg(n){const t=vt.fromString(n);return X(Cg(t)),t}function ua(n,t){return du(n.databaseId,t.path)}function ds(n,t){const e=wg(t);if(e.get(1)!==n.databaseId.projectId)throw new U(V.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+e.get(1)+" vs "+n.databaseId.projectId);if(e.get(3)!==n.databaseId.database)throw new U(V.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+e.get(3)+" vs "+n.databaseId.database);return new q(Tg(e))}function Ig(n,t){return du(n.databaseId,t)}function Eg(n){const t=wg(n);return t.length===4?vt.emptyPath():Tg(t)}function vl(n){return new vt(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function Tg(n){return X(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function cf(n,t,e){return{name:ua(n,t),fields:e.value.mapValue.fields}}function mT(n,t,e){const s=ds(n,t.name),i=pe(t.updateTime),r=t.createTime?pe(t.createTime):Z.min(),o=new oe({mapValue:{fields:t.fields}}),a=Ot.newFoundDocument(s,i,r,o);return e&&a.setHasCommittedMutations(),e?a.setHasCommittedMutations():a}function gT(n,t){let e;if("targetChange"in t){t.targetChange;const s=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:G()}(t.targetChange.targetChangeType||"NO_CHANGE"),i=t.targetChange.targetIds||[],r=function(u,h){return u.useProto3Json?(X(h===void 0||typeof h=="string"),Qt.fromBase64String(h||"")):(X(h===void 0||h instanceof Buffer||h instanceof Uint8Array),Qt.fromUint8Array(h||new Uint8Array))}(n,t.targetChange.resumeToken),o=t.targetChange.cause,a=o&&function(u){const h=u.code===void 0?V.UNKNOWN:yg(u.code);return new U(h,u.message||"")}(o);e=new _g(s,i,r,a||null)}else if("documentChange"in t){t.documentChange;const s=t.documentChange;s.document,s.document.name,s.document.updateTime;const i=ds(n,s.document.name),r=pe(s.document.updateTime),o=s.document.createTime?pe(s.document.createTime):Z.min(),a=new oe({mapValue:{fields:s.document.fields}}),l=Ot.newFoundDocument(i,r,o,a),u=s.targetIds||[],h=s.removedTargetIds||[];e=new Ko(u,h,l.key,l)}else if("documentDelete"in t){t.documentDelete;const s=t.documentDelete;s.document;const i=ds(n,s.document),r=s.readTime?pe(s.readTime):Z.min(),o=Ot.newNoDocument(i,r),a=s.removedTargetIds||[];e=new Ko([],a,o.key,o)}else if("documentRemove"in t){t.documentRemove;const s=t.documentRemove;s.document;const i=ds(n,s.document),r=s.removedTargetIds||[];e=new Ko([],r,i,null)}else{if(!("filter"in t))return G();{t.filter;const s=t.filter;s.targetId;const{count:i=0,unchangedNames:r}=s,o=new rT(i,r),a=s.targetId;e=new vg(a,o)}}return e}function da(n,t){let e;if(t instanceof Ri)e={update:cf(n,t.key,t.value)};else if(t instanceof qa)e={delete:ua(n,t.key)};else if(t instanceof hn)e={update:cf(n,t.key,t.data),updateMask:IT(t.fieldMask)};else{if(!(t instanceof gg))return G();e={verify:ua(n,t.key)}}return t.fieldTransforms.length>0&&(e.updateTransforms=t.fieldTransforms.map(s=>function(r,o){const a=o.transform;if(a instanceof Nr)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(a instanceof ui)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:a.elements}};if(a instanceof di)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:a.elements}};if(a instanceof xr)return{fieldPath:o.field.canonicalString(),increment:a.Pe};throw G()}(0,s))),t.precondition.isNone||(e.currentDocument=function(i,r){return r.updateTime!==void 0?{updateTime:pT(i,r.updateTime)}:r.exists!==void 0?{exists:r.exists}:G()}(n,t.precondition)),e}function _l(n,t){const e=t.currentDocument?function(r){return r.updateTime!==void 0?he.updateTime(pe(r.updateTime)):r.exists!==void 0?he.exists(r.exists):he.none()}(t.currentDocument):he.none(),s=t.updateTransforms?t.updateTransforms.map(i=>function(o,a){let l=null;if("setToServerValue"in a)X(a.setToServerValue==="REQUEST_TIME"),l=new Nr;else if("appendMissingElements"in a){const h=a.appendMissingElements.values||[];l=new ui(h)}else if("removeAllFromArray"in a){const h=a.removeAllFromArray.values||[];l=new di(h)}else"increment"in a?l=new xr(o,a.increment):G();const u=Ct.fromServerFormat(a.fieldPath);return new tT(u,l)}(n,i)):[];if(t.update){t.update.name;const i=ds(n,t.update.name),r=new oe({mapValue:{fields:t.update.fields}});if(t.updateMask){const o=function(l){const u=l.fieldPaths||[];return new be(u.map(h=>Ct.fromServerFormat(h)))}(t.updateMask);return new hn(i,r,o,e,s)}return new Ri(i,r,e,s)}if(t.delete){const i=ds(n,t.delete);return new qa(i,e)}if(t.verify){const i=ds(n,t.verify);return new gg(i,e)}return G()}function yT(n,t){return n&&n.length>0?(X(t!==void 0),n.map(e=>function(i,r){let o=i.updateTime?pe(i.updateTime):pe(r);return o.isEqual(Z.min())&&(o=pe(r)),new nT(o,i.transformResults||[])}(e,t))):[]}function Ag(n,t){return{documents:[Ig(n,t.path)]}}function Sg(n,t){const e={structuredQuery:{}},s=t.path;let i;t.collectionGroup!==null?(i=s,e.structuredQuery.from=[{collectionId:t.collectionGroup,allDescendants:!0}]):(i=s.popLast(),e.structuredQuery.from=[{collectionId:s.lastSegment()}]),e.parent=Ig(n,i);const r=function(u){if(u.length!==0)return Pg(bt.create(u,"and"))}(t.filters);r&&(e.structuredQuery.where=r);const o=function(u){if(u.length!==0)return u.map(h=>function(m){return{field:Gs(m.field),direction:_T(m.dir)}}(h))}(t.orderBy);o&&(e.structuredQuery.orderBy=o);const a=gl(n,t.limit);return a!==null&&(e.structuredQuery.limit=a),t.startAt&&(e.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(t.startAt)),t.endAt&&(e.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(t.endAt)),{_t:e,parent:i}}function kg(n){let t=Eg(n.parent);const e=n.structuredQuery,s=e.from?e.from.length:0;let i=null;if(s>0){X(s===1);const h=e.from[0];h.allDescendants?i=h.collectionId:t=t.child(h.collectionId)}let r=[];e.where&&(r=function(p){const m=Rg(p);return m instanceof bt&&ru(m)?m.getFilters():[m]}(e.where));let o=[];e.orderBy&&(o=function(p){return p.map(m=>function(E){return new aa(Ks(E.field),function(R){switch(R){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(E.direction))}(m))}(e.orderBy));let a=null;e.limit&&(a=function(p){let m;return m=typeof p=="object"?p.value:p,Oa(m)?null:m}(e.limit));let l=null;e.startAt&&(l=function(p){const m=!!p.before,I=p.values||[];return new ci(I,m)}(e.startAt));let u=null;return e.endAt&&(u=function(p){const m=!p.before,I=p.values||[];return new ci(I,m)}(e.endAt)),tg(t,i,o,r,a,"F",l,u)}function vT(n,t){const e=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return G()}}(t.purpose);return e==null?null:{"goog-listen-tags":e}}function Rg(n){return n.unaryFilter!==void 0?function(e){switch(e.unaryFilter.op){case"IS_NAN":const s=Ks(e.unaryFilter.field);return at.create(s,"==",{doubleValue:NaN});case"IS_NULL":const i=Ks(e.unaryFilter.field);return at.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const r=Ks(e.unaryFilter.field);return at.create(r,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=Ks(e.unaryFilter.field);return at.create(o,"!=",{nullValue:"NULL_VALUE"});default:return G()}}(n):n.fieldFilter!==void 0?function(e){return at.create(Ks(e.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return G()}}(e.fieldFilter.op),e.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(e){return bt.create(e.compositeFilter.filters.map(s=>Rg(s)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return G()}}(e.compositeFilter.op))}(n):G()}function _T(n){return uT[n]}function bT(n){return dT[n]}function wT(n){return hT[n]}function Gs(n){return{fieldPath:n.canonicalString()}}function Ks(n){return Ct.fromServerFormat(n.fieldPath)}function Pg(n){return n instanceof at?function(e){if(e.op==="=="){if(zh(e.value))return{unaryFilter:{field:Gs(e.field),op:"IS_NAN"}};if(jh(e.value))return{unaryFilter:{field:Gs(e.field),op:"IS_NULL"}}}else if(e.op==="!="){if(zh(e.value))return{unaryFilter:{field:Gs(e.field),op:"IS_NOT_NAN"}};if(jh(e.value))return{unaryFilter:{field:Gs(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Gs(e.field),op:bT(e.op),value:e.value}}}(n):n instanceof bt?function(e){const s=e.getFilters().map(i=>Pg(i));return s.length===1?s[0]:{compositeFilter:{op:wT(e.op),filters:s}}}(n):G()}function IT(n){const t=[];return n.fields.forEach(e=>t.push(e.canonicalString())),{fieldPaths:t}}function Cg(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class on{constructor(t,e,s,i,r=Z.min(),o=Z.min(),a=Qt.EMPTY_BYTE_STRING,l=null){this.target=t,this.targetId=e,this.purpose=s,this.sequenceNumber=i,this.snapshotVersion=r,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=l}withSequenceNumber(t){return new on(this.target,this.targetId,this.purpose,t,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(t,e){return new on(this.target,this.targetId,this.purpose,this.sequenceNumber,e,this.lastLimboFreeSnapshotVersion,t,null)}withExpectedCount(t){return new on(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,t)}withLastLimboFreeSnapshotVersion(t){return new on(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,t,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dg{constructor(t){this.ct=t}}function ET(n,t){let e;if(t.document)e=mT(n.ct,t.document,!!t.hasCommittedMutations);else if(t.noDocument){const s=q.fromSegments(t.noDocument.path),i=Is(t.noDocument.readTime);e=Ot.newNoDocument(s,i),t.hasCommittedMutations&&e.setHasCommittedMutations()}else{if(!t.unknownDocument)return G();{const s=q.fromSegments(t.unknownDocument.path),i=Is(t.unknownDocument.version);e=Ot.newUnknownDocument(s,i)}}return t.readTime&&e.setReadTime(function(i){const r=new Dt(i[0],i[1]);return Z.fromTimestamp(r)}(t.readTime)),e}function lf(n,t){const e=t.key,s={prefixPath:e.getCollectionPath().popLast().toArray(),collectionGroup:e.collectionGroup,documentId:e.path.lastSegment(),readTime:ha(t.readTime),hasCommittedMutations:t.hasCommittedMutations};if(t.isFoundDocument())s.document=function(r,o){return{name:ua(r,o.key),fields:o.data.value.mapValue.fields,updateTime:hi(r,o.version.toTimestamp()),createTime:hi(r,o.createTime.toTimestamp())}}(n.ct,t);else if(t.isNoDocument())s.noDocument={path:e.path.toArray(),readTime:ws(t.version)};else{if(!t.isUnknownDocument())return G();s.unknownDocument={path:e.path.toArray(),version:ws(t.version)}}return s}function ha(n){const t=n.toTimestamp();return[t.seconds,t.nanoseconds]}function ws(n){const t=n.toTimestamp();return{seconds:t.seconds,nanoseconds:t.nanoseconds}}function Is(n){const t=new Dt(n.seconds,n.nanoseconds);return Z.fromTimestamp(t)}function rs(n,t){const e=(t.baseMutations||[]).map(r=>_l(n.ct,r));for(let r=0;r<t.mutations.length-1;++r){const o=t.mutations[r];if(r+1<t.mutations.length&&t.mutations[r+1].transform!==void 0){const a=t.mutations[r+1];o.updateTransforms=a.transform.fieldTransforms,t.mutations.splice(r+1,1),++r}}const s=t.mutations.map(r=>_l(n.ct,r)),i=Dt.fromMillis(t.localWriteTimeMs);return new au(t.batchId,i,e,s)}function lr(n){const t=Is(n.readTime),e=n.lastLimboFreeSnapshotVersion!==void 0?Is(n.lastLimboFreeSnapshotVersion):Z.min();let s;return s=function(r){return r.documents!==void 0}(n.query)?function(r){return X(r.documents.length===1),Te(Ma(Eg(r.documents[0])))}(n.query):function(r){return Te(kg(r))}(n.query),new on(s,n.targetId,"TargetPurposeListen",n.lastListenSequenceNumber,t,e,Qt.fromBase64String(n.resumeToken))}function $g(n,t){const e=ws(t.snapshotVersion),s=ws(t.lastLimboFreeSnapshotVersion);let i;i=ca(t.target)?Ag(n.ct,t.target):Sg(n.ct,t.target)._t;const r=t.resumeToken.toBase64();return{targetId:t.targetId,canonicalId:bs(t.target),readTime:e,resumeToken:r,lastListenSequenceNumber:t.sequenceNumber,lastLimboFreeSnapshotVersion:s,query:i}}function Vg(n){const t=kg({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?ml(t,t.limit,"L"):t}function Lc(n,t){return new lu(t.largestBatchId,_l(n.ct,t.overlayMutation))}function uf(n,t){const e=t.path.lastSegment();return[n,fe(t.path.popLast()),e]}function df(n,t,e,s){return{indexId:n,uid:t,sequenceNumber:e,readTime:ws(s.readTime),documentKey:fe(s.documentKey.path),largestBatchId:s.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TT{getBundleMetadata(t,e){return hf(t).get(e).next(s=>{if(s)return function(r){return{id:r.bundleId,createTime:Is(r.createTime),version:r.version}}(s)})}saveBundleMetadata(t,e){return hf(t).put(function(i){return{bundleId:i.id,createTime:ws(pe(i.createTime)),version:i.version}}(e))}getNamedQuery(t,e){return ff(t).get(e).next(s=>{if(s)return function(r){return{name:r.name,query:Vg(r.bundledQuery),readTime:Is(r.readTime)}}(s)})}saveNamedQuery(t,e){return ff(t).put(function(i){return{name:i.name,readTime:ws(pe(i.readTime)),bundledQuery:i.bundledQuery}}(e))}}function hf(n){return Jt(n,"bundles")}function ff(n){return Jt(n,"namedQueries")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ba{constructor(t,e){this.serializer=t,this.userId=e}static lt(t,e){const s=e.uid||"";return new Ba(t,s)}getOverlay(t,e){return Ji(t).get(uf(this.userId,e)).next(s=>s?Lc(this.serializer,s):null)}getOverlays(t,e){const s=je();return P.forEach(e,i=>this.getOverlay(t,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(t,e,s){const i=[];return s.forEach((r,o)=>{const a=new lu(e,o);i.push(this.ht(t,a))}),P.waitFor(i)}removeOverlaysForBatchId(t,e,s){const i=new Set;e.forEach(o=>i.add(fe(o.getCollectionPath())));const r=[];return i.forEach(o=>{const a=IDBKeyRange.bound([this.userId,o,s],[this.userId,o,s+1],!1,!0);r.push(Ji(t).j("collectionPathOverlayIndex",a))}),P.waitFor(r)}getOverlaysForCollection(t,e,s){const i=je(),r=fe(e),o=IDBKeyRange.bound([this.userId,r,s],[this.userId,r,Number.POSITIVE_INFINITY],!0);return Ji(t).U("collectionPathOverlayIndex",o).next(a=>{for(const l of a){const u=Lc(this.serializer,l);i.set(u.getKey(),u)}return i})}getOverlaysForCollectionGroup(t,e,s,i){const r=je();let o;const a=IDBKeyRange.bound([this.userId,e,s],[this.userId,e,Number.POSITIVE_INFINITY],!0);return Ji(t).J({index:"collectionGroupOverlayIndex",range:a},(l,u,h)=>{const p=Lc(this.serializer,u);r.size()<i||p.largestBatchId===o?(r.set(p.getKey(),p),o=p.largestBatchId):h.done()}).next(()=>r)}ht(t,e){return Ji(t).put(function(i,r,o){const[a,l,u]=uf(r,o.mutation.key);return{userId:r,collectionPath:l,documentId:u,collectionGroup:o.mutation.key.getCollectionGroup(),largestBatchId:o.largestBatchId,overlayMutation:da(i.ct,o.mutation)}}(this.serializer,this.userId,e))}}function Ji(n){return Jt(n,"documentOverlays")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class os{constructor(){}Pt(t,e){this.It(t,e),e.Tt()}It(t,e){if("nullValue"in t)this.Et(e,5);else if("booleanValue"in t)this.Et(e,10),e.dt(t.booleanValue?1:0);else if("integerValue"in t)this.Et(e,15),e.dt(xt(t.integerValue));else if("doubleValue"in t){const s=xt(t.doubleValue);isNaN(s)?this.Et(e,13):(this.Et(e,15),Pr(s)?e.dt(0):e.dt(s))}else if("timestampValue"in t){let s=t.timestampValue;this.Et(e,20),typeof s=="string"&&(s=ln(s)),e.At(`${s.seconds||""}`),e.dt(s.nanos||0)}else if("stringValue"in t)this.Rt(t.stringValue,e),this.Vt(e);else if("bytesValue"in t)this.Et(e,30),e.ft(qn(t.bytesValue)),this.Vt(e);else if("referenceValue"in t)this.gt(t.referenceValue,e);else if("geoPointValue"in t){const s=t.geoPointValue;this.Et(e,45),e.dt(s.latitude||0),e.dt(s.longitude||0)}else"mapValue"in t?Gm(t)?this.Et(e,Number.MAX_SAFE_INTEGER):(this.yt(t.mapValue,e),this.Vt(e)):"arrayValue"in t?(this.wt(t.arrayValue,e),this.Vt(e)):G()}Rt(t,e){this.Et(e,25),this.St(t,e)}St(t,e){e.At(t)}yt(t,e){const s=t.fields||{};this.Et(e,55);for(const i of Object.keys(s))this.Rt(i,e),this.It(s[i],e)}wt(t,e){const s=t.values||[];this.Et(e,50);for(const i of s)this.It(i,e)}gt(t,e){this.Et(e,37),q.fromName(t).path.forEach(s=>{this.Et(e,60),this.St(s,e)})}Et(t,e){t.dt(e)}Vt(t){t.dt(2)}}os.bt=new os;function AT(n){if(n===0)return 8;let t=0;return!(n>>4)&&(t+=4,n<<=4),!(n>>6)&&(t+=2,n<<=2),!(n>>7)&&(t+=1),t}function pf(n){const t=64-function(s){let i=0;for(let r=0;r<8;++r){const o=AT(255&s[r]);if(i+=o,o!==8)break}return i}(n);return Math.ceil(t/8)}class ST{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Dt(t){const e=t[Symbol.iterator]();let s=e.next();for(;!s.done;)this.Ct(s.value),s=e.next();this.vt()}Ft(t){const e=t[Symbol.iterator]();let s=e.next();for(;!s.done;)this.Mt(s.value),s=e.next();this.xt()}Ot(t){for(const e of t){const s=e.charCodeAt(0);if(s<128)this.Ct(s);else if(s<2048)this.Ct(960|s>>>6),this.Ct(128|63&s);else if(e<"\uD800"||"\uDBFF"<e)this.Ct(480|s>>>12),this.Ct(128|63&s>>>6),this.Ct(128|63&s);else{const i=e.codePointAt(0);this.Ct(240|i>>>18),this.Ct(128|63&i>>>12),this.Ct(128|63&i>>>6),this.Ct(128|63&i)}}this.vt()}Nt(t){for(const e of t){const s=e.charCodeAt(0);if(s<128)this.Mt(s);else if(s<2048)this.Mt(960|s>>>6),this.Mt(128|63&s);else if(e<"\uD800"||"\uDBFF"<e)this.Mt(480|s>>>12),this.Mt(128|63&s>>>6),this.Mt(128|63&s);else{const i=e.codePointAt(0);this.Mt(240|i>>>18),this.Mt(128|63&i>>>12),this.Mt(128|63&i>>>6),this.Mt(128|63&i)}}this.xt()}Lt(t){const e=this.Bt(t),s=pf(e);this.kt(1+s),this.buffer[this.position++]=255&s;for(let i=e.length-s;i<e.length;++i)this.buffer[this.position++]=255&e[i]}qt(t){const e=this.Bt(t),s=pf(e);this.kt(1+s),this.buffer[this.position++]=~(255&s);for(let i=e.length-s;i<e.length;++i)this.buffer[this.position++]=~(255&e[i])}Qt(){this.Kt(255),this.Kt(255)}$t(){this.Ut(255),this.Ut(255)}reset(){this.position=0}seed(t){this.kt(t.length),this.buffer.set(t,this.position),this.position+=t.length}Wt(){return this.buffer.slice(0,this.position)}Bt(t){const e=function(r){const o=new DataView(new ArrayBuffer(8));return o.setFloat64(0,r,!1),new Uint8Array(o.buffer)}(t),s=(128&e[0])!=0;e[0]^=s?255:128;for(let i=1;i<e.length;++i)e[i]^=s?255:0;return e}Ct(t){const e=255&t;e===0?(this.Kt(0),this.Kt(255)):e===255?(this.Kt(255),this.Kt(0)):this.Kt(e)}Mt(t){const e=255&t;e===0?(this.Ut(0),this.Ut(255)):e===255?(this.Ut(255),this.Ut(0)):this.Ut(t)}vt(){this.Kt(0),this.Kt(1)}xt(){this.Ut(0),this.Ut(1)}Kt(t){this.kt(1),this.buffer[this.position++]=t}Ut(t){this.kt(1),this.buffer[this.position++]=~t}kt(t){const e=t+this.position;if(e<=this.buffer.length)return;let s=2*this.buffer.length;s<e&&(s=e);const i=new Uint8Array(s);i.set(this.buffer),this.buffer=i}}class kT{constructor(t){this.Gt=t}ft(t){this.Gt.Dt(t)}At(t){this.Gt.Ot(t)}dt(t){this.Gt.Lt(t)}Tt(){this.Gt.Qt()}}class RT{constructor(t){this.Gt=t}ft(t){this.Gt.Ft(t)}At(t){this.Gt.Nt(t)}dt(t){this.Gt.qt(t)}Tt(){this.Gt.$t()}}class Yi{constructor(){this.Gt=new ST,this.zt=new kT(this.Gt),this.jt=new RT(this.Gt)}seed(t){this.Gt.seed(t)}Ht(t){return t===0?this.zt:this.jt}Wt(){return this.Gt.Wt()}reset(){this.Gt.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class as{constructor(t,e,s,i){this.indexId=t,this.documentKey=e,this.arrayValue=s,this.directionalValue=i}Jt(){const t=this.directionalValue.length,e=t===0||this.directionalValue[t-1]===255?t+1:t,s=new Uint8Array(e);return s.set(this.directionalValue,0),e!==t?s.set([0],this.directionalValue.length):++s[s.length-1],new as(this.indexId,this.documentKey,this.arrayValue,s)}}function vn(n,t){let e=n.indexId-t.indexId;return e!==0?e:(e=mf(n.arrayValue,t.arrayValue),e!==0?e:(e=mf(n.directionalValue,t.directionalValue),e!==0?e:q.comparator(n.documentKey,t.documentKey)))}function mf(n,t){for(let e=0;e<n.length&&e<t.length;++e){const s=n[e]-t[e];if(s!==0)return s}return n.length-t.length}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gf{constructor(t){this.Yt=new wt((e,s)=>Ct.comparator(e.field,s.field)),this.collectionId=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment(),this.Zt=t.orderBy,this.Xt=[];for(const e of t.filters){const s=e;s.isInequality()?this.Yt=this.Yt.add(s):this.Xt.push(s)}}get en(){return this.Yt.size>1}tn(t){if(X(t.collectionGroup===this.collectionId),this.en)return!1;const e=al(t);if(e!==void 0&&!this.nn(e))return!1;const s=ss(t);let i=new Set,r=0,o=0;for(;r<s.length&&this.nn(s[r]);++r)i=i.add(s[r].fieldPath.canonicalString());if(r===s.length)return!0;if(this.Yt.size>0){const a=this.Yt.getIterator().getNext();if(!i.has(a.field.canonicalString())){const l=s[r];if(!this.rn(a,l)||!this.sn(this.Zt[o++],l))return!1}++r}for(;r<s.length;++r){const a=s[r];if(o>=this.Zt.length||!this.sn(this.Zt[o++],a))return!1}return!0}on(){if(this.en)return null;let t=new wt(Ct.comparator);const e=[];for(const s of this.Xt)if(!s.field.isKeyField())if(s.op==="array-contains"||s.op==="array-contains-any")e.push(new qo(s.field,2));else{if(t.has(s.field))continue;t=t.add(s.field),e.push(new qo(s.field,0))}for(const s of this.Zt)s.field.isKeyField()||t.has(s.field)||(t=t.add(s.field),e.push(new qo(s.field,s.dir==="asc"?0:1)));return new oa(oa.UNKNOWN_ID,this.collectionId,e,Rr.empty())}nn(t){for(const e of this.Xt)if(this.rn(e,t))return!0;return!1}rn(t,e){if(t===void 0||!t.field.isEqual(e.fieldPath))return!1;const s=t.op==="array-contains"||t.op==="array-contains-any";return e.kind===2===s}sn(t,e){return!!t.field.isEqual(e.fieldPath)&&(e.kind===0&&t.dir==="asc"||e.kind===1&&t.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ng(n){var t,e;if(X(n instanceof at||n instanceof bt),n instanceof at){if(n instanceof Zm){const i=((e=(t=n.value.arrayValue)===null||t===void 0?void 0:t.values)===null||e===void 0?void 0:e.map(r=>at.create(n.field,"==",r)))||[];return bt.create(i,"or")}return n}const s=n.filters.map(i=>Ng(i));return bt.create(s,n.op)}function PT(n){if(n.getFilters().length===0)return[];const t=Il(Ng(n));return X(xg(t)),bl(t)||wl(t)?[t]:t.getFilters()}function bl(n){return n instanceof at}function wl(n){return n instanceof bt&&ru(n)}function xg(n){return bl(n)||wl(n)||function(e){if(e instanceof bt&&dl(e)){for(const s of e.getFilters())if(!bl(s)&&!wl(s))return!1;return!0}return!1}(n)}function Il(n){if(X(n instanceof at||n instanceof bt),n instanceof at)return n;if(n.filters.length===1)return Il(n.filters[0]);const t=n.filters.map(s=>Il(s));let e=bt.create(t,n.op);return e=fa(e),xg(e)?e:(X(e instanceof bt),X(li(e)),X(e.filters.length>1),e.filters.reduce((s,i)=>hu(s,i)))}function hu(n,t){let e;return X(n instanceof at||n instanceof bt),X(t instanceof at||t instanceof bt),e=n instanceof at?t instanceof at?function(i,r){return bt.create([i,r],"and")}(n,t):yf(n,t):t instanceof at?yf(t,n):function(i,r){if(X(i.filters.length>0&&r.filters.length>0),li(i)&&li(r))return Jm(i,r.getFilters());const o=dl(i)?i:r,a=dl(i)?r:i,l=o.filters.map(u=>hu(u,a));return bt.create(l,"or")}(n,t),fa(e)}function yf(n,t){if(li(t))return Jm(t,n.getFilters());{const e=t.filters.map(s=>hu(n,s));return bt.create(e,"or")}}function fa(n){if(X(n instanceof at||n instanceof bt),n instanceof at)return n;const t=n.getFilters();if(t.length===1)return fa(t[0]);if(Hm(n))return n;const e=t.map(i=>fa(i)),s=[];return e.forEach(i=>{i instanceof at?s.push(i):i instanceof bt&&(i.op===n.op?s.push(...i.filters):s.push(i))}),s.length===1?s[0]:bt.create(s,n.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CT{constructor(){this._n=new fu}addToCollectionParentIndex(t,e){return this._n.add(e),P.resolve()}getCollectionParents(t,e){return P.resolve(this._n.getEntries(e))}addFieldIndex(t,e){return P.resolve()}deleteFieldIndex(t,e){return P.resolve()}deleteAllFieldIndexes(t){return P.resolve()}createTargetIndexes(t,e){return P.resolve()}getDocumentsMatchingTarget(t,e){return P.resolve(null)}getIndexType(t,e){return P.resolve(0)}getFieldIndexes(t,e){return P.resolve([])}getNextCollectionGroupToUpdate(t){return P.resolve(null)}getMinOffset(t,e){return P.resolve(Se.min())}getMinOffsetFromCollectionGroup(t,e){return P.resolve(Se.min())}updateCollectionGroup(t,e,s){return P.resolve()}updateIndexEntries(t,e){return P.resolve()}}class fu{constructor(){this.index={}}add(t){const e=t.lastSegment(),s=t.popLast(),i=this.index[e]||new wt(vt.comparator),r=!i.has(s);return this.index[e]=i.add(s),r}has(t){const e=t.lastSegment(),s=t.popLast(),i=this.index[e];return i&&i.has(s)}getEntries(t){return(this.index[t]||new wt(vt.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ro=new Uint8Array(0);class DT{constructor(t,e){this.databaseId=e,this.an=new fu,this.un=new Hn(s=>bs(s),(s,i)=>Qr(s,i)),this.uid=t.uid||""}addToCollectionParentIndex(t,e){if(!this.an.has(e)){const s=e.lastSegment(),i=e.popLast();t.addOnCommittedListener(()=>{this.an.add(e)});const r={collectionId:s,parent:fe(i)};return vf(t).put(r)}return P.resolve()}getCollectionParents(t,e){const s=[],i=IDBKeyRange.bound([e,""],[Dm(e),""],!1,!0);return vf(t).U(i).next(r=>{for(const o of r){if(o.collectionId!==e)break;s.push(Be(o.parent))}return s})}addFieldIndex(t,e){const s=Xi(t),i=function(a){return{indexId:a.indexId,collectionGroup:a.collectionGroup,fields:a.fields.map(l=>[l.fieldPath.canonicalString(),l.kind])}}(e);delete i.indexId;const r=s.add(i);if(e.indexState){const o=Ms(t);return r.next(a=>{o.put(df(a,this.uid,e.indexState.sequenceNumber,e.indexState.offset))})}return r.next()}deleteFieldIndex(t,e){const s=Xi(t),i=Ms(t),r=Os(t);return s.delete(e.indexId).next(()=>i.delete(IDBKeyRange.bound([e.indexId],[e.indexId+1],!1,!0))).next(()=>r.delete(IDBKeyRange.bound([e.indexId],[e.indexId+1],!1,!0)))}deleteAllFieldIndexes(t){const e=Xi(t),s=Os(t),i=Ms(t);return e.j().next(()=>s.j()).next(()=>i.j())}createTargetIndexes(t,e){return P.forEach(this.cn(e),s=>this.getIndexType(t,s).next(i=>{if(i===0||i===1){const r=new gf(s).on();if(r!=null)return this.addFieldIndex(t,r)}}))}getDocumentsMatchingTarget(t,e){const s=Os(t);let i=!0;const r=new Map;return P.forEach(this.cn(e),o=>this.ln(t,o).next(a=>{i&&(i=!!a),r.set(o,a)})).next(()=>{if(i){let o=rt();const a=[];return P.forEach(r,(l,u)=>{N("IndexedDbIndexManager",`Using index ${function(K){return`id=${K.indexId}|cg=${K.collectionGroup}|f=${K.fields.map(st=>`${st.fieldPath}:${st.kind}`).join(",")}`}(l)} to execute ${bs(e)}`);const h=function(K,st){const x=al(st);if(x===void 0)return null;for(const L of la(K,x.fieldPath))switch(L.op){case"array-contains-any":return L.value.arrayValue.values||[];case"array-contains":return[L.value]}return null}(u,l),p=function(K,st){const x=new Map;for(const L of ss(st))for(const b of la(K,L.fieldPath))switch(b.op){case"==":case"in":x.set(L.fieldPath.canonicalString(),b.value);break;case"not-in":case"!=":return x.set(L.fieldPath.canonicalString(),b.value),Array.from(x.values())}return null}(u,l),m=function(K,st){const x=[];let L=!0;for(const b of ss(st)){const y=b.kind===0?Qh(K,b.fieldPath,K.startAt):Jh(K,b.fieldPath,K.startAt);x.push(y.value),L&&(L=y.inclusive)}return new ci(x,L)}(u,l),I=function(K,st){const x=[];let L=!0;for(const b of ss(st)){const y=b.kind===0?Jh(K,b.fieldPath,K.endAt):Qh(K,b.fieldPath,K.endAt);x.push(y.value),L&&(L=y.inclusive)}return new ci(x,L)}(u,l),E=this.hn(l,u,m),$=this.hn(l,u,I),R=this.Pn(l,u,p),B=this.In(l.indexId,h,E,m.inclusive,$,I.inclusive,R);return P.forEach(B,H=>s.G(H,e.limit).next(K=>{K.forEach(st=>{const x=q.fromSegments(st.documentKey);o.has(x)||(o=o.add(x),a.push(x))})}))}).next(()=>a)}return P.resolve(null)})}cn(t){let e=this.un.get(t);return e||(t.filters.length===0?e=[t]:e=PT(bt.create(t.filters,"and")).map(s=>fl(t.path,t.collectionGroup,t.orderBy,s.getFilters(),t.limit,t.startAt,t.endAt)),this.un.set(t,e),e)}In(t,e,s,i,r,o,a){const l=(e!=null?e.length:1)*Math.max(s.length,r.length),u=l/(e!=null?e.length:1),h=[];for(let p=0;p<l;++p){const m=e?this.Tn(e[p/u]):Ro,I=this.En(t,m,s[p%u],i),E=this.dn(t,m,r[p%u],o),$=a.map(R=>this.En(t,m,R,!0));h.push(...this.createRange(I,E,$))}return h}En(t,e,s,i){const r=new as(t,q.empty(),e,s);return i?r:r.Jt()}dn(t,e,s,i){const r=new as(t,q.empty(),e,s);return i?r.Jt():r}ln(t,e){const s=new gf(e),i=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment();return this.getFieldIndexes(t,i).next(r=>{let o=null;for(const a of r)s.tn(a)&&(!o||a.fields.length>o.fields.length)&&(o=a);return o})}getIndexType(t,e){let s=2;const i=this.cn(e);return P.forEach(i,r=>this.ln(t,r).next(o=>{o?s!==0&&o.fields.length<function(l){let u=new wt(Ct.comparator),h=!1;for(const p of l.filters)for(const m of p.getFlattenedFilters())m.field.isKeyField()||(m.op==="array-contains"||m.op==="array-contains-any"?h=!0:u=u.add(m.field));for(const p of l.orderBy)p.field.isKeyField()||(u=u.add(p.field));return u.size+(h?1:0)}(r)&&(s=1):s=0})).next(()=>function(o){return o.limit!==null}(e)&&i.length>1&&s===2?1:s)}An(t,e){const s=new Yi;for(const i of ss(t)){const r=e.data.field(i.fieldPath);if(r==null)return null;const o=s.Ht(i.kind);os.bt.Pt(r,o)}return s.Wt()}Tn(t){const e=new Yi;return os.bt.Pt(t,e.Ht(0)),e.Wt()}Rn(t,e){const s=new Yi;return os.bt.Pt($r(this.databaseId,e),s.Ht(function(r){const o=ss(r);return o.length===0?0:o[o.length-1].kind}(t))),s.Wt()}Pn(t,e,s){if(s===null)return[];let i=[];i.push(new Yi);let r=0;for(const o of ss(t)){const a=s[r++];for(const l of i)if(this.Vn(e,o.fieldPath)&&Vr(a))i=this.mn(i,o,a);else{const u=l.Ht(o.kind);os.bt.Pt(a,u)}}return this.fn(i)}hn(t,e,s){return this.Pn(t,e,s.position)}fn(t){const e=[];for(let s=0;s<t.length;++s)e[s]=t[s].Wt();return e}mn(t,e,s){const i=[...t],r=[];for(const o of s.arrayValue.values||[])for(const a of i){const l=new Yi;l.seed(a.Wt()),os.bt.Pt(o,l.Ht(e.kind)),r.push(l)}return r}Vn(t,e){return!!t.filters.find(s=>s instanceof at&&s.field.isEqual(e)&&(s.op==="in"||s.op==="not-in"))}getFieldIndexes(t,e){const s=Xi(t),i=Ms(t);return(e?s.U("collectionGroupIndex",IDBKeyRange.bound(e,e)):s.U()).next(r=>{const o=[];return P.forEach(r,a=>i.get([a.indexId,this.uid]).next(l=>{o.push(function(h,p){const m=p?new Rr(p.sequenceNumber,new Se(Is(p.readTime),new q(Be(p.documentKey)),p.largestBatchId)):Rr.empty(),I=h.fields.map(([E,$])=>new qo(Ct.fromServerFormat(E),$));return new oa(h.indexId,h.collectionGroup,I,m)}(a,l))})).next(()=>o)})}getNextCollectionGroupToUpdate(t){return this.getFieldIndexes(t).next(e=>e.length===0?null:(e.sort((s,i)=>{const r=s.indexState.sequenceNumber-i.indexState.sequenceNumber;return r!==0?r:nt(s.collectionGroup,i.collectionGroup)}),e[0].collectionGroup))}updateCollectionGroup(t,e,s){const i=Xi(t),r=Ms(t);return this.gn(t).next(o=>i.U("collectionGroupIndex",IDBKeyRange.bound(e,e)).next(a=>P.forEach(a,l=>r.put(df(l.indexId,this.uid,o,s)))))}updateIndexEntries(t,e){const s=new Map;return P.forEach(e,(i,r)=>{const o=s.get(i.collectionGroup);return(o?P.resolve(o):this.getFieldIndexes(t,i.collectionGroup)).next(a=>(s.set(i.collectionGroup,a),P.forEach(a,l=>this.pn(t,i,l).next(u=>{const h=this.yn(r,l);return u.isEqual(h)?P.resolve():this.wn(t,r,l,u,h)}))))})}Sn(t,e,s,i){return Os(t).put({indexId:i.indexId,uid:this.uid,arrayValue:i.arrayValue,directionalValue:i.directionalValue,orderedDocumentKey:this.Rn(s,e.key),documentKey:e.key.path.toArray()})}bn(t,e,s,i){return Os(t).delete([i.indexId,this.uid,i.arrayValue,i.directionalValue,this.Rn(s,e.key),e.key.path.toArray()])}pn(t,e,s){const i=Os(t);let r=new wt(vn);return i.J({index:"documentKeyIndex",range:IDBKeyRange.only([s.indexId,this.uid,this.Rn(s,e)])},(o,a)=>{r=r.add(new as(s.indexId,e,a.arrayValue,a.directionalValue))}).next(()=>r)}yn(t,e){let s=new wt(vn);const i=this.An(e,t);if(i==null)return s;const r=al(e);if(r!=null){const o=t.data.field(r.fieldPath);if(Vr(o))for(const a of o.arrayValue.values||[])s=s.add(new as(e.indexId,t.key,this.Tn(a),i))}else s=s.add(new as(e.indexId,t.key,Ro,i));return s}wn(t,e,s,i,r){N("IndexedDbIndexManager","Updating index entries for document '%s'",e.key);const o=[];return function(l,u,h,p,m){const I=l.getIterator(),E=u.getIterator();let $=xs(I),R=xs(E);for(;$||R;){let B=!1,H=!1;if($&&R){const K=h($,R);K<0?H=!0:K>0&&(B=!0)}else $!=null?H=!0:B=!0;B?(p(R),R=xs(E)):H?(m($),$=xs(I)):($=xs(I),R=xs(E))}}(i,r,vn,a=>{o.push(this.Sn(t,e,s,a))},a=>{o.push(this.bn(t,e,s,a))}),P.waitFor(o)}gn(t){let e=1;return Ms(t).J({index:"sequenceNumberIndex",reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(s,i,r)=>{r.done(),e=i.sequenceNumber+1}).next(()=>e)}createRange(t,e,s){s=s.sort((o,a)=>vn(o,a)).filter((o,a,l)=>!a||vn(o,l[a-1])!==0);const i=[];i.push(t);for(const o of s){const a=vn(o,t),l=vn(o,e);if(a===0)i[0]=t.Jt();else if(a>0&&l<0)i.push(o),i.push(o.Jt());else if(l>0)break}i.push(e);const r=[];for(let o=0;o<i.length;o+=2){if(this.Dn(i[o],i[o+1]))return[];const a=[i[o].indexId,this.uid,i[o].arrayValue,i[o].directionalValue,Ro,[]],l=[i[o+1].indexId,this.uid,i[o+1].arrayValue,i[o+1].directionalValue,Ro,[]];r.push(IDBKeyRange.bound(a,l))}return r}Dn(t,e){return vn(t,e)>0}getMinOffsetFromCollectionGroup(t,e){return this.getFieldIndexes(t,e).next(_f)}getMinOffset(t,e){return P.mapArray(this.cn(e),s=>this.ln(t,s).next(i=>i||G())).next(_f)}}function vf(n){return Jt(n,"collectionParents")}function Os(n){return Jt(n,"indexEntries")}function Xi(n){return Jt(n,"indexConfiguration")}function Ms(n){return Jt(n,"indexState")}function _f(n){X(n.length!==0);let t=n[0].indexState.offset,e=t.largestBatchId;for(let s=1;s<n.length;s++){const i=n[s].indexState.offset;eu(i,t)<0&&(t=i),e<i.largestBatchId&&(e=i.largestBatchId)}return new Se(t.readTime,t.documentKey,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bf={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class ve{constructor(t,e,s){this.cacheSizeCollectionThreshold=t,this.percentileToCollect=e,this.maximumSequenceNumbersToCollect=s}static withCacheSize(t){return new ve(t,ve.DEFAULT_COLLECTION_PERCENTILE,ve.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Og(n,t,e){const s=n.store("mutations"),i=n.store("documentMutations"),r=[],o=IDBKeyRange.only(e.batchId);let a=0;const l=s.J({range:o},(h,p,m)=>(a++,m.delete()));r.push(l.next(()=>{X(a===1)}));const u=[];for(const h of e.mutations){const p=Lm(t,h.key.path,e.batchId);r.push(i.delete(p)),u.push(h.key)}return P.waitFor(r).next(()=>u)}function pa(n){if(!n)return 0;let t;if(n.document)t=n.document;else if(n.unknownDocument)t=n.unknownDocument;else{if(!n.noDocument)throw G();t=n.noDocument}return JSON.stringify(t).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ve.DEFAULT_COLLECTION_PERCENTILE=10,ve.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,ve.DEFAULT=new ve(41943040,ve.DEFAULT_COLLECTION_PERCENTILE,ve.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),ve.DISABLED=new ve(-1,0,0);class ja{constructor(t,e,s,i){this.userId=t,this.serializer=e,this.indexManager=s,this.referenceDelegate=i,this.Cn={}}static lt(t,e,s,i){X(t.uid!=="");const r=t.isAuthenticated()?t.uid:"";return new ja(r,e,s,i)}checkEmpty(t){let e=!0;const s=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return _n(t).J({index:"userMutationsIndex",range:s},(i,r,o)=>{e=!1,o.done()}).next(()=>e)}addMutationBatch(t,e,s,i){const r=Ws(t),o=_n(t);return o.add({}).next(a=>{X(typeof a=="number");const l=new au(a,e,s,i),u=function(I,E,$){const R=$.baseMutations.map(H=>da(I.ct,H)),B=$.mutations.map(H=>da(I.ct,H));return{userId:E,batchId:$.batchId,localWriteTimeMs:$.localWriteTime.toMillis(),baseMutations:R,mutations:B}}(this.serializer,this.userId,l),h=[];let p=new wt((m,I)=>nt(m.canonicalString(),I.canonicalString()));for(const m of i){const I=Lm(this.userId,m.key.path,a);p=p.add(m.key.path.popLast()),h.push(o.put(u)),h.push(r.put(I,gE))}return p.forEach(m=>{h.push(this.indexManager.addToCollectionParentIndex(t,m))}),t.addOnCommittedListener(()=>{this.Cn[a]=l.keys()}),P.waitFor(h).next(()=>l)})}lookupMutationBatch(t,e){return _n(t).get(e).next(s=>s?(X(s.userId===this.userId),rs(this.serializer,s)):null)}vn(t,e){return this.Cn[e]?P.resolve(this.Cn[e]):this.lookupMutationBatch(t,e).next(s=>{if(s){const i=s.keys();return this.Cn[e]=i,i}return null})}getNextMutationBatchAfterBatchId(t,e){const s=e+1,i=IDBKeyRange.lowerBound([this.userId,s]);let r=null;return _n(t).J({index:"userMutationsIndex",range:i},(o,a,l)=>{a.userId===this.userId&&(X(a.batchId>=s),r=rs(this.serializer,a)),l.done()}).next(()=>r)}getHighestUnacknowledgedBatchId(t){const e=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let s=-1;return _n(t).J({index:"userMutationsIndex",range:e,reverse:!0},(i,r,o)=>{s=r.batchId,o.done()}).next(()=>s)}getAllMutationBatches(t){const e=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return _n(t).U("userMutationsIndex",e).next(s=>s.map(i=>rs(this.serializer,i)))}getAllMutationBatchesAffectingDocumentKey(t,e){const s=Bo(this.userId,e.path),i=IDBKeyRange.lowerBound(s),r=[];return Ws(t).J({range:i},(o,a,l)=>{const[u,h,p]=o,m=Be(h);if(u===this.userId&&e.path.isEqual(m))return _n(t).get(p).next(I=>{if(!I)throw G();X(I.userId===this.userId),r.push(rs(this.serializer,I))});l.done()}).next(()=>r)}getAllMutationBatchesAffectingDocumentKeys(t,e){let s=new wt(nt);const i=[];return e.forEach(r=>{const o=Bo(this.userId,r.path),a=IDBKeyRange.lowerBound(o),l=Ws(t).J({range:a},(u,h,p)=>{const[m,I,E]=u,$=Be(I);m===this.userId&&r.path.isEqual($)?s=s.add(E):p.done()});i.push(l)}),P.waitFor(i).next(()=>this.Fn(t,s))}getAllMutationBatchesAffectingQuery(t,e){const s=e.path,i=s.length+1,r=Bo(this.userId,s),o=IDBKeyRange.lowerBound(r);let a=new wt(nt);return Ws(t).J({range:o},(l,u,h)=>{const[p,m,I]=l,E=Be(m);p===this.userId&&s.isPrefixOf(E)?E.length===i&&(a=a.add(I)):h.done()}).next(()=>this.Fn(t,a))}Fn(t,e){const s=[],i=[];return e.forEach(r=>{i.push(_n(t).get(r).next(o=>{if(o===null)throw G();X(o.userId===this.userId),s.push(rs(this.serializer,o))}))}),P.waitFor(i).next(()=>s)}removeMutationBatch(t,e){return Og(t._e,this.userId,e).next(s=>(t.addOnCommittedListener(()=>{this.Mn(e.batchId)}),P.forEach(s,i=>this.referenceDelegate.markPotentiallyOrphaned(t,i))))}Mn(t){delete this.Cn[t]}performConsistencyCheck(t){return this.checkEmpty(t).next(e=>{if(!e)return P.resolve();const s=IDBKeyRange.lowerBound(function(o){return[o]}(this.userId)),i=[];return Ws(t).J({range:s},(r,o,a)=>{if(r[0]===this.userId){const l=Be(r[1]);i.push(l)}else a.done()}).next(()=>{X(i.length===0)})})}containsKey(t,e){return Mg(t,this.userId,e)}xn(t){return Lg(t).get(this.userId).next(e=>e||{userId:this.userId,lastAcknowledgedBatchId:-1,lastStreamToken:""})}}function Mg(n,t,e){const s=Bo(t,e.path),i=s[1],r=IDBKeyRange.lowerBound(s);let o=!1;return Ws(n).J({range:r,H:!0},(a,l,u)=>{const[h,p,m]=a;h===t&&p===i&&(o=!0),u.done()}).next(()=>o)}function _n(n){return Jt(n,"mutations")}function Ws(n){return Jt(n,"documentMutations")}function Lg(n){return Jt(n,"mutationQueues")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Es{constructor(t){this.On=t}next(){return this.On+=2,this.On}static Nn(){return new Es(0)}static Ln(){return new Es(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $T{constructor(t,e){this.referenceDelegate=t,this.serializer=e}allocateTargetId(t){return this.Bn(t).next(e=>{const s=new Es(e.highestTargetId);return e.highestTargetId=s.next(),this.kn(t,e).next(()=>e.highestTargetId)})}getLastRemoteSnapshotVersion(t){return this.Bn(t).next(e=>Z.fromTimestamp(new Dt(e.lastRemoteSnapshotVersion.seconds,e.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(t){return this.Bn(t).next(e=>e.highestListenSequenceNumber)}setTargetsMetadata(t,e,s){return this.Bn(t).next(i=>(i.highestListenSequenceNumber=e,s&&(i.lastRemoteSnapshotVersion=s.toTimestamp()),e>i.highestListenSequenceNumber&&(i.highestListenSequenceNumber=e),this.kn(t,i)))}addTargetData(t,e){return this.qn(t,e).next(()=>this.Bn(t).next(s=>(s.targetCount+=1,this.Qn(e,s),this.kn(t,s))))}updateTargetData(t,e){return this.qn(t,e)}removeTargetData(t,e){return this.removeMatchingKeysForTargetId(t,e.targetId).next(()=>Ls(t).delete(e.targetId)).next(()=>this.Bn(t)).next(s=>(X(s.targetCount>0),s.targetCount-=1,this.kn(t,s)))}removeTargets(t,e,s){let i=0;const r=[];return Ls(t).J((o,a)=>{const l=lr(a);l.sequenceNumber<=e&&s.get(l.targetId)===null&&(i++,r.push(this.removeTargetData(t,l)))}).next(()=>P.waitFor(r)).next(()=>i)}forEachTarget(t,e){return Ls(t).J((s,i)=>{const r=lr(i);e(r)})}Bn(t){return wf(t).get("targetGlobalKey").next(e=>(X(e!==null),e))}kn(t,e){return wf(t).put("targetGlobalKey",e)}qn(t,e){return Ls(t).put($g(this.serializer,e))}Qn(t,e){let s=!1;return t.targetId>e.highestTargetId&&(e.highestTargetId=t.targetId,s=!0),t.sequenceNumber>e.highestListenSequenceNumber&&(e.highestListenSequenceNumber=t.sequenceNumber,s=!0),s}getTargetCount(t){return this.Bn(t).next(e=>e.targetCount)}getTargetData(t,e){const s=bs(e),i=IDBKeyRange.bound([s,Number.NEGATIVE_INFINITY],[s,Number.POSITIVE_INFINITY]);let r=null;return Ls(t).J({range:i,index:"queryTargetsIndex"},(o,a,l)=>{const u=lr(a);Qr(e,u.target)&&(r=u,l.done())}).next(()=>r)}addMatchingKeys(t,e,s){const i=[],r=kn(t);return e.forEach(o=>{const a=fe(o.path);i.push(r.put({targetId:s,path:a})),i.push(this.referenceDelegate.addReference(t,s,o))}),P.waitFor(i)}removeMatchingKeys(t,e,s){const i=kn(t);return P.forEach(e,r=>{const o=fe(r.path);return P.waitFor([i.delete([s,o]),this.referenceDelegate.removeReference(t,s,r)])})}removeMatchingKeysForTargetId(t,e){const s=kn(t),i=IDBKeyRange.bound([e],[e+1],!1,!0);return s.delete(i)}getMatchingKeysForTargetId(t,e){const s=IDBKeyRange.bound([e],[e+1],!1,!0),i=kn(t);let r=rt();return i.J({range:s,H:!0},(o,a,l)=>{const u=Be(o[1]),h=new q(u);r=r.add(h)}).next(()=>r)}containsKey(t,e){const s=fe(e.path),i=IDBKeyRange.bound([s],[Dm(s)],!1,!0);let r=0;return kn(t).J({index:"documentTargetsIndex",H:!0,range:i},([o,a],l,u)=>{o!==0&&(r++,u.done())}).next(()=>r>0)}ot(t,e){return Ls(t).get(e).next(s=>s?lr(s):null)}}function Ls(n){return Jt(n,"targets")}function wf(n){return Jt(n,"targetGlobal")}function kn(n){return Jt(n,"targetDocuments")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function If([n,t],[e,s]){const i=nt(n,e);return i===0?nt(t,s):i}class VT{constructor(t){this.Kn=t,this.buffer=new wt(If),this.$n=0}Un(){return++this.$n}Wn(t){const e=[t,this.Un()];if(this.buffer.size<this.Kn)this.buffer=this.buffer.add(e);else{const s=this.buffer.last();If(e,s)<0&&(this.buffer=this.buffer.delete(s).add(e))}}get maxValue(){return this.buffer.last()[0]}}class NT{constructor(t,e,s){this.garbageCollector=t,this.asyncQueue=e,this.localStore=s,this.Gn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.zn(6e4)}stop(){this.Gn&&(this.Gn.cancel(),this.Gn=null)}get started(){return this.Gn!==null}zn(t){N("LruGarbageCollector",`Garbage collection scheduled in ${t}ms`),this.Gn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",t,async()=>{this.Gn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(e){Wn(e)?N("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",e):await Kn(e)}await this.zn(3e5)})}}class xT{constructor(t,e){this.jn=t,this.params=e}calculateTargetCount(t,e){return this.jn.Hn(t).next(s=>Math.floor(e/100*s))}nthSequenceNumber(t,e){if(e===0)return P.resolve(_e.oe);const s=new VT(e);return this.jn.forEachTarget(t,i=>s.Wn(i.sequenceNumber)).next(()=>this.jn.Jn(t,i=>s.Wn(i))).next(()=>s.maxValue)}removeTargets(t,e,s){return this.jn.removeTargets(t,e,s)}removeOrphanedDocuments(t,e){return this.jn.removeOrphanedDocuments(t,e)}collect(t,e){return this.params.cacheSizeCollectionThreshold===-1?(N("LruGarbageCollector","Garbage collection skipped; disabled"),P.resolve(bf)):this.getCacheSize(t).next(s=>s<this.params.cacheSizeCollectionThreshold?(N("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),bf):this.Yn(t,e))}getCacheSize(t){return this.jn.getCacheSize(t)}Yn(t,e){let s,i,r,o,a,l,u;const h=Date.now();return this.calculateTargetCount(t,this.params.percentileToCollect).next(p=>(p>this.params.maximumSequenceNumbersToCollect?(N("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${p}`),i=this.params.maximumSequenceNumbersToCollect):i=p,o=Date.now(),this.nthSequenceNumber(t,i))).next(p=>(s=p,a=Date.now(),this.removeTargets(t,s,e))).next(p=>(r=p,l=Date.now(),this.removeOrphanedDocuments(t,s))).next(p=>(u=Date.now(),js()<=ot.DEBUG&&N("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-h}ms
	Determined least recently used ${i} in `+(a-o)+`ms
	Removed ${r} targets in `+(l-a)+`ms
	Removed ${p} documents in `+(u-l)+`ms
Total Duration: ${u-h}ms`),P.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:r,documentsRemoved:p})))}}function OT(n,t){return new xT(n,t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class MT{constructor(t,e){this.db=t,this.garbageCollector=OT(this,e)}Hn(t){const e=this.Zn(t);return this.db.getTargetCache().getTargetCount(t).next(s=>e.next(i=>s+i))}Zn(t){let e=0;return this.Jn(t,s=>{e++}).next(()=>e)}forEachTarget(t,e){return this.db.getTargetCache().forEachTarget(t,e)}Jn(t,e){return this.Xn(t,(s,i)=>e(i))}addReference(t,e,s){return Po(t,s)}removeReference(t,e,s){return Po(t,s)}removeTargets(t,e,s){return this.db.getTargetCache().removeTargets(t,e,s)}markPotentiallyOrphaned(t,e){return Po(t,e)}er(t,e){return function(i,r){let o=!1;return Lg(i).Y(a=>Mg(i,a,r).next(l=>(l&&(o=!0),P.resolve(!l)))).next(()=>o)}(t,e)}removeOrphanedDocuments(t,e){const s=this.db.getRemoteDocumentCache().newChangeBuffer(),i=[];let r=0;return this.Xn(t,(o,a)=>{if(a<=e){const l=this.er(t,o).next(u=>{if(!u)return r++,s.getEntry(t,o).next(()=>(s.removeEntry(o,Z.min()),kn(t).delete(function(p){return[0,fe(p.path)]}(o))))});i.push(l)}}).next(()=>P.waitFor(i)).next(()=>s.apply(t)).next(()=>r)}removeTarget(t,e){const s=e.withSequenceNumber(t.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(t,s)}updateLimboDocument(t,e){return Po(t,e)}Xn(t,e){const s=kn(t);let i,r=_e.oe;return s.J({index:"documentTargetsIndex"},([o,a],{path:l,sequenceNumber:u})=>{o===0?(r!==_e.oe&&e(new q(Be(i)),r),r=u,i=l):r=_e.oe}).next(()=>{r!==_e.oe&&e(new q(Be(i)),r)})}getCacheSize(t){return this.db.getRemoteDocumentCache().getSize(t)}}function Po(n,t){return kn(n).put(function(s,i){return{targetId:0,path:fe(s.path),sequenceNumber:i}}(t,n.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fg{constructor(){this.changes=new Hn(t=>t.toString(),(t,e)=>t.isEqual(e)),this.changesApplied=!1}addEntry(t){this.assertNotApplied(),this.changes.set(t.key,t)}removeEntry(t,e){this.assertNotApplied(),this.changes.set(t,Ot.newInvalidDocument(t).setReadTime(e))}getEntry(t,e){this.assertNotApplied();const s=this.changes.get(e);return s!==void 0?P.resolve(s):this.getFromCache(t,e)}getEntries(t,e){return this.getAllFromCache(t,e)}apply(t){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(t)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class LT{constructor(t){this.serializer=t}setIndexManager(t){this.indexManager=t}addEntry(t,e,s){return es(t).put(s)}removeEntry(t,e,s){return es(t).delete(function(r,o){const a=r.path.toArray();return[a.slice(0,a.length-2),a[a.length-2],ha(o),a[a.length-1]]}(e,s))}updateMetadata(t,e){return this.getMetadata(t).next(s=>(s.byteSize+=e,this.tr(t,s)))}getEntry(t,e){let s=Ot.newInvalidDocument(e);return es(t).J({index:"documentKeyIndex",range:IDBKeyRange.only(Zi(e))},(i,r)=>{s=this.nr(e,r)}).next(()=>s)}rr(t,e){let s={size:0,document:Ot.newInvalidDocument(e)};return es(t).J({index:"documentKeyIndex",range:IDBKeyRange.only(Zi(e))},(i,r)=>{s={document:this.nr(e,r),size:pa(r)}}).next(()=>s)}getEntries(t,e){let s=Ee();return this.ir(t,e,(i,r)=>{const o=this.nr(i,r);s=s.insert(i,o)}).next(()=>s)}sr(t,e){let s=Ee(),i=new At(q.comparator);return this.ir(t,e,(r,o)=>{const a=this.nr(r,o);s=s.insert(r,a),i=i.insert(r,pa(o))}).next(()=>({documents:s,_r:i}))}ir(t,e,s){if(e.isEmpty())return P.resolve();let i=new wt(Af);e.forEach(l=>i=i.add(l));const r=IDBKeyRange.bound(Zi(i.first()),Zi(i.last())),o=i.getIterator();let a=o.getNext();return es(t).J({index:"documentKeyIndex",range:r},(l,u,h)=>{const p=q.fromSegments([...u.prefixPath,u.collectionGroup,u.documentId]);for(;a&&Af(a,p)<0;)s(a,null),a=o.getNext();a&&a.isEqual(p)&&(s(a,u),a=o.hasNext()?o.getNext():null),a?h.$(Zi(a)):h.done()}).next(()=>{for(;a;)s(a,null),a=o.hasNext()?o.getNext():null})}getDocumentsMatchingQuery(t,e,s,i,r){const o=e.path,a=[o.popLast().toArray(),o.lastSegment(),ha(s.readTime),s.documentKey.path.isEmpty()?"":s.documentKey.path.lastSegment()],l=[o.popLast().toArray(),o.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return es(t).U(IDBKeyRange.bound(a,l,!0)).next(u=>{r==null||r.incrementDocumentReadCount(u.length);let h=Ee();for(const p of u){const m=this.nr(q.fromSegments(p.prefixPath.concat(p.collectionGroup,p.documentId)),p);m.isFoundDocument()&&(Yr(e,m)||i.has(m.key))&&(h=h.insert(m.key,m))}return h})}getAllFromCollectionGroup(t,e,s,i){let r=Ee();const o=Tf(e,s),a=Tf(e,Se.max());return es(t).J({index:"collectionGroupIndex",range:IDBKeyRange.bound(o,a,!0)},(l,u,h)=>{const p=this.nr(q.fromSegments(u.prefixPath.concat(u.collectionGroup,u.documentId)),u);r=r.insert(p.key,p),r.size===i&&h.done()}).next(()=>r)}newChangeBuffer(t){return new FT(this,!!t&&t.trackRemovals)}getSize(t){return this.getMetadata(t).next(e=>e.byteSize)}getMetadata(t){return Ef(t).get("remoteDocumentGlobalKey").next(e=>(X(!!e),e))}tr(t,e){return Ef(t).put("remoteDocumentGlobalKey",e)}nr(t,e){if(e){const s=ET(this.serializer,e);if(!(s.isNoDocument()&&s.version.isEqual(Z.min())))return s}return Ot.newInvalidDocument(t)}}function Ug(n){return new LT(n)}class FT extends Fg{constructor(t,e){super(),this.ar=t,this.trackRemovals=e,this.ur=new Hn(s=>s.toString(),(s,i)=>s.isEqual(i))}applyChanges(t){const e=[];let s=0,i=new wt((r,o)=>nt(r.canonicalString(),o.canonicalString()));return this.changes.forEach((r,o)=>{const a=this.ur.get(r);if(e.push(this.ar.removeEntry(t,r,a.readTime)),o.isValidDocument()){const l=lf(this.ar.serializer,o);i=i.add(r.path.popLast());const u=pa(l);s+=u-a.size,e.push(this.ar.addEntry(t,r,l))}else if(s-=a.size,this.trackRemovals){const l=lf(this.ar.serializer,o.convertToNoDocument(Z.min()));e.push(this.ar.addEntry(t,r,l))}}),i.forEach(r=>{e.push(this.ar.indexManager.addToCollectionParentIndex(t,r))}),e.push(this.ar.updateMetadata(t,s)),P.waitFor(e)}getFromCache(t,e){return this.ar.rr(t,e).next(s=>(this.ur.set(e,{size:s.size,readTime:s.document.readTime}),s.document))}getAllFromCache(t,e){return this.ar.sr(t,e).next(({documents:s,_r:i})=>(i.forEach((r,o)=>{this.ur.set(r,{size:o,readTime:s.get(r).readTime})}),s))}}function Ef(n){return Jt(n,"remoteDocumentGlobal")}function es(n){return Jt(n,"remoteDocumentsV14")}function Zi(n){const t=n.path.toArray();return[t.slice(0,t.length-2),t[t.length-2],t[t.length-1]]}function Tf(n,t){const e=t.documentKey.path.toArray();return[n,ha(t.readTime),e.slice(0,e.length-2),e.length>0?e[e.length-1]:""]}function Af(n,t){const e=n.path.toArray(),s=t.path.toArray();let i=0;for(let r=0;r<e.length-2&&r<s.length-2;++r)if(i=nt(e[r],s[r]),i)return i;return i=nt(e.length,s.length),i||(i=nt(e[e.length-2],s[s.length-2]),i||nt(e[e.length-1],s[s.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UT{constructor(t,e){this.overlayedDocument=t,this.mutatedFields=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qg{constructor(t,e,s,i){this.remoteDocumentCache=t,this.mutationQueue=e,this.documentOverlayCache=s,this.indexManager=i}getDocument(t,e){let s=null;return this.documentOverlayCache.getOverlay(t,e).next(i=>(s=i,this.remoteDocumentCache.getEntry(t,e))).next(i=>(s!==null&&gr(s.mutation,i,be.empty(),Dt.now()),i))}getDocuments(t,e){return this.remoteDocumentCache.getEntries(t,e).next(s=>this.getLocalViewOfDocuments(t,s,rt()).next(()=>s))}getLocalViewOfDocuments(t,e,s=rt()){const i=je();return this.populateOverlays(t,i,e).next(()=>this.computeViews(t,e,i,s).next(r=>{let o=ar();return r.forEach((a,l)=>{o=o.insert(a,l.overlayedDocument)}),o}))}getOverlayedDocuments(t,e){const s=je();return this.populateOverlays(t,s,e).next(()=>this.computeViews(t,e,s,rt()))}populateOverlays(t,e,s){const i=[];return s.forEach(r=>{e.has(r)||i.push(r)}),this.documentOverlayCache.getOverlays(t,i).next(r=>{r.forEach((o,a)=>{e.set(o,a)})})}computeViews(t,e,s,i){let r=Ee();const o=mr(),a=function(){return mr()}();return e.forEach((l,u)=>{const h=s.get(u.key);i.has(u.key)&&(h===void 0||h.mutation instanceof hn)?r=r.insert(u.key,u):h!==void 0?(o.set(u.key,h.mutation.getFieldMask()),gr(h.mutation,u,h.mutation.getFieldMask(),Dt.now())):o.set(u.key,be.empty())}),this.recalculateAndSaveOverlays(t,r).next(l=>(l.forEach((u,h)=>o.set(u,h)),e.forEach((u,h)=>{var p;return a.set(u,new UT(h,(p=o.get(u))!==null&&p!==void 0?p:null))}),a))}recalculateAndSaveOverlays(t,e){const s=mr();let i=new At((o,a)=>o-a),r=rt();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(t,e).next(o=>{for(const a of o)a.keys().forEach(l=>{const u=e.get(l);if(u===null)return;let h=s.get(l)||be.empty();h=a.applyToLocalView(u,h),s.set(l,h);const p=(i.get(a.batchId)||rt()).add(l);i=i.insert(a.batchId,p)})}).next(()=>{const o=[],a=i.getReverseIterator();for(;a.hasNext();){const l=a.getNext(),u=l.key,h=l.value,p=ag();h.forEach(m=>{if(!r.has(m)){const I=pg(e.get(m),s.get(m));I!==null&&p.set(m,I),r=r.add(m)}}),o.push(this.documentOverlayCache.saveOverlays(t,u,p))}return P.waitFor(o)}).next(()=>s)}recalculateAndSaveOverlaysForDocumentKeys(t,e){return this.remoteDocumentCache.getEntries(t,e).next(s=>this.recalculateAndSaveOverlays(t,s))}getDocumentsMatchingQuery(t,e,s,i){return function(o){return q.isDocumentKey(o.path)&&o.collectionGroup===null&&o.filters.length===0}(e)?this.getDocumentsMatchingDocumentQuery(t,e.path):eg(e)?this.getDocumentsMatchingCollectionGroupQuery(t,e,s,i):this.getDocumentsMatchingCollectionQuery(t,e,s,i)}getNextDocuments(t,e,s,i){return this.remoteDocumentCache.getAllFromCollectionGroup(t,e,s,i).next(r=>{const o=i-r.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(t,e,s.largestBatchId,i-r.size):P.resolve(je());let a=-1,l=r;return o.next(u=>P.forEach(u,(h,p)=>(a<p.largestBatchId&&(a=p.largestBatchId),r.get(h)?P.resolve():this.remoteDocumentCache.getEntry(t,h).next(m=>{l=l.insert(h,m)}))).next(()=>this.populateOverlays(t,u,r)).next(()=>this.computeViews(t,l,u,rt())).next(h=>({batchId:a,changes:og(h)})))})}getDocumentsMatchingDocumentQuery(t,e){return this.getDocument(t,new q(e)).next(s=>{let i=ar();return s.isFoundDocument()&&(i=i.insert(s.key,s)),i})}getDocumentsMatchingCollectionGroupQuery(t,e,s,i){const r=e.collectionGroup;let o=ar();return this.indexManager.getCollectionParents(t,r).next(a=>P.forEach(a,l=>{const u=function(p,m){return new Jr(m,null,p.explicitOrderBy.slice(),p.filters.slice(),p.limit,p.limitType,p.startAt,p.endAt)}(e,l.child(r));return this.getDocumentsMatchingCollectionQuery(t,u,s,i).next(h=>{h.forEach((p,m)=>{o=o.insert(p,m)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(t,e,s,i){let r;return this.documentOverlayCache.getOverlaysForCollection(t,e.path,s.largestBatchId).next(o=>(r=o,this.remoteDocumentCache.getDocumentsMatchingQuery(t,e,s,r,i))).next(o=>{r.forEach((l,u)=>{const h=u.getKey();o.get(h)===null&&(o=o.insert(h,Ot.newInvalidDocument(h)))});let a=ar();return o.forEach((l,u)=>{const h=r.get(l);h!==void 0&&gr(h.mutation,u,be.empty(),Dt.now()),Yr(e,u)&&(a=a.insert(l,u))}),a})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qT{constructor(t){this.serializer=t,this.cr=new Map,this.lr=new Map}getBundleMetadata(t,e){return P.resolve(this.cr.get(e))}saveBundleMetadata(t,e){return this.cr.set(e.id,function(i){return{id:i.id,version:i.version,createTime:pe(i.createTime)}}(e)),P.resolve()}getNamedQuery(t,e){return P.resolve(this.lr.get(e))}saveNamedQuery(t,e){return this.lr.set(e.name,function(i){return{name:i.name,query:Vg(i.bundledQuery),readTime:pe(i.readTime)}}(e)),P.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BT{constructor(){this.overlays=new At(q.comparator),this.hr=new Map}getOverlay(t,e){return P.resolve(this.overlays.get(e))}getOverlays(t,e){const s=je();return P.forEach(e,i=>this.getOverlay(t,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(t,e,s){return s.forEach((i,r)=>{this.ht(t,e,r)}),P.resolve()}removeOverlaysForBatchId(t,e,s){const i=this.hr.get(s);return i!==void 0&&(i.forEach(r=>this.overlays=this.overlays.remove(r)),this.hr.delete(s)),P.resolve()}getOverlaysForCollection(t,e,s){const i=je(),r=e.length+1,o=new q(e.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){const l=a.getNext().value,u=l.getKey();if(!e.isPrefixOf(u.path))break;u.path.length===r&&l.largestBatchId>s&&i.set(l.getKey(),l)}return P.resolve(i)}getOverlaysForCollectionGroup(t,e,s,i){let r=new At((u,h)=>u-h);const o=this.overlays.getIterator();for(;o.hasNext();){const u=o.getNext().value;if(u.getKey().getCollectionGroup()===e&&u.largestBatchId>s){let h=r.get(u.largestBatchId);h===null&&(h=je(),r=r.insert(u.largestBatchId,h)),h.set(u.getKey(),u)}}const a=je(),l=r.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((u,h)=>a.set(u,h)),!(a.size()>=i)););return P.resolve(a)}ht(t,e,s){const i=this.overlays.get(s.key);if(i!==null){const o=this.hr.get(i.largestBatchId).delete(s.key);this.hr.set(i.largestBatchId,o)}this.overlays=this.overlays.insert(s.key,new lu(e,s));let r=this.hr.get(e);r===void 0&&(r=rt(),this.hr.set(e,r)),this.hr.set(e,r.add(s.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pu{constructor(){this.Pr=new wt(Ht.Ir),this.Tr=new wt(Ht.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(t,e){const s=new Ht(t,e);this.Pr=this.Pr.add(s),this.Tr=this.Tr.add(s)}dr(t,e){t.forEach(s=>this.addReference(s,e))}removeReference(t,e){this.Ar(new Ht(t,e))}Rr(t,e){t.forEach(s=>this.removeReference(s,e))}Vr(t){const e=new q(new vt([])),s=new Ht(e,t),i=new Ht(e,t+1),r=[];return this.Tr.forEachInRange([s,i],o=>{this.Ar(o),r.push(o.key)}),r}mr(){this.Pr.forEach(t=>this.Ar(t))}Ar(t){this.Pr=this.Pr.delete(t),this.Tr=this.Tr.delete(t)}gr(t){const e=new q(new vt([])),s=new Ht(e,t),i=new Ht(e,t+1);let r=rt();return this.Tr.forEachInRange([s,i],o=>{r=r.add(o.key)}),r}containsKey(t){const e=new Ht(t,0),s=this.Pr.firstAfterOrEqual(e);return s!==null&&t.isEqual(s.key)}}class Ht{constructor(t,e){this.key=t,this.pr=e}static Ir(t,e){return q.comparator(t.key,e.key)||nt(t.pr,e.pr)}static Er(t,e){return nt(t.pr,e.pr)||q.comparator(t.key,e.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jT{constructor(t,e){this.indexManager=t,this.referenceDelegate=e,this.mutationQueue=[],this.yr=1,this.wr=new wt(Ht.Ir)}checkEmpty(t){return P.resolve(this.mutationQueue.length===0)}addMutationBatch(t,e,s,i){const r=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new au(r,e,s,i);this.mutationQueue.push(o);for(const a of i)this.wr=this.wr.add(new Ht(a.key,r)),this.indexManager.addToCollectionParentIndex(t,a.key.path.popLast());return P.resolve(o)}lookupMutationBatch(t,e){return P.resolve(this.Sr(e))}getNextMutationBatchAfterBatchId(t,e){const s=e+1,i=this.br(s),r=i<0?0:i;return P.resolve(this.mutationQueue.length>r?this.mutationQueue[r]:null)}getHighestUnacknowledgedBatchId(){return P.resolve(this.mutationQueue.length===0?-1:this.yr-1)}getAllMutationBatches(t){return P.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(t,e){const s=new Ht(e,0),i=new Ht(e,Number.POSITIVE_INFINITY),r=[];return this.wr.forEachInRange([s,i],o=>{const a=this.Sr(o.pr);r.push(a)}),P.resolve(r)}getAllMutationBatchesAffectingDocumentKeys(t,e){let s=new wt(nt);return e.forEach(i=>{const r=new Ht(i,0),o=new Ht(i,Number.POSITIVE_INFINITY);this.wr.forEachInRange([r,o],a=>{s=s.add(a.pr)})}),P.resolve(this.Dr(s))}getAllMutationBatchesAffectingQuery(t,e){const s=e.path,i=s.length+1;let r=s;q.isDocumentKey(r)||(r=r.child(""));const o=new Ht(new q(r),0);let a=new wt(nt);return this.wr.forEachWhile(l=>{const u=l.key.path;return!!s.isPrefixOf(u)&&(u.length===i&&(a=a.add(l.pr)),!0)},o),P.resolve(this.Dr(a))}Dr(t){const e=[];return t.forEach(s=>{const i=this.Sr(s);i!==null&&e.push(i)}),e}removeMutationBatch(t,e){X(this.Cr(e.batchId,"removed")===0),this.mutationQueue.shift();let s=this.wr;return P.forEach(e.mutations,i=>{const r=new Ht(i.key,e.batchId);return s=s.delete(r),this.referenceDelegate.markPotentiallyOrphaned(t,i.key)}).next(()=>{this.wr=s})}Mn(t){}containsKey(t,e){const s=new Ht(e,0),i=this.wr.firstAfterOrEqual(s);return P.resolve(e.isEqual(i&&i.key))}performConsistencyCheck(t){return this.mutationQueue.length,P.resolve()}Cr(t,e){return this.br(t)}br(t){return this.mutationQueue.length===0?0:t-this.mutationQueue[0].batchId}Sr(t){const e=this.br(t);return e<0||e>=this.mutationQueue.length?null:this.mutationQueue[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zT{constructor(t){this.vr=t,this.docs=function(){return new At(q.comparator)}(),this.size=0}setIndexManager(t){this.indexManager=t}addEntry(t,e){const s=e.key,i=this.docs.get(s),r=i?i.size:0,o=this.vr(e);return this.docs=this.docs.insert(s,{document:e.mutableCopy(),size:o}),this.size+=o-r,this.indexManager.addToCollectionParentIndex(t,s.path.popLast())}removeEntry(t){const e=this.docs.get(t);e&&(this.docs=this.docs.remove(t),this.size-=e.size)}getEntry(t,e){const s=this.docs.get(e);return P.resolve(s?s.document.mutableCopy():Ot.newInvalidDocument(e))}getEntries(t,e){let s=Ee();return e.forEach(i=>{const r=this.docs.get(i);s=s.insert(i,r?r.document.mutableCopy():Ot.newInvalidDocument(i))}),P.resolve(s)}getDocumentsMatchingQuery(t,e,s,i){let r=Ee();const o=e.path,a=new q(o.child("")),l=this.docs.getIteratorFrom(a);for(;l.hasNext();){const{key:u,value:{document:h}}=l.getNext();if(!o.isPrefixOf(u.path))break;u.path.length>o.length+1||eu(Vm(h),s)<=0||(i.has(h.key)||Yr(e,h))&&(r=r.insert(h.key,h.mutableCopy()))}return P.resolve(r)}getAllFromCollectionGroup(t,e,s,i){G()}Fr(t,e){return P.forEach(this.docs,s=>e(s))}newChangeBuffer(t){return new GT(this)}getSize(t){return P.resolve(this.size)}}class GT extends Fg{constructor(t){super(),this.ar=t}applyChanges(t){const e=[];return this.changes.forEach((s,i)=>{i.isValidDocument()?e.push(this.ar.addEntry(t,i)):this.ar.removeEntry(s)}),P.waitFor(e)}getFromCache(t,e){return this.ar.getEntry(t,e)}getAllFromCache(t,e){return this.ar.getEntries(t,e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KT{constructor(t){this.persistence=t,this.Mr=new Hn(e=>bs(e),Qr),this.lastRemoteSnapshotVersion=Z.min(),this.highestTargetId=0,this.Or=0,this.Nr=new pu,this.targetCount=0,this.Lr=Es.Nn()}forEachTarget(t,e){return this.Mr.forEach((s,i)=>e(i)),P.resolve()}getLastRemoteSnapshotVersion(t){return P.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(t){return P.resolve(this.Or)}allocateTargetId(t){return this.highestTargetId=this.Lr.next(),P.resolve(this.highestTargetId)}setTargetsMetadata(t,e,s){return s&&(this.lastRemoteSnapshotVersion=s),e>this.Or&&(this.Or=e),P.resolve()}qn(t){this.Mr.set(t.target,t);const e=t.targetId;e>this.highestTargetId&&(this.Lr=new Es(e),this.highestTargetId=e),t.sequenceNumber>this.Or&&(this.Or=t.sequenceNumber)}addTargetData(t,e){return this.qn(e),this.targetCount+=1,P.resolve()}updateTargetData(t,e){return this.qn(e),P.resolve()}removeTargetData(t,e){return this.Mr.delete(e.target),this.Nr.Vr(e.targetId),this.targetCount-=1,P.resolve()}removeTargets(t,e,s){let i=0;const r=[];return this.Mr.forEach((o,a)=>{a.sequenceNumber<=e&&s.get(a.targetId)===null&&(this.Mr.delete(o),r.push(this.removeMatchingKeysForTargetId(t,a.targetId)),i++)}),P.waitFor(r).next(()=>i)}getTargetCount(t){return P.resolve(this.targetCount)}getTargetData(t,e){const s=this.Mr.get(e)||null;return P.resolve(s)}addMatchingKeys(t,e,s){return this.Nr.dr(e,s),P.resolve()}removeMatchingKeys(t,e,s){this.Nr.Rr(e,s);const i=this.persistence.referenceDelegate,r=[];return i&&e.forEach(o=>{r.push(i.markPotentiallyOrphaned(t,o))}),P.waitFor(r)}removeMatchingKeysForTargetId(t,e){return this.Nr.Vr(e),P.resolve()}getMatchingKeysForTargetId(t,e){const s=this.Nr.gr(e);return P.resolve(s)}containsKey(t,e){return P.resolve(this.Nr.containsKey(e))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bg{constructor(t,e){this.Br={},this.overlays={},this.kr=new _e(0),this.qr=!1,this.qr=!0,this.referenceDelegate=t(this),this.Qr=new KT(this),this.indexManager=new CT,this.remoteDocumentCache=function(i){return new zT(i)}(s=>this.referenceDelegate.Kr(s)),this.serializer=new Dg(e),this.$r=new qT(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(t){return this.indexManager}getDocumentOverlayCache(t){let e=this.overlays[t.toKey()];return e||(e=new BT,this.overlays[t.toKey()]=e),e}getMutationQueue(t,e){let s=this.Br[t.toKey()];return s||(s=new jT(e,this.referenceDelegate),this.Br[t.toKey()]=s),s}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(t,e,s){N("MemoryPersistence","Starting transaction:",t);const i=new WT(this.kr.next());return this.referenceDelegate.Ur(),s(i).next(r=>this.referenceDelegate.Wr(i).next(()=>r)).toPromise().then(r=>(i.raiseOnCommittedEvent(),r))}Gr(t,e){return P.or(Object.values(this.Br).map(s=>()=>s.containsKey(t,e)))}}class WT extends xm{constructor(t){super(),this.currentSequenceNumber=t}}class za{constructor(t){this.persistence=t,this.zr=new pu,this.jr=null}static Hr(t){return new za(t)}get Jr(){if(this.jr)return this.jr;throw G()}addReference(t,e,s){return this.zr.addReference(s,e),this.Jr.delete(s.toString()),P.resolve()}removeReference(t,e,s){return this.zr.removeReference(s,e),this.Jr.add(s.toString()),P.resolve()}markPotentiallyOrphaned(t,e){return this.Jr.add(e.toString()),P.resolve()}removeTarget(t,e){this.zr.Vr(e.targetId).forEach(i=>this.Jr.add(i.toString()));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(t,e.targetId).next(i=>{i.forEach(r=>this.Jr.add(r.toString()))}).next(()=>s.removeTargetData(t,e))}Ur(){this.jr=new Set}Wr(t){const e=this.persistence.getRemoteDocumentCache().newChangeBuffer();return P.forEach(this.Jr,s=>{const i=q.fromPath(s);return this.Yr(t,i).next(r=>{r||e.removeEntry(i,Z.min())})}).next(()=>(this.jr=null,e.apply(t)))}updateLimboDocument(t,e){return this.Yr(t,e).next(s=>{s?this.Jr.delete(e.toString()):this.Jr.add(e.toString())})}Kr(t){return 0}Yr(t,e){return P.or([()=>P.resolve(this.zr.containsKey(e)),()=>this.persistence.getTargetCache().containsKey(t,e),()=>this.persistence.Gr(t,e)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HT{constructor(t){this.serializer=t}O(t,e,s,i){const r=new xa("createOrUpgrade",e);s<1&&i>=1&&(function(l){l.createObjectStore("owner")}(t),function(l){l.createObjectStore("mutationQueues",{keyPath:"userId"}),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",Fh,{unique:!0}),l.createObjectStore("documentMutations")}(t),Sf(t),function(l){l.createObjectStore("remoteDocuments")}(t));let o=P.resolve();return s<3&&i>=3&&(s!==0&&(function(l){l.deleteObjectStore("targetDocuments"),l.deleteObjectStore("targets"),l.deleteObjectStore("targetGlobal")}(t),Sf(t)),o=o.next(()=>function(l){const u=l.store("targetGlobal"),h={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:Z.min().toTimestamp(),targetCount:0};return u.put("targetGlobalKey",h)}(r))),s<4&&i>=4&&(s!==0&&(o=o.next(()=>function(l,u){return u.store("mutations").U().next(h=>{l.deleteObjectStore("mutations"),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",Fh,{unique:!0});const p=u.store("mutations"),m=h.map(I=>p.put(I));return P.waitFor(m)})}(t,r))),o=o.next(()=>{(function(l){l.createObjectStore("clientMetadata",{keyPath:"clientId"})})(t)})),s<5&&i>=5&&(o=o.next(()=>this.Xr(r))),s<6&&i>=6&&(o=o.next(()=>(function(l){l.createObjectStore("remoteDocumentGlobal")}(t),this.ei(r)))),s<7&&i>=7&&(o=o.next(()=>this.ti(r))),s<8&&i>=8&&(o=o.next(()=>this.ni(t,r))),s<9&&i>=9&&(o=o.next(()=>{(function(l){l.objectStoreNames.contains("remoteDocumentChanges")&&l.deleteObjectStore("remoteDocumentChanges")})(t)})),s<10&&i>=10&&(o=o.next(()=>this.ri(r))),s<11&&i>=11&&(o=o.next(()=>{(function(l){l.createObjectStore("bundles",{keyPath:"bundleId"})})(t),function(l){l.createObjectStore("namedQueries",{keyPath:"name"})}(t)})),s<12&&i>=12&&(o=o.next(()=>{(function(l){const u=l.createObjectStore("documentOverlays",{keyPath:RE});u.createIndex("collectionPathOverlayIndex",PE,{unique:!1}),u.createIndex("collectionGroupOverlayIndex",CE,{unique:!1})})(t)})),s<13&&i>=13&&(o=o.next(()=>function(l){const u=l.createObjectStore("remoteDocumentsV14",{keyPath:yE});u.createIndex("documentKeyIndex",vE),u.createIndex("collectionGroupIndex",_E)}(t)).next(()=>this.ii(t,r)).next(()=>t.deleteObjectStore("remoteDocuments"))),s<14&&i>=14&&(o=o.next(()=>this.si(t,r))),s<15&&i>=15&&(o=o.next(()=>function(l){l.createObjectStore("indexConfiguration",{keyPath:"indexId",autoIncrement:!0}).createIndex("collectionGroupIndex","collectionGroup",{unique:!1}),l.createObjectStore("indexState",{keyPath:TE}).createIndex("sequenceNumberIndex",AE,{unique:!1}),l.createObjectStore("indexEntries",{keyPath:SE}).createIndex("documentKeyIndex",kE,{unique:!1})}(t))),s<16&&i>=16&&(o=o.next(()=>{e.objectStore("indexState").clear()}).next(()=>{e.objectStore("indexEntries").clear()})),o}ei(t){let e=0;return t.store("remoteDocuments").J((s,i)=>{e+=pa(i)}).next(()=>{const s={byteSize:e};return t.store("remoteDocumentGlobal").put("remoteDocumentGlobalKey",s)})}Xr(t){const e=t.store("mutationQueues"),s=t.store("mutations");return e.U().next(i=>P.forEach(i,r=>{const o=IDBKeyRange.bound([r.userId,-1],[r.userId,r.lastAcknowledgedBatchId]);return s.U("userMutationsIndex",o).next(a=>P.forEach(a,l=>{X(l.userId===r.userId);const u=rs(this.serializer,l);return Og(t,r.userId,u).next(()=>{})}))}))}ti(t){const e=t.store("targetDocuments"),s=t.store("remoteDocuments");return t.store("targetGlobal").get("targetGlobalKey").next(i=>{const r=[];return s.J((o,a)=>{const l=new vt(o),u=function(p){return[0,fe(p)]}(l);r.push(e.get(u).next(h=>h?P.resolve():(p=>e.put({targetId:0,path:fe(p),sequenceNumber:i.highestListenSequenceNumber}))(l)))}).next(()=>P.waitFor(r))})}ni(t,e){t.createObjectStore("collectionParents",{keyPath:EE});const s=e.store("collectionParents"),i=new fu,r=o=>{if(i.add(o)){const a=o.lastSegment(),l=o.popLast();return s.put({collectionId:a,parent:fe(l)})}};return e.store("remoteDocuments").J({H:!0},(o,a)=>{const l=new vt(o);return r(l.popLast())}).next(()=>e.store("documentMutations").J({H:!0},([o,a,l],u)=>{const h=Be(a);return r(h.popLast())}))}ri(t){const e=t.store("targets");return e.J((s,i)=>{const r=lr(i),o=$g(this.serializer,r);return e.put(o)})}ii(t,e){const s=e.store("remoteDocuments"),i=[];return s.J((r,o)=>{const a=e.store("remoteDocumentsV14"),l=function(p){return p.document?new q(vt.fromString(p.document.name).popFirst(5)):p.noDocument?q.fromSegments(p.noDocument.path):p.unknownDocument?q.fromSegments(p.unknownDocument.path):G()}(o).path.toArray(),u={prefixPath:l.slice(0,l.length-2),collectionGroup:l[l.length-2],documentId:l[l.length-1],readTime:o.readTime||[0,0],unknownDocument:o.unknownDocument,noDocument:o.noDocument,document:o.document,hasCommittedMutations:!!o.hasCommittedMutations};i.push(a.put(u))}).next(()=>P.waitFor(i))}si(t,e){const s=e.store("mutations"),i=Ug(this.serializer),r=new Bg(za.Hr,this.serializer.ct);return s.U().next(o=>{const a=new Map;return o.forEach(l=>{var u;let h=(u=a.get(l.userId))!==null&&u!==void 0?u:rt();rs(this.serializer,l).keys().forEach(p=>h=h.add(p)),a.set(l.userId,h)}),P.forEach(a,(l,u)=>{const h=new re(u),p=Ba.lt(this.serializer,h),m=r.getIndexManager(h),I=ja.lt(h,this.serializer,m,r.referenceDelegate);return new qg(i,I,p,m).recalculateAndSaveOverlaysForDocumentKeys(new cl(e,_e.oe),l).next()})})}}function Sf(n){n.createObjectStore("targetDocuments",{keyPath:wE}).createIndex("documentTargetsIndex",IE,{unique:!0}),n.createObjectStore("targets",{keyPath:"targetId"}).createIndex("queryTargetsIndex",bE,{unique:!0}),n.createObjectStore("targetGlobal")}const Fc="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class mu{constructor(t,e,s,i,r,o,a,l,u,h,p=16){if(this.allowTabSynchronization=t,this.persistenceKey=e,this.clientId=s,this.oi=r,this.window=o,this.document=a,this._i=u,this.ai=h,this.ui=p,this.kr=null,this.qr=!1,this.isPrimary=!1,this.networkEnabled=!0,this.ci=null,this.inForeground=!1,this.li=null,this.hi=null,this.Pi=Number.NEGATIVE_INFINITY,this.Ii=m=>Promise.resolve(),!mu.D())throw new U(V.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new MT(this,i),this.Ti=e+"main",this.serializer=new Dg(l),this.Ei=new Nn(this.Ti,this.ui,new HT(this.serializer)),this.Qr=new $T(this.referenceDelegate,this.serializer),this.remoteDocumentCache=Ug(this.serializer),this.$r=new TT,this.window&&this.window.localStorage?this.di=this.window.localStorage:(this.di=null,h===!1&&Lt("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ai().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new U(V.FAILED_PRECONDITION,Fc);return this.Ri(),this.Vi(),this.mi(),this.runTransaction("getHighestListenSequenceNumber","readonly",t=>this.Qr.getHighestSequenceNumber(t))}).then(t=>{this.kr=new _e(t,this._i)}).then(()=>{this.qr=!0}).catch(t=>(this.Ei&&this.Ei.close(),Promise.reject(t)))}fi(t){return this.Ii=async e=>{if(this.started)return t(e)},t(this.isPrimary)}setDatabaseDeletedListener(t){this.Ei.L(async e=>{e.newVersion===null&&await t()})}setNetworkEnabled(t){this.networkEnabled!==t&&(this.networkEnabled=t,this.oi.enqueueAndForget(async()=>{this.started&&await this.Ai()}))}Ai(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",t=>Co(t).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.gi(t).next(e=>{e||(this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)))})}).next(()=>this.pi(t)).next(e=>this.isPrimary&&!e?this.yi(t).next(()=>!1):!!e&&this.wi(t).next(()=>!0))).catch(t=>{if(Wn(t))return N("IndexedDbPersistence","Failed to extend owner lease: ",t),this.isPrimary;if(!this.allowTabSynchronization)throw t;return N("IndexedDbPersistence","Releasing owner lease after error during lease refresh",t),!1}).then(t=>{this.isPrimary!==t&&this.oi.enqueueRetryable(()=>this.Ii(t)),this.isPrimary=t})}gi(t){return tr(t).get("owner").next(e=>P.resolve(this.Si(e)))}bi(t){return Co(t).delete(this.clientId)}async Di(){if(this.isPrimary&&!this.Ci(this.Pi,18e5)){this.Pi=Date.now();const t=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",e=>{const s=Jt(e,"clientMetadata");return s.U().next(i=>{const r=this.vi(i,18e5),o=i.filter(a=>r.indexOf(a)===-1);return P.forEach(o,a=>s.delete(a.clientId)).next(()=>o)})}).catch(()=>[]);if(this.di)for(const e of t)this.di.removeItem(this.Fi(e.clientId))}}mi(){this.hi=this.oi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Ai().then(()=>this.Di()).then(()=>this.mi()))}Si(t){return!!t&&t.ownerId===this.clientId}pi(t){return this.ai?P.resolve(!0):tr(t).get("owner").next(e=>{if(e!==null&&this.Ci(e.leaseTimestampMs,5e3)&&!this.Mi(e.ownerId)){if(this.Si(e)&&this.networkEnabled)return!0;if(!this.Si(e)){if(!e.allowTabSynchronization)throw new U(V.FAILED_PRECONDITION,Fc);return!1}}return!(!this.networkEnabled||!this.inForeground)||Co(t).U().next(s=>this.vi(s,5e3).find(i=>{if(this.clientId!==i.clientId){const r=!this.networkEnabled&&i.networkEnabled,o=!this.inForeground&&i.inForeground,a=this.networkEnabled===i.networkEnabled;if(r||o&&a)return!0}return!1})===void 0)}).next(e=>(this.isPrimary!==e&&N("IndexedDbPersistence",`Client ${e?"is":"is not"} eligible for a primary lease.`),e))}async shutdown(){this.qr=!1,this.xi(),this.hi&&(this.hi.cancel(),this.hi=null),this.Oi(),this.Ni(),await this.Ei.runTransaction("shutdown","readwrite",["owner","clientMetadata"],t=>{const e=new cl(t,_e.oe);return this.yi(e).next(()=>this.bi(e))}),this.Ei.close(),this.Li()}vi(t,e){return t.filter(s=>this.Ci(s.updateTimeMs,e)&&!this.Mi(s.clientId))}Bi(){return this.runTransaction("getActiveClients","readonly",t=>Co(t).U().next(e=>this.vi(e,18e5).map(s=>s.clientId)))}get started(){return this.qr}getMutationQueue(t,e){return ja.lt(t,this.serializer,e,this.referenceDelegate)}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(t){return new DT(t,this.serializer.ct.databaseId)}getDocumentOverlayCache(t){return Ba.lt(this.serializer,t)}getBundleCache(){return this.$r}runTransaction(t,e,s){N("IndexedDbPersistence","Starting transaction:",t);const i=e==="readonly"?"readonly":"readwrite",r=function(l){return l===16?$E:l===15?Bm:l===14?qm:l===13?Um:l===12?DE:l===11?Fm:void G()}(this.ui);let o;return this.Ei.runTransaction(t,i,r,a=>(o=new cl(a,this.kr?this.kr.next():_e.oe),e==="readwrite-primary"?this.gi(o).next(l=>!!l||this.pi(o)).next(l=>{if(!l)throw Lt(`Failed to obtain primary lease for action '${t}'.`),this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)),new U(V.FAILED_PRECONDITION,Nm);return s(o)}).next(l=>this.wi(o).next(()=>l)):this.ki(o).next(()=>s(o)))).then(a=>(o.raiseOnCommittedEvent(),a))}ki(t){return tr(t).get("owner").next(e=>{if(e!==null&&this.Ci(e.leaseTimestampMs,5e3)&&!this.Mi(e.ownerId)&&!this.Si(e)&&!(this.ai||this.allowTabSynchronization&&e.allowTabSynchronization))throw new U(V.FAILED_PRECONDITION,Fc)})}wi(t){const e={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return tr(t).put("owner",e)}static D(){return Nn.D()}yi(t){const e=tr(t);return e.get("owner").next(s=>this.Si(s)?(N("IndexedDbPersistence","Releasing primary lease."),e.delete("owner")):P.resolve())}Ci(t,e){const s=Date.now();return!(t<s-e)&&(!(t>s)||(Lt(`Detected an update time that is in the future: ${t} > ${s}`),!1))}Ri(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.li=()=>{this.oi.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.Ai()))},this.document.addEventListener("visibilitychange",this.li),this.inForeground=this.document.visibilityState==="visible")}Oi(){this.li&&(this.document.removeEventListener("visibilitychange",this.li),this.li=null)}Vi(){var t;typeof((t=this.window)===null||t===void 0?void 0:t.addEventListener)=="function"&&(this.ci=()=>{this.xi();const e=/(?:Version|Mobile)\/1[456]/;Lp()&&(navigator.appVersion.match(e)||navigator.userAgent.match(e))&&this.oi.enterRestrictedMode(!0),this.oi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.ci))}Ni(){this.ci&&(this.window.removeEventListener("pagehide",this.ci),this.ci=null)}Mi(t){var e;try{const s=((e=this.di)===null||e===void 0?void 0:e.getItem(this.Fi(t)))!==null;return N("IndexedDbPersistence",`Client '${t}' ${s?"is":"is not"} zombied in LocalStorage`),s}catch(s){return Lt("IndexedDbPersistence","Failed to get zombied client id.",s),!1}}xi(){if(this.di)try{this.di.setItem(this.Fi(this.clientId),String(Date.now()))}catch(t){Lt("Failed to set zombie client id.",t)}}Li(){if(this.di)try{this.di.removeItem(this.Fi(this.clientId))}catch{}}Fi(t){return`firestore_zombie_${this.persistenceKey}_${t}`}}function tr(n){return Jt(n,"owner")}function Co(n){return Jt(n,"clientMetadata")}function jg(n,t){let e=n.projectId;return n.isDefaultDatabase||(e+="."+n.database),"firestore/"+t+"/"+e+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gu{constructor(t,e,s,i){this.targetId=t,this.fromCache=e,this.qi=s,this.Qi=i}static Ki(t,e){let s=rt(),i=rt();for(const r of e.docChanges)switch(r.type){case 0:s=s.add(r.doc.key);break;case 1:i=i.add(r.doc.key)}return new gu(t,e.fromCache,s,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class QT{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(t){this._documentReadCount+=t}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zg{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=function(){return Lp()?8:Om(Bt())>0?6:4}()}initialize(t,e){this.zi=t,this.indexManager=e,this.$i=!0}getDocumentsMatchingQuery(t,e,s,i){const r={result:null};return this.ji(t,e).next(o=>{r.result=o}).next(()=>{if(!r.result)return this.Hi(t,e,i,s).next(o=>{r.result=o})}).next(()=>{if(r.result)return;const o=new QT;return this.Ji(t,e,o).next(a=>{if(r.result=a,this.Ui)return this.Yi(t,e,o,a.size)})}).next(()=>r.result)}Yi(t,e,s,i){return s.documentReadCount<this.Wi?(js()<=ot.DEBUG&&N("QueryEngine","SDK will not create cache indexes for query:",zs(e),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),P.resolve()):(js()<=ot.DEBUG&&N("QueryEngine","Query:",zs(e),"scans",s.documentReadCount,"local documents and returns",i,"documents as results."),s.documentReadCount>this.Gi*i?(js()<=ot.DEBUG&&N("QueryEngine","The SDK decides to create cache indexes for query:",zs(e),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(t,Te(e))):P.resolve())}ji(t,e){if(Yh(e))return P.resolve(null);let s=Te(e);return this.indexManager.getIndexType(t,s).next(i=>i===0?null:(e.limit!==null&&i===1&&(e=ml(e,null,"F"),s=Te(e)),this.indexManager.getDocumentsMatchingTarget(t,s).next(r=>{const o=rt(...r);return this.zi.getDocuments(t,o).next(a=>this.indexManager.getMinOffset(t,s).next(l=>{const u=this.Zi(e,a);return this.Xi(e,u,o,l.readTime)?this.ji(t,ml(e,null,"F")):this.es(t,u,e,l)}))})))}Hi(t,e,s,i){return Yh(e)||i.isEqual(Z.min())?P.resolve(null):this.zi.getDocuments(t,s).next(r=>{const o=this.Zi(e,r);return this.Xi(e,o,s,i)?P.resolve(null):(js()<=ot.DEBUG&&N("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),zs(e)),this.es(t,o,e,$m(i,-1)).next(a=>a))})}Zi(t,e){let s=new wt(ig(t));return e.forEach((i,r)=>{Yr(t,r)&&(s=s.add(r))}),s}Xi(t,e,s,i){if(t.limit===null)return!1;if(s.size!==e.size)return!0;const r=t.limitType==="F"?e.last():e.first();return!!r&&(r.hasPendingWrites||r.version.compareTo(i)>0)}Ji(t,e,s){return js()<=ot.DEBUG&&N("QueryEngine","Using full collection scan to execute query:",zs(e)),this.zi.getDocumentsMatchingQuery(t,e,Se.min(),s)}es(t,e,s,i){return this.zi.getDocumentsMatchingQuery(t,s,i).next(r=>(e.forEach(o=>{r=r.insert(o.key,o)}),r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class JT{constructor(t,e,s,i){this.persistence=t,this.ts=e,this.serializer=i,this.ns=new At(nt),this.rs=new Hn(r=>bs(r),Qr),this.ss=new Map,this.os=t.getRemoteDocumentCache(),this.Qr=t.getTargetCache(),this.$r=t.getBundleCache(),this._s(s)}_s(t){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(t),this.indexManager=this.persistence.getIndexManager(t),this.mutationQueue=this.persistence.getMutationQueue(t,this.indexManager),this.localDocuments=new qg(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(t){return this.persistence.runTransaction("Collect garbage","readwrite-primary",e=>t.collect(e,this.ns))}}function Gg(n,t,e,s){return new JT(n,t,e,s)}async function Kg(n,t){const e=W(n);return await e.persistence.runTransaction("Handle user change","readonly",s=>{let i;return e.mutationQueue.getAllMutationBatches(s).next(r=>(i=r,e._s(t),e.mutationQueue.getAllMutationBatches(s))).next(r=>{const o=[],a=[];let l=rt();for(const u of i){o.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}for(const u of r){a.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}return e.localDocuments.getDocuments(s,l).next(u=>({us:u,removedBatchIds:o,addedBatchIds:a}))})})}function YT(n,t){const e=W(n);return e.persistence.runTransaction("Acknowledge batch","readwrite-primary",s=>{const i=t.batch.keys(),r=e.os.newChangeBuffer({trackRemovals:!0});return function(a,l,u,h){const p=u.batch,m=p.keys();let I=P.resolve();return m.forEach(E=>{I=I.next(()=>h.getEntry(l,E)).next($=>{const R=u.docVersions.get(E);X(R!==null),$.version.compareTo(R)<0&&(p.applyToRemoteDocument($,u),$.isValidDocument()&&($.setReadTime(u.commitVersion),h.addEntry($)))})}),I.next(()=>a.mutationQueue.removeMutationBatch(l,p))}(e,s,t,r).next(()=>r.apply(s)).next(()=>e.mutationQueue.performConsistencyCheck(s)).next(()=>e.documentOverlayCache.removeOverlaysForBatchId(s,i,t.batch.batchId)).next(()=>e.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,function(a){let l=rt();for(let u=0;u<a.mutationResults.length;++u)a.mutationResults[u].transformResults.length>0&&(l=l.add(a.batch.mutations[u].key));return l}(t))).next(()=>e.localDocuments.getDocuments(s,i))})}function Wg(n){const t=W(n);return t.persistence.runTransaction("Get last remote snapshot version","readonly",e=>t.Qr.getLastRemoteSnapshotVersion(e))}function XT(n,t){const e=W(n),s=t.snapshotVersion;let i=e.ns;return e.persistence.runTransaction("Apply remote event","readwrite-primary",r=>{const o=e.os.newChangeBuffer({trackRemovals:!0});i=e.ns;const a=[];t.targetChanges.forEach((h,p)=>{const m=i.get(p);if(!m)return;a.push(e.Qr.removeMatchingKeys(r,h.removedDocuments,p).next(()=>e.Qr.addMatchingKeys(r,h.addedDocuments,p)));let I=m.withSequenceNumber(r.currentSequenceNumber);t.targetMismatches.get(p)!==null?I=I.withResumeToken(Qt.EMPTY_BYTE_STRING,Z.min()).withLastLimboFreeSnapshotVersion(Z.min()):h.resumeToken.approximateByteSize()>0&&(I=I.withResumeToken(h.resumeToken,s)),i=i.insert(p,I),function($,R,B){return $.resumeToken.approximateByteSize()===0||R.snapshotVersion.toMicroseconds()-$.snapshotVersion.toMicroseconds()>=3e8?!0:B.addedDocuments.size+B.modifiedDocuments.size+B.removedDocuments.size>0}(m,I,h)&&a.push(e.Qr.updateTargetData(r,I))});let l=Ee(),u=rt();if(t.documentUpdates.forEach(h=>{t.resolvedLimboDocuments.has(h)&&a.push(e.persistence.referenceDelegate.updateLimboDocument(r,h))}),a.push(ZT(r,o,t.documentUpdates).next(h=>{l=h.cs,u=h.ls})),!s.isEqual(Z.min())){const h=e.Qr.getLastRemoteSnapshotVersion(r).next(p=>e.Qr.setTargetsMetadata(r,r.currentSequenceNumber,s));a.push(h)}return P.waitFor(a).next(()=>o.apply(r)).next(()=>e.localDocuments.getLocalViewOfDocuments(r,l,u)).next(()=>l)}).then(r=>(e.ns=i,r))}function ZT(n,t,e){let s=rt(),i=rt();return e.forEach(r=>s=s.add(r)),t.getEntries(n,s).next(r=>{let o=Ee();return e.forEach((a,l)=>{const u=r.get(a);l.isFoundDocument()!==u.isFoundDocument()&&(i=i.add(a)),l.isNoDocument()&&l.version.isEqual(Z.min())?(t.removeEntry(a,l.readTime),o=o.insert(a,l)):!u.isValidDocument()||l.version.compareTo(u.version)>0||l.version.compareTo(u.version)===0&&u.hasPendingWrites?(t.addEntry(l),o=o.insert(a,l)):N("LocalStore","Ignoring outdated watch update for ",a,". Current version:",u.version," Watch version:",l.version)}),{cs:o,ls:i}})}function t0(n,t){const e=W(n);return e.persistence.runTransaction("Get next mutation batch","readonly",s=>(t===void 0&&(t=-1),e.mutationQueue.getNextMutationBatchAfterBatchId(s,t)))}function ma(n,t){const e=W(n);return e.persistence.runTransaction("Allocate target","readwrite",s=>{let i;return e.Qr.getTargetData(s,t).next(r=>r?(i=r,P.resolve(i)):e.Qr.allocateTargetId(s).next(o=>(i=new on(t,o,"TargetPurposeListen",s.currentSequenceNumber),e.Qr.addTargetData(s,i).next(()=>i))))}).then(s=>{const i=e.ns.get(s.targetId);return(i===null||s.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(e.ns=e.ns.insert(s.targetId,s),e.rs.set(t,s.targetId)),s})}async function fi(n,t,e){const s=W(n),i=s.ns.get(t),r=e?"readwrite":"readwrite-primary";try{e||await s.persistence.runTransaction("Release target",r,o=>s.persistence.referenceDelegate.removeTarget(o,i))}catch(o){if(!Wn(o))throw o;N("LocalStore",`Failed to update sequence numbers for target ${t}: ${o}`)}s.ns=s.ns.remove(t),s.rs.delete(i.target)}function El(n,t,e){const s=W(n);let i=Z.min(),r=rt();return s.persistence.runTransaction("Execute query","readwrite",o=>function(l,u,h){const p=W(l),m=p.rs.get(h);return m!==void 0?P.resolve(p.ns.get(m)):p.Qr.getTargetData(u,h)}(s,o,Te(t)).next(a=>{if(a)return i=a.lastLimboFreeSnapshotVersion,s.Qr.getMatchingKeysForTargetId(o,a.targetId).next(l=>{r=l})}).next(()=>s.ts.getDocumentsMatchingQuery(o,t,e?i:Z.min(),e?r:rt())).next(a=>(Jg(s,sg(t),a),{documents:a,hs:r})))}function Hg(n,t){const e=W(n),s=W(e.Qr),i=e.ns.get(t);return i?Promise.resolve(i.target):e.persistence.runTransaction("Get target data","readonly",r=>s.ot(r,t).next(o=>o?o.target:null))}function Qg(n,t){const e=W(n),s=e.ss.get(t)||Z.min();return e.persistence.runTransaction("Get new document changes","readonly",i=>e.os.getAllFromCollectionGroup(i,t,$m(s,-1),Number.MAX_SAFE_INTEGER)).then(i=>(Jg(e,t,i),i))}function Jg(n,t,e){let s=n.ss.get(t)||Z.min();e.forEach((i,r)=>{r.readTime.compareTo(s)>0&&(s=r.readTime)}),n.ss.set(t,s)}function kf(n,t){return`firestore_clients_${n}_${t}`}function Rf(n,t,e){let s=`firestore_mutations_${n}_${e}`;return t.isAuthenticated()&&(s+=`_${t.uid}`),s}function Uc(n,t){return`firestore_targets_${n}_${t}`}class ga{constructor(t,e,s,i){this.user=t,this.batchId=e,this.state=s,this.error=i}static Es(t,e,s){const i=JSON.parse(s);let r,o=typeof i=="object"&&["pending","acknowledged","rejected"].indexOf(i.state)!==-1&&(i.error===void 0||typeof i.error=="object");return o&&i.error&&(o=typeof i.error.message=="string"&&typeof i.error.code=="string",o&&(r=new U(i.error.code,i.error.message))),o?new ga(t,e,i.state,r):(Lt("SharedClientState",`Failed to parse mutation state for ID '${e}': ${s}`),null)}ds(){const t={state:this.state,updateTimeMs:Date.now()};return this.error&&(t.error={code:this.error.code,message:this.error.message}),JSON.stringify(t)}}class yr{constructor(t,e,s){this.targetId=t,this.state=e,this.error=s}static Es(t,e){const s=JSON.parse(e);let i,r=typeof s=="object"&&["not-current","current","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return r&&s.error&&(r=typeof s.error.message=="string"&&typeof s.error.code=="string",r&&(i=new U(s.error.code,s.error.message))),r?new yr(t,s.state,i):(Lt("SharedClientState",`Failed to parse target state for ID '${t}': ${e}`),null)}ds(){const t={state:this.state,updateTimeMs:Date.now()};return this.error&&(t.error={code:this.error.code,message:this.error.message}),JSON.stringify(t)}}class ya{constructor(t,e){this.clientId=t,this.activeTargetIds=e}static Es(t,e){const s=JSON.parse(e);let i=typeof s=="object"&&s.activeTargetIds instanceof Array,r=ou();for(let o=0;i&&o<s.activeTargetIds.length;++o)i=Mm(s.activeTargetIds[o]),r=r.add(s.activeTargetIds[o]);return i?new ya(t,r):(Lt("SharedClientState",`Failed to parse client data for instance '${t}': ${e}`),null)}}class yu{constructor(t,e){this.clientId=t,this.onlineState=e}static Es(t){const e=JSON.parse(t);return typeof e=="object"&&["Unknown","Online","Offline"].indexOf(e.onlineState)!==-1&&typeof e.clientId=="string"?new yu(e.clientId,e.onlineState):(Lt("SharedClientState",`Failed to parse online state: ${t}`),null)}}class Tl{constructor(){this.activeTargetIds=ou()}As(t){this.activeTargetIds=this.activeTargetIds.add(t)}Rs(t){this.activeTargetIds=this.activeTargetIds.delete(t)}ds(){const t={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(t)}}class qc{constructor(t,e,s,i,r){this.window=t,this.oi=e,this.persistenceKey=s,this.Vs=i,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.fs=this.gs.bind(this),this.ps=new At(nt),this.started=!1,this.ys=[];const o=s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=r,this.ws=kf(this.persistenceKey,this.Vs),this.Ss=function(l){return`firestore_sequence_number_${l}`}(this.persistenceKey),this.ps=this.ps.insert(this.Vs,new Tl),this.bs=new RegExp(`^firestore_clients_${o}_([^_]*)$`),this.Ds=new RegExp(`^firestore_mutations_${o}_(\\d+)(?:_(.*))?$`),this.Cs=new RegExp(`^firestore_targets_${o}_(\\d+)$`),this.vs=function(l){return`firestore_online_state_${l}`}(this.persistenceKey),this.Fs=function(l){return`firestore_bundle_loaded_v2_${l}`}(this.persistenceKey),this.window.addEventListener("storage",this.fs)}static D(t){return!(!t||!t.localStorage)}async start(){const t=await this.syncEngine.Bi();for(const s of t){if(s===this.Vs)continue;const i=this.getItem(kf(this.persistenceKey,s));if(i){const r=ya.Es(s,i);r&&(this.ps=this.ps.insert(r.clientId,r))}}this.Ms();const e=this.storage.getItem(this.vs);if(e){const s=this.xs(e);s&&this.Os(s)}for(const s of this.ys)this.gs(s);this.ys=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(t){this.setItem(this.Ss,JSON.stringify(t))}getAllActiveQueryTargets(){return this.Ns(this.ps)}isActiveQueryTarget(t){let e=!1;return this.ps.forEach((s,i)=>{i.activeTargetIds.has(t)&&(e=!0)}),e}addPendingMutation(t){this.Ls(t,"pending")}updateMutationState(t,e,s){this.Ls(t,e,s),this.Bs(t)}addLocalQueryTarget(t){let e="not-current";if(this.isActiveQueryTarget(t)){const s=this.storage.getItem(Uc(this.persistenceKey,t));if(s){const i=yr.Es(t,s);i&&(e=i.state)}}return this.ks.As(t),this.Ms(),e}removeLocalQueryTarget(t){this.ks.Rs(t),this.Ms()}isLocalQueryTarget(t){return this.ks.activeTargetIds.has(t)}clearQueryState(t){this.removeItem(Uc(this.persistenceKey,t))}updateQueryState(t,e,s){this.qs(t,e,s)}handleUserChange(t,e,s){e.forEach(i=>{this.Bs(i)}),this.currentUser=t,s.forEach(i=>{this.addPendingMutation(i)})}setOnlineState(t){this.Qs(t)}notifyBundleLoaded(t){this.Ks(t)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.fs),this.removeItem(this.ws),this.started=!1)}getItem(t){const e=this.storage.getItem(t);return N("SharedClientState","READ",t,e),e}setItem(t,e){N("SharedClientState","SET",t,e),this.storage.setItem(t,e)}removeItem(t){N("SharedClientState","REMOVE",t),this.storage.removeItem(t)}gs(t){const e=t;if(e.storageArea===this.storage){if(N("SharedClientState","EVENT",e.key,e.newValue),e.key===this.ws)return void Lt("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.oi.enqueueRetryable(async()=>{if(this.started){if(e.key!==null){if(this.bs.test(e.key)){if(e.newValue==null){const s=this.$s(e.key);return this.Us(s,null)}{const s=this.Ws(e.key,e.newValue);if(s)return this.Us(s.clientId,s)}}else if(this.Ds.test(e.key)){if(e.newValue!==null){const s=this.Gs(e.key,e.newValue);if(s)return this.zs(s)}}else if(this.Cs.test(e.key)){if(e.newValue!==null){const s=this.js(e.key,e.newValue);if(s)return this.Hs(s)}}else if(e.key===this.vs){if(e.newValue!==null){const s=this.xs(e.newValue);if(s)return this.Os(s)}}else if(e.key===this.Ss){const s=function(r){let o=_e.oe;if(r!=null)try{const a=JSON.parse(r);X(typeof a=="number"),o=a}catch(a){Lt("SharedClientState","Failed to read sequence number from WebStorage",a)}return o}(e.newValue);s!==_e.oe&&this.sequenceNumberHandler(s)}else if(e.key===this.Fs){const s=this.Js(e.newValue);await Promise.all(s.map(i=>this.syncEngine.Ys(i)))}}}else this.ys.push(e)})}}get ks(){return this.ps.get(this.Vs)}Ms(){this.setItem(this.ws,this.ks.ds())}Ls(t,e,s){const i=new ga(this.currentUser,t,e,s),r=Rf(this.persistenceKey,this.currentUser,t);this.setItem(r,i.ds())}Bs(t){const e=Rf(this.persistenceKey,this.currentUser,t);this.removeItem(e)}Qs(t){const e={clientId:this.Vs,onlineState:t};this.storage.setItem(this.vs,JSON.stringify(e))}qs(t,e,s){const i=Uc(this.persistenceKey,t),r=new yr(t,e,s);this.setItem(i,r.ds())}Ks(t){const e=JSON.stringify(Array.from(t));this.setItem(this.Fs,e)}$s(t){const e=this.bs.exec(t);return e?e[1]:null}Ws(t,e){const s=this.$s(t);return ya.Es(s,e)}Gs(t,e){const s=this.Ds.exec(t),i=Number(s[1]),r=s[2]!==void 0?s[2]:null;return ga.Es(new re(r),i,e)}js(t,e){const s=this.Cs.exec(t),i=Number(s[1]);return yr.Es(i,e)}xs(t){return yu.Es(t)}Js(t){return JSON.parse(t)}async zs(t){if(t.user.uid===this.currentUser.uid)return this.syncEngine.Zs(t.batchId,t.state,t.error);N("SharedClientState",`Ignoring mutation for non-active user ${t.user.uid}`)}Hs(t){return this.syncEngine.Xs(t.targetId,t.state,t.error)}Us(t,e){const s=e?this.ps.insert(t,e):this.ps.remove(t),i=this.Ns(this.ps),r=this.Ns(s),o=[],a=[];return r.forEach(l=>{i.has(l)||o.push(l)}),i.forEach(l=>{r.has(l)||a.push(l)}),this.syncEngine.eo(o,a).then(()=>{this.ps=s})}Os(t){this.ps.get(t.clientId)&&this.onlineStateHandler(t.onlineState)}Ns(t){let e=ou();return t.forEach((s,i)=>{e=e.unionWith(i.activeTargetIds)}),e}}class Yg{constructor(){this.no=new Tl,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(t){}updateMutationState(t,e,s){}addLocalQueryTarget(t){return this.no.As(t),this.ro[t]||"not-current"}updateQueryState(t,e,s){this.ro[t]=e}removeLocalQueryTarget(t){this.no.Rs(t)}isLocalQueryTarget(t){return this.no.activeTargetIds.has(t)}clearQueryState(t){delete this.ro[t]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(t){return this.no.activeTargetIds.has(t)}start(){return this.no=new Tl,Promise.resolve()}handleUserChange(t,e,s){}setOnlineState(t){}shutdown(){}writeSequenceNumber(t){}notifyBundleLoaded(t){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class e0{io(t){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pf{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(t){this.uo.push(t)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){N("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const t of this.uo)t(0)}ao(){N("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const t of this.uo)t(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Do=null;function Bc(){return Do===null?Do=function(){return 268435456+Math.round(2147483648*Math.random())}():Do++,"0x"+Do.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const n0={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class s0{constructor(t){this.lo=t.lo,this.ho=t.ho}Po(t){this.Io=t}To(t){this.Eo=t}Ao(t){this.Ro=t}onMessage(t){this.Vo=t}close(){this.ho()}send(t){this.lo(t)}mo(){this.Io()}fo(){this.Eo()}po(t){this.Ro(t)}yo(t){this.Vo(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ie="WebChannelConnection";class i0 extends class{constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const s=e.ssl?"https":"http",i=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.wo=s+"://"+e.host,this.So=`projects/${i}/databases/${r}`,this.bo=this.databaseId.database==="(default)"?`project_id=${i}`:`project_id=${i}&database_id=${r}`}get Do(){return!1}Co(e,s,i,r,o){const a=Bc(),l=this.vo(e,s.toUriEncodedString());N("RestConnection",`Sending RPC '${e}' ${a}:`,l,i);const u={"google-cloud-resource-prefix":this.So,"x-goog-request-params":this.bo};return this.Fo(u,r,o),this.Mo(e,l,u,i).then(h=>(N("RestConnection",`Received RPC '${e}' ${a}: `,h),h),h=>{throw Sr("RestConnection",`RPC '${e}' ${a} failed with error: `,h,"url: ",l,"request:",i),h})}xo(e,s,i,r,o,a){return this.Co(e,s,i,r,o)}Fo(e,s,i){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+ki}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),s&&s.headers.forEach((r,o)=>e[o]=r),i&&i.headers.forEach((r,o)=>e[o]=r)}vo(e,s){const i=n0[e];return`${this.wo}/v1/${s}:${i}`}terminate(){}}{constructor(t){super(t),this.forceLongPolling=t.forceLongPolling,this.autoDetectLongPolling=t.autoDetectLongPolling,this.useFetchStreams=t.useFetchStreams,this.longPollingOptions=t.longPollingOptions}Mo(t,e,s,i){const r=Bc();return new Promise((o,a)=>{const l=new Tm;l.setWithCredentials(!0),l.listenOnce(Sm.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case Uo.NO_ERROR:const h=l.getResponseJson();N(ie,`XHR for RPC '${t}' ${r} received:`,JSON.stringify(h)),o(h);break;case Uo.TIMEOUT:N(ie,`RPC '${t}' ${r} timed out`),a(new U(V.DEADLINE_EXCEEDED,"Request time out"));break;case Uo.HTTP_ERROR:const p=l.getStatus();if(N(ie,`RPC '${t}' ${r} failed with status:`,p,"response text:",l.getResponseText()),p>0){let m=l.getResponseJson();Array.isArray(m)&&(m=m[0]);const I=m==null?void 0:m.error;if(I&&I.status&&I.message){const E=function(R){const B=R.toLowerCase().replace(/_/g,"-");return Object.values(V).indexOf(B)>=0?B:V.UNKNOWN}(I.status);a(new U(E,I.message))}else a(new U(V.UNKNOWN,"Server responded with status "+l.getStatus()))}else a(new U(V.UNAVAILABLE,"Connection failed."));break;default:G()}}finally{N(ie,`RPC '${t}' ${r} completed.`)}});const u=JSON.stringify(i);N(ie,`RPC '${t}' ${r} sending request:`,i),l.send(e,"POST",u,s,15)})}Oo(t,e,s){const i=Bc(),r=[this.wo,"/","google.firestore.v1.Firestore","/",t,"/channel"],o=Pm(),a=Rm(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.xmlHttpFactory=new Am({})),this.Fo(l.initMessageHeaders,e,s),l.encodeInitMessageHeaders=!0;const h=r.join("");N(ie,`Creating RPC '${t}' stream ${i}: ${h}`,l);const p=o.createWebChannel(h,l);let m=!1,I=!1;const E=new s0({lo:R=>{I?N(ie,`Not sending because RPC '${t}' stream ${i} is closed:`,R):(m||(N(ie,`Opening RPC '${t}' stream ${i} transport.`),p.open(),m=!0),N(ie,`RPC '${t}' stream ${i} sending:`,R),p.send(R))},ho:()=>p.close()}),$=(R,B,H)=>{R.listen(B,K=>{try{H(K)}catch(st){setTimeout(()=>{throw st},0)}})};return $(p,or.EventType.OPEN,()=>{I||(N(ie,`RPC '${t}' stream ${i} transport opened.`),E.mo())}),$(p,or.EventType.CLOSE,()=>{I||(I=!0,N(ie,`RPC '${t}' stream ${i} transport closed`),E.po())}),$(p,or.EventType.ERROR,R=>{I||(I=!0,Sr(ie,`RPC '${t}' stream ${i} transport errored:`,R),E.po(new U(V.UNAVAILABLE,"The operation could not be completed")))}),$(p,or.EventType.MESSAGE,R=>{var B;if(!I){const H=R.data[0];X(!!H);const K=H,st=K.error||((B=K[0])===null||B===void 0?void 0:B.error);if(st){N(ie,`RPC '${t}' stream ${i} received error:`,st);const x=st.status;let L=function(v){const w=Ft[v];if(w!==void 0)return yg(w)}(x),b=st.message;L===void 0&&(L=V.INTERNAL,b="Unknown error status: "+x+" with message "+st.message),I=!0,E.po(new U(L,b)),p.close()}else N(ie,`RPC '${t}' stream ${i} received:`,H),E.yo(H)}}),$(a,km.STAT_EVENT,R=>{R.stat===ol.PROXY?N(ie,`RPC '${t}' stream ${i} detected buffering proxy`):R.stat===ol.NOPROXY&&N(ie,`RPC '${t}' stream ${i} detected no buffering proxy`)}),setTimeout(()=>{E.fo()},0),E}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xg(){return typeof window<"u"?window:null}function Wo(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ga(n){return new fT(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zg{constructor(t,e,s=1e3,i=1.5,r=6e4){this.oi=t,this.timerId=e,this.No=s,this.Lo=i,this.Bo=r,this.ko=0,this.qo=null,this.Qo=Date.now(),this.reset()}reset(){this.ko=0}Ko(){this.ko=this.Bo}$o(t){this.cancel();const e=Math.floor(this.ko+this.Uo()),s=Math.max(0,Date.now()-this.Qo),i=Math.max(0,e-s);i>0&&N("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.ko} ms, delay with jitter: ${e} ms, last attempt: ${s} ms ago)`),this.qo=this.oi.enqueueAfterDelay(this.timerId,i,()=>(this.Qo=Date.now(),t())),this.ko*=this.Lo,this.ko<this.No&&(this.ko=this.No),this.ko>this.Bo&&(this.ko=this.Bo)}Wo(){this.qo!==null&&(this.qo.skipDelay(),this.qo=null)}cancel(){this.qo!==null&&(this.qo.cancel(),this.qo=null)}Uo(){return(Math.random()-.5)*this.ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ty{constructor(t,e,s,i,r,o,a,l){this.oi=t,this.Go=s,this.zo=i,this.connection=r,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=l,this.state=0,this.jo=0,this.Ho=null,this.Jo=null,this.stream=null,this.Yo=new Zg(t,e)}Zo(){return this.state===1||this.state===5||this.Xo()}Xo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.e_()}async stop(){this.Zo()&&await this.close(0)}t_(){this.state=0,this.Yo.reset()}n_(){this.Xo()&&this.Ho===null&&(this.Ho=this.oi.enqueueAfterDelay(this.Go,6e4,()=>this.r_()))}i_(t){this.s_(),this.stream.send(t)}async r_(){if(this.Xo())return this.close(0)}s_(){this.Ho&&(this.Ho.cancel(),this.Ho=null)}o_(){this.Jo&&(this.Jo.cancel(),this.Jo=null)}async close(t,e){this.s_(),this.o_(),this.Yo.cancel(),this.jo++,t!==4?this.Yo.reset():e&&e.code===V.RESOURCE_EXHAUSTED?(Lt(e.toString()),Lt("Using maximum backoff delay to prevent overloading the backend."),this.Yo.Ko()):e&&e.code===V.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.__(),this.stream.close(),this.stream=null),this.state=t,await this.listener.Ao(e)}__(){}auth(){this.state=1;const t=this.a_(this.jo),e=this.jo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([s,i])=>{this.jo===e&&this.u_(s,i)},s=>{t(()=>{const i=new U(V.UNKNOWN,"Fetching auth token failed: "+s.message);return this.c_(i)})})}u_(t,e){const s=this.a_(this.jo);this.stream=this.l_(t,e),this.stream.Po(()=>{s(()=>this.listener.Po())}),this.stream.To(()=>{s(()=>(this.state=2,this.Jo=this.oi.enqueueAfterDelay(this.zo,1e4,()=>(this.Xo()&&(this.state=3),Promise.resolve())),this.listener.To()))}),this.stream.Ao(i=>{s(()=>this.c_(i))}),this.stream.onMessage(i=>{s(()=>this.onMessage(i))})}e_(){this.state=5,this.Yo.$o(async()=>{this.state=0,this.start()})}c_(t){return N("PersistentStream",`close with error: ${t}`),this.stream=null,this.close(4,t)}a_(t){return e=>{this.oi.enqueueAndForget(()=>this.jo===t?e():(N("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class r0 extends ty{constructor(t,e,s,i,r,o){super(t,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",e,s,i,o),this.serializer=r}l_(t,e){return this.connection.Oo("Listen",t,e)}onMessage(t){this.Yo.reset();const e=gT(this.serializer,t),s=function(r){if(!("targetChange"in r))return Z.min();const o=r.targetChange;return o.targetIds&&o.targetIds.length?Z.min():o.readTime?pe(o.readTime):Z.min()}(t);return this.listener.h_(e,s)}P_(t){const e={};e.database=vl(this.serializer),e.addTarget=function(r,o){let a;const l=o.target;if(a=ca(l)?{documents:Ag(r,l)}:{query:Sg(r,l)._t},a.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){a.resumeToken=bg(r,o.resumeToken);const u=gl(r,o.expectedCount);u!==null&&(a.expectedCount=u)}else if(o.snapshotVersion.compareTo(Z.min())>0){a.readTime=hi(r,o.snapshotVersion.toTimestamp());const u=gl(r,o.expectedCount);u!==null&&(a.expectedCount=u)}return a}(this.serializer,t);const s=vT(this.serializer,t);s&&(e.labels=s),this.i_(e)}I_(t){const e={};e.database=vl(this.serializer),e.removeTarget=t,this.i_(e)}}class o0 extends ty{constructor(t,e,s,i,r,o){super(t,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",e,s,i,o),this.serializer=r,this.T_=!1}get E_(){return this.T_}start(){this.T_=!1,this.lastStreamToken=void 0,super.start()}__(){this.T_&&this.d_([])}l_(t,e){return this.connection.Oo("Write",t,e)}onMessage(t){if(X(!!t.streamToken),this.lastStreamToken=t.streamToken,this.T_){this.Yo.reset();const e=yT(t.writeResults,t.commitTime),s=pe(t.commitTime);return this.listener.A_(s,e)}return X(!t.writeResults||t.writeResults.length===0),this.T_=!0,this.listener.R_()}V_(){const t={};t.database=vl(this.serializer),this.i_(t)}d_(t){const e={streamToken:this.lastStreamToken,writes:t.map(s=>da(this.serializer,s))};this.i_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class a0 extends class{}{constructor(t,e,s,i){super(),this.authCredentials=t,this.appCheckCredentials=e,this.connection=s,this.serializer=i,this.m_=!1}f_(){if(this.m_)throw new U(V.FAILED_PRECONDITION,"The client has already been terminated.")}Co(t,e,s,i){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([r,o])=>this.connection.Co(t,yl(e,s),i,r,o)).catch(r=>{throw r.name==="FirebaseError"?(r.code===V.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),r):new U(V.UNKNOWN,r.toString())})}xo(t,e,s,i,r){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,a])=>this.connection.xo(t,yl(e,s),i,o,a,r)).catch(o=>{throw o.name==="FirebaseError"?(o.code===V.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new U(V.UNKNOWN,o.toString())})}terminate(){this.m_=!0,this.connection.terminate()}}class c0{constructor(t,e){this.asyncQueue=t,this.onlineStateHandler=e,this.state="Unknown",this.g_=0,this.p_=null,this.y_=!0}w_(){this.g_===0&&(this.S_("Unknown"),this.p_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.p_=null,this.b_("Backend didn't respond within 10 seconds."),this.S_("Offline"),Promise.resolve())))}D_(t){this.state==="Online"?this.S_("Unknown"):(this.g_++,this.g_>=1&&(this.C_(),this.b_(`Connection failed 1 times. Most recent error: ${t.toString()}`),this.S_("Offline")))}set(t){this.C_(),this.g_=0,t==="Online"&&(this.y_=!1),this.S_(t)}S_(t){t!==this.state&&(this.state=t,this.onlineStateHandler(t))}b_(t){const e=`Could not reach Cloud Firestore backend. ${t}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.y_?(Lt(e),this.y_=!1):N("OnlineStateTracker",e)}C_(){this.p_!==null&&(this.p_.cancel(),this.p_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class l0{constructor(t,e,s,i,r){this.localStore=t,this.datastore=e,this.asyncQueue=s,this.remoteSyncer={},this.v_=[],this.F_=new Map,this.M_=new Set,this.x_=[],this.O_=r,this.O_.io(o=>{s.enqueueAndForget(async()=>{ks(this)&&(N("RemoteStore","Restarting streams for network reachability change."),await async function(l){const u=W(l);u.M_.add(4),await to(u),u.N_.set("Unknown"),u.M_.delete(4),await Ka(u)}(this))})}),this.N_=new c0(s,i)}}async function Ka(n){if(ks(n))for(const t of n.x_)await t(!0)}async function to(n){for(const t of n.x_)await t(!1)}function Wa(n,t){const e=W(n);e.F_.has(t.targetId)||(e.F_.set(t.targetId,t),bu(e)?_u(e):Ci(e).Xo()&&vu(e,t))}function pi(n,t){const e=W(n),s=Ci(e);e.F_.delete(t),s.Xo()&&ey(e,t),e.F_.size===0&&(s.Xo()?s.n_():ks(e)&&e.N_.set("Unknown"))}function vu(n,t){if(n.L_.xe(t.targetId),t.resumeToken.approximateByteSize()>0||t.snapshotVersion.compareTo(Z.min())>0){const e=n.remoteSyncer.getRemoteKeysForTarget(t.targetId).size;t=t.withExpectedCount(e)}Ci(n).P_(t)}function ey(n,t){n.L_.xe(t),Ci(n).I_(t)}function _u(n){n.L_=new lT({getRemoteKeysForTarget:t=>n.remoteSyncer.getRemoteKeysForTarget(t),ot:t=>n.F_.get(t)||null,tt:()=>n.datastore.serializer.databaseId}),Ci(n).start(),n.N_.w_()}function bu(n){return ks(n)&&!Ci(n).Zo()&&n.F_.size>0}function ks(n){return W(n).M_.size===0}function ny(n){n.L_=void 0}async function u0(n){n.N_.set("Online")}async function d0(n){n.F_.forEach((t,e)=>{vu(n,t)})}async function h0(n,t){ny(n),bu(n)?(n.N_.D_(t),_u(n)):n.N_.set("Unknown")}async function f0(n,t,e){if(n.N_.set("Online"),t instanceof _g&&t.state===2&&t.cause)try{await async function(i,r){const o=r.cause;for(const a of r.targetIds)i.F_.has(a)&&(await i.remoteSyncer.rejectListen(a,o),i.F_.delete(a),i.L_.removeTarget(a))}(n,t)}catch(s){N("RemoteStore","Failed to remove targets %s: %s ",t.targetIds.join(","),s),await va(n,s)}else if(t instanceof Ko?n.L_.Ke(t):t instanceof vg?n.L_.He(t):n.L_.We(t),!e.isEqual(Z.min()))try{const s=await Wg(n.localStore);e.compareTo(s)>=0&&await function(r,o){const a=r.L_.rt(o);return a.targetChanges.forEach((l,u)=>{if(l.resumeToken.approximateByteSize()>0){const h=r.F_.get(u);h&&r.F_.set(u,h.withResumeToken(l.resumeToken,o))}}),a.targetMismatches.forEach((l,u)=>{const h=r.F_.get(l);if(!h)return;r.F_.set(l,h.withResumeToken(Qt.EMPTY_BYTE_STRING,h.snapshotVersion)),ey(r,l);const p=new on(h.target,l,u,h.sequenceNumber);vu(r,p)}),r.remoteSyncer.applyRemoteEvent(a)}(n,e)}catch(s){N("RemoteStore","Failed to raise snapshot:",s),await va(n,s)}}async function va(n,t,e){if(!Wn(t))throw t;n.M_.add(1),await to(n),n.N_.set("Offline"),e||(e=()=>Wg(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{N("RemoteStore","Retrying IndexedDB access"),await e(),n.M_.delete(1),await Ka(n)})}function sy(n,t){return t().catch(e=>va(n,e,t))}async function Pi(n){const t=W(n),e=jn(t);let s=t.v_.length>0?t.v_[t.v_.length-1].batchId:-1;for(;p0(t);)try{const i=await t0(t.localStore,s);if(i===null){t.v_.length===0&&e.n_();break}s=i.batchId,m0(t,i)}catch(i){await va(t,i)}iy(t)&&ry(t)}function p0(n){return ks(n)&&n.v_.length<10}function m0(n,t){n.v_.push(t);const e=jn(n);e.Xo()&&e.E_&&e.d_(t.mutations)}function iy(n){return ks(n)&&!jn(n).Zo()&&n.v_.length>0}function ry(n){jn(n).start()}async function g0(n){jn(n).V_()}async function y0(n){const t=jn(n);for(const e of n.v_)t.d_(e.mutations)}async function v0(n,t,e){const s=n.v_.shift(),i=cu.from(s,t,e);await sy(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await Pi(n)}async function _0(n,t){t&&jn(n).E_&&await async function(s,i){if(function(o){return oT(o)&&o!==V.ABORTED}(i.code)){const r=s.v_.shift();jn(s).t_(),await sy(s,()=>s.remoteSyncer.rejectFailedWrite(r.batchId,i)),await Pi(s)}}(n,t),iy(n)&&ry(n)}async function Cf(n,t){const e=W(n);e.asyncQueue.verifyOperationInProgress(),N("RemoteStore","RemoteStore received new credentials");const s=ks(e);e.M_.add(3),await to(e),s&&e.N_.set("Unknown"),await e.remoteSyncer.handleCredentialChange(t),e.M_.delete(3),await Ka(e)}async function Al(n,t){const e=W(n);t?(e.M_.delete(2),await Ka(e)):t||(e.M_.add(2),await to(e),e.N_.set("Unknown"))}function Ci(n){return n.B_||(n.B_=function(e,s,i){const r=W(e);return r.f_(),new r0(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:u0.bind(null,n),To:d0.bind(null,n),Ao:h0.bind(null,n),h_:f0.bind(null,n)}),n.x_.push(async t=>{t?(n.B_.t_(),bu(n)?_u(n):n.N_.set("Unknown")):(await n.B_.stop(),ny(n))})),n.B_}function jn(n){return n.k_||(n.k_=function(e,s,i){const r=W(e);return r.f_(),new o0(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:()=>Promise.resolve(),To:g0.bind(null,n),Ao:_0.bind(null,n),R_:y0.bind(null,n),A_:v0.bind(null,n)}),n.x_.push(async t=>{t?(n.k_.t_(),await Pi(n)):(await n.k_.stop(),n.v_.length>0&&(N("RemoteStore",`Stopping write stream with ${n.v_.length} pending writes`),n.v_=[]))})),n.k_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wu{constructor(t,e,s,i,r){this.asyncQueue=t,this.timerId=e,this.targetTimeMs=s,this.op=i,this.removalCallback=r,this.deferred=new Vn,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(t,e,s,i,r){const o=Date.now()+s,a=new wu(t,e,o,i,r);return a.start(s),a}start(t){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),t)}skipDelay(){return this.handleDelayElapsed()}cancel(t){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new U(V.CANCELLED,"Operation cancelled"+(t?": "+t:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(t=>this.deferred.resolve(t))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Iu(n,t){if(Lt("AsyncQueue",`${t}: ${n}`),Wn(n))return new U(V.UNAVAILABLE,`${t}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ti{constructor(t){this.comparator=t?(e,s)=>t(e,s)||q.comparator(e.key,s.key):(e,s)=>q.comparator(e.key,s.key),this.keyedMap=ar(),this.sortedSet=new At(this.comparator)}static emptySet(t){return new ti(t.comparator)}has(t){return this.keyedMap.get(t)!=null}get(t){return this.keyedMap.get(t)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(t){const e=this.keyedMap.get(t);return e?this.sortedSet.indexOf(e):-1}get size(){return this.sortedSet.size}forEach(t){this.sortedSet.inorderTraversal((e,s)=>(t(e),!1))}add(t){const e=this.delete(t.key);return e.copy(e.keyedMap.insert(t.key,t),e.sortedSet.insert(t,null))}delete(t){const e=this.get(t);return e?this.copy(this.keyedMap.remove(t),this.sortedSet.remove(e)):this}isEqual(t){if(!(t instanceof ti)||this.size!==t.size)return!1;const e=this.sortedSet.getIterator(),s=t.sortedSet.getIterator();for(;e.hasNext();){const i=e.getNext().key,r=s.getNext().key;if(!i.isEqual(r))return!1}return!0}toString(){const t=[];return this.forEach(e=>{t.push(e.toString())}),t.length===0?"DocumentSet ()":`DocumentSet (
  `+t.join(`  
`)+`
)`}copy(t,e){const s=new ti;return s.comparator=this.comparator,s.keyedMap=t,s.sortedSet=e,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Df{constructor(){this.q_=new At(q.comparator)}track(t){const e=t.doc.key,s=this.q_.get(e);s?t.type!==0&&s.type===3?this.q_=this.q_.insert(e,t):t.type===3&&s.type!==1?this.q_=this.q_.insert(e,{type:s.type,doc:t.doc}):t.type===2&&s.type===2?this.q_=this.q_.insert(e,{type:2,doc:t.doc}):t.type===2&&s.type===0?this.q_=this.q_.insert(e,{type:0,doc:t.doc}):t.type===1&&s.type===0?this.q_=this.q_.remove(e):t.type===1&&s.type===2?this.q_=this.q_.insert(e,{type:1,doc:s.doc}):t.type===0&&s.type===1?this.q_=this.q_.insert(e,{type:2,doc:t.doc}):G():this.q_=this.q_.insert(e,t)}Q_(){const t=[];return this.q_.inorderTraversal((e,s)=>{t.push(s)}),t}}class mi{constructor(t,e,s,i,r,o,a,l,u){this.query=t,this.docs=e,this.oldDocs=s,this.docChanges=i,this.mutatedKeys=r,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=l,this.hasCachedResults=u}static fromInitialDocuments(t,e,s,i,r){const o=[];return e.forEach(a=>{o.push({type:0,doc:a})}),new mi(t,e,ti.emptySet(e),o,s,i,!0,!1,r)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(t){if(!(this.fromCache===t.fromCache&&this.hasCachedResults===t.hasCachedResults&&this.syncStateChanged===t.syncStateChanged&&this.mutatedKeys.isEqual(t.mutatedKeys)&&La(this.query,t.query)&&this.docs.isEqual(t.docs)&&this.oldDocs.isEqual(t.oldDocs)))return!1;const e=this.docChanges,s=t.docChanges;if(e.length!==s.length)return!1;for(let i=0;i<e.length;i++)if(e[i].type!==s[i].type||!e[i].doc.isEqual(s[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class b0{constructor(){this.K_=void 0,this.U_=[]}W_(){return this.U_.some(t=>t.G_())}}class w0{constructor(){this.queries=new Hn(t=>ng(t),La),this.onlineState="Unknown",this.z_=new Set}}async function I0(n,t){const e=W(n);let s=3;const i=t.query;let r=e.queries.get(i);r?!r.W_()&&t.G_()&&(s=2):(r=new b0,s=t.G_()?0:1);try{switch(s){case 0:r.K_=await e.onListen(i,!0);break;case 1:r.K_=await e.onListen(i,!1);break;case 2:await e.onFirstRemoteStoreListen(i)}}catch(o){const a=Iu(o,`Initialization of query '${zs(t.query)}' failed`);return void t.onError(a)}e.queries.set(i,r),r.U_.push(t),t.j_(e.onlineState),r.K_&&t.H_(r.K_)&&Eu(e)}async function E0(n,t){const e=W(n),s=t.query;let i=3;const r=e.queries.get(s);if(r){const o=r.U_.indexOf(t);o>=0&&(r.U_.splice(o,1),r.U_.length===0?i=t.G_()?0:1:!r.W_()&&t.G_()&&(i=2))}switch(i){case 0:return e.queries.delete(s),e.onUnlisten(s,!0);case 1:return e.queries.delete(s),e.onUnlisten(s,!1);case 2:return e.onLastRemoteStoreUnlisten(s);default:return}}function T0(n,t){const e=W(n);let s=!1;for(const i of t){const r=i.query,o=e.queries.get(r);if(o){for(const a of o.U_)a.H_(i)&&(s=!0);o.K_=i}}s&&Eu(e)}function A0(n,t,e){const s=W(n),i=s.queries.get(t);if(i)for(const r of i.U_)r.onError(e);s.queries.delete(t)}function Eu(n){n.z_.forEach(t=>{t.next()})}var Sl,$f;($f=Sl||(Sl={})).J_="default",$f.Cache="cache";class S0{constructor(t,e,s){this.query=t,this.Y_=e,this.Z_=!1,this.X_=null,this.onlineState="Unknown",this.options=s||{}}H_(t){if(!this.options.includeMetadataChanges){const s=[];for(const i of t.docChanges)i.type!==3&&s.push(i);t=new mi(t.query,t.docs,t.oldDocs,s,t.mutatedKeys,t.fromCache,t.syncStateChanged,!0,t.hasCachedResults)}let e=!1;return this.Z_?this.ea(t)&&(this.Y_.next(t),e=!0):this.ta(t,this.onlineState)&&(this.na(t),e=!0),this.X_=t,e}onError(t){this.Y_.error(t)}j_(t){this.onlineState=t;let e=!1;return this.X_&&!this.Z_&&this.ta(this.X_,t)&&(this.na(this.X_),e=!0),e}ta(t,e){if(!t.fromCache||!this.G_())return!0;const s=e!=="Offline";return(!this.options.ra||!s)&&(!t.docs.isEmpty()||t.hasCachedResults||e==="Offline")}ea(t){if(t.docChanges.length>0)return!0;const e=this.X_&&this.X_.hasPendingWrites!==t.hasPendingWrites;return!(!t.syncStateChanged&&!e)&&this.options.includeMetadataChanges===!0}na(t){t=mi.fromInitialDocuments(t.query,t.docs,t.mutatedKeys,t.fromCache,t.hasCachedResults),this.Z_=!0,this.Y_.next(t)}G_(){return this.options.source!==Sl.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oy{constructor(t){this.key=t}}class ay{constructor(t){this.key=t}}class k0{constructor(t,e){this.query=t,this.la=e,this.ha=null,this.hasCachedResults=!1,this.current=!1,this.Pa=rt(),this.mutatedKeys=rt(),this.Ia=ig(t),this.Ta=new ti(this.Ia)}get Ea(){return this.la}da(t,e){const s=e?e.Aa:new Df,i=e?e.Ta:this.Ta;let r=e?e.mutatedKeys:this.mutatedKeys,o=i,a=!1;const l=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,u=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(t.inorderTraversal((h,p)=>{const m=i.get(h),I=Yr(this.query,p)?p:null,E=!!m&&this.mutatedKeys.has(m.key),$=!!I&&(I.hasLocalMutations||this.mutatedKeys.has(I.key)&&I.hasCommittedMutations);let R=!1;m&&I?m.data.isEqual(I.data)?E!==$&&(s.track({type:3,doc:I}),R=!0):this.Ra(m,I)||(s.track({type:2,doc:I}),R=!0,(l&&this.Ia(I,l)>0||u&&this.Ia(I,u)<0)&&(a=!0)):!m&&I?(s.track({type:0,doc:I}),R=!0):m&&!I&&(s.track({type:1,doc:m}),R=!0,(l||u)&&(a=!0)),R&&(I?(o=o.add(I),r=$?r.add(h):r.delete(h)):(o=o.delete(h),r=r.delete(h)))}),this.query.limit!==null)for(;o.size>this.query.limit;){const h=this.query.limitType==="F"?o.last():o.first();o=o.delete(h.key),r=r.delete(h.key),s.track({type:1,doc:h})}return{Ta:o,Aa:s,Xi:a,mutatedKeys:r}}Ra(t,e){return t.hasLocalMutations&&e.hasCommittedMutations&&!e.hasLocalMutations}applyChanges(t,e,s,i){const r=this.Ta;this.Ta=t.Ta,this.mutatedKeys=t.mutatedKeys;const o=t.Aa.Q_();o.sort((h,p)=>function(I,E){const $=R=>{switch(R){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return G()}};return $(I)-$(E)}(h.type,p.type)||this.Ia(h.doc,p.doc)),this.Va(s),i=i!=null&&i;const a=e&&!i?this.ma():[],l=this.Pa.size===0&&this.current&&!i?1:0,u=l!==this.ha;return this.ha=l,o.length!==0||u?{snapshot:new mi(this.query,t.Ta,r,o,t.mutatedKeys,l===0,u,!1,!!s&&s.resumeToken.approximateByteSize()>0),fa:a}:{fa:a}}j_(t){return this.current&&t==="Offline"?(this.current=!1,this.applyChanges({Ta:this.Ta,Aa:new Df,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{fa:[]}}ga(t){return!this.la.has(t)&&!!this.Ta.has(t)&&!this.Ta.get(t).hasLocalMutations}Va(t){t&&(t.addedDocuments.forEach(e=>this.la=this.la.add(e)),t.modifiedDocuments.forEach(e=>{}),t.removedDocuments.forEach(e=>this.la=this.la.delete(e)),this.current=t.current)}ma(){if(!this.current)return[];const t=this.Pa;this.Pa=rt(),this.Ta.forEach(s=>{this.ga(s.key)&&(this.Pa=this.Pa.add(s.key))});const e=[];return t.forEach(s=>{this.Pa.has(s)||e.push(new ay(s))}),this.Pa.forEach(s=>{t.has(s)||e.push(new oy(s))}),e}pa(t){this.la=t.hs,this.Pa=rt();const e=this.da(t.documents);return this.applyChanges(e,!0)}ya(){return mi.fromInitialDocuments(this.query,this.Ta,this.mutatedKeys,this.ha===0,this.hasCachedResults)}}class R0{constructor(t,e,s){this.query=t,this.targetId=e,this.view=s}}class P0{constructor(t){this.key=t,this.wa=!1}}class C0{constructor(t,e,s,i,r,o){this.localStore=t,this.remoteStore=e,this.eventManager=s,this.sharedClientState=i,this.currentUser=r,this.maxConcurrentLimboResolutions=o,this.Sa={},this.ba=new Hn(a=>ng(a),La),this.Da=new Map,this.Ca=new Set,this.va=new At(q.comparator),this.Fa=new Map,this.Ma=new pu,this.xa={},this.Oa=new Map,this.Na=Es.Ln(),this.onlineState="Unknown",this.La=void 0}get isPrimaryClient(){return this.La===!0}}async function D0(n,t,e=!0){const s=Ha(n);let i;const r=s.ba.get(t);return r?(s.sharedClientState.addLocalQueryTarget(r.targetId),i=r.view.ya()):i=await cy(s,t,e,!0),i}async function $0(n,t){const e=Ha(n);await cy(e,t,!0,!1)}async function cy(n,t,e,s){const i=await ma(n.localStore,Te(t)),r=i.targetId,o=e?n.sharedClientState.addLocalQueryTarget(r):"not-current";let a;return s&&(a=await Tu(n,t,r,o==="current",i.resumeToken)),n.isPrimaryClient&&e&&Wa(n.remoteStore,i),a}async function Tu(n,t,e,s,i){n.Ba=(p,m,I)=>async function($,R,B,H){let K=R.view.da(B);K.Xi&&(K=await El($.localStore,R.query,!1).then(({documents:b})=>R.view.da(b,K)));const st=H&&H.targetChanges.get(R.targetId),x=H&&H.targetMismatches.get(R.targetId)!=null,L=R.view.applyChanges(K,$.isPrimaryClient,st,x);return kl($,R.targetId,L.fa),L.snapshot}(n,p,m,I);const r=await El(n.localStore,t,!0),o=new k0(t,r.hs),a=o.da(r.documents),l=Zr.createSynthesizedTargetChangeForCurrentChange(e,s&&n.onlineState!=="Offline",i),u=o.applyChanges(a,n.isPrimaryClient,l);kl(n,e,u.fa);const h=new R0(t,e,o);return n.ba.set(t,h),n.Da.has(e)?n.Da.get(e).push(t):n.Da.set(e,[t]),u.snapshot}async function V0(n,t,e){const s=W(n),i=s.ba.get(t),r=s.Da.get(i.targetId);if(r.length>1)return s.Da.set(i.targetId,r.filter(o=>!La(o,t))),void s.ba.delete(t);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(i.targetId),s.sharedClientState.isActiveQueryTarget(i.targetId)||await fi(s.localStore,i.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(i.targetId),e&&pi(s.remoteStore,i.targetId),gi(s,i.targetId)}).catch(Kn)):(gi(s,i.targetId),await fi(s.localStore,i.targetId,!0))}async function N0(n,t){const e=W(n),s=e.ba.get(t),i=e.Da.get(s.targetId);e.isPrimaryClient&&i.length===1&&(e.sharedClientState.removeLocalQueryTarget(s.targetId),pi(e.remoteStore,s.targetId))}async function x0(n,t,e){const s=Ru(n);try{const i=await function(o,a){const l=W(o),u=Dt.now(),h=a.reduce((I,E)=>I.add(E.key),rt());let p,m;return l.persistence.runTransaction("Locally write mutations","readwrite",I=>{let E=Ee(),$=rt();return l.os.getEntries(I,h).next(R=>{E=R,E.forEach((B,H)=>{H.isValidDocument()||($=$.add(B))})}).next(()=>l.localDocuments.getOverlayedDocuments(I,E)).next(R=>{p=R;const B=[];for(const H of a){const K=iT(H,p.get(H.key).overlayedDocument);K!=null&&B.push(new hn(H.key,K,Km(K.value.mapValue),he.exists(!0)))}return l.mutationQueue.addMutationBatch(I,u,B,a)}).next(R=>{m=R;const B=R.applyToLocalDocumentSet(p,$);return l.documentOverlayCache.saveOverlays(I,R.batchId,B)})}).then(()=>({batchId:m.batchId,changes:og(p)}))}(s.localStore,t);s.sharedClientState.addPendingMutation(i.batchId),function(o,a,l){let u=o.xa[o.currentUser.toKey()];u||(u=new At(nt)),u=u.insert(a,l),o.xa[o.currentUser.toKey()]=u}(s,i.batchId,e),await Qn(s,i.changes),await Pi(s.remoteStore)}catch(i){const r=Iu(i,"Failed to persist write");e.reject(r)}}async function ly(n,t){const e=W(n);try{const s=await XT(e.localStore,t);t.targetChanges.forEach((i,r)=>{const o=e.Fa.get(r);o&&(X(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1),i.addedDocuments.size>0?o.wa=!0:i.modifiedDocuments.size>0?X(o.wa):i.removedDocuments.size>0&&(X(o.wa),o.wa=!1))}),await Qn(e,s,t)}catch(s){await Kn(s)}}function Vf(n,t,e){const s=W(n);if(s.isPrimaryClient&&e===0||!s.isPrimaryClient&&e===1){const i=[];s.ba.forEach((r,o)=>{const a=o.view.j_(t);a.snapshot&&i.push(a.snapshot)}),function(o,a){const l=W(o);l.onlineState=a;let u=!1;l.queries.forEach((h,p)=>{for(const m of p.U_)m.j_(a)&&(u=!0)}),u&&Eu(l)}(s.eventManager,t),i.length&&s.Sa.h_(i),s.onlineState=t,s.isPrimaryClient&&s.sharedClientState.setOnlineState(t)}}async function O0(n,t,e){const s=W(n);s.sharedClientState.updateQueryState(t,"rejected",e);const i=s.Fa.get(t),r=i&&i.key;if(r){let o=new At(q.comparator);o=o.insert(r,Ot.newNoDocument(r,Z.min()));const a=rt().add(r),l=new Xr(Z.min(),new Map,new At(nt),o,a);await ly(s,l),s.va=s.va.remove(r),s.Fa.delete(t),ku(s)}else await fi(s.localStore,t,!1).then(()=>gi(s,t,e)).catch(Kn)}async function M0(n,t){const e=W(n),s=t.batch.batchId;try{const i=await YT(e.localStore,t);Su(e,s,null),Au(e,s),e.sharedClientState.updateMutationState(s,"acknowledged"),await Qn(e,i)}catch(i){await Kn(i)}}async function L0(n,t,e){const s=W(n);try{const i=await function(o,a){const l=W(o);return l.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let h;return l.mutationQueue.lookupMutationBatch(u,a).next(p=>(X(p!==null),h=p.keys(),l.mutationQueue.removeMutationBatch(u,p))).next(()=>l.mutationQueue.performConsistencyCheck(u)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(u,h,a)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,h)).next(()=>l.localDocuments.getDocuments(u,h))})}(s.localStore,t);Su(s,t,e),Au(s,t),s.sharedClientState.updateMutationState(t,"rejected",e),await Qn(s,i)}catch(i){await Kn(i)}}function Au(n,t){(n.Oa.get(t)||[]).forEach(e=>{e.resolve()}),n.Oa.delete(t)}function Su(n,t,e){const s=W(n);let i=s.xa[s.currentUser.toKey()];if(i){const r=i.get(t);r&&(e?r.reject(e):r.resolve(),i=i.remove(t)),s.xa[s.currentUser.toKey()]=i}}function gi(n,t,e=null){n.sharedClientState.removeLocalQueryTarget(t);for(const s of n.Da.get(t))n.ba.delete(s),e&&n.Sa.ka(s,e);n.Da.delete(t),n.isPrimaryClient&&n.Ma.Vr(t).forEach(s=>{n.Ma.containsKey(s)||uy(n,s)})}function uy(n,t){n.Ca.delete(t.path.canonicalString());const e=n.va.get(t);e!==null&&(pi(n.remoteStore,e),n.va=n.va.remove(t),n.Fa.delete(e),ku(n))}function kl(n,t,e){for(const s of e)s instanceof oy?(n.Ma.addReference(s.key,t),F0(n,s)):s instanceof ay?(N("SyncEngine","Document no longer in limbo: "+s.key),n.Ma.removeReference(s.key,t),n.Ma.containsKey(s.key)||uy(n,s.key)):G()}function F0(n,t){const e=t.key,s=e.path.canonicalString();n.va.get(e)||n.Ca.has(s)||(N("SyncEngine","New document in limbo: "+e),n.Ca.add(s),ku(n))}function ku(n){for(;n.Ca.size>0&&n.va.size<n.maxConcurrentLimboResolutions;){const t=n.Ca.values().next().value;n.Ca.delete(t);const e=new q(vt.fromString(t)),s=n.Na.next();n.Fa.set(s,new P0(e)),n.va=n.va.insert(e,s),Wa(n.remoteStore,new on(Te(Ma(e.path)),s,"TargetPurposeLimboResolution",_e.oe))}}async function Qn(n,t,e){const s=W(n),i=[],r=[],o=[];s.ba.isEmpty()||(s.ba.forEach((a,l)=>{o.push(s.Ba(l,t,e).then(u=>{if((u||e)&&s.isPrimaryClient){const h=u&&!u.fromCache;s.sharedClientState.updateQueryState(l.targetId,h?"current":"not-current")}if(u){i.push(u);const h=gu.Ki(l.targetId,u);r.push(h)}}))}),await Promise.all(o),s.Sa.h_(i),await async function(l,u){const h=W(l);try{await h.persistence.runTransaction("notifyLocalViewChanges","readwrite",p=>P.forEach(u,m=>P.forEach(m.qi,I=>h.persistence.referenceDelegate.addReference(p,m.targetId,I)).next(()=>P.forEach(m.Qi,I=>h.persistence.referenceDelegate.removeReference(p,m.targetId,I)))))}catch(p){if(!Wn(p))throw p;N("LocalStore","Failed to update sequence numbers: "+p)}for(const p of u){const m=p.targetId;if(!p.fromCache){const I=h.ns.get(m),E=I.snapshotVersion,$=I.withLastLimboFreeSnapshotVersion(E);h.ns=h.ns.insert(m,$)}}}(s.localStore,r))}async function U0(n,t){const e=W(n);if(!e.currentUser.isEqual(t)){N("SyncEngine","User change. New user:",t.toKey());const s=await Kg(e.localStore,t);e.currentUser=t,function(r,o){r.Oa.forEach(a=>{a.forEach(l=>{l.reject(new U(V.CANCELLED,o))})}),r.Oa.clear()}(e,"'waitForPendingWrites' promise is rejected due to a user change."),e.sharedClientState.handleUserChange(t,s.removedBatchIds,s.addedBatchIds),await Qn(e,s.us)}}function q0(n,t){const e=W(n),s=e.Fa.get(t);if(s&&s.wa)return rt().add(s.key);{let i=rt();const r=e.Da.get(t);if(!r)return i;for(const o of r){const a=e.ba.get(o);i=i.unionWith(a.view.Ea)}return i}}async function B0(n,t){const e=W(n),s=await El(e.localStore,t.query,!0),i=t.view.pa(s);return e.isPrimaryClient&&kl(e,t.targetId,i.fa),i}async function j0(n,t){const e=W(n);return Qg(e.localStore,t).then(s=>Qn(e,s))}async function z0(n,t,e,s){const i=W(n),r=await function(a,l){const u=W(a),h=W(u.mutationQueue);return u.persistence.runTransaction("Lookup mutation documents","readonly",p=>h.vn(p,l).next(m=>m?u.localDocuments.getDocuments(p,m):P.resolve(null)))}(i.localStore,t);r!==null?(e==="pending"?await Pi(i.remoteStore):e==="acknowledged"||e==="rejected"?(Su(i,t,s||null),Au(i,t),function(a,l){W(W(a).mutationQueue).Mn(l)}(i.localStore,t)):G(),await Qn(i,r)):N("SyncEngine","Cannot apply mutation batch with id: "+t)}async function G0(n,t){const e=W(n);if(Ha(e),Ru(e),t===!0&&e.La!==!0){const s=e.sharedClientState.getAllActiveQueryTargets(),i=await Nf(e,s.toArray());e.La=!0,await Al(e.remoteStore,!0);for(const r of i)Wa(e.remoteStore,r)}else if(t===!1&&e.La!==!1){const s=[];let i=Promise.resolve();e.Da.forEach((r,o)=>{e.sharedClientState.isLocalQueryTarget(o)?s.push(o):i=i.then(()=>(gi(e,o),fi(e.localStore,o,!0))),pi(e.remoteStore,o)}),await i,await Nf(e,s),function(o){const a=W(o);a.Fa.forEach((l,u)=>{pi(a.remoteStore,u)}),a.Ma.mr(),a.Fa=new Map,a.va=new At(q.comparator)}(e),e.La=!1,await Al(e.remoteStore,!1)}}async function Nf(n,t,e){const s=W(n),i=[],r=[];for(const o of t){let a;const l=s.Da.get(o);if(l&&l.length!==0){a=await ma(s.localStore,Te(l[0]));for(const u of l){const h=s.ba.get(u),p=await B0(s,h);p.snapshot&&r.push(p.snapshot)}}else{const u=await Hg(s.localStore,o);a=await ma(s.localStore,u),await Tu(s,dy(u),o,!1,a.resumeToken)}i.push(a)}return s.Sa.h_(r),i}function dy(n){return tg(n.path,n.collectionGroup,n.orderBy,n.filters,n.limit,"F",n.startAt,n.endAt)}function K0(n){return function(e){return W(W(e).persistence).Bi()}(W(n).localStore)}async function W0(n,t,e,s){const i=W(n);if(i.La)return void N("SyncEngine","Ignoring unexpected query state notification.");const r=i.Da.get(t);if(r&&r.length>0)switch(e){case"current":case"not-current":{const o=await Qg(i.localStore,sg(r[0])),a=Xr.createSynthesizedRemoteEventForCurrentChange(t,e==="current",Qt.EMPTY_BYTE_STRING);await Qn(i,o,a);break}case"rejected":await fi(i.localStore,t,!0),gi(i,t,s);break;default:G()}}async function H0(n,t,e){const s=Ha(n);if(s.La){for(const i of t){if(s.Da.has(i)&&s.sharedClientState.isActiveQueryTarget(i)){N("SyncEngine","Adding an already active target "+i);continue}const r=await Hg(s.localStore,i),o=await ma(s.localStore,r);await Tu(s,dy(r),o.targetId,!1,o.resumeToken),Wa(s.remoteStore,o)}for(const i of e)s.Da.has(i)&&await fi(s.localStore,i,!1).then(()=>{pi(s.remoteStore,i),gi(s,i)}).catch(Kn)}}function Ha(n){const t=W(n);return t.remoteStore.remoteSyncer.applyRemoteEvent=ly.bind(null,t),t.remoteStore.remoteSyncer.getRemoteKeysForTarget=q0.bind(null,t),t.remoteStore.remoteSyncer.rejectListen=O0.bind(null,t),t.Sa.h_=T0.bind(null,t.eventManager),t.Sa.ka=A0.bind(null,t.eventManager),t}function Ru(n){const t=W(n);return t.remoteStore.remoteSyncer.applySuccessfulWrite=M0.bind(null,t),t.remoteStore.remoteSyncer.rejectFailedWrite=L0.bind(null,t),t}class Rl{constructor(){this.synchronizeTabs=!1}async initialize(t){this.serializer=Ga(t.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(t),this.persistence=this.createPersistence(t),await this.persistence.start(),this.localStore=this.createLocalStore(t),this.gcScheduler=this.createGarbageCollectionScheduler(t,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(t,this.localStore)}createGarbageCollectionScheduler(t,e){return null}createIndexBackfillerScheduler(t,e){return null}createLocalStore(t){return Gg(this.persistence,new zg,t.initialUser,this.serializer)}createPersistence(t){return new Bg(za.Hr,this.serializer)}createSharedClientState(t){return new Yg}async terminate(){var t,e;(t=this.gcScheduler)===null||t===void 0||t.stop(),(e=this.indexBackfillerScheduler)===null||e===void 0||e.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class hy extends Rl{constructor(t,e,s){super(),this.Qa=t,this.cacheSizeBytes=e,this.forceOwnership=s,this.synchronizeTabs=!1}async initialize(t){await super.initialize(t),await this.Qa.initialize(this,t),await Ru(this.Qa.syncEngine),await Pi(this.Qa.remoteStore),await this.persistence.fi(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}createLocalStore(t){return Gg(this.persistence,new zg,t.initialUser,this.serializer)}createGarbageCollectionScheduler(t,e){const s=this.persistence.referenceDelegate.garbageCollector;return new NT(s,t.asyncQueue,e)}createIndexBackfillerScheduler(t,e){const s=new pE(e,this.persistence);return new fE(t.asyncQueue,s)}createPersistence(t){const e=jg(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey),s=this.cacheSizeBytes!==void 0?ve.withCacheSize(this.cacheSizeBytes):ve.DEFAULT;return new mu(this.synchronizeTabs,e,t.clientId,s,t.asyncQueue,Xg(),Wo(),this.serializer,this.sharedClientState,!!this.forceOwnership)}createSharedClientState(t){return new Yg}}class Q0 extends hy{constructor(t,e){super(t,e,!1),this.Qa=t,this.cacheSizeBytes=e,this.synchronizeTabs=!0}async initialize(t){await super.initialize(t);const e=this.Qa.syncEngine;this.sharedClientState instanceof qc&&(this.sharedClientState.syncEngine={Zs:z0.bind(null,e),Xs:W0.bind(null,e),eo:H0.bind(null,e),Bi:K0.bind(null,e),Ys:j0.bind(null,e)},await this.sharedClientState.start()),await this.persistence.fi(async s=>{await G0(this.Qa.syncEngine,s),this.gcScheduler&&(s&&!this.gcScheduler.started?this.gcScheduler.start():s||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(s&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():s||this.indexBackfillerScheduler.stop())})}createSharedClientState(t){const e=Xg();if(!qc.D(e))throw new U(V.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const s=jg(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey);return new qc(e,t.asyncQueue,s,t.clientId,t.initialUser)}}class Pu{async initialize(t,e){this.localStore||(this.localStore=t.localStore,this.sharedClientState=t.sharedClientState,this.datastore=this.createDatastore(e),this.remoteStore=this.createRemoteStore(e),this.eventManager=this.createEventManager(e),this.syncEngine=this.createSyncEngine(e,!t.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>Vf(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=U0.bind(null,this.syncEngine),await Al(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(t){return function(){return new w0}()}createDatastore(t){const e=Ga(t.databaseInfo.databaseId),s=function(r){return new i0(r)}(t.databaseInfo);return function(r,o,a,l){return new a0(r,o,a,l)}(t.authCredentials,t.appCheckCredentials,s,e)}createRemoteStore(t){return function(s,i,r,o,a){return new l0(s,i,r,o,a)}(this.localStore,this.datastore,t.asyncQueue,e=>Vf(this.syncEngine,e,0),function(){return Pf.D()?new Pf:new e0}())}createSyncEngine(t,e){return function(i,r,o,a,l,u,h){const p=new C0(i,r,o,a,l,u);return h&&(p.La=!0),p}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,t.initialUser,t.maxConcurrentLimboResolutions,e)}async terminate(){var t;await async function(s){const i=W(s);N("RemoteStore","RemoteStore shutting down."),i.M_.add(5),await to(i),i.O_.shutdown(),i.N_.set("Unknown")}(this.remoteStore),(t=this.datastore)===null||t===void 0||t.terminate()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J0{constructor(t){this.observer=t,this.muted=!1}next(t){this.observer.next&&this.Ka(this.observer.next,t)}error(t){this.observer.error?this.Ka(this.observer.error,t):Lt("Uncaught Error in snapshot listener:",t.toString())}$a(){this.muted=!0}Ka(t,e){this.muted||setTimeout(()=>{this.muted||t(e)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y0{constructor(t,e,s,i){this.authCredentials=t,this.appCheckCredentials=e,this.asyncQueue=s,this.databaseInfo=i,this.user=re.UNAUTHENTICATED,this.clientId=Cm.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(s,async r=>{N("FirestoreClient","Received user=",r.uid),await this.authCredentialListener(r),this.user=r}),this.appCheckCredentials.start(s,r=>(N("FirestoreClient","Received new app check token=",r),this.appCheckCredentialListener(r,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(t){this.authCredentialListener=t}setAppCheckTokenChangeListener(t){this.appCheckCredentialListener=t}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new U(V.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const t=new Vn;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),t.resolve()}catch(e){const s=Iu(e,"Failed to shutdown persistence");t.reject(s)}}),t.promise}}async function jc(n,t){n.asyncQueue.verifyOperationInProgress(),N("FirestoreClient","Initializing OfflineComponentProvider");const e=n.configuration;await t.initialize(e);let s=e.initialUser;n.setCredentialChangeListener(async i=>{s.isEqual(i)||(await Kg(t.localStore,i),s=i)}),t.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=t}async function xf(n,t){n.asyncQueue.verifyOperationInProgress();const e=await Z0(n);N("FirestoreClient","Initializing OnlineComponentProvider"),await t.initialize(e,n.configuration),n.setCredentialChangeListener(s=>Cf(t.remoteStore,s)),n.setAppCheckTokenChangeListener((s,i)=>Cf(t.remoteStore,i)),n._onlineComponents=t}function X0(n){return n.name==="FirebaseError"?n.code===V.FAILED_PRECONDITION||n.code===V.UNIMPLEMENTED:!(typeof DOMException<"u"&&n instanceof DOMException)||n.code===22||n.code===20||n.code===11}async function Z0(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){N("FirestoreClient","Using user provided OfflineComponentProvider");try{await jc(n,n._uninitializedComponentsProvider._offline)}catch(t){const e=t;if(!X0(e))throw e;Sr("Error using user provided cache. Falling back to memory cache: "+e),await jc(n,new Rl)}}else N("FirestoreClient","Using default OfflineComponentProvider"),await jc(n,new Rl);return n._offlineComponents}async function fy(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(N("FirestoreClient","Using user provided OnlineComponentProvider"),await xf(n,n._uninitializedComponentsProvider._online)):(N("FirestoreClient","Using default OnlineComponentProvider"),await xf(n,new Pu))),n._onlineComponents}function tA(n){return fy(n).then(t=>t.syncEngine)}async function Of(n){const t=await fy(n),e=t.eventManager;return e.onListen=D0.bind(null,t.syncEngine),e.onUnlisten=V0.bind(null,t.syncEngine),e.onFirstRemoteStoreListen=$0.bind(null,t.syncEngine),e.onLastRemoteStoreUnlisten=N0.bind(null,t.syncEngine),e}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function py(n){const t={};return n.timeoutSeconds!==void 0&&(t.timeoutSeconds=n.timeoutSeconds),t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mf=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function my(n,t,e){if(!e)throw new U(V.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${t}.`)}function eA(n,t,e,s){if(t===!0&&s===!0)throw new U(V.INVALID_ARGUMENT,`${n} and ${e} cannot be used together.`)}function Lf(n){if(!q.isDocumentKey(n))throw new U(V.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Ff(n){if(q.isDocumentKey(n))throw new U(V.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Qa(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const t=function(s){return s.constructor?s.constructor.name:null}(n);return t?`a custom ${t} object`:"an object"}}return typeof n=="function"?"a function":G()}function xn(n,t){if("_delegate"in n&&(n=n._delegate),!(n instanceof t)){if(t.name===n.constructor.name)throw new U(V.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const e=Qa(n);throw new U(V.INVALID_ARGUMENT,`Expected type '${t.name}', but it was: ${e}`)}}return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uf{constructor(t){var e,s;if(t.host===void 0){if(t.ssl!==void 0)throw new U(V.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=t.host,this.ssl=(e=t.ssl)===null||e===void 0||e;if(this.credentials=t.credentials,this.ignoreUndefinedProperties=!!t.ignoreUndefinedProperties,this.localCache=t.localCache,t.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(t.cacheSizeBytes!==-1&&t.cacheSizeBytes<1048576)throw new U(V.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=t.cacheSizeBytes}eA("experimentalForceLongPolling",t.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",t.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!t.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:t.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!t.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=py((s=t.experimentalLongPollingOptions)!==null&&s!==void 0?s:{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new U(V.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new U(V.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new U(V.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!t.useFetchStreams}isEqual(t){return this.host===t.host&&this.ssl===t.ssl&&this.credentials===t.credentials&&this.cacheSizeBytes===t.cacheSizeBytes&&this.experimentalForceLongPolling===t.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===t.experimentalAutoDetectLongPolling&&function(s,i){return s.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,t.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===t.ignoreUndefinedProperties&&this.useFetchStreams===t.useFetchStreams}}class Cu{constructor(t,e,s,i){this._authCredentials=t,this._appCheckCredentials=e,this._databaseId=s,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Uf({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new U(V.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(t){if(this._settingsFrozen)throw new U(V.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Uf(t),t.credentials!==void 0&&(this._authCredentials=function(s){if(!s)return new sE;switch(s.type){case"firstParty":return new oE(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new U(V.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(t.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(e){const s=Mf.get(e);s&&(N("ComponentProvider","Removing Datastore"),Mf.delete(e),s.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Di{constructor(t,e,s){this.converter=e,this._query=s,this.type="query",this.firestore=t}withConverter(t){return new Di(this.firestore,t,this._query)}}class me{constructor(t,e,s){this.converter=e,this._key=s,this.type="document",this.firestore=t}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new On(this.firestore,this.converter,this._key.path.popLast())}withConverter(t){return new me(this.firestore,t,this._key)}}class On extends Di{constructor(t,e,s){super(t,e,Ma(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const t=this._path.popLast();return t.isEmpty()?null:new me(this.firestore,null,new q(t))}withConverter(t){return new On(this.firestore,t,this._path)}}function Hs(n,t,...e){if(n=Wt(n),my("collection","path",t),n instanceof Cu){const s=vt.fromString(t,...e);return Ff(s),new On(n,null,s)}{if(!(n instanceof me||n instanceof On))throw new U(V.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(vt.fromString(t,...e));return Ff(s),new On(n.firestore,null,s)}}function Jn(n,t,...e){if(n=Wt(n),arguments.length===1&&(t=Cm.newId()),my("doc","path",t),n instanceof Cu){const s=vt.fromString(t,...e);return Lf(s),new me(n,null,new q(s))}{if(!(n instanceof me||n instanceof On))throw new U(V.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(vt.fromString(t,...e));return Lf(s),new me(n.firestore,n instanceof On?n.converter:null,new q(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nA{constructor(){this.iu=Promise.resolve(),this.su=[],this.ou=!1,this._u=[],this.au=null,this.uu=!1,this.cu=!1,this.lu=[],this.Yo=new Zg(this,"async_queue_retry"),this.hu=()=>{const e=Wo();e&&N("AsyncQueue","Visibility state changed to "+e.visibilityState),this.Yo.Wo()};const t=Wo();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.hu)}get isShuttingDown(){return this.ou}enqueueAndForget(t){this.enqueue(t)}enqueueAndForgetEvenWhileRestricted(t){this.Pu(),this.Iu(t)}enterRestrictedMode(t){if(!this.ou){this.ou=!0,this.cu=t||!1;const e=Wo();e&&typeof e.removeEventListener=="function"&&e.removeEventListener("visibilitychange",this.hu)}}enqueue(t){if(this.Pu(),this.ou)return new Promise(()=>{});const e=new Vn;return this.Iu(()=>this.ou&&this.cu?Promise.resolve():(t().then(e.resolve,e.reject),e.promise)).then(()=>e.promise)}enqueueRetryable(t){this.enqueueAndForget(()=>(this.su.push(t),this.Tu()))}async Tu(){if(this.su.length!==0){try{await this.su[0](),this.su.shift(),this.Yo.reset()}catch(t){if(!Wn(t))throw t;N("AsyncQueue","Operation failed with retryable error: "+t)}this.su.length>0&&this.Yo.$o(()=>this.Tu())}}Iu(t){const e=this.iu.then(()=>(this.uu=!0,t().catch(s=>{this.au=s,this.uu=!1;const i=function(o){let a=o.message||"";return o.stack&&(a=o.stack.includes(o.message)?o.stack:o.message+`
`+o.stack),a}(s);throw Lt("INTERNAL UNHANDLED ERROR: ",i),s}).then(s=>(this.uu=!1,s))));return this.iu=e,e}enqueueAfterDelay(t,e,s){this.Pu(),this.lu.indexOf(t)>-1&&(e=0);const i=wu.createAndSchedule(this,t,e,s,r=>this.Eu(r));return this._u.push(i),i}Pu(){this.au&&G()}verifyOperationInProgress(){}async du(){let t;do t=this.iu,await t;while(t!==this.iu)}Au(t){for(const e of this._u)if(e.timerId===t)return!0;return!1}Ru(t){return this.du().then(()=>{this._u.sort((e,s)=>e.targetTimeMs-s.targetTimeMs);for(const e of this._u)if(e.skipDelay(),t!=="all"&&e.timerId===t)break;return this.du()})}Vu(t){this.lu.push(t)}Eu(t){const e=this._u.indexOf(t);this._u.splice(e,1)}}function qf(n){return function(e,s){if(typeof e!="object"||e===null)return!1;const i=e;for(const r of s)if(r in i&&typeof i[r]=="function")return!0;return!1}(n,["next","error","complete"])}class yi extends Cu{constructor(t,e,s,i){super(t,e,s,i),this.type="firestore",this._queue=function(){return new nA}(),this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||yy(this),this._firestoreClient.terminate()}}function sA(n,t,e){e||(e="(default)");const s=zl(n,"firestore");if(s.isInitialized(e)){const i=s.getImmediate({identifier:e}),r=s.getOptions(e);if(Ir(r,t))return i;throw new U(V.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(t.cacheSizeBytes!==void 0&&t.localCache!==void 0)throw new U(V.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(t.cacheSizeBytes!==void 0&&t.cacheSizeBytes!==-1&&t.cacheSizeBytes<1048576)throw new U(V.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return s.initialize({options:t,instanceIdentifier:e})}function gy(n){return n._firestoreClient||yy(n),n._firestoreClient.verifyNotTerminated(),n._firestoreClient}function yy(n){var t,e,s;const i=n._freezeSettings(),r=function(a,l,u,h){return new NE(a,l,u,h.host,h.ssl,h.experimentalForceLongPolling,h.experimentalAutoDetectLongPolling,py(h.experimentalLongPollingOptions),h.useFetchStreams)}(n._databaseId,((t=n._app)===null||t===void 0?void 0:t.options.appId)||"",n._persistenceKey,i);n._firestoreClient=new Y0(n._authCredentials,n._appCheckCredentials,n._queue,r),!((e=i.localCache)===null||e===void 0)&&e._offlineComponentProvider&&(!((s=i.localCache)===null||s===void 0)&&s._onlineComponentProvider)&&(n._firestoreClient._uninitializedComponentsProvider={_offlineKind:i.localCache.kind,_offline:i.localCache._offlineComponentProvider,_online:i.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vi{constructor(t){this._byteString=t}static fromBase64String(t){try{return new vi(Qt.fromBase64String(t))}catch(e){throw new U(V.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+e)}}static fromUint8Array(t){return new vi(Qt.fromUint8Array(t))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(t){return this._byteString.isEqual(t._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ja{constructor(...t){for(let e=0;e<t.length;++e)if(t[e].length===0)throw new U(V.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Ct(t)}isEqual(t){return this._internalPath.isEqual(t._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Du{constructor(t){this._methodName=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $u{constructor(t,e){if(!isFinite(t)||t<-90||t>90)throw new U(V.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+t);if(!isFinite(e)||e<-180||e>180)throw new U(V.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+e);this._lat=t,this._long=e}get latitude(){return this._lat}get longitude(){return this._long}isEqual(t){return this._lat===t._lat&&this._long===t._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(t){return nt(this._lat,t._lat)||nt(this._long,t._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iA=/^__.*__$/;class rA{constructor(t,e,s){this.data=t,this.fieldMask=e,this.fieldTransforms=s}toMutation(t,e){return this.fieldMask!==null?new hn(t,this.data,this.fieldMask,e,this.fieldTransforms):new Ri(t,this.data,e,this.fieldTransforms)}}class vy{constructor(t,e,s){this.data=t,this.fieldMask=e,this.fieldTransforms=s}toMutation(t,e){return new hn(t,this.data,this.fieldMask,e,this.fieldTransforms)}}function _y(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw G()}}class Vu{constructor(t,e,s,i,r,o){this.settings=t,this.databaseId=e,this.serializer=s,this.ignoreUndefinedProperties=i,r===void 0&&this.mu(),this.fieldTransforms=r||[],this.fieldMask=o||[]}get path(){return this.settings.path}get fu(){return this.settings.fu}gu(t){return new Vu(Object.assign(Object.assign({},this.settings),t),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}pu(t){var e;const s=(e=this.path)===null||e===void 0?void 0:e.child(t),i=this.gu({path:s,yu:!1});return i.wu(t),i}Su(t){var e;const s=(e=this.path)===null||e===void 0?void 0:e.child(t),i=this.gu({path:s,yu:!1});return i.mu(),i}bu(t){return this.gu({path:void 0,yu:!0})}Du(t){return _a(t,this.settings.methodName,this.settings.Cu||!1,this.path,this.settings.vu)}contains(t){return this.fieldMask.find(e=>t.isPrefixOf(e))!==void 0||this.fieldTransforms.find(e=>t.isPrefixOf(e.field))!==void 0}mu(){if(this.path)for(let t=0;t<this.path.length;t++)this.wu(this.path.get(t))}wu(t){if(t.length===0)throw this.Du("Document fields must not be empty");if(_y(this.fu)&&iA.test(t))throw this.Du('Document fields cannot begin and end with "__"')}}class oA{constructor(t,e,s){this.databaseId=t,this.ignoreUndefinedProperties=e,this.serializer=s||Ga(t)}Fu(t,e,s,i=!1){return new Vu({fu:t,methodName:e,vu:s,path:Ct.emptyPath(),yu:!1,Cu:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Nu(n){const t=n._freezeSettings(),e=Ga(n._databaseId);return new oA(n._databaseId,!!t.ignoreUndefinedProperties,e)}function aA(n,t,e,s,i,r={}){const o=n.Fu(r.merge||r.mergeFields?2:0,t,e,i);xu("Data must be an object, but it was:",o,s);const a=by(s,o);let l,u;if(r.merge)l=new be(o.fieldMask),u=o.fieldTransforms;else if(r.mergeFields){const h=[];for(const p of r.mergeFields){const m=Pl(t,p,e);if(!o.contains(m))throw new U(V.INVALID_ARGUMENT,`Field '${m}' is specified in your field mask but missing from your input data.`);Iy(h,m)||h.push(m)}l=new be(h),u=o.fieldTransforms.filter(p=>l.covers(p.field))}else l=null,u=o.fieldTransforms;return new rA(new oe(a),l,u)}class eo extends Du{_toFieldTransform(t){if(t.fu!==2)throw t.fu===1?t.Du(`${this._methodName}() can only appear at the top level of your update data`):t.Du(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return t.fieldMask.push(t.path),null}isEqual(t){return t instanceof eo}}function cA(n,t,e,s){const i=n.Fu(1,t,e);xu("Data must be an object, but it was:",i,s);const r=[],o=oe.empty();Ss(s,(l,u)=>{const h=Ou(t,l,e);u=Wt(u);const p=i.Su(h);if(u instanceof eo)r.push(h);else{const m=no(u,p);m!=null&&(r.push(h),o.set(h,m))}});const a=new be(r);return new vy(o,a,i.fieldTransforms)}function lA(n,t,e,s,i,r){const o=n.Fu(1,t,e),a=[Pl(t,s,e)],l=[i];if(r.length%2!=0)throw new U(V.INVALID_ARGUMENT,`Function ${t}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let m=0;m<r.length;m+=2)a.push(Pl(t,r[m])),l.push(r[m+1]);const u=[],h=oe.empty();for(let m=a.length-1;m>=0;--m)if(!Iy(u,a[m])){const I=a[m];let E=l[m];E=Wt(E);const $=o.Su(I);if(E instanceof eo)u.push(I);else{const R=no(E,$);R!=null&&(u.push(I),h.set(I,R))}}const p=new be(u);return new vy(h,p,o.fieldTransforms)}function uA(n,t,e,s=!1){return no(e,n.Fu(s?4:3,t))}function no(n,t){if(wy(n=Wt(n)))return xu("Unsupported field value:",t,n),by(n,t);if(n instanceof Du)return function(s,i){if(!_y(i.fu))throw i.Du(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.Du(`${s._methodName}() is not currently supported inside arrays`);const r=s._toFieldTransform(i);r&&i.fieldTransforms.push(r)}(n,t),null;if(n===void 0&&t.ignoreUndefinedProperties)return null;if(t.path&&t.fieldMask.push(t.path),n instanceof Array){if(t.settings.yu&&t.fu!==4)throw t.Du("Nested arrays are not supported");return function(s,i){const r=[];let o=0;for(const a of s){let l=no(a,i.bu(o));l==null&&(l={nullValue:"NULL_VALUE"}),r.push(l),o++}return{arrayValue:{values:r}}}(n,t)}return function(s,i){if((s=Wt(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return YE(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const r=Dt.fromDate(s);return{timestampValue:hi(i.serializer,r)}}if(s instanceof Dt){const r=new Dt(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:hi(i.serializer,r)}}if(s instanceof $u)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof vi)return{bytesValue:bg(i.serializer,s._byteString)};if(s instanceof me){const r=i.databaseId,o=s.firestore._databaseId;if(!o.isEqual(r))throw i.Du(`Document reference is for database ${o.projectId}/${o.database} but should be for database ${r.projectId}/${r.database}`);return{referenceValue:du(s.firestore._databaseId||i.databaseId,s._key.path)}}throw i.Du(`Unsupported field value: ${Qa(s)}`)}(n,t)}function by(n,t){const e={};return jm(n)?t.path&&t.path.length>0&&t.fieldMask.push(t.path):Ss(n,(s,i)=>{const r=no(i,t.pu(s));r!=null&&(e[s]=r)}),{mapValue:{fields:e}}}function wy(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Dt||n instanceof $u||n instanceof vi||n instanceof me||n instanceof Du)}function xu(n,t,e){if(!wy(e)||!function(i){return typeof i=="object"&&i!==null&&(Object.getPrototypeOf(i)===Object.prototype||Object.getPrototypeOf(i)===null)}(e)){const s=Qa(e);throw s==="an object"?t.Du(n+" a custom object"):t.Du(n+" "+s)}}function Pl(n,t,e){if((t=Wt(t))instanceof Ja)return t._internalPath;if(typeof t=="string")return Ou(n,t);throw _a("Field path arguments must be of type string or ",n,!1,void 0,e)}const dA=new RegExp("[~\\*/\\[\\]]");function Ou(n,t,e){if(t.search(dA)>=0)throw _a(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,e);try{return new Ja(...t.split("."))._internalPath}catch{throw _a(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,e)}}function _a(n,t,e,s,i){const r=s&&!s.isEmpty(),o=i!==void 0;let a=`Function ${t}() called with invalid data`;e&&(a+=" (via `toFirestore()`)"),a+=". ";let l="";return(r||o)&&(l+=" (found",r&&(l+=` in field ${s}`),o&&(l+=` in document ${i}`),l+=")"),new U(V.INVALID_ARGUMENT,a+n+l)}function Iy(n,t){return n.some(e=>e.isEqual(t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ey{constructor(t,e,s,i,r){this._firestore=t,this._userDataWriter=e,this._key=s,this._document=i,this._converter=r}get id(){return this._key.path.lastSegment()}get ref(){return new me(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const t=new hA(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(t)}return this._userDataWriter.convertValue(this._document.data.value)}}get(t){if(this._document){const e=this._document.data.field(Mu("DocumentSnapshot.get",t));if(e!==null)return this._userDataWriter.convertValue(e)}}}class hA extends Ey{data(){return super.data()}}function Mu(n,t){return typeof t=="string"?Ou(n,t):t instanceof Ja?t._internalPath:t._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fA(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new U(V.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Lu{}class pA extends Lu{}function Bf(n,t,...e){let s=[];t instanceof Lu&&s.push(t),s=s.concat(e),function(r){const o=r.filter(l=>l instanceof Fu).length,a=r.filter(l=>l instanceof Ya).length;if(o>1||o>0&&a>0)throw new U(V.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(s);for(const i of s)n=i._apply(n);return n}class Ya extends pA{constructor(t,e,s){super(),this._field=t,this._op=e,this._value=s,this.type="where"}static _create(t,e,s){return new Ya(t,e,s)}_apply(t){const e=this._parse(t);return Ty(t._query,e),new Di(t.firestore,t.converter,pl(t._query,e))}_parse(t){const e=Nu(t.firestore);return function(r,o,a,l,u,h,p){let m;if(u.isKeyField()){if(h==="array-contains"||h==="array-contains-any")throw new U(V.INVALID_ARGUMENT,`Invalid Query. You can't perform '${h}' queries on documentId().`);if(h==="in"||h==="not-in"){Gf(p,h);const I=[];for(const E of p)I.push(zf(l,r,E));m={arrayValue:{values:I}}}else m=zf(l,r,p)}else h!=="in"&&h!=="not-in"&&h!=="array-contains-any"||Gf(p,h),m=uA(a,o,p,h==="in"||h==="not-in");return at.create(u,h,m)}(t._query,"where",e,t.firestore._databaseId,this._field,this._op,this._value)}}function jf(n,t,e){const s=t,i=Mu("where",n);return Ya._create(i,s,e)}class Fu extends Lu{constructor(t,e){super(),this.type=t,this._queryConstraints=e}static _create(t,e){return new Fu(t,e)}_parse(t){const e=this._queryConstraints.map(s=>s._parse(t)).filter(s=>s.getFilters().length>0);return e.length===1?e[0]:bt.create(e,this._getOperator())}_apply(t){const e=this._parse(t);return e.getFilters().length===0?t:(function(i,r){let o=i;const a=r.getFlattenedFilters();for(const l of a)Ty(o,l),o=pl(o,l)}(t._query,e),new Di(t.firestore,t.converter,pl(t._query,e)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}function zf(n,t,e){if(typeof(e=Wt(e))=="string"){if(e==="")throw new U(V.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!eg(t)&&e.indexOf("/")!==-1)throw new U(V.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${e}' contains a '/' character.`);const s=t.path.child(vt.fromString(e));if(!q.isDocumentKey(s))throw new U(V.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return $r(n,new q(s))}if(e instanceof me)return $r(n,e._key);throw new U(V.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Qa(e)}.`)}function Gf(n,t){if(!Array.isArray(n)||n.length===0)throw new U(V.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${t.toString()}' filters.`)}function Ty(n,t){const e=function(i,r){for(const o of i)for(const a of o.getFlattenedFilters())if(r.indexOf(a.op)>=0)return a.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(t.op));if(e!==null)throw e===t.op?new U(V.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${t.op.toString()}' filter.`):new U(V.INVALID_ARGUMENT,`Invalid query. You cannot use '${t.op.toString()}' filters with '${e.toString()}' filters.`)}class mA{convertValue(t,e="none"){switch(_s(t)){case 0:return null;case 1:return t.booleanValue;case 2:return xt(t.integerValue||t.doubleValue);case 3:return this.convertTimestamp(t.timestampValue);case 4:return this.convertServerTimestamp(t,e);case 5:return t.stringValue;case 6:return this.convertBytes(qn(t.bytesValue));case 7:return this.convertReference(t.referenceValue);case 8:return this.convertGeoPoint(t.geoPointValue);case 9:return this.convertArray(t.arrayValue,e);case 10:return this.convertObject(t.mapValue,e);default:throw G()}}convertObject(t,e){return this.convertObjectMap(t.fields,e)}convertObjectMap(t,e="none"){const s={};return Ss(t,(i,r)=>{s[i]=this.convertValue(r,e)}),s}convertGeoPoint(t){return new $u(xt(t.latitude),xt(t.longitude))}convertArray(t,e){return(t.values||[]).map(s=>this.convertValue(s,e))}convertServerTimestamp(t,e){switch(e){case"previous":const s=iu(t);return s==null?null:this.convertValue(s,e);case"estimate":return this.convertTimestamp(Cr(t));default:return null}}convertTimestamp(t){const e=ln(t);return new Dt(e.seconds,e.nanos)}convertDocumentKey(t,e){const s=vt.fromString(t);X(Cg(s));const i=new vs(s.get(1),s.get(3)),r=new q(s.popFirst(5));return i.isEqual(e)||Lt(`Document ${r} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gA(n,t,e){let s;return s=n?e&&(e.merge||e.mergeFields)?n.toFirestore(t,e):n.toFirestore(t):t,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ur{constructor(t,e){this.hasPendingWrites=t,this.fromCache=e}isEqual(t){return this.hasPendingWrites===t.hasPendingWrites&&this.fromCache===t.fromCache}}class Ay extends Ey{constructor(t,e,s,i,r,o){super(t,e,s,i,o),this._firestore=t,this._firestoreImpl=t,this.metadata=r}exists(){return super.exists()}data(t={}){if(this._document){if(this._converter){const e=new Ho(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(e,t)}return this._userDataWriter.convertValue(this._document.data.value,t.serverTimestamps)}}get(t,e={}){if(this._document){const s=this._document.data.field(Mu("DocumentSnapshot.get",t));if(s!==null)return this._userDataWriter.convertValue(s,e.serverTimestamps)}}}class Ho extends Ay{data(t={}){return super.data(t)}}class yA{constructor(t,e,s,i){this._firestore=t,this._userDataWriter=e,this._snapshot=i,this.metadata=new ur(i.hasPendingWrites,i.fromCache),this.query=s}get docs(){const t=[];return this.forEach(e=>t.push(e)),t}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(t,e){this._snapshot.docs.forEach(s=>{t.call(e,new Ho(this._firestore,this._userDataWriter,s.key,s,new ur(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))})}docChanges(t={}){const e=!!t.includeMetadataChanges;if(e&&this._snapshot.excludesMetadataChanges)throw new U(V.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===e||(this._cachedChanges=function(i,r){if(i._snapshot.oldDocs.isEmpty()){let o=0;return i._snapshot.docChanges.map(a=>{const l=new Ho(i._firestore,i._userDataWriter,a.doc.key,a.doc,new ur(i._snapshot.mutatedKeys.has(a.doc.key),i._snapshot.fromCache),i.query.converter);return a.doc,{type:"added",doc:l,oldIndex:-1,newIndex:o++}})}{let o=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(a=>r||a.type!==3).map(a=>{const l=new Ho(i._firestore,i._userDataWriter,a.doc.key,a.doc,new ur(i._snapshot.mutatedKeys.has(a.doc.key),i._snapshot.fromCache),i.query.converter);let u=-1,h=-1;return a.type!==0&&(u=o.indexOf(a.doc.key),o=o.delete(a.doc.key)),a.type!==1&&(o=o.add(a.doc),h=o.indexOf(a.doc.key)),{type:vA(a.type),doc:l,oldIndex:u,newIndex:h}})}}(this,e),this._cachedChangesIncludeMetadataChanges=e),this._cachedChanges}}function vA(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return G()}}class Sy extends mA{constructor(t){super(),this.firestore=t}convertBytes(t){return new vi(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new me(this.firestore,null,e)}}function Xa(n,t,e){n=xn(n,me);const s=xn(n.firestore,yi),i=gA(n.converter,t,e);return Uu(s,[aA(Nu(s),"setDoc",n._key,i,n.converter!==null,e).toMutation(n._key,he.none())])}function ky(n,t,e,...s){n=xn(n,me);const i=xn(n.firestore,yi),r=Nu(i);let o;return o=typeof(t=Wt(t))=="string"||t instanceof Ja?lA(r,"updateDoc",n._key,t,e,s):cA(r,"updateDoc",n._key,t),Uu(i,[o.toMutation(n._key,he.exists(!0))])}function _A(n){return Uu(xn(n.firestore,yi),[new qa(n._key,he.none())])}function Cl(n,...t){var e,s,i;n=Wt(n);let r={includeMetadataChanges:!1,source:"default"},o=0;typeof t[o]!="object"||qf(t[o])||(r=t[o],o++);const a={includeMetadataChanges:r.includeMetadataChanges,source:r.source};if(qf(t[o])){const p=t[o];t[o]=(e=p.next)===null||e===void 0?void 0:e.bind(p),t[o+1]=(s=p.error)===null||s===void 0?void 0:s.bind(p),t[o+2]=(i=p.complete)===null||i===void 0?void 0:i.bind(p)}let l,u,h;if(n instanceof me)u=xn(n.firestore,yi),h=Ma(n._key.path),l={next:p=>{t[o]&&t[o](bA(u,n,p))},error:t[o+1],complete:t[o+2]};else{const p=xn(n,Di);u=xn(p.firestore,yi),h=p._query;const m=new Sy(u);l={next:I=>{t[o]&&t[o](new yA(u,m,p,I))},error:t[o+1],complete:t[o+2]},fA(n._query)}return function(m,I,E,$){const R=new J0($),B=new S0(I,R,E);return m.asyncQueue.enqueueAndForget(async()=>I0(await Of(m),B)),()=>{R.$a(),m.asyncQueue.enqueueAndForget(async()=>E0(await Of(m),B))}}(gy(u),h,a,l)}function Uu(n,t){return function(s,i){const r=new Vn;return s.asyncQueue.enqueueAndForget(async()=>x0(await tA(s),i,r)),r.promise}(gy(n),t)}function bA(n,t,e){const s=e.docs.get(t._key),i=new Sy(n);return new Ay(n,i,t._key,s,new ur(e.hasPendingWrites,e.fromCache),t.converter)}class wA{constructor(t){let e;this.kind="persistent",t!=null&&t.tabManager?(t.tabManager._initialize(t),e=t.tabManager):(e=AA(),e._initialize(t)),this._onlineComponentProvider=e._onlineComponentProvider,this._offlineComponentProvider=e._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function IA(n){return new wA(n)}class EA{constructor(t){this.forceOwnership=t,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(t){this._onlineComponentProvider=new Pu,this._offlineComponentProvider=new hy(this._onlineComponentProvider,t==null?void 0:t.cacheSizeBytes,this.forceOwnership)}}class TA{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(t){this._onlineComponentProvider=new Pu,this._offlineComponentProvider=new Q0(this._onlineComponentProvider,t==null?void 0:t.cacheSizeBytes)}}function AA(n){return new EA(void 0)}function SA(){return new TA}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ry(){return new eo("deleteField")}(function(t,e=!0){(function(i){ki=i})(Ti),ii(new ps("firestore",(s,{instanceIdentifier:i,options:r})=>{const o=s.getProvider("app").getImmediate(),a=new yi(new iE(s.getProvider("auth-internal")),new cE(s.getProvider("app-check-internal")),function(u,h){if(!Object.prototype.hasOwnProperty.apply(u.options,["projectId"]))throw new U(V.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new vs(u.options.projectId,h)}(o,i),o);return r=Object.assign({useFetchStreams:e},r),a._setSettings(r),a},"PUBLIC").setMultipleInstances(!0)),Dn(Oh,"4.6.3",t),Dn(Oh,"4.6.3","esm2017")})();const Dl={apiKey:"AIzaSyC9Um4cxmF3LT_f9Ade5gYSj4ZjMbPHZU4",authDomain:"cursing-offers.firebaseapp.com",projectId:"cursing-offers",storageBucket:"cursing-offers.firebasestorage.app",messagingSenderId:"782347533500",appId:"1:782347533500:web:5da31b9357632fc055a4b9"};function kA(){const n=Date.now(),t=864e5,e=new Date().toISOString().slice(0,10),s=(r,o,a)=>({desc:r,qty:o,price:a,disc:0}),i=(r,o,a,l,u,h,p,m,I,E)=>({id:r,number:o,ts:n-I*t,date:new Date(n-I*t).toISOString().slice(0,10),customer:{name:a,phone:l,email:"",afm:"",address:u},subject:h,status:p,total:m,vatMode:"on",lines:E});return{quotes:[i("q1","2311","Γιώργος Παπαδόπουλος","6900000001","Πρέβεζα","Εγκατάσταση CCTV και WiFi","accepted",1437.16,3,[s("Hikvision IP 4MP Bullet",4,89),s("NVR 8 καναλιών + 2TB",1,245),s("UniFi U6 Lite",2,119),s("Εργασία εγκατάστασης",1,320)]),i("q2","2310","Hotel Aktaion","6900000002","Βόνιτσα","WiFi ξενοδοχείου 40 δωμάτια","pending",6920,5,[s("UniFi U6+",20,159),s("Switch PoE 24 θυρών",1,420),s("Εργασία",1,1700)]),i("q3","2309","Μαρία Νικολάου","6900000003","Λευκάδα","Συναγερμός Paradox","done",780,700,[s("Paradox MG5050 set",1,480),s("Εργασία",1,149)]),i("q4","2307","Κώστας Δήμου","6900000004","Πρέβεζα","Κάμερες καταστήματος","rejected",1150,12,[s("Dahua 4MP Dome",6,95),s("Εργασία",1,357)]),i("q5","2306","Σταύρος Σταύρου","6900000005","Πάλαιρος","Θυροτηλέφωνο + κάμερα","pending",540,1,[s("Θυροτηλέφωνο IP",1,290),s("Εργασία",1,145)])],products:[{id:"p1",cat:"Κάμερες",model:"Hikvision IP 4MP Bullet",desc:"DS-2CD2043",cost:71.2,minQty:8,links:[{sup:"Xpatit",url:"https://xpatit.gr",code:"HK-2043"}]},{id:"p2",cat:"Κάμερες",model:"Dahua 4MP Dome",desc:"",cost:76},{id:"p3",cat:"Καταγραφικά",model:"NVR 8 καναλιών",desc:"με δίσκο 2TB",cost:196},{id:"p4",cat:"WiFi",model:"UniFi U6 Lite",desc:"Access Point",cost:95.2},{id:"p5",cat:"WiFi",model:"UniFi U6+",desc:"",cost:127.2},{id:"p6",cat:"Συναγερμοί",model:"Paradox MG5050",desc:"set",cost:384}],smoves:[{id:"m1",pid:"p1",qty:6}],custs:[{id:"c1",name:"Γιώργος Παπαδόπουλος",phone:"6900000001",address:"Πρέβεζα",ts:n-30*t}],tasks:[{id:"t1",title:"Εγκατάσταση CCTV",date:e,time:"09:00",cust:"Γιώργος Παπαδόπουλος",tel:"6900000001",addr:"Πρέβεζα",emps:["e1"],rems:[60,0],done:!1,chk:[{tx:"4 κάμερες",dn:!0},{tx:"NVR + δίσκος",dn:!1},{tx:"Ρύθμιση εφαρμογής",dn:!1}],quoteId:"q1"},{id:"t2",title:"Αυτοψία WiFi ξενοδοχείου",date:e,time:"13:30",cust:"Hotel Aktaion",addr:"Βόνιτσα",done:!1,clr:9},{id:"t3",title:"Service συναγερμού",date:e,time:"17:00",cust:"Μαρία Νικολάου",addr:"Λευκάδα",done:!0},{id:"t4",title:"Ασφάλεια βαν",kind:"due",rep:"y",date:new Date(n+5*t).toISOString().slice(0,10),done:!1,rems:[1440,0]},{id:"t5",title:"Παραγγελία Xpatit",date:new Date(n-2*t).toISOString().slice(0,10),done:!1},{id:"t6",title:"Τηλέφωνο σε Σταύρο για θυροτηλέφωνο",date:"",done:!1},{id:"t7",title:"Συνδρομή Starlink",kind:"due",rep:"m",date:new Date(n+9*t).toISOString().slice(0,10),done:!1},{id:"t8",title:"Εγκατάσταση WiFi",date:new Date(n+t).toISOString().slice(0,10),time:"10:00",cust:"Hotel Aktaion",addr:"Βόνιτσα",emps:["e1"],done:!1}],ldocs:[{id:"d3",kind:"purchase",party:"Xpatit",number:"ΤΔΑ 1182",cat:"Εμπορεύματα",net:820,vat:196.8,rate:24,gross:1016.8,date:e,ts:n-t,items:[]},{id:"d4",kind:"purchase",party:"Cosmote",number:"",cat:"Τηλεπικοινωνίες",net:45,vat:10.8,rate:24,gross:55.8,date:e,ts:n-3*t,items:[]},{id:"d1",kind:"sale",qid:"q1",number:"2311",party:"Γιώργος Παπαδόπουλος",net:1159,vat:278.16,rate:24,gross:1437.16,date:e,ts:n-2*t},{id:"d2",kind:"sale",party:"Μαρία Νικολάου",gross:780,date:e,ts:n-30*t}],wdays:[{id:"w1",empId:"e1",date:e,days:1,amount:60},{id:"w2",empId:"e1",date:e,days:1,amount:60}],needs:[{id:"n1",ts:n-t,title:"Κρουστικό δράπανο",qty:"1",notes:"",by:{uid:"e",name:"Νίκος Τεχνικός"},done:!1},{id:"n2",ts:n-3*t,title:"Βίδες γυψοσανίδας",qty:"2 κουτιά",by:{uid:"demo",name:"Διαχειριστής"},done:!0,doneAt:n-t}],wpays:[{id:"wp1",empId:"e1",date:e,amount:50,method:"cash"}],lpays:[{id:"p3",dir:"out",date:e,party:"Xpatit",docId:"d3",amount:400,method:"bank",note:""},{id:"p1",docId:"d1",amount:500,dir:"in",date:e,party:"Γιώργος Παπαδόπουλος",method:"bank",note:"Προκαταβολή"},{id:"p2",docId:"d2",amount:780,dir:"in",date:e,party:"Μαρία Νικολάου",method:"cash",note:""}],emps:[{id:"e1",name:"Νίκος Τεχνικός",rate:60}],st:{main:{vat:24,margin:25,next:2312},books:{opening:1500,costCats:["Εμπορεύματα","Υλικά","Καύσιμα","Τηλεπικοινωνίες","Λοιπά έξοδα"]}}}}const $l={quotes:"quotes",custs:"customers",tasks:"tasks",ldocs:"ledger_docs",lpays:"ledger_pays",emps:"employees",products:"products",smoves:"stock_moves",wdays:"workdays",wpays:"wagepays",needs:"tool_needs"},so={...$l,qlog:"quote_log",pbuys:"partner_buys"},A={quotes:[],custs:[],tasks:[],ldocs:[],lpays:[],emps:[],products:[],smoves:[],wdays:[],wpays:[],needs:[],st:{}},Py=new Set;function RA(n){Py.add(n)}function Re(){Py.forEach(n=>n())}const Le=new URLSearchParams(location.search).has("demo"),Cy=Le;let un=null,de=null,ba=[];const vr={},PA=()=>un&&un.currentUser||null;function CA(n){if(Le){Object.assign(A,kA()),n({email:"demo@techmate"}),setTimeout(Re,0);return}const t=Bp(Dl);un=tE(t),de=sA(t,{localCache:IA({tabManager:SA()})}),qw(un,e=>{ba.forEach(s=>s()),ba=[],e&&DA(),n(e)})}let Js=[],er=null;function DA(){er=null,ba.push(Cl(Hs(de,"settings"),n=>{const t={};n.docs.forEach(r=>t[r.id]=r.data()),A.st=t;const e=un.currentUser,s=e&&(t.roles&&t.roles.users||{})[e.uid],i=s&&s.role==="team"?"team:"+(s.empId||""):"owner";i!==er&&(er=i,Kf(i)),Re()},()=>{er===null&&(er="owner",Kf("owner"))})),ba.push(()=>{Js.forEach(n=>n()),Js=[]})}function Kf(n){Js.forEach(s=>s()),Js=[],Object.keys($l).forEach(s=>{s!=="tasks"&&(A[s]=[],delete vr[s])});const t=(s,i)=>Js.push(Cl(i,r=>{A[s]=r.docs.map(o=>({...o.data(),id:o.id})),vr[s]=!0,Re()},()=>{A[s]=[],Re()}));if(n==="owner"){Object.entries($l).forEach(([s,i])=>t(s,Hs(de,i)));return}const e=n.slice(5);t("tasks",Hs(de,"tasks")),t("needs",Hs(de,"tool_needs")),e&&(t("wdays",Bf(Hs(de,"workdays"),jf("empId","==",e))),t("wpays",Bf(Hs(de,"wagepays"),jf("empId","==",e))),Js.push(Cl(Jn(de,"employees",e),s=>{A.emps=s.exists()?[{...s.data(),id:s.id}]:[],vr.emps=!0,Re()},()=>{A.emps=[],Re()})))}function $A(n,t){return Lw(un,n,t)}function VA(){return Le?location.assign(location.pathname):Bw(un)}const Rt=n=>String(n||"").trim().toLowerCase(),C=(n,t=0)=>{const e=parseFloat(n);return isNaN(e)?t:e},F=n=>Math.round(n*100)/100,ae=n=>n.status||"pending",We=n=>!!(n&&n.kind==="install"),Qo={pending:"Σε αναμονή",accepted:"Δεκτή",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"};function Za(n){let t=0;return A.lpays.forEach(e=>{e.docId===n&&(t+=C(e.amount))}),F(t)}function Dy(n){return Math.max(0,F(C(n.gross)-Za(n.id)))}function Je(){const n={},t=e=>{const s=Rt(e)||"_none";return n[s]||(n[s]={k:s,name:e||"(χωρίς όνομα)",quotes:[],mins:[],last:0})};return A.custs.forEach(e=>{const s=t(e.name);s.name=e.name,s.rec=e,s.last=Math.max(s.last,e.upd||e.ts||0)}),A.quotes.forEach(e=>{const s=t(e.customer&&e.customer.name);(We(e)?s.mins:s.quotes).push(e),s.last=Math.max(s.last,e.ts||0)}),A.ldocs.forEach(e=>{e.kind==="sale"&&t(e.party)}),Object.values(n).map(e=>{e.won=0,e.owed=0,e.docs=A.ldocs.filter(r=>r.kind==="sale"&&Rt(r.party)===e.k),e.quotes.forEach(r=>{const o=ae(r);(o==="accepted"||o==="done")&&(e.won+=C(r.total))}),e.docs.forEach(r=>{e.owed+=Dy(r),e.last=Math.max(e.last,r.ts||0)}),e.owed=F(e.owed),e.won=F(e.won);const s=e.quotes.slice().sort((r,o)=>(o.ts||0)-(r.ts||0))[0],i=s&&s.customer||{};return e.info={},["phone","email","afm","address"].forEach(r=>e.info[r]=e.rec&&e.rec[r]||i[r]||""),e})}const Kt=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),ce=n=>JSON.parse(JSON.stringify(n)),ct=()=>A.st.main;let $y=()=>{};function NA(n){$y=n}const Rs=n=>{n.catch(t=>$y(t))};function qt(n,t){const e=ce(t);delete e.id;const s=A[n];if(s){const i=s.findIndex(r=>r.id===t.id);i>=0?s[i]=ce(t):s.push(ce(t))}Le||Rs(Xa(Jn(de,so[n],t.id),e)),Re()}function Vy(n,t){A[n]&&(A[n]=A[n].filter(e=>e.id!==t)),Le||Rs(_A(Jn(de,so[n],t))),Re()}const _i=()=>Le?{uid:"demo",email:"demo@techmate"}:un&&un.currentUser;function Ts(n,t,e){const s=(A[n]||[]).find(r=>r.id===t);s&&Object.keys(e).forEach(r=>{e[r]===void 0?delete s[r]:s[r]=e[r]});const i={};Object.keys(e).forEach(r=>i[r]=e[r]===void 0?Ry():e[r]),Le||Rs(ky(Jn(de,so[n],t),i)),Re()}function He(n,t,e){const s=A[n];let i=s&&s.find(o=>o.id===t);s&&!i&&(i={id:t},s.push(i)),i&&Object.keys(e).forEach(o=>{e[o]===void 0?delete i[o]:i[o]=ce(e[o])});const r={};Object.keys(e).forEach(o=>{o!=="id"&&(r[o]=e[o]===void 0?Ry():ce(e[o]))}),Le||Rs(Xa(Jn(de,so[n],t),r,{merge:!0})),Re()}function xA(n){A.st.main&&(A.st.main.next=n),Le||Rs(Xa(Jn(de,"settings","main"),{next:n},{merge:!0}))}const qu=n=>C(n.qty)*C(n.price)*(1-C(n.disc)/100),Bu=n=>F((n.lines||[]).reduce((t,e)=>t+qu(e),0));function Ny(n){const t=Bu(n),e=n.vatMode==="off",s=C(ct()&&ct().vat,24),i=e?0:F(t*s/100);return{sub:t,vat:i,vp:s,off:e,total:F(t+i)}}function xy(n){const t=C(n.cost,0);if(n.marginEur!=null&&n.marginEur!=="")return F(t+C(n.marginEur));const e=n.margin==null||n.margin===""?C(ct()&&ct().margin,25):C(n.margin);return F(t*(1+e/100))}function Oy(n,t){let e=0,s=0,i=0;return A.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(o=>{o.pid===n&&(e+=C(o.qty))})}),A.smoves.forEach(r=>{r.pid===n&&(e+=C(r.qty))}),A.quotes.forEach(r=>{if(r.id===t)return;const o=ae(r);(r.lines||[]).forEach(a=>{if(a.pid!==n||a.src!=="stock")return;const l=C(a.qty);o==="done"?r.noStock||(s+=l):o==="accepted"&&(i+=l)})}),F(e-s-i)}function Wf(n,t){if(!["main","logo"].includes(n))return;const e=A.st[n]||(A.st[n]={});Object.keys(t).forEach(i=>{e[i]=ce(t[i])});const s={};Object.keys(t).forEach(i=>s[i]=ce(t[i])),Le||Rs(Xa(Jn(de,"settings",n),s,{merge:!0})),Re()}function Hf(n,t,e,s){const i=(A[n]||[]).find(a=>a.id===t);if(!i)return;const r=e.split(".");let o=i;for(let a=0;a<r.length-1;a++)(!o[r[a]]||typeof o[r[a]]!="object")&&(o[r[a]]={}),o=o[r[a]];o[r[r.length-1]]=ce(s),Le||Rs(ky(Jn(de,so[n],t),{[e]:ce(s)})),Re()}/*! Capacitor: https://capacitorjs.com/ - MIT License */var bi;(function(n){n.Unimplemented="UNIMPLEMENTED",n.Unavailable="UNAVAILABLE"})(bi||(bi={}));class zc extends Error{constructor(t,e,s){super(t),this.message=t,this.code=e,this.data=s}}const OA=n=>{var t,e;return n!=null&&n.androidBridge?"android":!((e=(t=n==null?void 0:n.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||e===void 0)&&e.bridge?"ios":"web"},MA=n=>{const t=n.CapacitorCustomPlatform||null,e=n.Capacitor||{},s=e.Plugins=e.Plugins||{},i=()=>t!==null?t.name:OA(n),r=()=>i()!=="web",o=p=>{const m=u.get(p);return!!(m!=null&&m.platforms.has(i())||a(p))},a=p=>{var m;return(m=e.PluginHeaders)===null||m===void 0?void 0:m.find(I=>I.name===p)},l=p=>n.console.error(p),u=new Map,h=(p,m={})=>{const I=u.get(p);if(I)return console.warn(`Capacitor plugin "${p}" already registered. Cannot register plugins twice.`),I.proxy;const E=i(),$=a(p);let R;const B=async()=>(!R&&E in m?R=typeof m[E]=="function"?R=await m[E]():R=m[E]:t!==null&&!R&&"web"in m&&(R=typeof m.web=="function"?R=await m.web():R=m.web),R),H=(y,v)=>{var w,T;if($){const S=$==null?void 0:$.methods.find(_=>v===_.name);if(S)return S.rtype==="promise"?_=>e.nativePromise(p,v.toString(),_):(_,ge)=>e.nativeCallback(p,v.toString(),_,ge);if(y)return(w=y[v])===null||w===void 0?void 0:w.bind(y)}else{if(y)return(T=y[v])===null||T===void 0?void 0:T.bind(y);throw new zc(`"${p}" plugin is not implemented on ${E}`,bi.Unimplemented)}},K=y=>{let v;const w=(...T)=>{const S=B().then(_=>{const ge=H(_,y);if(ge){const Fe=ge(...T);return v=Fe==null?void 0:Fe.remove,Fe}else throw new zc(`"${p}.${y}()" is not implemented on ${E}`,bi.Unimplemented)});return y==="addListener"&&(S.remove=async()=>v()),S};return w.toString=()=>`${y.toString()}() { [capacitor code] }`,Object.defineProperty(w,"name",{value:y,writable:!1,configurable:!1}),w},st=K("addListener"),x=K("removeListener"),L=(y,v)=>{const w=st({eventName:y},v).then(_=>_),T=async()=>{const _=await w;await x({eventName:y,callbackId:_})},S=new Promise(_=>w.then(()=>_({remove:T})));return S.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await T()},S},b=new Proxy({},{get(y,v){switch(v){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return $?L:st;case"removeListener":return x;default:return K(v)}}});return s[p]=b,u.set(p,{name:p,proxy:b,platforms:new Set([...Object.keys(m),...$?[E]:[]])}),b};return e.convertFileSrc||(e.convertFileSrc=p=>p),e.getPlatform=i,e.handleError=l,e.isNativePlatform=r,e.isPluginAvailable=o,e.registerPlugin=h,e.Exception=zc,e.DEBUG=!!e.DEBUG,e.isLoggingEnabled=!!e.isLoggingEnabled,e},LA=n=>n.Capacitor=MA(n),Or=LA(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),io=Or.registerPlugin;class ju{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(t,e){let s=!1;this.listeners[t]||(this.listeners[t]=[],s=!0),this.listeners[t].push(e);const r=this.windowListeners[t];r&&!r.registered&&this.addWindowListener(r),s&&this.sendRetainedArgumentsForEvent(t);const o=async()=>this.removeListener(t,e);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,e,s){const i=this.listeners[t];if(!i){if(s){let r=this.retainedEventArguments[t];r||(r=[]),r.push(e),this.retainedEventArguments[t]=r}return}i.forEach(r=>r(e))}hasListeners(t){var e;return!!(!((e=this.listeners[t])===null||e===void 0)&&e.length)}registerWindowListener(t,e){this.windowListeners[e]={registered:!1,windowEventName:t,pluginEventName:e,handler:s=>{this.notifyListeners(e,s)}}}unimplemented(t="not implemented"){return new Or.Exception(t,bi.Unimplemented)}unavailable(t="not available"){return new Or.Exception(t,bi.Unavailable)}async removeListener(t,e){const s=this.listeners[t];if(!s)return;const i=s.indexOf(e);i!==-1&&this.listeners[t].splice(i,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const e=this.retainedEventArguments[t];e&&(delete this.retainedEventArguments[t],e.forEach(s=>{this.notifyListeners(t,s)}))}}const Qf=n=>encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Jf=n=>n.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class FA extends ju{async getCookies(){const t=document.cookie,e={};return t.split(";").forEach(s=>{if(s.length<=0)return;let[i,r]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");i=Jf(i).trim(),r=Jf(r).trim(),e[i]=r}),e}async setCookie(t){try{const e=Qf(t.key),s=Qf(t.value),i=t.expires?`; expires=${t.expires.replace("expires=","")}`:"",r=(t.path||"/").replace("path=",""),o=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${e}=${s||""}${i}; path=${r}; ${o};`}catch(e){return Promise.reject(e)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(e){return Promise.reject(e)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const e of t)document.cookie=e.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}io("CapacitorCookies",{web:()=>new FA});const UA=async n=>new Promise((t,e)=>{const s=new FileReader;s.onload=()=>{const i=s.result;t(i.indexOf(",")>=0?i.split(",")[1]:i)},s.onerror=i=>e(i),s.readAsDataURL(n)}),qA=(n={})=>{const t=Object.keys(n);return Object.keys(n).map(i=>i.toLocaleLowerCase()).reduce((i,r,o)=>(i[r]=n[t[o]],i),{})},BA=(n,t=!0)=>n?Object.entries(n).reduce((s,i)=>{const[r,o]=i;let a,l;return Array.isArray(o)?(l="",o.forEach(u=>{a=t?encodeURIComponent(u):u,l+=`${r}=${a}&`}),l.slice(0,-1)):(a=t?encodeURIComponent(o):o,l=`${r}=${a}`),`${s}&${l}`},"").substr(1):null,jA=(n,t={})=>{const e=Object.assign({method:n.method||"GET",headers:n.headers},t),i=qA(n.headers)["content-type"]||"";if(typeof n.data=="string")e.body=n.data;else if(i.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[o,a]of Object.entries(n.data||{}))r.set(o,a);e.body=r.toString()}else if(i.includes("multipart/form-data")||n.data instanceof FormData){const r=new FormData;if(n.data instanceof FormData)n.data.forEach((a,l)=>{r.append(l,a)});else for(const a of Object.keys(n.data))r.append(a,n.data[a]);e.body=r;const o=new Headers(e.headers);o.delete("content-type"),e.headers=o}else(i.includes("application/json")||typeof n.data=="object")&&(e.body=JSON.stringify(n.data));return e};class zA extends ju{async request(t){const e=jA(t,t.webFetchExtra),s=BA(t.params,t.shouldEncodeUrlParams),i=s?`${t.url}?${s}`:t.url,r=await fetch(i,e),o=r.headers.get("content-type")||"";let{responseType:a="text"}=r.ok?t:{};o.includes("application/json")&&(a="json");let l,u;switch(a){case"arraybuffer":case"blob":u=await r.blob(),l=await UA(u);break;case"json":l=await r.json();break;case"document":case"text":default:l=await r.text()}const h={};return r.headers.forEach((p,m)=>{h[m]=p}),{data:l,headers:h,status:r.status,url:r.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}io("CapacitorHttp",{web:()=>new zA});var Yf;(function(n){n.Dark="DARK",n.Light="LIGHT",n.Default="DEFAULT"})(Yf||(Yf={}));var Xf;(function(n){n.StatusBar="StatusBar",n.NavigationBar="NavigationBar"})(Xf||(Xf={}));class GA extends ju{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}io("SystemBars",{web:()=>new GA});const KA="modulepreload",WA=function(n){return"/"+n},Zf={},wn=function(t,e,s){let i=Promise.resolve();if(e&&e.length>0){document.getElementsByTagName("link");const o=document.querySelector("meta[property=csp-nonce]"),a=(o==null?void 0:o.nonce)||(o==null?void 0:o.getAttribute("nonce"));i=Promise.allSettled(e.map(l=>{if(l=WA(l),l in Zf)return;Zf[l]=!0;const u=l.endsWith(".css"),h=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${h}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":KA,u||(p.as="script"),p.crossOrigin="",p.href=l,a&&p.setAttribute("nonce",a),document.head.appendChild(p),u)return new Promise((m,I)=>{p.addEventListener("load",m),p.addEventListener("error",()=>I(new Error(`Unable to preload CSS for ${l}`)))})}))}function r(o){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=o,window.dispatchEvent(a),!a.defaultPrevented)throw o}return i.then(o=>{for(const a of o||[])a.status==="rejected"&&r(a.reason);return t().catch(r)})},HA="__capgo_keep_url_path_after_reload",Gc="__capgo_history_stack__",tp=100,QA=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(QA){const n=window;if(!n.__capgoHistoryPatched){n.__capgoHistoryPatched=!0;const t=()=>{try{if(n.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(HA)==="1"}catch{return!1}},e=()=>{try{const x=window.sessionStorage.getItem(Gc);if(!x)return{stack:[],index:-1};const L=JSON.parse(x);return!L||!Array.isArray(L.stack)||typeof L.index!="number"?{stack:[],index:-1}:L}catch{return{stack:[],index:-1}}},s=(x,L)=>{try{window.sessionStorage.setItem(Gc,JSON.stringify({stack:x,index:L}))}catch{}},i=()=>{try{window.sessionStorage.removeItem(Gc)}catch{}},r=x=>{try{const L=x??window.location.href,b=new URL(L instanceof URL?L.toString():L,window.location.href);return`${b.pathname}${b.search}${b.hash}`}catch{return null}},o=(x,L)=>{if(x.length<=tp)return{stack:x,index:L};const b=x.length-tp,y=x.slice(b),v=Math.max(0,L-b);return{stack:y,index:v}},a=x=>{document.readyState==="complete"||document.readyState==="interactive"?x():window.addEventListener("DOMContentLoaded",x,{once:!0})};let l=!1,u=!1,h=!1;const p=()=>{if(!l)return;const x=e(),L=r();if(L){if(x.stack.length===0){x.stack.push(L),x.index=0,s(x.stack,x.index);return}(x.index<0||x.index>=x.stack.length)&&(x.index=x.stack.length-1),x.stack[x.index]!==L&&(x.stack[x.index]=L,s(x.stack,x.index))}},m=(x,L)=>{if(!l||u)return;const b=r(x);if(!b)return;let{stack:y,index:v}=e();y.length===0?(y.push(b),v=y.length-1):L?((v<0||v>=y.length)&&(v=y.length-1),y[v]=b):v>=y.length-1?(y.push(b),v=y.length-1):(y=y.slice(0,v+1),y.push(b),v=y.length-1),{stack:y,index:v}=o(y,v),s(y,v)},I=()=>{if(!l||u)return;const x=e();if(x.stack.length===0){p();return}const L=x.index>=0&&x.index<x.stack.length?x.index:x.stack.length-1,b=r();if(x.stack.length===1&&b===x.stack[0])return;const y=x.stack[0];if(!y)return;u=!0;try{history.replaceState(history.state,document.title,y);for(let T=1;T<x.stack.length;T+=1)history.pushState(history.state,document.title,x.stack[T])}catch{u=!1;return}u=!1;const v=x.stack.length-1,w=L-v;w!==0?history.go(w):(history.replaceState(history.state,document.title,x.stack[L]),window.dispatchEvent(new PopStateEvent("popstate")))},E=()=>{!l||h||(h=!0,a(()=>{h=!1,I()}))};let $=null,R=null;const B=()=>{if(!l||u)return;const x=r();if(!x)return;const L=e(),b=L.stack.lastIndexOf(x);b>=0?L.index=b:(L.stack.push(x),L.index=L.stack.length-1);const y=o(L.stack,L.index);s(y.stack,y.index)},H=()=>{$&&R||($=history.pushState,R=history.replaceState,history.pushState=function(L,b,y){const v=$==null?void 0:$.call(history,L,b,y);return m(y,!1),v},history.replaceState=function(L,b,y){const v=R==null?void 0:R.call(history,L,b,y);return m(y,!0),v},window.addEventListener("popstate",B))},K=()=>{$&&(history.pushState=$,$=null),R&&(history.replaceState=R,R=null),window.removeEventListener("popstate",B)},st=x=>{if(l===x){l&&(p(),E());return}l=x,l?(H(),p(),E()):(K(),i())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",x=>{var L;const b=x,y=(L=b==null?void 0:b.detail)===null||L===void 0?void 0:L.enabled;typeof y=="boolean"?(n.__capgoKeepUrlPathAfterReload=y,st(y)):(n.__capgoKeepUrlPathAfterReload=!0,st(!0))}),st(t())}}var ep;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",n[n.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",n[n.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(ep||(ep={}));var np;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.PENDING=1]="PENDING",n[n.DOWNLOADING=2]="DOWNLOADING",n[n.INSTALLING=3]="INSTALLING",n[n.INSTALLED=4]="INSTALLED",n[n.FAILED=5]="FAILED",n[n.CANCELED=6]="CANCELED",n[n.DOWNLOADED=11]="DOWNLOADED"})(np||(np={}));var sp;(function(n){n[n.OK=0]="OK",n[n.CANCELED=1]="CANCELED",n[n.FAILED=2]="FAILED",n[n.NOT_AVAILABLE=3]="NOT_AVAILABLE",n[n.NOT_ALLOWED=4]="NOT_ALLOWED",n[n.INFO_MISSING=5]="INFO_MISSING"})(sp||(sp={}));const Mr=io("CapacitorUpdater",{web:()=>wn(()=>import("./web-CV7IFn3q.js"),[]).then(n=>new n.CapacitorUpdaterWeb)}),Ps=Or.isNativePlatform(),Ne=Ps?io("TechMate"):null,Vl={accent:0,view:"lists",sun:!1,showDone:!0,compact:!1,defRems:"60,0",dueRems:"1440,0",rep:!0,repMin:5,repMax:6,snooze:10,alarmSound:!1,clockMode:!1,syncMin:60,notifyNew:!0,wAlpha:95,wMode:"todo",wList:"",wDays:2,autoUpd:!0,empClr:"{}",bUri:"",bAuto:!0,bLast:0};let hs={...Vl};const My="tm-settings",Gt=()=>hs;async function Lr(){if(Ne)try{const n=await Ne.getSettings();hs={...Vl,...n||{}}}catch{}else try{hs={...Vl,...JSON.parse(localStorage.getItem(My)||"{}")}}catch{}return hs}async function _r(n,t){if(hs={...hs,[n]:t},Ne)try{await Ne.setSetting({k:n,v:t})}catch{}else try{localStorage.setItem(My,JSON.stringify(hs))}catch{}}const Mt=async(n,t={},e=null)=>{if(!Ne)return e;try{return await Ne[n](t)}catch(s){return{error:s&&s.message||"σφάλμα"}}},Et={setSession:n=>Mt("setSession",n),clearSession:()=>Mt("clearSession"),setTasks:(n,t,e)=>Mt("setTasks",{json:n,emps:t,lists:e}),testNotif:()=>Mt("testNotif"),openBattery:()=>Mt("openBattery"),openNotifSettings:()=>Mt("openNotifSettings"),exactAlarms:()=>Mt("exactAlarms",{},{ok:!0}),msStatus:()=>Mt("msStatus",{},{connected:!1}),msLogin:()=>Mt("msLogin"),msSync:()=>Mt("msSync",{},{ok:!1}),msDisconnect:()=>Mt("msDisconnect"),pull:()=>Mt("pull",{},{ok:!1}),backupPick:()=>Mt("backupPick",{},{error:"Μόνο στο κινητό"}),backupWrite:n=>Mt("backupWrite",{json:n},{error:"Μόνο στο κινητό"}),takeLaunch:()=>Mt("takeLaunch",{},{}),installApk:(n,t)=>Mt("installApk",{url:n,size:t}),copy:async n=>{if(Ne)return Mt("copy",{text:n});try{await navigator.clipboard.writeText(n)}catch{}},paste:async()=>{if(Ne){const n=await Mt("paste");return n&&n.text||""}try{return await navigator.clipboard.readText()}catch{return""}},share:n=>Ne?Mt("share",{text:n}):Et.copy(n),shareFile:n=>Mt("shareFile",n,{error:"Μόνο στο κινητό"}),refreshWidgets:()=>Mt("refreshWidgets")};function tc(n,t){Ne&&Ne.addListener(n,t)}const Ly="1.2.0",JA="https://raw.githubusercontent.com/cursing/techmate-app-releases/main/latest.json",Fy=Or.isNativePlatform(),ip=(n,t)=>{const e=String(n).split(".").map(Number),s=String(t).split(".").map(Number);for(let i=0;i<3;i++){const r=(e[i]||0)-(s[i]||0);if(r)return r}return 0},Vt={state:"idle",latest:null,pct:0,err:"",needApk:!1,checkedAt:0};let Uy=()=>{};function YA(n){Uy=n}const De=n=>{Object.assign(Vt,n),Uy()};function XA(){Fy&&(Mr.notifyAppReady().catch(()=>{}),Mr.addListener("download",n=>{Vt.state==="downloading"&&De({pct:Math.round(n.percent||0)})}),tc("apk",n=>{Vt.state==="downloading"&&De({pct:n&&n.pct||0})}),Nl(),document.addEventListener("visibilitychange",()=>{!document.hidden&&Date.now()-Vt.checkedAt>30*6e4&&Nl()}))}async function Nl(n){if(!Fy){n&&De({state:"none"});return}if(Vt.state!=="downloading"){n&&De({state:"checking",err:""});try{const t=await fetch(JA+"?t="+Date.now(),{cache:"no-store"});if(!t.ok)throw new Error("HTTP "+t.status);const e=await t.json();if(Vt.checkedAt=Date.now(),!e.version||ip(e.version,Ly)<=0)return De({state:n?"none":"idle",latest:null});let s="0";try{s=(await Mr.getBuiltinVersion()).version||"0"}catch{}De({state:"available",latest:e,needApk:!!e.minNative&&ip(s,e.minNative)<0,err:""})}catch{De({state:n?"error":"idle",err:n?"Δεν μπόρεσα να ελέγξω για ενημέρωση. Έλεγξε τη σύνδεση.":""})}}}async function ZA(){const n=Vt.latest;if(!(!n||Vt.state==="downloading")){if(Vt.needApk){De({state:"downloading",pct:0,err:""});const t=await Et.installApk(n.apk,n.apkSize||0);De({state:"available",err:t&&t.error?t.error:""});return}De({state:"downloading",pct:0,err:""});try{const t=await Mr.download({url:n.zip,version:n.version,checksum:n.sha256||""});await Mr.set(t)}catch(t){De({state:"available",err:"Η λήψη απέτυχε: "+(t&&(t.message||t.code)||"άγνωστο σφάλμα")})}}}const tS=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),xl=n=>tS.format(Math.round((n||0)*100)/100),rp=n=>n<10?"0"+n:""+n,pt=()=>{const n=new Date;return n.getFullYear()+"-"+rp(n.getMonth()+1)+"-"+rp(n.getDate())},eS=n=>(n=C(n,24),[24,13,6,0].includes(n)?n:24),zu=()=>{const n=_i();return n&&(A.st.roles&&A.st.roles.users||{})[n.uid]||null},yt=()=>{const n=zu();return!!(n&&n.role==="team")},xe=()=>{const n=zu();return n&&n.empId||""},Mn=()=>{const n=_i();if(!n)return null;const t=zu();return{uid:n.uid,name:t?t.name||"Υπάλληλος":"Διαχειριστής"}},Gu=n=>!yt()||!!(n&&n.by&&_i()&&n.by.uid===_i().uid),Jo={pending:"Σε αναμονή απάντησης",accepted:"Έγινε δεκτή, προς εγκατάσταση",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"},Kc=(n,t,e)=>qt("qlog",{id:Kt(),qid:n.id||"",number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:t,text:e}),qy=n=>A.ldocs.find(t=>t.kind==="sale"&&(t.qid===n.id||!t.qid&&n.number&&t.number===n.number&&Rt(t.party)===Rt(n.customer&&n.customer.name)))||null,op=n=>!(n&&n.war&&n.war.on===!1),nS=n=>{const t=n&&n.war;return t&&t.m!=null&&t.m!==""?Math.max(0,Math.floor(C(t.m,0))):C(ct().warrantyMonths,24)};function sS(n,t){let e=0,s=0,i=0;return A.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(o=>{o.pid===n&&(e+=C(o.qty))})}),A.smoves.forEach(r=>{r.pid===n&&(e+=C(r.qty))}),A.quotes.forEach(r=>{if(r.id===t)return;const o=ae(r);(r.lines||[]).forEach(a=>{if(a.pid!==n||a.src!=="stock")return;const l=C(a.qty);o==="done"?r.noStock||(s+=l):o==="accepted"&&(i+=l)})}),F(e-s-i)}function iS(n,t){const e=[],s=qy(n);if(t==="pending"||t==="rejected"?s&&s.qid===n.id&&s.note==="Από προσφορά "+(n.number||"")&&Za(s.id)===0&&e.push("Θα αφαιρεθεί το παραστατικό πώλησης που είχε δημιουργηθεί αυτόματα."):!s&&ct()&&ct().autoSale!==!1&&e.push("Θα δημιουργηθεί παραστατικό πώλησης "+xl(By(n).gross)+" στα Λογιστικά."),t==="done"&&!n.install&&e.push("Θα καταχωρηθεί ως εγκατάσταση με σημερινή ημερομηνία."),(t==="accepted"||t==="done")&&n.gid){const i=A.quotes.filter(r=>r.gid===n.gid&&r.id!==n.id&&ae(r)==="pending").length;i&&e.push("Οι "+i+" άλλες εναλλακτικές θα μπουν ως «Απορρίφθηκε».")}return e}function By(n){const t=n.vatMode==="off"?0:eS(ct().vat),e=Bu(n),s=F(e*t/100);return{rate:t,net:e,vat:s,gross:F(e+s)}}function rS(n,t){const e=A.quotes.find(a=>a.id===n);if(!e||ae(e)===t)return{ok:!1};if(!ct())return{ok:!1,msg:"Δεν έχουν φορτώσει οι ρυθμίσεις. Περίμενε λίγο ή έλεγξε τη σύνδεση."};const s=ce(e);Kc(s,"status",Jo[ae(s)]+" → "+Jo[t]),t==="done"&&!s.install&&(s.install={date:pt(),months:op(s)?nS(s):0,serials:"",nw:!op(s)}),s.status=t,s.statusDate=pt();const i=[];t==="accepted"&&(s.lines||[]).forEach(a=>{if(a.pid&&a.src==="stock"&&C(a.qty)>sS(a.pid,s.id)){const l=A.products.find(u=>u.id===a.pid);i.push(l?l.model:a.desc)}});const r=[],o=qy(s);if(t==="pending"||t==="rejected")o&&o.qid===s.id&&o.note==="Από προσφορά "+(s.number||"")&&Za(o.id)===0&&(Vy("ldocs",o.id),r.push("Αφαιρέθηκε το αυτόματο παραστατικό πώλησης."));else if(!o&&ct().autoSale!==!1){const a=By(s),l={id:Kt(),ts:Date.now(),kind:"sale",date:pt(),party:s.customer&&s.customer.name||"Πελάτης",number:s.number||"",cat:"",net:a.net,vat:a.vat,gross:a.gross,rate:a.rate,note:"Από προσφορά "+(s.number||""),items:[],qid:s.id};qt("ldocs",l),A.lpays.forEach(u=>{u.qid===s.id&&!u.docId&&Ts("lpays",u.id,{docId:l.id,party:l.party||u.party})}),Kc(s,"edit","Δημιουργήθηκε αυτόματα παραστατικό πώλησης ("+xl(a.gross)+")."),r.push("Δημιουργήθηκε παραστατικό πώλησης "+xl(a.gross)+" στα Λογιστικά.")}return s.gid&&(t==="accepted"||t==="done")&&A.quotes.filter(a=>a.gid===s.gid&&a.id!==s.id&&ae(a)==="pending").forEach(a=>{const l=ce(a);l.status="rejected",l.statusDate=pt(),Kc(l,"status","Σε αναμονή → Απορρίφθηκε (έγινε δεκτή η εναλλακτική "+(s.number||"")+")"),qt("quotes",l)}),qt("quotes",s),i.length&&r.push("Δεν επαρκεί το απόθεμα για: "+i.join(", ")+"."),{ok:!0,msg:["Η κατάσταση άλλαξε: "+Jo[t]+"."].concat(r).join(" ")}}function oS(n,t){const e=String(t.name||"").trim();if(!e)return{msg:"Γράψε όνομα πελάτη."};const s=Rt(e),i=Je(),r=n&&i.find(u=>u.k===n);if((!n||n!==s)&&i.some(u=>u.k===s))return{msg:"Υπάρχει ήδη πελάτης «"+e+"». Άνοιξε τον φάκελό του."};const o=n&&A.custs.find(u=>Rt(u.name)===n),a=o?ce(o):{id:Kt(),ts:Date.now()},l=u=>String(t[u]||"").trim();return Object.assign(a,{name:e,phone:l("phone"),email:l("email"),afm:l("afm"),address:l("address"),notes:l("notes"),upd:Date.now()}),qt("custs",a),n&&n!==s&&r&&(r.quotes.concat(r.mins).forEach(u=>{const h=ce(u);h.customer=Object.assign({},h.customer||{},{name:e}),qt("quotes",h)}),A.ldocs.forEach(u=>{u.kind==="sale"&&Rt(u.party)===n&&Ts("ldocs",u.id,{party:e})}),A.lpays.forEach(u=>{u.dir==="in"&&Rt(u.party)===n&&Ts("lpays",u.id,{party:e})})),{ok:!0,k:s}}const zt=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),aS=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),lt=n=>aS.format(Math.round((n||0)*100)/100),jy=n=>String(F(n)).replace(".",","),ei=n=>C(String(n).replace(",","."),NaN),Fr=n=>{if(!n)return"";const t=String(n).slice(0,10).split("-");return t[2]+"/"+t[1]+"/"+t[0]},ap=n=>n<10?"0"+n:""+n,Fs=n=>n.getFullYear()+"-"+ap(n.getMonth()+1)+"-"+ap(n.getDate()),zy=()=>A.st.books||{},cS=n=>(n=C(n,24),[24,13,6,0].includes(n)?n:24);let Ur="month";try{Ur=localStorage.getItem("tm_period")||"month"}catch{}const lS=[["month","Μήνας"],["prevmonth","Προηγ. μήνας"],["quarter","Τρίμηνο"],["year","Έτος"],["all","Όλα"]];function Gy(){const n=new Date,t=n.getFullYear(),e=n.getMonth();switch(Ur){case"month":return[Fs(new Date(t,e,1)),Fs(new Date(t,e+1,0))];case"prevmonth":return[Fs(new Date(t,e-1,1)),Fs(new Date(t,e,0))];case"quarter":{const s=Math.floor(e/3)*3;return[Fs(new Date(t,s,1)),Fs(new Date(t,s+3,0))]}case"year":return[t+"-01-01",t+"-12-31"];default:return["",""]}}const cs=n=>{const t=Gy();return(!t[0]||n>=t[0])&&(!t[1]||n<=t[1])},uS=()=>{const n=Gy();return!n[0]&&!n[1]?"Όλες οι κινήσεις":Fr(n[0])+" έως "+Fr(n[1])};function Ky(n){let t=0,e=0;return A.wdays.forEach(s=>{s.empId===n&&(t+=C(s.amount))}),A.wpays.forEach(s=>{s.empId===n&&(e+=C(s.amount))}),{earned:F(t),paid:F(e),bal:F(t-e)}}function ec(){const n={},t={},e=(i,r)=>{const o=Rt(r)||"—";return i[o]||(i[o]={name:(r||"").trim()||"Χωρίς όνομα",inv:0,paid:0})};A.ldocs.forEach(i=>{e(i.kind==="sale"?t:n,i.party).inv+=C(i.gross)}),A.lpays.forEach(i=>{e(i.dir==="in"?t:n,i.party).paid+=C(i.amount)});const s=i=>Object.values(i).map(r=>(r.inv=F(r.inv),r.paid=F(r.paid),r.bal=F(r.inv-r.paid),r)).sort((r,o)=>o.bal-r.bal);return{sup:s(n),cus:s(t)}}function dS(){const n={sNet:0,sVat:0,pNet:0,pVat:0,inBank:0,inCash:0,outBank:0,outCash:0,wages:0,cats:{}};A.ldocs.forEach(i=>{if(!(i.opening||!cs(i.date)))if(i.kind==="sale")n.sNet+=C(i.net),n.sVat+=C(i.vat);else{n.pNet+=C(i.net),n.pVat+=C(i.vat);const r=i.cat||"Χωρίς κατηγορία";n.cats[r]=(n.cats[r]||0)+C(i.net)}}),A.lpays.forEach(i=>{cs(i.date)&&(i.dir==="in"?i.method==="bank"?n.inBank+=C(i.amount):n.inCash+=C(i.amount):i.method==="bank"?n.outBank+=C(i.amount):n.outCash+=C(i.amount))}),A.wdays.forEach(i=>{cs(i.date)&&(n.wages+=C(i.amount))}),A.wpays.forEach(i=>{cs(i.date)&&(i.method==="bank"?n.outBank+=C(i.amount):n.outCash+=C(i.amount))}),Object.keys(n).forEach(i=>{typeof n[i]=="number"&&(n[i]=F(n[i]))}),n.vatDue=F(n.sVat-n.pVat),n.profit=F(n.sNet-n.pNet-n.wages);let t=C(zy().opening,0),e=0;A.lpays.forEach(i=>{const r=i.dir==="in"?C(i.amount):-C(i.amount);i.method==="bank"?t+=r:e+=r}),A.wpays.forEach(i=>{i.method==="bank"?t-=C(i.amount):e-=C(i.amount)}),n.bank=F(t),n.cash=F(e),n.rcvAll=F(n.inBank+n.inCash),n.nRcv=A.lpays.filter(i=>i.dir==="in"&&cs(i.date)).length;const s=ec();return n.owe=0,n.due=0,n.nOwe=0,n.nDue=0,n.wOwe=0,n.nW=0,s.sup.forEach(i=>{i.bal>.004&&(n.owe+=i.bal,n.nOwe++)}),s.cus.forEach(i=>{i.bal>.004&&(n.due+=i.bal,n.nDue++)}),A.emps.forEach(i=>{const r=Ky(i.id).bal;r>.004&&(n.wOwe+=r,n.nW++)}),n.owe=F(n.owe),n.due=F(n.due),n.wOwe=F(n.wOwe),n}function ro(n){const t=Za(n.id),e=F(C(n.gross)-t);return C(n.gross)!==0&&e<=.004?{k:"paid",t:n.kind==="sale"?"Εισπράχθηκε":"Πληρώθηκε",rem:0}:t>0?{k:"part",t:"Μερικώς",rem:e}:{k:"open",t:n.kind==="sale"?"Δεν εισπράχθηκε":"Ανεξόφλητο",rem:e}}const hS=(n,t)=>{const e=t==="in"?"sale":"purchase",s=Rt(n);return A.ldocs.filter(i=>i.kind===e&&(!s||Rt(i.party)===s)&&ro(i).k!=="paid").sort((i,r)=>i.date<r.date?1:-1)},Wy=[["sum","Σύνοψη"],["docs","Παραστατικά"],["pays","Πληρωμές"],["bal","Υπόλοιπα"]];let Yo="all",ft=null;const Hy=()=>!!ft;function fS(){ft=null}const $o=(n,t,e="")=>`<div class="kpi"><b class="${e}">${n}</b><span>${t}</span></div>`,pS={paid:"p-ok",part:"p-w",open:"p-b"},mS=(n,t)=>`<div class="chips">${Wy.map(([e,s])=>`<a href="#/books/${e}" class="chip${e===n?" on":""}">${s}</a>`).join("")}</div>
  ${n==="bal"?"":`<div class="chips">${lS.map(([e,s])=>`<button data-bper="${e}" class="${e===Ur?"on":""}">${s}</button>`).join("")}</div><div class="plabel">${uS()}</div>`}${t?"":'<div class="upd">Φόρτωση…</div>'}`;function gS(){const n=dS(),t=Object.entries(n.cats).sort((e,s)=>s[1]-e[1]);return`<div class="kpis">${$o(lt(n.sNet),"Έσοδα (καθαρά)","ok")}${$o(lt(n.pNet),"Αγορές και έξοδα (καθαρά)","bad")}${$o(lt(n.wages),"Μεροκάματα")}${$o(lt(n.profit),"Κέρδος περιόδου",n.profit<0?"bad":"")}</div>
  ${n.sVat||n.pVat?`<div class="h">ΦΠΑ</div><div class="card"><div class="tot"><span>ΦΠΑ πωλήσεων</span><span>${lt(n.sVat)}</span></div><div class="tot"><span>ΦΠΑ αγορών</span><span>${lt(n.pVat)}</span></div>
    <div class="tot big"><span>${n.vatDue>=0?"ΦΠΑ προς απόδοση":"ΦΠΑ πιστωτικό"}</span><span>${lt(Math.abs(n.vatDue))}</span></div></div>`:""}
  <div class="h">Χρήματα</div><div class="card"><div class="tot"><span>Εισπράξεις περιόδου${n.nRcv?" ("+n.nRcv+")":""}</span><span>${lt(n.rcvAll)}</span></div>
    <div class="tot"><span>· τράπεζα ${lt(n.inBank)} · μετρητά ${lt(n.inCash)}</span><span></span></div>
    <div class="tot"><span>Πληρωμές περιόδου</span><span>${lt(F(n.outBank+n.outCash))}</span></div>
    <div class="tot big"><span>Τράπεζα σήμερα</span><span>${lt(n.bank)}</span></div><div class="tot big"><span>Μετρητά στο ταμείο</span><span>${lt(n.cash)}</span></div></div>
  <div class="h">Υπόλοιπα</div><div class="card">
    <a class="row" href="#/books/bal"><div class="av">👥</div><div class="t"><b>Πελάτες μου χρωστούν</b><span>${n.nDue} πελάτες</span></div><span class="amt">${lt(n.due)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">🏭</div><div class="t"><b>Χρωστάω σε προμηθευτές</b><span>${n.nOwe} προμηθευτές</span></div><span class="amt">${lt(n.owe)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">👷</div><div class="t"><b>Μεροκάματα που χρωστάω</b><span>${n.nW} υπάλληλοι</span></div><span class="amt">${lt(n.wOwe)}</span></a></div>
  ${t.length?`<div class="h">Έξοδα ανά κατηγορία</div><div class="card">${t.map(([e,s])=>`<div class="tot"><span>${zt(e)}</span><span>${lt(s)}</span></div>`).join("")}</div>`:""}`}function yS(){const n=A.ldocs.filter(t=>cs(t.date)&&(Yo==="all"||t.kind===Yo)).sort((t,e)=>t.date<e.date?1:t.date>e.date?-1:(e.ts||0)-(t.ts||0));return`<div class="chips">${[["all","Όλα"],["sale","Πωλήσεις"],["purchase","Αγορές"]].map(([t,e])=>`<button data-bdk="${t}" class="${Yo===t?"on":""}">${e}</button>`).join("")}</div>
  <div class="card">${n.map(t=>{const e=ro(t);return`<div class="row"><div class="av">${t.kind==="sale"?"📤":"📥"}</div>
    <div class="t"><b>${zt(t.party)}</b><span>${Fr(t.date)}${t.number?" · "+zt(t.number):""}${t.cat?" · "+zt(t.cat):""}${t.opening?" · παλιό υπόλοιπο":""}</span>${t.note?`<span>${zt(t.note)}</span>`:""}
    ${e.k!=="paid"?`<button class="lnk" data-bpay="${zt(t.id)}">${t.kind==="sale"?"💶 Είσπραξη":"💶 Πληρωμή"} ${lt(e.rem)}</button>`:""}</div>
    <div class="r"><div class="amt">${lt(t.gross)}</div><span class="pill ${pS[e.k]}">${e.t}</span></div></div>`}).join("")||'<div class="empty">Κανένα παραστατικό στην περίοδο</div>'}</div>`}function vS(){return`<div class="card">${A.lpays.filter(t=>cs(t.date)).sort((t,e)=>t.date<e.date?1:t.date>e.date?-1:(e.ts||0)-(t.ts||0)).map(t=>`<div class="row"><div class="av">${t.dir==="in"?"⬇️":"⬆️"}</div>
    <div class="t"><b>${zt(t.party)}</b><span>${Fr(t.date)} · ${t.method==="bank"?"τράπεζα":"μετρητά"}${t.note?" · "+zt(t.note):""}</span></div>
    <div class="r"><div class="amt ${t.dir==="in"?"ok":"bad"}">${t.dir==="in"?"+":"−"}${lt(t.amount)}</div></div></div>`).join("")||'<div class="empty">Καμία κίνηση στην περίοδο</div>'}</div>`}function _S(){const n=ec(),t=(s,i,r)=>s.map(o=>`<div class="row"><div class="t"><b>${zt(o.name)}</b><span>τιμολογημένα ${lt(o.inv)} · πληρωμένα ${lt(o.paid)}</span>
    ${o.bal>.004?`<button class="lnk" data-bnew="${i}" data-party="${zt(o.name)}">${i==="in"?"💶 Νέα είσπραξη":"💶 Νέα πληρωμή"}</button>`:""}</div>
    <div class="r"><span class="pill ${o.bal>.004?"p-b":o.bal<-.004?"p-w":"p-ok"}">${o.bal>.004?lt(o.bal):o.bal<-.004?"πιστωτικό "+lt(-o.bal):"εξοφλημένο"}</span></div></div>`).join("")||`<div class="empty">${r}</div>`,e=A.emps.slice().sort((s,i)=>String(s.name).localeCompare(i.name,"el"));return`<div class="h">Πελάτες</div><div class="card">${t(n.cus,"in","Δεν υπάρχουν πελάτες με παραστατικά")}</div>
  <div class="h">Προμηθευτές</div><div class="card">${t(n.sup,"out","Δεν υπάρχουν προμηθευτές")}</div>
  ${e.length?`<div class="h">Υπάλληλοι</div><div class="card">${e.map(s=>{const i=Ky(s.id);return`<div class="row"><div class="t"><b>${zt(s.name)}</b><span>δεδουλευμένα ${lt(i.earned)} · πληρωμένα ${lt(i.paid)}</span></div>
    <div class="r"><span class="pill ${i.bal>.004?"p-b":i.bal<-.004?"p-w":"p-ok"}">${i.bal>.004?lt(i.bal):i.bal<-.004?"προπληρωμή "+lt(-i.bal):"τακτοποιημένο"}</span></div></div>`}).join("")}</div>`:""}`}const Ue=(n,t,e="")=>`<label class="f">${t}<input class="in" data-bf="${n}" value="${zt(ft.v[n]??"")}" ${e}></label>`,br=(n,t)=>`<div class="seg">${t.map(([e,s])=>`<button data-bseg="${n}" data-v="${e}" class="${ft.v[n]===e?"on":""}">${s}</button>`).join("")}</div>`;function bS(){const n=ft.v,t=hS(n.party,n.dir),e=ec();return n.docId&&!t.some(s=>s.id===n.docId)&&(n.docId=""),`<div class="card pad">${br("dir",[["in","Είσπραξη από πελάτη"],["out","Πληρωμή σε προμηθευτή"]])}
    ${Ue("date","Ημερομηνία",'type="date"')}${Ue("party",n.dir==="in"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.dir==="in"?e.cus:e.sup).map(s=>`<option value="${zt(s.name)}">`).join("")}</datalist>
    <label class="f">Παραστατικό<select class="in" data-bf="docId"><option value="">Χωρίς σύνδεση με παραστατικό</option>${t.map(s=>`<option value="${zt(s.id)}" ${s.id===n.docId?"selected":""}>${Fr(s.date)} · ${zt(s.party)}${s.number?" · "+zt(s.number):""} · υπόλοιπο ${lt(ro(s).rem)}</option>`).join("")}</select></label>
    ${Ue("amount","Ποσό €",'inputmode="decimal"')}${br("method",[["bank","Τράπεζα"],["cash","Μετρητά"]])}${Ue("note","Σημείωση")}</div>`}function Ku(n){const t=ei(n.amount),e=C(n.rate,24);let s,i,r;return n.mode==="net"?(s=F(t),i=F(s*e/100),r=F(s+i)):(r=F(t),s=F(r/(1+e/100)),i=F(r-s)),{net:s,vat:i,gross:r,rate:e}}function wS(){const n=ft.v,t=ec(),e=isNaN(ei(n.amount))?null:Ku(n);return`<div class="card pad">${br("kind",[["purchase","Αγορά / έξοδο"],["sale","Πώληση"]])}
    ${Ue("date","Ημερομηνία",'type="date"')}${Ue("party",n.kind==="sale"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.kind==="sale"?t.cus:t.sup).map(s=>`<option value="${zt(s.name)}">`).join("")}</datalist>
    ${Ue("number","Αριθμός παραστατικού")}
    ${n.kind==="purchase"?`${Ue("cat","Κατηγορία εξόδου",'list="bcl" autocomplete="off"')}<datalist id="bcl">${(zy().costCats||[]).map(s=>`<option value="${zt(s)}">`).join("")}</datalist>`:""}
    ${Ue("amount","Ποσό €",'inputmode="decimal"')}${br("mode",[["gross","Το ποσό είναι με ΦΠΑ"],["net","Το ποσό είναι χωρίς ΦΠΑ"]])}
    <div class="f">Συντελεστής ΦΠΑ</div>${br("rate",[["24","24%"],["13","13%"],["6","6%"],["0","0%"]])}
    <div id="bprev" class="plabel">${e?`Καθαρό ${lt(e.net)} · ΦΠΑ ${lt(e.vat)} · Σύνολο ${lt(e.gross)}`:""}</div>${Ue("note","Σημείωση")}</div>`}function IS(n,t){if(n==="newpay"||n==="newdoc"){const s=n==="newpay"?"pay":"doc";return(!ft||ft.kind!==s)&&(ft={kind:s,v:s==="pay"?{dir:"in",date:pt(),party:"",docId:"",amount:"",method:"bank",note:"",...wa||{}}:{kind:"purchase",date:pt(),party:"",number:"",cat:"",amount:"",mode:"gross",rate:String(cS(ct()&&ct().vat)),note:""}}),wa=null,`<header class="top"><a class="ib" data-bact="cancel">←</a><h1>${s==="pay"?"Νέα κίνηση":"Νέο παραστατικό"}</h1></header><main class="body ed">${s==="pay"?bS():wS()}
      ${ft.msg?`<div class="err box">${zt(ft.msg)}</div>`:""}</main><div class="bar"><button class="btn b2" data-bact="cancel">Άκυρο</button><button class="btn b1" data-bact="save">💾 Αποθήκευση</button></div>`}ft=null;const e=Wy.some(([s])=>s===n)?n:"sum";return`<header class="top"><a class="ib" href="#/menu">←</a><h1>Λογιστικά</h1></header><main class="body">${mS(e,t)}${{sum:gS,docs:yS,pays:vS,bal:_S}[e]()}</main>
    <div class="fab2"><a class="btn b2" href="#/books/newdoc">＋ Παραστατικό</a><a class="btn b1" href="#/books/newpay">＋ Είσπραξη / πληρωμή</a></div>`}let wa=null;function ES(){const n=ft.v;if(!n.date)return"Βάλε ημερομηνία.";if(ft.kind==="pay"){let s=String(n.party||"").trim();const i=n.docId&&A.ldocs.find(r=>r.id===n.docId);return i&&(s=i.party),s?!String(n.amount).trim()||isNaN(ei(n.amount))?"Βάλε ποσό.":(qt("lpays",{dir:n.dir,date:n.date,party:s,docId:n.docId||"",amount:F(ei(n.amount)),method:n.method,note:String(n.note||"").trim(),id:Kt(),ts:Date.now()}),""):"Βάλε "+(n.dir==="in"?"πελάτη":"προμηθευτή")+"."}const t=String(n.party||"").trim();if(!t)return"Βάλε "+(n.kind==="sale"?"πελάτη":"προμηθευτή")+".";if(!String(n.amount).trim()||isNaN(ei(n.amount)))return"Βάλε ποσό.";const e=Ku(n);return qt("ldocs",{kind:n.kind,date:n.date,party:t,number:String(n.number||"").trim(),cat:n.kind==="purchase"?String(n.cat||"").trim():"",net:e.net,vat:e.vat,gross:e.gross,rate:e.rate,note:String(n.note||"").trim(),items:[],id:Kt(),ts:Date.now()}),""}function TS(n,t,e,s){const i=n.closest("[data-bper],[data-bdk],[data-bpay],[data-bnew],[data-bseg],[data-bact]");if(!i)return!1;const r=i.dataset;if(r.bper){Ur=r.bper;try{localStorage.setItem("tm_period",Ur)}catch{}}else if(r.bdk)Yo=r.bdk;else if(r.bpay){const o=A.ldocs.find(a=>a.id===r.bpay);return o&&(wa={dir:o.kind==="sale"?"in":"out",party:o.party,docId:o.id,amount:jy(ro(o).rem)}),ft=null,t("#/books/newpay"),!0}else{if(r.bnew)return wa={dir:r.bnew,party:r.party},ft=null,t("#/books/newpay"),!0;if(r.bseg)ft.v[r.bseg]=r.v,r.bseg==="dir"&&(ft.v.docId="");else if(r.bact==="cancel"){const o=ft&&ft.kind;return ft=null,t(o==="doc"?"#/books/docs":"#/books/pays",!0),!0}else if(r.bact==="save"){const o=ES();if(o)ft.msg=o;else{const a=ft.kind;return ft=null,s(a==="pay"?"Η κίνηση αποθηκεύτηκε.":"Το παραστατικό αποθηκεύτηκε."),t(a==="doc"?"#/books/docs":"#/books/pays",!0),!0}}}return e(),!0}function AS(n,t){if(!ft||!n.dataset.bf)return!1;const e=n.dataset.bf;if(ft.v[e]=n.value,ft.msg="",e==="docId"){const s=A.ldocs.find(i=>i.id===n.value);s&&(ft.v.party=s.party,ft.v.amount=jy(ro(s).rem)),t()}else if(!(e==="party"&&ft.kind==="pay")){if(e==="amount"&&ft.kind==="doc"){const s=document.getElementById("bprev");if(s){const i=isNaN(ei(n.value))?null:Ku(ft.v);s.textContent=i?`Καθαρό ${lt(i.net)} · ΦΠΑ ${lt(i.vat)} · Σύνολο ${lt(i.gross)}`:""}}}return!0}function SS(n,t){ft&&ft.kind==="pay"&&n.dataset.bf==="party"&&t()}const Ut=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),kS=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),$e=n=>kS.format(Math.round((n||0)*100)/100),ze=n=>String(F(n)).replace(".",","),RS=n=>C(String(n).replace(",","."),0),PS=()=>({war:{on:!0,m:null},id:null,number:null,date:null,ts:0,customer:{name:"",phone:"",email:"",afm:"",address:""},subject:"",notes:"",status:"pending",vatMode:"on",benefits:[],benShow:!0,planMarks:[],planOn:!0,gid:null,optName:"",validDays:null,payShow:!1,payIds:null,prepay:{type:"",val:0},lines:[]}),Ia=n=>n===null||typeof n!="object"?JSON.stringify(n===void 0?null:n):Array.isArray(n)?"["+n.map(Ia).join(",")+"]":"{"+Object.keys(n).sort().map(t=>JSON.stringify(t)+":"+Ia(n[t])).join(",")+"}";let et=null;const Qy=()=>!!et;function CS(){et=null}let Xo=null;function DS(n){Xo=n}function $S(n){if(n==="new"){const s=PS();return Xo&&(Object.assign(s.customer,Xo),Xo=null),et={arg:n,q:s,base:null,pick:!1,pq:"",pcat:""}}const t=A.quotes.find(s=>s.id===n);if(!t)return null;const e=ce(t);return e.customer=Object.assign({name:"",phone:"",email:"",afm:"",address:""},e.customer),e.lines=e.lines||[],et={arg:n,q:e,base:Ia(t),pick:!1,pq:"",pcat:""}}function VS(n,t){return`<div class="ln-ed" data-i="${t}">
    <div class="ln-top"><input class="in" data-l="desc" value="${Ut(n.desc)}" placeholder="Περιγραφή"><button class="x" data-act="del" aria-label="Διαγραφή γραμμής">✕</button></div>
    <div class="ln-bot">
      <div class="step"><button data-act="dec">−</button><input class="in" data-l="qty" inputmode="decimal" value="${Ut(ze(C(n.qty)))}"><button data-act="inc">＋</button></div>
      <label>Τιμή €<input class="in" data-l="price" inputmode="decimal" value="${Ut(ze(C(n.price)))}"></label>
      <label>Έκπτ. %<input class="in" data-l="disc" inputmode="decimal" value="${Ut(ze(C(n.disc)))}"></label>
      <div class="ln-sum" data-sum>${$e(qu(n))}</div>
    </div></div>`}function Jy(){const n=Ny(et.q);return`<div class="tot"><span>Καθαρό</span><span>${$e(n.sub)}</span></div>
  ${n.off?"":`<div class="tot"><span>ΦΠΑ ${ze(n.vp)}%</span><span>${$e(n.vat)}</span></div>`}
  <div class="tot big"><span>Σύνολο${n.off?" (χωρίς ΦΠΑ)":""}</span><span>${$e(n.total)}</span></div>`}function NS(){const n=[...new Set(A.products.map(s=>s.cat).filter(Boolean))].sort((s,i)=>s.localeCompare(i,"el")),t=Rt(et.pq),e=A.products.filter(s=>(!et.pcat||s.cat===et.pcat)&&(!t||Rt((s.model||"")+" "+(s.desc||"")+" "+(s.cat||"")).includes(t))).sort((s,i)=>((s.cat||"")+(s.model||"")).localeCompare((i.cat||"")+(i.model||""),"el")).slice(0,80);return`<div class="sheet"><div class="sheet-in">
    <div class="sheet-h"><b>Κατάλογος</b><button class="btn b1 sm" data-act="pick-close">Τέλος</button></div>
    <input class="search" id="pq" placeholder="🔍 Αναζήτηση προϊόντος" value="${Ut(et.pq)}">
    <div class="chips"><button data-pcat="" class="${et.pcat?"":"on"}">Όλα</button>${n.map(s=>`<button data-pcat="${Ut(s)}" class="${et.pcat===s?"on":""}">${Ut(s)}</button>`).join("")}</div>
    <div class="sheet-list">${e.map(s=>{const i=et.q.lines.find(o=>o.pid===s.id),r=Oy(s.id,et.q.id);return`<button class="prow${i?" has":""}" data-pid="${Ut(s.id)}"><div class="t"><b>${Ut(s.model)}</b><span>${Ut([s.cat,s.desc].filter(Boolean).join(" · "))}${r>=1?` · 📦 ${ze(r)} στο ράφι`:""}</span></div>
      <div class="r"><div class="amt">${$e(xy(s))}</div>${i?`<span class="pill p-ok">×${ze(C(i.qty))}</span>`:'<span class="muted">＋ προσθήκη</span>'}</div></button>`}).join("")||`<div class="empty">${A.products.length?"Δεν βρέθηκε προϊόν":"Ο κατάλογος είναι άδειος"}</div>`}</div>
  </div></div>`}function xS(n){if((!et||et.arg!==n)&&(et=null,!$S(n)))return null;const t=et.q,e=t.customer,s=Je().map(i=>i.name).filter(i=>i&&i!=="(χωρίς όνομα)");return`<header class="top"><a class="ib" data-act="cancel">←</a><h1>${t.id?"Προσφορά #"+Ut(t.number||"—"):"Νέα προσφορά"}<span class="sm">${t.id?"Επεξεργασία":"Δεν έχει αποθηκευτεί ακόμα"}</span></h1></header>
  <main class="body ed">
    <div class="card pad">
      <label class="f">Πελάτης<input class="in" data-c="name" list="cl" value="${Ut(e.name)}" placeholder="Όνομα πελάτη" autocomplete="off"></label>
      <datalist id="cl">${s.map(i=>`<option value="${Ut(i)}">`).join("")}</datalist>
      <details><summary>Τηλέφωνο, email, ΑΦΜ, διεύθυνση</summary>
        <label class="f">Τηλέφωνο<input class="in" data-c="phone" inputmode="tel" value="${Ut(e.phone)}"></label>
        <label class="f">Email<input class="in" data-c="email" inputmode="email" value="${Ut(e.email)}"></label>
        <label class="f">ΑΦΜ<input class="in" data-c="afm" inputmode="numeric" value="${Ut(e.afm)}"></label>
        <label class="f">Διεύθυνση<input class="in" data-c="address" value="${Ut(e.address)}"></label>
      </details>
      <label class="f">Θέμα<input class="in" data-q="subject" value="${Ut(t.subject)}" placeholder="π.χ. Εγκατάσταση CCTV"></label>
    </div>
    <div class="h">Είδη (${t.lines.length})</div>
    <div class="card pad" id="lines">${t.lines.map(VS).join("")||'<div class="empty">Πρόσθεσε είδη από τον κατάλογο ή γράψε δική σου γραμμή.</div>'}</div>
    <div class="actions"><button class="btn b1" data-act="pick">📦 Κατάλογος</button><button class="btn b2" data-act="free">＋ Γραμμή</button><button class="btn b2" data-act="work">🛠️ Εργασία</button></div>
    <div class="card pad">
      <div class="seg"><button data-vat="on" class="${t.vatMode==="off"?"":"on"}">Με ΦΠΑ</button><button data-vat="off" class="${t.vatMode==="off"?"on":""}">Χωρίς ΦΠΑ</button></div>
      <div id="tots">${Jy()}</div>
    </div>
    <div class="card pad"><label class="f">Σημειώσεις<textarea class="in" data-q="notes" rows="3">${Ut(t.notes)}</textarea></label></div>
    ${et.msg?`<div class="err box">${Ut(et.msg)}</div>`:""}
  </main>
  <div class="bar"><button class="btn b2" data-act="cancel">Άκυρο</button><button class="btn b1" data-act="save">💾 ${et.force?"Αποθήκευση (αντικατάσταση)":"Αποθήκευση"}</button></div>
  ${et.pick?NS():""}`}function OS(n,t,e){const s=()=>{const i=n.querySelector("#tots");i&&(i.innerHTML=Jy())};n.oninput=i=>{const r=i.target,o=et&&et.q;if(o){if(r.dataset.c){if(o.customer[r.dataset.c]=r.value,r.dataset.c==="name"){const a=Je().find(l=>l.k===Rt(r.value));if(a){let l=!1;if(["phone","email","afm","address"].forEach(u=>{!o.customer[u]&&a.info[u]&&(o.customer[u]=a.info[u],l=!0)}),l){t();const u=n.querySelector('[data-c="name"]');u.focus(),u.setSelectionRange(u.value.length,u.value.length)}}}}else if(r.dataset.q)o[r.dataset.q]=r.value;else if(r.dataset.l){const a=r.closest(".ln-ed"),l=o.lines[+a.dataset.i];if(!l)return;l[r.dataset.l]=r.dataset.l==="desc"?r.value:RS(r.value),a.querySelector("[data-sum]").textContent=$e(qu(l)),s()}else if(r.id==="pq"){et.pq=r.value,t();const a=n.querySelector("#pq");a.focus(),a.setSelectionRange(a.value.length,a.value.length)}}},n.onclick=i=>{const r=et&&et.q;if(!r)return;const o=i.target.closest("[data-act],[data-vat],[data-pcat],[data-pid]");if(!o)return;const a=o.closest(".ln-ed"),l=a&&r.lines[+a.dataset.i],u=o.dataset.act;if(o.dataset.vat)r.vatMode=o.dataset.vat;else if(o.dataset.pcat!==void 0)et.pcat=o.dataset.pcat;else if(o.dataset.pid)MS(o.dataset.pid);else if(u==="inc")l.qty=F(C(l.qty)+1);else if(u==="dec")l.qty=Math.max(0,F(C(l.qty)-1));else if(u==="del")r.lines.splice(+a.dataset.i,1);else if(u==="free")r.lines.push({desc:"",qty:1,price:0,disc:0,showImg:!0});else if(u==="work")r.lines.push({desc:"Εργασία / εγκατάσταση",qty:1,price:0,disc:0,showImg:!0});else if(u==="pick")et.pick=!0;else if(u==="pick-close")et.pick=!1;else if(u==="cancel"){const h=r.id;return et=null,e(h)}else if(u==="save"){const h=US();if(h)return et=null,e(h)}if(et.msg&&u!=="save"&&(et.msg="",et.force=!1),t(),u==="free"){const h=n.querySelectorAll('[data-l="desc"]');h[h.length-1].focus()}}}function MS(n){const t=A.products.find(s=>s.id===n);if(!t)return;const e=et.q.lines.find(s=>s.pid===n);e?e.qty=F(C(e.qty)+1):et.q.lines.push({pid:n,desc:t.model+(t.desc?" - "+t.desc:""),qty:1,price:xy(t),disc:0,src:Oy(n,et.q.id)>=1?"stock":"supplier",showImg:!!(t.img&&t.imgPdf!==!1)})}function LS(n,t){const e=[],s=(a,l,u)=>{String(l||"")!==String(u||"")&&e.push(a+": «"+(l||"—")+"» → «"+(u||"—")+"»")};s("Πελάτης",n.customer&&n.customer.name,t.customer&&t.customer.name),s("Θέμα",n.subject,t.subject),s("ΦΠΑ",n.vatMode==="off"?"χωρίς":"με",t.vatMode==="off"?"χωρίς":"με"),(n.notes||"")!==(t.notes||"")&&e.push("Άλλαξαν οι σημειώσεις");const i={},r={};if((n.lines||[]).forEach(a=>i[a.pid||a.desc]=a),(t.lines||[]).forEach(a=>r[a.pid||a.desc]=a),Object.keys(r).forEach(a=>{if(!i[a])e.push("Προστέθηκε: "+r[a].desc+" ×"+ze(C(r[a].qty)));else{const l=i[a],u=r[a];C(l.qty)!==C(u.qty)&&e.push(u.desc+": ποσότητα "+ze(C(l.qty))+" → "+ze(C(u.qty))),C(l.price)!==C(u.price)&&e.push(u.desc+": τιμή "+$e(C(l.price))+" → "+$e(C(u.price))),C(l.disc)!==C(u.disc)&&e.push(u.desc+": έκπτωση "+ze(C(u.disc))+"%")}}),Object.keys(i).forEach(a=>{r[a]||e.push("Αφαιρέθηκε: "+i[a].desc)}),!e.length)return"";const o=F(C(t.total)-C(n.total));return e.join("; ")+(o?" (σύνολο "+$e(C(n.total))+" → "+$e(C(t.total))+")":"")}const FS=n=>(n=C(n,24),[24,13,6,0].includes(n)?n:24);function US(){const n=et.q,t=ct();if(n.lines=n.lines.filter(a=>String(a.desc||"").trim()).map(a=>({...a,desc:String(a.desc).trim(),qty:C(a.qty),price:C(a.price),disc:C(a.disc)})),!n.lines.length)return et.msg="Η προσφορά δεν έχει γραμμές.",null;if(!t)return et.msg="Δεν έχουν φορτώσει οι ρυθμίσεις (αρίθμηση, ΦΠΑ). Περίμενε λίγο ή έλεγξε τη σύνδεση.",null;const e=n.id?A.quotes.find(a=>a.id===n.id):null;if(n.id&&!e)return et.msg="Η προσφορά δεν υπάρχει πια (ίσως διαγράφηκε από άλλη συσκευή).",null;if(e&&Ia(e)!==et.base&&!et.force)return et.force=!0,et.msg="Η προσφορά άλλαξε από άλλη συσκευή αφού την άνοιξες. Αν αποθηκεύσεις, οι αλλαγές εκείνες θα αντικατασταθούν. Πάτα ξανά «Αποθήκευση» για να συνεχίσεις, ή «Άκυρο».",null;let s=0;if(!n.number){const a=Math.max(1,Math.floor(C(t.next,1)));n.number=new Date().getFullYear()+"-"+String(a).padStart(3,"0"),s=a+1}n.date||(n.date=new Date().toLocaleDateString("el-GR")),n.id||(n.id=Kt(),n.ts=Date.now()),n.customer.name=String(n.customer.name||"").trim(),n.total=Ny(n).total;const i=ce(n);qt("quotes",i),s&&xA(s);const r=(a,l)=>qt("qlog",{id:Kt(),qid:i.id,number:i.number||"",customer:i.customer.name||"",ts:Date.now(),type:a,text:l});if(!e)r("create","Νέα προσφορά, σύνολο "+$e(i.total)+", "+i.lines.length+" γραμμές.");else{const a=LS(e,i);a&&r("edit",a)}const o=A.ldocs.find(a=>a.kind==="sale"&&(a.qid===i.id||!a.qid&&i.number&&a.number===i.number&&Rt(a.party)===Rt(i.customer.name)));if(o){const a=i.vatMode==="off"?0:FS(t.vat),l=Bu(i),u=F(l*a/100),h=F(l+u),p=i.customer.name||o.party;o.qid===i.id&&o.net===l&&o.vat===u&&o.gross===h&&o.rate===a&&o.party===p&&o.number===(i.number||"")||Ts("ldocs",o.id,{qid:i.id,net:l,vat:u,gross:h,rate:a,party:p,number:i.number||""})}return i.id}const it=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),cp=n=>n<10?"0"+n:""+n,Wu=n=>n.getFullYear()+"-"+cp(n.getMonth()+1)+"-"+cp(n.getDate()),Cs=n=>new Date(n+"T12:00:00"),Ae=(n,t)=>{const e=Cs(n);return e.setDate(e.getDate()+t),Wu(e)},qr=(n,t)=>{const e=Cs(n),s=e.getDate();e.setDate(1),e.setMonth(e.getMonth()+t);const i=new Date(e.getFullYear(),e.getMonth()+1,0).getDate();return e.setDate(Math.min(s,i)),Wu(e)},$i="el-GR",Yy=n=>n.charAt(0).toUpperCase()+n.slice(1),nc=n=>Yy(Cs(n).toLocaleDateString($i,{weekday:"long",day:"numeric",month:"long",year:"numeric"})),Ea=n=>Cs(n).toLocaleDateString($i,{weekday:"short",day:"numeric",month:"numeric"}),qS=n=>Yy(Cs(n).toLocaleDateString($i,{month:"long",year:"numeric"})),Xy=n=>{const t=pt();return n===t?"Σήμερα":n===Ae(t,1)?"Αύριο":n===Ae(t,-1)?"Χθες":Ea(n)},ni=[["Μπλε TechMate","#1F4E79"],["Γαλάζιο","#0288D1"],["Τιρκουάζ","#00897B"],["Πράσινο","#2E7D32"],["Λαχανί","#7CB342"],["Κίτρινο","#F2A900"],["Πορτοκαλί","#EF6C00"],["Κόκκινο","#D32F2F"],["Ροζ","#C2185B"],["Μωβ","#7B1FA2"],["Λουλακί","#3949AB"],["Γκρι","#546E7A"]],ls=n=>(ni[n]||ni[0])[1],Zy=()=>{try{return JSON.parse(Gt().empClr||"{}")}catch{return{}}},sc=n=>{const t=Zy()[n];return typeof t=="number"?t:-1};function tv(n){if(typeof n.clr=="number"&&n.clr>=0)return ls(n.clr);for(const t of n.emps||[]){const e=sc(t);if(e>=0)return ls(e)}return n.kind==="due"?ls(6):ls(C(Gt().accent,0))}const Hu=-1,ev=[0,15,30,60,120,1440,2880,10080,Hu],Ta=n=>String(n||"").split(",").map(t=>parseInt(t,10)).filter(t=>!isNaN(t));function Qu(n){return Array.isArray(n.rems)?n.rems.map(Number).filter(t=>!isNaN(t)):{none:[],eve:[Hu],15:[15],30:[30],60:[60],120:[120]}[n.remOff||"at"]||[0]}function Ol(n){return n===0?"Στην ώρα":n===Hu?"Το προηγ. βράδυ":n<60?n+"΄ πριν":n===60?"1 ώρα πριν":n<1440?n/60+" ώρες πριν":n===1440?"1 μέρα πριν":n===10080?"1 εβδομάδα πριν":n/1440+" μέρες πριν"}const BS=n=>n.length?n.includes(0)?"at":{[-1]:"eve",15:"15",30:"30",60:"60",120:"120"}[n[0]]||"at":"none",Ml={"":"Καμία",w:"Κάθε εβδομάδα",m:"Κάθε μήνα",y:"Κάθε χρόνο"},jS=n=>!yt()||!!xe()&&(n.emps||[]).includes(xe()),Ll=()=>A.tasks.filter(n=>!n.del&&jS(n)),Ju=n=>!yt()||(n.emps||[]).includes(xe()),Yu=n=>{const t=A.emps.find(e=>e.id===n);return t?t.name:""},Br=()=>A.emps.filter(n=>n.name&&String(n.name).trim()).slice().sort((n,t)=>String(n.name).localeCompare(String(t.name),$i));function ic(){const n=A.st.main||{},t=n.msDefList||"",e=n.msToolList||"",s=n.msListNames||{},i=[...new Set((Array.isArray(n.msLists)?n.msLists:[]).filter(r=>r!==e).concat(t?[t]:[]))];return{def:t,lists:i.map(r=>({id:r,name:s[r]||"Λίστα"})).sort((r,o)=>(r.id===t?0:1)-(o.id===t?0:1))}}function Xu(n,t){const e=String(t.title||"").trim();if(!e)return{msg:"Γράψε τίτλο πρώτα."};const s=n&&A.tasks.find(m=>m.id===n),i=!s;if(n&&!s)return{msg:"Η εργασία δεν υπάρχει πια (ίσως σβήστηκε)."};if(!i&&!Gu(s))return{msg:"Μπορείς να αλλάξεις μόνο εργασίες που έγραψες εσύ."};if(yt()&&!xe())return{msg:"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει."};const r=t.date||"",o=r&&t.time||"",a=Date.now(),l=!!(s&&s.done),u=(t.rems||[]).map(Number).filter((m,I,E)=>E.indexOf(m)===I).sort((m,I)=>I-m),h=i?{id:Kt(),ts:a,msId:"",msList:t.msList||"",rem:""}:{id:s.id};if(i){const m=Mn();m&&(h.by=m)}!i&&(s.date!==r||(s.time||"")!==o||JSON.stringify(Qu(s).slice().sort((m,I)=>I-m))!==JSON.stringify(u))&&(h.rem="");let p=(t.emps||[]).slice();if(yt()&&(p=(i?t.emps||[]:s.emps||[]).slice(),p.includes(xe())||p.push(xe())),Object.assign(h,{title:e,date:r,time:o,emps:p,cust:String(t.cust||"").trim(),tel:String(t.tel||"").trim(),addr:String(t.addr||"").trim(),notes:String(t.notes||"").trim(),done:!!t.done,remOff:BS(u),rems:u,quoteId:t.quoteId||"",chk:(t.chk||[]).map(m=>({tx:String(m.tx||"").trim(),dn:!!m.dn})).filter(m=>m.tx),kind:t.kind||"",rep:t.rep||"",clr:typeof t.clr=="number"?t.clr:-1,upd:a,dirty:!0,del:!1}),h.done&&!l){h.doneAt=a;const m=Mn();m&&(h.doneBy=m.name)}else h.done||(h.doneAt=void 0,h.doneBy=void 0);if(i){if(delete h.doneAt,delete h.doneBy,h.done){h.doneAt=a;const m=Mn();m&&(h.doneBy=m.name)}qt("tasks",h)}else He("tasks",h.id,h);return h.done&&!l&&nv(A.tasks.find(m=>m.id===h.id)||h),{ok:!0,id:h.id}}function Wc(n,t){if(!n||!Ju(n))return;const e=Date.now(),s=Mn(),i=!!n.done;Ts("tasks",n.id,t?{done:!0,upd:e,dirty:!0,doneAt:e,doneBy:s&&s.name||""}:{done:!1,upd:e,dirty:!0,doneAt:void 0,doneBy:void 0}),t&&!i&&nv(n)}function zS(n,t){Ts("tasks",n.id,{chk:t.map(e=>({tx:e.tx,dn:!!e.dn})),upd:Date.now(),dirty:!0})}function nv(n){if(!n.date||!n.rep)return;const t=n.rep==="w"?Ae(n.date,7):n.rep==="m"?qr(n.date,1):n.rep==="y"?qr(n.date,12):"";t&&Xu(null,{...n,rems:Qu(n),date:t,done:!1,chk:(n.chk||[]).map(e=>({tx:e.tx,dn:!1})),msList:n.msList||""})}function GS(n){return Gu(n)?(n.msId?Ts("tasks",n.id,{del:!0,dirty:!0,upd:Date.now()}):Vy("tasks",n.id),{ok:!0}):{msg:"Μπορείς να σβήσεις μόνο εργασίες που έγραψες εσύ."}}const Q={view:"",sel:"",emp:"",q:"",srch:!1,list:"myday",showDone:!1,quick:"",preset:null,ms:null,emSel:""},wi=()=>Q.sel||(Q.sel=pt());let z=null;const sv=()=>!!z,KS=()=>{z=null};function si(n){Q.preset=n}const jr=(n,t)=>n.done-t.done||(n.time||"99:99").localeCompare(t.time||"99:99")||String(n.title||"").localeCompare(String(t.title||""),$i),WS=(n,t)=>(n.date?0:1)-(t.date?0:1)||(n.date||"").localeCompare(t.date||"")||(n.time||"99").localeCompare(t.time||"99")||(t.upd||0)-(n.upd||0),HS=(n,t)=>!t||[n.title,n.cust,n.addr,n.notes,n.tel].some(e=>String(e||"").toLowerCase().includes(t))||(n.chk||[]).some(e=>String(e.tx||"").toLowerCase().includes(t));function lp(n){const t=Q.q.trim().toLowerCase();return Ll().filter(e=>(n||Gt().showDone||!e.done)&&(!Q.emp||(e.emps||[]).includes(Q.emp))&&HS(e,t))}function Ln(n,t){const e=!n.done&&n.date&&n.date<pt(),s=e?"var(--bad)":tv(n),i=[t&&n.date?e?"Καθυστέρηση · "+Ea(n.date):Xy(n.date):"",n.cust,n.addr].filter(Boolean).join(" · "),r=(n.emps||[]).map(Yu).filter(Boolean),o=(n.chk||[]).length?`<em>☑ ${(n.chk||[]).filter(u=>u.dn).length}/${n.chk.length}</em>`:"",a=[n.kind==="due"?"<em>💶 Λήξη</em>":"",n.rep?`<em>🔁 ${it(Ml[n.rep]||"")}</em>`:"",o,!yt()&&r.length?`<em>👷 ${it(r.join(", "))}</em>`:""].join(""),l=Ju(n);return`<div class="tc${n.done?" dn":""}${Gt().compact?" cp":""}" style="--c:${s}">
    <button class="tick${n.done?" on":""}" ${l?`data-tk="${it(n.id)}"`:"disabled"} aria-label="Ολοκληρώθηκε">${n.done?"✓":""}</button>
    <a class="tcb" href="#/t/${encodeURIComponent(n.id)}"><div class="t"><b>${n.kind==="due"?"💶 ":""}${it(n.title||"(χωρίς τίτλο)")}</b>${i?`<span>${it(i)}</span>`:""}${a&&!Gt().compact?`<div class="tags">${a}</div>`:""}</div>
    <div class="tcr" style="color:${s}">${it(n.time||"")}</div></a></div>`}const Hc=(n,t,e,s="")=>t.length?`<div class="h ${s}">${n}</div><div class="card">${t.map(i=>Ln(i,e)).join("")}</div>`:"";function QS(n){const t=wi(),e=Cs(t.slice(0,8)+"01"),s=!!Gt().sun,i=(e.getDay()+(s?0:6))%7,r=Wu(new Date(e.getFullYear(),e.getMonth(),1-i)),o=s?["Κυρ","Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ"]:["Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ","Κυρ"],a=pt(),l=t.slice(0,7);let u="";for(let p=0;p<6;p++){const m=Ae(r,p*7);if(p===5&&m.slice(0,7)!==l)break;for(let I=0;I<7;I++){const E=Ae(m,I),$=(n[E]||[]).slice().sort(jr);u+=`<button class="mc${E===t?" sel":""}${E===a?" now":""}${E.slice(0,7)!==l?" out":""}" data-csel="${E}"><b>${+E.slice(8)}</b><i>${$.slice(0,4).map(R=>`<u style="background:${tv(R)};opacity:${R.done?.35:1}"></u>`).join("")}</i>${$.length>4?`<small>+${$.length-4}</small>`:""}</button>`}}const h=(n[t]||[]).slice().sort(jr);return`<div class="mnav"><button data-cmon="-1">‹</button><b>${qS(t)}</b><button data-cmon="1">›</button></div>
    <div class="card mgrid" id="mgrid"><div class="mh">${o.map(p=>`<span>${p}</span>`).join("")}</div><div class="mg">${u}</div></div>
    <div class="h">${it(nc(t))}</div>
    <div class="card">${h.length?h.map(p=>Ln(p,!1)).join(""):'<div class="empty">Ελεύθερη μέρα. Πάτα «＋» για να προσθέσεις.</div>'}</div>`}function JS(n){const t=wi(),e=!!Gt().sun,s=Ae(t,-((Cs(t).getDay()+(e?0:6))%7)),i=pt();let r=`<div class="mnav"><button data-cwk="-1">‹</button><b>${Ea(s)} – ${Ea(Ae(s,6))}</b><button data-cwk="1">›</button></div>`;for(let o=0;o<7;o++){const a=Ae(s,o),l=(n[a]||[]).slice().sort(jr);r+=`<div class="h wkh${a===i?" now":""}" data-csel="${a}">${a===i?"● ":""}${it(nc(a))}${l.length?` · ${l.length}`:""}</div>`,r+=l.length?`<div class="card">${l.map(u=>Ln(u,!1)).join("")}</div>`:'<div class="wke">—</div>'}return r}function YS(n){const t=pt(),e=(a,l)=>(a.date||"").localeCompare(l.date||"")||jr(a,l),s=n.filter(a=>!a.done&&a.date&&a.date<t).sort(e),i={};n.filter(a=>a.date&&a.date>=t).sort(e).forEach(a=>(i[a.date]=i[a.date]||[]).push(a));const r=n.filter(a=>!a.date&&!a.done).sort((a,l)=>(l.upd||l.ts||0)-(a.upd||a.ts||0));return Hc(`⚠️ Εκκρεμότητες από πριν (${s.length})`,s,!0,"badh")+Object.keys(i).map(a=>Hc((a===t||a===Ae(t,1)?Xy(a)+" · ":"")+nc(a),i[a],!1)).join("")+Hc("Χωρίς ημερομηνία",r,!1)||'<div class="card"><div class="empty">Δεν υπάρχει τίποτα προγραμματισμένο.</div></div>'}function XS(n){const{def:t,lists:e}=ic(),s=pt(),i=Q.list,r=n.filter(u=>i==="myday"?u.date&&u.date<=s&&(!u.done||u.date===s):i==="planned"?!!u.date:i==="all"?!0:u.msList===i||!u.msList&&i===t),o=r.filter(u=>!u.done).sort(WS),a=r.filter(u=>u.done).sort((u,h)=>(h.upd||0)-(u.upd||0));return`<div class="chips">${[["myday","☀️ Η μέρα μου"],["planned","📅 Προγραμματισμένες"],["all","📥 Όλες"]].concat(e.map(u=>[u.id,"≡ "+u.name])).map(([u,h])=>`<button data-clist="${it(u)}" class="${i===u?"on":""}">${it(h)}</button>`).join("")}</div>
    <div class="qadd"><input class="search" data-cqv placeholder="＋ Προσθήκη εργασίας" value="${it(Q.quick)}" enterkeyhint="done"><button class="btn b1 sm" data-cqa>Προσθήκη</button></div>
    ${o.length?`<div class="card">${o.map(u=>Ln(u,!0)).join("")}</div>`:a.length?"":`<div class="card"><div class="empty">${i==="myday"?"Τίποτα για σήμερα 🙂":"Η λίστα είναι άδεια."}</div></div>`}
    ${a.length?`<div class="h lnk2" data-cdone>${Q.showDone?"▾":"▸"} Ολοκληρωμένες (${a.length})</div>${Q.showDone?`<div class="card">${a.map(u=>Ln(u,!0)).join("")}</div>`:""}`:""}`}function up(n,t,e,s){s&&s!==Q.argV&&["lists","month","week","agenda"].includes(s)&&(Q.view=s,Q.argV=s),Q.view||(Q.view=Gt().view||"lists");const i=Q.view,r=lp(!1),o={};r.forEach(p=>{p.date&&(o[p.date]=o[p.date]||[]).push(p)});const a=[["lists","☑ Λίστες"],["month","🗓 Μήνας"],["week","Εβδ."],["agenda","Ατζέντα"]],l=yt()?[]:Br(),u=t("Ημερολόγιο",yt()?(Mn()||{}).name||"":"Πρόγραμμα · εργασίες · λήξεις","",`<button class="ib" data-csrch aria-label="Αναζήτηση">${Q.srch?"✕":"🔍"}</button><button class="ib" data-ctoday aria-label="Σήμερα">◎</button><a class="ib" href="#/cset" aria-label="Ρυθμίσεις">⚙️</a>`),h=`${Q.srch?`<input class="search" id="csq" data-csq placeholder="🔍 Αναζήτηση σε τίτλο, πελάτη, σημειώσεις…" value="${it(Q.q)}">`:""}
    <div class="seg">${a.map(([p,m])=>`<button data-cv="${p}" class="${i===p?"on":""}">${m}</button>`).join("")}</div>
    ${l.length?`<div class="chips"><button data-cemp="" class="${Q.emp?"":"on"}">Όλοι</button>${l.map(p=>{const m=sc(p.id);return`<button data-cemp="${it(p.id)}" class="${Q.emp===p.id?"on":""}">${m>=0?`<u class="dot" style="background:${ls(m)}"></u>`:""}${it(p.name)}</button>`}).join("")}</div>`:""}
    ${n?i==="month"?QS(o):i==="week"?JS(o):i==="agenda"?YS(r):XS(lp(!0)):'<div class="card"><div class="empty">Φόρτωση…</div></div>'}`;return e(u,h,"cal",'<button class="fab" data-cnew aria-label="Νέα εργασία">＋</button>')}function ZS(n){const t=n!=="new"&&A.tasks.find(i=>i.id===n);if(n!=="new"&&!t)return!1;const e=Q.preset||{};Q.preset=null;const s=Ta(e.kind==="due"?Gt().dueRems:Gt().defRems);return z={arg:n,t0:t||null,isNew:!t,canEdit:!t||Gu(t),canTick:!t||Ju(t),msg:"",ask:!1,pick:null,err:!1,v:t?{kind:t.kind||"",title:t.title||"",date:t.date||"",time:t.time||"",rems:Qu(t),rep:t.rep||"",cust:t.cust||"",tel:t.tel||"",addr:t.addr||"",quoteId:t.quoteId||"",emps:(t.emps||[]).slice(),clr:typeof t.clr=="number"?t.clr:-1,notes:t.notes||"",chk:(t.chk||[]).map(i=>({tx:i.tx||"",dn:!!i.dn})),done:!!t.done,msList:t.msList||""}:{kind:e.kind||"",title:e.title||"",date:e.date!==void 0?e.date:pt(),time:"",rems:e.rems||s,rep:"",cust:e.cust||"",tel:e.tel||"",addr:e.addr||"",quoteId:e.quoteId||"",emps:[],clr:-1,notes:"",chk:[],done:!1,msList:e.msList||""}},!0}const wr=(n,t,e)=>`<div class="chips wrap">${n.map(([s,i])=>`<button ${e}="${it(s)}" class="${t(s)?"on":""}">${i}</button>`).join("")}</div>`,tk=n=>{const t=A.quotes.find(e=>e.id===n);return t?`#${t.number||"—"} · ${t.customer&&t.customer.name||""}${t.subject?" · "+t.subject:""}`:"Συνδεδεμένη προσφορά"},dp=n=>[n.kind==="due"?"💶 "+n.title:n.title,n.date?nc(n.date)+(n.time?" "+n.time:""):"",n.cust?"Πελάτης: "+n.cust:"",n.tel?"Τηλ: "+n.tel:"",n.addr?"Διεύθυνση: "+n.addr:"",(n.emps||[]).length?"Τεχνικοί: "+n.emps.map(Yu).filter(Boolean).join(", "):"",n.notes?`
`+n.notes:"",(n.chk||[]).length?`
`+n.chk.map(t=>(t.dn?"✔ ":"▫ ")+t.tx).join(`
`):""].filter(Boolean).join(`
`);function ek(n,t,e,s){if((!z||z.arg!==n)&&!ZS(n))return s(e("Εργασία","",'<a class="ib" href="#/cal">←</a>'),`<div class="card"><div class="empty">${t?"Η εργασία δεν βρέθηκε (ίσως σβήστηκε).":"Φόρτωση…"}</div></div>`,null);const i=z.v,r=z.canEdit,o=r?"":"disabled",a=!yt(),l=(R,B,H="",K="")=>`<label class="f">${B}<span class="fw"><input class="in${R==="title"&&z.err?" ine":""}" data-tf="${R}" value="${it(i[R]||"")}" ${o} ${H}>${K}</span></label>`,{def:u,lists:h}=ic(),p=z.isNew?i.kind==="due"?"Νέα λήξη / πληρωμή":"Νέα εργασία":r?"Επεξεργασία":"Εργασία",m=i.tel.replace(/\s/g,""),I=i.chk.filter(R=>R.dn).length,E=`${r?"":`<div class="upd">🔒 Την έγραψε ${it(z.t0.by&&z.t0.by.name||"άλλος")}. Μπορείς να τη σημειώσεις ολοκληρωμένη και να τσεκάρεις το checklist.</div>`}
  <div class="card pad"><div class="ch">📅 Τι και πότε</div>
    ${r?`<div class="seg">${[["","🛠 Εργασία"],["due","💶 Λήξη / πληρωμή"]].map(([R,B])=>`<button data-tfk="${R}" class="${i.kind===R?"on":""}">${B}</button>`).join("")}</div>`:""}
    ${a&&z.isNew&&h.length>1?`<div class="f">Λίστα To Do</div>${wr(h.map(R=>[R.id,it(R.name)]),R=>R===i.msList||!i.msList&&R===u,"data-tlist")}`:!z.isNew&&i.msList&&h.find(R=>R.id===i.msList)?`<div class="f">≡ Λίστα: ${it(h.find(R=>R.id===i.msList).name)}</div>`:""}
    ${l("title",i.kind==="due"?"Τι λήγει / τι πληρώνεται":"Τίτλος",'placeholder="π.χ. Εγκατάσταση καμερών" autocomplete="off"')}
    <div class="two">${l("date","Ημερομηνία",'type="date"')}${l("time","Ώρα",`type="time" ${i.date?"":"disabled"}`)}</div>
    ${r?`<div class="chips wrap">${[["Σήμερα",pt()],["Αύριο",Ae(pt(),1)],["+1 εβδομάδα",Ae(pt(),7)],["+1 μήνας",qr(pt(),1)]].map(([R,B])=>`<button data-tdq="${B}" class="${i.date===B?"on":""}">${R}</button>`).join("")}${i.date?'<button data-tdq="">✕ Χωρίς ημερομηνία</button>':""}</div>`:""}
  </div>
  <div class="card pad"><div class="ch">🔔 Υπενθυμίσεις</div>
    ${r?wr(ev.map(R=>[R,Ol(R)]),R=>i.rems.includes(+R),"data-trem")+(i.date&&!i.time?'<div class="hint">Χωρίς ώρα, οι υπενθυμίσεις υπολογίζονται από τις 08:00.</div>':"")+(i.date?"":'<div class="hint">Οι υπενθυμίσεις χρειάζονται ημερομηνία.</div>'):`<div class="hint">${i.rems.map(Ol).join(", ")||"Καμία"}</div>`}
    <div class="f" style="margin-top:8px">🔁 Επανάληψη</div>
    ${r?wr(Object.entries(Ml),R=>R===i.rep,"data-trep")+(i.rep?'<div class="hint">Όταν την ολοκληρώσεις, δημιουργείται αυτόματα η επόμενη.</div>':""):`<div class="hint">${Ml[i.rep]||"Καμία"}</div>`}
  </div>
  <div class="card pad"><div class="ch">👤 Πελάτης</div>
    ${a&&r?`<div class="actions"><button class="btn b2" data-tpick="cust">📇 Από πελάτες</button><button class="btn b2" data-tpick="quote">📄 ${i.quoteId?"Άλλη προσφορά":"Προσφορά"}</button></div>`:""}
    ${i.quoteId?`<div class="qlink"><a href="#/q/${encodeURIComponent(i.quoteId)}">🔗 ${it(tk(i.quoteId))}</a>${a&&r?'<button class="x" data-tunq aria-label="Αποσύνδεση">✕</button>':""}</div>`:""}
    ${l("cust","Όνομα πελάτη",'autocomplete="off"')}
    ${l("tel","Τηλέφωνο",'inputmode="tel"',m?`<a class="fa" href="tel:${it(m)}">📞</a>`:"")}
    ${l("addr","Διεύθυνση","",i.addr?`<a class="fa" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i.addr)}">🗺️</a>`:"")}
  </div>
  ${a&&A.emps.length||r?`<div class="card pad"><div class="ch">👷 Ποιος και χρώμα</div>
    ${a&&Br().length?`<div class="chips wrap">${Br().map(R=>{const B=sc(R.id),H=i.emps.includes(R.id);return`<button data-temp="${it(R.id)}" class="${H?"on":""}" ${o}>${H?"✓ ":B>=0?`<u class="dot" style="background:${ls(B)}"></u>`:""}${it(R.name)}</button>`}).join("")}</div>`:i.emps.length?`<div class="hint">${it(i.emps.map(Yu).filter(Boolean).join(", "))}</div>`:""}
    ${r?`<div class="f" style="margin-top:6px">Χρώμα</div><div class="clrs"><button data-tclr="-1" class="${i.clr<0?"on":""}">Αυτόματο</button>${ni.map(([R,B],H)=>`<button data-tclr="${H}" class="sw${i.clr===H?" on":""}" style="background:${B}" aria-label="${R}"></button>`).join("")}</div>`:""}
  </div>`:""}
  <div class="card pad"><div class="ch">📝 Σημειώσεις</div>
    <textarea class="in" data-tf="notes" rows="4" placeholder="Ό,τι χρειάζεται να θυμάσαι…" ${o}>${it(i.notes)}</textarea>
    <div class="actions"><button class="btn b2" data-tncopy>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tnpaste>📋 Επικόλληση</button>':""}</div>
  </div>
  <div class="card pad"><div class="ch">☑ Checklist${i.chk.length?` <span class="muted">${I}/${i.chk.length}</span>`:""}</div>
    ${i.chk.length?`<div class="prog"><i style="width:${Math.round(I/i.chk.length*100)}%"></i></div>`:""}
    ${i.chk.map((R,B)=>`<div class="ci"><button class="tick${R.dn?" on":""}" data-tchktg="${B}" ${z.canTick?"":"disabled"}>${R.dn?"✓":""}</button>${r?`<input class="in" data-tchk="${B}" value="${it(R.tx)}"><button class="x" data-tchkdel="${B}">✕</button>`:`<span class="${R.dn?"strike":""}">${it(R.tx)}</span>`}</div>`).join("")}
    <div class="actions">${r?'<button class="btn b2" data-tchkadd>＋ Στοιχείο</button>':""}<button class="btn b2" data-tccopy ${i.chk.length?"":"disabled"}>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tcpaste>📋 Επικόλληση</button>':""}</div>
    ${r?'<div class="hint">Επικόλληση: κάθε γραμμή του προχείρου γίνεται ξεχωριστό στοιχείο.</div>':""}
  </div>
  <div class="card pad"><div class="ch">✅ Κατάσταση</div>
    <label class="chk2"><input type="checkbox" data-tf="done" ${i.done?"checked":""} ${z.canTick?"":"disabled"}> ${i.done?"Ολοκληρώθηκε":"Ανοιχτή"}</label>
    ${z.t0&&z.t0.by&&z.t0.by.name?`<div class="hint">Την έγραψε: ${it(z.t0.by.uid===(Mn()||{}).uid?"εσύ":z.t0.by.name)}${z.t0.done&&z.t0.doneBy?" · ολοκλήρωσε: "+it(z.t0.doneBy):""}</div>`:""}
  </div>
  ${z.msg?`<div class="err box">${it(z.msg)}</div>`:""}
  ${!z.isNew&&r?`<button class="btn wide del" data-tdel>${z.ask?"Σίγουρα; Πάτα ξανά για διαγραφή":"🗑️ Διαγραφή"}</button>`:""}
  ${z.pick?nk():""}`;return`${e(p,"",'<a class="ib" data-tcancel>←</a>','<button class="ib" data-tcopy aria-label="Αντιγραφή">⧉</button><button class="ib" data-tshare aria-label="Αποστολή">📤</button>')}<main class="body ed">${E}</main><div class="bar"><button class="btn b2" data-tcancel>Άκυρο</button><button class="btn b1" data-tsave>💾 Αποθήκευση</button></div>`}function iv(){return z.pick.kind==="cust"?Je().filter(n=>n.name&&n.name!=="(χωρίς όνομα)").sort((n,t)=>(t.last||0)-(n.last||0)).map(n=>({t:n.name,s:[n.info.phone,n.info.address].filter(Boolean).join(" · "),v:{cust:n.name,tel:n.info.phone||"",addr:n.info.address||""}})):A.quotes.filter(n=>!We(n)).sort((n,t)=>(t.ts||0)-(n.ts||0)).map(n=>{const t=n.customer||{};return{t:`#${n.number||"—"} · ${t.name||""}`,s:[n.subject,t.address].filter(Boolean).join(" · "),v:{quoteId:n.id,cust:t.name||"",tel:t.phone||"",addr:t.address||"",q:!0}}})}function nk(){const n=z.pick.q.trim().toLowerCase(),t=iv().map((e,s)=>({...e,i:s})).filter(e=>!n||(e.t+" "+e.s).toLowerCase().includes(n)).slice(0,150);return`<div class="sheet" data-pkx><div class="sheet-in"><div class="sheet-h"><b>${z.pick.kind==="cust"?"Πελάτες":"Προσφορές"}</b><button class="ib dk" data-pkx>✕</button></div>
    <input class="search" id="pq" data-pq placeholder="🔍 Αναζήτηση…" value="${it(z.pick.q)}">
    <div class="sheet-list">${t.map(e=>`<button class="prow" data-pk="${e.i}"><div class="t"><b>${it(e.t)}</b><span>${it(e.s)}</span></div></button>`).join("")||'<div class="empty">Τίποτα</div>'}</div></div></div>`}const Ze=(n,t)=>`<label class="tg"><span>${t}</span><input type="checkbox" data-stg="${n}" ${Gt()[n]?"checked":""}></label>`,bn=(n,t,e)=>`<div class="f">${t}</div>${wr(e,s=>String(Gt()[n])===String(s),`data-s="${n}" data-v`)}`,hp=(n,t)=>`<div class="f">${t}</div>${wr(ev.map(e=>[e,Ol(e)]),e=>Ta(Gt()[n]).includes(+e),`data-sr="${n}" data-v`)}`;async function Zu(n){await Lr(),Q.ms=await Et.msStatus(),n()}function sk(n,t){const e=Gt(),s=Q.ms||{},{lists:i}=ic(),r=!yt(),o=l=>l?new Date(l).toLocaleString($i,{dateStyle:"short",timeStyle:"short"}):"",a=`${Ps?"":'<div class="upd">🧪 Preview στον browser: ειδοποιήσεις, widgets, backup και To Do λειτουργούν μόνο στο κινητό.</div>'}
  <div class="h">🎨 Εμφάνιση ημερολογίου</div><div class="card pad">
    ${bn("view","Οθόνη έναρξης",[["lists","Λίστες"],["month","Μήνας"],["week","Εβδομάδα"],["agenda","Ατζέντα"]])}
    <div class="f">Χρώμα εργασιών (προεπιλογή)</div><div class="clrs">${ni.map(([l,u],h)=>`<button data-s="accent" data-v="${h}" class="sw${C(e.accent)===h?" on":""}" style="background:${u}" aria-label="${l}"></button>`).join("")}</div>
    ${Ze("sun","Η εβδομάδα ξεκινά Κυριακή")}${Ze("showDone","Εμφάνιση ολοκληρωμένων")}${Ze("compact","Συμπαγής λίστα (περισσότερα στην οθόνη)")}
  </div>
  ${r&&Br().length?`<div class="h">👷 Χρώμα ανά τεχνικό</div><div class="card pad"><div class="hint">Οι εργασίες χωρίς δικό τους χρώμα παίρνουν το χρώμα του τεχνικού.</div>
    ${Br().map(l=>{const u=sc(l.id);return`<div class="erow" data-sec="${it(l.id)}"><u class="dot lg" style="background:${u>=0?ls(u):"var(--line)"}"></u><b>${it(l.name)}</b><span class="muted">${u>=0?ni[u][0]:"Αυτόματο"}</span></div>
      ${Q.emSel===l.id?`<div class="clrs"><button data-secv="${it(l.id)}|-1" class="${u<0?"on":""}">Αυτόματο</button>${ni.map(([h,p],m)=>`<button data-secv="${it(l.id)}|${m}" class="sw${u===m?" on":""}" style="background:${p}" aria-label="${h}"></button>`).join("")}</div>`:""}`}).join("")}</div>`:""}
  <div class="h">🔔 Υπενθυμίσεις</div><div class="card pad">
    ${hp("defRems","Προεπιλογή για νέες εργασίες")}${hp("dueRems","Προεπιλογή για λήξεις / πληρωμές")}
    ${Ze("rep","Να ξαναχτυπά μέχρι να πατήσω «ΟΚ»")}
    ${e.rep?bn("repMin","Κάθε",[2,5,10,15,30].map(l=>[l,l+"΄"]))+bn("repMax","Μέχρι",[3,6,12,24].map(l=>[l,l+" φορές"])):""}
    ${bn("snooze","Αναβολή",[5,10,15,30,60].map(l=>[l,l+"΄"]))}
    ${Ze("alarmSound","Δυνατός ήχος ξυπνητηριού")}${Ze("clockMode","Μέγιστη ακρίβεια (σαν ξυπνητήρι)")}
    <div class="actions"><button class="btn b2" data-sact="test">🔔 Δοκιμή</button><button class="btn b2" data-sact="notif">🔊 Ήχοι</button></div>
    <div class="hint">Αν το κινητό (Xiaomi, Huawei, Samsung) «κοιμίζει» τις εφαρμογές, βάλε το TechMate «Χωρίς περιορισμό» μπαταρίας:</div>
    <div class="actions"><button class="btn b2" data-sact="battery">🔋 Ρυθμίσεις μπαταρίας</button></div>
  </div>
  <div class="h">🔄 Συγχρονισμός και μπαταρία</div><div class="card pad">
    <div class="hint">Όσο η εφαρμογή είναι ανοιχτή, όλα ενημερώνονται αμέσως. Κλειστή, ελέγχει για νέες εργασίες μόνο όσο συχνά ορίσεις. Οι υπενθυμίσεις δεν εξαρτώνται από αυτό.</div>
    ${bn("syncMin","Έλεγχος για νέες εργασίες",[[0,"Ποτέ"],[15,"15΄"],[30,"30΄"],[60,"1 ώρα"],[180,"3 ώρες"],[360,"6 ώρες"]])}
    ${Ze("notifyNew","Ειδοποίηση για νέα / αλλαγμένη εργασία")}
  </div>
  <div class="h">🧩 Widget</div><div class="card pad">
    <label class="f">Διαφάνεια φόντου: <b id="wav">${e.wAlpha}%</b><input type="range" min="20" max="100" step="10" value="${e.wAlpha}" data-sw class="rng"></label>
    ${bn("wMode","Τι δείχνει το widget-λίστα",[["todo","Εργασίες (όπως το To Do)"],["cal","Μόνο ραντεβού με ημερομηνία"]])}
    ${e.wMode==="todo"&&i.length>1?bn("wList","Λίστα To Do στο widget",[["","Όλες"]].concat(i.map(l=>[l.id,it(l.name)]))):""}
    ${bn("wDays",e.wMode==="todo"?"Μαζί με ραντεβού για":"Η λίστα του widget δείχνει",[[1,"Σήμερα"],[2,"Σήμερα & αύριο"],[3,"3 μέρες"],[7,"Εβδομάδα"]])}
    <div class="hint">Για να το προσθέσεις: πάτα παρατεταμένα την αρχική οθόνη → Widgets → TechMate.</div>
  </div>
  ${r?`<div class="h">💾 Backup στη συσκευή / Google Drive</div><div class="card pad">
    <div class="hint">Σώζει ΟΛΟ το TechMate (προσφορές, πελάτες, λογιστικά, εργασίες…) σε αρχείο που διαλέγεις. Για Google Drive, πάτα ☰ στον επιλογέα και διάλεξε «Drive». Μόνο διαβάζει τη βάση, δεν αλλάζει τίποτα.</div>
    <div class="actions"><button class="btn b2" data-sact="bpick">📁 ${e.bUri?"Άλλο αρχείο":"Επιλογή αρχείου"}</button>${e.bUri?'<button class="btn b2" data-sact="bnow">☁️ Backup τώρα</button>':""}</div>
    ${e.bUri?Ze("bAuto","Αυτόματο backup μία φορά τη μέρα (όταν ανοίγεις την εφαρμογή)")+`<div class="hint">${e.bLast?"Τελευταίο: "+o(e.bLast):"Δεν έχει γίνει ακόμα"}</div>`:""}
    <label class="btn b2 wide filebtn">♻️ Επαναφορά εργασιών που λείπουν, από backup…<input type="file" accept="application/json,.json" data-restore hidden></label>
    <div class="hint">Η επαναφορά προσθέτει ΜΟΝΟ εργασίες που δεν υπάρχουν πια. Όσες υπάρχουν δεν αλλάζουν.</div>
  </div>
  <div class="h">✅ Microsoft To Do</div><div class="card pad">
    ${s.connected?`<div class="hint">👤 ${it(s.account||"Συνδεδεμένο")}</div><div class="hint">${s.status==="sync"?"⏳ Συγχρονισμός…":s.status==="login"?"⚠️ Χρειάζεται ξανά σύνδεση":s.status&&s.status!=="ok"?"⚠️ "+it(s.status):s.last?"✓ Τελευταίος συγχρονισμός: "+o(s.last):"✓ Συνδεδεμένο"}</div>
        <div class="actions">${s.status==="login"?'<button class="btn b1" data-sact="mslogin">Σύνδεση</button>':'<button class="btn b2" data-sact="mssync">🔄 Συγχρονισμός τώρα</button>'}<button class="btn b2" data-sact="msout">Αποσύνδεση</button></div>
        <div class="hint">Συγχρονίζονται οι λίστες που έχεις διαλέξει στο TechMate. Οι νέες εργασίες πάνε στην κύρια λίστα.</div>`:'<div class="hint">Σύνδεσε τον λογαριασμό Microsoft: οι εργασίες πηγαίνουν και έρχονται από το To Do απευθείας από το κινητό, με την ίδια λογική με το PWA (χωρίς διπλές).</div><button class="btn b1 wide" data-sact="mslogin">Σύνδεση με Microsoft</button>'}
  </div>`:'<div class="card pad"><div class="hint">Τον συγχρονισμό με το To Do και τα backup τα κάνει ο διαχειριστής.</div></div>'}
  <div class="card pad">${Ze("autoUpd","Αυτόματος έλεγχος για νέα έκδοση εφαρμογής")}</div>`;return t(n("Ρυθμίσεις ημερολογίου","Ειδοποιήσεις · widget · backup · To Do",'<a class="ib" href="#/cal">←</a>'),a,null)}function Fl(){const n=e=>Object.fromEntries((e||[]).map(s=>{const i={...s};return delete i.id,[s.id,i]})),t={};return["quotes","custs","tasks","ldocs","lpays","emps","products","smoves","wdays","wpays","needs"].forEach(e=>t[e]=n(A[e])),JSON.stringify({app:"TechMate",ver:2,at:new Date().toISOString(),tasks:t.tasks,data:t,settings:A.st},null,1)}async function ik(n){const t=Gt();if(!Ps||!n||yt()||!t.bUri||!t.bAuto||!A.tasks.length||!A.quotes.length||Date.now()-C(t.bLast)<20*36e5)return;const e=await Et.backupWrite(Fl());e&&e.ok&&await Lr()}async function rk(n,t,e){try{const s=JSON.parse(await n.text()),i=s.tasks||s.data&&s.data.tasks||{},r=new Set(A.tasks.map(a=>a.id));let o=0;Object.keys(i).forEach(a=>{r.has(a)||!i[a]||typeof i[a]!="object"||(qt("tasks",{...i[a],id:a}),o++)}),t(o?`Επαναφέρθηκαν ${o} εργασίες που έλειπαν.`:"Δεν έλειπε καμία εργασία. Δεν άλλαξε τίποτα.")}catch{t("Το αρχείο δεν είναι σωστό backup.")}e()}function rv(n){const t=Q.quick.trim();if(!t)return;const e=Q.list,s=Xu(null,{title:t,date:e==="myday"?pt():"",rems:[],msList:["myday","planned","all"].includes(e)?"":e});if(s.msg)return n(s.msg);Q.quick="",n("Προστέθηκε: "+t)}function ok(){if(Q.view==="lists"){const t=Q.list;si({date:t==="myday"||t==="planned"?pt():"",msList:["myday","planned","all"].includes(t)?"":t})}else si({date:wi()});location.hash="#/t/new"}async function ak(n,t,e){const s={test:async()=>{const i=await Et.testNotif();e(i&&i.error?i.error:Ps?"Στάλθηκε δοκιμαστική ειδοποίηση":"Μόνο στο κινητό")},notif:()=>Et.openNotifSettings(),battery:()=>Et.openBattery(),mslogin:()=>Et.msLogin(),mssync:async()=>{Q.ms={...Q.ms||{},status:"sync"},t();const i=await Et.msSync();e(i&&i.ok?"Συγχρονίστηκε με το To Do":"Ο συγχρονισμός απέτυχε")},msout:async()=>{await Et.msDisconnect(),e("Αποσυνδέθηκε το Microsoft To Do")},bpick:async()=>{const i=await Et.backupPick();if(i&&i.error)return e(i.error);if(i&&i.ok){await Lr();const r=await Et.backupWrite(Fl());e(r&&r.ok?"Έγινε το πρώτο backup":"Backup: "+(r&&r.error||"σφάλμα"))}},bnow:async()=>{const i=await Et.backupWrite(Fl());e(i&&i.ok?"Έγινε backup":"Backup: "+(i&&i.error||"σφάλμα"))}}[n];s&&await s(),await Lr(),Q.ms=await Et.msStatus(),t()}function ck(n,t,e){const s=n.closest("[data-tk],[data-cv],[data-csel],[data-cmon],[data-cwk],[data-cemp],[data-clist],[data-csrch],[data-ctoday],[data-cdone],[data-cnew],[data-cqa],[data-tfk],[data-trem],[data-trep],[data-temp],[data-tclr],[data-tdq],[data-tlist],[data-tunq],[data-tpick],[data-pk],[data-pkx],[data-tchkadd],[data-tchkdel],[data-tchktg],[data-tncopy],[data-tnpaste],[data-tccopy],[data-tcpaste],[data-tcopy],[data-tshare],[data-tsave],[data-tcancel],[data-tdel],[data-s],[data-sr],[data-sec],[data-secv],[data-sact]");if(!s)return!1;const i=s.dataset;if(i.tk){const o=A.tasks.find(l=>l.id===i.tk);if(!o)return!0;const a=!o.done;return Wc(o,a),e((a?"✓ Ολοκληρώθηκε: ":"Άνοιξε ξανά: ")+(o.title||""),{label:"Αναίρεση",fn:()=>{const l=A.tasks.find(u=>u.id===o.id);l&&Wc(l,!a)}}),!0}if(i.cv)return Q.view=i.cv,t(),!0;if(i.csel)return Q.sel=i.csel,Q.view==="week"&&(Q.view="month"),t(),!0;if(i.cmon)return Q.sel=qr(wi().slice(0,8)+"01",+i.cmon),t(),!0;if(i.cwk)return Q.sel=Ae(wi(),7*i.cwk),t(),!0;if("cemp"in i)return Q.emp=Q.emp===i.cemp?"":i.cemp,t(),!0;if(i.clist)return Q.list=i.clist,t(),!0;if("csrch"in i){Q.srch=!Q.srch,Q.srch||(Q.q=""),t();const o=document.getElementById("csq");return o&&o.focus(),!0}if("ctoday"in i)return Q.sel=pt(),t(),!0;if("cdone"in i)return Q.showDone=!Q.showDone,t(),!0;if("cnew"in i)return ok(),!0;if("cqa"in i)return rv(e),t(),!0;if(i.s!==void 0&&i.v!==void 0){const o=Gt()[i.s],a=typeof o=="number"?+i.v:typeof o=="boolean"?i.v==="true":i.v;return _r(i.s,a).then(t),!0}if(i.sr){const o=Ta(Gt()[i.sr]),a=+i.v,l=o.includes(a)?o.filter(u=>u!==a):o.concat(a);return _r(i.sr,l.join(",")).then(t),!0}if(i.secv){const[o,a]=i.secv.split("|"),l=Zy();return+a<0?delete l[o]:l[o]=+a,Q.emSel="",_r("empClr",JSON.stringify(l)).then(t),!0}if(i.sec)return Q.emSel=Q.emSel===i.sec?"":i.sec,t(),!0;if(i.sact)return ak(i.sact,t,e),!0;if(!z)return!1;const r=z.v;if("pkx"in i)return s.classList.contains("sheet")&&n!==s?!0:(z.pick=null,t(),!0);if(i.pk){const o=iv()[+i.pk];if(o){const a=o.v;a.q?(r.quoteId=a.quoteId,r.cust||(r.cust=a.cust),r.tel||(r.tel=a.tel),r.addr||(r.addr=a.addr),r.title||(r.title="Εγκατάσταση – "+a.cust)):(r.cust=a.cust,a.tel&&(r.tel=a.tel),a.addr&&(r.addr=a.addr))}return z.pick=null,t(),!0}if(i.tfk!==void 0)r.kind!==i.tfk&&z.isNew&&(r.rems=Ta(i.tfk==="due"?Gt().dueRems:Gt().defRems)),r.kind=i.tfk;else if(i.trem!==void 0){const o=+i.trem;r.rems=r.rems.includes(o)?r.rems.filter(a=>a!==o):r.rems.concat(o)}else if(i.trep!==void 0)r.rep=i.trep;else if(i.temp){const o=r.emps.indexOf(i.temp);o>=0?r.emps.splice(o,1):r.emps.push(i.temp)}else if(i.tclr!==void 0)r.clr=+i.tclr;else if(i.tdq!==void 0)r.date=i.tdq,r.date||(r.time="");else if(i.tlist)r.msList=i.tlist;else if("tunq"in i)r.quoteId="";else if(i.tpick)z.pick={kind:i.tpick,q:""};else if("tchkadd"in i)r.chk.push({tx:"",dn:!1});else if(i.tchkdel)r.chk.splice(+i.tchkdel,1);else if(i.tchktg){const o=r.chk[+i.tchktg];o&&z.canTick&&(o.dn=!o.dn)}else{if("tncopy"in i)return Et.copy(r.notes),e("Αντιγράφηκαν οι σημειώσεις"),!0;if("tnpaste"in i)return Et.paste().then(o=>{if(!o)return e("Το πρόχειρο είναι άδειο");r.notes=r.notes.trim()?r.notes.trimEnd()+`
`+o:o,e("Επικολλήθηκε"),t()}),!0;if("tccopy"in i)return Et.copy(r.chk.map(o=>(o.dn?"✔ ":"▫ ")+o.tx).join(`
`)),e("Αντιγράφηκε το checklist"),!0;if("tcpaste"in i)return Et.paste().then(o=>{const a=String(o||"").split(/\r?\n/).map(l=>l.trim()).filter(Boolean).map(l=>({tx:l.replace(/^([-*•▫☐☑✔✓]|\[[ xX]?\]|\d+[.)])\s*/,""),dn:/^(☑|✔|✓|\[[xX]\])/.test(l)})).filter(l=>l.tx);if(!a.length)return e("Το πρόχειρο είναι άδειο");r.chk.push(...a),e(`Προστέθηκαν ${a.length} στοιχεία`),t()}),!0;if("tcopy"in i)return Et.copy(dp(r)),e("Αντιγράφηκε η εργασία"),!0;if("tshare"in i)return Et.share(dp(r)),!0;if("tcancel"in i)return z=null,history.length>1?history.back():location.replace("#/cal"),!0;if("tdel"in i)if(!z.ask)z.ask=!0;else{const o=GS(z.t0);if(o.msg)z.msg=o.msg,z.ask=!1;else{const a=z.t0.title;return z=null,e("Διαγράφηκε: "+a),location.replace("#/cal"),!0}}else if("tsave"in i){if(z.canEdit){const l=Xu(z.isNew?null:z.arg,r);if(l.msg)return z.msg=l.msg,z.err=!r.title.trim(),t(),!0}else{const l=A.tasks.find(h=>h.id===z.arg)||z.t0,u=r.chk.filter(h=>h.tx.trim());JSON.stringify(u)!==JSON.stringify((l.chk||[]).map(h=>({tx:h.tx,dn:!!h.dn})))&&zS(l,u),!!r.done!=!!l.done&&Wc(l,r.done)}const o=r.title.trim(),a=z.isNew;return z=null,e(a?"Προστέθηκε: "+o:"Αποθηκεύτηκε"),history.length>1?history.back():location.replace("#/cal"),!0}}return t(),!0}function lk(n,t){const e=n.dataset;if("csq"in e){Q.q=n.value,t();const s=document.getElementById("csq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if("cqv"in e)return Q.quick=n.value,!0;if("sw"in e){const s=document.getElementById("wav");return s&&(s.textContent=n.value+"%"),!0}if(!z)return!1;if("pq"in e){z.pick.q=n.value,t();const s=document.getElementById("pq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(e.tchk!==void 0){const s=z.v.chk[+e.tchk];return s&&(s.tx=n.value),!0}return e.tf?(z.v[e.tf]=n.type==="checkbox"?n.checked:n.value,z.msg&&(z.msg=""),e.tf==="title"&&(z.err=!1),!0):!1}function uk(n,t,e){const s=n.dataset;return s.stg?(_r(s.stg,n.checked).then(t),!0):"sw"in s?(_r("wAlpha",+n.value).then(t),!0):"restore"in s?(n.files&&n.files[0]&&rk(n.files[0],e,t),!0):z&&(s.tf==="date"||s.tf==="done")?(z.v[s.tf]=n.type==="checkbox"?n.checked:n.value,s.tf==="date"&&!n.value&&(z.v.time=""),t(),!0):!1}function dk(n,t,e){if(n.key==="Enter"&&n.target.dataset&&"cqv"in n.target.dataset){n.preventDefault(),Q.quick=n.target.value,rv(e),t();const s=document.querySelector("[data-cqv]");return s&&s.focus(),!0}return!1}let nr=null;function ov(n,t){if(!n.target.closest||!n.target.closest("#mgrid")){nr=null;return}if(n.type==="touchstart")nr=n.touches[0].clientX;else if(n.type==="touchend"&&nr!==null){const e=n.changedTouches[0].clientX-nr;nr=null,Math.abs(e)>70&&(Q.sel=qr(wi().slice(0,8)+"01",e<0?1:-1),t())}}function hk(){const n=pt(),t=Ll().filter(e=>!e.done);return{today:Ll().filter(e=>e.date===n).sort(jr),late:t.filter(e=>e.date&&e.date<n).sort((e,s)=>e.date.localeCompare(s.date)),dues:t.filter(e=>e.kind==="due"&&e.date&&e.date>n&&e.date<=Ae(n,14)).sort((e,s)=>e.date.localeCompare(s.date))}}let fp=null,pp="";function fk(){!Ps||!vr.tasks||(clearTimeout(fp),fp=setTimeout(()=>{const n={};A.tasks.forEach(r=>{const o={...r};delete o.id,n[r.id]=o});const t=JSON.stringify(n),e=A.emps.map(r=>({id:r.id,name:r.name||""})),s=ic(),i=t.length+":"+t+JSON.stringify(e)+JSON.stringify(s);i!==pp&&(pp=i,Et.setTasks(t,e,s))},400))}const Y=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),pk=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Xt=n=>pk.format(Math.round((n||0)*100)/100),gt=n=>String(F(C(n))).replace(".",","),Ve=n=>C(String(n??"").replace(",","."),NaN),mp=n=>n<10?"0"+n:""+n,td=n=>n.getFullYear()+"-"+mp(n.getMonth()+1)+"-"+mp(n.getDate()),Fn=n=>{if(!n)return"";const t=String(n).slice(0,10).split("-");return t[2]+"/"+t[1]+"/"+t[0]},mk=n=>{try{return new Date(n+"T12:00").toLocaleDateString("el-GR",{weekday:"short"})}catch{return""}},_t=(n,t)=>(n||[]).find(e=>e.id===t),gk=["Ιανουάριος","Φεβρουάριος","Μάρτιος","Απρίλιος","Μάιος","Ιούνιος","Ιούλιος","Αύγουστος","Σεπτέμβριος","Οκτώβριος","Νοέμβριος","Δεκέμβριος"],yk=n=>{const t=n.split("-");return gk[+t[1]-1]+" "+t[0]},zn=n=>!!vr[n]||!!A[n].length,O={openNext:"",emp:"",month:"",f:null,stTab:"stock",stQ:"",stAll:!1,sheet:null,inQ:""},av=()=>!!O.f||!!O.sheet;function vk(){O.f=null,O.sheet=null}function Aa(n){let t=0,e=0,s=0;return A.wdays.forEach(i=>{i.empId===n&&(t+=C(i.amount),s+=C(i.days))}),A.wpays.forEach(i=>{i.empId===n&&(e+=C(i.amount))}),{earned:F(t),paid:F(e),bal:F(t-e),days:F(s)}}function gp(n){if(!n||!n.from||!n.until)return null;const t=n.from.split(":"),e=n.until.split(":");let s=+e[0]*60+ +e[1]-(+t[0]*60+ +t[1]);return s<=0&&(s+=1440),{txt:n.from+"–"+n.until,h:F(s/60)}}const ed=()=>A.emps.filter(n=>n.name&&(!yt()||n.id===xe())).slice().sort((n,t)=>String(n.name).localeCompare(String(t.name),"el")),In=n=>n?JSON.parse(JSON.stringify(n)):null;function Us(n,t,e,s,i){if(yt())return;const r=i||s||{},o=n==="emps"?e:r.empId||"",a=_t(A.emps,o);qt("pbuys",{id:Kt(),ts:Date.now(),kind:"hist",area:"wages",coll:n,act:t,recId:e,empId:o,empName:n==="emps"?r.name||"":a&&a.name||"",partner:"",at:new Date().toISOString(),before:In(s),after:In(i)})}const Qc=(n,t)=>Object.keys({...n,...t}).some(e=>e!=="id"&&e!=="ts"&&JSON.stringify(n[e])!==JSON.stringify(t[e]));function _k(n,t){const e=ed();if(yt()){const r=e[0];return r?cv(r.id,n,t,!0):t(n("Μεροκάματα",""),`<div class="card"><div class="empty">${zn("emps")?"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει.":"Φόρτωση…"}</div></div>`,"menu")}const s=e.reduce((r,o)=>r+Math.max(0,Aa(o.id).bal),0),i=`<div class="kpis"><div class="kpi"><b class="${s>0?"bad":""}">${Xt(s)}</b><span>Χρωστάω σε υπαλλήλους</span></div><div class="kpi"><b>${e.length}</b><span>Υπάλληλοι</span></div></div>
    <div class="card">${e.map(r=>{const o=Aa(r.id);return`<a class="row" href="#/wage/${encodeURIComponent(r.id)}"><div class="av">👷</div><div class="t"><b>${Y(r.name)}</b><span>${Xt(r.rate||0)} / ημέρα · ${gt(o.days)} ημέρες</span></div>
      <div class="r"><div class="amt ${o.bal>.004?"bad":""}">${o.bal>.004?Xt(o.bal):o.bal<-.004?"−"+Xt(-o.bal):"✓"}</div><span class="muted">${o.bal>.004?"του χρωστάω":o.bal<-.004?"προπληρωμή":"τακτοποιημένο"}</span></div></a>`}).join("")||`<div class="empty">${zn("emps")?"Δεν υπάρχουν υπάλληλοι.":"Φόρτωση…"}</div>`}</div>
    <button class="btn b2 wide" data-wa="emp-new">＋ Νέος υπάλληλος</button>
    <div class="hint" style="margin-top:10px">Η διαγραφή μεροκάματων/πληρωμών γίνεται από το PWA, που τις κρατά στον κάδο.</div>`;return t(n("Μεροκάματα","Υπάλληλοι · υπόλοιπα"),i+uv(),"menu",'<button class="fab" data-wa="work-new" aria-label="Νέο μεροκάματο">＋</button>')}function cv(n,t,e,s){const i=_t(A.emps,n);if(!i)return e(t("Υπάλληλος","",'<a class="ib" href="#/wages">←</a>'),`<div class="card"><div class="empty">${zn("emps")?"Δεν βρέθηκε.":"Φόρτωση…"}</div></div>`,null);const r=Aa(n),o=!yt(),a=[];A.wdays.forEach(E=>{E.empId===n&&a.push({t:"work",id:E.id,date:E.date,ts:E.ts||0,amt:C(E.amount),desc:(gp(E)?gp(E).txt+" · ":"")+gt(E.days)+(C(E.days)===1?" ημέρα":" ημέρες")+" × "+Xt(E.rate)+(E.note?" · "+E.note:"")})}),A.wpays.forEach(E=>{E.empId===n&&a.push({t:"pay",id:E.id,date:E.date,ts:E.ts||0,amt:-C(E.amount),desc:(E.method==="bank"?"Τράπεζα":"Μετρητά")+(E.note?" · "+E.note:"")})});const l=[...new Set(a.map(E=>String(E.date).slice(0,7)))].sort().reverse(),u=O.month&&l.includes(O.month)?O.month:"",h=a.filter(E=>!u||String(E.date).startsWith(u)).sort((E,$)=>E.date<$.date?1:E.date>$.date?-1:$.ts-E.ts),p=h.filter(E=>E.amt>0).reduce((E,$)=>E+$.amt,0),m=h.filter(E=>E.amt<0).reduce((E,$)=>E-$.amt,0),I=`<div class="kpis"><div class="kpi"><b class="${r.bal>.004?"bad":""}">${Xt(r.bal)}</b><span>${s?"Μου χρωστάνε":"Του χρωστάω"}</span></div><div class="kpi"><b>${gt(r.days)}</b><span>Ημέρες συνολικά</span></div>
    <div class="kpi"><b>${Xt(r.earned)}</b><span>Μεροκάματα</span></div><div class="kpi"><b>${Xt(r.paid)}</b><span>Πληρωμές</span></div></div>
    <div class="actions"><button class="btn b1" data-wa="work-new" data-emp="${Y(n)}">＋ Μεροκάματο</button>${o?`<button class="btn b2" data-wa="pay-new" data-emp="${Y(n)}">💶 Πληρωμή</button>`:""}</div>
    ${l.length>1?`<div class="chips"><button data-wm="" class="${u?"":"on"}">Όλοι οι μήνες</button>${l.map(E=>`<button data-wm="${E}" class="${u===E?"on":""}">${yk(E)}</button>`).join("")}</div>`:""}
    <div class="card">${h.map(E=>`<${o?`button class="row prow" data-wa="${E.t}-edit" data-id="${Y(E.id)}"`:'div class="row"'}><div class="av">${E.t==="work"?"🛠️":"💶"}</div>
      <div class="t"><b>${Fn(E.date)} · ${mk(E.date)}</b><span>${Y(E.desc)}</span></div><div class="r"><div class="amt ${E.amt<0?"ok":""}">${E.amt>0?"+":"−"}${Xt(Math.abs(E.amt))}</div><span class="muted">${E.t==="work"?"μεροκάματο":"πληρωμή"}</span></div></${o?"button":"div"}>`).join("")||`<div class="empty">${zn("wdays")?"Καμία κίνηση.":"Φόρτωση…"}</div>`}
    ${h.length?`<div class="tot"><span>Μεροκάματα ${Xt(p)} · Πληρωμές ${Xt(m)}</span><b>${Xt(p-m)}</b></div>`:""}</div>
    ${o?`<button class="btn b2 wide" data-wa="emp-edit" data-emp="${Y(n)}">✏️ Στοιχεία υπαλλήλου</button>`:'<div class="hint">Τα μεροκάματα που καταχωρείς μπαίνουν με το ημερομίσθιο που έχει ορίσει ο διαχειριστής. Αλλαγές και πληρωμές τις κάνει εκείνος.</div>'}`;return e(t(i.name,`${Xt(i.rate||0)} / ημέρα`,s?"":'<a class="ib" href="#/wages">←</a>'),I+uv(),s?"menu":null)}function bk(n,t,e){const s=[],i=n.split("-"),r=t.split("-"),o=new Date(+i[0],+i[1]-1,+i[2],12),a=new Date(+r[0],+r[1]-1,+r[2],12);for(;o<=a&&s.length<93;){const l=o.getDay();e&&(l===0||l===6)||s.push(td(o)),o.setDate(o.getDate()+1)}return s}function lv(n){return n.date?n.id||!n.to||n.to<=n.date?[n.date]:bk(n.date,n.to,!!n.skipWe):[]}function qs(n,t,e){const s=t||(yt()?xe():O.emp)||(ed()[0]||{}).id||"";if(n==="work"){const i=e&&_t(A.wdays,e),r=_t(A.emps,i?i.empId:s);O.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,days:gt(i.days),rate:gt(i.rate!=null&&i.rate!==""?i.rate:C(i.days)?C(i.amount)/C(i.days):r&&r.rate||0),note:i.note||"",from:i.from||"",until:i.until||""}:{empId:s,date:pt(),to:"",skipWe:!0,days:"1",rate:gt(r&&r.rate||0),note:"",from:"",until:""},msg:""}}else if(n==="pay"){const i=e&&_t(A.wpays,e);O.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,amount:gt(i.amount),method:i.method||"cash",note:i.note||""}:{empId:s,date:pt(),amount:"",method:"cash",note:""},msg:""}}else{const i=e&&_t(A.emps,e);O.f={kind:"emp",v:i?{id:i.id,name:i.name||"",rate:gt(i.rate||0),phone:i.phone||"",email:i.email||""}:{name:"",rate:"",phone:"",email:""},msg:""}}}const ye=(n,t,e="")=>`<label class="f">${t}<input class="in" data-wf="${n}" value="${Y(O.f.v[n]??"")}" ${e}></label>`;function uv(){const n=O.f;if(!n)return"";const t=n.v,e=yt(),s=ed();let i="",r="";const o=`<label class="f">Υπάλληλος<select class="in" data-wf="empId" ${e||t.id?"disabled":""}>${s.map(a=>`<option value="${Y(a.id)}" ${a.id===t.empId?"selected":""}>${Y(a.name)}</option>`).join("")}</select></label>`;if(n.kind==="work"){i=t.id?"Διόρθωση μεροκάματου":"Νέο μεροκάματο";const a=lv(t).length,l=Ve(t.days),u=e?C((_t(A.emps,xe())||{}).rate):Ve(t.rate);r=`${o}<div class="two">${ye("date","Ημερομηνία",'type="date"')}${t.id?"":ye("to","Έως (για πολλές μέρες)",'type="date"')}</div>
      ${!t.id&&t.to&&t.to>t.date?`<label class="chk2"><input type="checkbox" data-wf="skipWe" ${t.skipWe?"checked":""}> Χωρίς Σάββατο/Κυριακή</label>`:""}
      <div class="f">Ημέρες ανά ημερομηνία</div><div class="chips wrap">${["1","0,5","1,5","2"].map(h=>`<button data-wd="${h}" class="${t.days===h?"on":""}">${h}</button>`).join("")}</div>
      <div class="two">${ye("days","Ημέρες",'inputmode="decimal"')}${ye("rate","Ημερομίσθιο €",`inputmode="decimal" ${e?"disabled":""}`)}</div>
      <div class="two">${ye("from","Από ώρα (προαιρετικό)",'type="time"')}${ye("until","Έως ώρα",'type="time"')}</div>
      ${ye("note","Σημείωση",'placeholder="π.χ. εγκατάσταση Βόνιτσα"')}
      <div class="ask">${a?`${a} ${a===1?"ημέρα":"ημέρες"} × ${isNaN(l)?"—":gt(l)} × ${Xt(isNaN(u)?0:u)} = <b>${Xt(F(a*(isNaN(l)?0:l)*(isNaN(u)?0:u)))}</b>`:"Βάλε ημερομηνία."}</div>`}else n.kind==="pay"?(i=t.id?"Διόρθωση πληρωμής":"Πληρωμή στον υπάλληλο",r=`${o}<div class="two">${ye("date","Ημερομηνία",'type="date"')}${ye("amount","Ποσό €",'inputmode="decimal"')}</div>
      <div class="seg">${[["cash","💵 Μετρητά"],["bank","🏦 Τράπεζα"]].map(([a,l])=>`<button data-wpm="${a}" class="${t.method===a?"on":""}">${l}</button>`).join("")}</div>
      ${ye("note","Σημείωση")}${t.empId?`<div class="ask">Του χρωστάω τώρα <b>${Xt(Aa(t.empId).bal)}</b></div>`:""}`):(i=t.id?"Στοιχεία υπαλλήλου":"Νέος υπάλληλος",r=`${ye("name","Όνομα",'autocomplete="off"')}${ye("rate","Ημερομίσθιο €",'inputmode="decimal"')}${ye("phone","Κινητό",'inputmode="tel"')}${ye("email","Email",'inputmode="email"')}
      ${t.id?'<div class="hint">Η αλλαγή ημερομισθίου ισχύει για τα νέα μεροκάματα· τα παλιά μένουν όπως είναι.</div>':""}`);return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${i}</b><button class="ib dk" data-wa="close">✕</button></div>
    <div class="sheet-list pad">${r}${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-wa="close">Άκυρο</button><button class="btn b1" data-wa="save">💾 Αποθήκευση</button></div></div></div>`}function wk(n){const t=O.f,e=t.v,s=yt();if(!zn("emps"))return t.msg="Περίμενε να φορτώσουν τα δεδομένα.";if(t.kind==="emp"){const m=String(e.name||"").trim(),I=Ve(e.rate);if(!m)return t.msg="Γράψε όνομα.";if(isNaN(I)||I<0)return t.msg="Βάλε ημερομίσθιο.";const E={name:m,rate:F(I),phone:String(e.phone||"").trim(),email:String(e.email||"").trim()};if(e.id){const $=In(_t(A.emps,e.id));He("emps",e.id,E);const R=_t(A.emps,e.id);Qc($,R)&&Us("emps","edit",e.id,$,In(R))}else{const $={id:Kt(),ts:Date.now(),...E};qt("emps",$),Us("emps","create",$.id,null,$)}return O.f=null,n(e.id?"Ο υπάλληλος ενημερώθηκε.":"Ο υπάλληλος προστέθηκε."),""}const i=s?xe():e.empId,r=_t(A.emps,i);if(!r)return t.msg="Διάλεξε υπάλληλο.";if(t.kind==="pay"){const m=Ve(e.amount);if(!e.date)return t.msg="Βάλε ημερομηνία.";if(isNaN(m))return t.msg="Βάλε ποσό.";const I={empId:i,date:e.date,amount:F(m),method:e.method==="bank"?"bank":"cash",note:String(e.note||"").trim()};if(e.id){const E=In(_t(A.wpays,e.id));He("wpays",e.id,I);const $=_t(A.wpays,e.id);Qc(E,$)&&Us("wpays","edit",e.id,E,In($))}else{const E={id:Kt(),ts:Date.now(),...I};qt("wpays",E),Us("wpays","create",E.id,null,E)}return O.f=null,n(e.id?"Η πληρωμή ενημερώθηκε.":"Η πληρωμή αποθηκεύτηκε."),""}const o=lv(e);if(!o.length)return t.msg="Βάλε ημερομηνία.";const a=Ve(e.days);let l=Ve(e.rate);if(s&&(l=C(r.rate,0),e.id))return t.msg="Τις αλλαγές τις κάνει ο διαχειριστής.";if(isNaN(a)||a<=0||a>31)return t.msg="Βάλε πόσες ημέρες δούλεψε (π.χ. 1 ή 0,5).";if(isNaN(l))return t.msg="Βάλε ημερομίσθιο.";const u=e.from||"",h=e.until||"";if(!!u!=!!h)return t.msg="Βάλε και τις δύο ώρες (από – έως) ή καμία.";const p={empId:i,days:a,rate:l,amount:F(a*l),note:String(e.note||"").trim(),from:u,until:h};if(e.id){const m=In(_t(A.wdays,e.id));He("wdays",e.id,{...p,date:o[0]});const I=_t(A.wdays,e.id);Qc(m,I)&&Us("wdays","edit",e.id,m,In(I))}else{const m=Date.now(),I=Kt();o.forEach((E,$)=>{const R={id:I+$,...p,date:E,ts:m+$};qt("wdays",R),Us("wdays","create",R.id,null,R)})}return O.f=null,n(e.id?"Το μεροκάματο ενημερώθηκε.":o.length===1?"Το μεροκάματο αποθηκεύτηκε.":`Προστέθηκαν ${o.length} μεροκάματα.`),""}function rc(n,t){let e=0,s=0,i=0,r=0;return A.ldocs.forEach(o=>{o.kind==="purchase"&&o.items&&o.items.forEach(a=>{a.pid===n&&(e+=C(a.qty))})}),A.smoves.forEach(o=>{o.pid===n&&(e+=C(o.qty))}),A.quotes.forEach(o=>{if(o.id===t)return;const a=ae(o);(o.lines||[]).forEach(l=>{if(l.pid!==n||l.src!=="stock")return;const u=C(l.qty);a==="done"?o.noStock||(s+=u):a==="accepted"?i+=u:a==="pending"&&(r+=u)})}),{inQ:F(e),onHand:F(e-s),reserved:F(i),pending:F(r),avail:F(e-s-i)}}const dv=n=>n&&Array.isArray(n.links)&&n.links.length?n.links:n&&(n.sup||n.url)?[{sup:n.sup||"",url:n.url||""}]:[];function Zo(){const n={},t=(e,s)=>n[e]||(n[e]={pid:e,qty:0,sup:0,stk:0,qs:[],desc:s||"",why:[]});return A.quotes.forEach(e=>{ae(e)==="accepted"&&(e.lines||[]).forEach(s=>{if(!s.pid||s.src!=="supplier")return;const i=t(s.pid,s.desc);i.sup+=C(s.qty),i.qs.includes(e.number)||i.qs.push(e.number)})}),A.products.forEach(e=>{const s=C(e.minQty,0),i=rc(e.id),r=Math.max(0,s-i.avail);if(r>.004){const o=t(e.id,e.model);o.stk=F(r),o.why.push(i.avail<0?"λείπουν "+gt(-i.avail)+" για δεσμευμένες"+(s?" + ελάχιστο "+gt(s):""):"απόθεμα "+gt(i.avail)+" < ελάχιστο "+gt(s))}}),Object.values(n).map(e=>(e.qty=F(e.sup+e.stk),e.sup&&e.why.unshift(gt(e.sup)+" για προσφορές "+e.qs.join(", ")),e)).filter(e=>e.qty>0).sort((e,s)=>{const i=_t(A.products,e.pid),r=_t(A.products,s.pid);return String(i?i.model:e.desc).localeCompare(String(r?r.model:s.desc),"el")})}function Ik(){const n={};return Zo().forEach(t=>{const e=_t(A.products,t.pid),s=e?dv(e)[0]:null,i=s&&s.sup||"Χωρίς προμηθευτή";(n[i]=n[i]||[]).push("• "+(e?e.model:t.desc)+" × "+gt(t.qty))}),Object.keys(n).sort().map(t=>t+`:
`+n[t].join(`
`)).join(`

`)}const Ek={in:"Χειροκίνητη εισαγωγή",out:"Χειροκίνητη έξοδος",set:"Διόρθωση αποθέματος"};function Tk(n,t){yt()&&(O.stTab="needs");const e=yt()?[["needs","🧰 Εργαλεία που λείπουν"]]:[["stock","📦 Απόθεμα"],["order","🛒 Παραγγελία"],["moves","↕ Κινήσεις"],["needs","🧰 Λείπουν"]],s=O.stTab;let i=e.length>1?`<div class="chips">${e.map(([r,o])=>`<button data-stt="${r}" class="${s===r?"on":""}">${o}${r==="order"&&Zo().length?` (${Zo().length})`:""}${r==="needs"?` (${A.needs.filter(a=>!a.gone&&!a.done).length})`:""}</button>`).join("")}</div>`:"";if(s==="stock"){const r=A.products.map(m=>({p:m,i:rc(m.id)}));let o=0,a=0,l=0,u=0;r.forEach(m=>{m.i.onHand>0&&(o++,a+=m.i.onHand,l+=m.i.onHand*C(m.p.cost)),m.i.avail<0&&u++});const h=Rt(O.stQ),p=r.filter(m=>(O.stAll||m.i.inQ!==0||m.i.onHand!==0||m.i.reserved||m.i.pending||C(m.p.minQty,0)>0)&&Rt((m.p.cat||"")+" "+m.p.model+" "+(m.p.desc||"")).includes(h)).sort((m,I)=>String(m.p.model).localeCompare(String(I.p.model),"el"));i+=`<div class="kpis"><div class="kpi"><b>${o}</b><span>Είδη στο ράφι</span></div><div class="kpi"><b>${gt(a)}</b><span>Τεμάχια</span></div><div class="kpi"><b>${Xt(l)}</b><span>Αξία (τιμή αγοράς)</span></div><div class="kpi"><b class="${u?"bad":""}">${u}</b><span>Ελλείψεις</span></div></div>
      <input class="search" id="stq" data-stq placeholder="🔍 Αναζήτηση προϊόντος" value="${Y(O.stQ)}">
      <label class="chk2"><input type="checkbox" data-stall ${O.stAll?"checked":""}> Όλα τα προϊόντα του καταλόγου</label>
      <div class="card">${p.slice(0,200).map(({p:m,i:I})=>{const E=C(m.minQty,0);return`<button class="row prow" data-sp="${Y(m.id)}"><div class="t"><b>${Y(m.model)}</b><span>${Y([m.cat,m.desc].filter(Boolean).join(" · "))}${I.reserved?` · δεσμευμένα ${gt(I.reserved)}`:""}${I.pending?` · σε προσφορές ${gt(I.pending)}`:""}${E?` · ελάχ. ${gt(E)}`:""}</span></div>
        <div class="r"><div class="amt">${gt(I.onHand)}</div><span class="pill ${I.avail<0?"p-b":E&&I.avail<E?"p-w":I.avail>0?"p-ok":"p-a"}">διαθ. ${gt(I.avail)}</span></div></button>`}).join("")||`<div class="empty">${zn("products")?A.products.length?"Δεν υπάρχουν προϊόντα στην αποθήκη. Τσέκαρε «Όλα τα προϊόντα» για να βάλεις απόθεμα.":"Ο κατάλογος είναι άδειος.":"Φόρτωση…"}</div>`}</div>`}else if(s==="order"){const r=Zo();i+=`<div class="card">${r.map(o=>{const a=_t(A.products,o.pid),l=a?dv(a):[];return`<div class="item"><div class="t"><b>${Y(a?a.model:o.desc)} × ${gt(o.qty)}</b><span style="white-space:normal">${Y(o.why.join(" · "))}</span>
      ${l.map(u=>`<span>${Y(u.sup||"")}${u.code?" · "+Y(u.code):""}${/^https?:\/\//.test(u.url||"")?` · <a class="lnk" href="${Y(u.url)}">άνοιγμα</a>`:""}</span>`).join("")}</div></div>`}).join("")||'<div class="empty">Τίποτα προς παραγγελία. Εδώ μπαίνουν οι γραμμές «Από προμηθευτή» των δεκτών προσφορών, οι ελλείψεις και ό,τι είναι κάτω από το ελάχιστο απόθεμα.</div>'}</div>
      ${r.length?'<button class="btn b1 wide" data-sa="ocopy">📋 Αντιγραφή λίστας ανά προμηθευτή</button>':""}`}else if(s==="moves"){const r=[];A.smoves.forEach(o=>r.push({date:o.date,ts:o.ts||0,pid:o.pid,qty:C(o.qty),why:Ek[o.kind]||"Κίνηση",note:o.note})),A.ldocs.forEach(o=>{o.kind==="purchase"&&o.items&&o.items.forEach(a=>r.push({date:o.date,ts:o.ts||0,pid:a.pid,qty:C(a.qty),why:"Αγορά από "+o.party+(o.number?" ("+o.number+")":""),note:""}))}),r.sort((o,a)=>o.date<a.date?1:o.date>a.date?-1:a.ts-o.ts),i+=`<div class="card">${r.slice(0,80).map(o=>{const a=_t(A.products,o.pid);return`<div class="item"><div class="t"><b>${Y(a?a.model:"(διαγραμμένο προϊόν)")}</b><span>${Fn(o.date)} · ${Y(o.why)}${o.note?" · "+Y(o.note):""}</span></div><div class="amt ${o.qty<0?"bad":"ok"}">${o.qty>0?"+":""}${gt(o.qty)}</div></div>`}).join("")||'<div class="empty">Δεν υπάρχουν κινήσεις ακόμα.</div>'}</div>`}else i+=kk();return t(n(yt()?"Εργαλεία που λείπουν":"Αποθήκη",yt()?"Ό,τι λείπει από το συνεργείο":"Απόθεμα · παραγγελίες · εργαλεία"),i+Ak(),"menu",s==="needs"?'<button class="fab" data-na="new" aria-label="Προσθήκη">＋</button>':"")}function Ak(){const n=O.sheet;if(!n)return"";if(n.kind==="need"){const o=n.v;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${o.id?"Αλλαγή":"Τι λείπει;"}</b><button class="ib dk" data-na="close">✕</button></div><div class="sheet-list pad">
      <label class="f">Εργαλείο / υλικό<input class="in" data-nf="title" maxlength="120" value="${Y(o.title)}" placeholder="π.χ. Κρουστικό δράπανο"></label>
      <div class="two"><label class="f">Ποσότητα<input class="in" data-nf="qty" maxlength="20" value="${Y(o.qty)}"></label><label class="f">Σημείωση<input class="in" data-nf="notes" maxlength="300" value="${Y(o.notes)}"></label></div>
      ${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}</div><div class="actions"><button class="btn b2" data-na="close">Άκυρο</button><button class="btn b1" data-na="save">💾 Αποθήκευση</button></div></div></div>`}const t=_t(A.products,n.pid);if(!t)return"";const e=rc(t.id),s=n.v,i=Ve(s.qty),r=isNaN(i)?null:s.type==="in"?e.onHand+i:s.type==="out"?e.onHand-i:i;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${Y(t.model)}</b><button class="ib dk" data-sa="close">✕</button></div><div class="sheet-list pad">
    <div class="kpis"><div class="kpi"><b>${gt(e.onHand)}</b><span>Στο ράφι</span></div><div class="kpi"><b class="${e.avail<0?"bad":""}">${gt(e.avail)}</b><span>Διαθέσιμα (μετά τις δεσμευμένες)</span></div></div>
    <div class="seg">${[["in","➕ Εισαγωγή"],["out","➖ Έξοδος"],["set","✏️ Διόρθωση"]].map(([o,a])=>`<button data-smt="${o}" class="${s.type===o?"on":""}">${a}</button>`).join("")}</div>
    <div class="two"><label class="f">${s.type==="set"?"Πραγματική ποσότητα στο ράφι":"Ποσότητα"}<input class="in" data-sf="qty" inputmode="decimal" value="${Y(s.qty)}"></label><label class="f">Ημερομηνία<input class="in" type="date" data-sf="date" value="${Y(s.date)}"></label></div>
    <label class="f">Σημείωση<input class="in" data-sf="note" value="${Y(s.note)}"></label>
    <div class="ask" id="smprev">Τώρα στο ράφι: ${gt(e.onHand)} τεμ.${r!==null&&s.qty!==""?` → μετά: <b>${gt(F(r))}</b>`:""}</div>
    <label class="f" style="margin-top:10px">Ελάχιστο απόθεμα (κάτω από αυτό μπαίνει στη λίστα παραγγελίας)<input class="in" data-sf="min" inputmode="decimal" value="${Y(s.min)}" placeholder="—"></label>
    ${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-sa="close">Άκυρο</button><button class="btn b1" data-sa="save">💾 Αποθήκευση</button></div></div></div>`}function Sk(n){const t=O.sheet,e=t.v,s=_t(A.products,t.pid);if(!s)return O.sheet=null;const i=e.min.trim()===""?0:Math.max(0,Ve(e.min));if(isNaN(i))return t.msg="Το ελάχιστο απόθεμα πρέπει να είναι αριθμός.";let r=[];if(e.qty.trim()!==""){const o=Ve(e.qty);if(isNaN(o)||o<0)return t.msg="Βάλε ποσότητα.";const a=rc(s.id),l=e.type==="in"?o:e.type==="out"?-o:F(o-a.onHand);if(!l)return t.msg="Δεν υπάρχει αλλαγή στην ποσότητα.";qt("smoves",{id:Kt(),pid:s.id,qty:F(l),kind:e.type,date:e.date||pt(),note:e.note.trim(),ts:Date.now()}),r.push("Η κίνηση αποθηκεύτηκε")}C(s.minQty,0)!==i&&(He("products",s.id,{minQty:i}),r.push(i?"ελάχιστο "+gt(i):"χωρίς ελάχιστο")),O.sheet=null,n(r.length?r.join(" · ")+".":"Καμία αλλαγή.")}const Sa=n=>!yt()||!!(_i()&&n.by&&n.by.uid===_i().uid),yp=n=>n?Fn(td(new Date(n))):"";function kk(){const n=A.needs.filter(i=>!i.gone),t=n.filter(i=>!i.done).sort((i,r)=>(r.ts||0)-(i.ts||0)),e=n.filter(i=>i.done).sort((i,r)=>(r.doneAt||r.ts||0)-(i.doneAt||i.ts||0)),s=(i,r)=>`<div class="tc${r?" dn":""}" style="--c:${r?"var(--ok)":"var(--warn)"}">
    ${yt()?`<span class="tick${r?" on":""}" style="display:flex;align-items:center;justify-content:center">${r?"✓":""}</span>`:`<button class="tick${r?" on":""}" data-na="done" data-id="${Y(i.id)}" aria-label="Παραγγέλθηκε">${r?"✓":""}</button>`}
    <div class="t" style="flex:1"><b>${Y(i.title)}${i.qty?" × "+Y(i.qty):""}</b><span>${Y(i.by&&i.by.name||"—")} · ${Y(yp(i.ts))}${r&&i.doneAt?" · ✔ παραγγέλθηκε "+Y(yp(i.doneAt)):""}${i.notes?" · "+Y(i.notes):""}</span></div>
    ${Sa(i)?`<button class="x" style="background:var(--accs);color:var(--acc)" data-na="edit" data-id="${Y(i.id)}" aria-label="Αλλαγή">✏️</button><button class="x" data-na="gone" data-id="${Y(i.id)}" aria-label="Αφαίρεση">✕</button>`:""}</div>`;return`<div class="hint">${yt()?"Ό,τι γράφεις εδώ το βλέπει και ο διαχειριστής και μπαίνει στη λίστα παραγγελιών του.":"Το PWA τα συγχρονίζει με τη λίστα «Εργαλεία που λείπουν» του Microsoft To Do."}</div>
    <div class="h">Να παραγγελθούν (${t.length})${!yt()&&t.length?'<a class="hl" data-na="copy">📋 Αντιγραφή</a>':""}</div>
    <div class="card">${t.map(i=>s(i,!1)).join("")||`<div class="empty">${zn("needs")?"Δεν λείπει τίποτα αυτή τη στιγμή.":"Φόρτωση…"}</div>`}</div>
    ${e.length?`<div class="h">Παραγγέλθηκαν (${e.length})</div><div class="card">${e.slice(0,40).map(i=>s(i,!0)).join("")}</div>`:""}`}function Rk(n){const t=O.sheet,e=t.v,s=String(e.title||"").trim().slice(0,120);if(!s)return t.msg="Γράψε ποιο εργαλείο λείπει.";const i=Date.now(),r=String(e.qty||"").trim().slice(0,20),o=String(e.notes||"").trim().slice(0,300);if(e.id){const a=_t(A.needs,e.id);if(!a||!Sa(a))return O.sheet=null;He("needs",a.id,{title:s,qty:r,notes:o,by:a.by||{uid:"",name:""},upd:i,dirty:!0}),n("Η καταχώριση ενημερώθηκε.")}else qt("needs",{id:Kt(),ts:i,title:s,qty:r,notes:o,done:!1,gone:!1,msId:"",msList:"",by:Mn()||{uid:"",name:"Διαχειριστής"},upd:i,dirty:!0}),n("Προστέθηκε: "+s+".");O.sheet=null}const hv=n=>{const t=n&&n.war;return t&&t.m!=null&&t.m!==""?Math.max(0,Math.floor(C(t.m,0))):C(ct()&&ct().warrantyMonths,24)},vp=n=>!(n&&n.war&&n.war.on===!1),fs=n=>n.install||{date:n.statusDate||"",months:vp(n)?hv(n):0,serials:"",nw:!vp(n)},oc=(n,t)=>{if(!n)return"";const e=new Date(n+"T00:00:00");return isNaN(e)?"":(e.setMonth(e.getMonth()+C(t,0)),td(e))};function _p(n){const t=fs(n);if(t.nw)return{k:"na",t:"Χωρίς εγγύηση",end:""};const e=oc(t.date,t.months);if(!e)return{k:"na",t:"—",end:""};const s=Math.ceil((new Date(e+"T23:59:59")-Date.now())/864e5);return s<0?{k:"ex",t:"Έληξε",end:e,days:s}:s<=60?{k:"warn",t:"Λήγει σε "+s+" ημ.",end:e,days:s}:{k:"okp",t:"Ενεργή",end:e,days:s}}const Pk=n=>{const t=fs(n);return C(t.mt,0)>0?oc(t.mtLast||t.date,t.mt):""},Ck={okp:"p-ok",warn:"p-w",ex:"p-b",na:"p-a"};function Dk(n,t){const e=A.quotes.filter(u=>ae(u)==="done").sort((u,h)=>(fs(h).date||"")<(fs(u).date||"")?-1:1),s={okp:0,warn:0,ex:0};e.forEach(u=>{const h=_p(u);s[h.k]!=null&&s[h.k]++});const i=Rt(O.inQ),r=e.filter(u=>!i||Rt([u.number,u.subject,u.customer&&u.customer.name,u.customer&&u.customer.address].join(" ")).includes(i)),o=pt().slice(0,10),a=oc(o,1),l=`<div class="kpis"><div class="kpi"><b>${e.length}</b><span>Εγκαταστάσεις</span></div><div class="kpi"><b>${s.okp}</b><span>Ενεργές εγγυήσεις</span></div>
    <div class="kpi"><b class="${s.warn?"bad":""}">${s.warn}</b><span>Λήγουν σε 60 ημέρες</span></div><div class="kpi"><b>${s.ex}</b><span>Έληξαν</span></div></div>
    <input class="search" id="inq" data-inq placeholder="🔍 Πελάτης, αριθμός, περιοχή" value="${Y(O.inQ)}">
    <div class="card">${r.map(u=>{const h=fs(u),p=_p(u),m=Pk(u),I=u.customer&&u.customer.name||"";return`<button class="row prow" data-ie="${Y(u.id)}"><div class="av">${We(u)?"🛠️":"🛡️"}</div><div class="t"><b>${We(u)?Y(u.subject||"Παλιά εγκατάσταση"):"#"+Y(u.number||"—")+" · "+Y(I)}</b>
        <span>${We(u)?Y(I)+" · ":u.subject?Y(u.subject)+" · ":""}${h.date?"εγκατ. "+Fn(h.date):"χωρίς ημερομηνία"}${p.end?" · λήξη "+Fn(p.end):""}${m?" · 🔧 "+Fn(m):""}</span></div>
        <div class="r"><span class="pill ${Ck[p.k]}">${Y(p.t)}</span>${m&&m<=a?'<span class="pill p-w">🔧 συντήρηση</span>':""}</div></button>`}).join("")||`<div class="empty">${zn("quotes")?"Δεν υπάρχουν ολοκληρωμένες εγκαταστάσεις.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Βεβαίωση, τιμολόγια, υπογραφή και κωδικοί: από το PWA (έρχονται και εδώ).</div>`;return t(n("Εγκαταστάσεις","Εγγυήσεις · συντηρήσεις"),l+$k(),"menu")}function $k(){const n=O.sheet;if(!n||n.kind!=="inst")return"";const t=_t(A.quotes,n.id);if(!t)return"";const e=n.v,s=e.nw?"":oc(e.date,C(e.months,0));return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${We(t)?Y(t.subject||"Εγκατάσταση"):"#"+Y(t.number)+" · "+Y(t.customer&&t.customer.name||"")}</b><button class="ib dk" data-ia="close">✕</button></div><div class="sheet-list pad">
    <label class="f">Ημερομηνία εγκατάστασης<input class="in" type="date" data-if="date" value="${Y(e.date)}"></label>
    <label class="chk2"><input type="checkbox" data-if="war" ${e.nw?"":"checked"}> Με εγγύηση</label>
    ${e.nw?"":`<label class="f">Μήνες εγγύησης<input class="in" data-if="months" inputmode="numeric" value="${Y(e.months)}"></label><div class="hint">Λήξη: <b>${s?Fn(s):"—"}</b></div>`}
    <a class="btn b2 wide" href="#/sn/${encodeURIComponent(t.id)}">🔢 Σειριακοί (${(t.install&&t.install.sns||[]).length})</a>
    <div class="f">🔧 Περιοδική συντήρηση</div><div class="chips wrap">${[[0,"Καμία"],[6,"Κάθε 6 μήνες"],[12,"Κάθε 12 μήνες"]].map(([i,r])=>`<button data-imt="${i}" class="${C(e.mt,0)===i?"on":""}">${r}</button>`).join("")}</div>
    ${C(e.mt,0)?`<label class="f">Τιμή συντήρησης €<input class="in" data-if="mtp" inputmode="decimal" value="${Y(e.mtp)}" placeholder="π.χ. 120"></label>`:""}
    ${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}
    <a class="btn b2 wide" href="#/q/${encodeURIComponent(t.id)}">📄 Άνοιγμα ${We(t)?"έργου":"προσφοράς"}</a></div>
    <div class="actions"><button class="btn b2" data-ia="close">Άκυρο</button><button class="btn b1" data-ia="save">💾 Αποθήκευση</button></div></div></div>`}function Vk(n){const t=O.sheet,e=_t(A.quotes,t.id);if(!e)return O.sheet=null;const s=t.v,i=ce(fs(e));if(i.date=s.date||"",i.nw=!!s.nw,!i.nw){const o=Math.floor(Ve(s.months));if(isNaN(o)||o<0)return t.msg="Βάλε μήνες εγγύησης.";i.months=o}const r=Math.max(0,Math.floor(C(s.mt,0)));if(r){i.mt=r;const o=Ve(s.mtp);o>0?i.mtp=F(o):delete i.mtp}else delete i.mt,delete i.mtLast,delete i.mtp;He("quotes",e.id,{install:i}),O.sheet=null,n("Αποθηκεύτηκε.")}function fv(n){const t=_t(A.products,n);return t?(O.stTab="stock",O.sheet={kind:"stock",pid:n,v:{type:"in",qty:"",date:pt(),note:"",min:C(t.minQty,0)?gt(t.minQty):""},msg:""},!0):!1}function Nk(n,t,e){const s=n.closest("[data-wa],[data-wm],[data-wd],[data-wpm],[data-stt],[data-sp],[data-sa],[data-smt],[data-na],[data-ie],[data-ia],[data-imt]");if(!s)return!1;const i=s.dataset;if(i.wa){const r=i.wa;r==="close"?O.f=null:r==="save"?wk(e):r==="work-new"?qs("work",i.emp):r==="pay-new"?qs("pay",i.emp):r==="work-edit"?qs("work","",i.id):r==="pay-edit"?qs("pay","",i.id):r==="emp-new"?qs("emp"):r==="emp-edit"&&qs("emp","",i.emp)}else if(i.wm!==void 0)O.month=i.wm;else if(i.wd)O.f&&(O.f.v.days=i.wd);else if(i.wpm)O.f&&(O.f.v.method=i.wpm);else if(i.stt)O.stTab=i.stt;else if(i.sp){const r=_t(A.products,i.sp);O.sheet={kind:"stock",pid:i.sp,v:{type:"in",qty:"",date:pt(),note:"",min:r&&C(r.minQty,0)?gt(r.minQty):""},msg:""}}else if(i.smt)O.sheet&&(O.sheet.v.type=i.smt);else if(i.sa){if(i.sa==="close")O.sheet=null;else if(i.sa==="save")Sk(e);else if(i.sa==="ocopy"){const r=Ik();return r&&(Et.copy("Λίστα παραγγελίας ("+Fn(pt())+`)

`+r),e("Η λίστα αντιγράφηκε, ανά προμηθευτή.")),!0}}else if(i.na){const r=i.id&&_t(A.needs,i.id);if(i.na==="close")O.sheet=null;else if(i.na==="new")O.sheet={kind:"need",v:{title:"",qty:"",notes:""},msg:""};else if(i.na==="edit"&&r&&Sa(r))O.sheet={kind:"need",v:{id:r.id,title:r.title||"",qty:r.qty||"",notes:r.notes||""},msg:""};else if(i.na==="save")Rk(e);else if(i.na==="done"&&r&&!yt()){const o=!r.done,a=Date.now();He("needs",r.id,{done:o,doneAt:o?a:void 0,upd:a,dirty:!0}),e(o?"Σημειώθηκε ως παραγγελμένο.":"Ξαναμπήκε στη λίστα.")}else if(i.na==="gone"&&r&&Sa(r))He("needs",r.id,{gone:!0,upd:Date.now(),dirty:!0}),e("Αφαιρέθηκε: "+r.title,{label:"Αναίρεση",fn:()=>{He("needs",r.id,{gone:!1,msId:"",upd:Date.now(),dirty:!0}),t()}});else if(i.na==="copy"){const o=A.needs.filter(a=>!a.gone&&!a.done).sort((a,l)=>(a.ts||0)-(l.ts||0)).map(a=>"• "+a.title+(a.qty?" × "+a.qty:"")+(a.notes?" ("+a.notes+")":"")).join(`
`);return o&&(Et.copy(o),e("Η λίστα αντιγράφηκε.")),!0}}else if(i.ie){const r=_t(A.quotes,i.ie);if(r){const o=fs(r);O.sheet={kind:"inst",id:r.id,v:{date:o.date||"",nw:!!o.nw,months:String(C(o.months,hv(r))),mt:C(o.mt,0),mtp:o.mtp?gt(o.mtp):""},msg:""}}}else i.imt!==void 0?O.sheet&&(O.sheet.v.mt=+i.imt):i.ia&&(i.ia==="close"?O.sheet=null:i.ia==="save"&&Vk(e));return t(),!0}function xk(n,t){const e=n.dataset,s=i=>{t();const r=document.getElementById(i);r&&(r.focus(),r.setSelectionRange(r.value.length,r.value.length))};return"stq"in e?(O.stQ=n.value,s("stq"),!0):"inq"in e?(O.inQ=n.value,s("inq"),!0):e.wf&&O.f?(O.f.v[e.wf]=n.type==="checkbox"?n.checked:n.value,O.f.msg="",!0):e.nf&&O.sheet?(O.sheet.v[e.nf]=n.value,!0):e.sf&&O.sheet?(O.sheet.v[e.sf]=n.value,!0):e.if&&O.sheet?(O.sheet.v[e.if]=n.value,!0):!1}function Ok(n,t){const e=n.dataset;if("stall"in e)return O.stAll=n.checked,t(),!0;if(e.wf&&O.f){if(O.f.v[e.wf]=n.type==="checkbox"?n.checked:n.value,e.wf==="empId"&&!O.f.v.id&&O.f.kind==="work"){const s=_t(A.emps,n.value);s&&(O.f.v.rate=gt(s.rate||0))}return t(),!0}return e.sf&&O.sheet?(O.sheet.v[e.sf]=n.value,t(),!0):e.if&&O.sheet?(e.if==="war"?O.sheet.v.nw=!n.checked:O.sheet.v[e.if]=n.value,t(),!0):!1}const ke=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),Mk=n=>String(Math.round(C(n)*100)/100).replace(".",","),Un=(n,t)=>(n||[]).find(e=>e.id===t),Lk=["ean_13","ean_8","upc_a","upc_e","EAN_13","EAN_8","UPC_A","UPC_E"],j={stream:null,det:null,zx:null,t:0,ref:"",label:"",last:"",lastT:0,lastDup:"",added:[],track:null,torch:!1,qid:""},pv=()=>!!j.stream||!!document.getElementById("scan-ov"),bp=n=>!(n&&n.war&&n.war.on===!1),Fk=n=>{const t=n&&n.war;return t&&t.m!=null&&t.m!==""?Math.max(0,Math.floor(C(t.m,0))):C((ct()||{}).warrantyMonths,24)},Uk=n=>n.install||{date:n.statusDate||"",months:bp(n)?Fk(n):0,serials:"",nw:!bp(n)};function mv(n){const t=[],e={};return(n.lines||[]).forEach((s,i)=>{const r=s.pid?"p:"+s.pid:"l:"+i;if(e[r]){e[r].qty+=C(s.qty,0);return}e[r]={ref:r,label:s.desc||"(χωρίς περιγραφή)",qty:C(s.qty,0)},t.push(e[r])}),t}const nd=(n,t)=>{const e=mv(n).find(s=>s.ref===t);return e?e.label:""},Jc=(n,t)=>qt("qlog",{id:Kt(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:t});function ka(n,t){n.install?Hf("quotes",n.id,"install.sns",t):Hf("quotes",n.id,"install",{...Uk(n),sns:t})}const gv=n=>String(n||"").split(/[\r\n]+/)[0].trim().replace(/^(S\/?N|SN|SER(IAL)?(\s*NO\.?)?)\s*[:#.\-]?\s*/i,"").replace(/\s+/g," ").trim(),qk=n=>/^([0-9A-F]{2}[:\-]?){5}[0-9A-F]{2}$/i.test(n);function yv(n,t,e,s,i){if(!i&&Lk.includes(s))return"skip";const r=i?String(e||"").trim():gv(e);if(!r||r.length<3||r.length>64||!i&&(qk(r)||/^https?:\/\//i.test(r)))return"skip";const o=(n.install&&n.install.sns||[]).slice(),a=r.toUpperCase();if(o.some(u=>String(u.sn).toUpperCase()===a))return"dup";const l={id:Kt(),sn:r,ref:t,item:nd(n,t),name:"",ts:Date.now()};return o.push(l),j.added.push(l.id),ka(n,o),"added"}function Bk(n,t,e){const s=Un(A.quotes,n);if(!s)return e(t("Σειριακοί","",'<a class="ib" href="#/inst">←</a>'),'<div class="empty">Δεν βρέθηκε</div>',"menu");const i=s.install&&s.install.sns||[],r=mv(s),o={};r.forEach(l=>o[l.ref]=1);const a=i.filter(l=>!o[l.ref]);return a.length&&r.push({ref:"__other",label:"Άλλα (προϊόντα που δεν υπάρχουν πια στην προσφορά)",qty:0}),e(t("Σειριακοί",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,'<a class="ib" href="#/inst">←</a>'),'<div class="hint">Πάτα «📷 Σάρωση» στο προϊόν και σκάναρε τα barcode ή QR των συσκευών. Δίπλα σε κάθε σειριακό γράψε όνομα θέσης (π.χ. «Κάμερα εισόδου»).</div>'+r.map(l=>{const u=l.ref==="__other"?a:i.filter(h=>h.ref===l.ref);return`<div class="card pad sn-g"><div class="sn-h"><div><b>${ke(l.label)}</b> <span class="muted">(${u.length}${l.qty?" / "+Mk(l.qty):""})</span></div>${l.ref==="__other"?"":`<button class="btn b1 sm" data-sn-scan="${ke(l.ref)}">📷 Σάρωση</button>`}</div>
      ${u.map(h=>`<div class="sn-row"><code>${ke(h.sn)}</code><input class="in" data-sn-name="${ke(h.id)}" value="${ke(h.name||"")}" placeholder="Όνομα / θέση"><button class="ib dk" data-sn-del="${ke(h.id)}" aria-label="Διαγραφή">🗑️</button></div>`).join("")}
      ${l.ref==="__other"?"":`<div class="sn-add"><input class="in" data-sn-add="${ke(l.ref)}" placeholder="ή πληκτρολόγησε σειριακό" autocapitalize="characters" spellcheck="false"><button class="btn b2 sm" data-sn-addb="${ke(l.ref)}">＋</button></div>`}</div>`}).join("")||'<div class="empty">Η προσφορά δεν έχει γραμμές.</div>',"menu")}let wp=null;const jk=()=>wp||(wp=wn(()=>import("./zxing-CRxvinjV.js"),[]).then(n=>new Function(n.default+"; return ZXing;")()));function vv(){try{const n=window.AudioContext||window.webkitAudioContext;j.ac=j.ac||new n;const t=j.ac.createOscillator(),e=j.ac.createGain();t.frequency.value=1250,e.gain.value=.12,t.connect(e),e.connect(j.ac.destination),t.start(),t.stop(j.ac.currentTime+.09)}catch{}}function zk(){let n=document.getElementById("scan-ov");return n||(n=document.createElement("div"),n.id="scan-ov",document.body.appendChild(n)),n}function sd(){const n=Un(A.quotes,j.qid),t=n?(n.install&&n.install.sns||[]).filter(i=>i.ref===j.ref).length:0,e=document.getElementById("sc-count");e&&(e.textContent=`Σκαναρισμένοι σε αυτό το προϊόν: ${t} · σε αυτή τη σάρωση: ${j.added.length}`);const s=document.getElementById("sc-undo");s&&(s.disabled=!j.added.length)}const Gk=n=>String(n.code||"").split(/[\s,;]+/).filter(Boolean).map(t=>t.toUpperCase()),Kk=n=>{const t=String(n).trim().toUpperCase();return t&&(A.products.find(e=>Gk(e).includes(t))||A.products.find(e=>String(e.model||"").trim().toUpperCase()===t))||null};function _v(n){const t=String(n||"").split(/[\r\n]+/)[0].trim();if(!t||t.length>64)return;const e=Date.now();if(t===j.last&&e-j.lastT<1800)return;j.last=t,j.lastT=e;const s=Kk(t),i=document.getElementById("sc-last"),r=document.getElementById("sc-flash");if(s){try{navigator.vibrate&&navigator.vibrate(80)}catch{}vv();const o=j.rerender;id(),location.hash.startsWith("#/stock")?(fv(s.id),o&&o()):(O.openNext=s.id,location.hash="#/stock")}else r&&(r.className="dup",setTimeout(()=>r.className="",350)),i&&(i.innerHTML="❓ Άγνωστος κωδικός <b>"+ke(t)+"</b>")}function Ip(n,t,e){if(j.mode==="find")return _v(n);const s=Un(A.quotes,j.qid);if(!s)return;const i=Date.now(),r=gv(n);if(r===j.last&&i-j.lastT<2500)return;const o=yv(s,j.ref,n,t,!1);if(o==="skip")return;j.last=r,j.lastT=i;const a=document.getElementById("sc-last"),l=document.getElementById("sc-flash"),u=h=>{l&&(l.className=h,setTimeout(()=>l.className="",350))};if(o==="added"){j.lastDup=r;try{navigator.vibrate&&navigator.vibrate(90)}catch{}vv(),u("ok"),a&&(a.innerHTML="✅ <b>"+ke(r)+"</b>")}else r!==j.lastDup&&(j.lastDup=r,u("dup"),a&&(a.innerHTML="Υπάρχει ήδη: <b>"+ke(r)+"</b>"));sd()}async function Ep(n,t,e,s){const i=n==="",r=Un(A.quotes,n);if(!r&&!i)return;if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return e("Η κάμερα δεν είναι διαθέσιμη εδώ.");Object.assign(j,{mode:i?"find":"sn",qid:n,ref:t,label:i?"Σάρωση προϊόντος":nd(r,t),added:[],last:"",lastT:0,lastDup:"",rerender:s});const o=zk();o.innerHTML=`<div class="sc-top"><b id="sc-title">${ke(j.label)}</b><button class="ib dk" data-sc="close">✕</button></div><video id="sc-video" playsinline muted></video><div id="sc-flash"></div>
  <div class="sc-bot"><div id="sc-last">${i?"Σκάναρε το barcode ενός προϊόντος για να δεις το απόθεμά του.":"Στρέψε την κάμερα στο barcode ή στο QR του σειριακού."}</div><div id="sc-count"></div>
  <div class="sc-btns">${i?"":'<button class="btn b2" data-sc="undo" id="sc-undo" disabled>↶ Αναίρεση</button>'}<button class="btn b2" data-sc="torch" id="sc-torch" hidden>🔦</button><button class="btn b1" data-sc="close">Τέλος</button></div></div>`,o.onclick=a=>bv(a.target,s,e),sd();try{const a=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920},height:{ideal:1080}},audio:!1});if(!document.getElementById("scan-ov")){a.getTracks().forEach(h=>h.stop());return}j.stream=a,j.track=a.getVideoTracks()[0];const l=document.getElementById("sc-video");l.srcObject=a,l.muted=!0,await l.play();try{const h=j.track.getCapabilities&&j.track.getCapabilities();h&&h.torch&&(document.getElementById("sc-torch").hidden=!1)}catch{}let u=!1;if("BarcodeDetector"in window)try{const h=(await Promise.race([BarcodeDetector.getSupportedFormats(),new Promise((p,m)=>setTimeout(()=>m(1),1500))])).filter(p=>p!=="unknown");if(h.length){j.det=new BarcodeDetector({formats:h}),u=!0;const p=()=>{!j.stream||!j.det||j.det.detect(l).then(m=>(m||[]).forEach(I=>Ip(I.rawValue,I.format,e)),()=>{}).then(()=>{j.stream&&(j.t=setTimeout(p,160))})};p()}}catch{}if(!u){const h=await jk();if(!j.stream)return;j.zx=new h.BrowserMultiFormatReader,l.srcObject=null,j.zx.decodeFromStream(j.stream,l,p=>{if(p){let m="";try{m=h.BarcodeFormat[p.getBarcodeFormat()]||""}catch{}Ip(p.getText(),m,e)}})}}catch(a){id(),e(a&&a.name==="NotAllowedError"?"Δεν δόθηκε άδεια για την κάμερα. Δώσ' την από τις ρυθμίσεις του κινητού.":"Δεν άνοιξε η κάμερα.")}}function id(){if(clearTimeout(j.t),j.det=null,j.zx){try{j.zx.reset()}catch{}j.zx=null}j.stream&&(j.stream.getTracks().forEach(t=>t.stop()),j.stream=null),j.track=null,j.torch=!1;const n=document.getElementById("scan-ov");n&&n.remove()}function bv(n,t,e){const s=n.closest("[data-sn-scan],[data-sn-del],[data-sn-addb],[data-sc],[data-bcscan]");if(!s)return!1;if(s.dataset.bcscan!==void 0)return Ep("","",e,t),!0;const i=s.dataset,r=location.hash.replace(/^#\//,"").split("/");if(i.sc){if(i.sc==="close"){const a=Un(A.quotes,j.qid),l=j.added.length;id(),a&&l&&j.mode!=="find"&&(Jc(a,"Σάρωση σειριακών: "+l+" για «"+j.label+"»"),e("Προστέθηκαν "+l+" σειριακοί.")),t()}else if(i.sc==="undo"){const a=Un(A.quotes,j.qid);if(a&&j.added.length){const l=j.added.pop();ka(a,(a.install&&a.install.sns||[]).filter(u=>u.id!==l)),j.last="",sd()}}else i.sc==="torch"&&j.track&&(j.torch=!j.torch,j.track.applyConstraints({advanced:[{torch:j.torch}]}).catch(()=>j.torch=!1));return!0}const o=Un(A.quotes,decodeURIComponent(r[1]||""));if(!o)return!0;if(i.snScan)Ep(o.id,i.snScan,e,t);else if(i.snDel){const a=(o.install&&o.install.sns||[]).find(l=>l.id===i.snDel);a&&confirm("Διαγραφή του σειριακού "+a.sn+";")&&(ka(o,o.install.sns.filter(l=>l.id!==i.snDel)),Jc(o,"Διαγραφή σειριακού "+a.sn),t())}else if(i.snAddb){const a=document.querySelector(`[data-sn-add="${CSS.escape(i.snAddb)}"]`),l=a&&a.value,u=yv(o,i.snAddb,l,"",!0);u==="dup"?e("Αυτός ο σειριακός υπάρχει ήδη."):u==="skip"?e("Γράψε έναν σειριακό αριθμό."):(Jc(o,"Σειριακός "+String(l).trim()+" ("+nd(o,i.snAddb)+")"),t())}return!0}function Wk(n){if(!n.dataset.snName)return!1;const t=Un(A.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));if(!t||!t.install)return!0;const e=(t.install.sns||[]).map(s=>s.id===n.dataset.snName?{...s,name:n.value.trim()}:s);return ka(t,e),!0}const qe=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),Tp=n=>String(n??"").replace(".",","),Bs=n=>{const t=parseFloat(String(n??"").replace(",","."));return isNaN(t)?NaN:t},J={open:"company",f:null,msg:"",ok:""},wv=()=>!!J.f,Hk=()=>{J.f=null,J.msg="",J.ok=""},Qk=[["company","🏢","Εταιρεία & PDF",()=>ct().name||""],["prices","💶","Τιμές & αρίθμηση",()=>"ΦΠΑ "+C(ct().vat,24)+"% · κέρδος "+C(ct().margin,25)+"%"],["banks","🏦","Τραπεζικοί λογαριασμοί",()=>(ct().banks||[]).filter(n=>n.iban).length+" λογαριασμοί"],["team","👥","Χρήστες ομάδας",()=>Object.keys((A.st.roles||{}).users||{}).length+" χρήστες"]],Ap={company:()=>{const n=ct();return{name:n.name||"",info:n.info||"",bizEmail:n.bizEmail||"",pdfColor:n.pdfColor||"#1d4e89",logoMM:String(C(n.logoMM,18)),terms:n.terms||"",termsEn:n.termsEn||"",pubUrl:n.pubUrl||"",qrOn:n.qrOn!==!1}},prices:()=>{const n=ct();return{vat:Tp(C(n.vat,24)),margin:Tp(C(n.margin,25)),next:String(C(n.next,1)),validDays:String(n.validDays==null?15:C(n.validDays,15)),followDays:String(n.followDays==null?7:C(n.followDays,7)),warrantyMonths:String(C(n.warrantyMonths,24)),autoSale:n.autoSale!==!1}},banks:()=>({banks:(ct().banks||[]).map(n=>({id:n.id||Kt(),bank:n.bank||"",iban:n.iban||"",holder:n.holder||"",afm:n.afm||""}))})},tn=(n,t,e="")=>`<label class="f">${t}<input class="in" data-sf="${n}" value="${qe(J.f.v[n]??"")}" ${e}></label>`,Yc=(n,t,e=3)=>`<label class="f">${t}<textarea class="in" data-sf="${n}" rows="${e}">${qe(J.f.v[n]??"")}</textarea></label>`,Sp=(n,t)=>`<label class="chk"><input type="checkbox" data-sf="${n}" ${J.f.v[n]?"checked":""}> ${t}</label>`;function Jk(n){const t=J.f&&J.f.k===n?J.f:null;if(n==="team")return`<div class="muted small" style="margin-bottom:6px">Οι χρήστες ομάδας (τεχνικοί) προστίθενται και αφαιρούνται από το PWA, γιατί χρειάζονται λογαριασμό στο Firebase. Εδώ φαίνονται μόνο.</div>
    ${Object.entries((A.st.roles||{}).users||{}).map(([i,r])=>`<div class="item"><div class="t"><b>${qe(r.name||"—")}</b><span>${r.role==="team"?"Τεχνικός":"Διαχειριστής"}${r.empId?" · υπάλληλος":""}</span></div></div>`).join("")||'<div class="empty">Δεν υπάρχουν χρήστες ομάδας.</div>'}`;if(!t)return`<button class="btn b2 wide" data-st-edit="${n}">✏️ Αλλαγή</button>`+Yk(n);let e="";if(n==="company"){const s=t.logo||A.st.logo||{};e=`${tn("name","Επωνυμία")}${Yc("info","Στοιχεία (διεύθυνση, τηλ., email, ΑΦΜ)",5)}${tn("bizEmail","Email επιχείρησης",'inputmode="email" autocapitalize="off"')}
    <div class="lbl">Λογότυπο PDF ${s.data?"":"(δεν υπάρχει)"}</div>${s.data?`<img class="logo-prev" src="${qe(s.data)}">`:""}
    <label class="btn b2 wide">🖼️ ${s.data?"Αλλαγή":"Επιλογή"} λογοτύπου<input type="file" accept="image/png,image/jpeg" data-sl hidden></label>
    <label class="f">Μέγεθος λογοτύπου<select class="in" data-sf="logoMM">${[["12","Μικρό"],["18","Μεσαίο"],["26","Μεγάλο"]].map(([i,r])=>`<option value="${i}"${String(t.v.logoMM)===i?" selected":""}>${r}</option>`).join("")}</select></label>
    <label class="f">Χρώμα PDF<input class="in" type="color" data-sf="pdfColor" value="${qe(t.v.pdfColor)}" style="height:42px;padding:2px;max-width:120px"></label>
    ${Yc("terms","Όροι (κάτω στο PDF, ελληνικά)",4)}${Yc("termsEn","Όροι στα αγγλικά (κενό = τα ελληνικά)",4)}
    ${tn("pubUrl","Διεύθυνση συνδέσμων προς πελάτες",'inputmode="url" placeholder="https://tech-mate.gr" autocapitalize="off"')}${Sp("qrOn","QR στο PDF προς την Περιοχή πελάτη")}`}else n==="prices"?e=`${tn("vat","ΦΠΑ %",'inputmode="decimal"')}${tn("margin","Προεπιλεγμένο κέρδος % (για προϊόντα χωρίς δικό τους)",'inputmode="decimal"')}
    ${tn("next","Επόμενος αριθμός προσφοράς",'inputmode="numeric"')}${tn("validDays","Ισχύς προσφοράς (ημέρες, 0 = χωρίς)",'inputmode="numeric"')}
    ${tn("followDays","Υπενθύμιση για προσφορά χωρίς απάντηση μετά από (ημέρες, 0 = καμία)",'inputmode="numeric"')}${tn("warrantyMonths","Εγγύηση εγκατάστασης (μήνες)",'inputmode="numeric"')}
    ${Sp("autoSale","Όταν μια προσφορά γίνεται δεκτή, να φτιάχνεται αυτόματα παραστατικό πώλησης")}
    <div class="upd">Προσοχή στον «Επόμενο αριθμό»: αν τον κατεβάσεις, θα ξαναδοθούν αριθμοί που υπάρχουν ήδη.</div>`:n==="banks"&&(e=t.v.banks.map((s,i)=>`<div class="card pad" style="margin:0 0 8px">
      ${["bank:Τράπεζα","iban:IBAN","holder:Δικαιούχος","afm:ΑΦΜ δικαιούχου"].map(r=>{const[o,a]=r.split(":");return`<label class="f">${a}<input class="in" data-sb="${i}:${o}" value="${qe(s[o])}" ${o==="iban"?'autocapitalize="characters"':""}></label>`}).join("")}
      <button class="btn b2" data-st-bdel="${i}">🗑️ Αφαίρεση</button></div>`).join("")+'<button class="btn b2 wide" data-st-badd>＋ Νέος λογαριασμός</button>');return`${e}${J.msg?`<div class="err box">${qe(J.msg)}</div>`:""}<div class="actions"><button class="btn b2" data-st-cancel>Άκυρο</button><button class="btn b1" data-st-save="${n}">Αποθήκευση</button></div>
  <div class="muted small">Αλλάζουν μόνο τα πεδία αυτής της ενότητας· όλα τα υπόλοιπα στοιχεία μένουν όπως είναι.</div>`}function Yk(n){const t=ct(),e=(s,i)=>`<div class="fld"><label>${s}</label><div class="v">${qe(i)||"—"}</div></div>`;return n==="company"?`<div class="sm">${e("Επωνυμία",t.name)}${e("Email",t.bizEmail)}${e("Σύνδεσμοι πελατών",t.pubUrl)}</div>`:n==="prices"?`<div class="sm">${e("Επόμενη προσφορά","#"+C(t.next,1))}${e("Ισχύς προσφοράς",(t.validDays==null?15:t.validDays)+" ημέρες")}${e("Εγγύηση",C(t.warrantyMonths,24)+" μήνες")}</div>`:n==="banks"?`<div class="sm">${(t.banks||[]).filter(s=>s.iban).map(s=>e(s.bank||"Τράπεζα",s.iban)).join("")||'<div class="muted small">Κανένας λογαριασμός.</div>'}</div>`:""}function Xk(n,t){return t(n("Ρυθμίσεις","Εταιρεία · PDF · Τιμές · Τράπεζες",'<a class="ib" href="#/menu">←</a>'),`<div class="card">${Qk.map(([e,s,i,r])=>`<div class="acc${J.open===e?" open":""}"><button class="acc-h" data-st-open="${e}"><span class="ic">${s}</span><span class="t"><b>${i}</b><span>${qe(r())}</span></span><span class="chev">${J.open===e?"▾":"▸"}</span></button>
      ${J.open===e?`<div class="acc-b">${Jk(e)}</div>`:""}</div>`).join("")}</div>
    ${J.ok?`<div class="upd">${qe(J.ok)}</div>`:""}
    <div class="card"><a class="mi" href="#/cset"><div class="ic">🔔</div><div class="t"><b>Ειδοποιήσεις, widget & backup</b><span>Υπενθυμίσεις · Microsoft To Do · Αντίγραφα ημερολογίου</span></div></a></div>
    <div class="muted small" style="padding:0 6px 10px">Email προς πελάτες (πρότυπα, Microsoft), ιστοσελίδα, PIN και Περιοχή πελάτη ρυθμίζονται ακόμα από το PWA — δεν αλλάζουν από εδώ.</div>`,"menu")}function Zk(n){return new Promise((t,e)=>{const s=new FileReader;s.onerror=()=>e(new Error("Δεν διαβάστηκε")),s.onload=()=>{const i=new Image;i.onerror=()=>e(new Error("Δεν είναι εικόνα")),i.onload=()=>{const r=Math.min(1,700/Math.max(i.naturalWidth,i.naturalHeight)),o=Math.max(1,Math.round(i.naturalWidth*r)),a=Math.max(1,Math.round(i.naturalHeight*r)),l=document.createElement("canvas");l.width=o,l.height=a;const u=l.getContext("2d"),h=n.type==="image/png";h||(u.fillStyle="#fff",u.fillRect(0,0,o,a)),u.drawImage(i,0,0,o,a),t({data:l.toDataURL(h?"image/png":"image/jpeg",.9),w:o,h:a})},i.src=s.result},s.readAsDataURL(n)})}function tR(n,t){const e=J.f.v,s={};if(n==="company"){const o=String(e.name||"").trim();if(!o)return J.msg="Γράψε επωνυμία.";const a=String(e.bizEmail||"").trim();if(a&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(a))return J.msg="Το email δεν φαίνεται σωστό.";const l=String(e.pubUrl||"").trim();if(l&&!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}(:\d+)?\/?$/i.test(l))return J.msg="Η διεύθυνση πρέπει να είναι σαν https://tech-mate.gr";Object.assign(s,{name:o,info:e.info,bizEmail:a,pdfColor:e.pdfColor,logoMM:C(e.logoMM,18),terms:e.terms,termsEn:e.termsEn,pubUrl:l,qrOn:!!e.qrOn})}else if(n==="prices"){const o=Bs(e.vat),a=Bs(e.margin),l=Bs(e.next),u=Bs(e.validDays),h=Bs(e.followDays),p=Bs(e.warrantyMonths);if([o,a,l,u,h,p].some(isNaN)||o<0||o>30||a<0||l<1||u<0||h<0||p<0)return J.msg="Έλεγξε τους αριθμούς (δεν μπορούν να είναι κενοί ή αρνητικοί).";const m=A.quotes.reduce((I,E)=>Math.max(I,C(E.number,0)),0);if(Math.floor(l)<=m&&Math.floor(l)!==C(ct().next,1))return J.msg="Υπάρχουν ήδη προσφορές μέχρι το #"+m+". Ο επόμενος αριθμός πρέπει να είναι μεγαλύτερος.";Object.assign(s,{vat:o,margin:a,next:Math.floor(l),validDays:Math.floor(u),followDays:Math.floor(h),warrantyMonths:Math.floor(p),autoSale:!!e.autoSale})}else if(n==="banks"&&(s.banks=e.banks.map(o=>({id:o.id,bank:o.bank.trim(),iban:o.iban.replace(/\s+/g,"").toUpperCase(),holder:o.holder.trim(),afm:o.afm.trim()})).filter(o=>o.bank||o.iban||o.holder),s.banks.some(o=>o.iban&&!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(o.iban))))return J.msg="Ένα IBAN δεν φαίνεται σωστό.";const i={};Object.keys(s).forEach(o=>{JSON.stringify(J.f.v[o])!==JSON.stringify(J.f.v0[o])&&(i[o]=s[o])}),n==="company"&&J.f.logo&&Wf("logo",J.f.logo),Object.keys(i).length&&Wf("main",i);const r=Object.keys(i).length+(J.f.logo?1:0);J.f=null,J.msg="",J.ok=r?"Αποθηκεύτηκε.":"Καμία αλλαγή.",t(J.ok)}function eR(n,t,e){const s=n.closest("[data-st-open],[data-st-edit],[data-st-cancel],[data-st-save],[data-st-badd],[data-st-bdel]");if(!s)return!1;const i=s.dataset;if(i.stOpen){if(J.f)return!0;J.open=J.open===i.stOpen?"":i.stOpen,J.ok=""}else i.stEdit?(J.f={k:i.stEdit,v:Ap[i.stEdit](),v0:JSON.parse(JSON.stringify(Ap[i.stEdit]())),logo:null},J.msg="",J.ok=""):i.stCancel!==void 0?(J.f=null,J.msg=""):i.stSave?tR(i.stSave,e):i.stBadd!==void 0?J.f.v.banks.push({id:Kt(),bank:"",iban:"",holder:"",afm:""}):i.stBdel!==void 0&&J.f.v.banks.splice(+i.stBdel,1);return t(),!0}function nR(n){const t=n.dataset;if(t.sf&&J.f)return J.f.v[t.sf]=n.type==="checkbox"?n.checked:n.value,J.msg="",!0;if(t.sb&&J.f){const[e,s]=t.sb.split(":");return J.f.v.banks[+e][s]=n.value,J.msg="",!0}return!1}async function sR(n,t){const e=n.dataset;if(e.sl!==void 0&&J.f&&n.files&&n.files[0]){try{J.f.logo=await Zk(n.files[0]),J.msg=""}catch(s){J.msg=s.message}return t(),!0}return e.sf&&J.f&&n.tagName==="SELECT"?(J.f.v[e.sf]=n.value,!0):!1}const iR=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),rR=new Intl.NumberFormat("en-GB",{style:"currency",currency:"EUR"}),oR=n=>iR.format(Math.round((n||0)*100)/100),aR=n=>rR.format(Math.round((n||0)*100)/100),cR=n=>String(F(n)).replace(".",","),lR=n=>String(F(n)),Iv=n=>n.qty*n.price*(1-(n.disc||0)/100),uR=864e5,kp={el:{war:"Εγγύηση ",mUnit:"μήνες",noWar:"Χωρίς εγγύηση",planTitle:"Κάτοψη και θέσεις εξοπλισμού",planCam:"Κάμερα",planAp:"Access Point",planOther:"Σημείο",option:"Εναλλακτική: ",valid:"Ισχύει έως: ",payTitle:"Στοιχεία πληρωμής",payBank:"Τράπεζα",payIban:"IBAN",payHolder:"Δικαιούχος",payAfm:"ΑΦΜ",payRef:"Αιτιολογία",payRefVal:"Προσφορά ",payNote:"Παρακαλούμε ελέγξτε το όνομα δικαιούχου και το ΑΦΜ πριν στείλετε την πληρωμή.",notesTitle:"Σημειώσεις",termsTitle:"Όροι και προϋποθέσεις",page:"Σελίδα",of:"από",lang:"el",benTitle:"Τι κερδίζετε",file:"Prosfora_"},en:{war:"Warranty ",mUnit:"months",noWar:"No warranty",planTitle:"Layout and equipment positions",planCam:"Camera",planAp:"Access Point",planOther:"Point",option:"Option: ",valid:"Valid until: ",payTitle:"Payment details",payBank:"Bank",payIban:"IBAN",payHolder:"Beneficiary",payAfm:"VAT No.",payRef:"Reference",payRefVal:"Quotation ",payNote:"Please verify the beneficiary name and VAT number before sending your payment.",notesTitle:"Notes",termsTitle:"Terms and conditions",page:"Page",of:"of",lang:"en",benTitle:"What you gain",title:"QUOTATION",no:"No.: ",date:"Date: ",to:"To",subject:"Subject: ",desc:"Description",qty:"Qty",unit:"Unit price",disc:"Disc.",total:"Total",net:"Net amount",vat:"VAT ",grand:"TOTAL",grandNoVat:"TOTAL (no VAT)",file:"Quotation_"}},dR=n=>!(n&&n.war&&n.war.on===!1),hR=n=>{const t=n&&n.war;return t&&t.m!=null&&t.m!==""?Math.max(0,Math.floor(C(t.m,0))):C(ct().warrantyMonths,24)},fR=(n,t,e)=>{t=t||{};const s=C(t.val,0);return e=e||0,t.type==="eurnet"?F(Math.min(Math.max(0,s)*(1+e/100),n)):t.type==="pct"?F(n*Math.min(100,Math.max(0,s))/100):t.type==="eur"?F(Math.min(Math.max(0,s),n)):0};function Ev(n){let t=0;(n.lines||[]).forEach(u=>t+=Iv(u)),t=F(t);const e=n.vatMode==="off",s=C(ct().vat,24),i=e?0:F(t*s/100),r=F(t+i),o=n.prepay||{},a=e?0:s,l=fR(r,o,a);return{preNet:o.type==="eurnet"?F(l/(1+a/100)):0,sub:t,vat:i,vp:s,vatOff:e,total:r,pre:l,rest:F(r-l),preType:o.type||"",preVal:C(o.val,0)}}const pR=n=>{if(n.descEn)return n.descEn;const t=n.pid&&A.products.find(e=>e.id===n.pid);if(t&&t.descEn){const e=t.model+(t.desc?" - "+t.desc:"");if(!n.desc||n.desc===e)return t.model+" - "+t.descEn}return n.desc},mR=n=>{const t=String(n||"").trim().match(/^(https:\/\/[a-z0-9.-]+\.[a-z]{2,})(:\d+)?\/?$/i);return t?t[1].toLowerCase()+(t[2]||"")+"/":""},gR=n=>String(n&&n.info||"").replace(/\{email\}/gi,n&&n.bizEmail||""),yR=n=>{const t=n.validDays,e=t!=null&&t!==""?C(t,0):ct().validDays==null?15:C(ct().validDays,15);return e?new Date((n.ts||Date.now())+e*uR).toLocaleDateString("el-GR"):""};let Vo=null;async function vR(){if(Vo)return Vo;const[{jsPDF:n},t,e,s,i]=await Promise.all([wn(()=>import("./jspdf.es.min-H7aHxX1a.js").then(a=>a.j),[]),wn(()=>import("./jspdf.plugin.autotable-DYHf0IZ0.js"),[]),wn(()=>import("./reg-DWYsL-bi.js"),[]),wn(()=>import("./bold-BPkZ6IBK.js"),[]),wn(()=>import("./qrlib-Bgozeulj.js"),[])]);(t.applyPlugin||t.default&&t.default.applyPlugin)(n);const r=new Function(i.default+"; return qrcode;")(),o=await wn(()=>import("./gen-C78E_0f9.js"),[]);return Vo={jsPDF:n,fonts:{reg:e.default.trim(),bold:s.default.trim()},qrcode:r,gen:o},Vo}function _R(n,t){try{const e=n(0,"M");e.addData(t),e.make();const s=e.getModuleCount(),i=[];for(let r=0;r<s;r++){let o="";for(let a=0;a<s;a++)o+=e.isDark(r,a)?"1":"0";i.push(o)}return i}catch{return null}}async function bR(n,t){t=t==="en"?"en":"el";const{jsPDF:e,fonts:s,qrcode:i,gen:r}=await vR(),o=ct(),a=A.st.logo||{};let l=JSON.parse(JSON.stringify(n));t==="en"&&(l.lines=l.lines.map($=>({...$,desc:pR($)}))),l.war={on:dR(l),m:hR(l)};const u=mR(o.pubUrl),p={qr:o.qrOn!==!1&&u?_R(i,u+"portal.html"):null,qrT1:t==="en"?"View your documents online":"Δείτε τα έγγραφά σας online",qrT2:t==="en"?"Scan the code and sign in with your personal access code.":"Σκανάρετε το QR και μπείτε με τον προσωπικό σας κωδικό πρόσβασης.",validTo:yR(l),banks:o.banks||[],name:o.name,info:gR(o),terms:t==="en"&&o.termsEn&&o.termsEn.trim()?o.termsEn:o.terms,logoMM:o.logoMM,color:o.pdfColor,logo:a.data,logoW:a.w,logoH:a.h,plan:null},m={};l.lines.forEach(($,R)=>{const B=$.pid&&A.products.find(H=>H.id===$.pid);$.showImg&&B&&B.img&&B.imgW&&B.imgH&&(m[R]={data:B.img,w:B.imgW,h:B.imgH})});const I=r.makePdf(e,s,p,l,Ev(l),t==="en"?aR:oR,t==="en"?lR:cR,Iv,m,kp[t]),E=(l.customer.name||"").replace(/[^\p{L}\p{N}]+/gu,"_").replace(/^_|_$/g,"");return{buf:I,fn:kp[t].file+l.number+(E?"_"+E:"")+".pdf"}}const wR=Ev,No=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),IR=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Rp=(n,t,e)=>String(n||"").replace(/\{(\w+)\}/g,(s,i)=>({number:t.number||"",customer:t.customer&&t.customer.name||"",total:IR.format(wR(t).total),subject:t.subject||"",company:ct().name||"",name:(t.customer&&t.customer.name||"").split(" ")[0]})[i]??s),ER={el:{subj:"Προσφορά {number} - {company}",body:`Καλησπέρα,
σας στέλνω την προσφορά {number} ({subject}). Σύνολο {total}.
Μένω στη διάθεσή σας για οτιδήποτε χρειαστείτε.
{company}`},en:{subj:"Quotation {number} - {company}",body:`Hello,
please find attached quotation {number} ({subject}). Total {total}.
Feel free to contact us for anything you need.
{company}`}};let ut=null;const Tv=()=>!!ut;function TR(){ut=null}function AR(n){if(!A.quotes.find(s=>s.id===n))return;let e="el";try{e=localStorage.getItem("tm-pdflang")==="en"?"en":"el"}catch{}ut={id:n,lang:e,busy:"",msg:""}}function SR(){if(!ut)return"";const n=A.quotes.find(e=>e.id===ut.id);if(!n)return ut=null,"";const t=n.customer&&n.customer.email||"";return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>PDF προσφοράς #${No(n.number)}</b><button class="ib dk" data-sd="close">✕</button></div>
  <div class="sheet-list pad"><div class="lbl">Γλώσσα PDF</div>
  <div class="seg"><button data-sdl="el" class="${ut.lang==="el"?"on":""}">Ελληνικά</button><button data-sdl="en" class="${ut.lang==="en"?"on":""}">English</button></div>
  <div class="sd-btns">
    <button class="btn b1 wide" data-sd="share" ${ut.busy?"disabled":""}>📤 Αποστολή (WhatsApp, Viber, Drive…)</button>
    <button class="btn b2 wide" data-sd="mail" ${ut.busy?"disabled":""}>✉️ Email${t?" στον "+No(t):""}</button>
    <button class="btn b2 wide" data-sd="view" ${ut.busy?"disabled":""}>👁️ Προβολή / Αποθήκευση</button>
  </div>
  ${ut.busy?`<div class="upd">${No(ut.busy)}</div>`:""}${ut.msg?`<div class="err box">${No(ut.msg)}</div>`:""}
  <div class="muted small">Δεν αλλάζει τίποτα στην προσφορά· καταγράφεται μόνο στο ιστορικό της.</div></div></div></div>`}const kR=n=>{const t=new Uint8Array(n);let e="";const s=32768;for(let i=0;i<t.length;i+=s)e+=String.fromCharCode.apply(null,t.subarray(i,i+s));return btoa(e)};async function RR(n,t,e){const s=A.quotes.find(i=>i.id===ut.id);if(s){ut.busy="Φτιάχνω το PDF…",ut.msg="",t();try{const{buf:i,fn:r}=await bR(s,ut.lang);try{localStorage.setItem("tm-pdflang",ut.lang)}catch{}const o=ER[ut.lang],a=ct(),l=Rp(a.mailSubj&&ut.lang==="el"?a.mailSubj:o.subj,s,ut.lang),u=Rp(a.mailBody&&ut.lang==="el"?a.mailBody:o.body,s,ut.lang);let h={ok:!0};if(Ps)h=await Et.shareFile({name:r,b64:kR(i),mime:"application/pdf",text:u,subject:l,email:n==="mail"&&s.customer&&s.customer.email||"",view:n==="view"});else{const p=URL.createObjectURL(new Blob([i],{type:"application/pdf"})),m=document.createElement("a");m.href=p,m.download=r,document.body.appendChild(m),m.click(),m.remove(),setTimeout(()=>URL.revokeObjectURL(p),5e3)}if(h&&h.error)return ut.busy="",ut.msg=h.error,t();qt("qlog",{id:Kt(),qid:s.id,number:s.number||"",customer:s.customer&&s.customer.name||"",ts:Date.now(),type:"pdf",text:"Εξαγωγή PDF ("+(ut.lang==="en"?"αγγλικά":"ελληνικά")+") από την εφαρμογή Android."}),ut=null,e("Το PDF είναι έτοιμο."),t()}catch(i){ut.busy="",ut.msg="Δεν δημιουργήθηκε το PDF. "+(i&&i.message||""),t()}}}function PR(n,t,e){const s=n.closest("[data-sd],[data-sdl],[data-sdq]");if(!s)return!1;const i=s.dataset;return i.sdq?(AR(i.sdq),t(),!0):ut?i.sdl?(ut.lang=i.sdl,t(),!0):(i.sd==="close"?(ut=null,t()):ut.busy||RR(i.sd,t,e),!0):!1}const Oe=document.getElementById("app"),dt=n=>String(n??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),xo=n=>C(n).toLocaleString("el-GR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €",Ii=n=>Math.round(C(n)).toLocaleString("el-GR")+" €",CR=n=>n?new Date(n).toLocaleDateString("el-GR",{day:"numeric",month:"short"}):"",Av=n=>String(n||"?").split(/\s+/).filter(Boolean).slice(0,2).map(t=>t[0]).join("").toUpperCase(),DR={pending:"p-a",accepted:"p-ok",done:"p-ok",rejected:"p-b"};let an=null,Pe=!1;const jt={qf:"all",cq:"",stAsk:null};let kt=null;const $R=[["home","🏠","Αρχική"],["cal","📅","Ημερολόγιο"],["quotes","📄","Προσφορές"],["custs","👥","Πελάτες"],["menu","☰","Μενού"]],VR=n=>`<nav class="nav">${$R.filter(([t])=>!yt()||t==="cal"||t==="menu").map(([t,e,s])=>`<a href="#/${t}" class="${t===n?"on":""}"><i>${e}</i>${s}</a>`).join("")}</nav>`,Pt=(n,t,e="",s="")=>`<header class="top">${e}<h1>${dt(n)}${t?`<span class="sm">${dt(t)}</span>`:""}</h1>${s}</header>`,Ei=n=>`<a class="ib" href="#/${n}">←</a>`,Nt=(n,t,e,s="")=>`${n}<main class="body">${t}</main>${s}${e?VR(e):""}`;function NR(n=""){return`<div class="login"><img class="lico" src="/icon-192.png" alt=""><div class="logo">TechMate</div><p>Συνδέσου με τον ίδιο λογαριασμό που έχεις στο PWA.</p>
  <form id="lf"><label>Email<input name="e" type="email" autocomplete="username" required></label>
  <label>Κωδικός<input name="p" type="password" autocomplete="current-password" required></label>
  <label class="chk"><input type="checkbox" id="sp"> Εμφάνιση κωδικού</label>
  ${n?`<div class="err">${dt(n)}</div>`:""}<button class="btn b1">Σύνδεση</button></form></div>`}function xR(){return A.quotes.filter(n=>!We(n)&&ae(n)==="pending")}function Ul(){return Vt.state==="downloading"?`<div class="upd">⬇️ Κατεβαίνει η έκδοση ${dt(Vt.latest.version)}… ${Vt.pct}%</div>`:Vt.state!=="available"?"":`<div class="upd">⬇️ Νέα έκδοση ${dt(Vt.latest.version)}${Vt.latest.notes?": "+dt(Vt.latest.notes):""}${Vt.needApk?"<br>Χρειάζεται νέο αρχείο εγκατάστασης (APK).":""}${Vt.err?`<br><span class="bad">${dt(Vt.err)}</span>`:""}
    <button class="btn b1 sm" data-up="apply">${Vt.needApk?"Λήψη APK":"Ενημέρωση τώρα"}</button></div>`}function Pp(){const n={checking:"Έλεγχος…",none:"Έχεις την τελευταία έκδοση.",error:Vt.err}[Vt.state]||"";return`<div class="card pad ver"><div><b>TechMate ${dt(Ly)}</b>${n?`<span>${dt(n)}</span>`:""}</div><button class="btn b2 sm" data-up="check">Έλεγχος ενημέρωσης</button></div>`}function Cp(){const n=new Date,t=new Date(n.getFullYear(),n.getMonth(),1).getTime(),e=A.quotes.filter(a=>!We(a)&&["accepted","done"].includes(ae(a))&&(a.ts||0)>=t).reduce((a,l)=>a+C(l.total),0),s=A.ldocs.filter(a=>a.kind==="sale").reduce((a,l)=>a+Dy(l),0),i=hk(),r=n.getHours(),o=r<12?"Καλημέρα":r<18?"Καλησπέρα":"Καλό βράδυ";return Nt(Pt("TechMate",`${o} · ${n.toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}`,"",'<a class="ib" href="#/menu">👤</a>'),`${Cy?'<div class="upd">🧪 Δοκιμαστικά δεδομένα (preview)</div>':""}${Ul()}
    <div class="qa six"><a href="#/edit/new"><i>📝</i>Προσφορά</a><a data-hnew=""><i>📅</i>Ραντεβού</a><a data-hnew="due"><i>💶</i>Λήξη</a><a href="#/books/newdoc"><i>🧾</i>Έξοδο</a><a href="#/soon/Φωτογραφίες"><i>📷</i>Φωτο</a><a data-bcscan><i>🔍</i>Barcode</a></div>
    <div class="kpis">
      <a class="kpi" href="#/quotes"><b>${xR().length}</b><span>Σε αναμονή απάντησης</span></a>
      <div class="kpi"><b>${Ii(e)}</b><span>Δεκτές αυτόν τον μήνα</span></div>
      <a class="kpi" href="#/custs"><b>${Je().length}</b><span>Πελάτες</span></a>
      <div class="kpi"><b class="${s>0?"bad":""}">${Ii(s)}</b><span>Μου χρωστούν</span></div>
    </div>
    <div class="h">Σήμερα <a class="hl" href="#/cal">Ημερολόγιο ›</a></div>
    <div class="card">${i.today.length?i.today.map(a=>Ln(a,!1)).join(""):'<div class="empty">Τίποτα για σήμερα 🙂</div>'}</div>
    ${i.late.length?`<div class="h badh">⚠️ Εκκρεμούν από πριν (${i.late.length})</div><div class="card">${i.late.slice(0,5).map(a=>Ln(a,!0)).join("")}${i.late.length>5?`<a class="empty" href="#/cal">+${i.late.length-5} ακόμα ›</a>`:""}</div>`:""}
    ${i.dues.length?`<div class="h">💶 Λήξεις & πληρωμές (14 μέρες)</div><div class="card">${i.dues.map(a=>Ln(a,!0)).join("")}</div>`:""}`,"home")}function Sv(n){const t=ae(n),e=n.customer&&n.customer.name||"";return`<a class="row" href="#/q/${encodeURIComponent(n.id)}"><div class="av">${dt(Av(e))}</div>
  <div class="t"><b>${dt(n.subject||"(χωρίς θέμα)")}</b><span>#${dt(n.number||"—")} · ${dt(e)} · ${CR(n.ts)}</span></div>
  <div class="r"><div class="amt">${Ii(n.total)}</div><span class="pill ${DR[t]||"p-a"}">${Qo[t]||t}</span></div></a>`}function OR(){const n=A.quotes.filter(s=>!We(s)).sort((s,i)=>(i.ts||0)-(s.ts||0)),t=[["all","Όλες"],["pending","Σε αναμονή"],["accepted","Δεκτές"],["done","Ολοκληρ."],["rejected","Απορρίφθ."]],e=jt.qf==="all"?n:n.filter(s=>ae(s)===jt.qf);return Nt(Pt("Προσφορές",`${n.length} συνολικά`),`<div class="chips">${t.map(([s,i])=>`<button data-qf="${s}" class="${jt.qf===s?"on":""}">${i}</button>`).join("")}</div>
    <div class="card">${e.length?e.map(Sv).join(""):`<div class="empty">${Pe?"Καμία προσφορά":"Φόρτωση…"}</div>`}</div>`,"quotes",'<a class="fab" href="#/edit/new">＋</a>')}function MR(n){const t=A.quotes.find(o=>o.id===n);if(!t)return Nt(Pt("Προσφορά","",Ei("quotes")),`<div class="empty">${Pe?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"quotes");const e=ae(t),s=t.customer||{},i=t.lines||[],r=i.reduce((o,a)=>o+C(a.qty)*C(a.price)*(1-C(a.disc)/100),0);return Nt(Pt(`#${t.number||"—"}`,Qo[e],Ei("quotes")),`<div class="card"><div class="fld"><label>Πελάτης</label><a class="v" href="#/c/${encodeURIComponent(Rt(s.name)||"_none")}">${dt(s.name)} ›</a></div>
    <div class="fld" style="margin:0"><label>Θέμα</label><div class="v">${dt(t.subject)}</div></div></div>
    <div class="h">Κατάσταση</div>
    <div class="card pad"><div class="seg four">${Object.keys(Qo).map(o=>`<button data-st="${o}" class="${o===e?"on":""}">${Qo[o]}</button>`).join("")}</div>
    ${jt.stAsk&&jt.stAsk.id===t.id?`<div class="ask"><b>Αλλαγή σε «${dt(Jo[jt.stAsk.st])}»;</b>${iS(t,jt.stAsk.st).map(o=>`<div>• ${dt(o)}</div>`).join("")}
      <div class="actions"><button class="btn b2" data-stno>Άκυρο</button><button class="btn b1" data-stok>Ναι, αλλαγή</button></div></div>`:""}</div>
    <div class="h">Είδη (${i.length})</div>
    <div class="card">${i.map(o=>`<div class="item"><div class="t"><b>${dt(o.desc)}</b><span>${C(o.qty)} × ${xo(o.price)}${C(o.disc)?` · −${C(o.disc)}%`:""}</span></div><div class="amt">${xo(C(o.qty)*C(o.price)*(1-C(o.disc)/100))}</div></div>`).join("")||'<div class="empty">Χωρίς είδη</div>'}</div>
    <div class="card"><div class="tot"><span>Καθαρό</span><span>${xo(r)}</span></div>
    <div class="tot big"><span>Σύνολο${t.vatMode==="off"?" (χωρίς ΦΠΑ)":" με ΦΠΑ"}</span><span>${xo(t.total)}</span></div></div>${SR()}`,null,`<div class="bar"><a class="btn b2" href="#/edit/${encodeURIComponent(t.id)}">✏️ Επεξεργασία</a><button class="btn b2" data-qappt="${dt(t.id)}">📅 Ραντεβού</button><button class="btn b1" data-sdq="${dt(t.id)}">📤 PDF</button></div>`)}function LR(){const n=Rt(jt.cq),t=Je().filter(e=>!n||Rt(e.name).includes(n)).sort((e,s)=>(s.last||0)-(e.last||0));return Nt(Pt("Πελάτες",`${t.length}`),`<input class="search" id="cq" placeholder="🔍 Αναζήτηση πελάτη" value="${dt(jt.cq)}">
    <div class="card">${t.map(e=>`<a class="row" href="#/c/${encodeURIComponent(e.k)}"><div class="av">${dt(Av(e.name))}</div>
      <div class="t"><b>${dt(e.name)}</b><span>${e.quotes.length} προσφορές${e.info.phone?" · "+dt(e.info.phone):""}</span></div>
      <div class="r">${e.owed>0?`<div class="amt bad">${Ii(e.owed)}</div><span class="muted">χρωστάει</span>`:""}</div></a>`).join("")||`<div class="empty">${Pe?"Κανένας πελάτης":"Φόρτωση…"}</div>`}</div>`,"custs",'<a class="fab" href="#/ce/new">＋</a>')}function FR(n){const t=Je().find(i=>i.k===n);if(!t)return Nt(Pt("Πελάτης","",Ei("custs")),`<div class="empty">${Pe?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"custs");const e=t.info,s=e.phone.replace(/\s/g,"");return Nt(Pt(t.name,[e.address,e.phone].filter(Boolean).join(" · "),Ei("custs"),s?`<a class="ib" href="tel:${dt(s)}">📞</a>`:""),`<div class="kpis"><div class="kpi"><b>${Ii(t.won)}</b><span>Δεκτές προσφορές</span></div><div class="kpi"><b class="${t.owed>0?"bad":""}">${Ii(t.owed)}</b><span>Υπόλοιπο</span></div></div>
    <div class="actions">${s?`<a class="btn b2" href="viber://chat?number=${dt(s.startsWith("+")?s:"+30"+s)}">💬 Viber</a>`:""}
    ${e.address?`<a class="btn b2" href="https://maps.google.com/?q=${encodeURIComponent(e.address)}">🗺️ Οδηγίες</a>`:""}
    ${e.email?`<a class="btn b2" href="mailto:${dt(e.email)}">✉️ Email</a>`:""}</div>
    <div class="actions"><a class="btn b2" href="#/ce/${encodeURIComponent(t.k)}">✏️ Στοιχεία</a><button class="btn b2" data-newq="${dt(t.k)}">＋ Προσφορά</button><button class="btn b2" data-newt="${dt(t.k)}">＋ Εργασία</button></div>
    ${t.rec&&t.rec.notes?`<div class="card pad note">${dt(t.rec.notes)}</div>`:""}
    <div class="h">Προσφορές (${t.quotes.length})</div>
    <div class="card">${t.quotes.sort((i,r)=>(r.ts||0)-(i.ts||0)).map(Sv).join("")||'<div class="empty">Καμία</div>'}</div>
    ${t.mins.length?`<div class="h">Παλιές εγκαταστάσεις (${t.mins.length})</div>`:""}
    <div class="h">Φωτογραφίες δουλειάς</div><div class="card"><a class="empty" href="#/soon/Φωτογραφίες">📷 Οι φωτογραφίες δουλειάς και τα τιμολόγια ανεβαίνουν προς το παρόν από το PWA</a></div>`,"custs")}const sr=(n,t,e="")=>`<label class="f">${t}<input class="in" data-f="${n}" value="${dt(kt.v[n]||"")}" ${e}></label>`,UR=n=>`${kt.msg?`<div class="err box">${dt(kt.msg)}</div>`:""}`,qR='<div class="bar"><button class="btn b2" data-fa="cancel">Άκυρο</button><button class="btn b1" data-fa="save">💾 Αποθήκευση</button></div>';function BR(n){if(!kt||kt.kind!=="cust"||kt.arg!==n){const t=n!=="new"&&Je().find(e=>e.k===n);if(n!=="new"&&!t)return Nt(Pt("Πελάτης","",Ei("custs")),`<div class="empty">${Pe?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);kt={kind:"cust",arg:n,v:t?{name:t.name,...t.info,notes:t.rec&&t.rec.notes||""}:{name:""}}}return`${Pt(n==="new"?"Νέος πελάτης":"Στοιχεία πελάτη","",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${sr("name","Όνομα",'autocomplete="off"')}${sr("phone","Τηλέφωνο",'inputmode="tel"')}${sr("email","Email",'inputmode="email"')}${sr("afm","ΑΦΜ",'inputmode="numeric"')}${sr("address","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${dt(kt.v.notes||"")}</textarea></label></div>
    ${n!=="new"&&Rt(kt.v.name)!==n?'<div class="upd">Η αλλαγή ονόματος θα περάσει και στις προσφορές, στα παραστατικά και στις εισπράξεις του πελάτη.</div>':""}${UR()}</main>${qR}`}function jR(n){if(n==="cancel"){const e=kt.arg;return kt=null,location.replace(e==="new"?"#/custs":"#/c/"+encodeURIComponent(e))}const t=oS(kt.arg==="new"?"":kt.arg,kt.v);if(!t.ok)return kt.msg=t.msg,Tt();kt=null,location.replace("#/c/"+encodeURIComponent(t.k))}const zR=[["📄","Προσφορές","Νέα · Κατάλογος · Αποθηκευμένες · Κατάσταση · Δεκτές & παραγγελίες · Ιστορικό αλλαγών · Διαγραμμένα","#/quotes"],["📒","Λογιστικά","Σύνοψη · Παραστατικά · Πληρωμές · Υπόλοιπα","#/books/sum"],["🛡️","Εγκαταστάσεις","Εγγυήσεις · Συντηρήσεις","#/inst"],["👷","Μεροκάματα","Καταχώρηση · Πληρωμή υπαλλήλου · Υπόλοιπα","#/wages"],["📦","Αποθήκη","Απόθεμα · Κινήσεις · Λίστα παραγγελίας · Εργαλεία που λείπουν","#/stock"],["🌐","Ιστοσελίδα","Περιεχόμενο · Άρθρα · Μηνύματα — από το PWA"],["📅","Ημερολόγιο & ειδοποιήσεις","Υπενθυμίσεις · Widget · Χρώματα · Backup · Microsoft To Do","#/cset"],["⚙️","Ρυθμίσεις","Εταιρεία & PDF · Τιμές/αρίθμηση · Τράπεζες · Χρήστες ομάδας · Ειδοποιήσεις · Backup","#/set"]];function GR(){return yt()?Nt(Pt("Μενού",an?an.email:""),`<div class="card"><a class="mi" href="#/wages"><div class="ic">👷</div><div class="t"><b>Τα μεροκάματά μου</b><span>Καταχώρηση · Υπόλοιπο · Πληρωμές</span></div></a><a class="mi" href="#/stock"><div class="ic">🧰</div><div class="t"><b>Εργαλεία που λείπουν</b><span>Γράψε ό,τι χρειάζεται να παραγγελθεί</span></div></a><a class="mi" href="#/cset"><div class="ic">📅</div><div class="t"><b>Ημερολόγιο & ειδοποιήσεις</b><span>Υπενθυμίσεις · Widget · Χρώματα</span></div></a></div>${Ul()}${Pp()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu"):Nt(Pt("Μενού",an?an.email:""),`<div class="card">${zR.map(([n,t,e,s])=>`<a class="mi" href="${s||"#/soon/"+t}"><div class="ic">${n}</div><div class="t"><b>${t}${s?"":' <span class="soon">από το PWA</span>'}</b><span>${e}</span></div></a>`).join("")}</div>
    ${Ul()}${Pp()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu")}function KR(n){const t=(ct()&&ct().pubUrl||"").replace(/\/?$/,"/");return Nt(Pt(n,"",'<a class="ib" href="javascript:history.back()">←</a>'),`<div class="card"><div class="empty">🛠️ Το «${dt(n)}» γίνεται προς το παρόν από το PWA και φαίνεται αμέσως εδώ όπου χρειάζεται.${ct()&&ct().pubUrl?`<br><br><a class="btn b1" href="${dt(t)}app/" target="_blank" rel="noopener">Άνοιγμα του PWA</a>`:""}</div></div>`,null)}function Tt(){if(!an)return;const[n,t]=location.hash.replace(/^#\//,"").split("/").map(decodeURIComponent),e={home:Cp,quotes:OR,q:()=>MR(t),custs:LR,c:()=>FR(t),cal:()=>up(Pe,Pt,Nt,t),agenda:()=>up(Pe,Pt,Nt),t:()=>ek(t,Pe,Pt,Nt),cset:()=>sk(Pt,Nt),wages:()=>_k(Pt,Nt),wage:()=>cv(t,Pt,Nt,!1),stock:()=>Tk(Pt,Nt),inst:()=>Dk(Pt,Nt),set:()=>Xk(Pt,Nt),sn:()=>Bk(t,Pt,Nt),menu:GR,soon:()=>KR(t)};if(n==="edit")return kv(t);CS(),Object.assign(e,{ce:()=>BR(t),books:()=>IS(t,Pe)}),n!=="ce"&&(kt=null),n!=="t"&&KS(),n!==jt.lastR&&(vk(),TR(),Hk(),jt.lastR=n),O.openNext&&(fv(O.openNext),O.openNext=""),n!=="q"&&(jt.stAsk=null),n!=="books"&&fS();const s=scrollY,i=yt()&&!["cal","t","menu","cset","wages","stock"].includes(n)?e.cal:e[n]||Cp;if(Oe.innerHTML=i(),n==="custs"){const o=document.getElementById("cq");o.oninput=()=>{jt.cq=o.value,Tt();const a=document.getElementById("cq");a.focus(),a.setSelectionRange(a.value.length,a.value.length)}}const r=document.getElementById("out");r&&(r.onclick=()=>{confirm("Αποσύνδεση; Οι υπενθυμίσεις σε αυτό το κινητό θα σταματήσουν μέχρι να ξανασυνδεθείς.")&&(Et.clearSession(),Ra="",VA())}),scrollTo(0,s)}const WR=(n,t)=>t?location.replace(n):location.hash=n;Oe.addEventListener("change",n=>{Wk(n.target)||sR(n.target,Tt)||uk(n.target,Tt,Ie)||Ok(n.target,Tt)||SS(n.target,Tt)});Oe.addEventListener("keydown",n=>dk(n,Tt,Ie));Oe.addEventListener("touchstart",n=>ov(n,Tt),{passive:!0});Oe.addEventListener("touchend",n=>ov(n,Tt),{passive:!0});Oe.addEventListener("click",n=>{if(ck(n.target,Tt,Ie)||bv(n.target,Tt,Ie)||eR(n.target,Tt,Ie)||PR(n.target,Tt,Ie)||Nk(n.target,Tt,Ie)||TS(n.target,WR,Tt,Ie))return;const t=n.target.closest("[data-up],[data-qf],[data-st],[data-stok],[data-stno],[data-fa],[data-newq],[data-newt],[data-hnew],[data-qappt]");if(!t)return;const e=t.dataset,s=decodeURIComponent(location.hash.split("/")[2]||"");if(e.up){e.up==="apply"?ZA():Nl(!0);return}if(e.hnew!==void 0){si({kind:e.hnew,date:pt()}),location.hash="#/t/new";return}if(e.qappt){const i=A.quotes.find(o=>o.id===e.qappt),r=i&&i.customer||{};si({quoteId:e.qappt,cust:r.name||"",tel:r.phone||"",addr:r.address||"",title:"Εγκατάσταση – "+(r.name||""),date:pt()}),location.hash="#/t/new";return}if(e.qf)jt.qf=e.qf;else if(e.st){const i=A.quotes.find(r=>r.id===s);jt.stAsk=i&&ae(i)!==e.st?{id:s,st:e.st}:null}else if("stno"in e)jt.stAsk=null;else if("stok"in e){const i=rS(jt.stAsk.id,jt.stAsk.st);jt.stAsk=null,i.msg&&Ie(i.msg)}else{if(e.fa)return kt&&jR(e.fa);if(e.newq){const i=Je().find(r=>r.k===e.newq);i&&DS({name:i.name,...i.info}),location.hash="#/edit/new";return}else if(e.newt){const i=Je().find(r=>r.k===e.newt);i&&si({cust:i.name,tel:i.info.phone||"",addr:i.info.address||"",date:pt()}),location.hash="#/t/new";return}}Tt()});Oe.addEventListener("input",n=>{const t=n.target;nR(t)||lk(t,Tt)||xk(t,Tt)||AS(t,Tt)||kt&&t.dataset.f&&(kt.v[t.dataset.f]=t.type==="checkbox"?t.checked:t.value,kt.msg&&(kt.msg=""))});addEventListener("hashchange",()=>{scrollTo(0,0),location.hash.startsWith("#/cset")&&Zu(Tt),Tt()});function kv(n){const t=scrollY,e=xS(n);if(e===null){Oe.innerHTML=Nt(Pt("Προσφορά","",Ei("quotes")),`<div class="empty">${Pe?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);return}Oe.innerHTML=e,OS(Oe,()=>kv(n),s=>location.replace(s?"#/q/"+encodeURIComponent(s):"#/quotes")),scrollTo(0,t)}function Ie(n,t){let e=document.getElementById("toast");if(e||(e=document.createElement("div"),e.id="toast",document.body.appendChild(e)),e.textContent=n,t){const s=document.createElement("button");s.textContent=t.label,s.onclick=()=>{e.className="",t.fn()},e.appendChild(s)}e.className="show"+(t?" act":""),clearTimeout(Ie.t),Ie.t=setTimeout(()=>e.className="",6e3)}NA(n=>Ie(n&&n.code==="permission-denied"?"Δεν έχεις δικαίωμα για αυτή την αλλαγή. Δεν αποθηκεύτηκε.":"Η αποθήκευση απέτυχε: "+(n&&(n.code||n.message)||"άγνωστο σφάλμα")));YA(()=>{an&&!Qy()&&!kt&&!Hy()&&!sv()&&!av()&&!Tv()&&!wv()&&!pv()&&Tt()});XA();Cy&&(window.__tm={data:A,hitFind:_v});let Ra="";function HR(){const n=PA();if(!Ps||!n||!Object.keys(A.st).length)return;const t=Mn()||{},e={uid:n.uid,email:n.email||"",role:yt()?"team":"owner",empId:xe(),name:t.name||"",rt:n.refreshToken||"",apiKey:Dl.apiKey,project:Dl.projectId},s=JSON.stringify(e);s!==Ra&&(Ra=s,Et.setSession(e))}function Rv(n){!n||!an||(n.task?location.hash="#/t/"+encodeURIComponent(n.task):n.isNew&&(si({date:pt()}),location.hash="#/t/new"))}tc("open",Rv);tc("toast",n=>n&&n.text&&Ie(n.text));tc("ms",()=>{location.hash.startsWith("#/cset")&&Zu(Tt)});let Dp=!1,ql=!1;RA(()=>{Pe=!0,HR(),fk(),!ql&&A.tasks.length&&A.quotes.length&&(ql=!0,setTimeout(()=>ik(Pe),4e3)),!(Qy()||kt||Hy()||sv()||av()||Tv()||wv()||pv())&&Tt()});document.addEventListener("visibilitychange",()=>{!document.hidden&&an&&(ql=!1,Tt())});Lr().then(()=>{CA(n=>{if(an=n,!n){Ra="",Pv();return}location.hash.startsWith("#/cset")&&Zu(Tt),Tt(),Dp||(Dp=!0,Et.takeLaunch().then(Rv))})});function Pv(n="",t=""){Oe.innerHTML=NR(n);const e=document.getElementById("lf");e.e.value=t,document.getElementById("sp").onchange=s=>{e.p.type=s.target.checked?"text":"password"},document.getElementById("lf").onsubmit=s=>{s.preventDefault();const i=s.target;$A(i.e.value.trim(),i.p.value).catch(r=>{const o=r&&r.code||"",l=["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(o)?"Λάθος email ή κωδικός.":o==="auth/network-request-failed"?"Δεν υπάρχει σύνδεση στο internet.":o==="auth/too-many-requests"?"Πολλές προσπάθειες. Δοκίμασε ξανά σε λίγα λεπτά.":"Η σύνδεση μπλοκαρίστηκε.";Pv(l+" ["+(o||r&&r.message||"άγνωστο")+"]",i.e.value)})}}export{ep as A,ju as W,wn as _};
