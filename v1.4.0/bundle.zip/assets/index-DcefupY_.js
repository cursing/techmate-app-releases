(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&s(a)}).observe(document,{childList:!0,subtree:!0});function t(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(i){if(i.ep)return;i.ep=!0;const r=t(i);fetch(i.href,r)}})();var mf={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gm=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let i=n.charCodeAt(s);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++s)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},A_=function(n){const e=[];let t=0,s=0;for(;t<n.length;){const i=n[t++];if(i<128)e[s++]=String.fromCharCode(i);else if(i>191&&i<224){const r=n[t++];e[s++]=String.fromCharCode((i&31)<<6|r&63)}else if(i>239&&i<365){const r=n[t++],a=n[t++],o=n[t++],l=((i&7)<<18|(r&63)<<12|(a&63)<<6|o&63)-65536;e[s++]=String.fromCharCode(55296+(l>>10)),e[s++]=String.fromCharCode(56320+(l&1023))}else{const r=n[t++],a=n[t++];e[s++]=String.fromCharCode((i&15)<<12|(r&63)<<6|a&63)}}return e.join("")},Km={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let i=0;i<n.length;i+=3){const r=n[i],a=i+1<n.length,o=a?n[i+1]:0,l=i+2<n.length,u=l?n[i+2]:0,h=r>>2,p=(r&3)<<4|o>>4;let m=(o&15)<<2|u>>6,w=u&63;l||(w=64,a||(m=64)),s.push(t[h],t[p],t[m],t[w])}return s.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(Gm(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):A_(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let i=0;i<n.length;){const r=t[n.charAt(i++)],o=i<n.length?t[n.charAt(i)]:0;++i;const u=i<n.length?t[n.charAt(i)]:64;++i;const p=i<n.length?t[n.charAt(i)]:64;if(++i,r==null||o==null||u==null||p==null)throw new S_;const m=r<<2|o>>4;if(s.push(m),u!==64){const w=o<<4&240|u>>2;if(s.push(w),p!==64){const E=u<<6&192|p;s.push(E)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class S_ extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const k_=function(n){const e=Gm(n);return Km.encodeByteArray(e,!0)},Hm=function(n){return k_(n).replace(/\./g,"")},Qm=function(n){try{return Km.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function R_(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P_=()=>R_().__FIREBASE_DEFAULTS__,C_=()=>{if(typeof process>"u"||typeof mf>"u")return;const n=mf.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},$_=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&Qm(n[1]);return e&&JSON.parse(e)},lc=()=>{try{return P_()||C_()||$_()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},D_=n=>{var e,t;return(t=(e=lc())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},Jm=()=>{var n;return(n=lc())===null||n===void 0?void 0:n.config},Ym=n=>{var e;return(e=lc())===null||e===void 0?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class x_{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Je(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function N_(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Je())}function V_(){var n;const e=(n=lc())===null||n===void 0?void 0:n.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function O_(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function M_(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function L_(){const n=Je();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function Xm(){return!V_()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function Zm(){try{return typeof indexedDB=="object"}catch{return!1}}function F_(){return new Promise((n,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(s);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(s),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var r;e(((r=i.error)===null||r===void 0?void 0:r.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const U_="FirebaseError";class kn extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=U_,Object.setPrototypeOf(this,kn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,ma.prototype.create)}}class ma{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},i=`${this.service}/${e}`,r=this.errors[e],a=r?q_(r,s):"Error",o=`${this.serviceName}: ${a} (${i}).`;return new kn(i,o,s)}}function q_(n,e){return n.replace(B_,(t,s)=>{const i=e[s];return i!=null?String(i):`<${s}?>`})}const B_=/\{\$([^}]+)}/g;function j_(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function Wr(n,e){if(n===e)return!0;const t=Object.keys(n),s=Object.keys(e);for(const i of t){if(!s.includes(i))return!1;const r=n[i],a=e[i];if(gf(r)&&gf(a)){if(!Wr(r,a))return!1}else if(r!==a)return!1}for(const i of s)if(!t.includes(i))return!1;return!0}function gf(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ga(n){const e=[];for(const[t,s]of Object.entries(n))Array.isArray(s)?s.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function Ar(n){const e={};return n.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[i,r]=s.split("=");e[decodeURIComponent(i)]=decodeURIComponent(r)}}),e}function Sr(n){const e=n.indexOf("?");if(!e)return"";const t=n.indexOf("#",e);return n.substring(e,t>0?t:void 0)}function W_(n,e){const t=new z_(n,e);return t.subscribe.bind(t)}class z_{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let i;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");G_(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:s},i.next===void 0&&(i.next=dl),i.error===void 0&&(i.error=dl),i.complete===void 0&&(i.complete=dl);const r=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),r}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function G_(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function dl(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function et(n){return n&&n._delegate?n._delegate:n}class Ds{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _s="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class K_{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new x_;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&s.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const s=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),i=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(r){if(i)return null;throw r}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Q_(e))try{this.getOrInitializeService({instanceIdentifier:_s})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const r=this.getOrInitializeService({instanceIdentifier:i});s.resolve(r)}catch{}}}}clearInstance(e=_s){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=_s){return this.instances.has(e)}getOptions(e=_s){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[r,a]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(r);s===o&&a.resolve(i)}return i}onInit(e,t){var s;const i=this.normalizeInstanceIdentifier(t),r=(s=this.onInitCallbacks.get(i))!==null&&s!==void 0?s:new Set;r.add(e),this.onInitCallbacks.set(i,r);const a=this.instances.get(i);return a&&e(a,i),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const i of s)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:H_(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=_s){return this.component?this.component.multipleInstances?e:_s:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function H_(n){return n===_s?void 0:n}function Q_(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J_{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new K_(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var de;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(de||(de={}));const Y_={debug:de.DEBUG,verbose:de.VERBOSE,info:de.INFO,warn:de.WARN,error:de.ERROR,silent:de.SILENT},X_=de.INFO,Z_={[de.DEBUG]:"log",[de.VERBOSE]:"log",[de.INFO]:"info",[de.WARN]:"warn",[de.ERROR]:"error"},ew=(n,e,...t)=>{if(e<n.logLevel)return;const s=new Date().toISOString(),i=Z_[e];if(i)console[i](`[${s}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Pu{constructor(e){this.name=e,this._logLevel=X_,this._logHandler=ew,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in de))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Y_[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,de.DEBUG,...e),this._logHandler(this,de.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,de.VERBOSE,...e),this._logHandler(this,de.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,de.INFO,...e),this._logHandler(this,de.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,de.WARN,...e),this._logHandler(this,de.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,de.ERROR,...e),this._logHandler(this,de.ERROR,...e)}}const tw=(n,e)=>e.some(t=>n instanceof t);let yf,vf;function nw(){return yf||(yf=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function sw(){return vf||(vf=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const eg=new WeakMap,Ll=new WeakMap,tg=new WeakMap,hl=new WeakMap,Cu=new WeakMap;function iw(n){const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("success",r),n.removeEventListener("error",a)},r=()=>{t(Qn(n.result)),i()},a=()=>{s(n.error),i()};n.addEventListener("success",r),n.addEventListener("error",a)});return e.then(t=>{t instanceof IDBCursor&&eg.set(t,n)}).catch(()=>{}),Cu.set(e,n),e}function rw(n){if(Ll.has(n))return;const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("complete",r),n.removeEventListener("error",a),n.removeEventListener("abort",a)},r=()=>{t(),i()},a=()=>{s(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",r),n.addEventListener("error",a),n.addEventListener("abort",a)});Ll.set(n,e)}let Fl={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return Ll.get(n);if(e==="objectStoreNames")return n.objectStoreNames||tg.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Qn(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function aw(n){Fl=n(Fl)}function ow(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=n.call(fl(this),e,...t);return tg.set(s,e.sort?e.sort():[e]),Qn(s)}:sw().includes(n)?function(...e){return n.apply(fl(this),e),Qn(eg.get(this))}:function(...e){return Qn(n.apply(fl(this),e))}}function cw(n){return typeof n=="function"?ow(n):(n instanceof IDBTransaction&&rw(n),tw(n,nw())?new Proxy(n,Fl):n)}function Qn(n){if(n instanceof IDBRequest)return iw(n);if(hl.has(n))return hl.get(n);const e=cw(n);return e!==n&&(hl.set(n,e),Cu.set(e,n)),e}const fl=n=>Cu.get(n);function lw(n,e,{blocked:t,upgrade:s,blocking:i,terminated:r}={}){const a=indexedDB.open(n,e),o=Qn(a);return s&&a.addEventListener("upgradeneeded",l=>{s(Qn(a.result),l.oldVersion,l.newVersion,Qn(a.transaction),l)}),t&&a.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),o.then(l=>{r&&l.addEventListener("close",()=>r()),i&&l.addEventListener("versionchange",u=>i(u.oldVersion,u.newVersion,u))}).catch(()=>{}),o}const uw=["get","getKey","getAll","getAllKeys","count"],dw=["put","add","delete","clear"],pl=new Map;function bf(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(pl.get(e))return pl.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,i=dw.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(i||uw.includes(t)))return;const r=async function(a,...o){const l=this.transaction(a,i?"readwrite":"readonly");let u=l.store;return s&&(u=u.index(o.shift())),(await Promise.all([u[t](...o),i&&l.done]))[0]};return pl.set(e,r),r}aw(n=>({...n,get:(e,t,s)=>bf(e,t)||n.get(e,t,s),has:(e,t)=>!!bf(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hw{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(fw(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function fw(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Ul="@firebase/app",_f="0.10.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xs=new Pu("@firebase/app"),pw="@firebase/app-compat",mw="@firebase/analytics-compat",gw="@firebase/analytics",yw="@firebase/app-check-compat",vw="@firebase/app-check",bw="@firebase/auth",_w="@firebase/auth-compat",ww="@firebase/database",Iw="@firebase/database-compat",Ew="@firebase/functions",Tw="@firebase/functions-compat",Aw="@firebase/installations",Sw="@firebase/installations-compat",kw="@firebase/messaging",Rw="@firebase/messaging-compat",Pw="@firebase/performance",Cw="@firebase/performance-compat",$w="@firebase/remote-config",Dw="@firebase/remote-config-compat",xw="@firebase/storage",Nw="@firebase/storage-compat",Vw="@firebase/firestore",Ow="@firebase/vertexai-preview",Mw="@firebase/firestore-compat",Lw="firebase",Fw="10.12.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ql="[DEFAULT]",Uw={[Ul]:"fire-core",[pw]:"fire-core-compat",[gw]:"fire-analytics",[mw]:"fire-analytics-compat",[vw]:"fire-app-check",[yw]:"fire-app-check-compat",[bw]:"fire-auth",[_w]:"fire-auth-compat",[ww]:"fire-rtdb",[Iw]:"fire-rtdb-compat",[Ew]:"fire-fn",[Tw]:"fire-fn-compat",[Aw]:"fire-iid",[Sw]:"fire-iid-compat",[kw]:"fire-fcm",[Rw]:"fire-fcm-compat",[Pw]:"fire-perf",[Cw]:"fire-perf-compat",[$w]:"fire-rc",[Dw]:"fire-rc-compat",[xw]:"fire-gcs",[Nw]:"fire-gcs-compat",[Vw]:"fire-fst",[Mw]:"fire-fst-compat",[Ow]:"fire-vertex","fire-js":"fire-js",[Lw]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Po=new Map,qw=new Map,Bl=new Map;function wf(n,e){try{n.container.addComponent(e)}catch(t){xs.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function Ei(n){const e=n.name;if(Bl.has(e))return xs.debug(`There were multiple attempts to register component ${e}.`),!1;Bl.set(e,n);for(const t of Po.values())wf(t,n);for(const t of qw.values())wf(t,n);return!0}function $u(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function vn(n){return n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bw={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Jn=new ma("app","Firebase",Bw);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jw{constructor(e,t,s){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new Ds("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Jn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wi=Fw;function ng(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const s=Object.assign({name:ql,automaticDataCollectionEnabled:!1},e),i=s.name;if(typeof i!="string"||!i)throw Jn.create("bad-app-name",{appName:String(i)});if(t||(t=Jm()),!t)throw Jn.create("no-options");const r=Po.get(i);if(r){if(Wr(t,r.options)&&Wr(s,r.config))return r;throw Jn.create("duplicate-app",{appName:i})}const a=new J_(i);for(const l of Bl.values())a.addComponent(l);const o=new jw(t,s,a);return Po.set(i,o),o}function Ww(n=ql){const e=Po.get(n);if(!e&&n===ql&&Jm())return ng();if(!e)throw Jn.create("no-app",{appName:n});return e}function Yn(n,e,t){var s;let i=(s=Uw[n])!==null&&s!==void 0?s:n;t&&(i+=`-${t}`);const r=i.match(/\s|\//),a=e.match(/\s|\//);if(r||a){const o=[`Unable to register library "${i}" with version "${e}":`];r&&o.push(`library name "${i}" contains illegal characters (whitespace or "/")`),r&&a&&o.push("and"),a&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),xs.warn(o.join(" "));return}Ei(new Ds(`${i}-version`,()=>({library:i,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zw="firebase-heartbeat-database",Gw=1,zr="firebase-heartbeat-store";let ml=null;function sg(){return ml||(ml=lw(zw,Gw,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(zr)}catch(t){console.warn(t)}}}}).catch(n=>{throw Jn.create("idb-open",{originalErrorMessage:n.message})})),ml}async function Kw(n){try{const t=(await sg()).transaction(zr),s=await t.objectStore(zr).get(ig(n));return await t.done,s}catch(e){if(e instanceof kn)xs.warn(e.message);else{const t=Jn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});xs.warn(t.message)}}}async function If(n,e){try{const s=(await sg()).transaction(zr,"readwrite");await s.objectStore(zr).put(e,ig(n)),await s.done}catch(t){if(t instanceof kn)xs.warn(t.message);else{const s=Jn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});xs.warn(s.message)}}}function ig(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hw=1024,Qw=30*24*60*60*1e3;class Jw{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new Xw(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=Ef();if(!(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(a=>a.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:i}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(a=>{const o=new Date(a.date).valueOf();return Date.now()-o<=Qw}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var e;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=Ef(),{heartbeatsToSend:s,unsentEntries:i}=Yw(this._heartbeatsCache.heartbeats),r=Hm(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),r}}function Ef(){return new Date().toISOString().substring(0,10)}function Yw(n,e=Hw){const t=[];let s=n.slice();for(const i of n){const r=t.find(a=>a.agent===i.agent);if(r){if(r.dates.push(i.date),Tf(t)>e){r.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),Tf(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class Xw{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Zm()?F_().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await Kw(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return If(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return If(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}else return}}function Tf(n){return Hm(JSON.stringify({version:2,heartbeats:n})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zw(n){Ei(new Ds("platform-logger",e=>new hw(e),"PRIVATE")),Ei(new Ds("heartbeat",e=>new Jw(e),"PRIVATE")),Yn(Ul,_f,n),Yn(Ul,_f,"esm2017"),Yn("fire-js","")}Zw("");var eI="firebase",tI="10.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Yn(eI,tI,"app");function Du(n,e){var t={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&e.indexOf(s)<0&&(t[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var i=0,s=Object.getOwnPropertySymbols(n);i<s.length;i++)e.indexOf(s[i])<0&&Object.prototype.propertyIsEnumerable.call(n,s[i])&&(t[s[i]]=n[s[i]]);return t}function rg(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const nI=rg,ag=new ma("auth","Firebase",rg());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Co=new Pu("@firebase/auth");function sI(n,...e){Co.logLevel<=de.WARN&&Co.warn(`Auth (${Wi}): ${n}`,...e)}function co(n,...e){Co.logLevel<=de.ERROR&&Co.error(`Auth (${Wi}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qt(n,...e){throw xu(n,...e)}function rn(n,...e){return xu(n,...e)}function og(n,e,t){const s=Object.assign(Object.assign({},nI()),{[e]:t});return new ma("auth","Firebase",s).create(e,{appName:n.name})}function Xn(n){return og(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function xu(n,...e){if(typeof n!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=n.name),n._errorFactory.create(t,...s)}return ag.create(n,...e)}function te(n,e,...t){if(!n)throw xu(e,...t)}function bn(n){const e="INTERNAL ASSERTION FAILED: "+n;throw co(e),new Error(e)}function Tn(n,e){n||bn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jl(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function iI(){return Af()==="http:"||Af()==="https:"}function Af(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rI(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(iI()||O_()||"connection"in navigator)?navigator.onLine:!0}function aI(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ya{constructor(e,t){this.shortDelay=e,this.longDelay=t,Tn(t>e,"Short delay should be less than long delay!"),this.isMobile=N_()||M_()}get(){return rI()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nu(n,e){Tn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cg{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;bn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;bn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;bn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oI={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cI=new ya(3e4,6e4);function Ws(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function us(n,e,t,s,i={}){return lg(n,i,async()=>{let r={},a={};s&&(e==="GET"?a=s:r={body:JSON.stringify(s)});const o=ga(Object.assign({key:n.config.apiKey},a)).slice(1),l=await n._getAdditionalHeaders();return l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode),cg.fetch()(ug(n,n.config.apiHost,t,o),Object.assign({method:e,headers:l,referrerPolicy:"no-referrer"},r))})}async function lg(n,e,t){n._canInitEmulator=!1;const s=Object.assign(Object.assign({},oI),e);try{const i=new uI(n),r=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const a=await r.json();if("needConfirmation"in a)throw Qa(n,"account-exists-with-different-credential",a);if(r.ok&&!("errorMessage"in a))return a;{const o=r.ok?a.errorMessage:a.error.message,[l,u]=o.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw Qa(n,"credential-already-in-use",a);if(l==="EMAIL_EXISTS")throw Qa(n,"email-already-in-use",a);if(l==="USER_DISABLED")throw Qa(n,"user-disabled",a);const h=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw og(n,h,u);Qt(n,h)}}catch(i){if(i instanceof kn)throw i;Qt(n,"network-request-failed",{message:String(i)})}}async function uc(n,e,t,s,i={}){const r=await us(n,e,t,s,i);return"mfaPendingCredential"in r&&Qt(n,"multi-factor-auth-required",{_serverResponse:r}),r}function ug(n,e,t,s){const i=`${e}${t}?${s}`;return n.config.emulator?Nu(n.config,i):`${n.config.apiScheme}://${i}`}function lI(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class uI{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(rn(this.auth,"network-request-failed")),cI.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function Qa(n,e,t){const s={appName:n.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const i=rn(n,e,s);return i.customData._tokenResponse=t,i}function Sf(n){return n!==void 0&&n.enterprise!==void 0}class dI{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return lI(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}}async function hI(n,e){return us(n,"GET","/v2/recaptchaConfig",Ws(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fI(n,e){return us(n,"POST","/v1/accounts:delete",e)}async function dg(n,e){return us(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dr(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function pI(n,e=!1){const t=et(n),s=await t.getIdToken(e),i=Vu(s);te(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const r=typeof i.firebase=="object"?i.firebase:void 0,a=r==null?void 0:r.sign_in_provider;return{claims:i,token:s,authTime:Dr(gl(i.auth_time)),issuedAtTime:Dr(gl(i.iat)),expirationTime:Dr(gl(i.exp)),signInProvider:a||null,signInSecondFactor:(r==null?void 0:r.sign_in_second_factor)||null}}function gl(n){return Number(n)*1e3}function Vu(n){const[e,t,s]=n.split(".");if(e===void 0||t===void 0||s===void 0)return co("JWT malformed, contained fewer than 3 sections"),null;try{const i=Qm(t);return i?JSON.parse(i):(co("Failed to decode base64 JWT payload"),null)}catch(i){return co("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function kf(n){const e=Vu(n);return te(e,"internal-error"),te(typeof e.exp<"u","internal-error"),te(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Gr(n,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof kn&&mI(s)&&n.auth.currentUser===n&&await n.auth.signOut(),s}}function mI({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gI{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const s=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),s}else{this.errorBackoff=3e4;const i=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wl{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=Dr(this.lastLoginAt),this.creationTime=Dr(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $o(n){var e;const t=n.auth,s=await n.getIdToken(),i=await Gr(n,dg(t,{idToken:s}));te(i==null?void 0:i.users.length,t,"internal-error");const r=i.users[0];n._notifyReloadListener(r);const a=!((e=r.providerUserInfo)===null||e===void 0)&&e.length?hg(r.providerUserInfo):[],o=vI(n.providerData,a),l=n.isAnonymous,u=!(n.email&&r.passwordHash)&&!(o!=null&&o.length),h=l?u:!1,p={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:o,metadata:new Wl(r.createdAt,r.lastLoginAt),isAnonymous:h};Object.assign(n,p)}async function yI(n){const e=et(n);await $o(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function vI(n,e){return[...n.filter(s=>!e.some(i=>i.providerId===s.providerId)),...e]}function hg(n){return n.map(e=>{var{providerId:t}=e,s=Du(e,["providerId"]);return{providerId:t,uid:s.rawId||"",displayName:s.displayName||null,email:s.email||null,phoneNumber:s.phoneNumber||null,photoURL:s.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function bI(n,e){const t=await lg(n,{},async()=>{const s=ga({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:r}=n.config,a=ug(n,i,"/v1/token",`key=${r}`),o=await n._getAdditionalHeaders();return o["Content-Type"]="application/x-www-form-urlencoded",cg.fetch()(a,{method:"POST",headers:o,body:s})});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function _I(n,e){return us(n,"POST","/v2/accounts:revokeToken",Ws(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gi{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){te(e.idToken,"internal-error"),te(typeof e.idToken<"u","internal-error"),te(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):kf(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){te(e.length!==0,"internal-error");const t=kf(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(te(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:i,expiresIn:r}=await bI(e,t);this.updateTokensAndExpiration(s,i,Number(r))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:i,expirationTime:r}=t,a=new gi;return s&&(te(typeof s=="string","internal-error",{appName:e}),a.refreshToken=s),i&&(te(typeof i=="string","internal-error",{appName:e}),a.accessToken=i),r&&(te(typeof r=="number","internal-error",{appName:e}),a.expirationTime=r),a}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new gi,this.toJSON())}_performRefresh(){return bn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vn(n,e){te(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class _n{constructor(e){var{uid:t,auth:s,stsTokenManager:i}=e,r=Du(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new gI(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=s,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new Wl(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(e){const t=await Gr(this,this.stsTokenManager.getToken(this.auth,e));return te(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return pI(this,e)}reload(){return yI(this)}_assign(e){this!==e&&(te(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new _n(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){te(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await $o(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(vn(this.auth.app))return Promise.reject(Xn(this.auth));const e=await this.getIdToken();return await Gr(this,fI(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var s,i,r,a,o,l,u,h;const p=(s=t.displayName)!==null&&s!==void 0?s:void 0,m=(i=t.email)!==null&&i!==void 0?i:void 0,w=(r=t.phoneNumber)!==null&&r!==void 0?r:void 0,E=(a=t.photoURL)!==null&&a!==void 0?a:void 0,x=(o=t.tenantId)!==null&&o!==void 0?o:void 0,C=(l=t._redirectEventId)!==null&&l!==void 0?l:void 0,j=(u=t.createdAt)!==null&&u!==void 0?u:void 0,J=(h=t.lastLoginAt)!==null&&h!==void 0?h:void 0,{uid:H,emailVerified:ae,isAnonymous:O,providerData:U,stsTokenManager:_}=t;te(H&&_,e,"internal-error");const y=gi.fromJSON(this.name,_);te(typeof H=="string",e,"internal-error"),Vn(p,e.name),Vn(m,e.name),te(typeof ae=="boolean",e,"internal-error"),te(typeof O=="boolean",e,"internal-error"),Vn(w,e.name),Vn(E,e.name),Vn(x,e.name),Vn(C,e.name),Vn(j,e.name),Vn(J,e.name);const v=new _n({uid:H,auth:e,email:m,emailVerified:ae,displayName:p,isAnonymous:O,photoURL:E,phoneNumber:w,tenantId:x,stsTokenManager:y,createdAt:j,lastLoginAt:J});return U&&Array.isArray(U)&&(v.providerData=U.map(I=>Object.assign({},I))),C&&(v._redirectEventId=C),v}static async _fromIdTokenResponse(e,t,s=!1){const i=new gi;i.updateFromServerResponse(t);const r=new _n({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:s});return await $o(r),r}static async _fromGetAccountInfoResponse(e,t,s){const i=t.users[0];te(i.localId!==void 0,"internal-error");const r=i.providerUserInfo!==void 0?hg(i.providerUserInfo):[],a=!(i.email&&i.passwordHash)&&!(r!=null&&r.length),o=new gi;o.updateFromIdToken(s);const l=new _n({uid:i.localId,auth:e,stsTokenManager:o,isAnonymous:a}),u={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:r,metadata:new Wl(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(r!=null&&r.length)};return Object.assign(l,u),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rf=new Map;function wn(n){Tn(n instanceof Function,"Expected a class definition");let e=Rf.get(n);return e?(Tn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,Rf.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fg{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}fg.type="NONE";const Pf=fg;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lo(n,e,t){return`firebase:${n}:${e}:${t}`}class yi{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:i,name:r}=this.auth;this.fullUserKey=lo(this.userKey,i.apiKey,r),this.fullPersistenceKey=lo("persistence",i.apiKey,r),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?_n._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new yi(wn(Pf),e,s);const i=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let r=i[0]||wn(Pf);const a=lo(s,e.config.apiKey,e.name);let o=null;for(const u of t)try{const h=await u._get(a);if(h){const p=_n._fromJSON(e,h);u!==r&&(o=p),r=u;break}}catch{}const l=i.filter(u=>u._shouldAllowMigration);return!r._shouldAllowMigration||!l.length?new yi(r,e,s):(r=l[0],o&&await r._set(a,o.toJSON()),await Promise.all(t.map(async u=>{if(u!==r)try{await u._remove(a)}catch{}})),new yi(r,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cf(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(gg(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(pg(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(vg(e))return"Blackberry";if(bg(e))return"Webos";if(Ou(e))return"Safari";if((e.includes("chrome/")||mg(e))&&!e.includes("edge/"))return"Chrome";if(yg(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=n.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function pg(n=Je()){return/firefox\//i.test(n)}function Ou(n=Je()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function mg(n=Je()){return/crios\//i.test(n)}function gg(n=Je()){return/iemobile/i.test(n)}function yg(n=Je()){return/android/i.test(n)}function vg(n=Je()){return/blackberry/i.test(n)}function bg(n=Je()){return/webos/i.test(n)}function dc(n=Je()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function wI(n=Je()){var e;return dc(n)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function II(){return L_()&&document.documentMode===10}function _g(n=Je()){return dc(n)||yg(n)||bg(n)||vg(n)||/windows phone/i.test(n)||gg(n)}function EI(){try{return!!(window&&window!==window.top)}catch{return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wg(n,e=[]){let t;switch(n){case"Browser":t=Cf(Je());break;case"Worker":t=`${Cf(Je())}-${n}`;break;default:t=n}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Wi}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TI{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=r=>new Promise((a,o)=>{try{const l=e(r);a(l)}catch(l){o(l)}});s.onAbort=t,this.queue.push(s);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function AI(n,e={}){return us(n,"GET","/v2/passwordPolicy",Ws(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const SI=6;class kI{constructor(e){var t,s,i,r;const a=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=a.minPasswordLength)!==null&&t!==void 0?t:SI,a.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=a.maxPasswordLength),a.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=a.containsLowercaseCharacter),a.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=a.containsUppercaseCharacter),a.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=a.containsNumericCharacter),a.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=a.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(s=e.allowedNonAlphanumericCharacters)===null||s===void 0?void 0:s.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(r=e.forceUpgradeOnSignin)!==null&&r!==void 0?r:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,s,i,r,a,o;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,l),this.validatePasswordCharacterOptions(e,l),l.isValid&&(l.isValid=(t=l.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),l.isValid&&(l.isValid=(s=l.meetsMaxPasswordLength)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(i=l.containsLowercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(r=l.containsUppercaseLetter)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(a=l.containsNumericCharacter)!==null&&a!==void 0?a:!0),l.isValid&&(l.isValid=(o=l.containsNonAlphanumericCharacter)!==null&&o!==void 0?o:!0),l}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let i=0;i<e.length;i++)s=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,i,r){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RI{constructor(e,t,s,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new $f(this),this.idTokenSubscription=new $f(this),this.beforeStateQueue=new TI(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=ag,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=wn(t)),this._initializationPromise=this.queue(async()=>{var s,i;if(!this._deleted&&(this.persistenceManager=await yi.create(this,e),!this._deleted)){if(!((s=this._popupRedirectResolver)===null||s===void 0)&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((i=this.currentUser)===null||i===void 0?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await dg(this,{idToken:e}),s=await _n._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(vn(this.app)){const a=this.app.settings.authIdToken;return a?new Promise(o=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(a).then(o,o))}):this.directlySetCurrentUser(null)}const s=await this.assertedPersistence.getCurrentUser();let i=s,r=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const a=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,o=i==null?void 0:i._redirectEventId,l=await this.tryRedirectSignIn(e);(!a||a===o)&&(l!=null&&l.user)&&(i=l.user,r=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(i)}catch(a){i=s,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(a))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return te(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await $o(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=aI()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(vn(this.app))return Promise.reject(Xn(this));const t=e?et(e):null;return t&&te(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&te(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return vn(this.app)?Promise.reject(Xn(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return vn(this.app)?Promise.reject(Xn(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(wn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await AI(this),t=new kI(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new ma("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await _I(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&wn(e)||this._popupRedirectResolver;te(t,this,"argument-error"),this.redirectPersistenceManager=await yi.create(this,[wn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)===null||s===void 0?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const s=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==s&&(this.lastNotifiedUid=s,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,i){if(this._deleted)return()=>{};const r=typeof t=="function"?t:t.next.bind(t);let a=!1;const o=this._isInitialized?Promise.resolve():this._initializationPromise;if(te(o,this,"internal-error"),o.then(()=>{a||r(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,s,i);return()=>{a=!0,l()}}else{const l=e.addObserver(t);return()=>{a=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return te(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=wg(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const s=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());s&&(t["X-Firebase-Client"]=s);const i=await this._getAppCheckToken();return i&&(t["X-Firebase-AppCheck"]=i),t}async _getAppCheckToken(){var e;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&sI(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function zi(n){return et(n)}class $f{constructor(e){this.auth=e,this.observer=null,this.addObserver=W_(t=>this.observer=t)}get next(){return te(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let hc={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function PI(n){hc=n}function Ig(n){return hc.loadJS(n)}function CI(){return hc.recaptchaEnterpriseScript}function $I(){return hc.gapiScript}function DI(n){return`__${n}${Math.floor(Math.random()*1e6)}`}const xI="recaptcha-enterprise",NI="NO_RECAPTCHA";class VI{constructor(e){this.type=xI,this.auth=zi(e)}async verify(e="verify",t=!1){async function s(r){if(!t){if(r.tenantId==null&&r._agentRecaptchaConfig!=null)return r._agentRecaptchaConfig.siteKey;if(r.tenantId!=null&&r._tenantRecaptchaConfigs[r.tenantId]!==void 0)return r._tenantRecaptchaConfigs[r.tenantId].siteKey}return new Promise(async(a,o)=>{hI(r,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)o(new Error("recaptcha Enterprise site key undefined"));else{const u=new dI(l);return r.tenantId==null?r._agentRecaptchaConfig=u:r._tenantRecaptchaConfigs[r.tenantId]=u,a(u.siteKey)}}).catch(l=>{o(l)})})}function i(r,a,o){const l=window.grecaptcha;Sf(l)?l.enterprise.ready(()=>{l.enterprise.execute(r,{action:e}).then(u=>{a(u)}).catch(()=>{a(NI)})}):o(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((r,a)=>{s(this.auth).then(o=>{if(!t&&Sf(window.grecaptcha))i(o,r,a);else{if(typeof window>"u"){a(new Error("RecaptchaVerifier is only supported in browser"));return}let l=CI();l.length!==0&&(l+=o),Ig(l).then(()=>{i(o,r,a)}).catch(u=>{a(u)})}}).catch(o=>{a(o)})})}}async function Df(n,e,t,s=!1){const i=new VI(n);let r;try{r=await i.verify(t)}catch{r=await i.verify(t,!0)}const a=Object.assign({},e);return s?Object.assign(a,{captchaResp:r}):Object.assign(a,{captchaResponse:r}),Object.assign(a,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(a,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),a}async function xf(n,e,t,s){var i;if(!((i=n._getRecaptchaConfig())===null||i===void 0)&&i.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const r=await Df(n,e,t,t==="getOobCode");return s(n,r)}else return s(n,e).catch(async r=>{if(r.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const a=await Df(n,e,t,t==="getOobCode");return s(n,a)}else return Promise.reject(r)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function OI(n,e){const t=$u(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),r=t.getOptions();if(Wr(r,e??{}))return i;Qt(i,"already-initialized")}return t.initialize({options:e})}function MI(n,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(wn);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function LI(n,e,t){const s=zi(n);te(s._canInitEmulator,s,"emulator-config-failed"),te(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const i=!1,r=Eg(e),{host:a,port:o}=FI(e),l=o===null?"":`:${o}`;s.config.emulator={url:`${r}//${a}${l}/`},s.settings.appVerificationDisabledForTesting=!0,s.emulatorConfig=Object.freeze({host:a,port:o,protocol:r.replace(":",""),options:Object.freeze({disableWarnings:i})}),UI()}function Eg(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function FI(n){const e=Eg(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(s);if(i){const r=i[1];return{host:r,port:Nf(s.substr(r.length+1))}}else{const[r,a]=s.split(":");return{host:r,port:Nf(a)}}}function Nf(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function UI(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mu{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return bn("not implemented")}_getIdTokenResponse(e){return bn("not implemented")}_linkToIdToken(e,t){return bn("not implemented")}_getReauthenticationResolver(e){return bn("not implemented")}}async function qI(n,e){return us(n,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function BI(n,e){return uc(n,"POST","/v1/accounts:signInWithPassword",Ws(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jI(n,e){return uc(n,"POST","/v1/accounts:signInWithEmailLink",Ws(n,e))}async function WI(n,e){return uc(n,"POST","/v1/accounts:signInWithEmailLink",Ws(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kr extends Mu{constructor(e,t,s,i=null){super("password",s),this._email=e,this._password=t,this._tenantId=i}static _fromEmailAndPassword(e,t){return new Kr(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new Kr(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return xf(e,t,"signInWithPassword",BI);case"emailLink":return jI(e,{email:this._email,oobCode:this._password});default:Qt(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return xf(e,s,"signUpPassword",qI);case"emailLink":return WI(e,{idToken:t,email:this._email,oobCode:this._password});default:Qt(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function vi(n,e){return uc(n,"POST","/v1/accounts:signInWithIdp",Ws(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zI="http://localhost";class Ns extends Mu{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Ns(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Qt("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:i}=t,r=Du(t,["providerId","signInMethod"]);if(!s||!i)return null;const a=new Ns(s,i);return a.idToken=r.idToken||void 0,a.accessToken=r.accessToken||void 0,a.secret=r.secret,a.nonce=r.nonce,a.pendingToken=r.pendingToken||null,a}_getIdTokenResponse(e){const t=this.buildRequest();return vi(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,vi(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,vi(e,t)}buildRequest(){const e={requestUri:zI,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=ga(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function GI(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function KI(n){const e=Ar(Sr(n)).link,t=e?Ar(Sr(e)).deep_link_id:null,s=Ar(Sr(n)).deep_link_id;return(s?Ar(Sr(s)).link:null)||s||t||e||n}class Lu{constructor(e){var t,s,i,r,a,o;const l=Ar(Sr(e)),u=(t=l.apiKey)!==null&&t!==void 0?t:null,h=(s=l.oobCode)!==null&&s!==void 0?s:null,p=GI((i=l.mode)!==null&&i!==void 0?i:null);te(u&&h&&p,"argument-error"),this.apiKey=u,this.operation=p,this.code=h,this.continueUrl=(r=l.continueUrl)!==null&&r!==void 0?r:null,this.languageCode=(a=l.languageCode)!==null&&a!==void 0?a:null,this.tenantId=(o=l.tenantId)!==null&&o!==void 0?o:null}static parseLink(e){const t=KI(e);try{return new Lu(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gi{constructor(){this.providerId=Gi.PROVIDER_ID}static credential(e,t){return Kr._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=Lu.parseLink(t);return te(s,"argument-error"),Kr._fromEmailAndCode(e,s.code,s.tenantId)}}Gi.PROVIDER_ID="password";Gi.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Gi.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tg{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class va extends Tg{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qn extends va{constructor(){super("facebook.com")}static credential(e){return Ns._fromParams({providerId:qn.PROVIDER_ID,signInMethod:qn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return qn.credentialFromTaggedObject(e)}static credentialFromError(e){return qn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return qn.credential(e.oauthAccessToken)}catch{return null}}}qn.FACEBOOK_SIGN_IN_METHOD="facebook.com";qn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bn extends va{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Ns._fromParams({providerId:Bn.PROVIDER_ID,signInMethod:Bn.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return Bn.credentialFromTaggedObject(e)}static credentialFromError(e){return Bn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return Bn.credential(t,s)}catch{return null}}}Bn.GOOGLE_SIGN_IN_METHOD="google.com";Bn.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jn extends va{constructor(){super("github.com")}static credential(e){return Ns._fromParams({providerId:jn.PROVIDER_ID,signInMethod:jn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return jn.credentialFromTaggedObject(e)}static credentialFromError(e){return jn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return jn.credential(e.oauthAccessToken)}catch{return null}}}jn.GITHUB_SIGN_IN_METHOD="github.com";jn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wn extends va{constructor(){super("twitter.com")}static credential(e,t){return Ns._fromParams({providerId:Wn.PROVIDER_ID,signInMethod:Wn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Wn.credentialFromTaggedObject(e)}static credentialFromError(e){return Wn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return Wn.credential(t,s)}catch{return null}}}Wn.TWITTER_SIGN_IN_METHOD="twitter.com";Wn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ti{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,i=!1){const r=await _n._fromIdTokenResponse(e,s,i),a=Vf(s);return new Ti({user:r,providerId:a,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const i=Vf(s);return new Ti({user:e,providerId:i,_tokenResponse:s,operationType:t})}}function Vf(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Do extends kn{constructor(e,t,s,i){var r;super(t.code,t.message),this.operationType=s,this.user=i,Object.setPrototypeOf(this,Do.prototype),this.customData={appName:e.name,tenantId:(r=e.tenantId)!==null&&r!==void 0?r:void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,i){return new Do(e,t,s,i)}}function Ag(n,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(r=>{throw r.code==="auth/multi-factor-auth-required"?Do._fromErrorAndOperation(n,r,e,s):r})}async function HI(n,e,t=!1){const s=await Gr(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return Ti._forOperation(n,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function QI(n,e,t=!1){const{auth:s}=n;if(vn(s.app))return Promise.reject(Xn(s));const i="reauthenticate";try{const r=await Gr(n,Ag(s,i,e,n),t);te(r.idToken,s,"internal-error");const a=Vu(r.idToken);te(a,s,"internal-error");const{sub:o}=a;return te(n.uid===o,s,"user-mismatch"),Ti._forOperation(n,i,r)}catch(r){throw(r==null?void 0:r.code)==="auth/user-not-found"&&Qt(s,"user-mismatch"),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Sg(n,e,t=!1){if(vn(n.app))return Promise.reject(Xn(n));const s="signIn",i=await Ag(n,s,e),r=await Ti._fromIdTokenResponse(n,s,i);return t||await n._updateCurrentUser(r.user),r}async function JI(n,e){return Sg(zi(n),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function YI(n){const e=zi(n);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}function XI(n,e,t){return vn(n.app)?Promise.reject(Xn(n)):JI(et(n),Gi.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&YI(n),s})}function ZI(n,e,t,s){return et(n).onIdTokenChanged(e,t,s)}function eE(n,e,t){return et(n).beforeAuthStateChanged(e,t)}function tE(n,e,t,s){return et(n).onAuthStateChanged(e,t,s)}function nE(n){return et(n).signOut()}const xo="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kg{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(xo,"1"),this.storage.removeItem(xo),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sE(){const n=Je();return Ou(n)||dc(n)}const iE=1e3,rE=10;class Rg extends kg{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=sE()&&EI(),this.fallbackToPolling=_g(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),i=this.localCache[t];s!==i&&e(t,i,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((a,o,l)=>{this.notifyListeners(a,l)});return}const s=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const a=this.storage.getItem(s);if(e.newValue!==a)e.newValue!==null?this.storage.setItem(s,e.newValue):this.storage.removeItem(s);else if(this.localCache[s]===e.newValue&&!t)return}const i=()=>{const a=this.storage.getItem(s);!t&&this.localCache[s]===a||this.notifyListeners(s,a)},r=this.storage.getItem(s);II()&&r!==e.newValue&&e.newValue!==e.oldValue?setTimeout(i,rE):i()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const i of Array.from(s))i(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},iE)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Rg.type="LOCAL";const aE=Rg;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pg extends kg{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Pg.type="SESSION";const Cg=Pg;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oE(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fc{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(i=>i.isListeningto(e));if(t)return t;const s=new fc(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:i,data:r}=t.data,a=this.handlersMap[i];if(!(a!=null&&a.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:i});const o=Array.from(a).map(async u=>u(t.origin,r)),l=await oE(o);t.ports[0].postMessage({status:"done",eventId:s,eventType:i,response:l})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}fc.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fu(n="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cE{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let r,a;return new Promise((o,l)=>{const u=Fu("",20);i.port1.start();const h=setTimeout(()=>{l(new Error("unsupported_event"))},s);a={messageChannel:i,onMessage(p){const m=p;if(m.data.eventId===u)switch(m.data.status){case"ack":clearTimeout(h),r=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(r),o(m.data.response);break;default:clearTimeout(h),clearTimeout(r),l(new Error("invalid_response"));break}}},this.handlers.add(a),i.port1.addEventListener("message",a.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[i.port2])}).finally(()=>{a&&this.removeMessageHandler(a)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function an(){return window}function lE(n){an().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $g(){return typeof an().WorkerGlobalScope<"u"&&typeof an().importScripts=="function"}async function uE(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function dE(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function hE(){return $g()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dg="firebaseLocalStorageDb",fE=1,No="firebaseLocalStorage",xg="fbase_key";class ba{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function pc(n,e){return n.transaction([No],e?"readwrite":"readonly").objectStore(No)}function pE(){const n=indexedDB.deleteDatabase(Dg);return new ba(n).toPromise()}function zl(){const n=indexedDB.open(Dg,fE);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const s=n.result;try{s.createObjectStore(No,{keyPath:xg})}catch(i){t(i)}}),n.addEventListener("success",async()=>{const s=n.result;s.objectStoreNames.contains(No)?e(s):(s.close(),await pE(),e(await zl()))})})}async function Of(n,e,t){const s=pc(n,!0).put({[xg]:e,value:t});return new ba(s).toPromise()}async function mE(n,e){const t=pc(n,!1).get(e),s=await new ba(t).toPromise();return s===void 0?null:s.value}function Mf(n,e){const t=pc(n,!0).delete(e);return new ba(t).toPromise()}const gE=800,yE=3;class Ng{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await zl(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>yE)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return $g()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=fc._getInstance(hE()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await uE(),!this.activeServiceWorker)return;this.sender=new cE(this.activeServiceWorker);const s=await this.sender._send("ping",{},800);s&&!((e=s[0])===null||e===void 0)&&e.fulfilled&&!((t=s[0])===null||t===void 0)&&t.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||dE()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await zl();return await Of(e,xo,"1"),await Mf(e,xo),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>Of(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>mE(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Mf(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const r=pc(i,!1).getAll();return new ba(r).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:i,value:r}of e)s.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(r)&&(this.notifyListeners(i,r),t.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!s.has(i)&&(this.notifyListeners(i,null),t.push(i));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const i of Array.from(s))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),gE)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Ng.type="LOCAL";const vE=Ng;new ya(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bE(n,e){return e?wn(e):(te(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uu extends Mu{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return vi(e,this._buildIdpRequest())}_linkToIdToken(e,t){return vi(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return vi(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function _E(n){return Sg(n.auth,new Uu(n),n.bypassAuthState)}function wE(n){const{auth:e,user:t}=n;return te(t,e,"internal-error"),QI(t,new Uu(n),n.bypassAuthState)}async function IE(n){const{auth:e,user:t}=n;return te(t,e,"internal-error"),HI(t,new Uu(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vg{constructor(e,t,s,i,r=!1){this.auth=e,this.resolver=s,this.user=i,this.bypassAuthState=r,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:i,tenantId:r,error:a,type:o}=e;if(a){this.reject(a);return}const l={auth:this.auth,requestUri:t,sessionId:s,tenantId:r||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(o)(l))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return _E;case"linkViaPopup":case"linkViaRedirect":return IE;case"reauthViaPopup":case"reauthViaRedirect":return wE;default:Qt(this.auth,"internal-error")}}resolve(e){Tn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Tn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const EE=new ya(2e3,1e4);class pi extends Vg{constructor(e,t,s,i,r){super(e,t,i,r),this.provider=s,this.authWindow=null,this.pollId=null,pi.currentPopupAction&&pi.currentPopupAction.cancel(),pi.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return te(e,this.auth,"internal-error"),e}async onExecution(){Tn(this.filter.length===1,"Popup operations only handle one event");const e=Fu();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(rn(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(rn(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,pi.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if(!((s=(t=this.authWindow)===null||t===void 0?void 0:t.window)===null||s===void 0)&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(rn(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,EE.get())};e()}}pi.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const TE="pendingRedirect",uo=new Map;class AE extends Vg{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=uo.get(this.auth._key());if(!e){try{const s=await SE(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}uo.set(this.auth._key(),e)}return this.bypassAuthState||uo.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function SE(n,e){const t=PE(e),s=RE(n);if(!await s._isAvailable())return!1;const i=await s._get(t)==="true";return await s._remove(t),i}function kE(n,e){uo.set(n._key(),e)}function RE(n){return wn(n._redirectPersistence)}function PE(n){return lo(TE,n.config.apiKey,n.name)}async function CE(n,e,t=!1){if(vn(n.app))return Promise.reject(Xn(n));const s=zi(n),i=bE(s,e),a=await new AE(s,i,t).execute();return a&&!t&&(delete a.user._redirectEventId,await s._persistUserIfCurrent(a.user),await s._setRedirectUser(null,e)),a}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $E=10*60*1e3;class DE{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!xE(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!Og(e)){const i=((s=e.error.code)===null||s===void 0?void 0:s.split("auth/")[1])||"internal-error";t.onError(rn(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=$E&&this.cachedEventUids.clear(),this.cachedEventUids.has(Lf(e))}saveEventToCache(e){this.cachedEventUids.add(Lf(e)),this.lastProcessedEventTime=Date.now()}}function Lf(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function Og({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function xE(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Og(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function NE(n,e={}){return us(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VE=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,OE=/^https?/;async function ME(n){if(n.config.emulator)return;const{authorizedDomains:e}=await NE(n);for(const t of e)try{if(LE(t))return}catch{}Qt(n,"unauthorized-domain")}function LE(n){const e=jl(),{protocol:t,hostname:s}=new URL(e);if(n.startsWith("chrome-extension://")){const a=new URL(n);return a.hostname===""&&s===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&a.hostname===s}if(!OE.test(t))return!1;if(VE.test(n))return s===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FE=new ya(3e4,6e4);function Ff(){const n=an().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function UE(n){return new Promise((e,t)=>{var s,i,r;function a(){Ff(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{Ff(),t(rn(n,"network-request-failed"))},timeout:FE.get()})}if(!((i=(s=an().gapi)===null||s===void 0?void 0:s.iframes)===null||i===void 0)&&i.Iframe)e(gapi.iframes.getContext());else if(!((r=an().gapi)===null||r===void 0)&&r.load)a();else{const o=DI("iframefcb");return an()[o]=()=>{gapi.load?a():t(rn(n,"network-request-failed"))},Ig(`${$I()}?onload=${o}`).catch(l=>t(l))}}).catch(e=>{throw ho=null,e})}let ho=null;function qE(n){return ho=ho||UE(n),ho}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const BE=new ya(5e3,15e3),jE="__/auth/iframe",WE="emulator/auth/iframe",zE={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},GE=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function KE(n){const e=n.config;te(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?Nu(e,WE):`https://${n.config.authDomain}/${jE}`,s={apiKey:e.apiKey,appName:n.name,v:Wi},i=GE.get(n.config.apiHost);i&&(s.eid=i);const r=n._getFrameworks();return r.length&&(s.fw=r.join(",")),`${t}?${ga(s).slice(1)}`}async function HE(n){const e=await qE(n),t=an().gapi;return te(t,n,"internal-error"),e.open({where:document.body,url:KE(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:zE,dontclear:!0},s=>new Promise(async(i,r)=>{await s.restyle({setHideOnLeave:!1});const a=rn(n,"network-request-failed"),o=an().setTimeout(()=>{r(a)},BE.get());function l(){an().clearTimeout(o),i(s)}s.ping(l).then(l,()=>{r(a)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const QE={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},JE=500,YE=600,XE="_blank",ZE="http://localhost";class Uf{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function eT(n,e,t,s=JE,i=YE){const r=Math.max((window.screen.availHeight-i)/2,0).toString(),a=Math.max((window.screen.availWidth-s)/2,0).toString();let o="";const l=Object.assign(Object.assign({},QE),{width:s.toString(),height:i.toString(),top:r,left:a}),u=Je().toLowerCase();t&&(o=mg(u)?XE:t),pg(u)&&(e=e||ZE,l.scrollbars="yes");const h=Object.entries(l).reduce((m,[w,E])=>`${m}${w}=${E},`,"");if(wI(u)&&o!=="_self")return tT(e||"",o),new Uf(null);const p=window.open(e||"",o,h);te(p,n,"popup-blocked");try{p.focus()}catch{}return new Uf(p)}function tT(n,e){const t=document.createElement("a");t.href=n,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nT="__/auth/handler",sT="emulator/auth/handler",iT=encodeURIComponent("fac");async function qf(n,e,t,s,i,r){te(n.config.authDomain,n,"auth-domain-config-required"),te(n.config.apiKey,n,"invalid-api-key");const a={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:s,v:Wi,eventId:i};if(e instanceof Tg){e.setDefaultLanguage(n.languageCode),a.providerId=e.providerId||"",j_(e.getCustomParameters())||(a.customParameters=JSON.stringify(e.getCustomParameters()));for(const[h,p]of Object.entries({}))a[h]=p}if(e instanceof va){const h=e.getScopes().filter(p=>p!=="");h.length>0&&(a.scopes=h.join(","))}n.tenantId&&(a.tid=n.tenantId);const o=a;for(const h of Object.keys(o))o[h]===void 0&&delete o[h];const l=await n._getAppCheckToken(),u=l?`#${iT}=${encodeURIComponent(l)}`:"";return`${rT(n)}?${ga(o).slice(1)}${u}`}function rT({config:n}){return n.emulator?Nu(n,sT):`https://${n.authDomain}/${nT}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yl="webStorageSupport";class aT{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Cg,this._completeRedirectFn=CE,this._overrideRedirectResult=kE}async _openPopup(e,t,s,i){var r;Tn((r=this.eventManagers[e._key()])===null||r===void 0?void 0:r.manager,"_initialize() not called before _openPopup()");const a=await qf(e,t,s,jl(),i);return eT(e,a,Fu())}async _openRedirect(e,t,s,i){await this._originValidation(e);const r=await qf(e,t,s,jl(),i);return lE(r),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:i,promise:r}=this.eventManagers[t];return i?Promise.resolve(i):(Tn(r,"If manager is not set, promise should be"),r)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await HE(e),s=new DE(e);return t.register("authEvent",i=>(te(i==null?void 0:i.authEvent,e,"invalid-auth-event"),{status:s.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(yl,{type:yl},i=>{var r;const a=(r=i==null?void 0:i[0])===null||r===void 0?void 0:r[yl];a!==void 0&&t(!!a),Qt(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=ME(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return _g()||Ou()||dc()}}const oT=aT;var Bf="@firebase/auth",jf="1.7.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cT{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){te(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lT(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function uT(n){Ei(new Ds("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),r=e.getProvider("app-check-internal"),{apiKey:a,authDomain:o}=s.options;te(a&&!a.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:a,authDomain:o,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:wg(n)},u=new RI(s,i,r,l);return MI(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),Ei(new Ds("auth-internal",e=>{const t=zi(e.getProvider("auth").getImmediate());return(s=>new cT(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Yn(Bf,jf,lT(n)),Yn(Bf,jf,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dT=5*60,hT=Ym("authIdTokenMaxAge")||dT;let Wf=null;const fT=n=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>hT)return;const i=t==null?void 0:t.token;Wf!==i&&(Wf=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function pT(n=Ww()){const e=$u(n,"auth");if(e.isInitialized())return e.getImmediate();const t=OI(n,{popupRedirectResolver:oT,persistence:[vE,aE,Cg]}),s=Ym("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const r=new URL(s,location.origin);if(location.origin===r.origin){const a=fT(r.toString());eE(t,a,()=>a(t.currentUser)),ZI(t,o=>a(o))}}const i=D_("auth");return i&&LI(t,`http://${i}`),t}function mT(){var n,e;return(e=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&e!==void 0?e:document}PI({loadJS(n){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",n),s.onload=e,s.onerror=i=>{const r=rn("internal-error");r.customData=i,t(r)},s.type="text/javascript",s.charset="UTF-8",mT().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});uT("Browser");var zf=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Rs,Mg;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(_,y){function v(){}v.prototype=y.prototype,_.D=y.prototype,_.prototype=new v,_.prototype.constructor=_,_.C=function(I,T,R){for(var b=Array(arguments.length-2),St=2;St<arguments.length;St++)b[St-2]=arguments[St];return y.prototype[T].apply(I,b)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(s,t),s.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(_,y,v){v||(v=0);var I=Array(16);if(typeof y=="string")for(var T=0;16>T;++T)I[T]=y.charCodeAt(v++)|y.charCodeAt(v++)<<8|y.charCodeAt(v++)<<16|y.charCodeAt(v++)<<24;else for(T=0;16>T;++T)I[T]=y[v++]|y[v++]<<8|y[v++]<<16|y[v++]<<24;y=_.g[0],v=_.g[1],T=_.g[2];var R=_.g[3],b=y+(R^v&(T^R))+I[0]+3614090360&4294967295;y=v+(b<<7&4294967295|b>>>25),b=R+(T^y&(v^T))+I[1]+3905402710&4294967295,R=y+(b<<12&4294967295|b>>>20),b=T+(v^R&(y^v))+I[2]+606105819&4294967295,T=R+(b<<17&4294967295|b>>>15),b=v+(y^T&(R^y))+I[3]+3250441966&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(R^v&(T^R))+I[4]+4118548399&4294967295,y=v+(b<<7&4294967295|b>>>25),b=R+(T^y&(v^T))+I[5]+1200080426&4294967295,R=y+(b<<12&4294967295|b>>>20),b=T+(v^R&(y^v))+I[6]+2821735955&4294967295,T=R+(b<<17&4294967295|b>>>15),b=v+(y^T&(R^y))+I[7]+4249261313&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(R^v&(T^R))+I[8]+1770035416&4294967295,y=v+(b<<7&4294967295|b>>>25),b=R+(T^y&(v^T))+I[9]+2336552879&4294967295,R=y+(b<<12&4294967295|b>>>20),b=T+(v^R&(y^v))+I[10]+4294925233&4294967295,T=R+(b<<17&4294967295|b>>>15),b=v+(y^T&(R^y))+I[11]+2304563134&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(R^v&(T^R))+I[12]+1804603682&4294967295,y=v+(b<<7&4294967295|b>>>25),b=R+(T^y&(v^T))+I[13]+4254626195&4294967295,R=y+(b<<12&4294967295|b>>>20),b=T+(v^R&(y^v))+I[14]+2792965006&4294967295,T=R+(b<<17&4294967295|b>>>15),b=v+(y^T&(R^y))+I[15]+1236535329&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(T^R&(v^T))+I[1]+4129170786&4294967295,y=v+(b<<5&4294967295|b>>>27),b=R+(v^T&(y^v))+I[6]+3225465664&4294967295,R=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(R^y))+I[11]+643717713&4294967295,T=R+(b<<14&4294967295|b>>>18),b=v+(R^y&(T^R))+I[0]+3921069994&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(T^R&(v^T))+I[5]+3593408605&4294967295,y=v+(b<<5&4294967295|b>>>27),b=R+(v^T&(y^v))+I[10]+38016083&4294967295,R=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(R^y))+I[15]+3634488961&4294967295,T=R+(b<<14&4294967295|b>>>18),b=v+(R^y&(T^R))+I[4]+3889429448&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(T^R&(v^T))+I[9]+568446438&4294967295,y=v+(b<<5&4294967295|b>>>27),b=R+(v^T&(y^v))+I[14]+3275163606&4294967295,R=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(R^y))+I[3]+4107603335&4294967295,T=R+(b<<14&4294967295|b>>>18),b=v+(R^y&(T^R))+I[8]+1163531501&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(T^R&(v^T))+I[13]+2850285829&4294967295,y=v+(b<<5&4294967295|b>>>27),b=R+(v^T&(y^v))+I[2]+4243563512&4294967295,R=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(R^y))+I[7]+1735328473&4294967295,T=R+(b<<14&4294967295|b>>>18),b=v+(R^y&(T^R))+I[12]+2368359562&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(v^T^R)+I[5]+4294588738&4294967295,y=v+(b<<4&4294967295|b>>>28),b=R+(y^v^T)+I[8]+2272392833&4294967295,R=y+(b<<11&4294967295|b>>>21),b=T+(R^y^v)+I[11]+1839030562&4294967295,T=R+(b<<16&4294967295|b>>>16),b=v+(T^R^y)+I[14]+4259657740&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(v^T^R)+I[1]+2763975236&4294967295,y=v+(b<<4&4294967295|b>>>28),b=R+(y^v^T)+I[4]+1272893353&4294967295,R=y+(b<<11&4294967295|b>>>21),b=T+(R^y^v)+I[7]+4139469664&4294967295,T=R+(b<<16&4294967295|b>>>16),b=v+(T^R^y)+I[10]+3200236656&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(v^T^R)+I[13]+681279174&4294967295,y=v+(b<<4&4294967295|b>>>28),b=R+(y^v^T)+I[0]+3936430074&4294967295,R=y+(b<<11&4294967295|b>>>21),b=T+(R^y^v)+I[3]+3572445317&4294967295,T=R+(b<<16&4294967295|b>>>16),b=v+(T^R^y)+I[6]+76029189&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(v^T^R)+I[9]+3654602809&4294967295,y=v+(b<<4&4294967295|b>>>28),b=R+(y^v^T)+I[12]+3873151461&4294967295,R=y+(b<<11&4294967295|b>>>21),b=T+(R^y^v)+I[15]+530742520&4294967295,T=R+(b<<16&4294967295|b>>>16),b=v+(T^R^y)+I[2]+3299628645&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(T^(v|~R))+I[0]+4096336452&4294967295,y=v+(b<<6&4294967295|b>>>26),b=R+(v^(y|~T))+I[7]+1126891415&4294967295,R=y+(b<<10&4294967295|b>>>22),b=T+(y^(R|~v))+I[14]+2878612391&4294967295,T=R+(b<<15&4294967295|b>>>17),b=v+(R^(T|~y))+I[5]+4237533241&4294967295,v=T+(b<<21&4294967295|b>>>11),b=y+(T^(v|~R))+I[12]+1700485571&4294967295,y=v+(b<<6&4294967295|b>>>26),b=R+(v^(y|~T))+I[3]+2399980690&4294967295,R=y+(b<<10&4294967295|b>>>22),b=T+(y^(R|~v))+I[10]+4293915773&4294967295,T=R+(b<<15&4294967295|b>>>17),b=v+(R^(T|~y))+I[1]+2240044497&4294967295,v=T+(b<<21&4294967295|b>>>11),b=y+(T^(v|~R))+I[8]+1873313359&4294967295,y=v+(b<<6&4294967295|b>>>26),b=R+(v^(y|~T))+I[15]+4264355552&4294967295,R=y+(b<<10&4294967295|b>>>22),b=T+(y^(R|~v))+I[6]+2734768916&4294967295,T=R+(b<<15&4294967295|b>>>17),b=v+(R^(T|~y))+I[13]+1309151649&4294967295,v=T+(b<<21&4294967295|b>>>11),b=y+(T^(v|~R))+I[4]+4149444226&4294967295,y=v+(b<<6&4294967295|b>>>26),b=R+(v^(y|~T))+I[11]+3174756917&4294967295,R=y+(b<<10&4294967295|b>>>22),b=T+(y^(R|~v))+I[2]+718787259&4294967295,T=R+(b<<15&4294967295|b>>>17),b=v+(R^(T|~y))+I[9]+3951481745&4294967295,_.g[0]=_.g[0]+y&4294967295,_.g[1]=_.g[1]+(T+(b<<21&4294967295|b>>>11))&4294967295,_.g[2]=_.g[2]+T&4294967295,_.g[3]=_.g[3]+R&4294967295}s.prototype.u=function(_,y){y===void 0&&(y=_.length);for(var v=y-this.blockSize,I=this.B,T=this.h,R=0;R<y;){if(T==0)for(;R<=v;)i(this,_,R),R+=this.blockSize;if(typeof _=="string"){for(;R<y;)if(I[T++]=_.charCodeAt(R++),T==this.blockSize){i(this,I),T=0;break}}else for(;R<y;)if(I[T++]=_[R++],T==this.blockSize){i(this,I),T=0;break}}this.h=T,this.o+=y},s.prototype.v=function(){var _=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);_[0]=128;for(var y=1;y<_.length-8;++y)_[y]=0;var v=8*this.o;for(y=_.length-8;y<_.length;++y)_[y]=v&255,v/=256;for(this.u(_),_=Array(16),y=v=0;4>y;++y)for(var I=0;32>I;I+=8)_[v++]=this.g[y]>>>I&255;return _};function r(_,y){var v=o;return Object.prototype.hasOwnProperty.call(v,_)?v[_]:v[_]=y(_)}function a(_,y){this.h=y;for(var v=[],I=!0,T=_.length-1;0<=T;T--){var R=_[T]|0;I&&R==y||(v[T]=R,I=!1)}this.g=v}var o={};function l(_){return-128<=_&&128>_?r(_,function(y){return new a([y|0],0>y?-1:0)}):new a([_|0],0>_?-1:0)}function u(_){if(isNaN(_)||!isFinite(_))return p;if(0>_)return C(u(-_));for(var y=[],v=1,I=0;_>=v;I++)y[I]=_/v|0,v*=4294967296;return new a(y,0)}function h(_,y){if(_.length==0)throw Error("number format error: empty string");if(y=y||10,2>y||36<y)throw Error("radix out of range: "+y);if(_.charAt(0)=="-")return C(h(_.substring(1),y));if(0<=_.indexOf("-"))throw Error('number format error: interior "-" character');for(var v=u(Math.pow(y,8)),I=p,T=0;T<_.length;T+=8){var R=Math.min(8,_.length-T),b=parseInt(_.substring(T,T+R),y);8>R?(R=u(Math.pow(y,R)),I=I.j(R).add(u(b))):(I=I.j(v),I=I.add(u(b)))}return I}var p=l(0),m=l(1),w=l(16777216);n=a.prototype,n.m=function(){if(x(this))return-C(this).m();for(var _=0,y=1,v=0;v<this.g.length;v++){var I=this.i(v);_+=(0<=I?I:4294967296+I)*y,y*=4294967296}return _},n.toString=function(_){if(_=_||10,2>_||36<_)throw Error("radix out of range: "+_);if(E(this))return"0";if(x(this))return"-"+C(this).toString(_);for(var y=u(Math.pow(_,6)),v=this,I="";;){var T=ae(v,y).g;v=j(v,T.j(y));var R=((0<v.g.length?v.g[0]:v.h)>>>0).toString(_);if(v=T,E(v))return R+I;for(;6>R.length;)R="0"+R;I=R+I}},n.i=function(_){return 0>_?0:_<this.g.length?this.g[_]:this.h};function E(_){if(_.h!=0)return!1;for(var y=0;y<_.g.length;y++)if(_.g[y]!=0)return!1;return!0}function x(_){return _.h==-1}n.l=function(_){return _=j(this,_),x(_)?-1:E(_)?0:1};function C(_){for(var y=_.g.length,v=[],I=0;I<y;I++)v[I]=~_.g[I];return new a(v,~_.h).add(m)}n.abs=function(){return x(this)?C(this):this},n.add=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0,T=0;T<=y;T++){var R=I+(this.i(T)&65535)+(_.i(T)&65535),b=(R>>>16)+(this.i(T)>>>16)+(_.i(T)>>>16);I=b>>>16,R&=65535,b&=65535,v[T]=b<<16|R}return new a(v,v[v.length-1]&-2147483648?-1:0)};function j(_,y){return _.add(C(y))}n.j=function(_){if(E(this)||E(_))return p;if(x(this))return x(_)?C(this).j(C(_)):C(C(this).j(_));if(x(_))return C(this.j(C(_)));if(0>this.l(w)&&0>_.l(w))return u(this.m()*_.m());for(var y=this.g.length+_.g.length,v=[],I=0;I<2*y;I++)v[I]=0;for(I=0;I<this.g.length;I++)for(var T=0;T<_.g.length;T++){var R=this.i(I)>>>16,b=this.i(I)&65535,St=_.i(T)>>>16,Jt=_.i(T)&65535;v[2*I+2*T]+=b*Jt,J(v,2*I+2*T),v[2*I+2*T+1]+=R*Jt,J(v,2*I+2*T+1),v[2*I+2*T+1]+=b*St,J(v,2*I+2*T+1),v[2*I+2*T+2]+=R*St,J(v,2*I+2*T+2)}for(I=0;I<y;I++)v[I]=v[2*I+1]<<16|v[2*I];for(I=y;I<2*y;I++)v[I]=0;return new a(v,0)};function J(_,y){for(;(_[y]&65535)!=_[y];)_[y+1]+=_[y]>>>16,_[y]&=65535,y++}function H(_,y){this.g=_,this.h=y}function ae(_,y){if(E(y))throw Error("division by zero");if(E(_))return new H(p,p);if(x(_))return y=ae(C(_),y),new H(C(y.g),C(y.h));if(x(y))return y=ae(_,C(y)),new H(C(y.g),y.h);if(30<_.g.length){if(x(_)||x(y))throw Error("slowDivide_ only works with positive integers.");for(var v=m,I=y;0>=I.l(_);)v=O(v),I=O(I);var T=U(v,1),R=U(I,1);for(I=U(I,2),v=U(v,2);!E(I);){var b=R.add(I);0>=b.l(_)&&(T=T.add(v),R=b),I=U(I,1),v=U(v,1)}return y=j(_,T.j(y)),new H(T,y)}for(T=p;0<=_.l(y);){for(v=Math.max(1,Math.floor(_.m()/y.m())),I=Math.ceil(Math.log(v)/Math.LN2),I=48>=I?1:Math.pow(2,I-48),R=u(v),b=R.j(y);x(b)||0<b.l(_);)v-=I,R=u(v),b=R.j(y);E(R)&&(R=m),T=T.add(R),_=j(_,b)}return new H(T,_)}n.A=function(_){return ae(this,_).h},n.and=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)&_.i(I);return new a(v,this.h&_.h)},n.or=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)|_.i(I);return new a(v,this.h|_.h)},n.xor=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)^_.i(I);return new a(v,this.h^_.h)};function O(_){for(var y=_.g.length+1,v=[],I=0;I<y;I++)v[I]=_.i(I)<<1|_.i(I-1)>>>31;return new a(v,_.h)}function U(_,y){var v=y>>5;y%=32;for(var I=_.g.length-v,T=[],R=0;R<I;R++)T[R]=0<y?_.i(R+v)>>>y|_.i(R+v+1)<<32-y:_.i(R+v);return new a(T,_.h)}s.prototype.digest=s.prototype.v,s.prototype.reset=s.prototype.s,s.prototype.update=s.prototype.u,Mg=s,a.prototype.add=a.prototype.add,a.prototype.multiply=a.prototype.j,a.prototype.modulo=a.prototype.A,a.prototype.compare=a.prototype.l,a.prototype.toNumber=a.prototype.m,a.prototype.toString=a.prototype.toString,a.prototype.getBits=a.prototype.i,a.fromNumber=u,a.fromString=h,Rs=a}).apply(typeof zf<"u"?zf:typeof self<"u"?self:typeof window<"u"?window:{});var Ja=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Lg,Fg,kr,Ug,fo,Gl,qg,Bg,jg;(function(){var n,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(c,d,f){return c==Array.prototype||c==Object.prototype||(c[d]=f.value),c};function t(c){c=[typeof globalThis=="object"&&globalThis,c,typeof window=="object"&&window,typeof self=="object"&&self,typeof Ja=="object"&&Ja];for(var d=0;d<c.length;++d){var f=c[d];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var s=t(this);function i(c,d){if(d)e:{var f=s;c=c.split(".");for(var g=0;g<c.length-1;g++){var P=c[g];if(!(P in f))break e;f=f[P]}c=c[c.length-1],g=f[c],d=d(g),d!=g&&d!=null&&e(f,c,{configurable:!0,writable:!0,value:d})}}function r(c,d){c instanceof String&&(c+="");var f=0,g=!1,P={next:function(){if(!g&&f<c.length){var D=f++;return{value:d(D,c[D]),done:!1}}return g=!0,{done:!0,value:void 0}}};return P[Symbol.iterator]=function(){return P},P}i("Array.prototype.values",function(c){return c||function(){return r(this,function(d,f){return f})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var a=a||{},o=this||self;function l(c){var d=typeof c;return d=d!="object"?d:c?Array.isArray(c)?"array":d:"null",d=="array"||d=="object"&&typeof c.length=="number"}function u(c){var d=typeof c;return d=="object"&&c!=null||d=="function"}function h(c,d,f){return c.call.apply(c.bind,arguments)}function p(c,d,f){if(!c)throw Error();if(2<arguments.length){var g=Array.prototype.slice.call(arguments,2);return function(){var P=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(P,g),c.apply(d,P)}}return function(){return c.apply(d,arguments)}}function m(c,d,f){return m=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?h:p,m.apply(null,arguments)}function w(c,d){var f=Array.prototype.slice.call(arguments,1);return function(){var g=f.slice();return g.push.apply(g,arguments),c.apply(this,g)}}function E(c,d){function f(){}f.prototype=d.prototype,c.aa=d.prototype,c.prototype=new f,c.prototype.constructor=c,c.Qb=function(g,P,D){for(var L=Array(arguments.length-2),Re=2;Re<arguments.length;Re++)L[Re-2]=arguments[Re];return d.prototype[P].apply(g,L)}}function x(c){const d=c.length;if(0<d){const f=Array(d);for(let g=0;g<d;g++)f[g]=c[g];return f}return[]}function C(c,d){for(let f=1;f<arguments.length;f++){const g=arguments[f];if(l(g)){const P=c.length||0,D=g.length||0;c.length=P+D;for(let L=0;L<D;L++)c[P+L]=g[L]}else c.push(g)}}class j{constructor(d,f){this.i=d,this.j=f,this.h=0,this.g=null}get(){let d;return 0<this.h?(this.h--,d=this.g,this.g=d.next,d.next=null):d=this.i(),d}}function J(c){return/^[\s\xa0]*$/.test(c)}function H(){var c=o.navigator;return c&&(c=c.userAgent)?c:""}function ae(c){return ae[" "](c),c}ae[" "]=function(){};var O=H().indexOf("Gecko")!=-1&&!(H().toLowerCase().indexOf("webkit")!=-1&&H().indexOf("Edge")==-1)&&!(H().indexOf("Trident")!=-1||H().indexOf("MSIE")!=-1)&&H().indexOf("Edge")==-1;function U(c,d,f){for(const g in c)d.call(f,c[g],g,c)}function _(c,d){for(const f in c)d.call(void 0,c[f],f,c)}function y(c){const d={};for(const f in c)d[f]=c[f];return d}const v="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function I(c,d){let f,g;for(let P=1;P<arguments.length;P++){g=arguments[P];for(f in g)c[f]=g[f];for(let D=0;D<v.length;D++)f=v[D],Object.prototype.hasOwnProperty.call(g,f)&&(c[f]=g[f])}}function T(c){var d=1;c=c.split(":");const f=[];for(;0<d&&c.length;)f.push(c.shift()),d--;return c.length&&f.push(c.join(":")),f}function R(c){o.setTimeout(()=>{throw c},0)}function b(){var c=qc;let d=null;return c.g&&(d=c.g,c.g=c.g.next,c.g||(c.h=null),d.next=null),d}class St{constructor(){this.h=this.g=null}add(d,f){const g=Jt.get();g.set(d,f),this.h?this.h.next=g:this.g=g,this.h=g}}var Jt=new j(()=>new Wb,c=>c.reset());class Wb{constructor(){this.next=this.g=this.h=null}set(d,f){this.h=d,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let er,tr=!1,qc=new St,ph=()=>{const c=o.Promise.resolve(void 0);er=()=>{c.then(zb)}};var zb=()=>{for(var c;c=b();){try{c.h.call(c.g)}catch(f){R(f)}var d=Jt;d.j(c),100>d.h&&(d.h++,c.next=d.g,d.g=c)}tr=!1};function $n(){this.s=this.s,this.C=this.C}$n.prototype.s=!1,$n.prototype.ma=function(){this.s||(this.s=!0,this.N())},$n.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function ht(c,d){this.type=c,this.g=this.target=d,this.defaultPrevented=!1}ht.prototype.h=function(){this.defaultPrevented=!0};var Gb=function(){if(!o.addEventListener||!Object.defineProperty)return!1;var c=!1,d=Object.defineProperty({},"passive",{get:function(){c=!0}});try{const f=()=>{};o.addEventListener("test",f,d),o.removeEventListener("test",f,d)}catch{}return c}();function nr(c,d){if(ht.call(this,c?c.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,c){var f=this.type=c.type,g=c.changedTouches&&c.changedTouches.length?c.changedTouches[0]:null;if(this.target=c.target||c.srcElement,this.g=d,d=c.relatedTarget){if(O){e:{try{ae(d.nodeName);var P=!0;break e}catch{}P=!1}P||(d=null)}}else f=="mouseover"?d=c.fromElement:f=="mouseout"&&(d=c.toElement);this.relatedTarget=d,g?(this.clientX=g.clientX!==void 0?g.clientX:g.pageX,this.clientY=g.clientY!==void 0?g.clientY:g.pageY,this.screenX=g.screenX||0,this.screenY=g.screenY||0):(this.clientX=c.clientX!==void 0?c.clientX:c.pageX,this.clientY=c.clientY!==void 0?c.clientY:c.pageY,this.screenX=c.screenX||0,this.screenY=c.screenY||0),this.button=c.button,this.key=c.key||"",this.ctrlKey=c.ctrlKey,this.altKey=c.altKey,this.shiftKey=c.shiftKey,this.metaKey=c.metaKey,this.pointerId=c.pointerId||0,this.pointerType=typeof c.pointerType=="string"?c.pointerType:Kb[c.pointerType]||"",this.state=c.state,this.i=c,c.defaultPrevented&&nr.aa.h.call(this)}}E(nr,ht);var Kb={2:"touch",3:"pen",4:"mouse"};nr.prototype.h=function(){nr.aa.h.call(this);var c=this.i;c.preventDefault?c.preventDefault():c.returnValue=!1};var $a="closure_listenable_"+(1e6*Math.random()|0),Hb=0;function Qb(c,d,f,g,P){this.listener=c,this.proxy=null,this.src=d,this.type=f,this.capture=!!g,this.ha=P,this.key=++Hb,this.da=this.fa=!1}function Da(c){c.da=!0,c.listener=null,c.proxy=null,c.src=null,c.ha=null}function xa(c){this.src=c,this.g={},this.h=0}xa.prototype.add=function(c,d,f,g,P){var D=c.toString();c=this.g[D],c||(c=this.g[D]=[],this.h++);var L=jc(c,d,g,P);return-1<L?(d=c[L],f||(d.fa=!1)):(d=new Qb(d,this.src,D,!!g,P),d.fa=f,c.push(d)),d};function Bc(c,d){var f=d.type;if(f in c.g){var g=c.g[f],P=Array.prototype.indexOf.call(g,d,void 0),D;(D=0<=P)&&Array.prototype.splice.call(g,P,1),D&&(Da(d),c.g[f].length==0&&(delete c.g[f],c.h--))}}function jc(c,d,f,g){for(var P=0;P<c.length;++P){var D=c[P];if(!D.da&&D.listener==d&&D.capture==!!f&&D.ha==g)return P}return-1}var Wc="closure_lm_"+(1e6*Math.random()|0),zc={};function mh(c,d,f,g,P){if(Array.isArray(d)){for(var D=0;D<d.length;D++)mh(c,d[D],f,g,P);return null}return f=vh(f),c&&c[$a]?c.K(d,f,u(g)?!!g.capture:!1,P):Jb(c,d,f,!1,g,P)}function Jb(c,d,f,g,P,D){if(!d)throw Error("Invalid event type");var L=u(P)?!!P.capture:!!P,Re=Kc(c);if(Re||(c[Wc]=Re=new xa(c)),f=Re.add(d,f,g,L,D),f.proxy)return f;if(g=Yb(),f.proxy=g,g.src=c,g.listener=f,c.addEventListener)Gb||(P=L),P===void 0&&(P=!1),c.addEventListener(d.toString(),g,P);else if(c.attachEvent)c.attachEvent(yh(d.toString()),g);else if(c.addListener&&c.removeListener)c.addListener(g);else throw Error("addEventListener and attachEvent are unavailable.");return f}function Yb(){function c(f){return d.call(c.src,c.listener,f)}const d=Xb;return c}function gh(c,d,f,g,P){if(Array.isArray(d))for(var D=0;D<d.length;D++)gh(c,d[D],f,g,P);else g=u(g)?!!g.capture:!!g,f=vh(f),c&&c[$a]?(c=c.i,d=String(d).toString(),d in c.g&&(D=c.g[d],f=jc(D,f,g,P),-1<f&&(Da(D[f]),Array.prototype.splice.call(D,f,1),D.length==0&&(delete c.g[d],c.h--)))):c&&(c=Kc(c))&&(d=c.g[d.toString()],c=-1,d&&(c=jc(d,f,g,P)),(f=-1<c?d[c]:null)&&Gc(f))}function Gc(c){if(typeof c!="number"&&c&&!c.da){var d=c.src;if(d&&d[$a])Bc(d.i,c);else{var f=c.type,g=c.proxy;d.removeEventListener?d.removeEventListener(f,g,c.capture):d.detachEvent?d.detachEvent(yh(f),g):d.addListener&&d.removeListener&&d.removeListener(g),(f=Kc(d))?(Bc(f,c),f.h==0&&(f.src=null,d[Wc]=null)):Da(c)}}}function yh(c){return c in zc?zc[c]:zc[c]="on"+c}function Xb(c,d){if(c.da)c=!0;else{d=new nr(d,this);var f=c.listener,g=c.ha||c.src;c.fa&&Gc(c),c=f.call(g,d)}return c}function Kc(c){return c=c[Wc],c instanceof xa?c:null}var Hc="__closure_events_fn_"+(1e9*Math.random()>>>0);function vh(c){return typeof c=="function"?c:(c[Hc]||(c[Hc]=function(d){return c.handleEvent(d)}),c[Hc])}function ft(){$n.call(this),this.i=new xa(this),this.M=this,this.F=null}E(ft,$n),ft.prototype[$a]=!0,ft.prototype.removeEventListener=function(c,d,f,g){gh(this,c,d,f,g)};function _t(c,d){var f,g=c.F;if(g)for(f=[];g;g=g.F)f.push(g);if(c=c.M,g=d.type||d,typeof d=="string")d=new ht(d,c);else if(d instanceof ht)d.target=d.target||c;else{var P=d;d=new ht(g,c),I(d,P)}if(P=!0,f)for(var D=f.length-1;0<=D;D--){var L=d.g=f[D];P=Na(L,g,!0,d)&&P}if(L=d.g=c,P=Na(L,g,!0,d)&&P,P=Na(L,g,!1,d)&&P,f)for(D=0;D<f.length;D++)L=d.g=f[D],P=Na(L,g,!1,d)&&P}ft.prototype.N=function(){if(ft.aa.N.call(this),this.i){var c=this.i,d;for(d in c.g){for(var f=c.g[d],g=0;g<f.length;g++)Da(f[g]);delete c.g[d],c.h--}}this.F=null},ft.prototype.K=function(c,d,f,g){return this.i.add(String(c),d,!1,f,g)},ft.prototype.L=function(c,d,f,g){return this.i.add(String(c),d,!0,f,g)};function Na(c,d,f,g){if(d=c.i.g[String(d)],!d)return!0;d=d.concat();for(var P=!0,D=0;D<d.length;++D){var L=d[D];if(L&&!L.da&&L.capture==f){var Re=L.listener,at=L.ha||L.src;L.fa&&Bc(c.i,L),P=Re.call(at,g)!==!1&&P}}return P&&!g.defaultPrevented}function bh(c,d,f){if(typeof c=="function")f&&(c=m(c,f));else if(c&&typeof c.handleEvent=="function")c=m(c.handleEvent,c);else throw Error("Invalid listener argument");return 2147483647<Number(d)?-1:o.setTimeout(c,d||0)}function _h(c){c.g=bh(()=>{c.g=null,c.i&&(c.i=!1,_h(c))},c.l);const d=c.h;c.h=null,c.m.apply(null,d)}class Zb extends $n{constructor(d,f){super(),this.m=d,this.l=f,this.h=null,this.i=!1,this.g=null}j(d){this.h=arguments,this.g?this.i=!0:_h(this)}N(){super.N(),this.g&&(o.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function sr(c){$n.call(this),this.h=c,this.g={}}E(sr,$n);var wh=[];function Ih(c){U(c.g,function(d,f){this.g.hasOwnProperty(f)&&Gc(d)},c),c.g={}}sr.prototype.N=function(){sr.aa.N.call(this),Ih(this)},sr.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Qc=o.JSON.stringify,e_=o.JSON.parse,t_=class{stringify(c){return o.JSON.stringify(c,void 0)}parse(c){return o.JSON.parse(c,void 0)}};function Jc(){}Jc.prototype.h=null;function Eh(c){return c.h||(c.h=c.i())}function Th(){}var ir={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function Yc(){ht.call(this,"d")}E(Yc,ht);function Xc(){ht.call(this,"c")}E(Xc,ht);var ms={},Ah=null;function Va(){return Ah=Ah||new ft}ms.La="serverreachability";function Sh(c){ht.call(this,ms.La,c)}E(Sh,ht);function rr(c){const d=Va();_t(d,new Sh(d))}ms.STAT_EVENT="statevent";function kh(c,d){ht.call(this,ms.STAT_EVENT,c),this.stat=d}E(kh,ht);function wt(c){const d=Va();_t(d,new kh(d,c))}ms.Ma="timingevent";function Rh(c,d){ht.call(this,ms.Ma,c),this.size=d}E(Rh,ht);function ar(c,d){if(typeof c!="function")throw Error("Fn must not be null and must be a function");return o.setTimeout(function(){c()},d)}function or(){this.g=!0}or.prototype.xa=function(){this.g=!1};function n_(c,d,f,g,P,D){c.info(function(){if(c.g)if(D)for(var L="",Re=D.split("&"),at=0;at<Re.length;at++){var _e=Re[at].split("=");if(1<_e.length){var pt=_e[0];_e=_e[1];var mt=pt.split("_");L=2<=mt.length&&mt[1]=="type"?L+(pt+"="+_e+"&"):L+(pt+"=redacted&")}}else L=null;else L=D;return"XMLHTTP REQ ("+g+") [attempt "+P+"]: "+d+`
`+f+`
`+L})}function s_(c,d,f,g,P,D,L){c.info(function(){return"XMLHTTP RESP ("+g+") [ attempt "+P+"]: "+d+`
`+f+`
`+D+" "+L})}function Js(c,d,f,g){c.info(function(){return"XMLHTTP TEXT ("+d+"): "+r_(c,f)+(g?" "+g:"")})}function i_(c,d){c.info(function(){return"TIMEOUT: "+d})}or.prototype.info=function(){};function r_(c,d){if(!c.g)return d;if(!d)return null;try{var f=JSON.parse(d);if(f){for(c=0;c<f.length;c++)if(Array.isArray(f[c])){var g=f[c];if(!(2>g.length)){var P=g[1];if(Array.isArray(P)&&!(1>P.length)){var D=P[0];if(D!="noop"&&D!="stop"&&D!="close")for(var L=1;L<P.length;L++)P[L]=""}}}}return Qc(f)}catch{return d}}var Oa={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},Ph={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},Zc;function Ma(){}E(Ma,Jc),Ma.prototype.g=function(){return new XMLHttpRequest},Ma.prototype.i=function(){return{}},Zc=new Ma;function Dn(c,d,f,g){this.j=c,this.i=d,this.l=f,this.R=g||1,this.U=new sr(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new Ch}function Ch(){this.i=null,this.g="",this.h=!1}var $h={},el={};function tl(c,d,f){c.L=1,c.v=qa(hn(d)),c.m=f,c.P=!0,Dh(c,null)}function Dh(c,d){c.F=Date.now(),La(c),c.A=hn(c.v);var f=c.A,g=c.R;Array.isArray(g)||(g=[String(g)]),Gh(f.i,"t",g),c.C=0,f=c.j.J,c.h=new Ch,c.g=df(c.j,f?d:null,!c.m),0<c.O&&(c.M=new Zb(m(c.Y,c,c.g),c.O)),d=c.U,f=c.g,g=c.ca;var P="readystatechange";Array.isArray(P)||(P&&(wh[0]=P.toString()),P=wh);for(var D=0;D<P.length;D++){var L=mh(f,P[D],g||d.handleEvent,!1,d.h||d);if(!L)break;d.g[L.key]=L}d=c.H?y(c.H):{},c.m?(c.u||(c.u="POST"),d["Content-Type"]="application/x-www-form-urlencoded",c.g.ea(c.A,c.u,c.m,d)):(c.u="GET",c.g.ea(c.A,c.u,null,d)),rr(),n_(c.i,c.u,c.A,c.l,c.R,c.m)}Dn.prototype.ca=function(c){c=c.target;const d=this.M;d&&fn(c)==3?d.j():this.Y(c)},Dn.prototype.Y=function(c){try{if(c==this.g)e:{const mt=fn(this.g);var d=this.g.Ba();const Zs=this.g.Z();if(!(3>mt)&&(mt!=3||this.g&&(this.h.h||this.g.oa()||Zh(this.g)))){this.J||mt!=4||d==7||(d==8||0>=Zs?rr(3):rr(2)),nl(this);var f=this.g.Z();this.X=f;t:if(xh(this)){var g=Zh(this.g);c="";var P=g.length,D=fn(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){gs(this),cr(this);var L="";break t}this.h.i=new o.TextDecoder}for(d=0;d<P;d++)this.h.h=!0,c+=this.h.i.decode(g[d],{stream:!(D&&d==P-1)});g.length=0,this.h.g+=c,this.C=0,L=this.h.g}else L=this.g.oa();if(this.o=f==200,s_(this.i,this.u,this.A,this.l,this.R,mt,f),this.o){if(this.T&&!this.K){t:{if(this.g){var Re,at=this.g;if((Re=at.g?at.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!J(Re)){var _e=Re;break t}}_e=null}if(f=_e)Js(this.i,this.l,f,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,sl(this,f);else{this.o=!1,this.s=3,wt(12),gs(this),cr(this);break e}}if(this.P){f=!0;let qt;for(;!this.J&&this.C<L.length;)if(qt=a_(this,L),qt==el){mt==4&&(this.s=4,wt(14),f=!1),Js(this.i,this.l,null,"[Incomplete Response]");break}else if(qt==$h){this.s=4,wt(15),Js(this.i,this.l,L,"[Invalid Chunk]"),f=!1;break}else Js(this.i,this.l,qt,null),sl(this,qt);if(xh(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),mt!=4||L.length!=0||this.h.h||(this.s=1,wt(16),f=!1),this.o=this.o&&f,!f)Js(this.i,this.l,L,"[Invalid Chunked Response]"),gs(this),cr(this);else if(0<L.length&&!this.W){this.W=!0;var pt=this.j;pt.g==this&&pt.ba&&!pt.M&&(pt.j.info("Great, no buffering proxy detected. Bytes received: "+L.length),ll(pt),pt.M=!0,wt(11))}}else Js(this.i,this.l,L,null),sl(this,L);mt==4&&gs(this),this.o&&!this.J&&(mt==4?of(this.j,this):(this.o=!1,La(this)))}else E_(this.g),f==400&&0<L.indexOf("Unknown SID")?(this.s=3,wt(12)):(this.s=0,wt(13)),gs(this),cr(this)}}}catch{}finally{}};function xh(c){return c.g?c.u=="GET"&&c.L!=2&&c.j.Ca:!1}function a_(c,d){var f=c.C,g=d.indexOf(`
`,f);return g==-1?el:(f=Number(d.substring(f,g)),isNaN(f)?$h:(g+=1,g+f>d.length?el:(d=d.slice(g,g+f),c.C=g+f,d)))}Dn.prototype.cancel=function(){this.J=!0,gs(this)};function La(c){c.S=Date.now()+c.I,Nh(c,c.I)}function Nh(c,d){if(c.B!=null)throw Error("WatchDog timer not null");c.B=ar(m(c.ba,c),d)}function nl(c){c.B&&(o.clearTimeout(c.B),c.B=null)}Dn.prototype.ba=function(){this.B=null;const c=Date.now();0<=c-this.S?(i_(this.i,this.A),this.L!=2&&(rr(),wt(17)),gs(this),this.s=2,cr(this)):Nh(this,this.S-c)};function cr(c){c.j.G==0||c.J||of(c.j,c)}function gs(c){nl(c);var d=c.M;d&&typeof d.ma=="function"&&d.ma(),c.M=null,Ih(c.U),c.g&&(d=c.g,c.g=null,d.abort(),d.ma())}function sl(c,d){try{var f=c.j;if(f.G!=0&&(f.g==c||il(f.h,c))){if(!c.K&&il(f.h,c)&&f.G==3){try{var g=f.Da.g.parse(d)}catch{g=null}if(Array.isArray(g)&&g.length==3){var P=g;if(P[0]==0){e:if(!f.u){if(f.g)if(f.g.F+3e3<c.F)Ga(f),Wa(f);else break e;cl(f),wt(18)}}else f.za=P[1],0<f.za-f.T&&37500>P[2]&&f.F&&f.v==0&&!f.C&&(f.C=ar(m(f.Za,f),6e3));if(1>=Mh(f.h)&&f.ca){try{f.ca()}catch{}f.ca=void 0}}else vs(f,11)}else if((c.K||f.g==c)&&Ga(f),!J(d))for(P=f.Da.g.parse(d),d=0;d<P.length;d++){let _e=P[d];if(f.T=_e[0],_e=_e[1],f.G==2)if(_e[0]=="c"){f.K=_e[1],f.ia=_e[2];const pt=_e[3];pt!=null&&(f.la=pt,f.j.info("VER="+f.la));const mt=_e[4];mt!=null&&(f.Aa=mt,f.j.info("SVER="+f.Aa));const Zs=_e[5];Zs!=null&&typeof Zs=="number"&&0<Zs&&(g=1.5*Zs,f.L=g,f.j.info("backChannelRequestTimeoutMs_="+g)),g=f;const qt=c.g;if(qt){const Ha=qt.g?qt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Ha){var D=g.h;D.g||Ha.indexOf("spdy")==-1&&Ha.indexOf("quic")==-1&&Ha.indexOf("h2")==-1||(D.j=D.l,D.g=new Set,D.h&&(rl(D,D.h),D.h=null))}if(g.D){const ul=qt.g?qt.g.getResponseHeader("X-HTTP-Session-Id"):null;ul&&(g.ya=ul,Ve(g.I,g.D,ul))}}f.G=3,f.l&&f.l.ua(),f.ba&&(f.R=Date.now()-c.F,f.j.info("Handshake RTT: "+f.R+"ms")),g=f;var L=c;if(g.qa=uf(g,g.J?g.ia:null,g.W),L.K){Lh(g.h,L);var Re=L,at=g.L;at&&(Re.I=at),Re.B&&(nl(Re),La(Re)),g.g=L}else rf(g);0<f.i.length&&za(f)}else _e[0]!="stop"&&_e[0]!="close"||vs(f,7);else f.G==3&&(_e[0]=="stop"||_e[0]=="close"?_e[0]=="stop"?vs(f,7):ol(f):_e[0]!="noop"&&f.l&&f.l.ta(_e),f.v=0)}}rr(4)}catch{}}var o_=class{constructor(c,d){this.g=c,this.map=d}};function Vh(c){this.l=c||10,o.PerformanceNavigationTiming?(c=o.performance.getEntriesByType("navigation"),c=0<c.length&&(c[0].nextHopProtocol=="hq"||c[0].nextHopProtocol=="h2")):c=!!(o.chrome&&o.chrome.loadTimes&&o.chrome.loadTimes()&&o.chrome.loadTimes().wasFetchedViaSpdy),this.j=c?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function Oh(c){return c.h?!0:c.g?c.g.size>=c.j:!1}function Mh(c){return c.h?1:c.g?c.g.size:0}function il(c,d){return c.h?c.h==d:c.g?c.g.has(d):!1}function rl(c,d){c.g?c.g.add(d):c.h=d}function Lh(c,d){c.h&&c.h==d?c.h=null:c.g&&c.g.has(d)&&c.g.delete(d)}Vh.prototype.cancel=function(){if(this.i=Fh(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const c of this.g.values())c.cancel();this.g.clear()}};function Fh(c){if(c.h!=null)return c.i.concat(c.h.D);if(c.g!=null&&c.g.size!==0){let d=c.i;for(const f of c.g.values())d=d.concat(f.D);return d}return x(c.i)}function c_(c){if(c.V&&typeof c.V=="function")return c.V();if(typeof Map<"u"&&c instanceof Map||typeof Set<"u"&&c instanceof Set)return Array.from(c.values());if(typeof c=="string")return c.split("");if(l(c)){for(var d=[],f=c.length,g=0;g<f;g++)d.push(c[g]);return d}d=[],f=0;for(g in c)d[f++]=c[g];return d}function l_(c){if(c.na&&typeof c.na=="function")return c.na();if(!c.V||typeof c.V!="function"){if(typeof Map<"u"&&c instanceof Map)return Array.from(c.keys());if(!(typeof Set<"u"&&c instanceof Set)){if(l(c)||typeof c=="string"){var d=[];c=c.length;for(var f=0;f<c;f++)d.push(f);return d}d=[],f=0;for(const g in c)d[f++]=g;return d}}}function Uh(c,d){if(c.forEach&&typeof c.forEach=="function")c.forEach(d,void 0);else if(l(c)||typeof c=="string")Array.prototype.forEach.call(c,d,void 0);else for(var f=l_(c),g=c_(c),P=g.length,D=0;D<P;D++)d.call(void 0,g[D],f&&f[D],c)}var qh=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function u_(c,d){if(c){c=c.split("&");for(var f=0;f<c.length;f++){var g=c[f].indexOf("="),P=null;if(0<=g){var D=c[f].substring(0,g);P=c[f].substring(g+1)}else D=c[f];d(D,P?decodeURIComponent(P.replace(/\+/g," ")):"")}}}function ys(c){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,c instanceof ys){this.h=c.h,Fa(this,c.j),this.o=c.o,this.g=c.g,Ua(this,c.s),this.l=c.l;var d=c.i,f=new dr;f.i=d.i,d.g&&(f.g=new Map(d.g),f.h=d.h),Bh(this,f),this.m=c.m}else c&&(d=String(c).match(qh))?(this.h=!1,Fa(this,d[1]||"",!0),this.o=lr(d[2]||""),this.g=lr(d[3]||"",!0),Ua(this,d[4]),this.l=lr(d[5]||"",!0),Bh(this,d[6]||"",!0),this.m=lr(d[7]||"")):(this.h=!1,this.i=new dr(null,this.h))}ys.prototype.toString=function(){var c=[],d=this.j;d&&c.push(ur(d,jh,!0),":");var f=this.g;return(f||d=="file")&&(c.push("//"),(d=this.o)&&c.push(ur(d,jh,!0),"@"),c.push(encodeURIComponent(String(f)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.s,f!=null&&c.push(":",String(f))),(f=this.l)&&(this.g&&f.charAt(0)!="/"&&c.push("/"),c.push(ur(f,f.charAt(0)=="/"?f_:h_,!0))),(f=this.i.toString())&&c.push("?",f),(f=this.m)&&c.push("#",ur(f,m_)),c.join("")};function hn(c){return new ys(c)}function Fa(c,d,f){c.j=f?lr(d,!0):d,c.j&&(c.j=c.j.replace(/:$/,""))}function Ua(c,d){if(d){if(d=Number(d),isNaN(d)||0>d)throw Error("Bad port number "+d);c.s=d}else c.s=null}function Bh(c,d,f){d instanceof dr?(c.i=d,g_(c.i,c.h)):(f||(d=ur(d,p_)),c.i=new dr(d,c.h))}function Ve(c,d,f){c.i.set(d,f)}function qa(c){return Ve(c,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),c}function lr(c,d){return c?d?decodeURI(c.replace(/%25/g,"%2525")):decodeURIComponent(c):""}function ur(c,d,f){return typeof c=="string"?(c=encodeURI(c).replace(d,d_),f&&(c=c.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c):null}function d_(c){return c=c.charCodeAt(0),"%"+(c>>4&15).toString(16)+(c&15).toString(16)}var jh=/[#\/\?@]/g,h_=/[#\?:]/g,f_=/[#\?]/g,p_=/[#\?@]/g,m_=/#/g;function dr(c,d){this.h=this.g=null,this.i=c||null,this.j=!!d}function xn(c){c.g||(c.g=new Map,c.h=0,c.i&&u_(c.i,function(d,f){c.add(decodeURIComponent(d.replace(/\+/g," ")),f)}))}n=dr.prototype,n.add=function(c,d){xn(this),this.i=null,c=Ys(this,c);var f=this.g.get(c);return f||this.g.set(c,f=[]),f.push(d),this.h+=1,this};function Wh(c,d){xn(c),d=Ys(c,d),c.g.has(d)&&(c.i=null,c.h-=c.g.get(d).length,c.g.delete(d))}function zh(c,d){return xn(c),d=Ys(c,d),c.g.has(d)}n.forEach=function(c,d){xn(this),this.g.forEach(function(f,g){f.forEach(function(P){c.call(d,P,g,this)},this)},this)},n.na=function(){xn(this);const c=Array.from(this.g.values()),d=Array.from(this.g.keys()),f=[];for(let g=0;g<d.length;g++){const P=c[g];for(let D=0;D<P.length;D++)f.push(d[g])}return f},n.V=function(c){xn(this);let d=[];if(typeof c=="string")zh(this,c)&&(d=d.concat(this.g.get(Ys(this,c))));else{c=Array.from(this.g.values());for(let f=0;f<c.length;f++)d=d.concat(c[f])}return d},n.set=function(c,d){return xn(this),this.i=null,c=Ys(this,c),zh(this,c)&&(this.h-=this.g.get(c).length),this.g.set(c,[d]),this.h+=1,this},n.get=function(c,d){return c?(c=this.V(c),0<c.length?String(c[0]):d):d};function Gh(c,d,f){Wh(c,d),0<f.length&&(c.i=null,c.g.set(Ys(c,d),x(f)),c.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const c=[],d=Array.from(this.g.keys());for(var f=0;f<d.length;f++){var g=d[f];const D=encodeURIComponent(String(g)),L=this.V(g);for(g=0;g<L.length;g++){var P=D;L[g]!==""&&(P+="="+encodeURIComponent(String(L[g]))),c.push(P)}}return this.i=c.join("&")};function Ys(c,d){return d=String(d),c.j&&(d=d.toLowerCase()),d}function g_(c,d){d&&!c.j&&(xn(c),c.i=null,c.g.forEach(function(f,g){var P=g.toLowerCase();g!=P&&(Wh(this,g),Gh(this,P,f))},c)),c.j=d}function y_(c,d){const f=new or;if(o.Image){const g=new Image;g.onload=w(Nn,f,"TestLoadImage: loaded",!0,d,g),g.onerror=w(Nn,f,"TestLoadImage: error",!1,d,g),g.onabort=w(Nn,f,"TestLoadImage: abort",!1,d,g),g.ontimeout=w(Nn,f,"TestLoadImage: timeout",!1,d,g),o.setTimeout(function(){g.ontimeout&&g.ontimeout()},1e4),g.src=c}else d(!1)}function v_(c,d){const f=new or,g=new AbortController,P=setTimeout(()=>{g.abort(),Nn(f,"TestPingServer: timeout",!1,d)},1e4);fetch(c,{signal:g.signal}).then(D=>{clearTimeout(P),D.ok?Nn(f,"TestPingServer: ok",!0,d):Nn(f,"TestPingServer: server error",!1,d)}).catch(()=>{clearTimeout(P),Nn(f,"TestPingServer: error",!1,d)})}function Nn(c,d,f,g,P){try{P&&(P.onload=null,P.onerror=null,P.onabort=null,P.ontimeout=null),g(f)}catch{}}function b_(){this.g=new t_}function __(c,d,f){const g=f||"";try{Uh(c,function(P,D){let L=P;u(P)&&(L=Qc(P)),d.push(g+D+"="+encodeURIComponent(L))})}catch(P){throw d.push(g+"type="+encodeURIComponent("_badmap")),P}}function hr(c){this.l=c.Ub||null,this.j=c.eb||!1}E(hr,Jc),hr.prototype.g=function(){return new Ba(this.l,this.j)},hr.prototype.i=function(c){return function(){return c}}({});function Ba(c,d){ft.call(this),this.D=c,this.o=d,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}E(Ba,ft),n=Ba.prototype,n.open=function(c,d){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=c,this.A=d,this.readyState=1,pr(this)},n.send=function(c){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const d={headers:this.u,method:this.B,credentials:this.m,cache:void 0};c&&(d.body=c),(this.D||o).fetch(new Request(this.A,d)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,fr(this)),this.readyState=0},n.Sa=function(c){if(this.g&&(this.l=c,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=c.headers,this.readyState=2,pr(this)),this.g&&(this.readyState=3,pr(this),this.g)))if(this.responseType==="arraybuffer")c.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof o.ReadableStream<"u"&&"body"in c){if(this.j=c.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;Kh(this)}else c.text().then(this.Ra.bind(this),this.ga.bind(this))};function Kh(c){c.j.read().then(c.Pa.bind(c)).catch(c.ga.bind(c))}n.Pa=function(c){if(this.g){if(this.o&&c.value)this.response.push(c.value);else if(!this.o){var d=c.value?c.value:new Uint8Array(0);(d=this.v.decode(d,{stream:!c.done}))&&(this.response=this.responseText+=d)}c.done?fr(this):pr(this),this.readyState==3&&Kh(this)}},n.Ra=function(c){this.g&&(this.response=this.responseText=c,fr(this))},n.Qa=function(c){this.g&&(this.response=c,fr(this))},n.ga=function(){this.g&&fr(this)};function fr(c){c.readyState=4,c.l=null,c.j=null,c.v=null,pr(c)}n.setRequestHeader=function(c,d){this.u.append(c,d)},n.getResponseHeader=function(c){return this.h&&this.h.get(c.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const c=[],d=this.h.entries();for(var f=d.next();!f.done;)f=f.value,c.push(f[0]+": "+f[1]),f=d.next();return c.join(`\r
`)};function pr(c){c.onreadystatechange&&c.onreadystatechange.call(c)}Object.defineProperty(Ba.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(c){this.m=c?"include":"same-origin"}});function Hh(c){let d="";return U(c,function(f,g){d+=g,d+=":",d+=f,d+=`\r
`}),d}function al(c,d,f){e:{for(g in f){var g=!1;break e}g=!0}g||(f=Hh(f),typeof c=="string"?f!=null&&encodeURIComponent(String(f)):Ve(c,d,f))}function qe(c){ft.call(this),this.headers=new Map,this.o=c||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}E(qe,ft);var w_=/^https?$/i,I_=["POST","PUT"];n=qe.prototype,n.Ha=function(c){this.J=c},n.ea=function(c,d,f,g){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+c);d=d?d.toUpperCase():"GET",this.D=c,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():Zc.g(),this.v=this.o?Eh(this.o):Eh(Zc),this.g.onreadystatechange=m(this.Ea,this);try{this.B=!0,this.g.open(d,String(c),!0),this.B=!1}catch(D){Qh(this,D);return}if(c=f||"",f=new Map(this.headers),g)if(Object.getPrototypeOf(g)===Object.prototype)for(var P in g)f.set(P,g[P]);else if(typeof g.keys=="function"&&typeof g.get=="function")for(const D of g.keys())f.set(D,g.get(D));else throw Error("Unknown input type for opt_headers: "+String(g));g=Array.from(f.keys()).find(D=>D.toLowerCase()=="content-type"),P=o.FormData&&c instanceof o.FormData,!(0<=Array.prototype.indexOf.call(I_,d,void 0))||g||P||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[D,L]of f)this.g.setRequestHeader(D,L);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{Xh(this),this.u=!0,this.g.send(c),this.u=!1}catch(D){Qh(this,D)}};function Qh(c,d){c.h=!1,c.g&&(c.j=!0,c.g.abort(),c.j=!1),c.l=d,c.m=5,Jh(c),ja(c)}function Jh(c){c.A||(c.A=!0,_t(c,"complete"),_t(c,"error"))}n.abort=function(c){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=c||7,_t(this,"complete"),_t(this,"abort"),ja(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),ja(this,!0)),qe.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?Yh(this):this.bb())},n.bb=function(){Yh(this)};function Yh(c){if(c.h&&typeof a<"u"&&(!c.v[1]||fn(c)!=4||c.Z()!=2)){if(c.u&&fn(c)==4)bh(c.Ea,0,c);else if(_t(c,"readystatechange"),fn(c)==4){c.h=!1;try{const L=c.Z();e:switch(L){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var d=!0;break e;default:d=!1}var f;if(!(f=d)){var g;if(g=L===0){var P=String(c.D).match(qh)[1]||null;!P&&o.self&&o.self.location&&(P=o.self.location.protocol.slice(0,-1)),g=!w_.test(P?P.toLowerCase():"")}f=g}if(f)_t(c,"complete"),_t(c,"success");else{c.m=6;try{var D=2<fn(c)?c.g.statusText:""}catch{D=""}c.l=D+" ["+c.Z()+"]",Jh(c)}}finally{ja(c)}}}}function ja(c,d){if(c.g){Xh(c);const f=c.g,g=c.v[0]?()=>{}:null;c.g=null,c.v=null,d||_t(c,"ready");try{f.onreadystatechange=g}catch{}}}function Xh(c){c.I&&(o.clearTimeout(c.I),c.I=null)}n.isActive=function(){return!!this.g};function fn(c){return c.g?c.g.readyState:0}n.Z=function(){try{return 2<fn(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(c){if(this.g){var d=this.g.responseText;return c&&d.indexOf(c)==0&&(d=d.substring(c.length)),e_(d)}};function Zh(c){try{if(!c.g)return null;if("response"in c.g)return c.g.response;switch(c.H){case"":case"text":return c.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in c.g)return c.g.mozResponseArrayBuffer}return null}catch{return null}}function E_(c){const d={};c=(c.g&&2<=fn(c)&&c.g.getAllResponseHeaders()||"").split(`\r
`);for(let g=0;g<c.length;g++){if(J(c[g]))continue;var f=T(c[g]);const P=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const D=d[P]||[];d[P]=D,D.push(f)}_(d,function(g){return g.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function mr(c,d,f){return f&&f.internalChannelParams&&f.internalChannelParams[c]||d}function ef(c){this.Aa=0,this.i=[],this.j=new or,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=mr("failFast",!1,c),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=mr("baseRetryDelayMs",5e3,c),this.cb=mr("retryDelaySeedMs",1e4,c),this.Wa=mr("forwardChannelMaxRetries",2,c),this.wa=mr("forwardChannelRequestTimeoutMs",2e4,c),this.pa=c&&c.xmlHttpFactory||void 0,this.Xa=c&&c.Tb||void 0,this.Ca=c&&c.useFetchStreams||!1,this.L=void 0,this.J=c&&c.supportsCrossDomainXhr||!1,this.K="",this.h=new Vh(c&&c.concurrentRequestLimit),this.Da=new b_,this.P=c&&c.fastHandshake||!1,this.O=c&&c.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=c&&c.Rb||!1,c&&c.xa&&this.j.xa(),c&&c.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&c&&c.detectBufferingProxy||!1,this.ja=void 0,c&&c.longPollingTimeout&&0<c.longPollingTimeout&&(this.ja=c.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=ef.prototype,n.la=8,n.G=1,n.connect=function(c,d,f,g){wt(0),this.W=c,this.H=d||{},f&&g!==void 0&&(this.H.OSID=f,this.H.OAID=g),this.F=this.X,this.I=uf(this,null,this.W),za(this)};function ol(c){if(tf(c),c.G==3){var d=c.U++,f=hn(c.I);if(Ve(f,"SID",c.K),Ve(f,"RID",d),Ve(f,"TYPE","terminate"),gr(c,f),d=new Dn(c,c.j,d),d.L=2,d.v=qa(hn(f)),f=!1,o.navigator&&o.navigator.sendBeacon)try{f=o.navigator.sendBeacon(d.v.toString(),"")}catch{}!f&&o.Image&&(new Image().src=d.v,f=!0),f||(d.g=df(d.j,null),d.g.ea(d.v)),d.F=Date.now(),La(d)}lf(c)}function Wa(c){c.g&&(ll(c),c.g.cancel(),c.g=null)}function tf(c){Wa(c),c.u&&(o.clearTimeout(c.u),c.u=null),Ga(c),c.h.cancel(),c.s&&(typeof c.s=="number"&&o.clearTimeout(c.s),c.s=null)}function za(c){if(!Oh(c.h)&&!c.s){c.s=!0;var d=c.Ga;er||ph(),tr||(er(),tr=!0),qc.add(d,c),c.B=0}}function T_(c,d){return Mh(c.h)>=c.h.j-(c.s?1:0)?!1:c.s?(c.i=d.D.concat(c.i),!0):c.G==1||c.G==2||c.B>=(c.Va?0:c.Wa)?!1:(c.s=ar(m(c.Ga,c,d),cf(c,c.B)),c.B++,!0)}n.Ga=function(c){if(this.s)if(this.s=null,this.G==1){if(!c){this.U=Math.floor(1e5*Math.random()),c=this.U++;const P=new Dn(this,this.j,c);let D=this.o;if(this.S&&(D?(D=y(D),I(D,this.S)):D=this.S),this.m!==null||this.O||(P.H=D,D=null),this.P)e:{for(var d=0,f=0;f<this.i.length;f++){t:{var g=this.i[f];if("__data__"in g.map&&(g=g.map.__data__,typeof g=="string")){g=g.length;break t}g=void 0}if(g===void 0)break;if(d+=g,4096<d){d=f;break e}if(d===4096||f===this.i.length-1){d=f+1;break e}}d=1e3}else d=1e3;d=sf(this,P,d),f=hn(this.I),Ve(f,"RID",c),Ve(f,"CVER",22),this.D&&Ve(f,"X-HTTP-Session-Id",this.D),gr(this,f),D&&(this.O?d="headers="+encodeURIComponent(String(Hh(D)))+"&"+d:this.m&&al(f,this.m,D)),rl(this.h,P),this.Ua&&Ve(f,"TYPE","init"),this.P?(Ve(f,"$req",d),Ve(f,"SID","null"),P.T=!0,tl(P,f,null)):tl(P,f,d),this.G=2}}else this.G==3&&(c?nf(this,c):this.i.length==0||Oh(this.h)||nf(this))};function nf(c,d){var f;d?f=d.l:f=c.U++;const g=hn(c.I);Ve(g,"SID",c.K),Ve(g,"RID",f),Ve(g,"AID",c.T),gr(c,g),c.m&&c.o&&al(g,c.m,c.o),f=new Dn(c,c.j,f,c.B+1),c.m===null&&(f.H=c.o),d&&(c.i=d.D.concat(c.i)),d=sf(c,f,1e3),f.I=Math.round(.5*c.wa)+Math.round(.5*c.wa*Math.random()),rl(c.h,f),tl(f,g,d)}function gr(c,d){c.H&&U(c.H,function(f,g){Ve(d,g,f)}),c.l&&Uh({},function(f,g){Ve(d,g,f)})}function sf(c,d,f){f=Math.min(c.i.length,f);var g=c.l?m(c.l.Na,c.l,c):null;e:{var P=c.i;let D=-1;for(;;){const L=["count="+f];D==-1?0<f?(D=P[0].g,L.push("ofs="+D)):D=0:L.push("ofs="+D);let Re=!0;for(let at=0;at<f;at++){let _e=P[at].g;const pt=P[at].map;if(_e-=D,0>_e)D=Math.max(0,P[at].g-100),Re=!1;else try{__(pt,L,"req"+_e+"_")}catch{g&&g(pt)}}if(Re){g=L.join("&");break e}}}return c=c.i.splice(0,f),d.D=c,g}function rf(c){if(!c.g&&!c.u){c.Y=1;var d=c.Fa;er||ph(),tr||(er(),tr=!0),qc.add(d,c),c.v=0}}function cl(c){return c.g||c.u||3<=c.v?!1:(c.Y++,c.u=ar(m(c.Fa,c),cf(c,c.v)),c.v++,!0)}n.Fa=function(){if(this.u=null,af(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var c=2*this.R;this.j.info("BP detection timer enabled: "+c),this.A=ar(m(this.ab,this),c)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,wt(10),Wa(this),af(this))};function ll(c){c.A!=null&&(o.clearTimeout(c.A),c.A=null)}function af(c){c.g=new Dn(c,c.j,"rpc",c.Y),c.m===null&&(c.g.H=c.o),c.g.O=0;var d=hn(c.qa);Ve(d,"RID","rpc"),Ve(d,"SID",c.K),Ve(d,"AID",c.T),Ve(d,"CI",c.F?"0":"1"),!c.F&&c.ja&&Ve(d,"TO",c.ja),Ve(d,"TYPE","xmlhttp"),gr(c,d),c.m&&c.o&&al(d,c.m,c.o),c.L&&(c.g.I=c.L);var f=c.g;c=c.ia,f.L=1,f.v=qa(hn(d)),f.m=null,f.P=!0,Dh(f,c)}n.Za=function(){this.C!=null&&(this.C=null,Wa(this),cl(this),wt(19))};function Ga(c){c.C!=null&&(o.clearTimeout(c.C),c.C=null)}function of(c,d){var f=null;if(c.g==d){Ga(c),ll(c),c.g=null;var g=2}else if(il(c.h,d))f=d.D,Lh(c.h,d),g=1;else return;if(c.G!=0){if(d.o)if(g==1){f=d.m?d.m.length:0,d=Date.now()-d.F;var P=c.B;g=Va(),_t(g,new Rh(g,f)),za(c)}else rf(c);else if(P=d.s,P==3||P==0&&0<d.X||!(g==1&&T_(c,d)||g==2&&cl(c)))switch(f&&0<f.length&&(d=c.h,d.i=d.i.concat(f)),P){case 1:vs(c,5);break;case 4:vs(c,10);break;case 3:vs(c,6);break;default:vs(c,2)}}}function cf(c,d){let f=c.Ta+Math.floor(Math.random()*c.cb);return c.isActive()||(f*=2),f*d}function vs(c,d){if(c.j.info("Error code "+d),d==2){var f=m(c.fb,c),g=c.Xa;const P=!g;g=new ys(g||"//www.google.com/images/cleardot.gif"),o.location&&o.location.protocol=="http"||Fa(g,"https"),qa(g),P?y_(g.toString(),f):v_(g.toString(),f)}else wt(2);c.G=0,c.l&&c.l.sa(d),lf(c),tf(c)}n.fb=function(c){c?(this.j.info("Successfully pinged google.com"),wt(2)):(this.j.info("Failed to ping google.com"),wt(1))};function lf(c){if(c.G=0,c.ka=[],c.l){const d=Fh(c.h);(d.length!=0||c.i.length!=0)&&(C(c.ka,d),C(c.ka,c.i),c.h.i.length=0,x(c.i),c.i.length=0),c.l.ra()}}function uf(c,d,f){var g=f instanceof ys?hn(f):new ys(f);if(g.g!="")d&&(g.g=d+"."+g.g),Ua(g,g.s);else{var P=o.location;g=P.protocol,d=d?d+"."+P.hostname:P.hostname,P=+P.port;var D=new ys(null);g&&Fa(D,g),d&&(D.g=d),P&&Ua(D,P),f&&(D.l=f),g=D}return f=c.D,d=c.ya,f&&d&&Ve(g,f,d),Ve(g,"VER",c.la),gr(c,g),g}function df(c,d,f){if(d&&!c.J)throw Error("Can't create secondary domain capable XhrIo object.");return d=c.Ca&&!c.pa?new qe(new hr({eb:f})):new qe(c.pa),d.Ha(c.J),d}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function hf(){}n=hf.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function Ka(){}Ka.prototype.g=function(c,d){return new Dt(c,d)};function Dt(c,d){ft.call(this),this.g=new ef(d),this.l=c,this.h=d&&d.messageUrlParams||null,c=d&&d.messageHeaders||null,d&&d.clientProtocolHeaderRequired&&(c?c["X-Client-Protocol"]="webchannel":c={"X-Client-Protocol":"webchannel"}),this.g.o=c,c=d&&d.initMessageHeaders||null,d&&d.messageContentType&&(c?c["X-WebChannel-Content-Type"]=d.messageContentType:c={"X-WebChannel-Content-Type":d.messageContentType}),d&&d.va&&(c?c["X-WebChannel-Client-Profile"]=d.va:c={"X-WebChannel-Client-Profile":d.va}),this.g.S=c,(c=d&&d.Sb)&&!J(c)&&(this.g.m=c),this.v=d&&d.supportsCrossDomainXhr||!1,this.u=d&&d.sendRawJson||!1,(d=d&&d.httpSessionIdParam)&&!J(d)&&(this.g.D=d,c=this.h,c!==null&&d in c&&(c=this.h,d in c&&delete c[d])),this.j=new Xs(this)}E(Dt,ft),Dt.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},Dt.prototype.close=function(){ol(this.g)},Dt.prototype.o=function(c){var d=this.g;if(typeof c=="string"){var f={};f.__data__=c,c=f}else this.u&&(f={},f.__data__=Qc(c),c=f);d.i.push(new o_(d.Ya++,c)),d.G==3&&za(d)},Dt.prototype.N=function(){this.g.l=null,delete this.j,ol(this.g),delete this.g,Dt.aa.N.call(this)};function ff(c){Yc.call(this),c.__headers__&&(this.headers=c.__headers__,this.statusCode=c.__status__,delete c.__headers__,delete c.__status__);var d=c.__sm__;if(d){e:{for(const f in d){c=f;break e}c=void 0}(this.i=c)&&(c=this.i,d=d!==null&&c in d?d[c]:void 0),this.data=d}else this.data=c}E(ff,Yc);function pf(){Xc.call(this),this.status=1}E(pf,Xc);function Xs(c){this.g=c}E(Xs,hf),Xs.prototype.ua=function(){_t(this.g,"a")},Xs.prototype.ta=function(c){_t(this.g,new ff(c))},Xs.prototype.sa=function(c){_t(this.g,new pf)},Xs.prototype.ra=function(){_t(this.g,"b")},Ka.prototype.createWebChannel=Ka.prototype.g,Dt.prototype.send=Dt.prototype.o,Dt.prototype.open=Dt.prototype.m,Dt.prototype.close=Dt.prototype.close,jg=function(){return new Ka},Bg=function(){return Va()},qg=ms,Gl={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Oa.NO_ERROR=0,Oa.TIMEOUT=8,Oa.HTTP_ERROR=6,fo=Oa,Ph.COMPLETE="complete",Ug=Ph,Th.EventType=ir,ir.OPEN="a",ir.CLOSE="b",ir.ERROR="c",ir.MESSAGE="d",ft.prototype.listen=ft.prototype.K,kr=Th,Fg=hr,qe.prototype.listenOnce=qe.prototype.L,qe.prototype.getLastError=qe.prototype.Ka,qe.prototype.getLastErrorCode=qe.prototype.Ba,qe.prototype.getStatus=qe.prototype.Z,qe.prototype.getResponseJson=qe.prototype.Oa,qe.prototype.getResponseText=qe.prototype.oa,qe.prototype.send=qe.prototype.ea,qe.prototype.setWithCredentials=qe.prototype.Ha,Lg=qe}).apply(typeof Ja<"u"?Ja:typeof self<"u"?self:typeof window<"u"?window:{});const Gf="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yt{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}yt.UNAUTHENTICATED=new yt(null),yt.GOOGLE_CREDENTIALS=new yt("google-credentials-uid"),yt.FIRST_PARTY=new yt("first-party-uid"),yt.MOCK_USER=new yt("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ki="10.12.1";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vs=new Pu("@firebase/firestore");function li(){return Vs.logLevel}function V(n,...e){if(Vs.logLevel<=de.DEBUG){const t=e.map(qu);Vs.debug(`Firestore (${Ki}): ${n}`,...t)}}function He(n,...e){if(Vs.logLevel<=de.ERROR){const t=e.map(qu);Vs.error(`Firestore (${Ki}): ${n}`,...t)}}function Hr(n,...e){if(Vs.logLevel<=de.WARN){const t=e.map(qu);Vs.warn(`Firestore (${Ki}): ${n}`,...t)}}function qu(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function K(n="Unexpected state"){const e=`FIRESTORE (${Ki}) INTERNAL ASSERTION FAILED: `+n;throw He(e),new Error(e)}function Z(n,e){n||K()}function Q(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const N={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class F extends kn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class on{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gT{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class yT{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(yt.UNAUTHENTICATED))}shutdown(){}}class vT{constructor(e){this.t=e,this.currentUser=yt.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let s=this.i;const i=l=>this.i!==s?(s=this.i,t(l)):Promise.resolve();let r=new on;this.o=()=>{this.i++,this.currentUser=this.u(),r.resolve(),r=new on,e.enqueueRetryable(()=>i(this.currentUser))};const a=()=>{const l=r;e.enqueueRetryable(async()=>{await l.promise,await i(this.currentUser)})},o=l=>{V("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),a()};this.t.onInit(l=>o(l)),setTimeout(()=>{if(!this.auth){const l=this.t.getImmediate({optional:!0});l?o(l):(V("FirebaseAuthCredentialsProvider","Auth not yet detected"),r.resolve(),r=new on)}},0),a()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(s=>this.i!==e?(V("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(Z(typeof s.accessToken=="string"),new gT(s.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const e=this.auth&&this.auth.getUid();return Z(e===null||typeof e=="string"),new yt(e)}}class bT{constructor(e,t,s){this.l=e,this.h=t,this.P=s,this.type="FirstParty",this.user=yt.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class _T{constructor(e,t,s){this.l=e,this.h=t,this.P=s}getToken(){return Promise.resolve(new bT(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(yt.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class wT{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class IT{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,t){const s=r=>{r.error!=null&&V("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${r.error.message}`);const a=r.token!==this.R;return this.R=r.token,V("FirebaseAppCheckTokenProvider",`Received ${a?"new":"existing"} token.`),a?t(r.token):Promise.resolve()};this.o=r=>{e.enqueueRetryable(()=>s(r))};const i=r=>{V("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=r,this.appCheck.addTokenListener(this.o)};this.A.onInit(r=>i(r)),setTimeout(()=>{if(!this.appCheck){const r=this.A.getImmediate({optional:!0});r?i(r):V("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(Z(typeof t.token=="string"),this.R=t.token,new wT(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ET(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<n;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wg{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length;let s="";for(;s.length<20;){const i=ET(40);for(let r=0;r<i.length;++r)s.length<20&&i[r]<t&&(s+=e.charAt(i[r]%e.length))}return s}}function ie(n,e){return n<e?-1:n>e?1:0}function Ai(n,e,t){return n.length===e.length&&n.every((s,i)=>t(s,e[i]))}function zg(n){return n+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ue{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new F(N.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new F(N.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800)throw new F(N.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new F(N.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return Ue.fromMillis(Date.now())}static fromDate(e){return Ue.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor(1e6*(e-1e3*t));return new Ue(t,s)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?ie(this.nanoseconds,e.nanoseconds):ie(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ee{constructor(e){this.timestamp=e}static fromTimestamp(e){return new ee(e)}static min(){return new ee(new Ue(0,0))}static max(){return new ee(new Ue(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qr{constructor(e,t,s){t===void 0?t=0:t>e.length&&K(),s===void 0?s=e.length-t:s>e.length-t&&K(),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return Qr.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Qr?e.forEach(s=>{t.push(s)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let i=0;i<s;i++){const r=e.get(i),a=t.get(i);if(r<a)return-1;if(r>a)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class Ee extends Qr{construct(e,t,s){return new Ee(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new F(N.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter(i=>i.length>0))}return new Ee(t)}static emptyPath(){return new Ee([])}}const TT=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Fe extends Qr{construct(e,t,s){return new Fe(e,t,s)}static isValidIdentifier(e){return TT.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Fe.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new Fe(["__name__"])}static fromServerFormat(e){const t=[];let s="",i=0;const r=()=>{if(s.length===0)throw new F(N.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let a=!1;for(;i<e.length;){const o=e[i];if(o==="\\"){if(i+1===e.length)throw new F(N.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const l=e[i+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new F(N.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=l,i+=2}else o==="`"?(a=!a,i++):o!=="."||a?(s+=o,i++):(r(),i++)}if(r(),a)throw new F(N.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Fe(t)}static emptyPath(){return new Fe([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class B{constructor(e){this.path=e}static fromPath(e){return new B(Ee.fromString(e))}static fromName(e){return new B(Ee.fromString(e).popFirst(5))}static empty(){return new B(Ee.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&Ee.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return Ee.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new B(new Ee(e.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vo{constructor(e,t,s,i){this.indexId=e,this.collectionGroup=t,this.fields=s,this.indexState=i}}function Kl(n){return n.fields.find(e=>e.kind===2)}function ws(n){return n.fields.filter(e=>e.kind!==2)}Vo.UNKNOWN_ID=-1;class po{constructor(e,t){this.fieldPath=e,this.kind=t}}class Jr{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new Jr(0,Ot.min())}}function Gg(n,e){const t=n.toTimestamp().seconds,s=n.toTimestamp().nanoseconds+1,i=ee.fromTimestamp(s===1e9?new Ue(t+1,0):new Ue(t,s));return new Ot(i,B.empty(),e)}function Kg(n){return new Ot(n.readTime,n.key,-1)}class Ot{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new Ot(ee.min(),B.empty(),-1)}static max(){return new Ot(ee.max(),B.empty(),-1)}}function Bu(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=B.comparator(n.documentKey,e.documentKey),t!==0?t:ie(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hg="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Qg{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ds(n){if(n.code!==N.FAILED_PRECONDITION||n.message!==Hg)throw n;V("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ${constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&K(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new $((s,i)=>{this.nextCallback=r=>{this.wrapSuccess(e,r).next(s,i)},this.catchCallback=r=>{this.wrapFailure(t,r).next(s,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof $?t:$.resolve(t)}catch(t){return $.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):$.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):$.reject(t)}static resolve(e){return new $((t,s)=>{t(e)})}static reject(e){return new $((t,s)=>{s(e)})}static waitFor(e){return new $((t,s)=>{let i=0,r=0,a=!1;e.forEach(o=>{++i,o.next(()=>{++r,a&&r===i&&t()},l=>s(l))}),a=!0,r===i&&t()})}static or(e){let t=$.resolve(!1);for(const s of e)t=t.next(i=>i?$.resolve(i):s());return t}static forEach(e,t){const s=[];return e.forEach((i,r)=>{s.push(t.call(this,i,r))}),this.waitFor(s)}static mapArray(e,t){return new $((s,i)=>{const r=e.length,a=new Array(r);let o=0;for(let l=0;l<r;l++){const u=l;t(e[u]).next(h=>{a[u]=h,++o,o===r&&s(a)},h=>i(h))}})}static doWhile(e,t){return new $((s,i)=>{const r=()=>{e()===!0?t().next(()=>{r()},i):s()};r()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mc{constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.V=new on,this.transaction.oncomplete=()=>{this.V.resolve()},this.transaction.onabort=()=>{t.error?this.V.reject(new xr(e,t.error)):this.V.resolve()},this.transaction.onerror=s=>{const i=ju(s.target.error);this.V.reject(new xr(e,i))}}static open(e,t,s,i){try{return new mc(t,e.transaction(i,s))}catch(r){throw new xr(t,r)}}get m(){return this.V.promise}abort(e){e&&this.V.reject(e),this.aborted||(V("SimpleDb","Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}g(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new ST(t)}}class Zn{constructor(e,t,s){this.name=e,this.version=t,this.p=s,Zn.S(Je())===12.2&&He("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(e){return V("SimpleDb","Removing database:",e),Is(window.indexedDB.deleteDatabase(e)).toPromise()}static D(){if(!Zm())return!1;if(Zn.C())return!0;const e=Je(),t=Zn.S(e),s=0<t&&t<10,i=Jg(e),r=0<i&&i<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||s||r)}static C(){var e;return typeof process<"u"&&((e=process.__PRIVATE_env)===null||e===void 0?void 0:e.v)==="YES"}static F(e,t){return e.store(t)}static S(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),s=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(s)}async M(e){return this.db||(V("SimpleDb","Opening database:",this.name),this.db=await new Promise((t,s)=>{const i=indexedDB.open(this.name,this.version);i.onsuccess=r=>{const a=r.target.result;t(a)},i.onblocked=()=>{s(new xr(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},i.onerror=r=>{const a=r.target.error;a.name==="VersionError"?s(new F(N.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):a.name==="InvalidStateError"?s(new F(N.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+a)):s(new xr(e,a))},i.onupgradeneeded=r=>{V("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',r.oldVersion);const a=r.target.result;this.p.O(a,i.transaction,r.oldVersion,this.version).next(()=>{V("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.N&&(this.db.onversionchange=t=>this.N(t)),this.db}L(e){this.N=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,s,i){const r=t==="readonly";let a=0;for(;;){++a;try{this.db=await this.M(e);const o=mc.open(this.db,e,r?"readonly":"readwrite",s),l=i(o).next(u=>(o.g(),u)).catch(u=>(o.abort(u),$.reject(u))).toPromise();return l.catch(()=>{}),await o.m,l}catch(o){const l=o,u=l.name!=="FirebaseError"&&a<3;if(V("SimpleDb","Transaction failed with error:",l.message,"Retrying:",u),this.close(),!u)return Promise.reject(l)}}}close(){this.db&&this.db.close(),this.db=void 0}}function Jg(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class AT{constructor(e){this.B=e,this.k=!1,this.q=null}get isDone(){return this.k}get K(){return this.q}set cursor(e){this.B=e}done(){this.k=!0}$(e){this.q=e}delete(){return Is(this.B.delete())}}class xr extends F{constructor(e,t){super(N.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function hs(n){return n.name==="IndexedDbTransactionError"}class ST{constructor(e){this.store=e}put(e,t){let s;return t!==void 0?(V("SimpleDb","PUT",this.store.name,e,t),s=this.store.put(t,e)):(V("SimpleDb","PUT",this.store.name,"<auto-key>",e),s=this.store.put(e)),Is(s)}add(e){return V("SimpleDb","ADD",this.store.name,e,e),Is(this.store.add(e))}get(e){return Is(this.store.get(e)).next(t=>(t===void 0&&(t=null),V("SimpleDb","GET",this.store.name,e,t),t))}delete(e){return V("SimpleDb","DELETE",this.store.name,e),Is(this.store.delete(e))}count(){return V("SimpleDb","COUNT",this.store.name),Is(this.store.count())}U(e,t){const s=this.options(e,t),i=s.index?this.store.index(s.index):this.store;if(typeof i.getAll=="function"){const r=i.getAll(s.range);return new $((a,o)=>{r.onerror=l=>{o(l.target.error)},r.onsuccess=l=>{a(l.target.result)}})}{const r=this.cursor(s),a=[];return this.W(r,(o,l)=>{a.push(l)}).next(()=>a)}}G(e,t){const s=this.store.getAll(e,t===null?void 0:t);return new $((i,r)=>{s.onerror=a=>{r(a.target.error)},s.onsuccess=a=>{i(a.target.result)}})}j(e,t){V("SimpleDb","DELETE ALL",this.store.name);const s=this.options(e,t);s.H=!1;const i=this.cursor(s);return this.W(i,(r,a,o)=>o.delete())}J(e,t){let s;t?s=e:(s={},t=e);const i=this.cursor(s);return this.W(i,t)}Y(e){const t=this.cursor({});return new $((s,i)=>{t.onerror=r=>{const a=ju(r.target.error);i(a)},t.onsuccess=r=>{const a=r.target.result;a?e(a.primaryKey,a.value).next(o=>{o?a.continue():s()}):s()}})}W(e,t){const s=[];return new $((i,r)=>{e.onerror=a=>{r(a.target.error)},e.onsuccess=a=>{const o=a.target.result;if(!o)return void i();const l=new AT(o),u=t(o.primaryKey,o.value,l);if(u instanceof $){const h=u.catch(p=>(l.done(),$.reject(p)));s.push(h)}l.isDone?i():l.K===null?o.continue():o.continue(l.K)}}).next(()=>$.waitFor(s))}options(e,t){let s;return e!==void 0&&(typeof e=="string"?s=e:t=e),{index:s,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const s=this.store.index(e.index);return e.H?s.openKeyCursor(e.range,t):s.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function Is(n){return new $((e,t)=>{n.onsuccess=s=>{const i=s.target.result;e(i)},n.onerror=s=>{const i=ju(s.target.error);t(i)}})}let Kf=!1;function ju(n){const e=Zn.S(Je());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(n.message.indexOf(t)>=0){const s=new F("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Kf||(Kf=!0,setTimeout(()=>{throw s},0)),s}}return n}class kT{constructor(e,t){this.asyncQueue=e,this.Z=t,this.task=null}start(){this.X(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}X(e){V("IndexBackfiller",`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,async()=>{this.task=null;try{V("IndexBackfiller",`Documents written: ${await this.Z.ee()}`)}catch(t){hs(t)?V("IndexBackfiller","Ignoring IndexedDB error during index backfill: ",t):await ds(t)}await this.X(6e4)})}}class RT{constructor(e,t){this.localStore=e,this.persistence=t}async ee(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",t=>this.te(t,e))}te(e,t){const s=new Set;let i=t,r=!0;return $.doWhile(()=>r===!0&&i>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next(a=>{if(a!==null&&!s.has(a))return V("IndexBackfiller",`Processing collection: ${a}`),this.ne(e,a,i).next(o=>{i-=o,s.add(a)});r=!1})).next(()=>t-i)}ne(e,t,s){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next(i=>this.localStore.localDocuments.getNextDocuments(e,t,i,s).next(r=>{const a=r.changes;return this.localStore.indexManager.updateIndexEntries(e,a).next(()=>this.re(i,r)).next(o=>(V("IndexBackfiller",`Updating offset: ${o}`),this.localStore.indexManager.updateCollectionGroup(e,t,o))).next(()=>a.size)}))}re(e,t){let s=e;return t.changes.forEach((i,r)=>{const a=Kg(r);Bu(a,s)>0&&(s=a)}),new Ot(s.readTime,s.documentKey,Math.max(t.batchId,e.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pt{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.ie(s),this.se=s=>t.writeSequenceNumber(s))}ie(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.se&&this.se(e),e}}Pt.oe=-1;function gc(n){return n==null}function Yr(n){return n===0&&1/n==-1/0}function Yg(n){return typeof n=="number"&&Number.isInteger(n)&&!Yr(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tt(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=Hf(e)),e=PT(n.get(t),e);return Hf(e)}function PT(n,e){let t=e;const s=n.length;for(let i=0;i<s;i++){const r=n.charAt(i);switch(r){case"\0":t+="";break;case"":t+="";break;default:t+=r}}return t}function Hf(n){return n+""}function en(n){const e=n.length;if(Z(e>=2),e===2)return Z(n.charAt(0)===""&&n.charAt(1)===""),Ee.emptyPath();const t=e-2,s=[];let i="";for(let r=0;r<e;){const a=n.indexOf("",r);switch((a<0||a>t)&&K(),n.charAt(a+1)){case"":const o=n.substring(r,a);let l;i.length===0?l=o:(i+=o,l=i,i=""),s.push(l);break;case"":i+=n.substring(r,a),i+="\0";break;case"":i+=n.substring(r,a+1);break;default:K()}r=a+2}return new Ee(s)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qf=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mo(n,e){return[n,Tt(e)]}function Xg(n,e,t){return[n,Tt(e),t]}const CT={},$T=["prefixPath","collectionGroup","readTime","documentId"],DT=["prefixPath","collectionGroup","documentId"],xT=["collectionGroup","readTime","prefixPath","documentId"],NT=["canonicalId","targetId"],VT=["targetId","path"],OT=["path","targetId"],MT=["collectionId","parent"],LT=["indexId","uid"],FT=["uid","sequenceNumber"],UT=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],qT=["indexId","uid","orderedDocumentKey"],BT=["userId","collectionPath","documentId"],jT=["userId","collectionPath","largestBatchId"],WT=["userId","collectionGroup","largestBatchId"],Zg=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],zT=[...Zg,"documentOverlays"],ey=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],ty=ey,ny=[...ty,"indexConfiguration","indexState","indexEntries"],GT=ny;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hl extends Qg{constructor(e,t){super(),this._e=e,this.currentSequenceNumber=t}}function rt(n,e){const t=Q(n);return Zn.F(t._e,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jf(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function zs(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function sy(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ne{constructor(e,t){this.comparator=e,this.root=t||ut.EMPTY}insert(e,t){return new Ne(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,ut.BLACK,null,null))}remove(e){return new Ne(this.comparator,this.root.remove(e,this.comparator).copy(null,null,ut.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const i=this.comparator(e,s.key);if(i===0)return t+s.left.size;i<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,s)=>(e(t,s),!1))}toString(){const e=[];return this.inorderTraversal((t,s)=>(e.push(`${t}:${s}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Ya(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Ya(this.root,e,this.comparator,!1)}getReverseIterator(){return new Ya(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Ya(this.root,e,this.comparator,!0)}}class Ya{constructor(e,t,s,i){this.isReverse=i,this.nodeStack=[];let r=1;for(;!e.isEmpty();)if(r=t?s(e.key,t):1,t&&i&&(r*=-1),r<0)e=this.isReverse?e.left:e.right;else{if(r===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class ut{constructor(e,t,s,i,r){this.key=e,this.value=t,this.color=s??ut.RED,this.left=i??ut.EMPTY,this.right=r??ut.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,i,r){return new ut(e??this.key,t??this.value,s??this.color,i??this.left,r??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let i=this;const r=s(e,i.key);return i=r<0?i.copy(null,null,null,i.left.insert(e,t,s),null):r===0?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,s)),i.fixUp()}removeMin(){if(this.left.isEmpty())return ut.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,i=this;if(t(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),t(e,i.key)===0){if(i.right.isEmpty())return ut.EMPTY;s=i.right.min(),i=i.copy(s.key,s.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,ut.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,ut.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw K();const e=this.left.check();if(e!==this.right.check())throw K();return e+(this.isRed()?0:1)}}ut.EMPTY=null,ut.RED=!0,ut.BLACK=!1;ut.EMPTY=new class{constructor(){this.size=0}get key(){throw K()}get value(){throw K()}get color(){throw K()}get left(){throw K()}get right(){throw K()}copy(e,t,s,i,r){return this}insert(e,t,s){return new ut(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ke{constructor(e){this.comparator=e,this.data=new Ne(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,s)=>(e(t),!1))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const i=s.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Yf(this.data.getIterator())}getIteratorFrom(e){return new Yf(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(s=>{t=t.add(s)}),t}isEqual(e){if(!(e instanceof ke)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const i=t.getNext().key,r=s.getNext().key;if(this.comparator(i,r)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new ke(this.comparator);return t.data=e,t}}class Yf{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function ei(n){return n.hasNext()?n.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ct{constructor(e){this.fields=e,e.sort(Fe.comparator)}static empty(){return new Ct([])}unionWith(e){let t=new ke(Fe.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new Ct(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return Ai(this.fields,e.fields,(t,s)=>t.isEqual(s))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iy extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class it{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(i){try{return atob(i)}catch(r){throw typeof DOMException<"u"&&r instanceof DOMException?new iy("Invalid base64 string: "+r):r}}(e);return new it(t)}static fromUint8Array(e){const t=function(i){let r="";for(let a=0;a<i.length;++a)r+=String.fromCharCode(i[a]);return r}(e);return new it(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const s=new Uint8Array(t.length);for(let i=0;i<t.length;i++)s[i]=t.charCodeAt(i);return s}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ie(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}it.EMPTY_BYTE_STRING=new it("");const KT=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function An(n){if(Z(!!n),typeof n=="string"){let e=0;const t=KT.exec(n);if(Z(!!t),t[1]){let i=t[1];i=(i+"000000000").substr(0,9),e=Number(i)}const s=new Date(n);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:je(n.seconds),nanos:je(n.nanos)}}function je(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function rs(n){return typeof n=="string"?it.fromBase64String(n):it.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wu(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{}).__type__)===null||t===void 0?void 0:t.stringValue)==="server_timestamp"}function zu(n){const e=n.mapValue.fields.__previous_value__;return Wu(e)?zu(e):e}function Xr(n){const e=An(n.mapValue.fields.__local_write_time__.timestampValue);return new Ue(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HT{constructor(e,t,s,i,r,a,o,l,u){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=i,this.ssl=r,this.forceLongPolling=a,this.autoDetectLongPolling=o,this.longPollingOptions=l,this.useFetchStreams=u}}class Os{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new Os("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof Os&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kn={mapValue:{fields:{__type__:{stringValue:"__max__"}}}},go={nullValue:"NULL_VALUE"};function Ms(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?Wu(n)?4:ry(n)?9007199254740991:10:K()}function ln(n,e){if(n===e)return!0;const t=Ms(n);if(t!==Ms(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return Xr(n).isEqual(Xr(e));case 3:return function(i,r){if(typeof i.timestampValue=="string"&&typeof r.timestampValue=="string"&&i.timestampValue.length===r.timestampValue.length)return i.timestampValue===r.timestampValue;const a=An(i.timestampValue),o=An(r.timestampValue);return a.seconds===o.seconds&&a.nanos===o.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,r){return rs(i.bytesValue).isEqual(rs(r.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,r){return je(i.geoPointValue.latitude)===je(r.geoPointValue.latitude)&&je(i.geoPointValue.longitude)===je(r.geoPointValue.longitude)}(n,e);case 2:return function(i,r){if("integerValue"in i&&"integerValue"in r)return je(i.integerValue)===je(r.integerValue);if("doubleValue"in i&&"doubleValue"in r){const a=je(i.doubleValue),o=je(r.doubleValue);return a===o?Yr(a)===Yr(o):isNaN(a)&&isNaN(o)}return!1}(n,e);case 9:return Ai(n.arrayValue.values||[],e.arrayValue.values||[],ln);case 10:return function(i,r){const a=i.mapValue.fields||{},o=r.mapValue.fields||{};if(Jf(a)!==Jf(o))return!1;for(const l in a)if(a.hasOwnProperty(l)&&(o[l]===void 0||!ln(a[l],o[l])))return!1;return!0}(n,e);default:return K()}}function Zr(n,e){return(n.values||[]).find(t=>ln(t,e))!==void 0}function as(n,e){if(n===e)return 0;const t=Ms(n),s=Ms(e);if(t!==s)return ie(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return ie(n.booleanValue,e.booleanValue);case 2:return function(r,a){const o=je(r.integerValue||r.doubleValue),l=je(a.integerValue||a.doubleValue);return o<l?-1:o>l?1:o===l?0:isNaN(o)?isNaN(l)?0:-1:1}(n,e);case 3:return Xf(n.timestampValue,e.timestampValue);case 4:return Xf(Xr(n),Xr(e));case 5:return ie(n.stringValue,e.stringValue);case 6:return function(r,a){const o=rs(r),l=rs(a);return o.compareTo(l)}(n.bytesValue,e.bytesValue);case 7:return function(r,a){const o=r.split("/"),l=a.split("/");for(let u=0;u<o.length&&u<l.length;u++){const h=ie(o[u],l[u]);if(h!==0)return h}return ie(o.length,l.length)}(n.referenceValue,e.referenceValue);case 8:return function(r,a){const o=ie(je(r.latitude),je(a.latitude));return o!==0?o:ie(je(r.longitude),je(a.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return function(r,a){const o=r.values||[],l=a.values||[];for(let u=0;u<o.length&&u<l.length;++u){const h=as(o[u],l[u]);if(h)return h}return ie(o.length,l.length)}(n.arrayValue,e.arrayValue);case 10:return function(r,a){if(r===Kn.mapValue&&a===Kn.mapValue)return 0;if(r===Kn.mapValue)return 1;if(a===Kn.mapValue)return-1;const o=r.fields||{},l=Object.keys(o),u=a.fields||{},h=Object.keys(u);l.sort(),h.sort();for(let p=0;p<l.length&&p<h.length;++p){const m=ie(l[p],h[p]);if(m!==0)return m;const w=as(o[l[p]],u[h[p]]);if(w!==0)return w}return ie(l.length,h.length)}(n.mapValue,e.mapValue);default:throw K()}}function Xf(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return ie(n,e);const t=An(n),s=An(e),i=ie(t.seconds,s.seconds);return i!==0?i:ie(t.nanos,s.nanos)}function Si(n){return Ql(n)}function Ql(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const s=An(t);return`time(${s.seconds},${s.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return rs(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return B.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let s="[",i=!0;for(const r of t.values||[])i?i=!1:s+=",",s+=Ql(r);return s+"]"}(n.arrayValue):"mapValue"in n?function(t){const s=Object.keys(t.fields||{}).sort();let i="{",r=!0;for(const a of s)r?r=!1:i+=",",i+=`${a}:${Ql(t.fields[a])}`;return i+"}"}(n.mapValue):K()}function ea(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function Jl(n){return!!n&&"integerValue"in n}function ta(n){return!!n&&"arrayValue"in n}function Zf(n){return!!n&&"nullValue"in n}function ep(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function yo(n){return!!n&&"mapValue"in n}function Nr(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const e={mapValue:{fields:{}}};return zs(n.mapValue.fields,(t,s)=>e.mapValue.fields[t]=Nr(s)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=Nr(n.arrayValue.values[t]);return e}return Object.assign({},n)}function ry(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}function QT(n){return"nullValue"in n?go:"booleanValue"in n?{booleanValue:!1}:"integerValue"in n||"doubleValue"in n?{doubleValue:NaN}:"timestampValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in n?{stringValue:""}:"bytesValue"in n?{bytesValue:""}:"referenceValue"in n?ea(Os.empty(),B.empty()):"geoPointValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in n?{arrayValue:{}}:"mapValue"in n?{mapValue:{}}:K()}function JT(n){return"nullValue"in n?{booleanValue:!1}:"booleanValue"in n?{doubleValue:NaN}:"integerValue"in n||"doubleValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in n?{stringValue:""}:"stringValue"in n?{bytesValue:""}:"bytesValue"in n?ea(Os.empty(),B.empty()):"referenceValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in n?{arrayValue:{}}:"arrayValue"in n?{mapValue:{}}:"mapValue"in n?Kn:K()}function tp(n,e){const t=as(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?-1:!n.inclusive&&e.inclusive?1:0}function np(n,e){const t=as(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?1:!n.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e){this.value=e}static empty(){return new vt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!yo(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Nr(t)}setAll(e){let t=Fe.emptyPath(),s={},i=[];e.forEach((a,o)=>{if(!t.isImmediateParentOf(o)){const l=this.getFieldsMap(t);this.applyChanges(l,s,i),s={},i=[],t=o.popLast()}a?s[o.lastSegment()]=Nr(a):i.push(o.lastSegment())});const r=this.getFieldsMap(t);this.applyChanges(r,s,i)}delete(e){const t=this.field(e.popLast());yo(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return ln(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let i=t.mapValue.fields[e.get(s)];yo(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,s){zs(t,(i,r)=>e[i]=r);for(const i of s)delete e[i]}clone(){return new vt(Nr(this.value))}}function ay(n){const e=[];return zs(n.fields,(t,s)=>{const i=new Fe([t]);if(yo(s)){const r=ay(s.mapValue).fields;if(r.length===0)e.push(i);else for(const a of r)e.push(i.child(a))}else e.push(i)}),new Ct(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class We{constructor(e,t,s,i,r,a,o){this.key=e,this.documentType=t,this.version=s,this.readTime=i,this.createTime=r,this.data=a,this.documentState=o}static newInvalidDocument(e){return new We(e,0,ee.min(),ee.min(),ee.min(),vt.empty(),0)}static newFoundDocument(e,t,s,i){return new We(e,1,t,ee.min(),s,i,0)}static newNoDocument(e,t){return new We(e,2,t,ee.min(),ee.min(),vt.empty(),0)}static newUnknownDocument(e,t){return new We(e,3,t,ee.min(),ee.min(),vt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ee.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=vt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=vt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ee.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof We&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new We(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ki{constructor(e,t){this.position=e,this.inclusive=t}}function sp(n,e,t){let s=0;for(let i=0;i<n.position.length;i++){const r=e[i],a=n.position[i];if(r.field.isKeyField()?s=B.comparator(B.fromName(a.referenceValue),t.key):s=as(a,t.data.field(r.field)),r.dir==="desc"&&(s*=-1),s!==0)break}return s}function ip(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!ln(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class na{constructor(e,t="asc"){this.field=e,this.dir=t}}function YT(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oy{}class he extends oy{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new XT(e,t,s):t==="array-contains"?new t0(e,s):t==="in"?new fy(e,s):t==="not-in"?new n0(e,s):t==="array-contains-any"?new s0(e,s):new he(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new ZT(e,s):new e0(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&this.matchesComparison(as(t,this.value)):t!==null&&Ms(this.value)===Ms(t)&&this.matchesComparison(as(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return K()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Ae extends oy{constructor(e,t){super(),this.filters=e,this.op=t,this.ae=null}static create(e,t){return new Ae(e,t)}matches(e){return Ri(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.ae!==null||(this.ae=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ae}getFilters(){return Object.assign([],this.filters)}}function Ri(n){return n.op==="and"}function Yl(n){return n.op==="or"}function Gu(n){return cy(n)&&Ri(n)}function cy(n){for(const e of n.filters)if(e instanceof Ae)return!1;return!0}function Xl(n){if(n instanceof he)return n.field.canonicalString()+n.op.toString()+Si(n.value);if(Gu(n))return n.filters.map(e=>Xl(e)).join(",");{const e=n.filters.map(t=>Xl(t)).join(",");return`${n.op}(${e})`}}function ly(n,e){return n instanceof he?function(s,i){return i instanceof he&&s.op===i.op&&s.field.isEqual(i.field)&&ln(s.value,i.value)}(n,e):n instanceof Ae?function(s,i){return i instanceof Ae&&s.op===i.op&&s.filters.length===i.filters.length?s.filters.reduce((r,a,o)=>r&&ly(a,i.filters[o]),!0):!1}(n,e):void K()}function uy(n,e){const t=n.filters.concat(e);return Ae.create(t,n.op)}function dy(n){return n instanceof he?function(t){return`${t.field.canonicalString()} ${t.op} ${Si(t.value)}`}(n):n instanceof Ae?function(t){return t.op.toString()+" {"+t.getFilters().map(dy).join(" ,")+"}"}(n):"Filter"}class XT extends he{constructor(e,t,s){super(e,t,s),this.key=B.fromName(s.referenceValue)}matches(e){const t=B.comparator(e.key,this.key);return this.matchesComparison(t)}}class ZT extends he{constructor(e,t){super(e,"in",t),this.keys=hy("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class e0 extends he{constructor(e,t){super(e,"not-in",t),this.keys=hy("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function hy(n,e){var t;return(((t=e.arrayValue)===null||t===void 0?void 0:t.values)||[]).map(s=>B.fromName(s.referenceValue))}class t0 extends he{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return ta(t)&&Zr(t.arrayValue,this.value)}}class fy extends he{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Zr(this.value.arrayValue,t)}}class n0 extends he{constructor(e,t){super(e,"not-in",t)}matches(e){if(Zr(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&!Zr(this.value.arrayValue,t)}}class s0 extends he{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!ta(t)||!t.arrayValue.values)&&t.arrayValue.values.some(s=>Zr(this.value.arrayValue,s))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class i0{constructor(e,t=null,s=[],i=[],r=null,a=null,o=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=i,this.limit=r,this.startAt=a,this.endAt=o,this.ue=null}}function Zl(n,e=null,t=[],s=[],i=null,r=null,a=null){return new i0(n,e,t,s,i,r,a)}function Ls(n){const e=Q(n);if(e.ue===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(s=>Xl(s)).join(","),t+="|ob:",t+=e.orderBy.map(s=>function(r){return r.field.canonicalString()+r.dir}(s)).join(","),gc(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(s=>Si(s)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(s=>Si(s)).join(",")),e.ue=t}return e.ue}function _a(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!YT(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!ly(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!ip(n.startAt,e.startAt)&&ip(n.endAt,e.endAt)}function Oo(n){return B.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function Mo(n,e){return n.filters.filter(t=>t instanceof he&&t.field.isEqual(e))}function rp(n,e,t){let s=go,i=!0;for(const r of Mo(n,e)){let a=go,o=!0;switch(r.op){case"<":case"<=":a=QT(r.value);break;case"==":case"in":case">=":a=r.value;break;case">":a=r.value,o=!1;break;case"!=":case"not-in":a=go}tp({value:s,inclusive:i},{value:a,inclusive:o})<0&&(s=a,i=o)}if(t!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(e)){const a=t.position[r];tp({value:s,inclusive:i},{value:a,inclusive:t.inclusive})<0&&(s=a,i=t.inclusive);break}}return{value:s,inclusive:i}}function ap(n,e,t){let s=Kn,i=!0;for(const r of Mo(n,e)){let a=Kn,o=!0;switch(r.op){case">=":case">":a=JT(r.value),o=!1;break;case"==":case"in":case"<=":a=r.value;break;case"<":a=r.value,o=!1;break;case"!=":case"not-in":a=Kn}np({value:s,inclusive:i},{value:a,inclusive:o})>0&&(s=a,i=o)}if(t!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(e)){const a=t.position[r];np({value:s,inclusive:i},{value:a,inclusive:t.inclusive})>0&&(s=a,i=t.inclusive);break}}return{value:s,inclusive:i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hi{constructor(e,t=null,s=[],i=[],r=null,a="F",o=null,l=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=i,this.limit=r,this.limitType=a,this.startAt=o,this.endAt=l,this.ce=null,this.le=null,this.he=null,this.startAt,this.endAt}}function py(n,e,t,s,i,r,a,o){return new Hi(n,e,t,s,i,r,a,o)}function wa(n){return new Hi(n)}function op(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function my(n){return n.collectionGroup!==null}function Vr(n){const e=Q(n);if(e.ce===null){e.ce=[];const t=new Set;for(const r of e.explicitOrderBy)e.ce.push(r),t.add(r.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(a){let o=new ke(Fe.comparator);return a.filters.forEach(l=>{l.getFlattenedFilters().forEach(u=>{u.isInequality()&&(o=o.add(u.field))})}),o})(e).forEach(r=>{t.has(r.canonicalString())||r.isKeyField()||e.ce.push(new na(r,s))}),t.has(Fe.keyField().canonicalString())||e.ce.push(new na(Fe.keyField(),s))}return e.ce}function Nt(n){const e=Q(n);return e.le||(e.le=r0(e,Vr(n))),e.le}function r0(n,e){if(n.limitType==="F")return Zl(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(i=>{const r=i.dir==="desc"?"asc":"desc";return new na(i.field,r)});const t=n.endAt?new ki(n.endAt.position,n.endAt.inclusive):null,s=n.startAt?new ki(n.startAt.position,n.startAt.inclusive):null;return Zl(n.path,n.collectionGroup,e,n.filters,n.limit,t,s)}}function eu(n,e){const t=n.filters.concat([e]);return new Hi(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function Lo(n,e,t){return new Hi(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function yc(n,e){return _a(Nt(n),Nt(e))&&n.limitType===e.limitType}function gy(n){return`${Ls(Nt(n))}|lt:${n.limitType}`}function ui(n){return`Query(target=${function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map(i=>dy(i)).join(", ")}]`),gc(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map(i=>function(a){return`${a.field.canonicalString()} (${a.dir})`}(i)).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map(i=>Si(i)).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map(i=>Si(i)).join(",")),`Target(${s})`}(Nt(n))}; limitType=${n.limitType})`}function Ia(n,e){return e.isFoundDocument()&&function(s,i){const r=i.key.path;return s.collectionGroup!==null?i.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(r):B.isDocumentKey(s.path)?s.path.isEqual(r):s.path.isImmediateParentOf(r)}(n,e)&&function(s,i){for(const r of Vr(s))if(!r.field.isKeyField()&&i.data.field(r.field)===null)return!1;return!0}(n,e)&&function(s,i){for(const r of s.filters)if(!r.matches(i))return!1;return!0}(n,e)&&function(s,i){return!(s.startAt&&!function(a,o,l){const u=sp(a,o,l);return a.inclusive?u<=0:u<0}(s.startAt,Vr(s),i)||s.endAt&&!function(a,o,l){const u=sp(a,o,l);return a.inclusive?u>=0:u>0}(s.endAt,Vr(s),i))}(n,e)}function yy(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function vy(n){return(e,t)=>{let s=!1;for(const i of Vr(n)){const r=a0(i,e,t);if(r!==0)return r;s=s||i.field.isKeyField()}return 0}}function a0(n,e,t){const s=n.field.isKeyField()?B.comparator(e.key,t.key):function(r,a,o){const l=a.data.field(r),u=o.data.field(r);return l!==null&&u!==null?as(l,u):K()}(n.field,e,t);switch(n.dir){case"asc":return s;case"desc":return-1*s;default:return K()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fs{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[i,r]of s)if(this.equalsFn(i,e))return r}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),i=this.inner[s];if(i===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let r=0;r<i.length;r++)if(this.equalsFn(i[r][0],e))return void(i[r]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return s.length===1?delete this.inner[t]:s.splice(i,1),this.innerSize--,!0;return!1}forEach(e){zs(this.inner,(t,s)=>{for(const[i,r]of s)e(i,r)})}isEmpty(){return sy(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const o0=new Ne(B.comparator);function xt(){return o0}const by=new Ne(B.comparator);function Rr(...n){let e=by;for(const t of n)e=e.insert(t.key,t);return e}function _y(n){let e=by;return n.forEach((t,s)=>e=e.insert(t,s.overlayedDocument)),e}function tn(){return Or()}function wy(){return Or()}function Or(){return new fs(n=>n.toString(),(n,e)=>n.isEqual(e))}const c0=new Ne(B.comparator),l0=new ke(B.comparator);function ce(...n){let e=l0;for(const t of n)e=e.add(t);return e}const u0=new ke(ie);function Ku(){return u0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Iy(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Yr(e)?"-0":e}}function Ey(n){return{integerValue:""+n}}function d0(n,e){return Yg(e)?Ey(e):Iy(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vc{constructor(){this._=void 0}}function h0(n,e,t){return n instanceof sa?function(i,r){const a={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return r&&Wu(r)&&(r=zu(r)),r&&(a.fields.__previous_value__=r),{mapValue:a}}(t,e):n instanceof Pi?Ay(n,e):n instanceof Ci?Sy(n,e):function(i,r){const a=Ty(i,r),o=cp(a)+cp(i.Pe);return Jl(a)&&Jl(i.Pe)?Ey(o):Iy(i.serializer,o)}(n,e)}function f0(n,e,t){return n instanceof Pi?Ay(n,e):n instanceof Ci?Sy(n,e):t}function Ty(n,e){return n instanceof ia?function(s){return Jl(s)||function(r){return!!r&&"doubleValue"in r}(s)}(e)?e:{integerValue:0}:null}class sa extends vc{}class Pi extends vc{constructor(e){super(),this.elements=e}}function Ay(n,e){const t=ky(e);for(const s of n.elements)t.some(i=>ln(i,s))||t.push(s);return{arrayValue:{values:t}}}class Ci extends vc{constructor(e){super(),this.elements=e}}function Sy(n,e){let t=ky(e);for(const s of n.elements)t=t.filter(i=>!ln(i,s));return{arrayValue:{values:t}}}class ia extends vc{constructor(e,t){super(),this.serializer=e,this.Pe=t}}function cp(n){return je(n.integerValue||n.doubleValue)}function ky(n){return ta(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p0{constructor(e,t){this.field=e,this.transform=t}}function m0(n,e){return n.field.isEqual(e.field)&&function(s,i){return s instanceof Pi&&i instanceof Pi||s instanceof Ci&&i instanceof Ci?Ai(s.elements,i.elements,ln):s instanceof ia&&i instanceof ia?ln(s.Pe,i.Pe):s instanceof sa&&i instanceof sa}(n.transform,e.transform)}class g0{constructor(e,t){this.version=e,this.transformResults=t}}class Et{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Et}static exists(e){return new Et(void 0,e)}static updateTime(e){return new Et(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function vo(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class bc{}function Ry(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new _c(n.key,Et.none()):new Qi(n.key,n.data,Et.none());{const t=n.data,s=vt.empty();let i=new ke(Fe.comparator);for(let r of e.fields)if(!i.has(r)){let a=t.field(r);a===null&&r.length>1&&(r=r.popLast(),a=t.field(r)),a===null?s.delete(r):s.set(r,a),i=i.add(r)}return new Rn(n.key,s,new Ct(i.toArray()),Et.none())}}function y0(n,e,t){n instanceof Qi?function(i,r,a){const o=i.value.clone(),l=up(i.fieldTransforms,r,a.transformResults);o.setAll(l),r.convertToFoundDocument(a.version,o).setHasCommittedMutations()}(n,e,t):n instanceof Rn?function(i,r,a){if(!vo(i.precondition,r))return void r.convertToUnknownDocument(a.version);const o=up(i.fieldTransforms,r,a.transformResults),l=r.data;l.setAll(Py(i)),l.setAll(o),r.convertToFoundDocument(a.version,l).setHasCommittedMutations()}(n,e,t):function(i,r,a){r.convertToNoDocument(a.version).setHasCommittedMutations()}(0,e,t)}function Mr(n,e,t,s){return n instanceof Qi?function(r,a,o,l){if(!vo(r.precondition,a))return o;const u=r.value.clone(),h=dp(r.fieldTransforms,l,a);return u.setAll(h),a.convertToFoundDocument(a.version,u).setHasLocalMutations(),null}(n,e,t,s):n instanceof Rn?function(r,a,o,l){if(!vo(r.precondition,a))return o;const u=dp(r.fieldTransforms,l,a),h=a.data;return h.setAll(Py(r)),h.setAll(u),a.convertToFoundDocument(a.version,h).setHasLocalMutations(),o===null?null:o.unionWith(r.fieldMask.fields).unionWith(r.fieldTransforms.map(p=>p.field))}(n,e,t,s):function(r,a,o){return vo(r.precondition,a)?(a.convertToNoDocument(a.version).setHasLocalMutations(),null):o}(n,e,t)}function v0(n,e){let t=null;for(const s of n.fieldTransforms){const i=e.data.field(s.field),r=Ty(s.transform,i||null);r!=null&&(t===null&&(t=vt.empty()),t.set(s.field,r))}return t||null}function lp(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(s,i){return s===void 0&&i===void 0||!(!s||!i)&&Ai(s,i,(r,a)=>m0(r,a))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Qi extends bc{constructor(e,t,s,i=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class Rn extends bc{constructor(e,t,s,i,r=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=i,this.fieldTransforms=r,this.type=1}getFieldMask(){return this.fieldMask}}function Py(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const s=n.data.field(t);e.set(t,s)}}),e}function up(n,e,t){const s=new Map;Z(n.length===t.length);for(let i=0;i<t.length;i++){const r=n[i],a=r.transform,o=e.data.field(r.field);s.set(r.field,f0(a,o,t[i]))}return s}function dp(n,e,t){const s=new Map;for(const i of n){const r=i.transform,a=t.data.field(i.field);s.set(i.field,h0(r,a,e))}return s}class _c extends bc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Cy extends bc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hu{constructor(e,t,s,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=i}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let i=0;i<this.mutations.length;i++){const r=this.mutations[i];r.key.isEqual(e.key)&&y0(r,e,s[i])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=Mr(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=Mr(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=wy();return this.mutations.forEach(i=>{const r=e.get(i.key),a=r.overlayedDocument;let o=this.applyToLocalView(a,r.mutatedFields);o=t.has(i.key)?null:o;const l=Ry(a,o);l!==null&&s.set(i.key,l),a.isValidDocument()||a.convertToNoDocument(ee.min())}),s}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),ce())}isEqual(e){return this.batchId===e.batchId&&Ai(this.mutations,e.mutations,(t,s)=>lp(t,s))&&Ai(this.baseMutations,e.baseMutations,(t,s)=>lp(t,s))}}class Qu{constructor(e,t,s,i){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=i}static from(e,t,s){Z(e.mutations.length===s.length);let i=function(){return c0}();const r=e.mutations;for(let a=0;a<r.length;a++)i=i.insert(r[a].key,s[a].version);return new Qu(e,t,s,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ju{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class b0{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Qe,pe;function _0(n){switch(n){default:return K();case N.CANCELLED:case N.UNKNOWN:case N.DEADLINE_EXCEEDED:case N.RESOURCE_EXHAUSTED:case N.INTERNAL:case N.UNAVAILABLE:case N.UNAUTHENTICATED:return!1;case N.INVALID_ARGUMENT:case N.NOT_FOUND:case N.ALREADY_EXISTS:case N.PERMISSION_DENIED:case N.FAILED_PRECONDITION:case N.ABORTED:case N.OUT_OF_RANGE:case N.UNIMPLEMENTED:case N.DATA_LOSS:return!0}}function $y(n){if(n===void 0)return He("GRPC error has no .code"),N.UNKNOWN;switch(n){case Qe.OK:return N.OK;case Qe.CANCELLED:return N.CANCELLED;case Qe.UNKNOWN:return N.UNKNOWN;case Qe.DEADLINE_EXCEEDED:return N.DEADLINE_EXCEEDED;case Qe.RESOURCE_EXHAUSTED:return N.RESOURCE_EXHAUSTED;case Qe.INTERNAL:return N.INTERNAL;case Qe.UNAVAILABLE:return N.UNAVAILABLE;case Qe.UNAUTHENTICATED:return N.UNAUTHENTICATED;case Qe.INVALID_ARGUMENT:return N.INVALID_ARGUMENT;case Qe.NOT_FOUND:return N.NOT_FOUND;case Qe.ALREADY_EXISTS:return N.ALREADY_EXISTS;case Qe.PERMISSION_DENIED:return N.PERMISSION_DENIED;case Qe.FAILED_PRECONDITION:return N.FAILED_PRECONDITION;case Qe.ABORTED:return N.ABORTED;case Qe.OUT_OF_RANGE:return N.OUT_OF_RANGE;case Qe.UNIMPLEMENTED:return N.UNIMPLEMENTED;case Qe.DATA_LOSS:return N.DATA_LOSS;default:return K()}}(pe=Qe||(Qe={}))[pe.OK=0]="OK",pe[pe.CANCELLED=1]="CANCELLED",pe[pe.UNKNOWN=2]="UNKNOWN",pe[pe.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",pe[pe.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",pe[pe.NOT_FOUND=5]="NOT_FOUND",pe[pe.ALREADY_EXISTS=6]="ALREADY_EXISTS",pe[pe.PERMISSION_DENIED=7]="PERMISSION_DENIED",pe[pe.UNAUTHENTICATED=16]="UNAUTHENTICATED",pe[pe.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",pe[pe.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",pe[pe.ABORTED=10]="ABORTED",pe[pe.OUT_OF_RANGE=11]="OUT_OF_RANGE",pe[pe.UNIMPLEMENTED=12]="UNIMPLEMENTED",pe[pe.INTERNAL=13]="INTERNAL",pe[pe.UNAVAILABLE=14]="UNAVAILABLE",pe[pe.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function w0(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const I0=new Rs([4294967295,4294967295],0);function hp(n){const e=w0().encode(n),t=new Mg;return t.update(e),new Uint8Array(t.digest())}function fp(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),i=e.getUint32(8,!0),r=e.getUint32(12,!0);return[new Rs([t,s],0),new Rs([i,r],0)]}class Yu{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new Pr(`Invalid padding: ${t}`);if(s<0)throw new Pr(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new Pr(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new Pr(`Invalid padding when bitmap length is 0: ${t}`);this.Ie=8*e.length-t,this.Te=Rs.fromNumber(this.Ie)}Ee(e,t,s){let i=e.add(t.multiply(Rs.fromNumber(s)));return i.compare(I0)===1&&(i=new Rs([i.getBits(0),i.getBits(1)],0)),i.modulo(this.Te).toNumber()}de(e){return(this.bitmap[Math.floor(e/8)]&1<<e%8)!=0}mightContain(e){if(this.Ie===0)return!1;const t=hp(e),[s,i]=fp(t);for(let r=0;r<this.hashCount;r++){const a=this.Ee(s,i,r);if(!this.de(a))return!1}return!0}static create(e,t,s){const i=e%8==0?0:8-e%8,r=new Uint8Array(Math.ceil(e/8)),a=new Yu(r,i,t);return s.forEach(o=>a.insert(o)),a}insert(e){if(this.Ie===0)return;const t=hp(e),[s,i]=fp(t);for(let r=0;r<this.hashCount;r++){const a=this.Ee(s,i,r);this.Ae(a)}}Ae(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class Pr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ea{constructor(e,t,s,i,r){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=i,this.resolvedLimboDocuments=r}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const i=new Map;return i.set(e,Ta.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new Ea(ee.min(),i,new Ne(ie),xt(),ce())}}class Ta{constructor(e,t,s,i,r){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=i,this.removedDocuments=r}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new Ta(s,t,ce(),ce(),ce())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bo{constructor(e,t,s,i){this.Re=e,this.removedTargetIds=t,this.key=s,this.Ve=i}}class Dy{constructor(e,t){this.targetId=e,this.me=t}}class xy{constructor(e,t,s=it.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=i}}class pp{constructor(){this.fe=0,this.ge=gp(),this.pe=it.EMPTY_BYTE_STRING,this.ye=!1,this.we=!0}get current(){return this.ye}get resumeToken(){return this.pe}get Se(){return this.fe!==0}get be(){return this.we}De(e){e.approximateByteSize()>0&&(this.we=!0,this.pe=e)}Ce(){let e=ce(),t=ce(),s=ce();return this.ge.forEach((i,r)=>{switch(r){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:s=s.add(i);break;default:K()}}),new Ta(this.pe,this.ye,e,t,s)}ve(){this.we=!1,this.ge=gp()}Fe(e,t){this.we=!0,this.ge=this.ge.insert(e,t)}Me(e){this.we=!0,this.ge=this.ge.remove(e)}xe(){this.fe+=1}Oe(){this.fe-=1,Z(this.fe>=0)}Ne(){this.we=!0,this.ye=!0}}class E0{constructor(e){this.Le=e,this.Be=new Map,this.ke=xt(),this.qe=mp(),this.Qe=new Ne(ie)}Ke(e){for(const t of e.Re)e.Ve&&e.Ve.isFoundDocument()?this.$e(t,e.Ve):this.Ue(t,e.key,e.Ve);for(const t of e.removedTargetIds)this.Ue(t,e.key,e.Ve)}We(e){this.forEachTarget(e,t=>{const s=this.Ge(t);switch(e.state){case 0:this.ze(t)&&s.De(e.resumeToken);break;case 1:s.Oe(),s.Se||s.ve(),s.De(e.resumeToken);break;case 2:s.Oe(),s.Se||this.removeTarget(t);break;case 3:this.ze(t)&&(s.Ne(),s.De(e.resumeToken));break;case 4:this.ze(t)&&(this.je(t),s.De(e.resumeToken));break;default:K()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.Be.forEach((s,i)=>{this.ze(i)&&t(i)})}He(e){const t=e.targetId,s=e.me.count,i=this.Je(t);if(i){const r=i.target;if(Oo(r))if(s===0){const a=new B(r.path);this.Ue(t,a,We.newNoDocument(a,ee.min()))}else Z(s===1);else{const a=this.Ye(t);if(a!==s){const o=this.Ze(e),l=o?this.Xe(o,e,a):1;if(l!==0){this.je(t);const u=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Qe=this.Qe.insert(t,u)}}}}}Ze(e){const t=e.me.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:i=0},hashCount:r=0}=t;let a,o;try{a=rs(s).toUint8Array()}catch(l){if(l instanceof iy)return Hr("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{o=new Yu(a,i,r)}catch(l){return Hr(l instanceof Pr?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return o.Ie===0?null:o}Xe(e,t,s){return t.me.count===s-this.nt(e,t.targetId)?0:2}nt(e,t){const s=this.Le.getRemoteKeysForTarget(t);let i=0;return s.forEach(r=>{const a=this.Le.tt(),o=`projects/${a.projectId}/databases/${a.database}/documents/${r.path.canonicalString()}`;e.mightContain(o)||(this.Ue(t,r,null),i++)}),i}rt(e){const t=new Map;this.Be.forEach((r,a)=>{const o=this.Je(a);if(o){if(r.current&&Oo(o.target)){const l=new B(o.target.path);this.ke.get(l)!==null||this.it(a,l)||this.Ue(a,l,We.newNoDocument(l,e))}r.be&&(t.set(a,r.Ce()),r.ve())}});let s=ce();this.qe.forEach((r,a)=>{let o=!0;a.forEachWhile(l=>{const u=this.Je(l);return!u||u.purpose==="TargetPurposeLimboResolution"||(o=!1,!1)}),o&&(s=s.add(r))}),this.ke.forEach((r,a)=>a.setReadTime(e));const i=new Ea(e,t,this.Qe,this.ke,s);return this.ke=xt(),this.qe=mp(),this.Qe=new Ne(ie),i}$e(e,t){if(!this.ze(e))return;const s=this.it(e,t.key)?2:0;this.Ge(e).Fe(t.key,s),this.ke=this.ke.insert(t.key,t),this.qe=this.qe.insert(t.key,this.st(t.key).add(e))}Ue(e,t,s){if(!this.ze(e))return;const i=this.Ge(e);this.it(e,t)?i.Fe(t,1):i.Me(t),this.qe=this.qe.insert(t,this.st(t).delete(e)),s&&(this.ke=this.ke.insert(t,s))}removeTarget(e){this.Be.delete(e)}Ye(e){const t=this.Ge(e).Ce();return this.Le.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}xe(e){this.Ge(e).xe()}Ge(e){let t=this.Be.get(e);return t||(t=new pp,this.Be.set(e,t)),t}st(e){let t=this.qe.get(e);return t||(t=new ke(ie),this.qe=this.qe.insert(e,t)),t}ze(e){const t=this.Je(e)!==null;return t||V("WatchChangeAggregator","Detected inactive target",e),t}Je(e){const t=this.Be.get(e);return t&&t.Se?null:this.Le.ot(e)}je(e){this.Be.set(e,new pp),this.Le.getRemoteKeysForTarget(e).forEach(t=>{this.Ue(e,t,null)})}it(e,t){return this.Le.getRemoteKeysForTarget(e).has(t)}}function mp(){return new Ne(B.comparator)}function gp(){return new Ne(B.comparator)}const T0={asc:"ASCENDING",desc:"DESCENDING"},A0={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},S0={and:"AND",or:"OR"};class k0{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function tu(n,e){return n.useProto3Json||gc(e)?e:{value:e}}function $i(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Ny(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function R0(n,e){return $i(n,e.toTimestamp())}function At(n){return Z(!!n),ee.fromTimestamp(function(t){const s=An(t);return new Ue(s.seconds,s.nanos)}(n))}function Xu(n,e){return nu(n,e).canonicalString()}function nu(n,e){const t=function(i){return new Ee(["projects",i.projectId,"databases",i.database])}(n).child("documents");return e===void 0?t:t.child(e)}function Vy(n){const e=Ee.fromString(n);return Z(Wy(e)),e}function Fo(n,e){return Xu(n.databaseId,e.path)}function Ps(n,e){const t=Vy(e);if(t.get(1)!==n.databaseId.projectId)throw new F(N.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new F(N.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new B(Ly(t))}function Oy(n,e){return Xu(n.databaseId,e)}function My(n){const e=Vy(n);return e.length===4?Ee.emptyPath():Ly(e)}function su(n){return new Ee(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function Ly(n){return Z(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function yp(n,e,t){return{name:Fo(n,e),fields:t.value.mapValue.fields}}function P0(n,e,t){const s=Ps(n,e.name),i=At(e.updateTime),r=e.createTime?At(e.createTime):ee.min(),a=new vt({mapValue:{fields:e.fields}}),o=We.newFoundDocument(s,i,r,a);return t&&o.setHasCommittedMutations(),t?o.setHasCommittedMutations():o}function C0(n,e){let t;if("targetChange"in e){e.targetChange;const s=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:K()}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],r=function(u,h){return u.useProto3Json?(Z(h===void 0||typeof h=="string"),it.fromBase64String(h||"")):(Z(h===void 0||h instanceof Buffer||h instanceof Uint8Array),it.fromUint8Array(h||new Uint8Array))}(n,e.targetChange.resumeToken),a=e.targetChange.cause,o=a&&function(u){const h=u.code===void 0?N.UNKNOWN:$y(u.code);return new F(h,u.message||"")}(a);t=new xy(s,i,r,o||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const i=Ps(n,s.document.name),r=At(s.document.updateTime),a=s.document.createTime?At(s.document.createTime):ee.min(),o=new vt({mapValue:{fields:s.document.fields}}),l=We.newFoundDocument(i,r,a,o),u=s.targetIds||[],h=s.removedTargetIds||[];t=new bo(u,h,l.key,l)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const i=Ps(n,s.document),r=s.readTime?At(s.readTime):ee.min(),a=We.newNoDocument(i,r),o=s.removedTargetIds||[];t=new bo([],o,a.key,a)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const i=Ps(n,s.document),r=s.removedTargetIds||[];t=new bo([],r,i,null)}else{if(!("filter"in e))return K();{e.filter;const s=e.filter;s.targetId;const{count:i=0,unchangedNames:r}=s,a=new b0(i,r),o=s.targetId;t=new Dy(o,a)}}return t}function Uo(n,e){let t;if(e instanceof Qi)t={update:yp(n,e.key,e.value)};else if(e instanceof _c)t={delete:Fo(n,e.key)};else if(e instanceof Rn)t={update:yp(n,e.key,e.data),updateMask:O0(e.fieldMask)};else{if(!(e instanceof Cy))return K();t={verify:Fo(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(s=>function(r,a){const o=a.transform;if(o instanceof sa)return{fieldPath:a.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(o instanceof Pi)return{fieldPath:a.field.canonicalString(),appendMissingElements:{values:o.elements}};if(o instanceof Ci)return{fieldPath:a.field.canonicalString(),removeAllFromArray:{values:o.elements}};if(o instanceof ia)return{fieldPath:a.field.canonicalString(),increment:o.Pe};throw K()}(0,s))),e.precondition.isNone||(t.currentDocument=function(i,r){return r.updateTime!==void 0?{updateTime:R0(i,r.updateTime)}:r.exists!==void 0?{exists:r.exists}:K()}(n,e.precondition)),t}function iu(n,e){const t=e.currentDocument?function(r){return r.updateTime!==void 0?Et.updateTime(At(r.updateTime)):r.exists!==void 0?Et.exists(r.exists):Et.none()}(e.currentDocument):Et.none(),s=e.updateTransforms?e.updateTransforms.map(i=>function(a,o){let l=null;if("setToServerValue"in o)Z(o.setToServerValue==="REQUEST_TIME"),l=new sa;else if("appendMissingElements"in o){const h=o.appendMissingElements.values||[];l=new Pi(h)}else if("removeAllFromArray"in o){const h=o.removeAllFromArray.values||[];l=new Ci(h)}else"increment"in o?l=new ia(a,o.increment):K();const u=Fe.fromServerFormat(o.fieldPath);return new p0(u,l)}(n,i)):[];if(e.update){e.update.name;const i=Ps(n,e.update.name),r=new vt({mapValue:{fields:e.update.fields}});if(e.updateMask){const a=function(l){const u=l.fieldPaths||[];return new Ct(u.map(h=>Fe.fromServerFormat(h)))}(e.updateMask);return new Rn(i,r,a,t,s)}return new Qi(i,r,t,s)}if(e.delete){const i=Ps(n,e.delete);return new _c(i,t)}if(e.verify){const i=Ps(n,e.verify);return new Cy(i,t)}return K()}function $0(n,e){return n&&n.length>0?(Z(e!==void 0),n.map(t=>function(i,r){let a=i.updateTime?At(i.updateTime):At(r);return a.isEqual(ee.min())&&(a=At(r)),new g0(a,i.transformResults||[])}(t,e))):[]}function Fy(n,e){return{documents:[Oy(n,e.path)]}}function Uy(n,e){const t={structuredQuery:{}},s=e.path;let i;e.collectionGroup!==null?(i=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(i=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=Oy(n,i);const r=function(u){if(u.length!==0)return jy(Ae.create(u,"and"))}(e.filters);r&&(t.structuredQuery.where=r);const a=function(u){if(u.length!==0)return u.map(h=>function(m){return{field:di(m.field),direction:x0(m.dir)}}(h))}(e.orderBy);a&&(t.structuredQuery.orderBy=a);const o=tu(n,e.limit);return o!==null&&(t.structuredQuery.limit=o),e.startAt&&(t.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(e.endAt)),{_t:t,parent:i}}function qy(n){let e=My(n.parent);const t=n.structuredQuery,s=t.from?t.from.length:0;let i=null;if(s>0){Z(s===1);const h=t.from[0];h.allDescendants?i=h.collectionId:e=e.child(h.collectionId)}let r=[];t.where&&(r=function(p){const m=By(p);return m instanceof Ae&&Gu(m)?m.getFilters():[m]}(t.where));let a=[];t.orderBy&&(a=function(p){return p.map(m=>function(E){return new na(hi(E.field),function(C){switch(C){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(E.direction))}(m))}(t.orderBy));let o=null;t.limit&&(o=function(p){let m;return m=typeof p=="object"?p.value:p,gc(m)?null:m}(t.limit));let l=null;t.startAt&&(l=function(p){const m=!!p.before,w=p.values||[];return new ki(w,m)}(t.startAt));let u=null;return t.endAt&&(u=function(p){const m=!p.before,w=p.values||[];return new ki(w,m)}(t.endAt)),py(e,i,a,r,o,"F",l,u)}function D0(n,e){const t=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return K()}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function By(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=hi(t.unaryFilter.field);return he.create(s,"==",{doubleValue:NaN});case"IS_NULL":const i=hi(t.unaryFilter.field);return he.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const r=hi(t.unaryFilter.field);return he.create(r,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const a=hi(t.unaryFilter.field);return he.create(a,"!=",{nullValue:"NULL_VALUE"});default:return K()}}(n):n.fieldFilter!==void 0?function(t){return he.create(hi(t.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return K()}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Ae.create(t.compositeFilter.filters.map(s=>By(s)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return K()}}(t.compositeFilter.op))}(n):K()}function x0(n){return T0[n]}function N0(n){return A0[n]}function V0(n){return S0[n]}function di(n){return{fieldPath:n.canonicalString()}}function hi(n){return Fe.fromServerFormat(n.fieldPath)}function jy(n){return n instanceof he?function(t){if(t.op==="=="){if(ep(t.value))return{unaryFilter:{field:di(t.field),op:"IS_NAN"}};if(Zf(t.value))return{unaryFilter:{field:di(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(ep(t.value))return{unaryFilter:{field:di(t.field),op:"IS_NOT_NAN"}};if(Zf(t.value))return{unaryFilter:{field:di(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:di(t.field),op:N0(t.op),value:t.value}}}(n):n instanceof Ae?function(t){const s=t.getFilters().map(i=>jy(i));return s.length===1?s[0]:{compositeFilter:{op:V0(t.op),filters:s}}}(n):K()}function O0(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Wy(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class In{constructor(e,t,s,i,r=ee.min(),a=ee.min(),o=it.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=i,this.snapshotVersion=r,this.lastLimboFreeSnapshotVersion=a,this.resumeToken=o,this.expectedCount=l}withSequenceNumber(e){return new In(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new In(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new In(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new In(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zy{constructor(e){this.ct=e}}function M0(n,e){let t;if(e.document)t=P0(n.ct,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const s=B.fromSegments(e.noDocument.path),i=Us(e.noDocument.readTime);t=We.newNoDocument(s,i),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return K();{const s=B.fromSegments(e.unknownDocument.path),i=Us(e.unknownDocument.version);t=We.newUnknownDocument(s,i)}}return e.readTime&&t.setReadTime(function(i){const r=new Ue(i[0],i[1]);return ee.fromTimestamp(r)}(e.readTime)),t}function vp(n,e){const t=e.key,s={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:qo(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())s.document=function(r,a){return{name:Fo(r,a.key),fields:a.data.value.mapValue.fields,updateTime:$i(r,a.version.toTimestamp()),createTime:$i(r,a.createTime.toTimestamp())}}(n.ct,e);else if(e.isNoDocument())s.noDocument={path:t.path.toArray(),readTime:Fs(e.version)};else{if(!e.isUnknownDocument())return K();s.unknownDocument={path:t.path.toArray(),version:Fs(e.version)}}return s}function qo(n){const e=n.toTimestamp();return[e.seconds,e.nanoseconds]}function Fs(n){const e=n.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function Us(n){const e=new Ue(n.seconds,n.nanoseconds);return ee.fromTimestamp(e)}function Es(n,e){const t=(e.baseMutations||[]).map(r=>iu(n.ct,r));for(let r=0;r<e.mutations.length-1;++r){const a=e.mutations[r];if(r+1<e.mutations.length&&e.mutations[r+1].transform!==void 0){const o=e.mutations[r+1];a.updateTransforms=o.transform.fieldTransforms,e.mutations.splice(r+1,1),++r}}const s=e.mutations.map(r=>iu(n.ct,r)),i=Ue.fromMillis(e.localWriteTimeMs);return new Hu(e.batchId,i,t,s)}function Cr(n){const e=Us(n.readTime),t=n.lastLimboFreeSnapshotVersion!==void 0?Us(n.lastLimboFreeSnapshotVersion):ee.min();let s;return s=function(r){return r.documents!==void 0}(n.query)?function(r){return Z(r.documents.length===1),Nt(wa(My(r.documents[0])))}(n.query):function(r){return Nt(qy(r))}(n.query),new In(s,n.targetId,"TargetPurposeListen",n.lastListenSequenceNumber,e,t,it.fromBase64String(n.resumeToken))}function Gy(n,e){const t=Fs(e.snapshotVersion),s=Fs(e.lastLimboFreeSnapshotVersion);let i;i=Oo(e.target)?Fy(n.ct,e.target):Uy(n.ct,e.target)._t;const r=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:Ls(e.target),readTime:t,resumeToken:r,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:s,query:i}}function Ky(n){const e=qy({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Lo(e,e.limit,"L"):e}function vl(n,e){return new Ju(e.largestBatchId,iu(n.ct,e.overlayMutation))}function bp(n,e){const t=e.path.lastSegment();return[n,Tt(e.path.popLast()),t]}function _p(n,e,t,s){return{indexId:n,uid:e,sequenceNumber:t,readTime:Fs(s.readTime),documentKey:Tt(s.documentKey.path),largestBatchId:s.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L0{getBundleMetadata(e,t){return wp(e).get(t).next(s=>{if(s)return function(r){return{id:r.bundleId,createTime:Us(r.createTime),version:r.version}}(s)})}saveBundleMetadata(e,t){return wp(e).put(function(i){return{bundleId:i.id,createTime:Fs(At(i.createTime)),version:i.version}}(t))}getNamedQuery(e,t){return Ip(e).get(t).next(s=>{if(s)return function(r){return{name:r.name,query:Ky(r.bundledQuery),readTime:Us(r.readTime)}}(s)})}saveNamedQuery(e,t){return Ip(e).put(function(i){return{name:i.name,readTime:Fs(At(i.readTime)),bundledQuery:i.bundledQuery}}(t))}}function wp(n){return rt(n,"bundles")}function Ip(n){return rt(n,"namedQueries")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wc{constructor(e,t){this.serializer=e,this.userId=t}static lt(e,t){const s=t.uid||"";return new wc(e,s)}getOverlay(e,t){return yr(e).get(bp(this.userId,t)).next(s=>s?vl(this.serializer,s):null)}getOverlays(e,t){const s=tn();return $.forEach(t,i=>this.getOverlay(e,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(e,t,s){const i=[];return s.forEach((r,a)=>{const o=new Ju(t,a);i.push(this.ht(e,o))}),$.waitFor(i)}removeOverlaysForBatchId(e,t,s){const i=new Set;t.forEach(a=>i.add(Tt(a.getCollectionPath())));const r=[];return i.forEach(a=>{const o=IDBKeyRange.bound([this.userId,a,s],[this.userId,a,s+1],!1,!0);r.push(yr(e).j("collectionPathOverlayIndex",o))}),$.waitFor(r)}getOverlaysForCollection(e,t,s){const i=tn(),r=Tt(t),a=IDBKeyRange.bound([this.userId,r,s],[this.userId,r,Number.POSITIVE_INFINITY],!0);return yr(e).U("collectionPathOverlayIndex",a).next(o=>{for(const l of o){const u=vl(this.serializer,l);i.set(u.getKey(),u)}return i})}getOverlaysForCollectionGroup(e,t,s,i){const r=tn();let a;const o=IDBKeyRange.bound([this.userId,t,s],[this.userId,t,Number.POSITIVE_INFINITY],!0);return yr(e).J({index:"collectionGroupOverlayIndex",range:o},(l,u,h)=>{const p=vl(this.serializer,u);r.size()<i||p.largestBatchId===a?(r.set(p.getKey(),p),a=p.largestBatchId):h.done()}).next(()=>r)}ht(e,t){return yr(e).put(function(i,r,a){const[o,l,u]=bp(r,a.mutation.key);return{userId:r,collectionPath:l,documentId:u,collectionGroup:a.mutation.key.getCollectionGroup(),largestBatchId:a.largestBatchId,overlayMutation:Uo(i.ct,a.mutation)}}(this.serializer,this.userId,t))}}function yr(n){return rt(n,"documentOverlays")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ts{constructor(){}Pt(e,t){this.It(e,t),t.Tt()}It(e,t){if("nullValue"in e)this.Et(t,5);else if("booleanValue"in e)this.Et(t,10),t.dt(e.booleanValue?1:0);else if("integerValue"in e)this.Et(t,15),t.dt(je(e.integerValue));else if("doubleValue"in e){const s=je(e.doubleValue);isNaN(s)?this.Et(t,13):(this.Et(t,15),Yr(s)?t.dt(0):t.dt(s))}else if("timestampValue"in e){let s=e.timestampValue;this.Et(t,20),typeof s=="string"&&(s=An(s)),t.At(`${s.seconds||""}`),t.dt(s.nanos||0)}else if("stringValue"in e)this.Rt(e.stringValue,t),this.Vt(t);else if("bytesValue"in e)this.Et(t,30),t.ft(rs(e.bytesValue)),this.Vt(t);else if("referenceValue"in e)this.gt(e.referenceValue,t);else if("geoPointValue"in e){const s=e.geoPointValue;this.Et(t,45),t.dt(s.latitude||0),t.dt(s.longitude||0)}else"mapValue"in e?ry(e)?this.Et(t,Number.MAX_SAFE_INTEGER):(this.yt(e.mapValue,t),this.Vt(t)):"arrayValue"in e?(this.wt(e.arrayValue,t),this.Vt(t)):K()}Rt(e,t){this.Et(t,25),this.St(e,t)}St(e,t){t.At(e)}yt(e,t){const s=e.fields||{};this.Et(t,55);for(const i of Object.keys(s))this.Rt(i,t),this.It(s[i],t)}wt(e,t){const s=e.values||[];this.Et(t,50);for(const i of s)this.It(i,t)}gt(e,t){this.Et(t,37),B.fromName(e).path.forEach(s=>{this.Et(t,60),this.St(s,t)})}Et(e,t){e.dt(t)}Vt(e){e.dt(2)}}Ts.bt=new Ts;function F0(n){if(n===0)return 8;let e=0;return!(n>>4)&&(e+=4,n<<=4),!(n>>6)&&(e+=2,n<<=2),!(n>>7)&&(e+=1),e}function Ep(n){const e=64-function(s){let i=0;for(let r=0;r<8;++r){const a=F0(255&s[r]);if(i+=a,a!==8)break}return i}(n);return Math.ceil(e/8)}class U0{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Dt(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Ct(s.value),s=t.next();this.vt()}Ft(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Mt(s.value),s=t.next();this.xt()}Ot(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Ct(s);else if(s<2048)this.Ct(960|s>>>6),this.Ct(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Ct(480|s>>>12),this.Ct(128|63&s>>>6),this.Ct(128|63&s);else{const i=t.codePointAt(0);this.Ct(240|i>>>18),this.Ct(128|63&i>>>12),this.Ct(128|63&i>>>6),this.Ct(128|63&i)}}this.vt()}Nt(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Mt(s);else if(s<2048)this.Mt(960|s>>>6),this.Mt(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Mt(480|s>>>12),this.Mt(128|63&s>>>6),this.Mt(128|63&s);else{const i=t.codePointAt(0);this.Mt(240|i>>>18),this.Mt(128|63&i>>>12),this.Mt(128|63&i>>>6),this.Mt(128|63&i)}}this.xt()}Lt(e){const t=this.Bt(e),s=Ep(t);this.kt(1+s),this.buffer[this.position++]=255&s;for(let i=t.length-s;i<t.length;++i)this.buffer[this.position++]=255&t[i]}qt(e){const t=this.Bt(e),s=Ep(t);this.kt(1+s),this.buffer[this.position++]=~(255&s);for(let i=t.length-s;i<t.length;++i)this.buffer[this.position++]=~(255&t[i])}Qt(){this.Kt(255),this.Kt(255)}$t(){this.Ut(255),this.Ut(255)}reset(){this.position=0}seed(e){this.kt(e.length),this.buffer.set(e,this.position),this.position+=e.length}Wt(){return this.buffer.slice(0,this.position)}Bt(e){const t=function(r){const a=new DataView(new ArrayBuffer(8));return a.setFloat64(0,r,!1),new Uint8Array(a.buffer)}(e),s=(128&t[0])!=0;t[0]^=s?255:128;for(let i=1;i<t.length;++i)t[i]^=s?255:0;return t}Ct(e){const t=255&e;t===0?(this.Kt(0),this.Kt(255)):t===255?(this.Kt(255),this.Kt(0)):this.Kt(t)}Mt(e){const t=255&e;t===0?(this.Ut(0),this.Ut(255)):t===255?(this.Ut(255),this.Ut(0)):this.Ut(e)}vt(){this.Kt(0),this.Kt(1)}xt(){this.Ut(0),this.Ut(1)}Kt(e){this.kt(1),this.buffer[this.position++]=e}Ut(e){this.kt(1),this.buffer[this.position++]=~e}kt(e){const t=e+this.position;if(t<=this.buffer.length)return;let s=2*this.buffer.length;s<t&&(s=t);const i=new Uint8Array(s);i.set(this.buffer),this.buffer=i}}class q0{constructor(e){this.Gt=e}ft(e){this.Gt.Dt(e)}At(e){this.Gt.Ot(e)}dt(e){this.Gt.Lt(e)}Tt(){this.Gt.Qt()}}class B0{constructor(e){this.Gt=e}ft(e){this.Gt.Ft(e)}At(e){this.Gt.Nt(e)}dt(e){this.Gt.qt(e)}Tt(){this.Gt.$t()}}class vr{constructor(){this.Gt=new U0,this.zt=new q0(this.Gt),this.jt=new B0(this.Gt)}seed(e){this.Gt.seed(e)}Ht(e){return e===0?this.zt:this.jt}Wt(){return this.Gt.Wt()}reset(){this.Gt.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(e,t,s,i){this.indexId=e,this.documentKey=t,this.arrayValue=s,this.directionalValue=i}Jt(){const e=this.directionalValue.length,t=e===0||this.directionalValue[e-1]===255?e+1:e,s=new Uint8Array(t);return s.set(this.directionalValue,0),t!==e?s.set([0],this.directionalValue.length):++s[s.length-1],new As(this.indexId,this.documentKey,this.arrayValue,s)}}function On(n,e){let t=n.indexId-e.indexId;return t!==0?t:(t=Tp(n.arrayValue,e.arrayValue),t!==0?t:(t=Tp(n.directionalValue,e.directionalValue),t!==0?t:B.comparator(n.documentKey,e.documentKey)))}function Tp(n,e){for(let t=0;t<n.length&&t<e.length;++t){const s=n[t]-e[t];if(s!==0)return s}return n.length-e.length}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ap{constructor(e){this.Yt=new ke((t,s)=>Fe.comparator(t.field,s.field)),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.Zt=e.orderBy,this.Xt=[];for(const t of e.filters){const s=t;s.isInequality()?this.Yt=this.Yt.add(s):this.Xt.push(s)}}get en(){return this.Yt.size>1}tn(e){if(Z(e.collectionGroup===this.collectionId),this.en)return!1;const t=Kl(e);if(t!==void 0&&!this.nn(t))return!1;const s=ws(e);let i=new Set,r=0,a=0;for(;r<s.length&&this.nn(s[r]);++r)i=i.add(s[r].fieldPath.canonicalString());if(r===s.length)return!0;if(this.Yt.size>0){const o=this.Yt.getIterator().getNext();if(!i.has(o.field.canonicalString())){const l=s[r];if(!this.rn(o,l)||!this.sn(this.Zt[a++],l))return!1}++r}for(;r<s.length;++r){const o=s[r];if(a>=this.Zt.length||!this.sn(this.Zt[a++],o))return!1}return!0}on(){if(this.en)return null;let e=new ke(Fe.comparator);const t=[];for(const s of this.Xt)if(!s.field.isKeyField())if(s.op==="array-contains"||s.op==="array-contains-any")t.push(new po(s.field,2));else{if(e.has(s.field))continue;e=e.add(s.field),t.push(new po(s.field,0))}for(const s of this.Zt)s.field.isKeyField()||e.has(s.field)||(e=e.add(s.field),t.push(new po(s.field,s.dir==="asc"?0:1)));return new Vo(Vo.UNKNOWN_ID,this.collectionId,t,Jr.empty())}nn(e){for(const t of this.Xt)if(this.rn(t,e))return!0;return!1}rn(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const s=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===s}sn(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hy(n){var e,t;if(Z(n instanceof he||n instanceof Ae),n instanceof he){if(n instanceof fy){const i=((t=(e=n.value.arrayValue)===null||e===void 0?void 0:e.values)===null||t===void 0?void 0:t.map(r=>he.create(n.field,"==",r)))||[];return Ae.create(i,"or")}return n}const s=n.filters.map(i=>Hy(i));return Ae.create(s,n.op)}function j0(n){if(n.getFilters().length===0)return[];const e=ou(Hy(n));return Z(Qy(e)),ru(e)||au(e)?[e]:e.getFilters()}function ru(n){return n instanceof he}function au(n){return n instanceof Ae&&Gu(n)}function Qy(n){return ru(n)||au(n)||function(t){if(t instanceof Ae&&Yl(t)){for(const s of t.getFilters())if(!ru(s)&&!au(s))return!1;return!0}return!1}(n)}function ou(n){if(Z(n instanceof he||n instanceof Ae),n instanceof he)return n;if(n.filters.length===1)return ou(n.filters[0]);const e=n.filters.map(s=>ou(s));let t=Ae.create(e,n.op);return t=Bo(t),Qy(t)?t:(Z(t instanceof Ae),Z(Ri(t)),Z(t.filters.length>1),t.filters.reduce((s,i)=>Zu(s,i)))}function Zu(n,e){let t;return Z(n instanceof he||n instanceof Ae),Z(e instanceof he||e instanceof Ae),t=n instanceof he?e instanceof he?function(i,r){return Ae.create([i,r],"and")}(n,e):Sp(n,e):e instanceof he?Sp(e,n):function(i,r){if(Z(i.filters.length>0&&r.filters.length>0),Ri(i)&&Ri(r))return uy(i,r.getFilters());const a=Yl(i)?i:r,o=Yl(i)?r:i,l=a.filters.map(u=>Zu(u,o));return Ae.create(l,"or")}(n,e),Bo(t)}function Sp(n,e){if(Ri(e))return uy(e,n.getFilters());{const t=e.filters.map(s=>Zu(n,s));return Ae.create(t,"or")}}function Bo(n){if(Z(n instanceof he||n instanceof Ae),n instanceof he)return n;const e=n.getFilters();if(e.length===1)return Bo(e[0]);if(cy(n))return n;const t=e.map(i=>Bo(i)),s=[];return t.forEach(i=>{i instanceof he?s.push(i):i instanceof Ae&&(i.op===n.op?s.push(...i.filters):s.push(i))}),s.length===1?s[0]:Ae.create(s,n.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W0{constructor(){this._n=new ed}addToCollectionParentIndex(e,t){return this._n.add(t),$.resolve()}getCollectionParents(e,t){return $.resolve(this._n.getEntries(t))}addFieldIndex(e,t){return $.resolve()}deleteFieldIndex(e,t){return $.resolve()}deleteAllFieldIndexes(e){return $.resolve()}createTargetIndexes(e,t){return $.resolve()}getDocumentsMatchingTarget(e,t){return $.resolve(null)}getIndexType(e,t){return $.resolve(0)}getFieldIndexes(e,t){return $.resolve([])}getNextCollectionGroupToUpdate(e){return $.resolve(null)}getMinOffset(e,t){return $.resolve(Ot.min())}getMinOffsetFromCollectionGroup(e,t){return $.resolve(Ot.min())}updateCollectionGroup(e,t,s){return $.resolve()}updateIndexEntries(e,t){return $.resolve()}}class ed{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),i=this.index[t]||new ke(Ee.comparator),r=!i.has(s);return this.index[t]=i.add(s),r}has(e){const t=e.lastSegment(),s=e.popLast(),i=this.index[t];return i&&i.has(s)}getEntries(e){return(this.index[e]||new ke(Ee.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xa=new Uint8Array(0);class z0{constructor(e,t){this.databaseId=t,this.an=new ed,this.un=new fs(s=>Ls(s),(s,i)=>_a(s,i)),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.an.has(t)){const s=t.lastSegment(),i=t.popLast();e.addOnCommittedListener(()=>{this.an.add(t)});const r={collectionId:s,parent:Tt(i)};return kp(e).put(r)}return $.resolve()}getCollectionParents(e,t){const s=[],i=IDBKeyRange.bound([t,""],[zg(t),""],!1,!0);return kp(e).U(i).next(r=>{for(const a of r){if(a.collectionId!==t)break;s.push(en(a.parent))}return s})}addFieldIndex(e,t){const s=br(e),i=function(o){return{indexId:o.indexId,collectionGroup:o.collectionGroup,fields:o.fields.map(l=>[l.fieldPath.canonicalString(),l.kind])}}(t);delete i.indexId;const r=s.add(i);if(t.indexState){const a=ni(e);return r.next(o=>{a.put(_p(o,this.uid,t.indexState.sequenceNumber,t.indexState.offset))})}return r.next()}deleteFieldIndex(e,t){const s=br(e),i=ni(e),r=ti(e);return s.delete(t.indexId).next(()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))).next(()=>r.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))}deleteAllFieldIndexes(e){const t=br(e),s=ti(e),i=ni(e);return t.j().next(()=>s.j()).next(()=>i.j())}createTargetIndexes(e,t){return $.forEach(this.cn(t),s=>this.getIndexType(e,s).next(i=>{if(i===0||i===1){const r=new Ap(s).on();if(r!=null)return this.addFieldIndex(e,r)}}))}getDocumentsMatchingTarget(e,t){const s=ti(e);let i=!0;const r=new Map;return $.forEach(this.cn(t),a=>this.ln(e,a).next(o=>{i&&(i=!!o),r.set(a,o)})).next(()=>{if(i){let a=ce();const o=[];return $.forEach(r,(l,u)=>{V("IndexedDbIndexManager",`Using index ${function(H){return`id=${H.indexId}|cg=${H.collectionGroup}|f=${H.fields.map(ae=>`${ae.fieldPath}:${ae.kind}`).join(",")}`}(l)} to execute ${Ls(t)}`);const h=function(H,ae){const O=Kl(ae);if(O===void 0)return null;for(const U of Mo(H,O.fieldPath))switch(U.op){case"array-contains-any":return U.value.arrayValue.values||[];case"array-contains":return[U.value]}return null}(u,l),p=function(H,ae){const O=new Map;for(const U of ws(ae))for(const _ of Mo(H,U.fieldPath))switch(_.op){case"==":case"in":O.set(U.fieldPath.canonicalString(),_.value);break;case"not-in":case"!=":return O.set(U.fieldPath.canonicalString(),_.value),Array.from(O.values())}return null}(u,l),m=function(H,ae){const O=[];let U=!0;for(const _ of ws(ae)){const y=_.kind===0?rp(H,_.fieldPath,H.startAt):ap(H,_.fieldPath,H.startAt);O.push(y.value),U&&(U=y.inclusive)}return new ki(O,U)}(u,l),w=function(H,ae){const O=[];let U=!0;for(const _ of ws(ae)){const y=_.kind===0?ap(H,_.fieldPath,H.endAt):rp(H,_.fieldPath,H.endAt);O.push(y.value),U&&(U=y.inclusive)}return new ki(O,U)}(u,l),E=this.hn(l,u,m),x=this.hn(l,u,w),C=this.Pn(l,u,p),j=this.In(l.indexId,h,E,m.inclusive,x,w.inclusive,C);return $.forEach(j,J=>s.G(J,t.limit).next(H=>{H.forEach(ae=>{const O=B.fromSegments(ae.documentKey);a.has(O)||(a=a.add(O),o.push(O))})}))}).next(()=>o)}return $.resolve(null)})}cn(e){let t=this.un.get(e);return t||(e.filters.length===0?t=[e]:t=j0(Ae.create(e.filters,"and")).map(s=>Zl(e.path,e.collectionGroup,e.orderBy,s.getFilters(),e.limit,e.startAt,e.endAt)),this.un.set(e,t),t)}In(e,t,s,i,r,a,o){const l=(t!=null?t.length:1)*Math.max(s.length,r.length),u=l/(t!=null?t.length:1),h=[];for(let p=0;p<l;++p){const m=t?this.Tn(t[p/u]):Xa,w=this.En(e,m,s[p%u],i),E=this.dn(e,m,r[p%u],a),x=o.map(C=>this.En(e,m,C,!0));h.push(...this.createRange(w,E,x))}return h}En(e,t,s,i){const r=new As(e,B.empty(),t,s);return i?r:r.Jt()}dn(e,t,s,i){const r=new As(e,B.empty(),t,s);return i?r.Jt():r}ln(e,t){const s=new Ap(t),i=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,i).next(r=>{let a=null;for(const o of r)s.tn(o)&&(!a||o.fields.length>a.fields.length)&&(a=o);return a})}getIndexType(e,t){let s=2;const i=this.cn(t);return $.forEach(i,r=>this.ln(e,r).next(a=>{a?s!==0&&a.fields.length<function(l){let u=new ke(Fe.comparator),h=!1;for(const p of l.filters)for(const m of p.getFlattenedFilters())m.field.isKeyField()||(m.op==="array-contains"||m.op==="array-contains-any"?h=!0:u=u.add(m.field));for(const p of l.orderBy)p.field.isKeyField()||(u=u.add(p.field));return u.size+(h?1:0)}(r)&&(s=1):s=0})).next(()=>function(a){return a.limit!==null}(t)&&i.length>1&&s===2?1:s)}An(e,t){const s=new vr;for(const i of ws(e)){const r=t.data.field(i.fieldPath);if(r==null)return null;const a=s.Ht(i.kind);Ts.bt.Pt(r,a)}return s.Wt()}Tn(e){const t=new vr;return Ts.bt.Pt(e,t.Ht(0)),t.Wt()}Rn(e,t){const s=new vr;return Ts.bt.Pt(ea(this.databaseId,t),s.Ht(function(r){const a=ws(r);return a.length===0?0:a[a.length-1].kind}(e))),s.Wt()}Pn(e,t,s){if(s===null)return[];let i=[];i.push(new vr);let r=0;for(const a of ws(e)){const o=s[r++];for(const l of i)if(this.Vn(t,a.fieldPath)&&ta(o))i=this.mn(i,a,o);else{const u=l.Ht(a.kind);Ts.bt.Pt(o,u)}}return this.fn(i)}hn(e,t,s){return this.Pn(e,t,s.position)}fn(e){const t=[];for(let s=0;s<e.length;++s)t[s]=e[s].Wt();return t}mn(e,t,s){const i=[...e],r=[];for(const a of s.arrayValue.values||[])for(const o of i){const l=new vr;l.seed(o.Wt()),Ts.bt.Pt(a,l.Ht(t.kind)),r.push(l)}return r}Vn(e,t){return!!e.filters.find(s=>s instanceof he&&s.field.isEqual(t)&&(s.op==="in"||s.op==="not-in"))}getFieldIndexes(e,t){const s=br(e),i=ni(e);return(t?s.U("collectionGroupIndex",IDBKeyRange.bound(t,t)):s.U()).next(r=>{const a=[];return $.forEach(r,o=>i.get([o.indexId,this.uid]).next(l=>{a.push(function(h,p){const m=p?new Jr(p.sequenceNumber,new Ot(Us(p.readTime),new B(en(p.documentKey)),p.largestBatchId)):Jr.empty(),w=h.fields.map(([E,x])=>new po(Fe.fromServerFormat(E),x));return new Vo(h.indexId,h.collectionGroup,w,m)}(o,l))})).next(()=>a)})}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next(t=>t.length===0?null:(t.sort((s,i)=>{const r=s.indexState.sequenceNumber-i.indexState.sequenceNumber;return r!==0?r:ie(s.collectionGroup,i.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(e,t,s){const i=br(e),r=ni(e);return this.gn(e).next(a=>i.U("collectionGroupIndex",IDBKeyRange.bound(t,t)).next(o=>$.forEach(o,l=>r.put(_p(l.indexId,this.uid,a,s)))))}updateIndexEntries(e,t){const s=new Map;return $.forEach(t,(i,r)=>{const a=s.get(i.collectionGroup);return(a?$.resolve(a):this.getFieldIndexes(e,i.collectionGroup)).next(o=>(s.set(i.collectionGroup,o),$.forEach(o,l=>this.pn(e,i,l).next(u=>{const h=this.yn(r,l);return u.isEqual(h)?$.resolve():this.wn(e,r,l,u,h)}))))})}Sn(e,t,s,i){return ti(e).put({indexId:i.indexId,uid:this.uid,arrayValue:i.arrayValue,directionalValue:i.directionalValue,orderedDocumentKey:this.Rn(s,t.key),documentKey:t.key.path.toArray()})}bn(e,t,s,i){return ti(e).delete([i.indexId,this.uid,i.arrayValue,i.directionalValue,this.Rn(s,t.key),t.key.path.toArray()])}pn(e,t,s){const i=ti(e);let r=new ke(On);return i.J({index:"documentKeyIndex",range:IDBKeyRange.only([s.indexId,this.uid,this.Rn(s,t)])},(a,o)=>{r=r.add(new As(s.indexId,t,o.arrayValue,o.directionalValue))}).next(()=>r)}yn(e,t){let s=new ke(On);const i=this.An(t,e);if(i==null)return s;const r=Kl(t);if(r!=null){const a=e.data.field(r.fieldPath);if(ta(a))for(const o of a.arrayValue.values||[])s=s.add(new As(t.indexId,e.key,this.Tn(o),i))}else s=s.add(new As(t.indexId,e.key,Xa,i));return s}wn(e,t,s,i,r){V("IndexedDbIndexManager","Updating index entries for document '%s'",t.key);const a=[];return function(l,u,h,p,m){const w=l.getIterator(),E=u.getIterator();let x=ei(w),C=ei(E);for(;x||C;){let j=!1,J=!1;if(x&&C){const H=h(x,C);H<0?J=!0:H>0&&(j=!0)}else x!=null?J=!0:j=!0;j?(p(C),C=ei(E)):J?(m(x),x=ei(w)):(x=ei(w),C=ei(E))}}(i,r,On,o=>{a.push(this.Sn(e,t,s,o))},o=>{a.push(this.bn(e,t,s,o))}),$.waitFor(a)}gn(e){let t=1;return ni(e).J({index:"sequenceNumberIndex",reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(s,i,r)=>{r.done(),t=i.sequenceNumber+1}).next(()=>t)}createRange(e,t,s){s=s.sort((a,o)=>On(a,o)).filter((a,o,l)=>!o||On(a,l[o-1])!==0);const i=[];i.push(e);for(const a of s){const o=On(a,e),l=On(a,t);if(o===0)i[0]=e.Jt();else if(o>0&&l<0)i.push(a),i.push(a.Jt());else if(l>0)break}i.push(t);const r=[];for(let a=0;a<i.length;a+=2){if(this.Dn(i[a],i[a+1]))return[];const o=[i[a].indexId,this.uid,i[a].arrayValue,i[a].directionalValue,Xa,[]],l=[i[a+1].indexId,this.uid,i[a+1].arrayValue,i[a+1].directionalValue,Xa,[]];r.push(IDBKeyRange.bound(o,l))}return r}Dn(e,t){return On(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(Rp)}getMinOffset(e,t){return $.mapArray(this.cn(t),s=>this.ln(e,s).next(i=>i||K())).next(Rp)}}function kp(n){return rt(n,"collectionParents")}function ti(n){return rt(n,"indexEntries")}function br(n){return rt(n,"indexConfiguration")}function ni(n){return rt(n,"indexState")}function Rp(n){Z(n.length!==0);let e=n[0].indexState.offset,t=e.largestBatchId;for(let s=1;s<n.length;s++){const i=n[s].indexState.offset;Bu(i,e)<0&&(e=i),t<i.largestBatchId&&(t=i.largestBatchId)}return new Ot(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pp={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class Rt{constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}static withCacheSize(e){return new Rt(e,Rt.DEFAULT_COLLECTION_PERCENTILE,Rt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jy(n,e,t){const s=n.store("mutations"),i=n.store("documentMutations"),r=[],a=IDBKeyRange.only(t.batchId);let o=0;const l=s.J({range:a},(h,p,m)=>(o++,m.delete()));r.push(l.next(()=>{Z(o===1)}));const u=[];for(const h of t.mutations){const p=Xg(e,h.key.path,t.batchId);r.push(i.delete(p)),u.push(h.key)}return $.waitFor(r).next(()=>u)}function jo(n){if(!n)return 0;let e;if(n.document)e=n.document;else if(n.unknownDocument)e=n.unknownDocument;else{if(!n.noDocument)throw K();e=n.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Rt.DEFAULT_COLLECTION_PERCENTILE=10,Rt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Rt.DEFAULT=new Rt(41943040,Rt.DEFAULT_COLLECTION_PERCENTILE,Rt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Rt.DISABLED=new Rt(-1,0,0);class Ic{constructor(e,t,s,i){this.userId=e,this.serializer=t,this.indexManager=s,this.referenceDelegate=i,this.Cn={}}static lt(e,t,s,i){Z(e.uid!=="");const r=e.isAuthenticated()?e.uid:"";return new Ic(r,t,s,i)}checkEmpty(e){let t=!0;const s=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Mn(e).J({index:"userMutationsIndex",range:s},(i,r,a)=>{t=!1,a.done()}).next(()=>t)}addMutationBatch(e,t,s,i){const r=fi(e),a=Mn(e);return a.add({}).next(o=>{Z(typeof o=="number");const l=new Hu(o,t,s,i),u=function(w,E,x){const C=x.baseMutations.map(J=>Uo(w.ct,J)),j=x.mutations.map(J=>Uo(w.ct,J));return{userId:E,batchId:x.batchId,localWriteTimeMs:x.localWriteTime.toMillis(),baseMutations:C,mutations:j}}(this.serializer,this.userId,l),h=[];let p=new ke((m,w)=>ie(m.canonicalString(),w.canonicalString()));for(const m of i){const w=Xg(this.userId,m.key.path,o);p=p.add(m.key.path.popLast()),h.push(a.put(u)),h.push(r.put(w,CT))}return p.forEach(m=>{h.push(this.indexManager.addToCollectionParentIndex(e,m))}),e.addOnCommittedListener(()=>{this.Cn[o]=l.keys()}),$.waitFor(h).next(()=>l)})}lookupMutationBatch(e,t){return Mn(e).get(t).next(s=>s?(Z(s.userId===this.userId),Es(this.serializer,s)):null)}vn(e,t){return this.Cn[t]?$.resolve(this.Cn[t]):this.lookupMutationBatch(e,t).next(s=>{if(s){const i=s.keys();return this.Cn[t]=i,i}return null})}getNextMutationBatchAfterBatchId(e,t){const s=t+1,i=IDBKeyRange.lowerBound([this.userId,s]);let r=null;return Mn(e).J({index:"userMutationsIndex",range:i},(a,o,l)=>{o.userId===this.userId&&(Z(o.batchId>=s),r=Es(this.serializer,o)),l.done()}).next(()=>r)}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let s=-1;return Mn(e).J({index:"userMutationsIndex",range:t,reverse:!0},(i,r,a)=>{s=r.batchId,a.done()}).next(()=>s)}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return Mn(e).U("userMutationsIndex",t).next(s=>s.map(i=>Es(this.serializer,i)))}getAllMutationBatchesAffectingDocumentKey(e,t){const s=mo(this.userId,t.path),i=IDBKeyRange.lowerBound(s),r=[];return fi(e).J({range:i},(a,o,l)=>{const[u,h,p]=a,m=en(h);if(u===this.userId&&t.path.isEqual(m))return Mn(e).get(p).next(w=>{if(!w)throw K();Z(w.userId===this.userId),r.push(Es(this.serializer,w))});l.done()}).next(()=>r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new ke(ie);const i=[];return t.forEach(r=>{const a=mo(this.userId,r.path),o=IDBKeyRange.lowerBound(a),l=fi(e).J({range:o},(u,h,p)=>{const[m,w,E]=u,x=en(w);m===this.userId&&r.path.isEqual(x)?s=s.add(E):p.done()});i.push(l)}),$.waitFor(i).next(()=>this.Fn(e,s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,i=s.length+1,r=mo(this.userId,s),a=IDBKeyRange.lowerBound(r);let o=new ke(ie);return fi(e).J({range:a},(l,u,h)=>{const[p,m,w]=l,E=en(m);p===this.userId&&s.isPrefixOf(E)?E.length===i&&(o=o.add(w)):h.done()}).next(()=>this.Fn(e,o))}Fn(e,t){const s=[],i=[];return t.forEach(r=>{i.push(Mn(e).get(r).next(a=>{if(a===null)throw K();Z(a.userId===this.userId),s.push(Es(this.serializer,a))}))}),$.waitFor(i).next(()=>s)}removeMutationBatch(e,t){return Jy(e._e,this.userId,t).next(s=>(e.addOnCommittedListener(()=>{this.Mn(t.batchId)}),$.forEach(s,i=>this.referenceDelegate.markPotentiallyOrphaned(e,i))))}Mn(e){delete this.Cn[e]}performConsistencyCheck(e){return this.checkEmpty(e).next(t=>{if(!t)return $.resolve();const s=IDBKeyRange.lowerBound(function(a){return[a]}(this.userId)),i=[];return fi(e).J({range:s},(r,a,o)=>{if(r[0]===this.userId){const l=en(r[1]);i.push(l)}else o.done()}).next(()=>{Z(i.length===0)})})}containsKey(e,t){return Yy(e,this.userId,t)}xn(e){return Xy(e).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:-1,lastStreamToken:""})}}function Yy(n,e,t){const s=mo(e,t.path),i=s[1],r=IDBKeyRange.lowerBound(s);let a=!1;return fi(n).J({range:r,H:!0},(o,l,u)=>{const[h,p,m]=o;h===e&&p===i&&(a=!0),u.done()}).next(()=>a)}function Mn(n){return rt(n,"mutations")}function fi(n){return rt(n,"documentMutations")}function Xy(n){return rt(n,"mutationQueues")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs{constructor(e){this.On=e}next(){return this.On+=2,this.On}static Nn(){return new qs(0)}static Ln(){return new qs(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class G0{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.Bn(e).next(t=>{const s=new qs(t.highestTargetId);return t.highestTargetId=s.next(),this.kn(e,t).next(()=>t.highestTargetId)})}getLastRemoteSnapshotVersion(e){return this.Bn(e).next(t=>ee.fromTimestamp(new Ue(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(e){return this.Bn(e).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(e,t,s){return this.Bn(e).next(i=>(i.highestListenSequenceNumber=t,s&&(i.lastRemoteSnapshotVersion=s.toTimestamp()),t>i.highestListenSequenceNumber&&(i.highestListenSequenceNumber=t),this.kn(e,i)))}addTargetData(e,t){return this.qn(e,t).next(()=>this.Bn(e).next(s=>(s.targetCount+=1,this.Qn(t,s),this.kn(e,s))))}updateTargetData(e,t){return this.qn(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next(()=>si(e).delete(t.targetId)).next(()=>this.Bn(e)).next(s=>(Z(s.targetCount>0),s.targetCount-=1,this.kn(e,s)))}removeTargets(e,t,s){let i=0;const r=[];return si(e).J((a,o)=>{const l=Cr(o);l.sequenceNumber<=t&&s.get(l.targetId)===null&&(i++,r.push(this.removeTargetData(e,l)))}).next(()=>$.waitFor(r)).next(()=>i)}forEachTarget(e,t){return si(e).J((s,i)=>{const r=Cr(i);t(r)})}Bn(e){return Cp(e).get("targetGlobalKey").next(t=>(Z(t!==null),t))}kn(e,t){return Cp(e).put("targetGlobalKey",t)}qn(e,t){return si(e).put(Gy(this.serializer,t))}Qn(e,t){let s=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,s=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,s=!0),s}getTargetCount(e){return this.Bn(e).next(t=>t.targetCount)}getTargetData(e,t){const s=Ls(t),i=IDBKeyRange.bound([s,Number.NEGATIVE_INFINITY],[s,Number.POSITIVE_INFINITY]);let r=null;return si(e).J({range:i,index:"queryTargetsIndex"},(a,o,l)=>{const u=Cr(o);_a(t,u.target)&&(r=u,l.done())}).next(()=>r)}addMatchingKeys(e,t,s){const i=[],r=zn(e);return t.forEach(a=>{const o=Tt(a.path);i.push(r.put({targetId:s,path:o})),i.push(this.referenceDelegate.addReference(e,s,a))}),$.waitFor(i)}removeMatchingKeys(e,t,s){const i=zn(e);return $.forEach(t,r=>{const a=Tt(r.path);return $.waitFor([i.delete([s,a]),this.referenceDelegate.removeReference(e,s,r)])})}removeMatchingKeysForTargetId(e,t){const s=zn(e),i=IDBKeyRange.bound([t],[t+1],!1,!0);return s.delete(i)}getMatchingKeysForTargetId(e,t){const s=IDBKeyRange.bound([t],[t+1],!1,!0),i=zn(e);let r=ce();return i.J({range:s,H:!0},(a,o,l)=>{const u=en(a[1]),h=new B(u);r=r.add(h)}).next(()=>r)}containsKey(e,t){const s=Tt(t.path),i=IDBKeyRange.bound([s],[zg(s)],!1,!0);let r=0;return zn(e).J({index:"documentTargetsIndex",H:!0,range:i},([a,o],l,u)=>{a!==0&&(r++,u.done())}).next(()=>r>0)}ot(e,t){return si(e).get(t).next(s=>s?Cr(s):null)}}function si(n){return rt(n,"targets")}function Cp(n){return rt(n,"targetGlobal")}function zn(n){return rt(n,"targetDocuments")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $p([n,e],[t,s]){const i=ie(n,t);return i===0?ie(e,s):i}class K0{constructor(e){this.Kn=e,this.buffer=new ke($p),this.$n=0}Un(){return++this.$n}Wn(e){const t=[e,this.Un()];if(this.buffer.size<this.Kn)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();$p(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class H0{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.Gn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.zn(6e4)}stop(){this.Gn&&(this.Gn.cancel(),this.Gn=null)}get started(){return this.Gn!==null}zn(e){V("LruGarbageCollector",`Garbage collection scheduled in ${e}ms`),this.Gn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Gn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){hs(t)?V("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",t):await ds(t)}await this.zn(3e5)})}}class Q0{constructor(e,t){this.jn=e,this.params=t}calculateTargetCount(e,t){return this.jn.Hn(e).next(s=>Math.floor(t/100*s))}nthSequenceNumber(e,t){if(t===0)return $.resolve(Pt.oe);const s=new K0(t);return this.jn.forEachTarget(e,i=>s.Wn(i.sequenceNumber)).next(()=>this.jn.Jn(e,i=>s.Wn(i))).next(()=>s.maxValue)}removeTargets(e,t,s){return this.jn.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.jn.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(V("LruGarbageCollector","Garbage collection skipped; disabled"),$.resolve(Pp)):this.getCacheSize(e).next(s=>s<this.params.cacheSizeCollectionThreshold?(V("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Pp):this.Yn(e,t))}getCacheSize(e){return this.jn.getCacheSize(e)}Yn(e,t){let s,i,r,a,o,l,u;const h=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(p=>(p>this.params.maximumSequenceNumbersToCollect?(V("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${p}`),i=this.params.maximumSequenceNumbersToCollect):i=p,a=Date.now(),this.nthSequenceNumber(e,i))).next(p=>(s=p,o=Date.now(),this.removeTargets(e,s,t))).next(p=>(r=p,l=Date.now(),this.removeOrphanedDocuments(e,s))).next(p=>(u=Date.now(),li()<=de.DEBUG&&V("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${a-h}ms
	Determined least recently used ${i} in `+(o-a)+`ms
	Removed ${r} targets in `+(l-o)+`ms
	Removed ${p} documents in `+(u-l)+`ms
Total Duration: ${u-h}ms`),$.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:r,documentsRemoved:p})))}}function J0(n,e){return new Q0(n,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y0{constructor(e,t){this.db=e,this.garbageCollector=J0(this,t)}Hn(e){const t=this.Zn(e);return this.db.getTargetCache().getTargetCount(e).next(s=>t.next(i=>s+i))}Zn(e){let t=0;return this.Jn(e,s=>{t++}).next(()=>t)}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}Jn(e,t){return this.Xn(e,(s,i)=>t(i))}addReference(e,t,s){return Za(e,s)}removeReference(e,t,s){return Za(e,s)}removeTargets(e,t,s){return this.db.getTargetCache().removeTargets(e,t,s)}markPotentiallyOrphaned(e,t){return Za(e,t)}er(e,t){return function(i,r){let a=!1;return Xy(i).Y(o=>Yy(i,o,r).next(l=>(l&&(a=!0),$.resolve(!l)))).next(()=>a)}(e,t)}removeOrphanedDocuments(e,t){const s=this.db.getRemoteDocumentCache().newChangeBuffer(),i=[];let r=0;return this.Xn(e,(a,o)=>{if(o<=t){const l=this.er(e,a).next(u=>{if(!u)return r++,s.getEntry(e,a).next(()=>(s.removeEntry(a,ee.min()),zn(e).delete(function(p){return[0,Tt(p.path)]}(a))))});i.push(l)}}).next(()=>$.waitFor(i)).next(()=>s.apply(e)).next(()=>r)}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,s)}updateLimboDocument(e,t){return Za(e,t)}Xn(e,t){const s=zn(e);let i,r=Pt.oe;return s.J({index:"documentTargetsIndex"},([a,o],{path:l,sequenceNumber:u})=>{a===0?(r!==Pt.oe&&t(new B(en(i)),r),r=u,i=l):r=Pt.oe}).next(()=>{r!==Pt.oe&&t(new B(en(i)),r)})}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function Za(n,e){return zn(n).put(function(s,i){return{targetId:0,path:Tt(s.path),sequenceNumber:i}}(e,n.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zy{constructor(){this.changes=new fs(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,We.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?$.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class X0{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,s){return bs(e).put(s)}removeEntry(e,t,s){return bs(e).delete(function(r,a){const o=r.path.toArray();return[o.slice(0,o.length-2),o[o.length-2],qo(a),o[o.length-1]]}(t,s))}updateMetadata(e,t){return this.getMetadata(e).next(s=>(s.byteSize+=t,this.tr(e,s)))}getEntry(e,t){let s=We.newInvalidDocument(t);return bs(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(_r(t))},(i,r)=>{s=this.nr(t,r)}).next(()=>s)}rr(e,t){let s={size:0,document:We.newInvalidDocument(t)};return bs(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(_r(t))},(i,r)=>{s={document:this.nr(t,r),size:jo(r)}}).next(()=>s)}getEntries(e,t){let s=xt();return this.ir(e,t,(i,r)=>{const a=this.nr(i,r);s=s.insert(i,a)}).next(()=>s)}sr(e,t){let s=xt(),i=new Ne(B.comparator);return this.ir(e,t,(r,a)=>{const o=this.nr(r,a);s=s.insert(r,o),i=i.insert(r,jo(a))}).next(()=>({documents:s,_r:i}))}ir(e,t,s){if(t.isEmpty())return $.resolve();let i=new ke(Np);t.forEach(l=>i=i.add(l));const r=IDBKeyRange.bound(_r(i.first()),_r(i.last())),a=i.getIterator();let o=a.getNext();return bs(e).J({index:"documentKeyIndex",range:r},(l,u,h)=>{const p=B.fromSegments([...u.prefixPath,u.collectionGroup,u.documentId]);for(;o&&Np(o,p)<0;)s(o,null),o=a.getNext();o&&o.isEqual(p)&&(s(o,u),o=a.hasNext()?a.getNext():null),o?h.$(_r(o)):h.done()}).next(()=>{for(;o;)s(o,null),o=a.hasNext()?a.getNext():null})}getDocumentsMatchingQuery(e,t,s,i,r){const a=t.path,o=[a.popLast().toArray(),a.lastSegment(),qo(s.readTime),s.documentKey.path.isEmpty()?"":s.documentKey.path.lastSegment()],l=[a.popLast().toArray(),a.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return bs(e).U(IDBKeyRange.bound(o,l,!0)).next(u=>{r==null||r.incrementDocumentReadCount(u.length);let h=xt();for(const p of u){const m=this.nr(B.fromSegments(p.prefixPath.concat(p.collectionGroup,p.documentId)),p);m.isFoundDocument()&&(Ia(t,m)||i.has(m.key))&&(h=h.insert(m.key,m))}return h})}getAllFromCollectionGroup(e,t,s,i){let r=xt();const a=xp(t,s),o=xp(t,Ot.max());return bs(e).J({index:"collectionGroupIndex",range:IDBKeyRange.bound(a,o,!0)},(l,u,h)=>{const p=this.nr(B.fromSegments(u.prefixPath.concat(u.collectionGroup,u.documentId)),u);r=r.insert(p.key,p),r.size===i&&h.done()}).next(()=>r)}newChangeBuffer(e){return new Z0(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next(t=>t.byteSize)}getMetadata(e){return Dp(e).get("remoteDocumentGlobalKey").next(t=>(Z(!!t),t))}tr(e,t){return Dp(e).put("remoteDocumentGlobalKey",t)}nr(e,t){if(t){const s=M0(this.serializer,t);if(!(s.isNoDocument()&&s.version.isEqual(ee.min())))return s}return We.newInvalidDocument(e)}}function ev(n){return new X0(n)}class Z0 extends Zy{constructor(e,t){super(),this.ar=e,this.trackRemovals=t,this.ur=new fs(s=>s.toString(),(s,i)=>s.isEqual(i))}applyChanges(e){const t=[];let s=0,i=new ke((r,a)=>ie(r.canonicalString(),a.canonicalString()));return this.changes.forEach((r,a)=>{const o=this.ur.get(r);if(t.push(this.ar.removeEntry(e,r,o.readTime)),a.isValidDocument()){const l=vp(this.ar.serializer,a);i=i.add(r.path.popLast());const u=jo(l);s+=u-o.size,t.push(this.ar.addEntry(e,r,l))}else if(s-=o.size,this.trackRemovals){const l=vp(this.ar.serializer,a.convertToNoDocument(ee.min()));t.push(this.ar.addEntry(e,r,l))}}),i.forEach(r=>{t.push(this.ar.indexManager.addToCollectionParentIndex(e,r))}),t.push(this.ar.updateMetadata(e,s)),$.waitFor(t)}getFromCache(e,t){return this.ar.rr(e,t).next(s=>(this.ur.set(t,{size:s.size,readTime:s.document.readTime}),s.document))}getAllFromCache(e,t){return this.ar.sr(e,t).next(({documents:s,_r:i})=>(i.forEach((r,a)=>{this.ur.set(r,{size:a,readTime:s.get(r).readTime})}),s))}}function Dp(n){return rt(n,"remoteDocumentGlobal")}function bs(n){return rt(n,"remoteDocumentsV14")}function _r(n){const e=n.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function xp(n,e){const t=e.documentKey.path.toArray();return[n,qo(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function Np(n,e){const t=n.path.toArray(),s=e.path.toArray();let i=0;for(let r=0;r<t.length-2&&r<s.length-2;++r)if(i=ie(t[r],s[r]),i)return i;return i=ie(t.length,s.length),i||(i=ie(t[t.length-2],s[s.length-2]),i||ie(t[t.length-1],s[s.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eA{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tv{constructor(e,t,s,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=i}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(s=i,this.remoteDocumentCache.getEntry(e,t))).next(i=>(s!==null&&Mr(s.mutation,i,Ct.empty(),Ue.now()),i))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.getLocalViewOfDocuments(e,s,ce()).next(()=>s))}getLocalViewOfDocuments(e,t,s=ce()){const i=tn();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,s).next(r=>{let a=Rr();return r.forEach((o,l)=>{a=a.insert(o,l.overlayedDocument)}),a}))}getOverlayedDocuments(e,t){const s=tn();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,ce()))}populateOverlays(e,t,s){const i=[];return s.forEach(r=>{t.has(r)||i.push(r)}),this.documentOverlayCache.getOverlays(e,i).next(r=>{r.forEach((a,o)=>{t.set(a,o)})})}computeViews(e,t,s,i){let r=xt();const a=Or(),o=function(){return Or()}();return t.forEach((l,u)=>{const h=s.get(u.key);i.has(u.key)&&(h===void 0||h.mutation instanceof Rn)?r=r.insert(u.key,u):h!==void 0?(a.set(u.key,h.mutation.getFieldMask()),Mr(h.mutation,u,h.mutation.getFieldMask(),Ue.now())):a.set(u.key,Ct.empty())}),this.recalculateAndSaveOverlays(e,r).next(l=>(l.forEach((u,h)=>a.set(u,h)),t.forEach((u,h)=>{var p;return o.set(u,new eA(h,(p=a.get(u))!==null&&p!==void 0?p:null))}),o))}recalculateAndSaveOverlays(e,t){const s=Or();let i=new Ne((a,o)=>a-o),r=ce();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(a=>{for(const o of a)o.keys().forEach(l=>{const u=t.get(l);if(u===null)return;let h=s.get(l)||Ct.empty();h=o.applyToLocalView(u,h),s.set(l,h);const p=(i.get(o.batchId)||ce()).add(l);i=i.insert(o.batchId,p)})}).next(()=>{const a=[],o=i.getReverseIterator();for(;o.hasNext();){const l=o.getNext(),u=l.key,h=l.value,p=wy();h.forEach(m=>{if(!r.has(m)){const w=Ry(t.get(m),s.get(m));w!==null&&p.set(m,w),r=r.add(m)}}),a.push(this.documentOverlayCache.saveOverlays(e,u,p))}return $.waitFor(a)}).next(()=>s)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.recalculateAndSaveOverlays(e,s))}getDocumentsMatchingQuery(e,t,s,i){return function(a){return B.isDocumentKey(a.path)&&a.collectionGroup===null&&a.filters.length===0}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):my(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,i):this.getDocumentsMatchingCollectionQuery(e,t,s,i)}getNextDocuments(e,t,s,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,i).next(r=>{const a=i-r.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,i-r.size):$.resolve(tn());let o=-1,l=r;return a.next(u=>$.forEach(u,(h,p)=>(o<p.largestBatchId&&(o=p.largestBatchId),r.get(h)?$.resolve():this.remoteDocumentCache.getEntry(e,h).next(m=>{l=l.insert(h,m)}))).next(()=>this.populateOverlays(e,u,r)).next(()=>this.computeViews(e,l,u,ce())).next(h=>({batchId:o,changes:_y(h)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new B(t)).next(s=>{let i=Rr();return s.isFoundDocument()&&(i=i.insert(s.key,s)),i})}getDocumentsMatchingCollectionGroupQuery(e,t,s,i){const r=t.collectionGroup;let a=Rr();return this.indexManager.getCollectionParents(e,r).next(o=>$.forEach(o,l=>{const u=function(p,m){return new Hi(m,null,p.explicitOrderBy.slice(),p.filters.slice(),p.limit,p.limitType,p.startAt,p.endAt)}(t,l.child(r));return this.getDocumentsMatchingCollectionQuery(e,u,s,i).next(h=>{h.forEach((p,m)=>{a=a.insert(p,m)})})}).next(()=>a))}getDocumentsMatchingCollectionQuery(e,t,s,i){let r;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next(a=>(r=a,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,r,i))).next(a=>{r.forEach((l,u)=>{const h=u.getKey();a.get(h)===null&&(a=a.insert(h,We.newInvalidDocument(h)))});let o=Rr();return a.forEach((l,u)=>{const h=r.get(l);h!==void 0&&Mr(h.mutation,u,Ct.empty(),Ue.now()),Ia(t,u)&&(o=o.insert(l,u))}),o})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tA{constructor(e){this.serializer=e,this.cr=new Map,this.lr=new Map}getBundleMetadata(e,t){return $.resolve(this.cr.get(t))}saveBundleMetadata(e,t){return this.cr.set(t.id,function(i){return{id:i.id,version:i.version,createTime:At(i.createTime)}}(t)),$.resolve()}getNamedQuery(e,t){return $.resolve(this.lr.get(t))}saveNamedQuery(e,t){return this.lr.set(t.name,function(i){return{name:i.name,query:Ky(i.bundledQuery),readTime:At(i.readTime)}}(t)),$.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nA{constructor(){this.overlays=new Ne(B.comparator),this.hr=new Map}getOverlay(e,t){return $.resolve(this.overlays.get(t))}getOverlays(e,t){const s=tn();return $.forEach(t,i=>this.getOverlay(e,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(e,t,s){return s.forEach((i,r)=>{this.ht(e,t,r)}),$.resolve()}removeOverlaysForBatchId(e,t,s){const i=this.hr.get(s);return i!==void 0&&(i.forEach(r=>this.overlays=this.overlays.remove(r)),this.hr.delete(s)),$.resolve()}getOverlaysForCollection(e,t,s){const i=tn(),r=t.length+1,a=new B(t.child("")),o=this.overlays.getIteratorFrom(a);for(;o.hasNext();){const l=o.getNext().value,u=l.getKey();if(!t.isPrefixOf(u.path))break;u.path.length===r&&l.largestBatchId>s&&i.set(l.getKey(),l)}return $.resolve(i)}getOverlaysForCollectionGroup(e,t,s,i){let r=new Ne((u,h)=>u-h);const a=this.overlays.getIterator();for(;a.hasNext();){const u=a.getNext().value;if(u.getKey().getCollectionGroup()===t&&u.largestBatchId>s){let h=r.get(u.largestBatchId);h===null&&(h=tn(),r=r.insert(u.largestBatchId,h)),h.set(u.getKey(),u)}}const o=tn(),l=r.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((u,h)=>o.set(u,h)),!(o.size()>=i)););return $.resolve(o)}ht(e,t,s){const i=this.overlays.get(s.key);if(i!==null){const a=this.hr.get(i.largestBatchId).delete(s.key);this.hr.set(i.largestBatchId,a)}this.overlays=this.overlays.insert(s.key,new Ju(t,s));let r=this.hr.get(t);r===void 0&&(r=ce(),this.hr.set(t,r)),this.hr.set(t,r.add(s.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class td{constructor(){this.Pr=new ke(st.Ir),this.Tr=new ke(st.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(e,t){const s=new st(e,t);this.Pr=this.Pr.add(s),this.Tr=this.Tr.add(s)}dr(e,t){e.forEach(s=>this.addReference(s,t))}removeReference(e,t){this.Ar(new st(e,t))}Rr(e,t){e.forEach(s=>this.removeReference(s,t))}Vr(e){const t=new B(new Ee([])),s=new st(t,e),i=new st(t,e+1),r=[];return this.Tr.forEachInRange([s,i],a=>{this.Ar(a),r.push(a.key)}),r}mr(){this.Pr.forEach(e=>this.Ar(e))}Ar(e){this.Pr=this.Pr.delete(e),this.Tr=this.Tr.delete(e)}gr(e){const t=new B(new Ee([])),s=new st(t,e),i=new st(t,e+1);let r=ce();return this.Tr.forEachInRange([s,i],a=>{r=r.add(a.key)}),r}containsKey(e){const t=new st(e,0),s=this.Pr.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class st{constructor(e,t){this.key=e,this.pr=t}static Ir(e,t){return B.comparator(e.key,t.key)||ie(e.pr,t.pr)}static Er(e,t){return ie(e.pr,t.pr)||B.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sA{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.yr=1,this.wr=new ke(st.Ir)}checkEmpty(e){return $.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,i){const r=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const a=new Hu(r,t,s,i);this.mutationQueue.push(a);for(const o of i)this.wr=this.wr.add(new st(o.key,r)),this.indexManager.addToCollectionParentIndex(e,o.key.path.popLast());return $.resolve(a)}lookupMutationBatch(e,t){return $.resolve(this.Sr(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,i=this.br(s),r=i<0?0:i;return $.resolve(this.mutationQueue.length>r?this.mutationQueue[r]:null)}getHighestUnacknowledgedBatchId(){return $.resolve(this.mutationQueue.length===0?-1:this.yr-1)}getAllMutationBatches(e){return $.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new st(t,0),i=new st(t,Number.POSITIVE_INFINITY),r=[];return this.wr.forEachInRange([s,i],a=>{const o=this.Sr(a.pr);r.push(o)}),$.resolve(r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new ke(ie);return t.forEach(i=>{const r=new st(i,0),a=new st(i,Number.POSITIVE_INFINITY);this.wr.forEachInRange([r,a],o=>{s=s.add(o.pr)})}),$.resolve(this.Dr(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,i=s.length+1;let r=s;B.isDocumentKey(r)||(r=r.child(""));const a=new st(new B(r),0);let o=new ke(ie);return this.wr.forEachWhile(l=>{const u=l.key.path;return!!s.isPrefixOf(u)&&(u.length===i&&(o=o.add(l.pr)),!0)},a),$.resolve(this.Dr(o))}Dr(e){const t=[];return e.forEach(s=>{const i=this.Sr(s);i!==null&&t.push(i)}),t}removeMutationBatch(e,t){Z(this.Cr(t.batchId,"removed")===0),this.mutationQueue.shift();let s=this.wr;return $.forEach(t.mutations,i=>{const r=new st(i.key,t.batchId);return s=s.delete(r),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.wr=s})}Mn(e){}containsKey(e,t){const s=new st(t,0),i=this.wr.firstAfterOrEqual(s);return $.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,$.resolve()}Cr(e,t){return this.br(e)}br(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Sr(e){const t=this.br(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iA{constructor(e){this.vr=e,this.docs=function(){return new Ne(B.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,i=this.docs.get(s),r=i?i.size:0,a=this.vr(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:a}),this.size+=a-r,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return $.resolve(s?s.document.mutableCopy():We.newInvalidDocument(t))}getEntries(e,t){let s=xt();return t.forEach(i=>{const r=this.docs.get(i);s=s.insert(i,r?r.document.mutableCopy():We.newInvalidDocument(i))}),$.resolve(s)}getDocumentsMatchingQuery(e,t,s,i){let r=xt();const a=t.path,o=new B(a.child("")),l=this.docs.getIteratorFrom(o);for(;l.hasNext();){const{key:u,value:{document:h}}=l.getNext();if(!a.isPrefixOf(u.path))break;u.path.length>a.length+1||Bu(Kg(h),s)<=0||(i.has(h.key)||Ia(t,h))&&(r=r.insert(h.key,h.mutableCopy()))}return $.resolve(r)}getAllFromCollectionGroup(e,t,s,i){K()}Fr(e,t){return $.forEach(this.docs,s=>t(s))}newChangeBuffer(e){return new rA(this)}getSize(e){return $.resolve(this.size)}}class rA extends Zy{constructor(e){super(),this.ar=e}applyChanges(e){const t=[];return this.changes.forEach((s,i)=>{i.isValidDocument()?t.push(this.ar.addEntry(e,i)):this.ar.removeEntry(s)}),$.waitFor(t)}getFromCache(e,t){return this.ar.getEntry(e,t)}getAllFromCache(e,t){return this.ar.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aA{constructor(e){this.persistence=e,this.Mr=new fs(t=>Ls(t),_a),this.lastRemoteSnapshotVersion=ee.min(),this.highestTargetId=0,this.Or=0,this.Nr=new td,this.targetCount=0,this.Lr=qs.Nn()}forEachTarget(e,t){return this.Mr.forEach((s,i)=>t(i)),$.resolve()}getLastRemoteSnapshotVersion(e){return $.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return $.resolve(this.Or)}allocateTargetId(e){return this.highestTargetId=this.Lr.next(),$.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.Or&&(this.Or=t),$.resolve()}qn(e){this.Mr.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Lr=new qs(t),this.highestTargetId=t),e.sequenceNumber>this.Or&&(this.Or=e.sequenceNumber)}addTargetData(e,t){return this.qn(t),this.targetCount+=1,$.resolve()}updateTargetData(e,t){return this.qn(t),$.resolve()}removeTargetData(e,t){return this.Mr.delete(t.target),this.Nr.Vr(t.targetId),this.targetCount-=1,$.resolve()}removeTargets(e,t,s){let i=0;const r=[];return this.Mr.forEach((a,o)=>{o.sequenceNumber<=t&&s.get(o.targetId)===null&&(this.Mr.delete(a),r.push(this.removeMatchingKeysForTargetId(e,o.targetId)),i++)}),$.waitFor(r).next(()=>i)}getTargetCount(e){return $.resolve(this.targetCount)}getTargetData(e,t){const s=this.Mr.get(t)||null;return $.resolve(s)}addMatchingKeys(e,t,s){return this.Nr.dr(t,s),$.resolve()}removeMatchingKeys(e,t,s){this.Nr.Rr(t,s);const i=this.persistence.referenceDelegate,r=[];return i&&t.forEach(a=>{r.push(i.markPotentiallyOrphaned(e,a))}),$.waitFor(r)}removeMatchingKeysForTargetId(e,t){return this.Nr.Vr(t),$.resolve()}getMatchingKeysForTargetId(e,t){const s=this.Nr.gr(t);return $.resolve(s)}containsKey(e,t){return $.resolve(this.Nr.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nv{constructor(e,t){this.Br={},this.overlays={},this.kr=new Pt(0),this.qr=!1,this.qr=!0,this.referenceDelegate=e(this),this.Qr=new aA(this),this.indexManager=new W0,this.remoteDocumentCache=function(i){return new iA(i)}(s=>this.referenceDelegate.Kr(s)),this.serializer=new zy(t),this.$r=new tA(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new nA,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this.Br[e.toKey()];return s||(s=new sA(t,this.referenceDelegate),this.Br[e.toKey()]=s),s}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(e,t,s){V("MemoryPersistence","Starting transaction:",e);const i=new oA(this.kr.next());return this.referenceDelegate.Ur(),s(i).next(r=>this.referenceDelegate.Wr(i).next(()=>r)).toPromise().then(r=>(i.raiseOnCommittedEvent(),r))}Gr(e,t){return $.or(Object.values(this.Br).map(s=>()=>s.containsKey(e,t)))}}class oA extends Qg{constructor(e){super(),this.currentSequenceNumber=e}}class Ec{constructor(e){this.persistence=e,this.zr=new td,this.jr=null}static Hr(e){return new Ec(e)}get Jr(){if(this.jr)return this.jr;throw K()}addReference(e,t,s){return this.zr.addReference(s,t),this.Jr.delete(s.toString()),$.resolve()}removeReference(e,t,s){return this.zr.removeReference(s,t),this.Jr.add(s.toString()),$.resolve()}markPotentiallyOrphaned(e,t){return this.Jr.add(t.toString()),$.resolve()}removeTarget(e,t){this.zr.Vr(t.targetId).forEach(i=>this.Jr.add(i.toString()));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next(i=>{i.forEach(r=>this.Jr.add(r.toString()))}).next(()=>s.removeTargetData(e,t))}Ur(){this.jr=new Set}Wr(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return $.forEach(this.Jr,s=>{const i=B.fromPath(s);return this.Yr(e,i).next(r=>{r||t.removeEntry(i,ee.min())})}).next(()=>(this.jr=null,t.apply(e)))}updateLimboDocument(e,t){return this.Yr(e,t).next(s=>{s?this.Jr.delete(t.toString()):this.Jr.add(t.toString())})}Kr(e){return 0}Yr(e,t){return $.or([()=>$.resolve(this.zr.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gr(e,t)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cA{constructor(e){this.serializer=e}O(e,t,s,i){const r=new mc("createOrUpgrade",t);s<1&&i>=1&&(function(l){l.createObjectStore("owner")}(e),function(l){l.createObjectStore("mutationQueues",{keyPath:"userId"}),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",Qf,{unique:!0}),l.createObjectStore("documentMutations")}(e),Vp(e),function(l){l.createObjectStore("remoteDocuments")}(e));let a=$.resolve();return s<3&&i>=3&&(s!==0&&(function(l){l.deleteObjectStore("targetDocuments"),l.deleteObjectStore("targets"),l.deleteObjectStore("targetGlobal")}(e),Vp(e)),a=a.next(()=>function(l){const u=l.store("targetGlobal"),h={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:ee.min().toTimestamp(),targetCount:0};return u.put("targetGlobalKey",h)}(r))),s<4&&i>=4&&(s!==0&&(a=a.next(()=>function(l,u){return u.store("mutations").U().next(h=>{l.deleteObjectStore("mutations"),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",Qf,{unique:!0});const p=u.store("mutations"),m=h.map(w=>p.put(w));return $.waitFor(m)})}(e,r))),a=a.next(()=>{(function(l){l.createObjectStore("clientMetadata",{keyPath:"clientId"})})(e)})),s<5&&i>=5&&(a=a.next(()=>this.Xr(r))),s<6&&i>=6&&(a=a.next(()=>(function(l){l.createObjectStore("remoteDocumentGlobal")}(e),this.ei(r)))),s<7&&i>=7&&(a=a.next(()=>this.ti(r))),s<8&&i>=8&&(a=a.next(()=>this.ni(e,r))),s<9&&i>=9&&(a=a.next(()=>{(function(l){l.objectStoreNames.contains("remoteDocumentChanges")&&l.deleteObjectStore("remoteDocumentChanges")})(e)})),s<10&&i>=10&&(a=a.next(()=>this.ri(r))),s<11&&i>=11&&(a=a.next(()=>{(function(l){l.createObjectStore("bundles",{keyPath:"bundleId"})})(e),function(l){l.createObjectStore("namedQueries",{keyPath:"name"})}(e)})),s<12&&i>=12&&(a=a.next(()=>{(function(l){const u=l.createObjectStore("documentOverlays",{keyPath:BT});u.createIndex("collectionPathOverlayIndex",jT,{unique:!1}),u.createIndex("collectionGroupOverlayIndex",WT,{unique:!1})})(e)})),s<13&&i>=13&&(a=a.next(()=>function(l){const u=l.createObjectStore("remoteDocumentsV14",{keyPath:$T});u.createIndex("documentKeyIndex",DT),u.createIndex("collectionGroupIndex",xT)}(e)).next(()=>this.ii(e,r)).next(()=>e.deleteObjectStore("remoteDocuments"))),s<14&&i>=14&&(a=a.next(()=>this.si(e,r))),s<15&&i>=15&&(a=a.next(()=>function(l){l.createObjectStore("indexConfiguration",{keyPath:"indexId",autoIncrement:!0}).createIndex("collectionGroupIndex","collectionGroup",{unique:!1}),l.createObjectStore("indexState",{keyPath:LT}).createIndex("sequenceNumberIndex",FT,{unique:!1}),l.createObjectStore("indexEntries",{keyPath:UT}).createIndex("documentKeyIndex",qT,{unique:!1})}(e))),s<16&&i>=16&&(a=a.next(()=>{t.objectStore("indexState").clear()}).next(()=>{t.objectStore("indexEntries").clear()})),a}ei(e){let t=0;return e.store("remoteDocuments").J((s,i)=>{t+=jo(i)}).next(()=>{const s={byteSize:t};return e.store("remoteDocumentGlobal").put("remoteDocumentGlobalKey",s)})}Xr(e){const t=e.store("mutationQueues"),s=e.store("mutations");return t.U().next(i=>$.forEach(i,r=>{const a=IDBKeyRange.bound([r.userId,-1],[r.userId,r.lastAcknowledgedBatchId]);return s.U("userMutationsIndex",a).next(o=>$.forEach(o,l=>{Z(l.userId===r.userId);const u=Es(this.serializer,l);return Jy(e,r.userId,u).next(()=>{})}))}))}ti(e){const t=e.store("targetDocuments"),s=e.store("remoteDocuments");return e.store("targetGlobal").get("targetGlobalKey").next(i=>{const r=[];return s.J((a,o)=>{const l=new Ee(a),u=function(p){return[0,Tt(p)]}(l);r.push(t.get(u).next(h=>h?$.resolve():(p=>t.put({targetId:0,path:Tt(p),sequenceNumber:i.highestListenSequenceNumber}))(l)))}).next(()=>$.waitFor(r))})}ni(e,t){e.createObjectStore("collectionParents",{keyPath:MT});const s=t.store("collectionParents"),i=new ed,r=a=>{if(i.add(a)){const o=a.lastSegment(),l=a.popLast();return s.put({collectionId:o,parent:Tt(l)})}};return t.store("remoteDocuments").J({H:!0},(a,o)=>{const l=new Ee(a);return r(l.popLast())}).next(()=>t.store("documentMutations").J({H:!0},([a,o,l],u)=>{const h=en(o);return r(h.popLast())}))}ri(e){const t=e.store("targets");return t.J((s,i)=>{const r=Cr(i),a=Gy(this.serializer,r);return t.put(a)})}ii(e,t){const s=t.store("remoteDocuments"),i=[];return s.J((r,a)=>{const o=t.store("remoteDocumentsV14"),l=function(p){return p.document?new B(Ee.fromString(p.document.name).popFirst(5)):p.noDocument?B.fromSegments(p.noDocument.path):p.unknownDocument?B.fromSegments(p.unknownDocument.path):K()}(a).path.toArray(),u={prefixPath:l.slice(0,l.length-2),collectionGroup:l[l.length-2],documentId:l[l.length-1],readTime:a.readTime||[0,0],unknownDocument:a.unknownDocument,noDocument:a.noDocument,document:a.document,hasCommittedMutations:!!a.hasCommittedMutations};i.push(o.put(u))}).next(()=>$.waitFor(i))}si(e,t){const s=t.store("mutations"),i=ev(this.serializer),r=new nv(Ec.Hr,this.serializer.ct);return s.U().next(a=>{const o=new Map;return a.forEach(l=>{var u;let h=(u=o.get(l.userId))!==null&&u!==void 0?u:ce();Es(this.serializer,l).keys().forEach(p=>h=h.add(p)),o.set(l.userId,h)}),$.forEach(o,(l,u)=>{const h=new yt(u),p=wc.lt(this.serializer,h),m=r.getIndexManager(h),w=Ic.lt(h,this.serializer,m,r.referenceDelegate);return new tv(i,w,p,m).recalculateAndSaveOverlaysForDocumentKeys(new Hl(t,Pt.oe),l).next()})})}}function Vp(n){n.createObjectStore("targetDocuments",{keyPath:VT}).createIndex("documentTargetsIndex",OT,{unique:!0}),n.createObjectStore("targets",{keyPath:"targetId"}).createIndex("queryTargetsIndex",NT,{unique:!0}),n.createObjectStore("targetGlobal")}const bl="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class nd{constructor(e,t,s,i,r,a,o,l,u,h,p=16){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=s,this.oi=r,this.window=a,this.document=o,this._i=u,this.ai=h,this.ui=p,this.kr=null,this.qr=!1,this.isPrimary=!1,this.networkEnabled=!0,this.ci=null,this.inForeground=!1,this.li=null,this.hi=null,this.Pi=Number.NEGATIVE_INFINITY,this.Ii=m=>Promise.resolve(),!nd.D())throw new F(N.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new Y0(this,i),this.Ti=t+"main",this.serializer=new zy(l),this.Ei=new Zn(this.Ti,this.ui,new cA(this.serializer)),this.Qr=new G0(this.referenceDelegate,this.serializer),this.remoteDocumentCache=ev(this.serializer),this.$r=new L0,this.window&&this.window.localStorage?this.di=this.window.localStorage:(this.di=null,h===!1&&He("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ai().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new F(N.FAILED_PRECONDITION,bl);return this.Ri(),this.Vi(),this.mi(),this.runTransaction("getHighestListenSequenceNumber","readonly",e=>this.Qr.getHighestSequenceNumber(e))}).then(e=>{this.kr=new Pt(e,this._i)}).then(()=>{this.qr=!0}).catch(e=>(this.Ei&&this.Ei.close(),Promise.reject(e)))}fi(e){return this.Ii=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.Ei.L(async t=>{t.newVersion===null&&await e()})}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.oi.enqueueAndForget(async()=>{this.started&&await this.Ai()}))}Ai(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",e=>eo(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.gi(e).next(t=>{t||(this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)))})}).next(()=>this.pi(e)).next(t=>this.isPrimary&&!t?this.yi(e).next(()=>!1):!!t&&this.wi(e).next(()=>!0))).catch(e=>{if(hs(e))return V("IndexedDbPersistence","Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return V("IndexedDbPersistence","Releasing owner lease after error during lease refresh",e),!1}).then(e=>{this.isPrimary!==e&&this.oi.enqueueRetryable(()=>this.Ii(e)),this.isPrimary=e})}gi(e){return wr(e).get("owner").next(t=>$.resolve(this.Si(t)))}bi(e){return eo(e).delete(this.clientId)}async Di(){if(this.isPrimary&&!this.Ci(this.Pi,18e5)){this.Pi=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const s=rt(t,"clientMetadata");return s.U().next(i=>{const r=this.vi(i,18e5),a=i.filter(o=>r.indexOf(o)===-1);return $.forEach(a,o=>s.delete(o.clientId)).next(()=>a)})}).catch(()=>[]);if(this.di)for(const t of e)this.di.removeItem(this.Fi(t.clientId))}}mi(){this.hi=this.oi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Ai().then(()=>this.Di()).then(()=>this.mi()))}Si(e){return!!e&&e.ownerId===this.clientId}pi(e){return this.ai?$.resolve(!0):wr(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)){if(this.Si(t)&&this.networkEnabled)return!0;if(!this.Si(t)){if(!t.allowTabSynchronization)throw new F(N.FAILED_PRECONDITION,bl);return!1}}return!(!this.networkEnabled||!this.inForeground)||eo(e).U().next(s=>this.vi(s,5e3).find(i=>{if(this.clientId!==i.clientId){const r=!this.networkEnabled&&i.networkEnabled,a=!this.inForeground&&i.inForeground,o=this.networkEnabled===i.networkEnabled;if(r||a&&o)return!0}return!1})===void 0)}).next(t=>(this.isPrimary!==t&&V("IndexedDbPersistence",`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.qr=!1,this.xi(),this.hi&&(this.hi.cancel(),this.hi=null),this.Oi(),this.Ni(),await this.Ei.runTransaction("shutdown","readwrite",["owner","clientMetadata"],e=>{const t=new Hl(e,Pt.oe);return this.yi(t).next(()=>this.bi(t))}),this.Ei.close(),this.Li()}vi(e,t){return e.filter(s=>this.Ci(s.updateTimeMs,t)&&!this.Mi(s.clientId))}Bi(){return this.runTransaction("getActiveClients","readonly",e=>eo(e).U().next(t=>this.vi(t,18e5).map(s=>s.clientId)))}get started(){return this.qr}getMutationQueue(e,t){return Ic.lt(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new z0(e,this.serializer.ct.databaseId)}getDocumentOverlayCache(e){return wc.lt(this.serializer,e)}getBundleCache(){return this.$r}runTransaction(e,t,s){V("IndexedDbPersistence","Starting transaction:",e);const i=t==="readonly"?"readonly":"readwrite",r=function(l){return l===16?GT:l===15?ny:l===14?ty:l===13?ey:l===12?zT:l===11?Zg:void K()}(this.ui);let a;return this.Ei.runTransaction(e,i,r,o=>(a=new Hl(o,this.kr?this.kr.next():Pt.oe),t==="readwrite-primary"?this.gi(a).next(l=>!!l||this.pi(a)).next(l=>{if(!l)throw He(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)),new F(N.FAILED_PRECONDITION,Hg);return s(a)}).next(l=>this.wi(a).next(()=>l)):this.ki(a).next(()=>s(a)))).then(o=>(a.raiseOnCommittedEvent(),o))}ki(e){return wr(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)&&!this.Si(t)&&!(this.ai||this.allowTabSynchronization&&t.allowTabSynchronization))throw new F(N.FAILED_PRECONDITION,bl)})}wi(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return wr(e).put("owner",t)}static D(){return Zn.D()}yi(e){const t=wr(e);return t.get("owner").next(s=>this.Si(s)?(V("IndexedDbPersistence","Releasing primary lease."),t.delete("owner")):$.resolve())}Ci(e,t){const s=Date.now();return!(e<s-t)&&(!(e>s)||(He(`Detected an update time that is in the future: ${e} > ${s}`),!1))}Ri(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.li=()=>{this.oi.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.Ai()))},this.document.addEventListener("visibilitychange",this.li),this.inForeground=this.document.visibilityState==="visible")}Oi(){this.li&&(this.document.removeEventListener("visibilitychange",this.li),this.li=null)}Vi(){var e;typeof((e=this.window)===null||e===void 0?void 0:e.addEventListener)=="function"&&(this.ci=()=>{this.xi();const t=/(?:Version|Mobile)\/1[456]/;Xm()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.oi.enterRestrictedMode(!0),this.oi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.ci))}Ni(){this.ci&&(this.window.removeEventListener("pagehide",this.ci),this.ci=null)}Mi(e){var t;try{const s=((t=this.di)===null||t===void 0?void 0:t.getItem(this.Fi(e)))!==null;return V("IndexedDbPersistence",`Client '${e}' ${s?"is":"is not"} zombied in LocalStorage`),s}catch(s){return He("IndexedDbPersistence","Failed to get zombied client id.",s),!1}}xi(){if(this.di)try{this.di.setItem(this.Fi(this.clientId),String(Date.now()))}catch(e){He("Failed to set zombie client id.",e)}}Li(){if(this.di)try{this.di.removeItem(this.Fi(this.clientId))}catch{}}Fi(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function wr(n){return rt(n,"owner")}function eo(n){return rt(n,"clientMetadata")}function sv(n,e){let t=n.projectId;return n.isDefaultDatabase||(t+="."+n.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sd{constructor(e,t,s,i){this.targetId=e,this.fromCache=t,this.qi=s,this.Qi=i}static Ki(e,t){let s=ce(),i=ce();for(const r of t.docChanges)switch(r.type){case 0:s=s.add(r.doc.key);break;case 1:i=i.add(r.doc.key)}return new sd(e,t.fromCache,s,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lA{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iv{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=function(){return Xm()?8:Jg(Je())>0?6:4}()}initialize(e,t){this.zi=e,this.indexManager=t,this.$i=!0}getDocumentsMatchingQuery(e,t,s,i){const r={result:null};return this.ji(e,t).next(a=>{r.result=a}).next(()=>{if(!r.result)return this.Hi(e,t,i,s).next(a=>{r.result=a})}).next(()=>{if(r.result)return;const a=new lA;return this.Ji(e,t,a).next(o=>{if(r.result=o,this.Ui)return this.Yi(e,t,a,o.size)})}).next(()=>r.result)}Yi(e,t,s,i){return s.documentReadCount<this.Wi?(li()<=de.DEBUG&&V("QueryEngine","SDK will not create cache indexes for query:",ui(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),$.resolve()):(li()<=de.DEBUG&&V("QueryEngine","Query:",ui(t),"scans",s.documentReadCount,"local documents and returns",i,"documents as results."),s.documentReadCount>this.Gi*i?(li()<=de.DEBUG&&V("QueryEngine","The SDK decides to create cache indexes for query:",ui(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,Nt(t))):$.resolve())}ji(e,t){if(op(t))return $.resolve(null);let s=Nt(t);return this.indexManager.getIndexType(e,s).next(i=>i===0?null:(t.limit!==null&&i===1&&(t=Lo(t,null,"F"),s=Nt(t)),this.indexManager.getDocumentsMatchingTarget(e,s).next(r=>{const a=ce(...r);return this.zi.getDocuments(e,a).next(o=>this.indexManager.getMinOffset(e,s).next(l=>{const u=this.Zi(t,o);return this.Xi(t,u,a,l.readTime)?this.ji(e,Lo(t,null,"F")):this.es(e,u,t,l)}))})))}Hi(e,t,s,i){return op(t)||i.isEqual(ee.min())?$.resolve(null):this.zi.getDocuments(e,s).next(r=>{const a=this.Zi(t,r);return this.Xi(t,a,s,i)?$.resolve(null):(li()<=de.DEBUG&&V("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),ui(t)),this.es(e,a,t,Gg(i,-1)).next(o=>o))})}Zi(e,t){let s=new ke(vy(e));return t.forEach((i,r)=>{Ia(e,r)&&(s=s.add(r))}),s}Xi(e,t,s,i){if(e.limit===null)return!1;if(s.size!==t.size)return!0;const r=e.limitType==="F"?t.last():t.first();return!!r&&(r.hasPendingWrites||r.version.compareTo(i)>0)}Ji(e,t,s){return li()<=de.DEBUG&&V("QueryEngine","Using full collection scan to execute query:",ui(t)),this.zi.getDocumentsMatchingQuery(e,t,Ot.min(),s)}es(e,t,s,i){return this.zi.getDocumentsMatchingQuery(e,s,i).next(r=>(t.forEach(a=>{r=r.insert(a.key,a)}),r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uA{constructor(e,t,s,i){this.persistence=e,this.ts=t,this.serializer=i,this.ns=new Ne(ie),this.rs=new fs(r=>Ls(r),_a),this.ss=new Map,this.os=e.getRemoteDocumentCache(),this.Qr=e.getTargetCache(),this.$r=e.getBundleCache(),this._s(s)}_s(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new tv(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.ns))}}function rv(n,e,t,s){return new uA(n,e,t,s)}async function av(n,e){const t=Q(n);return await t.persistence.runTransaction("Handle user change","readonly",s=>{let i;return t.mutationQueue.getAllMutationBatches(s).next(r=>(i=r,t._s(e),t.mutationQueue.getAllMutationBatches(s))).next(r=>{const a=[],o=[];let l=ce();for(const u of i){a.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}for(const u of r){o.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}return t.localDocuments.getDocuments(s,l).next(u=>({us:u,removedBatchIds:a,addedBatchIds:o}))})})}function dA(n,e){const t=Q(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",s=>{const i=e.batch.keys(),r=t.os.newChangeBuffer({trackRemovals:!0});return function(o,l,u,h){const p=u.batch,m=p.keys();let w=$.resolve();return m.forEach(E=>{w=w.next(()=>h.getEntry(l,E)).next(x=>{const C=u.docVersions.get(E);Z(C!==null),x.version.compareTo(C)<0&&(p.applyToRemoteDocument(x,u),x.isValidDocument()&&(x.setReadTime(u.commitVersion),h.addEntry(x)))})}),w.next(()=>o.mutationQueue.removeMutationBatch(l,p))}(t,s,e,r).next(()=>r.apply(s)).next(()=>t.mutationQueue.performConsistencyCheck(s)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(s,i,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,function(o){let l=ce();for(let u=0;u<o.mutationResults.length;++u)o.mutationResults[u].transformResults.length>0&&(l=l.add(o.batch.mutations[u].key));return l}(e))).next(()=>t.localDocuments.getDocuments(s,i))})}function ov(n){const e=Q(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Qr.getLastRemoteSnapshotVersion(t))}function hA(n,e){const t=Q(n),s=e.snapshotVersion;let i=t.ns;return t.persistence.runTransaction("Apply remote event","readwrite-primary",r=>{const a=t.os.newChangeBuffer({trackRemovals:!0});i=t.ns;const o=[];e.targetChanges.forEach((h,p)=>{const m=i.get(p);if(!m)return;o.push(t.Qr.removeMatchingKeys(r,h.removedDocuments,p).next(()=>t.Qr.addMatchingKeys(r,h.addedDocuments,p)));let w=m.withSequenceNumber(r.currentSequenceNumber);e.targetMismatches.get(p)!==null?w=w.withResumeToken(it.EMPTY_BYTE_STRING,ee.min()).withLastLimboFreeSnapshotVersion(ee.min()):h.resumeToken.approximateByteSize()>0&&(w=w.withResumeToken(h.resumeToken,s)),i=i.insert(p,w),function(x,C,j){return x.resumeToken.approximateByteSize()===0||C.snapshotVersion.toMicroseconds()-x.snapshotVersion.toMicroseconds()>=3e8?!0:j.addedDocuments.size+j.modifiedDocuments.size+j.removedDocuments.size>0}(m,w,h)&&o.push(t.Qr.updateTargetData(r,w))});let l=xt(),u=ce();if(e.documentUpdates.forEach(h=>{e.resolvedLimboDocuments.has(h)&&o.push(t.persistence.referenceDelegate.updateLimboDocument(r,h))}),o.push(fA(r,a,e.documentUpdates).next(h=>{l=h.cs,u=h.ls})),!s.isEqual(ee.min())){const h=t.Qr.getLastRemoteSnapshotVersion(r).next(p=>t.Qr.setTargetsMetadata(r,r.currentSequenceNumber,s));o.push(h)}return $.waitFor(o).next(()=>a.apply(r)).next(()=>t.localDocuments.getLocalViewOfDocuments(r,l,u)).next(()=>l)}).then(r=>(t.ns=i,r))}function fA(n,e,t){let s=ce(),i=ce();return t.forEach(r=>s=s.add(r)),e.getEntries(n,s).next(r=>{let a=xt();return t.forEach((o,l)=>{const u=r.get(o);l.isFoundDocument()!==u.isFoundDocument()&&(i=i.add(o)),l.isNoDocument()&&l.version.isEqual(ee.min())?(e.removeEntry(o,l.readTime),a=a.insert(o,l)):!u.isValidDocument()||l.version.compareTo(u.version)>0||l.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(l),a=a.insert(o,l)):V("LocalStore","Ignoring outdated watch update for ",o,". Current version:",u.version," Watch version:",l.version)}),{cs:a,ls:i}})}function pA(n,e){const t=Q(n);return t.persistence.runTransaction("Get next mutation batch","readonly",s=>(e===void 0&&(e=-1),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e)))}function Wo(n,e){const t=Q(n);return t.persistence.runTransaction("Allocate target","readwrite",s=>{let i;return t.Qr.getTargetData(s,e).next(r=>r?(i=r,$.resolve(i)):t.Qr.allocateTargetId(s).next(a=>(i=new In(e,a,"TargetPurposeListen",s.currentSequenceNumber),t.Qr.addTargetData(s,i).next(()=>i))))}).then(s=>{const i=t.ns.get(s.targetId);return(i===null||s.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(t.ns=t.ns.insert(s.targetId,s),t.rs.set(e,s.targetId)),s})}async function Di(n,e,t){const s=Q(n),i=s.ns.get(e),r=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",r,a=>s.persistence.referenceDelegate.removeTarget(a,i))}catch(a){if(!hs(a))throw a;V("LocalStore",`Failed to update sequence numbers for target ${e}: ${a}`)}s.ns=s.ns.remove(e),s.rs.delete(i.target)}function cu(n,e,t){const s=Q(n);let i=ee.min(),r=ce();return s.persistence.runTransaction("Execute query","readwrite",a=>function(l,u,h){const p=Q(l),m=p.rs.get(h);return m!==void 0?$.resolve(p.ns.get(m)):p.Qr.getTargetData(u,h)}(s,a,Nt(e)).next(o=>{if(o)return i=o.lastLimboFreeSnapshotVersion,s.Qr.getMatchingKeysForTargetId(a,o.targetId).next(l=>{r=l})}).next(()=>s.ts.getDocumentsMatchingQuery(a,e,t?i:ee.min(),t?r:ce())).next(o=>(uv(s,yy(e),o),{documents:o,hs:r})))}function cv(n,e){const t=Q(n),s=Q(t.Qr),i=t.ns.get(e);return i?Promise.resolve(i.target):t.persistence.runTransaction("Get target data","readonly",r=>s.ot(r,e).next(a=>a?a.target:null))}function lv(n,e){const t=Q(n),s=t.ss.get(e)||ee.min();return t.persistence.runTransaction("Get new document changes","readonly",i=>t.os.getAllFromCollectionGroup(i,e,Gg(s,-1),Number.MAX_SAFE_INTEGER)).then(i=>(uv(t,e,i),i))}function uv(n,e,t){let s=n.ss.get(e)||ee.min();t.forEach((i,r)=>{r.readTime.compareTo(s)>0&&(s=r.readTime)}),n.ss.set(e,s)}function Op(n,e){return`firestore_clients_${n}_${e}`}function Mp(n,e,t){let s=`firestore_mutations_${n}_${t}`;return e.isAuthenticated()&&(s+=`_${e.uid}`),s}function _l(n,e){return`firestore_targets_${n}_${e}`}class zo{constructor(e,t,s,i){this.user=e,this.batchId=t,this.state=s,this.error=i}static Es(e,t,s){const i=JSON.parse(s);let r,a=typeof i=="object"&&["pending","acknowledged","rejected"].indexOf(i.state)!==-1&&(i.error===void 0||typeof i.error=="object");return a&&i.error&&(a=typeof i.error.message=="string"&&typeof i.error.code=="string",a&&(r=new F(i.error.code,i.error.message))),a?new zo(e,t,i.state,r):(He("SharedClientState",`Failed to parse mutation state for ID '${t}': ${s}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Lr{constructor(e,t,s){this.targetId=e,this.state=t,this.error=s}static Es(e,t){const s=JSON.parse(t);let i,r=typeof s=="object"&&["not-current","current","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return r&&s.error&&(r=typeof s.error.message=="string"&&typeof s.error.code=="string",r&&(i=new F(s.error.code,s.error.message))),r?new Lr(e,s.state,i):(He("SharedClientState",`Failed to parse target state for ID '${e}': ${t}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Go{constructor(e,t){this.clientId=e,this.activeTargetIds=t}static Es(e,t){const s=JSON.parse(t);let i=typeof s=="object"&&s.activeTargetIds instanceof Array,r=Ku();for(let a=0;i&&a<s.activeTargetIds.length;++a)i=Yg(s.activeTargetIds[a]),r=r.add(s.activeTargetIds[a]);return i?new Go(e,r):(He("SharedClientState",`Failed to parse client data for instance '${e}': ${t}`),null)}}class id{constructor(e,t){this.clientId=e,this.onlineState=t}static Es(e){const t=JSON.parse(e);return typeof t=="object"&&["Unknown","Online","Offline"].indexOf(t.onlineState)!==-1&&typeof t.clientId=="string"?new id(t.clientId,t.onlineState):(He("SharedClientState",`Failed to parse online state: ${e}`),null)}}class lu{constructor(){this.activeTargetIds=Ku()}As(e){this.activeTargetIds=this.activeTargetIds.add(e)}Rs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ds(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class wl{constructor(e,t,s,i,r){this.window=e,this.oi=t,this.persistenceKey=s,this.Vs=i,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.fs=this.gs.bind(this),this.ps=new Ne(ie),this.started=!1,this.ys=[];const a=s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=r,this.ws=Op(this.persistenceKey,this.Vs),this.Ss=function(l){return`firestore_sequence_number_${l}`}(this.persistenceKey),this.ps=this.ps.insert(this.Vs,new lu),this.bs=new RegExp(`^firestore_clients_${a}_([^_]*)$`),this.Ds=new RegExp(`^firestore_mutations_${a}_(\\d+)(?:_(.*))?$`),this.Cs=new RegExp(`^firestore_targets_${a}_(\\d+)$`),this.vs=function(l){return`firestore_online_state_${l}`}(this.persistenceKey),this.Fs=function(l){return`firestore_bundle_loaded_v2_${l}`}(this.persistenceKey),this.window.addEventListener("storage",this.fs)}static D(e){return!(!e||!e.localStorage)}async start(){const e=await this.syncEngine.Bi();for(const s of e){if(s===this.Vs)continue;const i=this.getItem(Op(this.persistenceKey,s));if(i){const r=Go.Es(s,i);r&&(this.ps=this.ps.insert(r.clientId,r))}}this.Ms();const t=this.storage.getItem(this.vs);if(t){const s=this.xs(t);s&&this.Os(s)}for(const s of this.ys)this.gs(s);this.ys=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(e){this.setItem(this.Ss,JSON.stringify(e))}getAllActiveQueryTargets(){return this.Ns(this.ps)}isActiveQueryTarget(e){let t=!1;return this.ps.forEach((s,i)=>{i.activeTargetIds.has(e)&&(t=!0)}),t}addPendingMutation(e){this.Ls(e,"pending")}updateMutationState(e,t,s){this.Ls(e,t,s),this.Bs(e)}addLocalQueryTarget(e){let t="not-current";if(this.isActiveQueryTarget(e)){const s=this.storage.getItem(_l(this.persistenceKey,e));if(s){const i=Lr.Es(e,s);i&&(t=i.state)}}return this.ks.As(e),this.Ms(),t}removeLocalQueryTarget(e){this.ks.Rs(e),this.Ms()}isLocalQueryTarget(e){return this.ks.activeTargetIds.has(e)}clearQueryState(e){this.removeItem(_l(this.persistenceKey,e))}updateQueryState(e,t,s){this.qs(e,t,s)}handleUserChange(e,t,s){t.forEach(i=>{this.Bs(i)}),this.currentUser=e,s.forEach(i=>{this.addPendingMutation(i)})}setOnlineState(e){this.Qs(e)}notifyBundleLoaded(e){this.Ks(e)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.fs),this.removeItem(this.ws),this.started=!1)}getItem(e){const t=this.storage.getItem(e);return V("SharedClientState","READ",e,t),t}setItem(e,t){V("SharedClientState","SET",e,t),this.storage.setItem(e,t)}removeItem(e){V("SharedClientState","REMOVE",e),this.storage.removeItem(e)}gs(e){const t=e;if(t.storageArea===this.storage){if(V("SharedClientState","EVENT",t.key,t.newValue),t.key===this.ws)return void He("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.oi.enqueueRetryable(async()=>{if(this.started){if(t.key!==null){if(this.bs.test(t.key)){if(t.newValue==null){const s=this.$s(t.key);return this.Us(s,null)}{const s=this.Ws(t.key,t.newValue);if(s)return this.Us(s.clientId,s)}}else if(this.Ds.test(t.key)){if(t.newValue!==null){const s=this.Gs(t.key,t.newValue);if(s)return this.zs(s)}}else if(this.Cs.test(t.key)){if(t.newValue!==null){const s=this.js(t.key,t.newValue);if(s)return this.Hs(s)}}else if(t.key===this.vs){if(t.newValue!==null){const s=this.xs(t.newValue);if(s)return this.Os(s)}}else if(t.key===this.Ss){const s=function(r){let a=Pt.oe;if(r!=null)try{const o=JSON.parse(r);Z(typeof o=="number"),a=o}catch(o){He("SharedClientState","Failed to read sequence number from WebStorage",o)}return a}(t.newValue);s!==Pt.oe&&this.sequenceNumberHandler(s)}else if(t.key===this.Fs){const s=this.Js(t.newValue);await Promise.all(s.map(i=>this.syncEngine.Ys(i)))}}}else this.ys.push(t)})}}get ks(){return this.ps.get(this.Vs)}Ms(){this.setItem(this.ws,this.ks.ds())}Ls(e,t,s){const i=new zo(this.currentUser,e,t,s),r=Mp(this.persistenceKey,this.currentUser,e);this.setItem(r,i.ds())}Bs(e){const t=Mp(this.persistenceKey,this.currentUser,e);this.removeItem(t)}Qs(e){const t={clientId:this.Vs,onlineState:e};this.storage.setItem(this.vs,JSON.stringify(t))}qs(e,t,s){const i=_l(this.persistenceKey,e),r=new Lr(e,t,s);this.setItem(i,r.ds())}Ks(e){const t=JSON.stringify(Array.from(e));this.setItem(this.Fs,t)}$s(e){const t=this.bs.exec(e);return t?t[1]:null}Ws(e,t){const s=this.$s(e);return Go.Es(s,t)}Gs(e,t){const s=this.Ds.exec(e),i=Number(s[1]),r=s[2]!==void 0?s[2]:null;return zo.Es(new yt(r),i,t)}js(e,t){const s=this.Cs.exec(e),i=Number(s[1]);return Lr.Es(i,t)}xs(e){return id.Es(e)}Js(e){return JSON.parse(e)}async zs(e){if(e.user.uid===this.currentUser.uid)return this.syncEngine.Zs(e.batchId,e.state,e.error);V("SharedClientState",`Ignoring mutation for non-active user ${e.user.uid}`)}Hs(e){return this.syncEngine.Xs(e.targetId,e.state,e.error)}Us(e,t){const s=t?this.ps.insert(e,t):this.ps.remove(e),i=this.Ns(this.ps),r=this.Ns(s),a=[],o=[];return r.forEach(l=>{i.has(l)||a.push(l)}),i.forEach(l=>{r.has(l)||o.push(l)}),this.syncEngine.eo(a,o).then(()=>{this.ps=s})}Os(e){this.ps.get(e.clientId)&&this.onlineStateHandler(e.onlineState)}Ns(e){let t=Ku();return e.forEach((s,i)=>{t=t.unionWith(i.activeTargetIds)}),t}}class dv{constructor(){this.no=new lu,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e){return this.no.As(e),this.ro[e]||"not-current"}updateQueryState(e,t,s){this.ro[e]=t}removeLocalQueryTarget(e){this.no.Rs(e)}isLocalQueryTarget(e){return this.no.activeTargetIds.has(e)}clearQueryState(e){delete this.ro[e]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(e){return this.no.activeTargetIds.has(e)}start(){return this.no=new lu,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mA{io(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lp{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(e){this.uo.push(e)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){V("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const e of this.uo)e(0)}ao(){V("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const e of this.uo)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let to=null;function Il(){return to===null?to=function(){return 268435456+Math.round(2147483648*Math.random())}():to++,"0x"+to.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gA={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yA{constructor(e){this.lo=e.lo,this.ho=e.ho}Po(e){this.Io=e}To(e){this.Eo=e}Ao(e){this.Ro=e}onMessage(e){this.Vo=e}close(){this.ho()}send(e){this.lo(e)}mo(){this.Io()}fo(){this.Eo()}po(e){this.Ro(e)}yo(e){this.Vo(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gt="WebChannelConnection";class vA extends class{constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const s=t.ssl?"https":"http",i=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.wo=s+"://"+t.host,this.So=`projects/${i}/databases/${r}`,this.bo=this.databaseId.database==="(default)"?`project_id=${i}`:`project_id=${i}&database_id=${r}`}get Do(){return!1}Co(t,s,i,r,a){const o=Il(),l=this.vo(t,s.toUriEncodedString());V("RestConnection",`Sending RPC '${t}' ${o}:`,l,i);const u={"google-cloud-resource-prefix":this.So,"x-goog-request-params":this.bo};return this.Fo(u,r,a),this.Mo(t,l,u,i).then(h=>(V("RestConnection",`Received RPC '${t}' ${o}: `,h),h),h=>{throw Hr("RestConnection",`RPC '${t}' ${o} failed with error: `,h,"url: ",l,"request:",i),h})}xo(t,s,i,r,a,o){return this.Co(t,s,i,r,a)}Fo(t,s,i){t["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Ki}(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),s&&s.headers.forEach((r,a)=>t[a]=r),i&&i.headers.forEach((r,a)=>t[a]=r)}vo(t,s){const i=gA[t];return`${this.wo}/v1/${s}:${i}`}terminate(){}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Mo(e,t,s,i){const r=Il();return new Promise((a,o)=>{const l=new Lg;l.setWithCredentials(!0),l.listenOnce(Ug.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case fo.NO_ERROR:const h=l.getResponseJson();V(gt,`XHR for RPC '${e}' ${r} received:`,JSON.stringify(h)),a(h);break;case fo.TIMEOUT:V(gt,`RPC '${e}' ${r} timed out`),o(new F(N.DEADLINE_EXCEEDED,"Request time out"));break;case fo.HTTP_ERROR:const p=l.getStatus();if(V(gt,`RPC '${e}' ${r} failed with status:`,p,"response text:",l.getResponseText()),p>0){let m=l.getResponseJson();Array.isArray(m)&&(m=m[0]);const w=m==null?void 0:m.error;if(w&&w.status&&w.message){const E=function(C){const j=C.toLowerCase().replace(/_/g,"-");return Object.values(N).indexOf(j)>=0?j:N.UNKNOWN}(w.status);o(new F(E,w.message))}else o(new F(N.UNKNOWN,"Server responded with status "+l.getStatus()))}else o(new F(N.UNAVAILABLE,"Connection failed."));break;default:K()}}finally{V(gt,`RPC '${e}' ${r} completed.`)}});const u=JSON.stringify(i);V(gt,`RPC '${e}' ${r} sending request:`,i),l.send(t,"POST",u,s,15)})}Oo(e,t,s){const i=Il(),r=[this.wo,"/","google.firestore.v1.Firestore","/",e,"/channel"],a=jg(),o=Bg(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.xmlHttpFactory=new Fg({})),this.Fo(l.initMessageHeaders,t,s),l.encodeInitMessageHeaders=!0;const h=r.join("");V(gt,`Creating RPC '${e}' stream ${i}: ${h}`,l);const p=a.createWebChannel(h,l);let m=!1,w=!1;const E=new yA({lo:C=>{w?V(gt,`Not sending because RPC '${e}' stream ${i} is closed:`,C):(m||(V(gt,`Opening RPC '${e}' stream ${i} transport.`),p.open(),m=!0),V(gt,`RPC '${e}' stream ${i} sending:`,C),p.send(C))},ho:()=>p.close()}),x=(C,j,J)=>{C.listen(j,H=>{try{J(H)}catch(ae){setTimeout(()=>{throw ae},0)}})};return x(p,kr.EventType.OPEN,()=>{w||(V(gt,`RPC '${e}' stream ${i} transport opened.`),E.mo())}),x(p,kr.EventType.CLOSE,()=>{w||(w=!0,V(gt,`RPC '${e}' stream ${i} transport closed`),E.po())}),x(p,kr.EventType.ERROR,C=>{w||(w=!0,Hr(gt,`RPC '${e}' stream ${i} transport errored:`,C),E.po(new F(N.UNAVAILABLE,"The operation could not be completed")))}),x(p,kr.EventType.MESSAGE,C=>{var j;if(!w){const J=C.data[0];Z(!!J);const H=J,ae=H.error||((j=H[0])===null||j===void 0?void 0:j.error);if(ae){V(gt,`RPC '${e}' stream ${i} received error:`,ae);const O=ae.status;let U=function(v){const I=Qe[v];if(I!==void 0)return $y(I)}(O),_=ae.message;U===void 0&&(U=N.INTERNAL,_="Unknown error status: "+O+" with message "+ae.message),w=!0,E.po(new F(U,_)),p.close()}else V(gt,`RPC '${e}' stream ${i} received:`,J),E.yo(J)}}),x(o,qg.STAT_EVENT,C=>{C.stat===Gl.PROXY?V(gt,`RPC '${e}' stream ${i} detected buffering proxy`):C.stat===Gl.NOPROXY&&V(gt,`RPC '${e}' stream ${i} detected no buffering proxy`)}),setTimeout(()=>{E.fo()},0),E}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hv(){return typeof window<"u"?window:null}function _o(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tc(n){return new k0(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fv{constructor(e,t,s=1e3,i=1.5,r=6e4){this.oi=e,this.timerId=t,this.No=s,this.Lo=i,this.Bo=r,this.ko=0,this.qo=null,this.Qo=Date.now(),this.reset()}reset(){this.ko=0}Ko(){this.ko=this.Bo}$o(e){this.cancel();const t=Math.floor(this.ko+this.Uo()),s=Math.max(0,Date.now()-this.Qo),i=Math.max(0,t-s);i>0&&V("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.ko} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.qo=this.oi.enqueueAfterDelay(this.timerId,i,()=>(this.Qo=Date.now(),e())),this.ko*=this.Lo,this.ko<this.No&&(this.ko=this.No),this.ko>this.Bo&&(this.ko=this.Bo)}Wo(){this.qo!==null&&(this.qo.skipDelay(),this.qo=null)}cancel(){this.qo!==null&&(this.qo.cancel(),this.qo=null)}Uo(){return(Math.random()-.5)*this.ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pv{constructor(e,t,s,i,r,a,o,l){this.oi=e,this.Go=s,this.zo=i,this.connection=r,this.authCredentialsProvider=a,this.appCheckCredentialsProvider=o,this.listener=l,this.state=0,this.jo=0,this.Ho=null,this.Jo=null,this.stream=null,this.Yo=new fv(e,t)}Zo(){return this.state===1||this.state===5||this.Xo()}Xo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.e_()}async stop(){this.Zo()&&await this.close(0)}t_(){this.state=0,this.Yo.reset()}n_(){this.Xo()&&this.Ho===null&&(this.Ho=this.oi.enqueueAfterDelay(this.Go,6e4,()=>this.r_()))}i_(e){this.s_(),this.stream.send(e)}async r_(){if(this.Xo())return this.close(0)}s_(){this.Ho&&(this.Ho.cancel(),this.Ho=null)}o_(){this.Jo&&(this.Jo.cancel(),this.Jo=null)}async close(e,t){this.s_(),this.o_(),this.Yo.cancel(),this.jo++,e!==4?this.Yo.reset():t&&t.code===N.RESOURCE_EXHAUSTED?(He(t.toString()),He("Using maximum backoff delay to prevent overloading the backend."),this.Yo.Ko()):t&&t.code===N.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.__(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Ao(t)}__(){}auth(){this.state=1;const e=this.a_(this.jo),t=this.jo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([s,i])=>{this.jo===t&&this.u_(s,i)},s=>{e(()=>{const i=new F(N.UNKNOWN,"Fetching auth token failed: "+s.message);return this.c_(i)})})}u_(e,t){const s=this.a_(this.jo);this.stream=this.l_(e,t),this.stream.Po(()=>{s(()=>this.listener.Po())}),this.stream.To(()=>{s(()=>(this.state=2,this.Jo=this.oi.enqueueAfterDelay(this.zo,1e4,()=>(this.Xo()&&(this.state=3),Promise.resolve())),this.listener.To()))}),this.stream.Ao(i=>{s(()=>this.c_(i))}),this.stream.onMessage(i=>{s(()=>this.onMessage(i))})}e_(){this.state=5,this.Yo.$o(async()=>{this.state=0,this.start()})}c_(e){return V("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}a_(e){return t=>{this.oi.enqueueAndForget(()=>this.jo===e?t():(V("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class bA extends pv{constructor(e,t,s,i,r,a){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,i,a),this.serializer=r}l_(e,t){return this.connection.Oo("Listen",e,t)}onMessage(e){this.Yo.reset();const t=C0(this.serializer,e),s=function(r){if(!("targetChange"in r))return ee.min();const a=r.targetChange;return a.targetIds&&a.targetIds.length?ee.min():a.readTime?At(a.readTime):ee.min()}(e);return this.listener.h_(t,s)}P_(e){const t={};t.database=su(this.serializer),t.addTarget=function(r,a){let o;const l=a.target;if(o=Oo(l)?{documents:Fy(r,l)}:{query:Uy(r,l)._t},o.targetId=a.targetId,a.resumeToken.approximateByteSize()>0){o.resumeToken=Ny(r,a.resumeToken);const u=tu(r,a.expectedCount);u!==null&&(o.expectedCount=u)}else if(a.snapshotVersion.compareTo(ee.min())>0){o.readTime=$i(r,a.snapshotVersion.toTimestamp());const u=tu(r,a.expectedCount);u!==null&&(o.expectedCount=u)}return o}(this.serializer,e);const s=D0(this.serializer,e);s&&(t.labels=s),this.i_(t)}I_(e){const t={};t.database=su(this.serializer),t.removeTarget=e,this.i_(t)}}class _A extends pv{constructor(e,t,s,i,r,a){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,i,a),this.serializer=r,this.T_=!1}get E_(){return this.T_}start(){this.T_=!1,this.lastStreamToken=void 0,super.start()}__(){this.T_&&this.d_([])}l_(e,t){return this.connection.Oo("Write",e,t)}onMessage(e){if(Z(!!e.streamToken),this.lastStreamToken=e.streamToken,this.T_){this.Yo.reset();const t=$0(e.writeResults,e.commitTime),s=At(e.commitTime);return this.listener.A_(s,t)}return Z(!e.writeResults||e.writeResults.length===0),this.T_=!0,this.listener.R_()}V_(){const e={};e.database=su(this.serializer),this.i_(e)}d_(e){const t={streamToken:this.lastStreamToken,writes:e.map(s=>Uo(this.serializer,s))};this.i_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wA extends class{}{constructor(e,t,s,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=i,this.m_=!1}f_(){if(this.m_)throw new F(N.FAILED_PRECONDITION,"The client has already been terminated.")}Co(e,t,s,i){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([r,a])=>this.connection.Co(e,nu(t,s),i,r,a)).catch(r=>{throw r.name==="FirebaseError"?(r.code===N.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),r):new F(N.UNKNOWN,r.toString())})}xo(e,t,s,i,r){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([a,o])=>this.connection.xo(e,nu(t,s),i,a,o,r)).catch(a=>{throw a.name==="FirebaseError"?(a.code===N.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),a):new F(N.UNKNOWN,a.toString())})}terminate(){this.m_=!0,this.connection.terminate()}}class IA{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.g_=0,this.p_=null,this.y_=!0}w_(){this.g_===0&&(this.S_("Unknown"),this.p_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.p_=null,this.b_("Backend didn't respond within 10 seconds."),this.S_("Offline"),Promise.resolve())))}D_(e){this.state==="Online"?this.S_("Unknown"):(this.g_++,this.g_>=1&&(this.C_(),this.b_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.S_("Offline")))}set(e){this.C_(),this.g_=0,e==="Online"&&(this.y_=!1),this.S_(e)}S_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}b_(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.y_?(He(t),this.y_=!1):V("OnlineStateTracker",t)}C_(){this.p_!==null&&(this.p_.cancel(),this.p_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class EA{constructor(e,t,s,i,r){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.v_=[],this.F_=new Map,this.M_=new Set,this.x_=[],this.O_=r,this.O_.io(a=>{s.enqueueAndForget(async()=>{Gs(this)&&(V("RemoteStore","Restarting streams for network reachability change."),await async function(l){const u=Q(l);u.M_.add(4),await Aa(u),u.N_.set("Unknown"),u.M_.delete(4),await Ac(u)}(this))})}),this.N_=new IA(s,i)}}async function Ac(n){if(Gs(n))for(const e of n.x_)await e(!0)}async function Aa(n){for(const e of n.x_)await e(!1)}function Sc(n,e){const t=Q(n);t.F_.has(e.targetId)||(t.F_.set(e.targetId,e),od(t)?ad(t):Yi(t).Xo()&&rd(t,e))}function xi(n,e){const t=Q(n),s=Yi(t);t.F_.delete(e),s.Xo()&&mv(t,e),t.F_.size===0&&(s.Xo()?s.n_():Gs(t)&&t.N_.set("Unknown"))}function rd(n,e){if(n.L_.xe(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ee.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Yi(n).P_(e)}function mv(n,e){n.L_.xe(e),Yi(n).I_(e)}function ad(n){n.L_=new E0({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),ot:e=>n.F_.get(e)||null,tt:()=>n.datastore.serializer.databaseId}),Yi(n).start(),n.N_.w_()}function od(n){return Gs(n)&&!Yi(n).Zo()&&n.F_.size>0}function Gs(n){return Q(n).M_.size===0}function gv(n){n.L_=void 0}async function TA(n){n.N_.set("Online")}async function AA(n){n.F_.forEach((e,t)=>{rd(n,e)})}async function SA(n,e){gv(n),od(n)?(n.N_.D_(e),ad(n)):n.N_.set("Unknown")}async function kA(n,e,t){if(n.N_.set("Online"),e instanceof xy&&e.state===2&&e.cause)try{await async function(i,r){const a=r.cause;for(const o of r.targetIds)i.F_.has(o)&&(await i.remoteSyncer.rejectListen(o,a),i.F_.delete(o),i.L_.removeTarget(o))}(n,e)}catch(s){V("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),s),await Ko(n,s)}else if(e instanceof bo?n.L_.Ke(e):e instanceof Dy?n.L_.He(e):n.L_.We(e),!t.isEqual(ee.min()))try{const s=await ov(n.localStore);t.compareTo(s)>=0&&await function(r,a){const o=r.L_.rt(a);return o.targetChanges.forEach((l,u)=>{if(l.resumeToken.approximateByteSize()>0){const h=r.F_.get(u);h&&r.F_.set(u,h.withResumeToken(l.resumeToken,a))}}),o.targetMismatches.forEach((l,u)=>{const h=r.F_.get(l);if(!h)return;r.F_.set(l,h.withResumeToken(it.EMPTY_BYTE_STRING,h.snapshotVersion)),mv(r,l);const p=new In(h.target,l,u,h.sequenceNumber);rd(r,p)}),r.remoteSyncer.applyRemoteEvent(o)}(n,t)}catch(s){V("RemoteStore","Failed to raise snapshot:",s),await Ko(n,s)}}async function Ko(n,e,t){if(!hs(e))throw e;n.M_.add(1),await Aa(n),n.N_.set("Offline"),t||(t=()=>ov(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{V("RemoteStore","Retrying IndexedDB access"),await t(),n.M_.delete(1),await Ac(n)})}function yv(n,e){return e().catch(t=>Ko(n,t,e))}async function Ji(n){const e=Q(n),t=os(e);let s=e.v_.length>0?e.v_[e.v_.length-1].batchId:-1;for(;RA(e);)try{const i=await pA(e.localStore,s);if(i===null){e.v_.length===0&&t.n_();break}s=i.batchId,PA(e,i)}catch(i){await Ko(e,i)}vv(e)&&bv(e)}function RA(n){return Gs(n)&&n.v_.length<10}function PA(n,e){n.v_.push(e);const t=os(n);t.Xo()&&t.E_&&t.d_(e.mutations)}function vv(n){return Gs(n)&&!os(n).Zo()&&n.v_.length>0}function bv(n){os(n).start()}async function CA(n){os(n).V_()}async function $A(n){const e=os(n);for(const t of n.v_)e.d_(t.mutations)}async function DA(n,e,t){const s=n.v_.shift(),i=Qu.from(s,e,t);await yv(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await Ji(n)}async function xA(n,e){e&&os(n).E_&&await async function(s,i){if(function(a){return _0(a)&&a!==N.ABORTED}(i.code)){const r=s.v_.shift();os(s).t_(),await yv(s,()=>s.remoteSyncer.rejectFailedWrite(r.batchId,i)),await Ji(s)}}(n,e),vv(n)&&bv(n)}async function Fp(n,e){const t=Q(n);t.asyncQueue.verifyOperationInProgress(),V("RemoteStore","RemoteStore received new credentials");const s=Gs(t);t.M_.add(3),await Aa(t),s&&t.N_.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.M_.delete(3),await Ac(t)}async function uu(n,e){const t=Q(n);e?(t.M_.delete(2),await Ac(t)):e||(t.M_.add(2),await Aa(t),t.N_.set("Unknown"))}function Yi(n){return n.B_||(n.B_=function(t,s,i){const r=Q(t);return r.f_(),new bA(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:TA.bind(null,n),To:AA.bind(null,n),Ao:SA.bind(null,n),h_:kA.bind(null,n)}),n.x_.push(async e=>{e?(n.B_.t_(),od(n)?ad(n):n.N_.set("Unknown")):(await n.B_.stop(),gv(n))})),n.B_}function os(n){return n.k_||(n.k_=function(t,s,i){const r=Q(t);return r.f_(),new _A(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:()=>Promise.resolve(),To:CA.bind(null,n),Ao:xA.bind(null,n),R_:$A.bind(null,n),A_:DA.bind(null,n)}),n.x_.push(async e=>{e?(n.k_.t_(),await Ji(n)):(await n.k_.stop(),n.v_.length>0&&(V("RemoteStore",`Stopping write stream with ${n.v_.length} pending writes`),n.v_=[]))})),n.k_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cd{constructor(e,t,s,i,r){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=i,this.removalCallback=r,this.deferred=new on,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(a=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,i,r){const a=Date.now()+s,o=new cd(e,t,a,i,r);return o.start(s),o}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new F(N.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function ld(n,e){if(He("AsyncQueue",`${e}: ${n}`),hs(n))return new F(N.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bi{constructor(e){this.comparator=e?(t,s)=>e(t,s)||B.comparator(t.key,s.key):(t,s)=>B.comparator(t.key,s.key),this.keyedMap=Rr(),this.sortedSet=new Ne(this.comparator)}static emptySet(e){return new bi(e.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,s)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof bi)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const i=t.getNext().key,r=s.getNext().key;if(!i.isEqual(r))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new bi;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Up{constructor(){this.q_=new Ne(B.comparator)}track(e){const t=e.doc.key,s=this.q_.get(t);s?e.type!==0&&s.type===3?this.q_=this.q_.insert(t,e):e.type===3&&s.type!==1?this.q_=this.q_.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.q_=this.q_.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.q_=this.q_.remove(t):e.type===1&&s.type===2?this.q_=this.q_.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):K():this.q_=this.q_.insert(t,e)}Q_(){const e=[];return this.q_.inorderTraversal((t,s)=>{e.push(s)}),e}}class Ni{constructor(e,t,s,i,r,a,o,l,u){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=i,this.mutatedKeys=r,this.fromCache=a,this.syncStateChanged=o,this.excludesMetadataChanges=l,this.hasCachedResults=u}static fromInitialDocuments(e,t,s,i,r){const a=[];return t.forEach(o=>{a.push({type:0,doc:o})}),new Ni(e,t,bi.emptySet(t),a,s,i,!0,!1,r)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&yc(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==s[i].type||!t[i].doc.isEqual(s[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NA{constructor(){this.K_=void 0,this.U_=[]}W_(){return this.U_.some(e=>e.G_())}}class VA{constructor(){this.queries=new fs(e=>gy(e),yc),this.onlineState="Unknown",this.z_=new Set}}async function ud(n,e){const t=Q(n);let s=3;const i=e.query;let r=t.queries.get(i);r?!r.W_()&&e.G_()&&(s=2):(r=new NA,s=e.G_()?0:1);try{switch(s){case 0:r.K_=await t.onListen(i,!0);break;case 1:r.K_=await t.onListen(i,!1);break;case 2:await t.onFirstRemoteStoreListen(i)}}catch(a){const o=ld(a,`Initialization of query '${ui(e.query)}' failed`);return void e.onError(o)}t.queries.set(i,r),r.U_.push(e),e.j_(t.onlineState),r.K_&&e.H_(r.K_)&&hd(t)}async function dd(n,e){const t=Q(n),s=e.query;let i=3;const r=t.queries.get(s);if(r){const a=r.U_.indexOf(e);a>=0&&(r.U_.splice(a,1),r.U_.length===0?i=e.G_()?0:1:!r.W_()&&e.G_()&&(i=2))}switch(i){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function OA(n,e){const t=Q(n);let s=!1;for(const i of e){const r=i.query,a=t.queries.get(r);if(a){for(const o of a.U_)o.H_(i)&&(s=!0);a.K_=i}}s&&hd(t)}function MA(n,e,t){const s=Q(n),i=s.queries.get(e);if(i)for(const r of i.U_)r.onError(t);s.queries.delete(e)}function hd(n){n.z_.forEach(e=>{e.next()})}var du,qp;(qp=du||(du={})).J_="default",qp.Cache="cache";class fd{constructor(e,t,s){this.query=e,this.Y_=t,this.Z_=!1,this.X_=null,this.onlineState="Unknown",this.options=s||{}}H_(e){if(!this.options.includeMetadataChanges){const s=[];for(const i of e.docChanges)i.type!==3&&s.push(i);e=new Ni(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Z_?this.ea(e)&&(this.Y_.next(e),t=!0):this.ta(e,this.onlineState)&&(this.na(e),t=!0),this.X_=e,t}onError(e){this.Y_.error(e)}j_(e){this.onlineState=e;let t=!1;return this.X_&&!this.Z_&&this.ta(this.X_,e)&&(this.na(this.X_),t=!0),t}ta(e,t){if(!e.fromCache||!this.G_())return!0;const s=t!=="Offline";return(!this.options.ra||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}ea(e){if(e.docChanges.length>0)return!0;const t=this.X_&&this.X_.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}na(e){e=Ni.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Z_=!0,this.Y_.next(e)}G_(){return this.options.source!==du.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _v{constructor(e){this.key=e}}class wv{constructor(e){this.key=e}}class LA{constructor(e,t){this.query=e,this.la=t,this.ha=null,this.hasCachedResults=!1,this.current=!1,this.Pa=ce(),this.mutatedKeys=ce(),this.Ia=vy(e),this.Ta=new bi(this.Ia)}get Ea(){return this.la}da(e,t){const s=t?t.Aa:new Up,i=t?t.Ta:this.Ta;let r=t?t.mutatedKeys:this.mutatedKeys,a=i,o=!1;const l=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,u=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((h,p)=>{const m=i.get(h),w=Ia(this.query,p)?p:null,E=!!m&&this.mutatedKeys.has(m.key),x=!!w&&(w.hasLocalMutations||this.mutatedKeys.has(w.key)&&w.hasCommittedMutations);let C=!1;m&&w?m.data.isEqual(w.data)?E!==x&&(s.track({type:3,doc:w}),C=!0):this.Ra(m,w)||(s.track({type:2,doc:w}),C=!0,(l&&this.Ia(w,l)>0||u&&this.Ia(w,u)<0)&&(o=!0)):!m&&w?(s.track({type:0,doc:w}),C=!0):m&&!w&&(s.track({type:1,doc:m}),C=!0,(l||u)&&(o=!0)),C&&(w?(a=a.add(w),r=x?r.add(h):r.delete(h)):(a=a.delete(h),r=r.delete(h)))}),this.query.limit!==null)for(;a.size>this.query.limit;){const h=this.query.limitType==="F"?a.last():a.first();a=a.delete(h.key),r=r.delete(h.key),s.track({type:1,doc:h})}return{Ta:a,Aa:s,Xi:o,mutatedKeys:r}}Ra(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,i){const r=this.Ta;this.Ta=e.Ta,this.mutatedKeys=e.mutatedKeys;const a=e.Aa.Q_();a.sort((h,p)=>function(w,E){const x=C=>{switch(C){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return K()}};return x(w)-x(E)}(h.type,p.type)||this.Ia(h.doc,p.doc)),this.Va(s),i=i!=null&&i;const o=t&&!i?this.ma():[],l=this.Pa.size===0&&this.current&&!i?1:0,u=l!==this.ha;return this.ha=l,a.length!==0||u?{snapshot:new Ni(this.query,e.Ta,r,a,e.mutatedKeys,l===0,u,!1,!!s&&s.resumeToken.approximateByteSize()>0),fa:o}:{fa:o}}j_(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Ta:this.Ta,Aa:new Up,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{fa:[]}}ga(e){return!this.la.has(e)&&!!this.Ta.has(e)&&!this.Ta.get(e).hasLocalMutations}Va(e){e&&(e.addedDocuments.forEach(t=>this.la=this.la.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.la=this.la.delete(t)),this.current=e.current)}ma(){if(!this.current)return[];const e=this.Pa;this.Pa=ce(),this.Ta.forEach(s=>{this.ga(s.key)&&(this.Pa=this.Pa.add(s.key))});const t=[];return e.forEach(s=>{this.Pa.has(s)||t.push(new wv(s))}),this.Pa.forEach(s=>{e.has(s)||t.push(new _v(s))}),t}pa(e){this.la=e.hs,this.Pa=ce();const t=this.da(e.documents);return this.applyChanges(t,!0)}ya(){return Ni.fromInitialDocuments(this.query,this.Ta,this.mutatedKeys,this.ha===0,this.hasCachedResults)}}class FA{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class UA{constructor(e){this.key=e,this.wa=!1}}class qA{constructor(e,t,s,i,r,a){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=i,this.currentUser=r,this.maxConcurrentLimboResolutions=a,this.Sa={},this.ba=new fs(o=>gy(o),yc),this.Da=new Map,this.Ca=new Set,this.va=new Ne(B.comparator),this.Fa=new Map,this.Ma=new td,this.xa={},this.Oa=new Map,this.Na=qs.Ln(),this.onlineState="Unknown",this.La=void 0}get isPrimaryClient(){return this.La===!0}}async function BA(n,e,t=!0){const s=kc(n);let i;const r=s.ba.get(e);return r?(s.sharedClientState.addLocalQueryTarget(r.targetId),i=r.view.ya()):i=await Iv(s,e,t,!0),i}async function jA(n,e){const t=kc(n);await Iv(t,e,!0,!1)}async function Iv(n,e,t,s){const i=await Wo(n.localStore,Nt(e)),r=i.targetId,a=t?n.sharedClientState.addLocalQueryTarget(r):"not-current";let o;return s&&(o=await pd(n,e,r,a==="current",i.resumeToken)),n.isPrimaryClient&&t&&Sc(n.remoteStore,i),o}async function pd(n,e,t,s,i){n.Ba=(p,m,w)=>async function(x,C,j,J){let H=C.view.da(j);H.Xi&&(H=await cu(x.localStore,C.query,!1).then(({documents:_})=>C.view.da(_,H)));const ae=J&&J.targetChanges.get(C.targetId),O=J&&J.targetMismatches.get(C.targetId)!=null,U=C.view.applyChanges(H,x.isPrimaryClient,ae,O);return hu(x,C.targetId,U.fa),U.snapshot}(n,p,m,w);const r=await cu(n.localStore,e,!0),a=new LA(e,r.hs),o=a.da(r.documents),l=Ta.createSynthesizedTargetChangeForCurrentChange(t,s&&n.onlineState!=="Offline",i),u=a.applyChanges(o,n.isPrimaryClient,l);hu(n,t,u.fa);const h=new FA(e,t,a);return n.ba.set(e,h),n.Da.has(t)?n.Da.get(t).push(e):n.Da.set(t,[e]),u.snapshot}async function WA(n,e,t){const s=Q(n),i=s.ba.get(e),r=s.Da.get(i.targetId);if(r.length>1)return s.Da.set(i.targetId,r.filter(a=>!yc(a,e))),void s.ba.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(i.targetId),s.sharedClientState.isActiveQueryTarget(i.targetId)||await Di(s.localStore,i.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(i.targetId),t&&xi(s.remoteStore,i.targetId),Vi(s,i.targetId)}).catch(ds)):(Vi(s,i.targetId),await Di(s.localStore,i.targetId,!0))}async function zA(n,e){const t=Q(n),s=t.ba.get(e),i=t.Da.get(s.targetId);t.isPrimaryClient&&i.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),xi(t.remoteStore,s.targetId))}async function GA(n,e,t){const s=vd(n);try{const i=await function(a,o){const l=Q(a),u=Ue.now(),h=o.reduce((w,E)=>w.add(E.key),ce());let p,m;return l.persistence.runTransaction("Locally write mutations","readwrite",w=>{let E=xt(),x=ce();return l.os.getEntries(w,h).next(C=>{E=C,E.forEach((j,J)=>{J.isValidDocument()||(x=x.add(j))})}).next(()=>l.localDocuments.getOverlayedDocuments(w,E)).next(C=>{p=C;const j=[];for(const J of o){const H=v0(J,p.get(J.key).overlayedDocument);H!=null&&j.push(new Rn(J.key,H,ay(H.value.mapValue),Et.exists(!0)))}return l.mutationQueue.addMutationBatch(w,u,j,o)}).next(C=>{m=C;const j=C.applyToLocalDocumentSet(p,x);return l.documentOverlayCache.saveOverlays(w,C.batchId,j)})}).then(()=>({batchId:m.batchId,changes:_y(p)}))}(s.localStore,e);s.sharedClientState.addPendingMutation(i.batchId),function(a,o,l){let u=a.xa[a.currentUser.toKey()];u||(u=new Ne(ie)),u=u.insert(o,l),a.xa[a.currentUser.toKey()]=u}(s,i.batchId,t),await ps(s,i.changes),await Ji(s.remoteStore)}catch(i){const r=ld(i,"Failed to persist write");t.reject(r)}}async function Ev(n,e){const t=Q(n);try{const s=await hA(t.localStore,e);e.targetChanges.forEach((i,r)=>{const a=t.Fa.get(r);a&&(Z(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1),i.addedDocuments.size>0?a.wa=!0:i.modifiedDocuments.size>0?Z(a.wa):i.removedDocuments.size>0&&(Z(a.wa),a.wa=!1))}),await ps(t,s,e)}catch(s){await ds(s)}}function Bp(n,e,t){const s=Q(n);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const i=[];s.ba.forEach((r,a)=>{const o=a.view.j_(e);o.snapshot&&i.push(o.snapshot)}),function(a,o){const l=Q(a);l.onlineState=o;let u=!1;l.queries.forEach((h,p)=>{for(const m of p.U_)m.j_(o)&&(u=!0)}),u&&hd(l)}(s.eventManager,e),i.length&&s.Sa.h_(i),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function KA(n,e,t){const s=Q(n);s.sharedClientState.updateQueryState(e,"rejected",t);const i=s.Fa.get(e),r=i&&i.key;if(r){let a=new Ne(B.comparator);a=a.insert(r,We.newNoDocument(r,ee.min()));const o=ce().add(r),l=new Ea(ee.min(),new Map,new Ne(ie),a,o);await Ev(s,l),s.va=s.va.remove(r),s.Fa.delete(e),yd(s)}else await Di(s.localStore,e,!1).then(()=>Vi(s,e,t)).catch(ds)}async function HA(n,e){const t=Q(n),s=e.batch.batchId;try{const i=await dA(t.localStore,e);gd(t,s,null),md(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await ps(t,i)}catch(i){await ds(i)}}async function QA(n,e,t){const s=Q(n);try{const i=await function(a,o){const l=Q(a);return l.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let h;return l.mutationQueue.lookupMutationBatch(u,o).next(p=>(Z(p!==null),h=p.keys(),l.mutationQueue.removeMutationBatch(u,p))).next(()=>l.mutationQueue.performConsistencyCheck(u)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(u,h,o)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,h)).next(()=>l.localDocuments.getDocuments(u,h))})}(s.localStore,e);gd(s,e,t),md(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await ps(s,i)}catch(i){await ds(i)}}function md(n,e){(n.Oa.get(e)||[]).forEach(t=>{t.resolve()}),n.Oa.delete(e)}function gd(n,e,t){const s=Q(n);let i=s.xa[s.currentUser.toKey()];if(i){const r=i.get(e);r&&(t?r.reject(t):r.resolve(),i=i.remove(e)),s.xa[s.currentUser.toKey()]=i}}function Vi(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const s of n.Da.get(e))n.ba.delete(s),t&&n.Sa.ka(s,t);n.Da.delete(e),n.isPrimaryClient&&n.Ma.Vr(e).forEach(s=>{n.Ma.containsKey(s)||Tv(n,s)})}function Tv(n,e){n.Ca.delete(e.path.canonicalString());const t=n.va.get(e);t!==null&&(xi(n.remoteStore,t),n.va=n.va.remove(e),n.Fa.delete(t),yd(n))}function hu(n,e,t){for(const s of t)s instanceof _v?(n.Ma.addReference(s.key,e),JA(n,s)):s instanceof wv?(V("SyncEngine","Document no longer in limbo: "+s.key),n.Ma.removeReference(s.key,e),n.Ma.containsKey(s.key)||Tv(n,s.key)):K()}function JA(n,e){const t=e.key,s=t.path.canonicalString();n.va.get(t)||n.Ca.has(s)||(V("SyncEngine","New document in limbo: "+t),n.Ca.add(s),yd(n))}function yd(n){for(;n.Ca.size>0&&n.va.size<n.maxConcurrentLimboResolutions;){const e=n.Ca.values().next().value;n.Ca.delete(e);const t=new B(Ee.fromString(e)),s=n.Na.next();n.Fa.set(s,new UA(t)),n.va=n.va.insert(t,s),Sc(n.remoteStore,new In(Nt(wa(t.path)),s,"TargetPurposeLimboResolution",Pt.oe))}}async function ps(n,e,t){const s=Q(n),i=[],r=[],a=[];s.ba.isEmpty()||(s.ba.forEach((o,l)=>{a.push(s.Ba(l,e,t).then(u=>{if((u||t)&&s.isPrimaryClient){const h=u&&!u.fromCache;s.sharedClientState.updateQueryState(l.targetId,h?"current":"not-current")}if(u){i.push(u);const h=sd.Ki(l.targetId,u);r.push(h)}}))}),await Promise.all(a),s.Sa.h_(i),await async function(l,u){const h=Q(l);try{await h.persistence.runTransaction("notifyLocalViewChanges","readwrite",p=>$.forEach(u,m=>$.forEach(m.qi,w=>h.persistence.referenceDelegate.addReference(p,m.targetId,w)).next(()=>$.forEach(m.Qi,w=>h.persistence.referenceDelegate.removeReference(p,m.targetId,w)))))}catch(p){if(!hs(p))throw p;V("LocalStore","Failed to update sequence numbers: "+p)}for(const p of u){const m=p.targetId;if(!p.fromCache){const w=h.ns.get(m),E=w.snapshotVersion,x=w.withLastLimboFreeSnapshotVersion(E);h.ns=h.ns.insert(m,x)}}}(s.localStore,r))}async function YA(n,e){const t=Q(n);if(!t.currentUser.isEqual(e)){V("SyncEngine","User change. New user:",e.toKey());const s=await av(t.localStore,e);t.currentUser=e,function(r,a){r.Oa.forEach(o=>{o.forEach(l=>{l.reject(new F(N.CANCELLED,a))})}),r.Oa.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await ps(t,s.us)}}function XA(n,e){const t=Q(n),s=t.Fa.get(e);if(s&&s.wa)return ce().add(s.key);{let i=ce();const r=t.Da.get(e);if(!r)return i;for(const a of r){const o=t.ba.get(a);i=i.unionWith(o.view.Ea)}return i}}async function ZA(n,e){const t=Q(n),s=await cu(t.localStore,e.query,!0),i=e.view.pa(s);return t.isPrimaryClient&&hu(t,e.targetId,i.fa),i}async function eS(n,e){const t=Q(n);return lv(t.localStore,e).then(s=>ps(t,s))}async function tS(n,e,t,s){const i=Q(n),r=await function(o,l){const u=Q(o),h=Q(u.mutationQueue);return u.persistence.runTransaction("Lookup mutation documents","readonly",p=>h.vn(p,l).next(m=>m?u.localDocuments.getDocuments(p,m):$.resolve(null)))}(i.localStore,e);r!==null?(t==="pending"?await Ji(i.remoteStore):t==="acknowledged"||t==="rejected"?(gd(i,e,s||null),md(i,e),function(o,l){Q(Q(o).mutationQueue).Mn(l)}(i.localStore,e)):K(),await ps(i,r)):V("SyncEngine","Cannot apply mutation batch with id: "+e)}async function nS(n,e){const t=Q(n);if(kc(t),vd(t),e===!0&&t.La!==!0){const s=t.sharedClientState.getAllActiveQueryTargets(),i=await jp(t,s.toArray());t.La=!0,await uu(t.remoteStore,!0);for(const r of i)Sc(t.remoteStore,r)}else if(e===!1&&t.La!==!1){const s=[];let i=Promise.resolve();t.Da.forEach((r,a)=>{t.sharedClientState.isLocalQueryTarget(a)?s.push(a):i=i.then(()=>(Vi(t,a),Di(t.localStore,a,!0))),xi(t.remoteStore,a)}),await i,await jp(t,s),function(a){const o=Q(a);o.Fa.forEach((l,u)=>{xi(o.remoteStore,u)}),o.Ma.mr(),o.Fa=new Map,o.va=new Ne(B.comparator)}(t),t.La=!1,await uu(t.remoteStore,!1)}}async function jp(n,e,t){const s=Q(n),i=[],r=[];for(const a of e){let o;const l=s.Da.get(a);if(l&&l.length!==0){o=await Wo(s.localStore,Nt(l[0]));for(const u of l){const h=s.ba.get(u),p=await ZA(s,h);p.snapshot&&r.push(p.snapshot)}}else{const u=await cv(s.localStore,a);o=await Wo(s.localStore,u),await pd(s,Av(u),a,!1,o.resumeToken)}i.push(o)}return s.Sa.h_(r),i}function Av(n){return py(n.path,n.collectionGroup,n.orderBy,n.filters,n.limit,"F",n.startAt,n.endAt)}function sS(n){return function(t){return Q(Q(t).persistence).Bi()}(Q(n).localStore)}async function iS(n,e,t,s){const i=Q(n);if(i.La)return void V("SyncEngine","Ignoring unexpected query state notification.");const r=i.Da.get(e);if(r&&r.length>0)switch(t){case"current":case"not-current":{const a=await lv(i.localStore,yy(r[0])),o=Ea.createSynthesizedRemoteEventForCurrentChange(e,t==="current",it.EMPTY_BYTE_STRING);await ps(i,a,o);break}case"rejected":await Di(i.localStore,e,!0),Vi(i,e,s);break;default:K()}}async function rS(n,e,t){const s=kc(n);if(s.La){for(const i of e){if(s.Da.has(i)&&s.sharedClientState.isActiveQueryTarget(i)){V("SyncEngine","Adding an already active target "+i);continue}const r=await cv(s.localStore,i),a=await Wo(s.localStore,r);await pd(s,Av(r),a.targetId,!1,a.resumeToken),Sc(s.remoteStore,a)}for(const i of t)s.Da.has(i)&&await Di(s.localStore,i,!1).then(()=>{xi(s.remoteStore,i),Vi(s,i)}).catch(ds)}}function kc(n){const e=Q(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Ev.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=XA.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=KA.bind(null,e),e.Sa.h_=OA.bind(null,e.eventManager),e.Sa.ka=MA.bind(null,e.eventManager),e}function vd(n){const e=Q(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=HA.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=QA.bind(null,e),e}class fu{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=Tc(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){return rv(this.persistence,new iv,e.initialUser,this.serializer)}createPersistence(e){return new nv(Ec.Hr,this.serializer)}createSharedClientState(e){return new dv}async terminate(){var e,t;(e=this.gcScheduler)===null||e===void 0||e.stop(),(t=this.indexBackfillerScheduler)===null||t===void 0||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class Sv extends fu{constructor(e,t,s){super(),this.Qa=e,this.cacheSizeBytes=t,this.forceOwnership=s,this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Qa.initialize(this,e),await vd(this.Qa.syncEngine),await Ji(this.Qa.remoteStore),await this.persistence.fi(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}createLocalStore(e){return rv(this.persistence,new iv,e.initialUser,this.serializer)}createGarbageCollectionScheduler(e,t){const s=this.persistence.referenceDelegate.garbageCollector;return new H0(s,e.asyncQueue,t)}createIndexBackfillerScheduler(e,t){const s=new RT(t,this.persistence);return new kT(e.asyncQueue,s)}createPersistence(e){const t=sv(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),s=this.cacheSizeBytes!==void 0?Rt.withCacheSize(this.cacheSizeBytes):Rt.DEFAULT;return new nd(this.synchronizeTabs,t,e.clientId,s,e.asyncQueue,hv(),_o(),this.serializer,this.sharedClientState,!!this.forceOwnership)}createSharedClientState(e){return new dv}}class aS extends Sv{constructor(e,t){super(e,t,!1),this.Qa=e,this.cacheSizeBytes=t,this.synchronizeTabs=!0}async initialize(e){await super.initialize(e);const t=this.Qa.syncEngine;this.sharedClientState instanceof wl&&(this.sharedClientState.syncEngine={Zs:tS.bind(null,t),Xs:iS.bind(null,t),eo:rS.bind(null,t),Bi:sS.bind(null,t),Ys:eS.bind(null,t)},await this.sharedClientState.start()),await this.persistence.fi(async s=>{await nS(this.Qa.syncEngine,s),this.gcScheduler&&(s&&!this.gcScheduler.started?this.gcScheduler.start():s||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(s&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():s||this.indexBackfillerScheduler.stop())})}createSharedClientState(e){const t=hv();if(!wl.D(t))throw new F(N.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const s=sv(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey);return new wl(t,e.asyncQueue,s,e.clientId,e.initialUser)}}class bd{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>Bp(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=YA.bind(null,this.syncEngine),await uu(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new VA}()}createDatastore(e){const t=Tc(e.databaseInfo.databaseId),s=function(r){return new vA(r)}(e.databaseInfo);return function(r,a,o,l){return new wA(r,a,o,l)}(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return function(s,i,r,a,o){return new EA(s,i,r,a,o)}(this.localStore,this.datastore,e.asyncQueue,t=>Bp(this.syncEngine,t,0),function(){return Lp.D()?new Lp:new mA}())}createSyncEngine(e,t){return function(i,r,a,o,l,u,h){const p=new qA(i,r,a,o,l,u);return h&&(p.La=!0),p}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e;await async function(s){const i=Q(s);V("RemoteStore","RemoteStore shutting down."),i.M_.add(5),await Aa(i),i.O_.shutdown(),i.N_.set("Unknown")}(this.remoteStore),(e=this.datastore)===null||e===void 0||e.terminate()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _d{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Ka(this.observer.next,e)}error(e){this.observer.error?this.Ka(this.observer.error,e):He("Uncaught Error in snapshot listener:",e.toString())}$a(){this.muted=!0}Ka(e,t){this.muted||setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oS{constructor(e,t,s,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this.databaseInfo=i,this.user=yt.UNAUTHENTICATED,this.clientId=Wg.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(s,async r=>{V("FirestoreClient","Received user=",r.uid),await this.authCredentialListener(r),this.user=r}),this.appCheckCredentials.start(s,r=>(V("FirestoreClient","Received new app check token=",r),this.appCheckCredentialListener(r,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new F(N.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const e=new on;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=ld(t,"Failed to shutdown persistence");e.reject(s)}}),e.promise}}async function El(n,e){n.asyncQueue.verifyOperationInProgress(),V("FirestoreClient","Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let s=t.initialUser;n.setCredentialChangeListener(async i=>{s.isEqual(i)||(await av(e.localStore,i),s=i)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function Wp(n,e){n.asyncQueue.verifyOperationInProgress();const t=await lS(n);V("FirestoreClient","Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(s=>Fp(e.remoteStore,s)),n.setAppCheckTokenChangeListener((s,i)=>Fp(e.remoteStore,i)),n._onlineComponents=e}function cS(n){return n.name==="FirebaseError"?n.code===N.FAILED_PRECONDITION||n.code===N.UNIMPLEMENTED:!(typeof DOMException<"u"&&n instanceof DOMException)||n.code===22||n.code===20||n.code===11}async function lS(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){V("FirestoreClient","Using user provided OfflineComponentProvider");try{await El(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!cS(t))throw t;Hr("Error using user provided cache. Falling back to memory cache: "+t),await El(n,new fu)}}else V("FirestoreClient","Using default OfflineComponentProvider"),await El(n,new fu);return n._offlineComponents}async function kv(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(V("FirestoreClient","Using user provided OnlineComponentProvider"),await Wp(n,n._uninitializedComponentsProvider._online)):(V("FirestoreClient","Using default OnlineComponentProvider"),await Wp(n,new bd))),n._onlineComponents}function uS(n){return kv(n).then(e=>e.syncEngine)}async function Ho(n){const e=await kv(n),t=e.eventManager;return t.onListen=BA.bind(null,e.syncEngine),t.onUnlisten=WA.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=jA.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=zA.bind(null,e.syncEngine),t}function dS(n,e,t={}){const s=new on;return n.asyncQueue.enqueueAndForget(async()=>function(r,a,o,l,u){const h=new _d({next:m=>{a.enqueueAndForget(()=>dd(r,p));const w=m.docs.has(o);!w&&m.fromCache?u.reject(new F(N.UNAVAILABLE,"Failed to get document because the client is offline.")):w&&m.fromCache&&l&&l.source==="server"?u.reject(new F(N.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):u.resolve(m)},error:m=>u.reject(m)}),p=new fd(wa(o.path),h,{includeMetadataChanges:!0,ra:!0});return ud(r,p)}(await Ho(n),n.asyncQueue,e,t,s)),s.promise}function hS(n,e,t={}){const s=new on;return n.asyncQueue.enqueueAndForget(async()=>function(r,a,o,l,u){const h=new _d({next:m=>{a.enqueueAndForget(()=>dd(r,p)),m.fromCache&&l.source==="server"?u.reject(new F(N.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):u.resolve(m)},error:m=>u.reject(m)}),p=new fd(o,h,{includeMetadataChanges:!0,ra:!0});return ud(r,p)}(await Ho(n),n.asyncQueue,e,t,s)),s.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rv(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zp=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pv(n,e,t){if(!t)throw new F(N.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function fS(n,e,t,s){if(e===!0&&s===!0)throw new F(N.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Gp(n){if(!B.isDocumentKey(n))throw new F(N.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Kp(n){if(B.isDocumentKey(n))throw new F(N.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Rc(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(s){return s.constructor?s.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":K()}function Ut(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new F(N.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=Rc(n);throw new F(N.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hp{constructor(e){var t,s;if(e.host===void 0){if(e.ssl!==void 0)throw new F(N.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(t=e.ssl)===null||t===void 0||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new F(N.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}fS("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Rv((s=e.experimentalLongPollingOptions)!==null&&s!==void 0?s:{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new F(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new F(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new F(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(s,i){return s.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class wd{constructor(e,t,s,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Hp({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new F(N.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(e){if(this._settingsFrozen)throw new F(N.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Hp(e),e.credentials!==void 0&&(this._authCredentials=function(s){if(!s)return new yT;switch(s.type){case"firstParty":return new _T(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new F(N.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const s=zp.get(t);s&&(V("ComponentProvider","Removing Datastore"),zp.delete(t),s.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pn{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new Pn(this.firestore,e,this._query)}}class bt{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new es(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new bt(this.firestore,e,this._key)}}class es extends Pn{constructor(e,t,s){super(e,t,wa(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new bt(this.firestore,null,new B(e))}withConverter(e){return new es(this.firestore,e,this._path)}}function Gn(n,e,...t){if(n=et(n),Pv("collection","path",e),n instanceof wd){const s=Ee.fromString(e,...t);return Kp(s),new es(n,null,s)}{if(!(n instanceof bt||n instanceof es))throw new F(N.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(Ee.fromString(e,...t));return Kp(s),new es(n.firestore,null,s)}}function $t(n,e,...t){if(n=et(n),arguments.length===1&&(e=Wg.newId()),Pv("doc","path",e),n instanceof wd){const s=Ee.fromString(e,...t);return Gp(s),new bt(n,null,new B(s))}{if(!(n instanceof bt||n instanceof es))throw new F(N.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(Ee.fromString(e,...t));return Gp(s),new bt(n.firestore,n instanceof es?n.converter:null,new B(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pS{constructor(){this.iu=Promise.resolve(),this.su=[],this.ou=!1,this._u=[],this.au=null,this.uu=!1,this.cu=!1,this.lu=[],this.Yo=new fv(this,"async_queue_retry"),this.hu=()=>{const t=_o();t&&V("AsyncQueue","Visibility state changed to "+t.visibilityState),this.Yo.Wo()};const e=_o();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.hu)}get isShuttingDown(){return this.ou}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Pu(),this.Iu(e)}enterRestrictedMode(e){if(!this.ou){this.ou=!0,this.cu=e||!1;const t=_o();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.hu)}}enqueue(e){if(this.Pu(),this.ou)return new Promise(()=>{});const t=new on;return this.Iu(()=>this.ou&&this.cu?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.su.push(e),this.Tu()))}async Tu(){if(this.su.length!==0){try{await this.su[0](),this.su.shift(),this.Yo.reset()}catch(e){if(!hs(e))throw e;V("AsyncQueue","Operation failed with retryable error: "+e)}this.su.length>0&&this.Yo.$o(()=>this.Tu())}}Iu(e){const t=this.iu.then(()=>(this.uu=!0,e().catch(s=>{this.au=s,this.uu=!1;const i=function(a){let o=a.message||"";return a.stack&&(o=a.stack.includes(a.message)?a.stack:a.message+`
`+a.stack),o}(s);throw He("INTERNAL UNHANDLED ERROR: ",i),s}).then(s=>(this.uu=!1,s))));return this.iu=t,t}enqueueAfterDelay(e,t,s){this.Pu(),this.lu.indexOf(e)>-1&&(t=0);const i=cd.createAndSchedule(this,e,t,s,r=>this.Eu(r));return this._u.push(i),i}Pu(){this.au&&K()}verifyOperationInProgress(){}async du(){let e;do e=this.iu,await e;while(e!==this.iu)}Au(e){for(const t of this._u)if(t.timerId===e)return!0;return!1}Ru(e){return this.du().then(()=>{this._u.sort((t,s)=>t.targetTimeMs-s.targetTimeMs);for(const t of this._u)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.du()})}Vu(e){this.lu.push(e)}Eu(e){const t=this._u.indexOf(e);this._u.splice(t,1)}}function Qp(n){return function(t,s){if(typeof t!="object"||t===null)return!1;const i=t;for(const r of s)if(r in i&&typeof i[r]=="function")return!0;return!1}(n,["next","error","complete"])}class cs extends wd{constructor(e,t,s,i){super(e,t,s,i),this.type="firestore",this._queue=function(){return new pS}(),this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||Cv(this),this._firestoreClient.terminate()}}function mS(n,e,t){t||(t="(default)");const s=$u(n,"firestore");if(s.isInitialized(t)){const i=s.getImmediate({identifier:t}),r=s.getOptions(t);if(Wr(r,e))return i;throw new F(N.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new F(N.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new F(N.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return s.initialize({options:e,instanceIdentifier:t})}function Pc(n){return n._firestoreClient||Cv(n),n._firestoreClient.verifyNotTerminated(),n._firestoreClient}function Cv(n){var e,t,s;const i=n._freezeSettings(),r=function(o,l,u,h){return new HT(o,l,u,h.host,h.ssl,h.experimentalForceLongPolling,h.experimentalAutoDetectLongPolling,Rv(h.experimentalLongPollingOptions),h.useFetchStreams)}(n._databaseId,((e=n._app)===null||e===void 0?void 0:e.options.appId)||"",n._persistenceKey,i);n._firestoreClient=new oS(n._authCredentials,n._appCheckCredentials,n._queue,r),!((t=i.localCache)===null||t===void 0)&&t._offlineComponentProvider&&(!((s=i.localCache)===null||s===void 0)&&s._onlineComponentProvider)&&(n._firestoreClient._uninitializedComponentsProvider={_offlineKind:i.localCache.kind,_offline:i.localCache._offlineComponentProvider,_online:i.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oi{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Oi(it.fromBase64String(e))}catch(t){throw new F(N.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Oi(it.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cc{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new F(N.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Fe(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Id{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ed{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new F(N.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new F(N.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return ie(this._lat,e._lat)||ie(this._long,e._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gS=/^__.*__$/;class yS{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new Rn(e,this.data,this.fieldMask,t,this.fieldTransforms):new Qi(e,this.data,t,this.fieldTransforms)}}class $v{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new Rn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Dv(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw K()}}class Td{constructor(e,t,s,i,r,a){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=i,r===void 0&&this.mu(),this.fieldTransforms=r||[],this.fieldMask=a||[]}get path(){return this.settings.path}get fu(){return this.settings.fu}gu(e){return new Td(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}pu(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),i=this.gu({path:s,yu:!1});return i.wu(e),i}Su(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),i=this.gu({path:s,yu:!1});return i.mu(),i}bu(e){return this.gu({path:void 0,yu:!0})}Du(e){return Qo(e,this.settings.methodName,this.settings.Cu||!1,this.path,this.settings.vu)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}mu(){if(this.path)for(let e=0;e<this.path.length;e++)this.wu(this.path.get(e))}wu(e){if(e.length===0)throw this.Du("Document fields must not be empty");if(Dv(this.fu)&&gS.test(e))throw this.Du('Document fields cannot begin and end with "__"')}}class vS{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||Tc(e)}Fu(e,t,s,i=!1){return new Td({fu:e,methodName:t,vu:s,path:Fe.emptyPath(),yu:!1,Cu:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Ad(n){const e=n._freezeSettings(),t=Tc(n._databaseId);return new vS(n._databaseId,!!e.ignoreUndefinedProperties,t)}function bS(n,e,t,s,i,r={}){const a=n.Fu(r.merge||r.mergeFields?2:0,e,t,i);Sd("Data must be an object, but it was:",a,s);const o=xv(s,a);let l,u;if(r.merge)l=new Ct(a.fieldMask),u=a.fieldTransforms;else if(r.mergeFields){const h=[];for(const p of r.mergeFields){const m=pu(e,p,t);if(!a.contains(m))throw new F(N.INVALID_ARGUMENT,`Field '${m}' is specified in your field mask but missing from your input data.`);Vv(h,m)||h.push(m)}l=new Ct(h),u=a.fieldTransforms.filter(p=>l.covers(p.field))}else l=null,u=a.fieldTransforms;return new yS(new vt(o),l,u)}class Sa extends Id{_toFieldTransform(e){if(e.fu!==2)throw e.fu===1?e.Du(`${this._methodName}() can only appear at the top level of your update data`):e.Du(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Sa}}function _S(n,e,t,s){const i=n.Fu(1,e,t);Sd("Data must be an object, but it was:",i,s);const r=[],a=vt.empty();zs(s,(l,u)=>{const h=kd(e,l,t);u=et(u);const p=i.Su(h);if(u instanceof Sa)r.push(h);else{const m=ka(u,p);m!=null&&(r.push(h),a.set(h,m))}});const o=new Ct(r);return new $v(a,o,i.fieldTransforms)}function wS(n,e,t,s,i,r){const a=n.Fu(1,e,t),o=[pu(e,s,t)],l=[i];if(r.length%2!=0)throw new F(N.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let m=0;m<r.length;m+=2)o.push(pu(e,r[m])),l.push(r[m+1]);const u=[],h=vt.empty();for(let m=o.length-1;m>=0;--m)if(!Vv(u,o[m])){const w=o[m];let E=l[m];E=et(E);const x=a.Su(w);if(E instanceof Sa)u.push(w);else{const C=ka(E,x);C!=null&&(u.push(w),h.set(w,C))}}const p=new Ct(u);return new $v(h,p,a.fieldTransforms)}function IS(n,e,t,s=!1){return ka(t,n.Fu(s?4:3,e))}function ka(n,e){if(Nv(n=et(n)))return Sd("Unsupported field value:",e,n),xv(n,e);if(n instanceof Id)return function(s,i){if(!Dv(i.fu))throw i.Du(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.Du(`${s._methodName}() is not currently supported inside arrays`);const r=s._toFieldTransform(i);r&&i.fieldTransforms.push(r)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.yu&&e.fu!==4)throw e.Du("Nested arrays are not supported");return function(s,i){const r=[];let a=0;for(const o of s){let l=ka(o,i.bu(a));l==null&&(l={nullValue:"NULL_VALUE"}),r.push(l),a++}return{arrayValue:{values:r}}}(n,e)}return function(s,i){if((s=et(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return d0(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const r=Ue.fromDate(s);return{timestampValue:$i(i.serializer,r)}}if(s instanceof Ue){const r=new Ue(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:$i(i.serializer,r)}}if(s instanceof Ed)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof Oi)return{bytesValue:Ny(i.serializer,s._byteString)};if(s instanceof bt){const r=i.databaseId,a=s.firestore._databaseId;if(!a.isEqual(r))throw i.Du(`Document reference is for database ${a.projectId}/${a.database} but should be for database ${r.projectId}/${r.database}`);return{referenceValue:Xu(s.firestore._databaseId||i.databaseId,s._key.path)}}throw i.Du(`Unsupported field value: ${Rc(s)}`)}(n,e)}function xv(n,e){const t={};return sy(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):zs(n,(s,i)=>{const r=ka(i,e.pu(s));r!=null&&(t[s]=r)}),{mapValue:{fields:t}}}function Nv(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Ue||n instanceof Ed||n instanceof Oi||n instanceof bt||n instanceof Id)}function Sd(n,e,t){if(!Nv(t)||!function(i){return typeof i=="object"&&i!==null&&(Object.getPrototypeOf(i)===Object.prototype||Object.getPrototypeOf(i)===null)}(t)){const s=Rc(t);throw s==="an object"?e.Du(n+" a custom object"):e.Du(n+" "+s)}}function pu(n,e,t){if((e=et(e))instanceof Cc)return e._internalPath;if(typeof e=="string")return kd(n,e);throw Qo("Field path arguments must be of type string or ",n,!1,void 0,t)}const ES=new RegExp("[~\\*/\\[\\]]");function kd(n,e,t){if(e.search(ES)>=0)throw Qo(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Cc(...e.split("."))._internalPath}catch{throw Qo(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Qo(n,e,t,s,i){const r=s&&!s.isEmpty(),a=i!==void 0;let o=`Function ${e}() called with invalid data`;t&&(o+=" (via `toFirestore()`)"),o+=". ";let l="";return(r||a)&&(l+=" (found",r&&(l+=` in field ${s}`),a&&(l+=` in document ${i}`),l+=")"),new F(N.INVALID_ARGUMENT,o+n+l)}function Vv(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ov{constructor(e,t,s,i,r){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=i,this._converter=r}get id(){return this._key.path.lastSegment()}get ref(){return new bt(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new TS(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field($c("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class TS extends Ov{data(){return super.data()}}function $c(n,e){return typeof e=="string"?kd(n,e):e instanceof Cc?e._internalPath:e._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mv(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new F(N.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Rd{}class Pd extends Rd{}function mu(n,e,...t){let s=[];e instanceof Rd&&s.push(e),s=s.concat(t),function(r){const a=r.filter(l=>l instanceof Cd).length,o=r.filter(l=>l instanceof Dc).length;if(a>1||a>0&&o>0)throw new F(N.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(s);for(const i of s)n=i._apply(n);return n}class Dc extends Pd{constructor(e,t,s){super(),this._field=e,this._op=t,this._value=s,this.type="where"}static _create(e,t,s){return new Dc(e,t,s)}_apply(e){const t=this._parse(e);return Lv(e._query,t),new Pn(e.firestore,e.converter,eu(e._query,t))}_parse(e){const t=Ad(e.firestore);return function(r,a,o,l,u,h,p){let m;if(u.isKeyField()){if(h==="array-contains"||h==="array-contains-any")throw new F(N.INVALID_ARGUMENT,`Invalid Query. You can't perform '${h}' queries on documentId().`);if(h==="in"||h==="not-in"){Xp(p,h);const w=[];for(const E of p)w.push(Yp(l,r,E));m={arrayValue:{values:w}}}else m=Yp(l,r,p)}else h!=="in"&&h!=="not-in"&&h!=="array-contains-any"||Xp(p,h),m=IS(o,a,p,h==="in"||h==="not-in");return he.create(u,h,m)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function Jp(n,e,t){const s=e,i=$c("where",n);return Dc._create(i,s,t)}class Cd extends Rd{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Cd(e,t)}_parse(e){const t=this._queryConstraints.map(s=>s._parse(e)).filter(s=>s.getFilters().length>0);return t.length===1?t[0]:Ae.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(i,r){let a=i;const o=r.getFlattenedFilters();for(const l of o)Lv(a,l),a=eu(a,l)}(e._query,t),new Pn(e.firestore,e.converter,eu(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class $d extends Pd{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new $d(e,t)}_apply(e){const t=function(i,r,a){if(i.startAt!==null)throw new F(N.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(i.endAt!==null)throw new F(N.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new na(r,a)}(e._query,this._field,this._direction);return new Pn(e.firestore,e.converter,function(i,r){const a=i.explicitOrderBy.concat([r]);return new Hi(i.path,i.collectionGroup,a,i.filters.slice(),i.limit,i.limitType,i.startAt,i.endAt)}(e._query,t))}}function AS(n,e="asc"){const t=e,s=$c("orderBy",n);return $d._create(s,t)}class Dd extends Pd{constructor(e,t,s){super(),this.type=e,this._limit=t,this._limitType=s}static _create(e,t,s){return new Dd(e,t,s)}_apply(e){return new Pn(e.firestore,e.converter,Lo(e._query,this._limit,this._limitType))}}function SS(n){return Dd._create("limit",n,"F")}function Yp(n,e,t){if(typeof(t=et(t))=="string"){if(t==="")throw new F(N.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!my(e)&&t.indexOf("/")!==-1)throw new F(N.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const s=e.path.child(Ee.fromString(t));if(!B.isDocumentKey(s))throw new F(N.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return ea(n,new B(s))}if(t instanceof bt)return ea(n,t._key);throw new F(N.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Rc(t)}.`)}function Xp(n,e){if(!Array.isArray(n)||n.length===0)throw new F(N.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Lv(n,e){const t=function(i,r){for(const a of i)for(const o of a.getFlattenedFilters())if(r.indexOf(o.op)>=0)return o.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new F(N.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new F(N.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}class kS{convertValue(e,t="none"){switch(Ms(e)){case 0:return null;case 1:return e.booleanValue;case 2:return je(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(rs(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw K()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return zs(e,(i,r)=>{s[i]=this.convertValue(r,t)}),s}convertGeoPoint(e){return new Ed(je(e.latitude),je(e.longitude))}convertArray(e,t){return(e.values||[]).map(s=>this.convertValue(s,t))}convertServerTimestamp(e,t){switch(t){case"previous":const s=zu(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(Xr(e));default:return null}}convertTimestamp(e){const t=An(e);return new Ue(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=Ee.fromString(e);Z(Wy(s));const i=new Os(s.get(1),s.get(3)),r=new B(s.popFirst(5));return i.isEqual(t)||He(`Document ${r} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function RS(n,e,t){let s;return s=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $r{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class Fv extends Ov{constructor(e,t,s,i,r,a){super(e,t,s,i,a),this._firestore=e,this._firestoreImpl=e,this.metadata=r}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new wo(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field($c("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}}class wo extends Fv{data(e={}){return super.data(e)}}class Uv{constructor(e,t,s,i){this._firestore=e,this._userDataWriter=t,this._snapshot=i,this.metadata=new $r(i.hasPendingWrites,i.fromCache),this.query=s}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(s=>{e.call(t,new wo(this._firestore,this._userDataWriter,s.key,s,new $r(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new F(N.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(i,r){if(i._snapshot.oldDocs.isEmpty()){let a=0;return i._snapshot.docChanges.map(o=>{const l=new wo(i._firestore,i._userDataWriter,o.doc.key,o.doc,new $r(i._snapshot.mutatedKeys.has(o.doc.key),i._snapshot.fromCache),i.query.converter);return o.doc,{type:"added",doc:l,oldIndex:-1,newIndex:a++}})}{let a=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(o=>r||o.type!==3).map(o=>{const l=new wo(i._firestore,i._userDataWriter,o.doc.key,o.doc,new $r(i._snapshot.mutatedKeys.has(o.doc.key),i._snapshot.fromCache),i.query.converter);let u=-1,h=-1;return o.type!==0&&(u=a.indexOf(o.doc.key),a=a.delete(o.doc.key)),o.type!==1&&(a=a.add(o.doc),h=a.indexOf(o.doc.key)),{type:PS(o.type),doc:l,oldIndex:u,newIndex:h}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function PS(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return K()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function CS(n){n=Ut(n,bt);const e=Ut(n.firestore,cs);return dS(Pc(e),n._key).then(t=>jv(e,n,t))}class xd extends kS{constructor(e){super(),this.firestore=e}convertBytes(e){return new Oi(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new bt(this.firestore,null,t)}}function qv(n){n=Ut(n,Pn);const e=Ut(n.firestore,cs),t=Pc(e),s=new xd(e);return Mv(n._query),hS(t,n._query).then(i=>new Uv(e,s,n,i))}function Ks(n,e,t){n=Ut(n,bt);const s=Ut(n.firestore,cs),i=RS(n.converter,e,t);return Vd(s,[bS(Ad(s),"setDoc",n._key,i,n.converter!==null,t).toMutation(n._key,Et.none())])}function Bv(n,e,t,...s){n=Ut(n,bt);const i=Ut(n.firestore,cs),r=Ad(i);let a;return a=typeof(e=et(e))=="string"||e instanceof Cc?wS(r,"updateDoc",n._key,e,t,s):_S(r,"updateDoc",n._key,e),Vd(i,[a.toMutation(n._key,Et.exists(!0))])}function Nd(n){return Vd(Ut(n.firestore,cs),[new _c(n._key,Et.none())])}function gu(n,...e){var t,s,i;n=et(n);let r={includeMetadataChanges:!1,source:"default"},a=0;typeof e[a]!="object"||Qp(e[a])||(r=e[a],a++);const o={includeMetadataChanges:r.includeMetadataChanges,source:r.source};if(Qp(e[a])){const p=e[a];e[a]=(t=p.next)===null||t===void 0?void 0:t.bind(p),e[a+1]=(s=p.error)===null||s===void 0?void 0:s.bind(p),e[a+2]=(i=p.complete)===null||i===void 0?void 0:i.bind(p)}let l,u,h;if(n instanceof bt)u=Ut(n.firestore,cs),h=wa(n._key.path),l={next:p=>{e[a]&&e[a](jv(u,n,p))},error:e[a+1],complete:e[a+2]};else{const p=Ut(n,Pn);u=Ut(p.firestore,cs),h=p._query;const m=new xd(u);l={next:w=>{e[a]&&e[a](new Uv(u,m,p,w))},error:e[a+1],complete:e[a+2]},Mv(n._query)}return function(m,w,E,x){const C=new _d(x),j=new fd(w,C,E);return m.asyncQueue.enqueueAndForget(async()=>ud(await Ho(m),j)),()=>{C.$a(),m.asyncQueue.enqueueAndForget(async()=>dd(await Ho(m),j))}}(Pc(u),h,o,l)}function Vd(n,e){return function(s,i){const r=new on;return s.asyncQueue.enqueueAndForget(async()=>GA(await uS(s),i,r)),r.promise}(Pc(n),e)}function jv(n,e,t){const s=t.docs.get(e._key),i=new xd(n);return new Fv(n,i,e._key,s,new $r(t.hasPendingWrites,t.fromCache),e.converter)}class $S{constructor(e){let t;this.kind="persistent",e!=null&&e.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=VS(),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function DS(n){return new $S(n)}class xS{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new bd,this._offlineComponentProvider=new Sv(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes,this.forceOwnership)}}class NS{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new bd,this._offlineComponentProvider=new aS(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes)}}function VS(n){return new xS(void 0)}function OS(){return new NS}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wv(){return new Sa("deleteField")}(function(e,t=!0){(function(i){Ki=i})(Wi),Ei(new Ds("firestore",(s,{instanceIdentifier:i,options:r})=>{const a=s.getProvider("app").getImmediate(),o=new cs(new vT(s.getProvider("auth-internal")),new IT(s.getProvider("app-check-internal")),function(u,h){if(!Object.prototype.hasOwnProperty.apply(u.options,["projectId"]))throw new F(N.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Os(u.options.projectId,h)}(a,i),a);return r=Object.assign({useFetchStreams:t},r),o._setSettings(r),o},"PUBLIC").setMultipleInstances(!0)),Yn(Gf,"4.6.3",e),Yn(Gf,"4.6.3","esm2017")})();const yu={apiKey:"AIzaSyC9Um4cxmF3LT_f9Ade5gYSj4ZjMbPHZU4",authDomain:"cursing-offers.firebaseapp.com",projectId:"cursing-offers",storageBucket:"cursing-offers.firebasestorage.app",messagingSenderId:"782347533500",appId:"1:782347533500:web:5da31b9357632fc055a4b9"};function MS(){const n=Date.now(),e=864e5,t=new Date().toISOString().slice(0,10),s=(r,a,o)=>({desc:r,qty:a,price:o,disc:0}),i=(r,a,o,l,u,h,p,m,w,E)=>({id:r,number:a,ts:n-w*e,date:new Date(n-w*e).toISOString().slice(0,10),customer:{name:o,phone:l,email:"",afm:"",address:u},subject:h,status:p,total:m,vatMode:"on",lines:E});return{quotes:[i("q1","2311","Γιώργος Παπαδόπουλος","6900000001","Πρέβεζα","Εγκατάσταση CCTV και WiFi","accepted",1437.16,3,[s("Hikvision IP 4MP Bullet",4,89),s("NVR 8 καναλιών + 2TB",1,245),s("UniFi U6 Lite",2,119),s("Εργασία εγκατάστασης",1,320)]),i("q2","2310","Hotel Aktaion","6900000002","Βόνιτσα","WiFi ξενοδοχείου 40 δωμάτια","pending",6920,5,[s("UniFi U6+",20,159),s("Switch PoE 24 θυρών",1,420),s("Εργασία",1,1700)]),i("q3","2309","Μαρία Νικολάου","6900000003","Λευκάδα","Συναγερμός Paradox","done",780,700,[s("Paradox MG5050 set",1,480),s("Εργασία",1,149)]),i("q4","2307","Κώστας Δήμου","6900000004","Πρέβεζα","Κάμερες καταστήματος","rejected",1150,12,[s("Dahua 4MP Dome",6,95),s("Εργασία",1,357)]),i("q5","2306","Σταύρος Σταύρου","6900000005","Πάλαιρος","Θυροτηλέφωνο + κάμερα","pending",540,1,[s("Θυροτηλέφωνο IP",1,290),s("Εργασία",1,145)])],products:[{id:"p1",img:"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100'><rect width='100' height='100' fill='%23eef'/><circle cx='50' cy='50' r='26' fill='%231d5c8a'/><circle cx='50' cy='50' r='10' fill='%23fff'/></svg>",imgW:100,imgH:100,cat:"Κάμερες",model:"Hikvision IP 4MP Bullet",desc:"DS-2CD2043",cost:71.2,minQty:8,links:[{sup:"Xpatit",url:"https://xpatit.gr",code:"HK-2043"}]},{id:"p2",cat:"Κάμερες",model:"Dahua 4MP Dome",desc:"",cost:76},{id:"p3",cat:"Καταγραφικά",model:"NVR 8 καναλιών",desc:"με δίσκο 2TB",cost:196},{id:"p4",cat:"WiFi",model:"UniFi U6 Lite",desc:"Access Point",cost:95.2},{id:"p5",cat:"WiFi",model:"UniFi U6+",desc:"",cost:127.2},{id:"p6",cat:"Συναγερμοί",model:"Paradox MG5050",desc:"set",cost:384}],smoves:[{id:"m1",pid:"p1",qty:6}],custs:[{id:"c1",name:"Γιώργος Παπαδόπουλος",phone:"6900000001",address:"Πρέβεζα",ts:n-30*e}],tasks:[{id:"t1",title:"Εγκατάσταση CCTV",date:t,time:"09:00",cust:"Γιώργος Παπαδόπουλος",tel:"6900000001",addr:"Πρέβεζα",emps:["e1"],rems:[60,0],done:!1,chk:[{tx:"4 κάμερες",dn:!0},{tx:"NVR + δίσκος",dn:!1},{tx:"Ρύθμιση εφαρμογής",dn:!1}],quoteId:"q1"},{id:"t2",title:"Αυτοψία WiFi ξενοδοχείου",date:t,time:"13:30",cust:"Hotel Aktaion",addr:"Βόνιτσα",done:!1,clr:9},{id:"t3",title:"Service συναγερμού",date:t,time:"17:00",cust:"Μαρία Νικολάου",addr:"Λευκάδα",done:!0},{id:"t4",title:"Ασφάλεια βαν",kind:"due",rep:"y",date:new Date(n+5*e).toISOString().slice(0,10),done:!1,rems:[1440,0]},{id:"t5",title:"Παραγγελία Xpatit",date:new Date(n-2*e).toISOString().slice(0,10),done:!1},{id:"t6",title:"Τηλέφωνο σε Σταύρο για θυροτηλέφωνο",date:"",done:!1},{id:"t7",title:"Συνδρομή Starlink",kind:"due",rep:"m",date:new Date(n+9*e).toISOString().slice(0,10),done:!1},{id:"t8",title:"Εγκατάσταση WiFi",date:new Date(n+e).toISOString().slice(0,10),time:"10:00",cust:"Hotel Aktaion",addr:"Βόνιτσα",emps:["e1"],done:!1}],ldocs:[{id:"d3",kind:"purchase",party:"Xpatit",number:"ΤΔΑ 1182",cat:"Εμπορεύματα",net:820,vat:196.8,rate:24,gross:1016.8,date:t,ts:n-e,items:[]},{id:"d4",kind:"purchase",party:"Cosmote",number:"",cat:"Τηλεπικοινωνίες",net:45,vat:10.8,rate:24,gross:55.8,date:t,ts:n-3*e,items:[]},{id:"d1",kind:"sale",qid:"q1",number:"2311",party:"Γιώργος Παπαδόπουλος",net:1159,vat:278.16,rate:24,gross:1437.16,date:t,ts:n-2*e},{id:"d2",kind:"sale",party:"Μαρία Νικολάου",gross:780,date:t,ts:n-30*e}],wdays:[{id:"w1",empId:"e1",date:t,days:1,amount:60},{id:"w2",empId:"e1",date:t,days:1,amount:60}],needs:[{id:"n1",ts:n-e,title:"Κρουστικό δράπανο",qty:"1",notes:"",by:{uid:"e",name:"Νίκος Τεχνικός"},done:!1},{id:"n2",ts:n-3*e,title:"Βίδες γυψοσανίδας",qty:"2 κουτιά",by:{uid:"demo",name:"Διαχειριστής"},done:!0,doneAt:n-e}],wpays:[{id:"wp1",empId:"e1",date:t,amount:50,method:"cash"}],lpays:[{id:"p3",dir:"out",date:t,party:"Xpatit",docId:"d3",amount:400,method:"bank",note:""},{id:"p1",docId:"d1",amount:500,dir:"in",date:t,party:"Γιώργος Παπαδόπουλος",method:"bank",note:"Προκαταβολή"},{id:"p2",docId:"d2",amount:780,dir:"in",date:t,party:"Μαρία Νικολάου",method:"cash",note:""}],emps:[{id:"e1",name:"Νίκος Τεχνικός",rate:60}],st:{main:{vat:24,margin:25,next:2312},books:{opening:1500,costCats:["Εμπορεύματα","Υλικά","Καύσιμα","Τηλεπικοινωνίες","Λοιπά έξοδα"]}}}}const vu={quotes:"quotes",custs:"customers",tasks:"tasks",ldocs:"ledger_docs",lpays:"ledger_pays",emps:"employees",products:"products",smoves:"stock_moves",wdays:"workdays",wpays:"wagepays",needs:"tool_needs"},Ra={...vu,qlog:"quote_log",pbuys:"partner_buys"},A={quotes:[],custs:[],tasks:[],ldocs:[],lpays:[],emps:[],products:[],smoves:[],wdays:[],wpays:[],needs:[],st:{}},zv=new Set;function LS(n){zv.add(n)}function Lt(){zv.forEach(n=>n())}const tt=new URLSearchParams(location.search).has("demo"),Hs=tt;let Sn=null,Le=null,Jo=[];const Fr={},FS=()=>Sn&&Sn.currentUser||null;function US(n){if(tt){Object.assign(A,MS()),n({email:"demo@techmate"}),setTimeout(Lt,0);return}const e=ng(yu);Sn=pT(e),Le=mS(e,{localCache:DS({tabManager:OS()})}),tE(Sn,t=>{Jo.forEach(s=>s()),Jo=[],t&&qS(),n(t)})}let mi=[],Ir=null;function qS(){Ir=null,Jo.push(gu(Gn(Le,"settings"),n=>{const e={};n.docs.forEach(r=>e[r.id]=r.data()),A.st=e;const t=Sn.currentUser,s=t&&(e.roles&&e.roles.users||{})[t.uid],i=s&&s.role==="team"?"team:"+(s.empId||""):"owner";i!==Ir&&(Ir=i,Zp(i)),Lt()},()=>{Ir===null&&(Ir="owner",Zp("owner"))})),Jo.push(()=>{mi.forEach(n=>n()),mi=[]})}function Zp(n){mi.forEach(s=>s()),mi=[],Object.keys(vu).forEach(s=>{s!=="tasks"&&(A[s]=[],delete Fr[s])});const e=(s,i)=>mi.push(gu(i,r=>{A[s]=r.docs.map(a=>({...a.data(),id:a.id})),Fr[s]=!0,Lt()},()=>{A[s]=[],Lt()}));if(n==="owner"){Object.entries(vu).forEach(([s,i])=>e(s,Gn(Le,i)));return}const t=n.slice(5);e("tasks",Gn(Le,"tasks")),e("needs",Gn(Le,"tool_needs")),t&&(e("wdays",mu(Gn(Le,"workdays"),Jp("empId","==",t))),e("wpays",mu(Gn(Le,"wagepays"),Jp("empId","==",t))),mi.push(gu($t(Le,"employees",t),s=>{A.emps=s.exists()?[{...s.data(),id:s.id}]:[],Fr.emps=!0,Lt()},()=>{A.emps=[],Lt()})))}function BS(n,e){return XI(Sn,n,e)}function jS(){return tt?location.assign(location.pathname):nE(Sn)}const Me=n=>String(n||"").trim().toLowerCase(),k=(n,e=0)=>{const t=parseFloat(n);return isNaN(t)?e:t},q=n=>Math.round(n*100)/100,dt=n=>n.status||"pending",cn=n=>!!(n&&n.kind==="install"),Io={pending:"Σε αναμονή",accepted:"Δεκτή",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"};function xc(n){let e=0;return A.lpays.forEach(t=>{t.docId===n&&(e+=k(t.amount))}),q(e)}function Gv(n){return Math.max(0,q(k(n.gross)-xc(n.id)))}function un(){const n={},e=t=>{const s=Me(t)||"_none";return n[s]||(n[s]={k:s,name:t||"(χωρίς όνομα)",quotes:[],mins:[],last:0})};return A.custs.forEach(t=>{const s=e(t.name);s.name=t.name,s.rec=t,s.last=Math.max(s.last,t.upd||t.ts||0)}),A.quotes.forEach(t=>{const s=e(t.customer&&t.customer.name);(cn(t)?s.mins:s.quotes).push(t),s.last=Math.max(s.last,t.ts||0)}),A.ldocs.forEach(t=>{t.kind==="sale"&&e(t.party)}),Object.values(n).map(t=>{t.won=0,t.owed=0,t.docs=A.ldocs.filter(r=>r.kind==="sale"&&Me(r.party)===t.k),t.quotes.forEach(r=>{const a=dt(r);(a==="accepted"||a==="done")&&(t.won+=k(r.total))}),t.docs.forEach(r=>{t.owed+=Gv(r),t.last=Math.max(t.last,r.ts||0)}),t.owed=q(t.owed),t.won=q(t.won);const s=t.quotes.slice().sort((r,a)=>(a.ts||0)-(r.ts||0))[0],i=s&&s.customer||{};return t.info={},["phone","email","afm","address"].forEach(r=>t.info[r]=t.rec&&t.rec[r]||i[r]||""),t})}const ze=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),Ce=n=>JSON.parse(JSON.stringify(n)),ne=()=>A.st.main;let Kv=()=>{};function WS(n){Kv=n}const dn=n=>{n.catch(e=>Kv(e))};function Ge(n,e){const t=Ce(e);delete t.id;const s=A[n];if(s){const i=s.findIndex(r=>r.id===e.id);i>=0?s[i]=Ce(e):s.push(Ce(e))}tt||dn(Ks($t(Le,Ra[n],e.id),t)),Lt()}function Hv(n,e){A[n]&&(A[n]=A[n].filter(t=>t.id!==e)),tt||dn(Nd($t(Le,Ra[n],e))),Lt()}const Mi=()=>tt?{uid:"demo",email:"demo@techmate"}:Sn&&Sn.currentUser;function Bs(n,e,t){const s=(A[n]||[]).find(r=>r.id===e);s&&Object.keys(t).forEach(r=>{t[r]===void 0?delete s[r]:s[r]=t[r]});const i={};Object.keys(t).forEach(r=>i[r]=t[r]===void 0?Wv():t[r]),tt||dn(Bv($t(Le,Ra[n],e),i)),Lt()}function zt(n,e,t){const s=A[n];let i=s&&s.find(a=>a.id===e);s&&!i&&(i={id:e},s.push(i)),i&&Object.keys(t).forEach(a=>{t[a]===void 0?delete i[a]:i[a]=Ce(t[a])});const r={};Object.keys(t).forEach(a=>{a!=="id"&&(r[a]=t[a]===void 0?Wv():Ce(t[a]))}),tt||dn(Ks($t(Le,Ra[n],e),r,{merge:!0})),Lt()}function em(n,e){tt||dn(Ks($t(Le,"product_imgs",n),{d:e.d,w:e.w,h:e.h}))}function zS(n){tt||dn(Nd($t(Le,"product_imgs",n)))}const js={};async function Qv(n){if(tt)return js[n]?Ce(js[n]):null;const e=await CS($t(Le,n));return e.exists()?e.data():null}async function GS(n){return tt?Object.keys(js).filter(t=>t.startsWith(n+"/")).map(t=>({...Ce(js[t]),id:t.slice(n.length+1)})):(await qv(Gn(Le,n))).docs.map(t=>({...t.data(),id:t.id}))}async function Li(n,e){if(tt){js[n]={...js[n]||{},...Ce(e)};return}await Ks($t(Le,n),e,{merge:!0})}async function tm(n){if(tt){delete js[n];return}await Nd($t(Le,n))}function KS(n){A.st.main&&(A.st.main.next=n),tt||dn(Ks($t(Le,"settings","main"),{next:n},{merge:!0}))}const Od=n=>k(n.qty)*k(n.price)*(1-k(n.disc)/100),Md=n=>q((n.lines||[]).reduce((e,t)=>e+Od(t),0));function Jv(n){const e=Md(n),t=n.vatMode==="off",s=k(ne()&&ne().vat,24),i=t?0:q(e*s/100);return{sub:e,vat:i,vp:s,off:t,total:q(e+i)}}function Nc(n){const e=k(n.cost,0);if(n.marginEur!=null&&n.marginEur!=="")return q(e+k(n.marginEur));const t=n.margin==null||n.margin===""?k(ne()&&ne().margin,25):k(n.margin);return q(e*(1+t/100))}function Yv(n,e){let t=0,s=0,i=0;return A.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(a=>{a.pid===n&&(t+=k(a.qty))})}),A.smoves.forEach(r=>{r.pid===n&&(t+=k(r.qty))}),A.quotes.forEach(r=>{if(r.id===e)return;const a=dt(r);(r.lines||[]).forEach(o=>{if(o.pid!==n||o.src!=="stock")return;const l=k(o.qty);a==="done"?r.noStock||(s+=l):a==="accepted"&&(i+=l)})}),q(t-s-i)}function no(n,e){if(!["main","logo","books","meta"].includes(n))return;const t=A.st[n]||(A.st[n]={});Object.keys(e).forEach(i=>{t[i]=Ce(e[i])});const s={};Object.keys(e).forEach(i=>s[i]=Ce(e[i])),tt||dn(Ks($t(Le,"settings",n),s,{merge:!0})),Lt()}function Yo(n,e,t,s){const i=(A[n]||[]).find(o=>o.id===e);if(!i)return;const r=t.split(".");let a=i;for(let o=0;o<r.length-1;o++)(!a[r[o]]||typeof a[r[o]]!="object")&&(a[r[o]]={}),a=a[r[o]];a[r[r.length-1]]=Ce(s),tt||dn(Bv($t(Le,Ra[n],e),{[t]:Ce(s)})),Lt()}async function HS(){return tt?[{id:"m1",name:"Νίκος Δημητρίου",phone:"6911111111",email:"",msg:"Θέλω προσφορά για 4 κάμερες σε κατάστημα.",svc:"Κάμερες",area:"Χαλκίδα",day:"Απόγευμα",at:new Date().toISOString(),read:!1},{id:"m2",name:"Ελένη Κ.",phone:"",email:"eleni@example.gr",msg:"Πρόβλημα με το WiFi στο ξενοδοχείο.",svc:"WiFi",area:"",day:"",at:new Date(Date.now()-864e5*3).toISOString(),read:!0}]:(await qv(mu(Gn(Le,"contact"),AS("at","desc"),SS(50)))).docs.map(e=>({...e.data(),id:e.id}))}function QS(n){tt||dn(Ks($t(Le,"contact",n),{read:!0},{merge:!0}))}/*! Capacitor: https://capacitorjs.com/ - MIT License */var Fi;(function(n){n.Unimplemented="UNIMPLEMENTED",n.Unavailable="UNAVAILABLE"})(Fi||(Fi={}));class Tl extends Error{constructor(e,t,s){super(e),this.message=e,this.code=t,this.data=s}}const JS=n=>{var e,t;return n!=null&&n.androidBridge?"android":!((t=(e=n==null?void 0:n.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||t===void 0)&&t.bridge?"ios":"web"},YS=n=>{const e=n.CapacitorCustomPlatform||null,t=n.Capacitor||{},s=t.Plugins=t.Plugins||{},i=()=>e!==null?e.name:JS(n),r=()=>i()!=="web",a=p=>{const m=u.get(p);return!!(m!=null&&m.platforms.has(i())||o(p))},o=p=>{var m;return(m=t.PluginHeaders)===null||m===void 0?void 0:m.find(w=>w.name===p)},l=p=>n.console.error(p),u=new Map,h=(p,m={})=>{const w=u.get(p);if(w)return console.warn(`Capacitor plugin "${p}" already registered. Cannot register plugins twice.`),w.proxy;const E=i(),x=o(p);let C;const j=async()=>(!C&&E in m?C=typeof m[E]=="function"?C=await m[E]():C=m[E]:e!==null&&!C&&"web"in m&&(C=typeof m.web=="function"?C=await m.web():C=m.web),C),J=(y,v)=>{var I,T;if(x){const R=x==null?void 0:x.methods.find(b=>v===b.name);if(R)return R.rtype==="promise"?b=>t.nativePromise(p,v.toString(),b):(b,St)=>t.nativeCallback(p,v.toString(),b,St);if(y)return(I=y[v])===null||I===void 0?void 0:I.bind(y)}else{if(y)return(T=y[v])===null||T===void 0?void 0:T.bind(y);throw new Tl(`"${p}" plugin is not implemented on ${E}`,Fi.Unimplemented)}},H=y=>{let v;const I=(...T)=>{const R=j().then(b=>{const St=J(b,y);if(St){const Jt=St(...T);return v=Jt==null?void 0:Jt.remove,Jt}else throw new Tl(`"${p}.${y}()" is not implemented on ${E}`,Fi.Unimplemented)});return y==="addListener"&&(R.remove=async()=>v()),R};return I.toString=()=>`${y.toString()}() { [capacitor code] }`,Object.defineProperty(I,"name",{value:y,writable:!1,configurable:!1}),I},ae=H("addListener"),O=H("removeListener"),U=(y,v)=>{const I=ae({eventName:y},v).then(b=>b),T=async()=>{const b=await I;await O({eventName:y,callbackId:b})},R=new Promise(b=>I.then(()=>b({remove:T})));return R.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await T()},R},_=new Proxy({},{get(y,v){switch(v){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return x?U:ae;case"removeListener":return O;default:return H(v)}}});return s[p]=_,u.set(p,{name:p,proxy:_,platforms:new Set([...Object.keys(m),...x?[E]:[]])}),_};return t.convertFileSrc||(t.convertFileSrc=p=>p),t.getPlatform=i,t.handleError=l,t.isNativePlatform=r,t.isPluginAvailable=a,t.registerPlugin=h,t.Exception=Tl,t.DEBUG=!!t.DEBUG,t.isLoggingEnabled=!!t.isLoggingEnabled,t},XS=n=>n.Capacitor=YS(n),ra=XS(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),Pa=ra.registerPlugin;class Ld{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let s=!1;this.listeners[e]||(this.listeners[e]=[],s=!0),this.listeners[e].push(t);const r=this.windowListeners[e];r&&!r.registered&&this.addWindowListener(r),s&&this.sendRetainedArgumentsForEvent(e);const a=async()=>this.removeListener(e,t);return Promise.resolve({remove:a})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,s){const i=this.listeners[e];if(!i){if(s){let r=this.retainedEventArguments[e];r||(r=[]),r.push(t),this.retainedEventArguments[e]=r}return}i.forEach(r=>r(t))}hasListeners(e){var t;return!!(!((t=this.listeners[e])===null||t===void 0)&&t.length)}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:s=>{this.notifyListeners(t,s)}}}unimplemented(e="not implemented"){return new ra.Exception(e,Fi.Unimplemented)}unavailable(e="not available"){return new ra.Exception(e,Fi.Unavailable)}async removeListener(e,t){const s=this.listeners[e];if(!s)return;const i=s.indexOf(t);i!==-1&&this.listeners[e].splice(i,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(s=>{this.notifyListeners(e,s)}))}}const nm=n=>encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),sm=n=>n.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class ZS extends Ld{async getCookies(){const e=document.cookie,t={};return e.split(";").forEach(s=>{if(s.length<=0)return;let[i,r]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");i=sm(i).trim(),r=sm(r).trim(),t[i]=r}),t}async setCookie(e){try{const t=nm(e.key),s=nm(e.value),i=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",r=(e.path||"/").replace("path=",""),a=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${t}=${s||""}${i}; path=${r}; ${a};`}catch(t){return Promise.reject(t)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(t){return Promise.reject(t)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const t of e)document.cookie=t.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}Pa("CapacitorCookies",{web:()=>new ZS});const ek=async n=>new Promise((e,t)=>{const s=new FileReader;s.onload=()=>{const i=s.result;e(i.indexOf(",")>=0?i.split(",")[1]:i)},s.onerror=i=>t(i),s.readAsDataURL(n)}),tk=(n={})=>{const e=Object.keys(n);return Object.keys(n).map(i=>i.toLocaleLowerCase()).reduce((i,r,a)=>(i[r]=n[e[a]],i),{})},nk=(n,e=!0)=>n?Object.entries(n).reduce((s,i)=>{const[r,a]=i;let o,l;return Array.isArray(a)?(l="",a.forEach(u=>{o=e?encodeURIComponent(u):u,l+=`${r}=${o}&`}),l.slice(0,-1)):(o=e?encodeURIComponent(a):a,l=`${r}=${o}`),`${s}&${l}`},"").substr(1):null,sk=(n,e={})=>{const t=Object.assign({method:n.method||"GET",headers:n.headers},e),i=tk(n.headers)["content-type"]||"";if(typeof n.data=="string")t.body=n.data;else if(i.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[a,o]of Object.entries(n.data||{}))r.set(a,o);t.body=r.toString()}else if(i.includes("multipart/form-data")||n.data instanceof FormData){const r=new FormData;if(n.data instanceof FormData)n.data.forEach((o,l)=>{r.append(l,o)});else for(const o of Object.keys(n.data))r.append(o,n.data[o]);t.body=r;const a=new Headers(t.headers);a.delete("content-type"),t.headers=a}else(i.includes("application/json")||typeof n.data=="object")&&(t.body=JSON.stringify(n.data));return t};class ik extends Ld{async request(e){const t=sk(e,e.webFetchExtra),s=nk(e.params,e.shouldEncodeUrlParams),i=s?`${e.url}?${s}`:e.url,r=await fetch(i,t),a=r.headers.get("content-type")||"";let{responseType:o="text"}=r.ok?e:{};a.includes("application/json")&&(o="json");let l,u;switch(o){case"arraybuffer":case"blob":u=await r.blob(),l=await ek(u);break;case"json":l=await r.json();break;case"document":case"text":default:l=await r.text()}const h={};return r.headers.forEach((p,m)=>{h[m]=p}),{data:l,headers:h,status:r.status,url:r.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}Pa("CapacitorHttp",{web:()=>new ik});var im;(function(n){n.Dark="DARK",n.Light="LIGHT",n.Default="DEFAULT"})(im||(im={}));var rm;(function(n){n.StatusBar="StatusBar",n.NavigationBar="NavigationBar"})(rm||(rm={}));class rk extends Ld{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}Pa("SystemBars",{web:()=>new rk});const ak="modulepreload",ok=function(n){return"/"+n},am={},Fn=function(e,t,s){let i=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),o=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));i=Promise.allSettled(t.map(l=>{if(l=ok(l),l in am)return;am[l]=!0;const u=l.endsWith(".css"),h=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${h}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":ak,u||(p.as="script"),p.crossOrigin="",p.href=l,o&&p.setAttribute("nonce",o),document.head.appendChild(p),u)return new Promise((m,w)=>{p.addEventListener("load",m),p.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${l}`)))})}))}function r(a){const o=new Event("vite:preloadError",{cancelable:!0});if(o.payload=a,window.dispatchEvent(o),!o.defaultPrevented)throw a}return i.then(a=>{for(const o of a||[])o.status==="rejected"&&r(o.reason);return e().catch(r)})},ck="__capgo_keep_url_path_after_reload",Al="__capgo_history_stack__",om=100,lk=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(lk){const n=window;if(!n.__capgoHistoryPatched){n.__capgoHistoryPatched=!0;const e=()=>{try{if(n.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(ck)==="1"}catch{return!1}},t=()=>{try{const O=window.sessionStorage.getItem(Al);if(!O)return{stack:[],index:-1};const U=JSON.parse(O);return!U||!Array.isArray(U.stack)||typeof U.index!="number"?{stack:[],index:-1}:U}catch{return{stack:[],index:-1}}},s=(O,U)=>{try{window.sessionStorage.setItem(Al,JSON.stringify({stack:O,index:U}))}catch{}},i=()=>{try{window.sessionStorage.removeItem(Al)}catch{}},r=O=>{try{const U=O??window.location.href,_=new URL(U instanceof URL?U.toString():U,window.location.href);return`${_.pathname}${_.search}${_.hash}`}catch{return null}},a=(O,U)=>{if(O.length<=om)return{stack:O,index:U};const _=O.length-om,y=O.slice(_),v=Math.max(0,U-_);return{stack:y,index:v}},o=O=>{document.readyState==="complete"||document.readyState==="interactive"?O():window.addEventListener("DOMContentLoaded",O,{once:!0})};let l=!1,u=!1,h=!1;const p=()=>{if(!l)return;const O=t(),U=r();if(U){if(O.stack.length===0){O.stack.push(U),O.index=0,s(O.stack,O.index);return}(O.index<0||O.index>=O.stack.length)&&(O.index=O.stack.length-1),O.stack[O.index]!==U&&(O.stack[O.index]=U,s(O.stack,O.index))}},m=(O,U)=>{if(!l||u)return;const _=r(O);if(!_)return;let{stack:y,index:v}=t();y.length===0?(y.push(_),v=y.length-1):U?((v<0||v>=y.length)&&(v=y.length-1),y[v]=_):v>=y.length-1?(y.push(_),v=y.length-1):(y=y.slice(0,v+1),y.push(_),v=y.length-1),{stack:y,index:v}=a(y,v),s(y,v)},w=()=>{if(!l||u)return;const O=t();if(O.stack.length===0){p();return}const U=O.index>=0&&O.index<O.stack.length?O.index:O.stack.length-1,_=r();if(O.stack.length===1&&_===O.stack[0])return;const y=O.stack[0];if(!y)return;u=!0;try{history.replaceState(history.state,document.title,y);for(let T=1;T<O.stack.length;T+=1)history.pushState(history.state,document.title,O.stack[T])}catch{u=!1;return}u=!1;const v=O.stack.length-1,I=U-v;I!==0?history.go(I):(history.replaceState(history.state,document.title,O.stack[U]),window.dispatchEvent(new PopStateEvent("popstate")))},E=()=>{!l||h||(h=!0,o(()=>{h=!1,w()}))};let x=null,C=null;const j=()=>{if(!l||u)return;const O=r();if(!O)return;const U=t(),_=U.stack.lastIndexOf(O);_>=0?U.index=_:(U.stack.push(O),U.index=U.stack.length-1);const y=a(U.stack,U.index);s(y.stack,y.index)},J=()=>{x&&C||(x=history.pushState,C=history.replaceState,history.pushState=function(U,_,y){const v=x==null?void 0:x.call(history,U,_,y);return m(y,!1),v},history.replaceState=function(U,_,y){const v=C==null?void 0:C.call(history,U,_,y);return m(y,!0),v},window.addEventListener("popstate",j))},H=()=>{x&&(history.pushState=x,x=null),C&&(history.replaceState=C,C=null),window.removeEventListener("popstate",j)},ae=O=>{if(l===O){l&&(p(),E());return}l=O,l?(J(),p(),E()):(H(),i())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",O=>{var U;const _=O,y=(U=_==null?void 0:_.detail)===null||U===void 0?void 0:U.enabled;typeof y=="boolean"?(n.__capgoKeepUrlPathAfterReload=y,ae(y)):(n.__capgoKeepUrlPathAfterReload=!0,ae(!0))}),ae(e())}}var cm;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",n[n.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",n[n.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(cm||(cm={}));var lm;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.PENDING=1]="PENDING",n[n.DOWNLOADING=2]="DOWNLOADING",n[n.INSTALLING=3]="INSTALLING",n[n.INSTALLED=4]="INSTALLED",n[n.FAILED=5]="FAILED",n[n.CANCELED=6]="CANCELED",n[n.DOWNLOADED=11]="DOWNLOADED"})(lm||(lm={}));var um;(function(n){n[n.OK=0]="OK",n[n.CANCELED=1]="CANCELED",n[n.FAILED=2]="FAILED",n[n.NOT_AVAILABLE=3]="NOT_AVAILABLE",n[n.NOT_ALLOWED=4]="NOT_ALLOWED",n[n.INFO_MISSING=5]="INFO_MISSING"})(um||(um={}));const aa=Pa("CapacitorUpdater",{web:()=>Fn(()=>import("./web-D33pmard.js"),[]).then(n=>new n.CapacitorUpdaterWeb)}),Cn=ra.isNativePlatform(),Gt=Cn?Pa("TechMate"):null,bu={accent:0,view:"lists",sun:!1,showDone:!0,compact:!1,defRems:"60,0",dueRems:"1440,0",rep:!0,repMin:5,repMax:6,snooze:10,alarmSound:!1,clockMode:!1,syncMin:60,notifyNew:!0,wAlpha:95,wMode:"todo",wList:"",wDays:2,autoUpd:!0,empClr:"{}",bUri:"",bAuto:!0,bLast:0};let Cs={...bu};const Xv="tm-settings",Ze=()=>Cs;async function oa(){if(Gt)try{const n=await Gt.getSettings();Cs={...bu,...n||{}}}catch{}else try{Cs={...bu,...JSON.parse(localStorage.getItem(Xv)||"{}")}}catch{}return Cs}async function Ur(n,e){if(Cs={...Cs,[n]:e},Gt)try{await Gt.setSetting({k:n,v:e})}catch{}else try{localStorage.setItem(Xv,JSON.stringify(Cs))}catch{}}const $e=async(n,e={},t=null)=>{if(!Gt)return t;try{return await Gt[n](e)}catch(s){return{error:s&&s.message||"σφάλμα"}}},be={setSession:n=>$e("setSession",n),clearSession:()=>$e("clearSession"),setTasks:(n,e,t)=>$e("setTasks",{json:n,emps:e,lists:t}),testNotif:()=>$e("testNotif"),openBattery:()=>$e("openBattery"),openNotifSettings:()=>$e("openNotifSettings"),exactAlarms:()=>$e("exactAlarms",{},{ok:!0}),msStatus:()=>$e("msStatus",{},{connected:!1}),msLogin:()=>$e("msLogin"),msSync:()=>$e("msSync",{},{ok:!1}),msDisconnect:()=>$e("msDisconnect"),pull:()=>$e("pull",{},{ok:!1}),backupPick:()=>$e("backupPick",{},{error:"Μόνο στο κινητό"}),backupWrite:n=>$e("backupWrite",{json:n},{error:"Μόνο στο κινητό"}),takeLaunch:()=>$e("takeLaunch",{},{}),installApk:(n,e)=>$e("installApk",{url:n,size:e}),copy:async n=>{if(Gt)return $e("copy",{text:n});try{await navigator.clipboard.writeText(n)}catch{}},paste:async()=>{if(Gt){const n=await $e("paste");return n&&n.text||""}try{return await navigator.clipboard.readText()}catch{return""}},share:n=>Gt?$e("share",{text:n}):be.copy(n),filesStatus:()=>$e("filesStatus",{},{connected:!1,account:""}),filesLogin:()=>$e("filesLogin"),filesDisconnect:()=>$e("filesDisconnect"),filesToken:()=>$e("filesToken",{},{ok:!1,error:"Μόνο στο κινητό"}),minimize:()=>$e("minimize"),shareFile:n=>$e("shareFile",n,{error:"Μόνο στο κινητό"}),refreshWidgets:()=>$e("refreshWidgets")};function Xi(n,e){Gt&&Gt.addListener(n,e)}const Zv="1.4.0",uk="https://raw.githubusercontent.com/cursing/techmate-app-releases/main/latest.json",eb=ra.isNativePlatform(),dm=(n,e)=>{const t=String(n).split(".").map(Number),s=String(e).split(".").map(Number);for(let i=0;i<3;i++){const r=(t[i]||0)-(s[i]||0);if(r)return r}return 0},Be={state:"idle",latest:null,pct:0,err:"",needApk:!1,checkedAt:0};let tb=()=>{};function dk(n){tb=n}const Bt=n=>{Object.assign(Be,n),tb()};function hk(){eb&&(aa.notifyAppReady().catch(()=>{}),aa.addListener("download",n=>{Be.state==="downloading"&&Bt({pct:Math.round(n.percent||0)})}),Xi("apk",n=>{Be.state==="downloading"&&Bt({pct:n&&n.pct||0})}),_u(),document.addEventListener("visibilitychange",()=>{!document.hidden&&Date.now()-Be.checkedAt>30*6e4&&_u()}))}async function _u(n){if(!eb){n&&Bt({state:"none"});return}if(Be.state!=="downloading"){n&&Bt({state:"checking",err:""});try{const e=await fetch(uk+"?t="+Date.now(),{cache:"no-store"});if(!e.ok)throw new Error("HTTP "+e.status);const t=await e.json();if(Be.checkedAt=Date.now(),!t.version||dm(t.version,Zv)<=0)return Bt({state:n?"none":"idle",latest:null});let s="0";try{s=(await aa.getBuiltinVersion()).version||"0"}catch{}Bt({state:"available",latest:t,needApk:!!t.minNative&&dm(s,t.minNative)<0,err:""})}catch{Bt({state:n?"error":"idle",err:n?"Δεν μπόρεσα να ελέγξω για ενημέρωση. Έλεγξε τη σύνδεση.":""})}}}async function fk(){const n=Be.latest;if(!(!n||Be.state==="downloading")){if(Be.needApk){Bt({state:"downloading",pct:0,err:""});const e=await be.installApk(n.apk,n.apkSize||0);Bt({state:"available",err:e&&e.error?e.error:""});return}Bt({state:"downloading",pct:0,err:""});try{const e=await aa.download({url:n.zip,version:n.version,checksum:n.sha256||""});await aa.set(e)}catch(e){Bt({state:"available",err:"Η λήψη απέτυχε: "+(e&&(e.message||e.code)||"άγνωστο σφάλμα")})}}}const pk=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),wu=n=>pk.format(Math.round((n||0)*100)/100),hm=n=>n<10?"0"+n:""+n,ye=()=>{const n=new Date;return n.getFullYear()+"-"+hm(n.getMonth()+1)+"-"+hm(n.getDate())},mk=n=>(n=k(n,24),[24,13,6,0].includes(n)?n:24),Fd=()=>{const n=Mi();return n&&(A.st.roles&&A.st.roles.users||{})[n.uid]||null},Ie=()=>{const n=Fd();return!!(n&&n.role==="team")},Kt=()=>{const n=Fd();return n&&n.empId||""},ts=()=>{const n=Mi();if(!n)return null;const e=Fd();return{uid:n.uid,name:e?e.name||"Υπάλληλος":"Διαχειριστής"}},Ud=n=>!Ie()||!!(n&&n.by&&Mi()&&n.by.uid===Mi().uid),Eo={pending:"Σε αναμονή απάντησης",accepted:"Έγινε δεκτή, προς εγκατάσταση",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"},Sl=(n,e,t)=>Ge("qlog",{id:ze(),qid:n.id||"",number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:e,text:t}),nb=n=>A.ldocs.find(e=>e.kind==="sale"&&(e.qid===n.id||!e.qid&&n.number&&e.number===n.number&&Me(e.party)===Me(n.customer&&n.customer.name)))||null,fm=n=>!(n&&n.war&&n.war.on===!1),gk=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(k(e.m,0))):k(ne().warrantyMonths,24)};function yk(n,e){let t=0,s=0,i=0;return A.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(a=>{a.pid===n&&(t+=k(a.qty))})}),A.smoves.forEach(r=>{r.pid===n&&(t+=k(r.qty))}),A.quotes.forEach(r=>{if(r.id===e)return;const a=dt(r);(r.lines||[]).forEach(o=>{if(o.pid!==n||o.src!=="stock")return;const l=k(o.qty);a==="done"?r.noStock||(s+=l):a==="accepted"&&(i+=l)})}),q(t-s-i)}function vk(n,e){const t=[],s=nb(n);if(e==="pending"||e==="rejected"?s&&s.qid===n.id&&s.note==="Από προσφορά "+(n.number||"")&&xc(s.id)===0&&t.push("Θα αφαιρεθεί το παραστατικό πώλησης που είχε δημιουργηθεί αυτόματα."):!s&&ne()&&ne().autoSale!==!1&&t.push("Θα δημιουργηθεί παραστατικό πώλησης "+wu(sb(n).gross)+" στα Λογιστικά."),e==="done"&&!n.install&&t.push("Θα καταχωρηθεί ως εγκατάσταση με σημερινή ημερομηνία."),(e==="accepted"||e==="done")&&n.gid){const i=A.quotes.filter(r=>r.gid===n.gid&&r.id!==n.id&&dt(r)==="pending").length;i&&t.push("Οι "+i+" άλλες εναλλακτικές θα μπουν ως «Απορρίφθηκε».")}return t}function sb(n){const e=n.vatMode==="off"?0:mk(ne().vat),t=Md(n),s=q(t*e/100);return{rate:e,net:t,vat:s,gross:q(t+s)}}function bk(n,e){const t=A.quotes.find(o=>o.id===n);if(!t||dt(t)===e)return{ok:!1};if(!ne())return{ok:!1,msg:"Δεν έχουν φορτώσει οι ρυθμίσεις. Περίμενε λίγο ή έλεγξε τη σύνδεση."};const s=Ce(t);Sl(s,"status",Eo[dt(s)]+" → "+Eo[e]),e==="done"&&!s.install&&(s.install={date:ye(),months:fm(s)?gk(s):0,serials:"",nw:!fm(s)}),s.status=e,s.statusDate=ye();const i=[];e==="accepted"&&(s.lines||[]).forEach(o=>{if(o.pid&&o.src==="stock"&&k(o.qty)>yk(o.pid,s.id)){const l=A.products.find(u=>u.id===o.pid);i.push(l?l.model:o.desc)}});const r=[],a=nb(s);if(e==="pending"||e==="rejected")a&&a.qid===s.id&&a.note==="Από προσφορά "+(s.number||"")&&xc(a.id)===0&&(Hv("ldocs",a.id),r.push("Αφαιρέθηκε το αυτόματο παραστατικό πώλησης."));else if(!a&&ne().autoSale!==!1){const o=sb(s),l={id:ze(),ts:Date.now(),kind:"sale",date:ye(),party:s.customer&&s.customer.name||"Πελάτης",number:s.number||"",cat:"",net:o.net,vat:o.vat,gross:o.gross,rate:o.rate,note:"Από προσφορά "+(s.number||""),items:[],qid:s.id};Ge("ldocs",l),A.lpays.forEach(u=>{u.qid===s.id&&!u.docId&&Bs("lpays",u.id,{docId:l.id,party:l.party||u.party})}),Sl(s,"edit","Δημιουργήθηκε αυτόματα παραστατικό πώλησης ("+wu(o.gross)+")."),r.push("Δημιουργήθηκε παραστατικό πώλησης "+wu(o.gross)+" στα Λογιστικά.")}return s.gid&&(e==="accepted"||e==="done")&&A.quotes.filter(o=>o.gid===s.gid&&o.id!==s.id&&dt(o)==="pending").forEach(o=>{const l=Ce(o);l.status="rejected",l.statusDate=ye(),Sl(l,"status","Σε αναμονή → Απορρίφθηκε (έγινε δεκτή η εναλλακτική "+(s.number||"")+")"),Ge("quotes",l)}),Ge("quotes",s),i.length&&r.push("Δεν επαρκεί το απόθεμα για: "+i.join(", ")+"."),{ok:!0,msg:["Η κατάσταση άλλαξε: "+Eo[e]+"."].concat(r).join(" ")}}function _k(n,e){const t=String(e.name||"").trim();if(!t)return{msg:"Γράψε όνομα πελάτη."};const s=Me(t),i=un(),r=n&&i.find(u=>u.k===n);if((!n||n!==s)&&i.some(u=>u.k===s))return{msg:"Υπάρχει ήδη πελάτης «"+t+"». Άνοιξε τον φάκελό του."};const a=n&&A.custs.find(u=>Me(u.name)===n),o=a?Ce(a):{id:ze(),ts:Date.now()},l=u=>String(e[u]||"").trim();return Object.assign(o,{name:t,phone:l("phone"),email:l("email"),afm:l("afm"),address:l("address"),notes:l("notes"),upd:Date.now()}),Ge("custs",o),n&&n!==s&&r&&(r.quotes.concat(r.mins).forEach(u=>{const h=Ce(u);h.customer=Object.assign({},h.customer||{},{name:t}),Ge("quotes",h)}),A.ldocs.forEach(u=>{u.kind==="sale"&&Me(u.party)===n&&Bs("ldocs",u.id,{party:t})}),A.lpays.forEach(u=>{u.dir==="in"&&Me(u.party)===n&&Bs("lpays",u.id,{party:t})})),{ok:!0,k:s}}const Xe=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),wk=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),fe=n=>wk.format(Math.round((n||0)*100)/100),ib=n=>String(q(n)).replace(".",","),_i=n=>k(String(n).replace(",","."),NaN),ca=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},pm=n=>n<10?"0"+n:""+n,ii=n=>n.getFullYear()+"-"+pm(n.getMonth()+1)+"-"+pm(n.getDate()),rb=()=>A.st.books||{},Ik=n=>(n=k(n,24),[24,13,6,0].includes(n)?n:24);let la="month";try{la=localStorage.getItem("tm_period")||"month"}catch{}const Ek=[["month","Μήνας"],["prevmonth","Προηγ. μήνας"],["quarter","Τρίμηνο"],["year","Έτος"],["all","Όλα"]];function ab(){const n=new Date,e=n.getFullYear(),t=n.getMonth();switch(la){case"month":return[ii(new Date(e,t,1)),ii(new Date(e,t+1,0))];case"prevmonth":return[ii(new Date(e,t-1,1)),ii(new Date(e,t,0))];case"quarter":{const s=Math.floor(t/3)*3;return[ii(new Date(e,s,1)),ii(new Date(e,s+3,0))]}case"year":return[e+"-01-01",e+"-12-31"];default:return["",""]}}const Ss=n=>{const e=ab();return(!e[0]||n>=e[0])&&(!e[1]||n<=e[1])},Tk=()=>{const n=ab();return!n[0]&&!n[1]?"Όλες οι κινήσεις":ca(n[0])+" έως "+ca(n[1])};function ob(n){let e=0,t=0;return A.wdays.forEach(s=>{s.empId===n&&(e+=k(s.amount))}),A.wpays.forEach(s=>{s.empId===n&&(t+=k(s.amount))}),{earned:q(e),paid:q(t),bal:q(e-t)}}function Vc(){const n={},e={},t=(i,r)=>{const a=Me(r)||"—";return i[a]||(i[a]={name:(r||"").trim()||"Χωρίς όνομα",inv:0,paid:0})};A.ldocs.forEach(i=>{t(i.kind==="sale"?e:n,i.party).inv+=k(i.gross)}),A.lpays.forEach(i=>{t(i.dir==="in"?e:n,i.party).paid+=k(i.amount)});const s=i=>Object.values(i).map(r=>(r.inv=q(r.inv),r.paid=q(r.paid),r.bal=q(r.inv-r.paid),r)).sort((r,a)=>a.bal-r.bal);return{sup:s(n),cus:s(e)}}function Ak(){const n={sNet:0,sVat:0,pNet:0,pVat:0,inBank:0,inCash:0,outBank:0,outCash:0,wages:0,cats:{}};A.ldocs.forEach(i=>{if(!(i.opening||!Ss(i.date)))if(i.kind==="sale")n.sNet+=k(i.net),n.sVat+=k(i.vat);else{n.pNet+=k(i.net),n.pVat+=k(i.vat);const r=i.cat||"Χωρίς κατηγορία";n.cats[r]=(n.cats[r]||0)+k(i.net)}}),A.lpays.forEach(i=>{Ss(i.date)&&(i.dir==="in"?i.method==="bank"?n.inBank+=k(i.amount):n.inCash+=k(i.amount):i.method==="bank"?n.outBank+=k(i.amount):n.outCash+=k(i.amount))}),A.wdays.forEach(i=>{Ss(i.date)&&(n.wages+=k(i.amount))}),A.wpays.forEach(i=>{Ss(i.date)&&(i.method==="bank"?n.outBank+=k(i.amount):n.outCash+=k(i.amount))}),Object.keys(n).forEach(i=>{typeof n[i]=="number"&&(n[i]=q(n[i]))}),n.vatDue=q(n.sVat-n.pVat),n.profit=q(n.sNet-n.pNet-n.wages);let e=k(rb().opening,0),t=0;A.lpays.forEach(i=>{const r=i.dir==="in"?k(i.amount):-k(i.amount);i.method==="bank"?e+=r:t+=r}),A.wpays.forEach(i=>{i.method==="bank"?e-=k(i.amount):t-=k(i.amount)}),n.bank=q(e),n.cash=q(t),n.rcvAll=q(n.inBank+n.inCash),n.nRcv=A.lpays.filter(i=>i.dir==="in"&&Ss(i.date)).length;const s=Vc();return n.owe=0,n.due=0,n.nOwe=0,n.nDue=0,n.wOwe=0,n.nW=0,s.sup.forEach(i=>{i.bal>.004&&(n.owe+=i.bal,n.nOwe++)}),s.cus.forEach(i=>{i.bal>.004&&(n.due+=i.bal,n.nDue++)}),A.emps.forEach(i=>{const r=ob(i.id).bal;r>.004&&(n.wOwe+=r,n.nW++)}),n.owe=q(n.owe),n.due=q(n.due),n.wOwe=q(n.wOwe),n}function Ca(n){const e=xc(n.id),t=q(k(n.gross)-e);return k(n.gross)!==0&&t<=.004?{k:"paid",t:n.kind==="sale"?"Εισπράχθηκε":"Πληρώθηκε",rem:0}:e>0?{k:"part",t:"Μερικώς",rem:t}:{k:"open",t:n.kind==="sale"?"Δεν εισπράχθηκε":"Ανεξόφλητο",rem:t}}const Sk=(n,e)=>{const t=e==="in"?"sale":"purchase",s=Me(n);return A.ldocs.filter(i=>i.kind===t&&(!s||Me(i.party)===s)&&Ca(i).k!=="paid").sort((i,r)=>i.date<r.date?1:-1)},cb=[["sum","Σύνοψη"],["docs","Παραστατικά"],["pays","Πληρωμές"],["bal","Υπόλοιπα"]];let To="all",ge=null;const qd=()=>!!ge;function kk(){ge=null}const so=(n,e,t="")=>`<div class="kpi"><b class="${t}">${n}</b><span>${e}</span></div>`,Rk={paid:"p-ok",part:"p-w",open:"p-b"},Pk=(n,e)=>`<div class="chips">${cb.map(([t,s])=>`<a href="#/books/${t}" class="chip${t===n?" on":""}">${s}</a>`).join("")}</div>
  ${n==="bal"?"":`<div class="chips">${Ek.map(([t,s])=>`<button data-bper="${t}" class="${t===la?"on":""}">${s}</button>`).join("")}</div><div class="plabel">${Tk()}</div>`}${e?"":'<div class="upd">Φόρτωση…</div>'}`;function Ck(){const n=Ak(),e=Object.entries(n.cats).sort((t,s)=>s[1]-t[1]);return`<div class="kpis">${so(fe(n.sNet),"Έσοδα (καθαρά)","ok")}${so(fe(n.pNet),"Αγορές και έξοδα (καθαρά)","bad")}${so(fe(n.wages),"Μεροκάματα")}${so(fe(n.profit),"Κέρδος περιόδου",n.profit<0?"bad":"")}</div>
  ${n.sVat||n.pVat?`<div class="h">ΦΠΑ</div><div class="card"><div class="tot"><span>ΦΠΑ πωλήσεων</span><span>${fe(n.sVat)}</span></div><div class="tot"><span>ΦΠΑ αγορών</span><span>${fe(n.pVat)}</span></div>
    <div class="tot big"><span>${n.vatDue>=0?"ΦΠΑ προς απόδοση":"ΦΠΑ πιστωτικό"}</span><span>${fe(Math.abs(n.vatDue))}</span></div></div>`:""}
  <div class="h">Χρήματα</div><div class="card"><div class="tot"><span>Εισπράξεις περιόδου${n.nRcv?" ("+n.nRcv+")":""}</span><span>${fe(n.rcvAll)}</span></div>
    <div class="tot"><span>· τράπεζα ${fe(n.inBank)} · μετρητά ${fe(n.inCash)}</span><span></span></div>
    <div class="tot"><span>Πληρωμές περιόδου</span><span>${fe(q(n.outBank+n.outCash))}</span></div>
    <div class="tot big"><span>Τράπεζα σήμερα</span><span>${fe(n.bank)}</span></div><div class="tot big"><span>Μετρητά στο ταμείο</span><span>${fe(n.cash)}</span></div></div>
  <div class="h">Υπόλοιπα</div><div class="card">
    <a class="row" href="#/books/bal"><div class="av">👥</div><div class="t"><b>Πελάτες μου χρωστούν</b><span>${n.nDue} πελάτες</span></div><span class="amt">${fe(n.due)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">🏭</div><div class="t"><b>Χρωστάω σε προμηθευτές</b><span>${n.nOwe} προμηθευτές</span></div><span class="amt">${fe(n.owe)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">👷</div><div class="t"><b>Μεροκάματα που χρωστάω</b><span>${n.nW} υπάλληλοι</span></div><span class="amt">${fe(n.wOwe)}</span></a></div>
  ${e.length?`<div class="h">Έξοδα ανά κατηγορία</div><div class="card">${e.map(([t,s])=>`<div class="tot"><span>${Xe(t)}</span><span>${fe(s)}</span></div>`).join("")}</div>`:""}`}function $k(){const n=A.ldocs.filter(e=>Ss(e.date)&&(To==="all"||e.kind===To)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0));return`<div class="chips">${[["all","Όλα"],["sale","Πωλήσεις"],["purchase","Αγορές"]].map(([e,t])=>`<button data-bdk="${e}" class="${To===e?"on":""}">${t}</button>`).join("")}</div>
  <div class="card">${n.map(e=>{const t=Ca(e);return`<div class="row"><div class="av">${e.kind==="sale"?"📤":"📥"}</div>
    <div class="t"><b>${Xe(e.party)}</b><span>${ca(e.date)}${e.number?" · "+Xe(e.number):""}${e.cat?" · "+Xe(e.cat):""}${e.opening?" · παλιό υπόλοιπο":""}</span>${e.note?`<span>${Xe(e.note)}</span>`:""}
    ${t.k!=="paid"?`<button class="lnk" data-bpay="${Xe(e.id)}">${e.kind==="sale"?"💶 Είσπραξη":"💶 Πληρωμή"} ${fe(t.rem)}</button>`:""}</div>
    <div class="r"><div class="amt">${fe(e.gross)}</div><span class="pill ${Rk[t.k]}">${t.t}</span></div></div>`}).join("")||'<div class="empty">Κανένα παραστατικό στην περίοδο</div>'}</div>`}function Dk(){return`<div class="card">${A.lpays.filter(e=>Ss(e.date)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0)).map(e=>`<div class="row"><div class="av">${e.dir==="in"?"⬇️":"⬆️"}</div>
    <div class="t"><b>${Xe(e.party)}</b><span>${ca(e.date)} · ${e.method==="bank"?"τράπεζα":"μετρητά"}${e.note?" · "+Xe(e.note):""}</span></div>
    <div class="r"><div class="amt ${e.dir==="in"?"ok":"bad"}">${e.dir==="in"?"+":"−"}${fe(e.amount)}</div></div></div>`).join("")||'<div class="empty">Καμία κίνηση στην περίοδο</div>'}</div>`}function xk(){const n=Vc(),e=(s,i,r)=>s.map(a=>`<div class="row"><div class="t"><b>${Xe(a.name)}</b><span>τιμολογημένα ${fe(a.inv)} · πληρωμένα ${fe(a.paid)}</span>
    ${a.bal>.004?`<button class="lnk" data-bnew="${i}" data-party="${Xe(a.name)}">${i==="in"?"💶 Νέα είσπραξη":"💶 Νέα πληρωμή"}</button>`:""}</div>
    <div class="r"><span class="pill ${a.bal>.004?"p-b":a.bal<-.004?"p-w":"p-ok"}">${a.bal>.004?fe(a.bal):a.bal<-.004?"πιστωτικό "+fe(-a.bal):"εξοφλημένο"}</span></div></div>`).join("")||`<div class="empty">${r}</div>`,t=A.emps.slice().sort((s,i)=>String(s.name).localeCompare(i.name,"el"));return`<div class="h">Πελάτες</div><div class="card">${e(n.cus,"in","Δεν υπάρχουν πελάτες με παραστατικά")}</div>
  <div class="h">Προμηθευτές</div><div class="card">${e(n.sup,"out","Δεν υπάρχουν προμηθευτές")}</div>
  ${t.length?`<div class="h">Υπάλληλοι</div><div class="card">${t.map(s=>{const i=ob(s.id);return`<div class="row"><div class="t"><b>${Xe(s.name)}</b><span>δεδουλευμένα ${fe(i.earned)} · πληρωμένα ${fe(i.paid)}</span></div>
    <div class="r"><span class="pill ${i.bal>.004?"p-b":i.bal<-.004?"p-w":"p-ok"}">${i.bal>.004?fe(i.bal):i.bal<-.004?"προπληρωμή "+fe(-i.bal):"τακτοποιημένο"}</span></div></div>`}).join("")}</div>`:""}`}const Xt=(n,e,t="")=>`<label class="f">${e}<input class="in" data-bf="${n}" value="${Xe(ge.v[n]??"")}" ${t}></label>`,qr=(n,e)=>`<div class="seg">${e.map(([t,s])=>`<button data-bseg="${n}" data-v="${t}" class="${ge.v[n]===t?"on":""}">${s}</button>`).join("")}</div>`;function Nk(){const n=ge.v,e=Sk(n.party,n.dir),t=Vc();return n.docId&&!e.some(s=>s.id===n.docId)&&(n.docId=""),`<div class="card pad">${qr("dir",[["in","Είσπραξη από πελάτη"],["out","Πληρωμή σε προμηθευτή"]])}
    ${Xt("date","Ημερομηνία",'type="date"')}${Xt("party",n.dir==="in"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.dir==="in"?t.cus:t.sup).map(s=>`<option value="${Xe(s.name)}">`).join("")}</datalist>
    <label class="f">Παραστατικό<select class="in" data-bf="docId"><option value="">Χωρίς σύνδεση με παραστατικό</option>${e.map(s=>`<option value="${Xe(s.id)}" ${s.id===n.docId?"selected":""}>${ca(s.date)} · ${Xe(s.party)}${s.number?" · "+Xe(s.number):""} · υπόλοιπο ${fe(Ca(s).rem)}</option>`).join("")}</select></label>
    ${Xt("amount","Ποσό €",'inputmode="decimal"')}${qr("method",[["bank","Τράπεζα"],["cash","Μετρητά"]])}${Xt("note","Σημείωση")}</div>`}function Bd(n){const e=_i(n.amount),t=k(n.rate,24);let s,i,r;return n.mode==="net"?(s=q(e),i=q(s*t/100),r=q(s+i)):(r=q(e),s=q(r/(1+t/100)),i=q(r-s)),{net:s,vat:i,gross:r,rate:t}}function Vk(){const n=ge.v,e=Vc(),t=isNaN(_i(n.amount))?null:Bd(n);return`<div class="card pad">${qr("kind",[["purchase","Αγορά / έξοδο"],["sale","Πώληση"]])}
    ${Xt("date","Ημερομηνία",'type="date"')}${Xt("party",n.kind==="sale"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.kind==="sale"?e.cus:e.sup).map(s=>`<option value="${Xe(s.name)}">`).join("")}</datalist>
    ${Xt("number","Αριθμός παραστατικού")}
    ${n.kind==="purchase"?`${Xt("cat","Κατηγορία εξόδου",'list="bcl" autocomplete="off"')}<datalist id="bcl">${(rb().costCats||[]).map(s=>`<option value="${Xe(s)}">`).join("")}</datalist>`:""}
    ${Xt("amount","Ποσό €",'inputmode="decimal"')}${qr("mode",[["gross","Το ποσό είναι με ΦΠΑ"],["net","Το ποσό είναι χωρίς ΦΠΑ"]])}
    <div class="f">Συντελεστής ΦΠΑ</div>${qr("rate",[["24","24%"],["13","13%"],["6","6%"],["0","0%"]])}
    <div id="bprev" class="plabel">${t?`Καθαρό ${fe(t.net)} · ΦΠΑ ${fe(t.vat)} · Σύνολο ${fe(t.gross)}`:""}</div>${Xt("note","Σημείωση")}</div>`}function Ok(n,e){if(n==="newpay"||n==="newdoc"){const s=n==="newpay"?"pay":"doc";return(!ge||ge.kind!==s)&&(ge={kind:s,v:s==="pay"?{dir:"in",date:ye(),party:"",docId:"",amount:"",method:"bank",note:"",...Xo||{}}:{kind:"purchase",date:ye(),party:"",number:"",cat:"",amount:"",mode:"gross",rate:String(Ik(ne()&&ne().vat)),note:""}}),Xo=null,`<header class="top"><a class="ib" data-bact="cancel">←</a><h1>${s==="pay"?"Νέα κίνηση":"Νέο παραστατικό"}</h1></header><main class="body ed">${s==="pay"?Nk():Vk()}
      ${ge.msg?`<div class="err box">${Xe(ge.msg)}</div>`:""}</main><div class="bar"><button class="btn b2" data-bact="cancel">Άκυρο</button><button class="btn b1" data-bact="save">💾 Αποθήκευση</button></div>`}ge=null;const t=cb.some(([s])=>s===n)?n:"sum";return`<header class="top"><a class="ib" href="#/menu">←</a><h1>Λογιστικά</h1></header><main class="body">${Pk(t,e)}${{sum:Ck,docs:$k,pays:Dk,bal:xk}[t]()}</main>
    <div class="fab2"><a class="btn b2" href="#/books/newdoc">＋ Παραστατικό</a><a class="btn b1" href="#/books/newpay">＋ Είσπραξη / πληρωμή</a></div>`}let Xo=null;function Mk(){const n=ge.v;if(!n.date)return"Βάλε ημερομηνία.";if(ge.kind==="pay"){let s=String(n.party||"").trim();const i=n.docId&&A.ldocs.find(r=>r.id===n.docId);return i&&(s=i.party),s?!String(n.amount).trim()||isNaN(_i(n.amount))?"Βάλε ποσό.":(Ge("lpays",{dir:n.dir,date:n.date,party:s,docId:n.docId||"",amount:q(_i(n.amount)),method:n.method,note:String(n.note||"").trim(),id:ze(),ts:Date.now()}),""):"Βάλε "+(n.dir==="in"?"πελάτη":"προμηθευτή")+"."}const e=String(n.party||"").trim();if(!e)return"Βάλε "+(n.kind==="sale"?"πελάτη":"προμηθευτή")+".";if(!String(n.amount).trim()||isNaN(_i(n.amount)))return"Βάλε ποσό.";const t=Bd(n);return Ge("ldocs",{kind:n.kind,date:n.date,party:e,number:String(n.number||"").trim(),cat:n.kind==="purchase"?String(n.cat||"").trim():"",net:t.net,vat:t.vat,gross:t.gross,rate:t.rate,note:String(n.note||"").trim(),items:[],id:ze(),ts:Date.now()}),""}function Lk(n,e,t,s){const i=n.closest("[data-bper],[data-bdk],[data-bpay],[data-bnew],[data-bseg],[data-bact]");if(!i)return!1;const r=i.dataset;if(r.bper){la=r.bper;try{localStorage.setItem("tm_period",la)}catch{}}else if(r.bdk)To=r.bdk;else if(r.bpay){const a=A.ldocs.find(o=>o.id===r.bpay);return a&&(Xo={dir:a.kind==="sale"?"in":"out",party:a.party,docId:a.id,amount:ib(Ca(a).rem)}),ge=null,e("#/books/newpay"),!0}else{if(r.bnew)return Xo={dir:r.bnew,party:r.party},ge=null,e("#/books/newpay"),!0;if(r.bseg)ge.v[r.bseg]=r.v,r.bseg==="dir"&&(ge.v.docId="");else if(r.bact==="cancel"){const a=ge&&ge.kind;return ge=null,e(a==="doc"?"#/books/docs":"#/books/pays",!0),!0}else if(r.bact==="save"){const a=Mk();if(a)ge.msg=a;else{const o=ge.kind;return ge=null,s(o==="pay"?"Η κίνηση αποθηκεύτηκε.":"Το παραστατικό αποθηκεύτηκε."),e(o==="doc"?"#/books/docs":"#/books/pays",!0),!0}}}return t(),!0}function Fk(n,e){if(!ge||!n.dataset.bf)return!1;const t=n.dataset.bf;if(ge.v[t]=n.value,ge.msg="",t==="docId"){const s=A.ldocs.find(i=>i.id===n.value);s&&(ge.v.party=s.party,ge.v.amount=ib(Ca(s).rem)),e()}else if(!(t==="party"&&ge.kind==="pay")){if(t==="amount"&&ge.kind==="doc"){const s=document.getElementById("bprev");if(s){const i=isNaN(_i(n.value))?null:Bd(ge.v);s.textContent=i?`Καθαρό ${fe(i.net)} · ΦΠΑ ${fe(i.vat)} · Σύνολο ${fe(i.gross)}`:""}}}return!0}function Uk(n,e){ge&&ge.kind==="pay"&&n.dataset.bf==="party"&&e()}const Ke=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),qk=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),jt=n=>qk.format(Math.round((n||0)*100)/100),nn=n=>String(q(n)).replace(".",","),Bk=n=>k(String(n).replace(",","."),0),jk=()=>({war:{on:!0,m:null},id:null,number:null,date:null,ts:0,customer:{name:"",phone:"",email:"",afm:"",address:""},subject:"",notes:"",status:"pending",vatMode:"on",benefits:[],benShow:!0,planMarks:[],planOn:!0,gid:null,optName:"",validDays:null,payShow:!1,payIds:null,prepay:{type:"",val:0},lines:[]}),Zo=n=>n===null||typeof n!="object"?JSON.stringify(n===void 0?null:n):Array.isArray(n)?"["+n.map(Zo).join(",")+"]":"{"+Object.keys(n).sort().map(e=>JSON.stringify(e)+":"+Zo(n[e])).join(",")+"}";let se=null;const jd=()=>!!se;function Wk(){se=null}let Ao=null;function zk(n){Ao=n}function Gk(n){if(n==="new"){const s=jk();return Ao&&(Object.assign(s.customer,Ao),Ao=null),se={arg:n,q:s,base:null,pick:!1,pq:"",pcat:""}}const e=A.quotes.find(s=>s.id===n);if(!e)return null;const t=Ce(e);return t.customer=Object.assign({name:"",phone:"",email:"",afm:"",address:""},t.customer),t.lines=t.lines||[],se={arg:n,q:t,base:Zo(e),pick:!1,pq:"",pcat:""}}function Kk(n,e){return`<div class="ln-ed" data-i="${e}">
    <div class="ln-top"><input class="in" data-l="desc" value="${Ke(n.desc)}" placeholder="Περιγραφή"><button class="x" data-act="del" aria-label="Διαγραφή γραμμής">✕</button></div>
    <div class="ln-bot">
      <div class="step"><button data-act="dec">−</button><input class="in" data-l="qty" inputmode="decimal" value="${Ke(nn(k(n.qty)))}"><button data-act="inc">＋</button></div>
      <label>Τιμή €<input class="in" data-l="price" inputmode="decimal" value="${Ke(nn(k(n.price)))}"></label>
      <label>Έκπτ. %<input class="in" data-l="disc" inputmode="decimal" value="${Ke(nn(k(n.disc)))}"></label>
      <div class="ln-sum" data-sum>${jt(Od(n))}</div>
    </div></div>`}function lb(){const n=Jv(se.q);return`<div class="tot"><span>Καθαρό</span><span>${jt(n.sub)}</span></div>
  ${n.off?"":`<div class="tot"><span>ΦΠΑ ${nn(n.vp)}%</span><span>${jt(n.vat)}</span></div>`}
  <div class="tot big"><span>Σύνολο${n.off?" (χωρίς ΦΠΑ)":""}</span><span>${jt(n.total)}</span></div>`}function Hk(){const n=[...new Set(A.products.map(s=>s.cat).filter(Boolean))].sort((s,i)=>s.localeCompare(i,"el")),e=Me(se.pq),t=A.products.filter(s=>(!se.pcat||s.cat===se.pcat)&&(!e||Me((s.model||"")+" "+(s.desc||"")+" "+(s.cat||"")).includes(e))).sort((s,i)=>((s.cat||"")+(s.model||"")).localeCompare((i.cat||"")+(i.model||""),"el")).slice(0,80);return`<div class="sheet"><div class="sheet-in">
    <div class="sheet-h"><b>Κατάλογος</b><button class="btn b1 sm" data-act="pick-close">Τέλος</button></div>
    <input class="search" id="pq" placeholder="🔍 Αναζήτηση προϊόντος" value="${Ke(se.pq)}">
    <div class="chips"><button data-pcat="" class="${se.pcat?"":"on"}">Όλα</button>${n.map(s=>`<button data-pcat="${Ke(s)}" class="${se.pcat===s?"on":""}">${Ke(s)}</button>`).join("")}</div>
    <div class="sheet-list">${t.map(s=>{const i=se.q.lines.find(a=>a.pid===s.id),r=Yv(s.id,se.q.id);return`<button class="prow${i?" has":""}" data-pid="${Ke(s.id)}">${s.img?`<img class="pth" src="${Ke(s.img)}" alt="" loading="lazy">`:'<span class="pth ph">📦</span>'}<div class="t"><b>${Ke(s.model)}</b><span>${Ke([s.cat,s.desc].filter(Boolean).join(" · "))}${r>=1?` · 📦 ${nn(r)} στο ράφι`:""}</span></div>
      <div class="r"><div class="amt">${jt(Nc(s))}</div>${i?`<span class="pill p-ok">×${nn(k(i.qty))}</span>`:'<span class="muted">＋ προσθήκη</span>'}</div></button>`}).join("")||`<div class="empty">${A.products.length?"Δεν βρέθηκε προϊόν":"Ο κατάλογος είναι άδειος"}</div>`}</div>
  </div></div>`}function Qk(n){if((!se||se.arg!==n)&&(se=null,!Gk(n)))return null;const e=se.q,t=e.customer,s=un().map(i=>i.name).filter(i=>i&&i!=="(χωρίς όνομα)");return`<header class="top"><a class="ib" data-act="cancel">←</a><h1>${e.id?"Προσφορά #"+Ke(e.number||"—"):"Νέα προσφορά"}<span class="sm">${e.id?"Επεξεργασία":"Δεν έχει αποθηκευτεί ακόμα"}</span></h1></header>
  <main class="body ed">
    <div class="card pad">
      <label class="f">Πελάτης<input class="in" data-c="name" list="cl" value="${Ke(t.name)}" placeholder="Όνομα πελάτη" autocomplete="off"></label>
      <datalist id="cl">${s.map(i=>`<option value="${Ke(i)}">`).join("")}</datalist>
      <details><summary>Τηλέφωνο, email, ΑΦΜ, διεύθυνση</summary>
        <label class="f">Τηλέφωνο<input class="in" data-c="phone" inputmode="tel" value="${Ke(t.phone)}"></label>
        <label class="f">Email<input class="in" data-c="email" inputmode="email" value="${Ke(t.email)}"></label>
        <label class="f">ΑΦΜ<input class="in" data-c="afm" inputmode="numeric" value="${Ke(t.afm)}"></label>
        <label class="f">Διεύθυνση<input class="in" data-c="address" value="${Ke(t.address)}"></label>
      </details>
      <label class="f">Θέμα<input class="in" data-q="subject" value="${Ke(e.subject)}" placeholder="π.χ. Εγκατάσταση CCTV"></label>
    </div>
    <div class="h">Είδη (${e.lines.length})</div>
    <div class="card pad" id="lines">${e.lines.map(Kk).join("")||'<div class="empty">Πρόσθεσε είδη από τον κατάλογο ή γράψε δική σου γραμμή.</div>'}</div>
    <div class="actions"><button class="btn b1" data-act="pick">📦 Κατάλογος</button><button class="btn b2" data-act="free">＋ Γραμμή</button><button class="btn b2" data-act="work">🛠️ Εργασία</button></div>
    <div class="card pad">
      <div class="seg"><button data-vat="on" class="${e.vatMode==="off"?"":"on"}">Με ΦΠΑ</button><button data-vat="off" class="${e.vatMode==="off"?"on":""}">Χωρίς ΦΠΑ</button></div>
      <div id="tots">${lb()}</div>
    </div>
    <div class="card pad"><label class="f">Σημειώσεις<textarea class="in" data-q="notes" rows="3">${Ke(e.notes)}</textarea></label></div>
    ${se.msg?`<div class="err box">${Ke(se.msg)}</div>`:""}
  </main>
  <div class="bar"><button class="btn b2" data-act="cancel">Άκυρο</button><button class="btn b1" data-act="save">💾 ${se.force?"Αποθήκευση (αντικατάσταση)":"Αποθήκευση"}</button></div>
  ${se.pick?Hk():""}`}function Jk(n,e,t){const s=()=>{const i=n.querySelector("#tots");i&&(i.innerHTML=lb())};n.oninput=i=>{const r=i.target,a=se&&se.q;if(a){if(r.dataset.c){if(a.customer[r.dataset.c]=r.value,r.dataset.c==="name"){const o=un().find(l=>l.k===Me(r.value));if(o){let l=!1;if(["phone","email","afm","address"].forEach(u=>{!a.customer[u]&&o.info[u]&&(a.customer[u]=o.info[u],l=!0)}),l){e();const u=n.querySelector('[data-c="name"]');u.focus(),u.setSelectionRange(u.value.length,u.value.length)}}}}else if(r.dataset.q)a[r.dataset.q]=r.value;else if(r.dataset.l){const o=r.closest(".ln-ed"),l=a.lines[+o.dataset.i];if(!l)return;l[r.dataset.l]=r.dataset.l==="desc"?r.value:Bk(r.value),o.querySelector("[data-sum]").textContent=jt(Od(l)),s()}else if(r.id==="pq"){se.pq=r.value,e();const o=n.querySelector("#pq");o.focus(),o.setSelectionRange(o.value.length,o.value.length)}}},n.onclick=i=>{const r=se&&se.q;if(!r)return;const a=i.target.closest("[data-act],[data-vat],[data-pcat],[data-pid]");if(!a)return;const o=a.closest(".ln-ed"),l=o&&r.lines[+o.dataset.i],u=a.dataset.act;if(a.dataset.vat)r.vatMode=a.dataset.vat;else if(a.dataset.pcat!==void 0)se.pcat=a.dataset.pcat;else if(a.dataset.pid)Yk(a.dataset.pid);else if(u==="inc")l.qty=q(k(l.qty)+1);else if(u==="dec")l.qty=Math.max(0,q(k(l.qty)-1));else if(u==="del")r.lines.splice(+o.dataset.i,1);else if(u==="free")r.lines.push({desc:"",qty:1,price:0,disc:0,showImg:!0});else if(u==="work")r.lines.push({desc:"Εργασία / εγκατάσταση",qty:1,price:0,disc:0,showImg:!0});else if(u==="pick")se.pick=!0;else if(u==="pick-close")se.pick=!1;else if(u==="cancel"){const h=r.id;return se=null,t(h)}else if(u==="save"){const h=eR();if(h)return se=null,t(h)}if(se.msg&&u!=="save"&&(se.msg="",se.force=!1),e(),u==="free"){const h=n.querySelectorAll('[data-l="desc"]');h[h.length-1].focus()}}}function Yk(n){const e=A.products.find(s=>s.id===n);if(!e)return;const t=se.q.lines.find(s=>s.pid===n);t?t.qty=q(k(t.qty)+1):se.q.lines.push({pid:n,desc:e.model+(e.desc?" - "+e.desc:""),qty:1,price:Nc(e),disc:0,src:Yv(n,se.q.id)>=1?"stock":"supplier",showImg:!!(e.img&&e.imgPdf!==!1)})}function Xk(n,e){const t=[],s=(o,l,u)=>{String(l||"")!==String(u||"")&&t.push(o+": «"+(l||"—")+"» → «"+(u||"—")+"»")};s("Πελάτης",n.customer&&n.customer.name,e.customer&&e.customer.name),s("Θέμα",n.subject,e.subject),s("ΦΠΑ",n.vatMode==="off"?"χωρίς":"με",e.vatMode==="off"?"χωρίς":"με"),(n.notes||"")!==(e.notes||"")&&t.push("Άλλαξαν οι σημειώσεις");const i={},r={};if((n.lines||[]).forEach(o=>i[o.pid||o.desc]=o),(e.lines||[]).forEach(o=>r[o.pid||o.desc]=o),Object.keys(r).forEach(o=>{if(!i[o])t.push("Προστέθηκε: "+r[o].desc+" ×"+nn(k(r[o].qty)));else{const l=i[o],u=r[o];k(l.qty)!==k(u.qty)&&t.push(u.desc+": ποσότητα "+nn(k(l.qty))+" → "+nn(k(u.qty))),k(l.price)!==k(u.price)&&t.push(u.desc+": τιμή "+jt(k(l.price))+" → "+jt(k(u.price))),k(l.disc)!==k(u.disc)&&t.push(u.desc+": έκπτωση "+nn(k(u.disc))+"%")}}),Object.keys(i).forEach(o=>{r[o]||t.push("Αφαιρέθηκε: "+i[o].desc)}),!t.length)return"";const a=q(k(e.total)-k(n.total));return t.join("; ")+(a?" (σύνολο "+jt(k(n.total))+" → "+jt(k(e.total))+")":"")}const Zk=n=>(n=k(n,24),[24,13,6,0].includes(n)?n:24);function eR(){const n=se.q,e=ne();if(n.lines=n.lines.filter(o=>String(o.desc||"").trim()).map(o=>({...o,desc:String(o.desc).trim(),qty:k(o.qty),price:k(o.price),disc:k(o.disc)})),!n.lines.length)return se.msg="Η προσφορά δεν έχει γραμμές.",null;if(!e)return se.msg="Δεν έχουν φορτώσει οι ρυθμίσεις (αρίθμηση, ΦΠΑ). Περίμενε λίγο ή έλεγξε τη σύνδεση.",null;const t=n.id?A.quotes.find(o=>o.id===n.id):null;if(n.id&&!t)return se.msg="Η προσφορά δεν υπάρχει πια (ίσως διαγράφηκε από άλλη συσκευή).",null;if(t&&Zo(t)!==se.base&&!se.force)return se.force=!0,se.msg="Η προσφορά άλλαξε από άλλη συσκευή αφού την άνοιξες. Αν αποθηκεύσεις, οι αλλαγές εκείνες θα αντικατασταθούν. Πάτα ξανά «Αποθήκευση» για να συνεχίσεις, ή «Άκυρο».",null;let s=0;if(!n.number){const o=Math.max(1,Math.floor(k(e.next,1)));n.number=new Date().getFullYear()+"-"+String(o).padStart(3,"0"),s=o+1}n.date||(n.date=new Date().toLocaleDateString("el-GR")),n.id||(n.id=ze(),n.ts=Date.now()),n.customer.name=String(n.customer.name||"").trim(),n.total=Jv(n).total;const i=Ce(n);Ge("quotes",i),s&&KS(s);const r=(o,l)=>Ge("qlog",{id:ze(),qid:i.id,number:i.number||"",customer:i.customer.name||"",ts:Date.now(),type:o,text:l});if(!t)r("create","Νέα προσφορά, σύνολο "+jt(i.total)+", "+i.lines.length+" γραμμές.");else{const o=Xk(t,i);o&&r("edit",o)}const a=A.ldocs.find(o=>o.kind==="sale"&&(o.qid===i.id||!o.qid&&i.number&&o.number===i.number&&Me(o.party)===Me(i.customer.name)));if(a){const o=i.vatMode==="off"?0:Zk(e.vat),l=Md(i),u=q(l*o/100),h=q(l+u),p=i.customer.name||a.party;a.qid===i.id&&a.net===l&&a.vat===u&&a.gross===h&&a.rate===o&&a.party===p&&a.number===(i.number||"")||Bs("ldocs",a.id,{qid:i.id,net:l,vat:u,gross:h,rate:o,party:p,number:i.number||""})}return i.id}const oe=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),mm=n=>n<10?"0"+n:""+n,Wd=n=>n.getFullYear()+"-"+mm(n.getMonth()+1)+"-"+mm(n.getDate()),Qs=n=>new Date(n+"T12:00:00"),Vt=(n,e)=>{const t=Qs(n);return t.setDate(t.getDate()+e),Wd(t)},ua=(n,e)=>{const t=Qs(n),s=t.getDate();t.setDate(1),t.setMonth(t.getMonth()+e);const i=new Date(t.getFullYear(),t.getMonth()+1,0).getDate();return t.setDate(Math.min(s,i)),Wd(t)},Zi="el-GR",ub=n=>n.charAt(0).toUpperCase()+n.slice(1),Oc=n=>ub(Qs(n).toLocaleDateString(Zi,{weekday:"long",day:"numeric",month:"long",year:"numeric"})),ec=n=>Qs(n).toLocaleDateString(Zi,{weekday:"short",day:"numeric",month:"numeric"}),tR=n=>ub(Qs(n).toLocaleDateString(Zi,{month:"long",year:"numeric"})),db=n=>{const e=ye();return n===e?"Σήμερα":n===Vt(e,1)?"Αύριο":n===Vt(e,-1)?"Χθες":ec(n)},wi=[["Μπλε TechMate","#1F4E79"],["Γαλάζιο","#0288D1"],["Τιρκουάζ","#00897B"],["Πράσινο","#2E7D32"],["Λαχανί","#7CB342"],["Κίτρινο","#F2A900"],["Πορτοκαλί","#EF6C00"],["Κόκκινο","#D32F2F"],["Ροζ","#C2185B"],["Μωβ","#7B1FA2"],["Λουλακί","#3949AB"],["Γκρι","#546E7A"]],ks=n=>(wi[n]||wi[0])[1],hb=()=>{try{return JSON.parse(Ze().empClr||"{}")}catch{return{}}},Mc=n=>{const e=hb()[n];return typeof e=="number"?e:-1};function fb(n){if(typeof n.clr=="number"&&n.clr>=0)return ks(n.clr);for(const e of n.emps||[]){const t=Mc(e);if(t>=0)return ks(t)}return n.kind==="due"?ks(6):ks(k(Ze().accent,0))}const zd=-1,pb=[0,15,30,60,120,1440,2880,10080,zd],tc=n=>String(n||"").split(",").map(e=>parseInt(e,10)).filter(e=>!isNaN(e));function Gd(n){return Array.isArray(n.rems)?n.rems.map(Number).filter(e=>!isNaN(e)):{none:[],eve:[zd],15:[15],30:[30],60:[60],120:[120]}[n.remOff||"at"]||[0]}function Iu(n){return n===0?"Στην ώρα":n===zd?"Το προηγ. βράδυ":n<60?n+"΄ πριν":n===60?"1 ώρα πριν":n<1440?n/60+" ώρες πριν":n===1440?"1 μέρα πριν":n===10080?"1 εβδομάδα πριν":n/1440+" μέρες πριν"}const nR=n=>n.length?n.includes(0)?"at":{[-1]:"eve",15:"15",30:"30",60:"60",120:"120"}[n[0]]||"at":"none",Eu={"":"Καμία",w:"Κάθε εβδομάδα",m:"Κάθε μήνα",y:"Κάθε χρόνο"},sR=n=>!Ie()||!!Kt()&&(n.emps||[]).includes(Kt()),Tu=()=>A.tasks.filter(n=>!n.del&&sR(n)),Kd=n=>!Ie()||(n.emps||[]).includes(Kt()),Hd=n=>{const e=A.emps.find(t=>t.id===n);return e?e.name:""},da=()=>A.emps.filter(n=>n.name&&String(n.name).trim()).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),Zi));function Lc(){const n=A.st.main||{},e=n.msDefList||"",t=n.msToolList||"",s=n.msListNames||{},i=[...new Set((Array.isArray(n.msLists)?n.msLists:[]).filter(r=>r!==t).concat(e?[e]:[]))];return{def:e,lists:i.map(r=>({id:r,name:s[r]||"Λίστα"})).sort((r,a)=>(r.id===e?0:1)-(a.id===e?0:1))}}function Qd(n,e){const t=String(e.title||"").trim();if(!t)return{msg:"Γράψε τίτλο πρώτα."};const s=n&&A.tasks.find(m=>m.id===n),i=!s;if(n&&!s)return{msg:"Η εργασία δεν υπάρχει πια (ίσως σβήστηκε)."};if(!i&&!Ud(s))return{msg:"Μπορείς να αλλάξεις μόνο εργασίες που έγραψες εσύ."};if(Ie()&&!Kt())return{msg:"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει."};const r=e.date||"",a=r&&e.time||"",o=Date.now(),l=!!(s&&s.done),u=(e.rems||[]).map(Number).filter((m,w,E)=>E.indexOf(m)===w).sort((m,w)=>w-m),h=i?{id:ze(),ts:o,msId:"",msList:e.msList||"",rem:""}:{id:s.id};if(i){const m=ts();m&&(h.by=m)}!i&&(s.date!==r||(s.time||"")!==a||JSON.stringify(Gd(s).slice().sort((m,w)=>w-m))!==JSON.stringify(u))&&(h.rem="");let p=(e.emps||[]).slice();if(Ie()&&(p=(i?e.emps||[]:s.emps||[]).slice(),p.includes(Kt())||p.push(Kt())),Object.assign(h,{title:t,date:r,time:a,emps:p,cust:String(e.cust||"").trim(),tel:String(e.tel||"").trim(),addr:String(e.addr||"").trim(),notes:String(e.notes||"").trim(),done:!!e.done,remOff:nR(u),rems:u,quoteId:e.quoteId||"",chk:(e.chk||[]).map(m=>({tx:String(m.tx||"").trim(),dn:!!m.dn})).filter(m=>m.tx),kind:e.kind||"",rep:e.rep||"",clr:typeof e.clr=="number"?e.clr:-1,upd:o,dirty:!0,del:!1}),h.done&&!l){h.doneAt=o;const m=ts();m&&(h.doneBy=m.name)}else h.done||(h.doneAt=void 0,h.doneBy=void 0);if(i){if(delete h.doneAt,delete h.doneBy,h.done){h.doneAt=o;const m=ts();m&&(h.doneBy=m.name)}Ge("tasks",h)}else zt("tasks",h.id,h);return h.done&&!l&&mb(A.tasks.find(m=>m.id===h.id)||h),{ok:!0,id:h.id}}function kl(n,e){if(!n||!Kd(n))return;const t=Date.now(),s=ts(),i=!!n.done;Bs("tasks",n.id,e?{done:!0,upd:t,dirty:!0,doneAt:t,doneBy:s&&s.name||""}:{done:!1,upd:t,dirty:!0,doneAt:void 0,doneBy:void 0}),e&&!i&&mb(n)}function iR(n,e){Bs("tasks",n.id,{chk:e.map(t=>({tx:t.tx,dn:!!t.dn})),upd:Date.now(),dirty:!0})}function mb(n){if(!n.date||!n.rep)return;const e=n.rep==="w"?Vt(n.date,7):n.rep==="m"?ua(n.date,1):n.rep==="y"?ua(n.date,12):"";e&&Qd(null,{...n,rems:Gd(n),date:e,done:!1,chk:(n.chk||[]).map(t=>({tx:t.tx,dn:!1})),msList:n.msList||""})}function rR(n){return Ud(n)?(n.msId?Bs("tasks",n.id,{del:!0,dirty:!0,upd:Date.now()}):Hv("tasks",n.id),{ok:!0}):{msg:"Μπορείς να σβήσεις μόνο εργασίες που έγραψες εσύ."}}const Y={view:"",sel:"",emp:"",q:"",srch:!1,list:"myday",showDone:!1,quick:"",preset:null,ms:null,emSel:""},Ui=()=>Y.sel||(Y.sel=ye());let z=null;const Jd=()=>!!z,aR=()=>{z=null};function Ii(n){Y.preset=n}const ha=(n,e)=>n.done-e.done||(n.time||"99:99").localeCompare(e.time||"99:99")||String(n.title||"").localeCompare(String(e.title||""),Zi),oR=(n,e)=>(n.date?0:1)-(e.date?0:1)||(n.date||"").localeCompare(e.date||"")||(n.time||"99").localeCompare(e.time||"99")||(e.upd||0)-(n.upd||0),cR=(n,e)=>!e||[n.title,n.cust,n.addr,n.notes,n.tel].some(t=>String(t||"").toLowerCase().includes(e))||(n.chk||[]).some(t=>String(t.tx||"").toLowerCase().includes(e));function gm(n){const e=Y.q.trim().toLowerCase();return Tu().filter(t=>(n||Ze().showDone||!t.done)&&(!Y.emp||(t.emps||[]).includes(Y.emp))&&cR(t,e))}function ns(n,e){const t=!n.done&&n.date&&n.date<ye(),s=t?"var(--bad)":fb(n),i=[e&&n.date?t?"Καθυστέρηση · "+ec(n.date):db(n.date):"",n.cust,n.addr].filter(Boolean).join(" · "),r=(n.emps||[]).map(Hd).filter(Boolean),a=(n.chk||[]).length?`<em>☑ ${(n.chk||[]).filter(u=>u.dn).length}/${n.chk.length}</em>`:"",o=[n.kind==="due"?"<em>💶 Λήξη</em>":"",n.rep?`<em>🔁 ${oe(Eu[n.rep]||"")}</em>`:"",a,!Ie()&&r.length?`<em>👷 ${oe(r.join(", "))}</em>`:""].join(""),l=Kd(n);return`<div class="tc${n.done?" dn":""}${Ze().compact?" cp":""}" style="--c:${s}">
    <button class="tick${n.done?" on":""}" ${l?`data-tk="${oe(n.id)}"`:"disabled"} aria-label="Ολοκληρώθηκε">${n.done?"✓":""}</button>
    <a class="tcb" href="#/t/${encodeURIComponent(n.id)}"><div class="t"><b>${n.kind==="due"?"💶 ":""}${oe(n.title||"(χωρίς τίτλο)")}</b>${i?`<span>${oe(i)}</span>`:""}${o&&!Ze().compact?`<div class="tags">${o}</div>`:""}</div>
    <div class="tcr" style="color:${s}">${oe(n.time||"")}</div></a></div>`}const Rl=(n,e,t,s="")=>e.length?`<div class="h ${s}">${n}</div><div class="card">${e.map(i=>ns(i,t)).join("")}</div>`:"";function lR(n){const e=Ui(),t=Qs(e.slice(0,8)+"01"),s=!!Ze().sun,i=(t.getDay()+(s?0:6))%7,r=Wd(new Date(t.getFullYear(),t.getMonth(),1-i)),a=s?["Κυρ","Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ"]:["Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ","Κυρ"],o=ye(),l=e.slice(0,7);let u="";for(let p=0;p<6;p++){const m=Vt(r,p*7);if(p===5&&m.slice(0,7)!==l)break;for(let w=0;w<7;w++){const E=Vt(m,w),x=(n[E]||[]).slice().sort(ha);u+=`<button class="mc${E===e?" sel":""}${E===o?" now":""}${E.slice(0,7)!==l?" out":""}" data-csel="${E}"><b>${+E.slice(8)}</b><i>${x.slice(0,4).map(C=>`<u style="background:${fb(C)};opacity:${C.done?.35:1}"></u>`).join("")}</i>${x.length>4?`<small>+${x.length-4}</small>`:""}</button>`}}const h=(n[e]||[]).slice().sort(ha);return`<div class="mnav"><button data-cmon="-1">‹</button><b>${tR(e)}</b><button data-cmon="1">›</button></div>
    <div class="card mgrid" id="mgrid"><div class="mh">${a.map(p=>`<span>${p}</span>`).join("")}</div><div class="mg">${u}</div></div>
    <div class="h">${oe(Oc(e))}</div>
    <div class="card">${h.length?h.map(p=>ns(p,!1)).join(""):'<div class="empty">Ελεύθερη μέρα. Πάτα «＋» για να προσθέσεις.</div>'}</div>`}function uR(n){const e=Ui(),t=!!Ze().sun,s=Vt(e,-((Qs(e).getDay()+(t?0:6))%7)),i=ye();let r=`<div class="mnav"><button data-cwk="-1">‹</button><b>${ec(s)} – ${ec(Vt(s,6))}</b><button data-cwk="1">›</button></div>`;for(let a=0;a<7;a++){const o=Vt(s,a),l=(n[o]||[]).slice().sort(ha);r+=`<div class="h wkh${o===i?" now":""}" data-csel="${o}">${o===i?"● ":""}${oe(Oc(o))}${l.length?` · ${l.length}`:""}</div>`,r+=l.length?`<div class="card">${l.map(u=>ns(u,!1)).join("")}</div>`:'<div class="wke">—</div>'}return r}function dR(n){const e=ye(),t=(o,l)=>(o.date||"").localeCompare(l.date||"")||ha(o,l),s=n.filter(o=>!o.done&&o.date&&o.date<e).sort(t),i={};n.filter(o=>o.date&&o.date>=e).sort(t).forEach(o=>(i[o.date]=i[o.date]||[]).push(o));const r=n.filter(o=>!o.date&&!o.done).sort((o,l)=>(l.upd||l.ts||0)-(o.upd||o.ts||0));return Rl(`⚠️ Εκκρεμότητες από πριν (${s.length})`,s,!0,"badh")+Object.keys(i).map(o=>Rl((o===e||o===Vt(e,1)?db(o)+" · ":"")+Oc(o),i[o],!1)).join("")+Rl("Χωρίς ημερομηνία",r,!1)||'<div class="card"><div class="empty">Δεν υπάρχει τίποτα προγραμματισμένο.</div></div>'}function hR(n){const{def:e,lists:t}=Lc(),s=ye(),i=Y.list,r=n.filter(u=>i==="myday"?u.date&&u.date<=s&&(!u.done||u.date===s):i==="planned"?!!u.date:i==="all"?!0:u.msList===i||!u.msList&&i===e),a=r.filter(u=>!u.done).sort(oR),o=r.filter(u=>u.done).sort((u,h)=>(h.upd||0)-(u.upd||0));return`<div class="chips">${[["myday","☀️ Η μέρα μου"],["planned","📅 Προγραμματισμένες"],["all","📥 Όλες"]].concat(t.map(u=>[u.id,"≡ "+u.name])).map(([u,h])=>`<button data-clist="${oe(u)}" class="${i===u?"on":""}">${oe(h)}</button>`).join("")}</div>
    <div class="qadd"><input class="search" data-cqv placeholder="＋ Προσθήκη εργασίας" value="${oe(Y.quick)}" enterkeyhint="done"><button class="btn b1 sm" data-cqa>Προσθήκη</button></div>
    ${a.length?`<div class="card">${a.map(u=>ns(u,!0)).join("")}</div>`:o.length?"":`<div class="card"><div class="empty">${i==="myday"?"Τίποτα για σήμερα 🙂":"Η λίστα είναι άδεια."}</div></div>`}
    ${o.length?`<div class="h lnk2" data-cdone>${Y.showDone?"▾":"▸"} Ολοκληρωμένες (${o.length})</div>${Y.showDone?`<div class="card">${o.map(u=>ns(u,!0)).join("")}</div>`:""}`:""}`}function ym(n,e,t,s){s&&s!==Y.argV&&["lists","month","week","agenda"].includes(s)&&(Y.view=s,Y.argV=s),Y.view||(Y.view=Ze().view||"lists");const i=Y.view,r=gm(!1),a={};r.forEach(p=>{p.date&&(a[p.date]=a[p.date]||[]).push(p)});const o=[["lists","☑ Λίστες"],["month","🗓 Μήνας"],["week","Εβδ."],["agenda","Ατζέντα"]],l=Ie()?[]:da(),u=e("Ημερολόγιο",Ie()?(ts()||{}).name||"":"Πρόγραμμα · εργασίες · λήξεις","",`<button class="ib" data-csrch aria-label="Αναζήτηση">${Y.srch?"✕":"🔍"}</button><button class="ib" data-ctoday aria-label="Σήμερα">◎</button><a class="ib" href="#/cset" aria-label="Ρυθμίσεις">⚙️</a>`),h=`${Y.srch?`<input class="search" id="csq" data-csq placeholder="🔍 Αναζήτηση σε τίτλο, πελάτη, σημειώσεις…" value="${oe(Y.q)}">`:""}
    <div class="seg">${o.map(([p,m])=>`<button data-cv="${p}" class="${i===p?"on":""}">${m}</button>`).join("")}</div>
    ${l.length?`<div class="chips"><button data-cemp="" class="${Y.emp?"":"on"}">Όλοι</button>${l.map(p=>{const m=Mc(p.id);return`<button data-cemp="${oe(p.id)}" class="${Y.emp===p.id?"on":""}">${m>=0?`<u class="dot" style="background:${ks(m)}"></u>`:""}${oe(p.name)}</button>`}).join("")}</div>`:""}
    ${n?i==="month"?lR(a):i==="week"?uR(a):i==="agenda"?dR(r):hR(gm(!0)):'<div class="card"><div class="empty">Φόρτωση…</div></div>'}`;return t(u,h,"cal",'<button class="fab" data-cnew aria-label="Νέα εργασία">＋</button>')}function fR(n){const e=n!=="new"&&A.tasks.find(i=>i.id===n);if(n!=="new"&&!e)return!1;const t=Y.preset||{};Y.preset=null;const s=tc(t.kind==="due"?Ze().dueRems:Ze().defRems);return z={arg:n,t0:e||null,isNew:!e,canEdit:!e||Ud(e),canTick:!e||Kd(e),msg:"",ask:!1,pick:null,err:!1,v:e?{kind:e.kind||"",title:e.title||"",date:e.date||"",time:e.time||"",rems:Gd(e),rep:e.rep||"",cust:e.cust||"",tel:e.tel||"",addr:e.addr||"",quoteId:e.quoteId||"",emps:(e.emps||[]).slice(),clr:typeof e.clr=="number"?e.clr:-1,notes:e.notes||"",chk:(e.chk||[]).map(i=>({tx:i.tx||"",dn:!!i.dn})),done:!!e.done,msList:e.msList||""}:{kind:t.kind||"",title:t.title||"",date:t.date!==void 0?t.date:ye(),time:"",rems:t.rems||s,rep:"",cust:t.cust||"",tel:t.tel||"",addr:t.addr||"",quoteId:t.quoteId||"",emps:[],clr:-1,notes:"",chk:[],done:!1,msList:t.msList||""}},!0}const Br=(n,e,t)=>`<div class="chips wrap">${n.map(([s,i])=>`<button ${t}="${oe(s)}" class="${e(s)?"on":""}">${i}</button>`).join("")}</div>`,pR=n=>{const e=A.quotes.find(t=>t.id===n);return e?`#${e.number||"—"} · ${e.customer&&e.customer.name||""}${e.subject?" · "+e.subject:""}`:"Συνδεδεμένη προσφορά"},vm=n=>[n.kind==="due"?"💶 "+n.title:n.title,n.date?Oc(n.date)+(n.time?" "+n.time:""):"",n.cust?"Πελάτης: "+n.cust:"",n.tel?"Τηλ: "+n.tel:"",n.addr?"Διεύθυνση: "+n.addr:"",(n.emps||[]).length?"Τεχνικοί: "+n.emps.map(Hd).filter(Boolean).join(", "):"",n.notes?`
`+n.notes:"",(n.chk||[]).length?`
`+n.chk.map(e=>(e.dn?"✔ ":"▫ ")+e.tx).join(`
`):""].filter(Boolean).join(`
`);function mR(n,e,t,s){if((!z||z.arg!==n)&&!fR(n))return s(t("Εργασία","",'<a class="ib" href="#/cal">←</a>'),`<div class="card"><div class="empty">${e?"Η εργασία δεν βρέθηκε (ίσως σβήστηκε).":"Φόρτωση…"}</div></div>`,null);const i=z.v,r=z.canEdit,a=r?"":"disabled",o=!Ie(),l=(C,j,J="",H="")=>`<label class="f">${j}<span class="fw"><input class="in${C==="title"&&z.err?" ine":""}" data-tf="${C}" value="${oe(i[C]||"")}" ${a} ${J}>${H}</span></label>`,{def:u,lists:h}=Lc(),p=z.isNew?i.kind==="due"?"Νέα λήξη / πληρωμή":"Νέα εργασία":r?"Επεξεργασία":"Εργασία",m=i.tel.replace(/\s/g,""),w=i.chk.filter(C=>C.dn).length,E=`${r?"":`<div class="upd">🔒 Την έγραψε ${oe(z.t0.by&&z.t0.by.name||"άλλος")}. Μπορείς να τη σημειώσεις ολοκληρωμένη και να τσεκάρεις το checklist.</div>`}
  <div class="card pad"><div class="ch">📅 Τι και πότε</div>
    ${r?`<div class="seg">${[["","🛠 Εργασία"],["due","💶 Λήξη / πληρωμή"]].map(([C,j])=>`<button data-tfk="${C}" class="${i.kind===C?"on":""}">${j}</button>`).join("")}</div>`:""}
    ${o&&z.isNew&&h.length>1?`<div class="f">Λίστα To Do</div>${Br(h.map(C=>[C.id,oe(C.name)]),C=>C===i.msList||!i.msList&&C===u,"data-tlist")}`:!z.isNew&&i.msList&&h.find(C=>C.id===i.msList)?`<div class="f">≡ Λίστα: ${oe(h.find(C=>C.id===i.msList).name)}</div>`:""}
    ${l("title",i.kind==="due"?"Τι λήγει / τι πληρώνεται":"Τίτλος",'placeholder="π.χ. Εγκατάσταση καμερών" autocomplete="off"')}
    <div class="two">${l("date","Ημερομηνία",'type="date"')}${l("time","Ώρα",`type="time" ${i.date?"":"disabled"}`)}</div>
    ${r?`<div class="chips wrap">${[["Σήμερα",ye()],["Αύριο",Vt(ye(),1)],["+1 εβδομάδα",Vt(ye(),7)],["+1 μήνας",ua(ye(),1)]].map(([C,j])=>`<button data-tdq="${j}" class="${i.date===j?"on":""}">${C}</button>`).join("")}${i.date?'<button data-tdq="">✕ Χωρίς ημερομηνία</button>':""}</div>`:""}
  </div>
  <div class="card pad"><div class="ch">🔔 Υπενθυμίσεις</div>
    ${r?Br(pb.map(C=>[C,Iu(C)]),C=>i.rems.includes(+C),"data-trem")+(i.date&&!i.time?'<div class="hint">Χωρίς ώρα, οι υπενθυμίσεις υπολογίζονται από τις 08:00.</div>':"")+(i.date?"":'<div class="hint">Οι υπενθυμίσεις χρειάζονται ημερομηνία.</div>'):`<div class="hint">${i.rems.map(Iu).join(", ")||"Καμία"}</div>`}
    <div class="f" style="margin-top:8px">🔁 Επανάληψη</div>
    ${r?Br(Object.entries(Eu),C=>C===i.rep,"data-trep")+(i.rep?'<div class="hint">Όταν την ολοκληρώσεις, δημιουργείται αυτόματα η επόμενη.</div>':""):`<div class="hint">${Eu[i.rep]||"Καμία"}</div>`}
  </div>
  <div class="card pad"><div class="ch">👤 Πελάτης</div>
    ${o&&r?`<div class="actions"><button class="btn b2" data-tpick="cust">📇 Από πελάτες</button><button class="btn b2" data-tpick="quote">📄 ${i.quoteId?"Άλλη προσφορά":"Προσφορά"}</button></div>`:""}
    ${i.quoteId?`<div class="qlink"><a href="#/q/${encodeURIComponent(i.quoteId)}">🔗 ${oe(pR(i.quoteId))}</a>${o&&r?'<button class="x" data-tunq aria-label="Αποσύνδεση">✕</button>':""}</div>`:""}
    ${l("cust","Όνομα πελάτη",'autocomplete="off"')}
    ${l("tel","Τηλέφωνο",'inputmode="tel"',m?`<a class="fa" href="tel:${oe(m)}">📞</a>`:"")}
    ${l("addr","Διεύθυνση","",i.addr?`<a class="fa" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i.addr)}">🗺️</a>`:"")}
  </div>
  ${o&&A.emps.length||r?`<div class="card pad"><div class="ch">👷 Ποιος και χρώμα</div>
    ${o&&da().length?`<div class="chips wrap">${da().map(C=>{const j=Mc(C.id),J=i.emps.includes(C.id);return`<button data-temp="${oe(C.id)}" class="${J?"on":""}" ${a}>${J?"✓ ":j>=0?`<u class="dot" style="background:${ks(j)}"></u>`:""}${oe(C.name)}</button>`}).join("")}</div>`:i.emps.length?`<div class="hint">${oe(i.emps.map(Hd).filter(Boolean).join(", "))}</div>`:""}
    ${r?`<div class="f" style="margin-top:6px">Χρώμα</div><div class="clrs"><button data-tclr="-1" class="${i.clr<0?"on":""}">Αυτόματο</button>${wi.map(([C,j],J)=>`<button data-tclr="${J}" class="sw${i.clr===J?" on":""}" style="background:${j}" aria-label="${C}"></button>`).join("")}</div>`:""}
  </div>`:""}
  <div class="card pad"><div class="ch">📝 Σημειώσεις</div>
    <textarea class="in" data-tf="notes" rows="4" placeholder="Ό,τι χρειάζεται να θυμάσαι…" ${a}>${oe(i.notes)}</textarea>
    <div class="actions"><button class="btn b2" data-tncopy>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tnpaste>📋 Επικόλληση</button>':""}</div>
  </div>
  <div class="card pad"><div class="ch">☑ Checklist${i.chk.length?` <span class="muted">${w}/${i.chk.length}</span>`:""}</div>
    ${i.chk.length?`<div class="prog"><i style="width:${Math.round(w/i.chk.length*100)}%"></i></div>`:""}
    ${i.chk.map((C,j)=>`<div class="ci"><button class="tick${C.dn?" on":""}" data-tchktg="${j}" ${z.canTick?"":"disabled"}>${C.dn?"✓":""}</button>${r?`<input class="in" data-tchk="${j}" value="${oe(C.tx)}"><button class="x" data-tchkdel="${j}">✕</button>`:`<span class="${C.dn?"strike":""}">${oe(C.tx)}</span>`}</div>`).join("")}
    <div class="actions">${r?'<button class="btn b2" data-tchkadd>＋ Στοιχείο</button>':""}<button class="btn b2" data-tccopy ${i.chk.length?"":"disabled"}>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tcpaste>📋 Επικόλληση</button>':""}</div>
    ${r?'<div class="hint">Επικόλληση: κάθε γραμμή του προχείρου γίνεται ξεχωριστό στοιχείο.</div>':""}
  </div>
  <div class="card pad"><div class="ch">✅ Κατάσταση</div>
    <label class="chk2"><input type="checkbox" data-tf="done" ${i.done?"checked":""} ${z.canTick?"":"disabled"}> ${i.done?"Ολοκληρώθηκε":"Ανοιχτή"}</label>
    ${z.t0&&z.t0.by&&z.t0.by.name?`<div class="hint">Την έγραψε: ${oe(z.t0.by.uid===(ts()||{}).uid?"εσύ":z.t0.by.name)}${z.t0.done&&z.t0.doneBy?" · ολοκλήρωσε: "+oe(z.t0.doneBy):""}</div>`:""}
  </div>
  ${z.msg?`<div class="err box">${oe(z.msg)}</div>`:""}
  ${!z.isNew&&r?`<button class="btn wide del" data-tdel>${z.ask?"Σίγουρα; Πάτα ξανά για διαγραφή":"🗑️ Διαγραφή"}</button>`:""}
  ${z.pick?gR():""}`;return`${t(p,"",'<a class="ib" data-tcancel>←</a>','<button class="ib" data-tcopy aria-label="Αντιγραφή">⧉</button><button class="ib" data-tshare aria-label="Αποστολή">📤</button>')}<main class="body ed">${E}</main><div class="bar"><button class="btn b2" data-tcancel>Άκυρο</button><button class="btn b1" data-tsave>💾 Αποθήκευση</button></div>`}function gb(){return z.pick.kind==="cust"?un().filter(n=>n.name&&n.name!=="(χωρίς όνομα)").sort((n,e)=>(e.last||0)-(n.last||0)).map(n=>({t:n.name,s:[n.info.phone,n.info.address].filter(Boolean).join(" · "),v:{cust:n.name,tel:n.info.phone||"",addr:n.info.address||""}})):A.quotes.filter(n=>!cn(n)).sort((n,e)=>(e.ts||0)-(n.ts||0)).map(n=>{const e=n.customer||{};return{t:`#${n.number||"—"} · ${e.name||""}`,s:[n.subject,e.address].filter(Boolean).join(" · "),v:{quoteId:n.id,cust:e.name||"",tel:e.phone||"",addr:e.address||"",q:!0}}})}function gR(){const n=z.pick.q.trim().toLowerCase(),e=gb().map((t,s)=>({...t,i:s})).filter(t=>!n||(t.t+" "+t.s).toLowerCase().includes(n)).slice(0,150);return`<div class="sheet" data-pkx><div class="sheet-in"><div class="sheet-h"><b>${z.pick.kind==="cust"?"Πελάτες":"Προσφορές"}</b><button class="ib dk" data-pkx>✕</button></div>
    <input class="search" id="pq" data-pq placeholder="🔍 Αναζήτηση…" value="${oe(z.pick.q)}">
    <div class="sheet-list">${e.map(t=>`<button class="prow" data-pk="${t.i}"><div class="t"><b>${oe(t.t)}</b><span>${oe(t.s)}</span></div></button>`).join("")||'<div class="empty">Τίποτα</div>'}</div></div></div>`}const pn=(n,e)=>`<label class="tg"><span>${e}</span><input type="checkbox" data-stg="${n}" ${Ze()[n]?"checked":""}></label>`,Ln=(n,e,t)=>`<div class="f">${e}</div>${Br(t,s=>String(Ze()[n])===String(s),`data-s="${n}" data-v`)}`,bm=(n,e)=>`<div class="f">${e}</div>${Br(pb.map(t=>[t,Iu(t)]),t=>tc(Ze()[n]).includes(+t),`data-sr="${n}" data-v`)}`;async function Yd(n){await oa(),Y.ms=await be.msStatus(),n()}function yR(n,e){const t=Ze(),s=Y.ms||{},{lists:i}=Lc(),r=!Ie(),a=l=>l?new Date(l).toLocaleString(Zi,{dateStyle:"short",timeStyle:"short"}):"",o=`${Cn?"":'<div class="upd">🧪 Preview στον browser: ειδοποιήσεις, widgets, backup και To Do λειτουργούν μόνο στο κινητό.</div>'}
  <div class="h">🎨 Εμφάνιση ημερολογίου</div><div class="card pad">
    ${Ln("view","Οθόνη έναρξης",[["lists","Λίστες"],["month","Μήνας"],["week","Εβδομάδα"],["agenda","Ατζέντα"]])}
    <div class="f">Χρώμα εργασιών (προεπιλογή)</div><div class="clrs">${wi.map(([l,u],h)=>`<button data-s="accent" data-v="${h}" class="sw${k(t.accent)===h?" on":""}" style="background:${u}" aria-label="${l}"></button>`).join("")}</div>
    ${pn("sun","Η εβδομάδα ξεκινά Κυριακή")}${pn("showDone","Εμφάνιση ολοκληρωμένων")}${pn("compact","Συμπαγής λίστα (περισσότερα στην οθόνη)")}
  </div>
  ${r&&da().length?`<div class="h">👷 Χρώμα ανά τεχνικό</div><div class="card pad"><div class="hint">Οι εργασίες χωρίς δικό τους χρώμα παίρνουν το χρώμα του τεχνικού.</div>
    ${da().map(l=>{const u=Mc(l.id);return`<div class="erow" data-sec="${oe(l.id)}"><u class="dot lg" style="background:${u>=0?ks(u):"var(--line)"}"></u><b>${oe(l.name)}</b><span class="muted">${u>=0?wi[u][0]:"Αυτόματο"}</span></div>
      ${Y.emSel===l.id?`<div class="clrs"><button data-secv="${oe(l.id)}|-1" class="${u<0?"on":""}">Αυτόματο</button>${wi.map(([h,p],m)=>`<button data-secv="${oe(l.id)}|${m}" class="sw${u===m?" on":""}" style="background:${p}" aria-label="${h}"></button>`).join("")}</div>`:""}`}).join("")}</div>`:""}
  <div class="h">🔔 Υπενθυμίσεις</div><div class="card pad">
    ${bm("defRems","Προεπιλογή για νέες εργασίες")}${bm("dueRems","Προεπιλογή για λήξεις / πληρωμές")}
    ${pn("rep","Να ξαναχτυπά μέχρι να πατήσω «ΟΚ»")}
    ${t.rep?Ln("repMin","Κάθε",[2,5,10,15,30].map(l=>[l,l+"΄"]))+Ln("repMax","Μέχρι",[3,6,12,24].map(l=>[l,l+" φορές"])):""}
    ${Ln("snooze","Αναβολή",[5,10,15,30,60].map(l=>[l,l+"΄"]))}
    ${pn("alarmSound","Δυνατός ήχος ξυπνητηριού")}${pn("clockMode","Μέγιστη ακρίβεια (σαν ξυπνητήρι)")}
    <div class="actions"><button class="btn b2" data-sact="test">🔔 Δοκιμή</button><button class="btn b2" data-sact="notif">🔊 Ήχοι</button></div>
    <div class="hint">Αν το κινητό (Xiaomi, Huawei, Samsung) «κοιμίζει» τις εφαρμογές, βάλε το TechMate «Χωρίς περιορισμό» μπαταρίας:</div>
    <div class="actions"><button class="btn b2" data-sact="battery">🔋 Ρυθμίσεις μπαταρίας</button></div>
  </div>
  <div class="h">🔄 Συγχρονισμός και μπαταρία</div><div class="card pad">
    <div class="hint">Όσο η εφαρμογή είναι ανοιχτή, όλα ενημερώνονται αμέσως. Κλειστή, ελέγχει για νέες εργασίες μόνο όσο συχνά ορίσεις. Οι υπενθυμίσεις δεν εξαρτώνται από αυτό.</div>
    ${Ln("syncMin","Έλεγχος για νέες εργασίες",[[0,"Ποτέ"],[15,"15΄"],[30,"30΄"],[60,"1 ώρα"],[180,"3 ώρες"],[360,"6 ώρες"]])}
    ${pn("notifyNew","Ειδοποίηση για νέα / αλλαγμένη εργασία")}
  </div>
  <div class="h">🧩 Widget</div><div class="card pad">
    <label class="f">Διαφάνεια φόντου: <b id="wav">${t.wAlpha}%</b><input type="range" min="20" max="100" step="10" value="${t.wAlpha}" data-sw class="rng"></label>
    ${Ln("wMode","Τι δείχνει το widget-λίστα",[["todo","Εργασίες (όπως το To Do)"],["cal","Μόνο ραντεβού με ημερομηνία"]])}
    ${t.wMode==="todo"&&i.length>1?Ln("wList","Λίστα To Do στο widget",[["","Όλες"]].concat(i.map(l=>[l.id,oe(l.name)]))):""}
    ${Ln("wDays",t.wMode==="todo"?"Μαζί με ραντεβού για":"Η λίστα του widget δείχνει",[[1,"Σήμερα"],[2,"Σήμερα & αύριο"],[3,"3 μέρες"],[7,"Εβδομάδα"]])}
    <div class="hint">Για να το προσθέσεις: πάτα παρατεταμένα την αρχική οθόνη → Widgets → TechMate.</div>
  </div>
  ${r?`<div class="h">💾 Backup στη συσκευή / Google Drive</div><div class="card pad">
    <div class="hint">Σώζει ΟΛΟ το TechMate (προσφορές, πελάτες, λογιστικά, εργασίες…) σε αρχείο που διαλέγεις. Για Google Drive, πάτα ☰ στον επιλογέα και διάλεξε «Drive». Μόνο διαβάζει τη βάση, δεν αλλάζει τίποτα.</div>
    <div class="actions"><button class="btn b2" data-sact="bpick">📁 ${t.bUri?"Άλλο αρχείο":"Επιλογή αρχείου"}</button>${t.bUri?'<button class="btn b2" data-sact="bnow">☁️ Backup τώρα</button>':""}</div>
    ${t.bUri?pn("bAuto","Αυτόματο backup μία φορά τη μέρα (όταν ανοίγεις την εφαρμογή)")+`<div class="hint">${t.bLast?"Τελευταίο: "+a(t.bLast):"Δεν έχει γίνει ακόμα"}</div>`:""}
    <label class="btn b2 wide filebtn">♻️ Επαναφορά εργασιών που λείπουν, από backup…<input type="file" accept="application/json,.json" data-restore hidden></label>
    <div class="hint">Η επαναφορά προσθέτει ΜΟΝΟ εργασίες που δεν υπάρχουν πια. Όσες υπάρχουν δεν αλλάζουν.</div>
  </div>
  <div class="h">✅ Microsoft To Do</div><div class="card pad">
    ${s.connected?`<div class="hint">👤 ${oe(s.account||"Συνδεδεμένο")}</div><div class="hint">${s.status==="sync"?"⏳ Συγχρονισμός…":s.status==="login"?"⚠️ Χρειάζεται ξανά σύνδεση":s.status&&s.status!=="ok"?"⚠️ "+oe(s.status):s.last?"✓ Τελευταίος συγχρονισμός: "+a(s.last):"✓ Συνδεδεμένο"}</div>
        <div class="actions">${s.status==="login"?'<button class="btn b1" data-sact="mslogin">Σύνδεση</button>':'<button class="btn b2" data-sact="mssync">🔄 Συγχρονισμός τώρα</button>'}<button class="btn b2" data-sact="msout">Αποσύνδεση</button></div>
        <div class="hint">Συγχρονίζονται οι λίστες που έχεις διαλέξει στο TechMate. Οι νέες εργασίες πάνε στην κύρια λίστα.</div>`:'<div class="hint">Σύνδεσε τον λογαριασμό Microsoft: οι εργασίες πηγαίνουν και έρχονται από το To Do απευθείας από το κινητό, με την ίδια λογική με το PWA (χωρίς διπλές).</div><button class="btn b1 wide" data-sact="mslogin">Σύνδεση με Microsoft</button>'}
  </div>`:'<div class="card pad"><div class="hint">Τον συγχρονισμό με το To Do και τα backup τα κάνει ο διαχειριστής.</div></div>'}
  <div class="card pad">${pn("autoUpd","Αυτόματος έλεγχος για νέα έκδοση εφαρμογής")}</div>`;return e(n("Ρυθμίσεις ημερολογίου","Ειδοποιήσεις · widget · backup · To Do",'<a class="ib" href="#/cal">←</a>'),o,null)}function Au(){const n=t=>Object.fromEntries((t||[]).map(s=>{const i={...s};return delete i.id,[s.id,i]})),e={};return["quotes","custs","tasks","ldocs","lpays","emps","products","smoves","wdays","wpays","needs"].forEach(t=>e[t]=n(A[t])),JSON.stringify({app:"TechMate",ver:2,at:new Date().toISOString(),tasks:e.tasks,data:e,settings:A.st},null,1)}async function vR(n){const e=Ze();if(!Cn||!n||Ie()||!e.bUri||!e.bAuto||!A.tasks.length||!A.quotes.length||Date.now()-k(e.bLast)<20*36e5)return;const t=await be.backupWrite(Au());t&&t.ok&&await oa()}async function bR(n,e,t){try{const s=JSON.parse(await n.text()),i=s.tasks||s.data&&s.data.tasks||{},r=new Set(A.tasks.map(o=>o.id));let a=0;Object.keys(i).forEach(o=>{r.has(o)||!i[o]||typeof i[o]!="object"||(Ge("tasks",{...i[o],id:o}),a++)}),e(a?`Επαναφέρθηκαν ${a} εργασίες που έλειπαν.`:"Δεν έλειπε καμία εργασία. Δεν άλλαξε τίποτα.")}catch{e("Το αρχείο δεν είναι σωστό backup.")}t()}function yb(n){const e=Y.quick.trim();if(!e)return;const t=Y.list,s=Qd(null,{title:e,date:t==="myday"?ye():"",rems:[],msList:["myday","planned","all"].includes(t)?"":t});if(s.msg)return n(s.msg);Y.quick="",n("Προστέθηκε: "+e)}function _R(){if(Y.view==="lists"){const e=Y.list;Ii({date:e==="myday"||e==="planned"?ye():"",msList:["myday","planned","all"].includes(e)?"":e})}else Ii({date:Ui()});location.hash="#/t/new"}async function wR(n,e,t){const s={test:async()=>{const i=await be.testNotif();t(i&&i.error?i.error:Cn?"Στάλθηκε δοκιμαστική ειδοποίηση":"Μόνο στο κινητό")},notif:()=>be.openNotifSettings(),battery:()=>be.openBattery(),mslogin:()=>be.msLogin(),mssync:async()=>{Y.ms={...Y.ms||{},status:"sync"},e();const i=await be.msSync();t(i&&i.ok?"Συγχρονίστηκε με το To Do":"Ο συγχρονισμός απέτυχε")},msout:async()=>{await be.msDisconnect(),t("Αποσυνδέθηκε το Microsoft To Do")},bpick:async()=>{const i=await be.backupPick();if(i&&i.error)return t(i.error);if(i&&i.ok){await oa();const r=await be.backupWrite(Au());t(r&&r.ok?"Έγινε το πρώτο backup":"Backup: "+(r&&r.error||"σφάλμα"))}},bnow:async()=>{const i=await be.backupWrite(Au());t(i&&i.ok?"Έγινε backup":"Backup: "+(i&&i.error||"σφάλμα"))}}[n];s&&await s(),await oa(),Y.ms=await be.msStatus(),e()}function IR(n,e,t){const s=n.closest("[data-tk],[data-cv],[data-csel],[data-cmon],[data-cwk],[data-cemp],[data-clist],[data-csrch],[data-ctoday],[data-cdone],[data-cnew],[data-cqa],[data-tfk],[data-trem],[data-trep],[data-temp],[data-tclr],[data-tdq],[data-tlist],[data-tunq],[data-tpick],[data-pk],[data-pkx],[data-tchkadd],[data-tchkdel],[data-tchktg],[data-tncopy],[data-tnpaste],[data-tccopy],[data-tcpaste],[data-tcopy],[data-tshare],[data-tsave],[data-tcancel],[data-tdel],[data-s],[data-sr],[data-sec],[data-secv],[data-sact]");if(!s)return!1;const i=s.dataset;if(i.tk){const a=A.tasks.find(l=>l.id===i.tk);if(!a)return!0;const o=!a.done;return kl(a,o),t((o?"✓ Ολοκληρώθηκε: ":"Άνοιξε ξανά: ")+(a.title||""),{label:"Αναίρεση",fn:()=>{const l=A.tasks.find(u=>u.id===a.id);l&&kl(l,!o)}}),!0}if(i.cv)return Y.view=i.cv,e(),!0;if(i.csel)return Y.sel=i.csel,Y.view==="week"&&(Y.view="month"),e(),!0;if(i.cmon)return Y.sel=ua(Ui().slice(0,8)+"01",+i.cmon),e(),!0;if(i.cwk)return Y.sel=Vt(Ui(),7*i.cwk),e(),!0;if("cemp"in i)return Y.emp=Y.emp===i.cemp?"":i.cemp,e(),!0;if(i.clist)return Y.list=i.clist,e(),!0;if("csrch"in i){Y.srch=!Y.srch,Y.srch||(Y.q=""),e();const a=document.getElementById("csq");return a&&a.focus(),!0}if("ctoday"in i)return Y.sel=ye(),e(),!0;if("cdone"in i)return Y.showDone=!Y.showDone,e(),!0;if("cnew"in i)return _R(),!0;if("cqa"in i)return yb(t),e(),!0;if(i.s!==void 0&&i.v!==void 0){const a=Ze()[i.s],o=typeof a=="number"?+i.v:typeof a=="boolean"?i.v==="true":i.v;return Ur(i.s,o).then(e),!0}if(i.sr){const a=tc(Ze()[i.sr]),o=+i.v,l=a.includes(o)?a.filter(u=>u!==o):a.concat(o);return Ur(i.sr,l.join(",")).then(e),!0}if(i.secv){const[a,o]=i.secv.split("|"),l=hb();return+o<0?delete l[a]:l[a]=+o,Y.emSel="",Ur("empClr",JSON.stringify(l)).then(e),!0}if(i.sec)return Y.emSel=Y.emSel===i.sec?"":i.sec,e(),!0;if(i.sact)return wR(i.sact,e,t),!0;if(!z)return!1;const r=z.v;if("pkx"in i)return s.classList.contains("sheet")&&n!==s?!0:(z.pick=null,e(),!0);if(i.pk){const a=gb()[+i.pk];if(a){const o=a.v;o.q?(r.quoteId=o.quoteId,r.cust||(r.cust=o.cust),r.tel||(r.tel=o.tel),r.addr||(r.addr=o.addr),r.title||(r.title="Εγκατάσταση – "+o.cust)):(r.cust=o.cust,o.tel&&(r.tel=o.tel),o.addr&&(r.addr=o.addr))}return z.pick=null,e(),!0}if(i.tfk!==void 0)r.kind!==i.tfk&&z.isNew&&(r.rems=tc(i.tfk==="due"?Ze().dueRems:Ze().defRems)),r.kind=i.tfk;else if(i.trem!==void 0){const a=+i.trem;r.rems=r.rems.includes(a)?r.rems.filter(o=>o!==a):r.rems.concat(a)}else if(i.trep!==void 0)r.rep=i.trep;else if(i.temp){const a=r.emps.indexOf(i.temp);a>=0?r.emps.splice(a,1):r.emps.push(i.temp)}else if(i.tclr!==void 0)r.clr=+i.tclr;else if(i.tdq!==void 0)r.date=i.tdq,r.date||(r.time="");else if(i.tlist)r.msList=i.tlist;else if("tunq"in i)r.quoteId="";else if(i.tpick)z.pick={kind:i.tpick,q:""};else if("tchkadd"in i)r.chk.push({tx:"",dn:!1});else if(i.tchkdel)r.chk.splice(+i.tchkdel,1);else if(i.tchktg){const a=r.chk[+i.tchktg];a&&z.canTick&&(a.dn=!a.dn)}else{if("tncopy"in i)return be.copy(r.notes),t("Αντιγράφηκαν οι σημειώσεις"),!0;if("tnpaste"in i)return be.paste().then(a=>{if(!a)return t("Το πρόχειρο είναι άδειο");r.notes=r.notes.trim()?r.notes.trimEnd()+`
`+a:a,t("Επικολλήθηκε"),e()}),!0;if("tccopy"in i)return be.copy(r.chk.map(a=>(a.dn?"✔ ":"▫ ")+a.tx).join(`
`)),t("Αντιγράφηκε το checklist"),!0;if("tcpaste"in i)return be.paste().then(a=>{const o=String(a||"").split(/\r?\n/).map(l=>l.trim()).filter(Boolean).map(l=>({tx:l.replace(/^([-*•▫☐☑✔✓]|\[[ xX]?\]|\d+[.)])\s*/,""),dn:/^(☑|✔|✓|\[[xX]\])/.test(l)})).filter(l=>l.tx);if(!o.length)return t("Το πρόχειρο είναι άδειο");r.chk.push(...o),t(`Προστέθηκαν ${o.length} στοιχεία`),e()}),!0;if("tcopy"in i)return be.copy(vm(r)),t("Αντιγράφηκε η εργασία"),!0;if("tshare"in i)return be.share(vm(r)),!0;if("tcancel"in i)return z=null,history.length>1?history.back():location.replace("#/cal"),!0;if("tdel"in i)if(!z.ask)z.ask=!0;else{const a=rR(z.t0);if(a.msg)z.msg=a.msg,z.ask=!1;else{const o=z.t0.title;return z=null,t("Διαγράφηκε: "+o),location.replace("#/cal"),!0}}else if("tsave"in i){if(z.canEdit){const l=Qd(z.isNew?null:z.arg,r);if(l.msg)return z.msg=l.msg,z.err=!r.title.trim(),e(),!0}else{const l=A.tasks.find(h=>h.id===z.arg)||z.t0,u=r.chk.filter(h=>h.tx.trim());JSON.stringify(u)!==JSON.stringify((l.chk||[]).map(h=>({tx:h.tx,dn:!!h.dn})))&&iR(l,u),!!r.done!=!!l.done&&kl(l,r.done)}const a=r.title.trim(),o=z.isNew;return z=null,t(o?"Προστέθηκε: "+a:"Αποθηκεύτηκε"),history.length>1?history.back():location.replace("#/cal"),!0}}return e(),!0}function ER(n,e){const t=n.dataset;if("csq"in t){Y.q=n.value,e();const s=document.getElementById("csq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if("cqv"in t)return Y.quick=n.value,!0;if("sw"in t){const s=document.getElementById("wav");return s&&(s.textContent=n.value+"%"),!0}if(!z)return!1;if("pq"in t){z.pick.q=n.value,e();const s=document.getElementById("pq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(t.tchk!==void 0){const s=z.v.chk[+t.tchk];return s&&(s.tx=n.value),!0}return t.tf?(z.v[t.tf]=n.type==="checkbox"?n.checked:n.value,z.msg&&(z.msg=""),t.tf==="title"&&(z.err=!1),!0):!1}function TR(n,e,t){const s=n.dataset;return s.stg?(Ur(s.stg,n.checked).then(e),!0):"sw"in s?(Ur("wAlpha",+n.value).then(e),!0):"restore"in s?(n.files&&n.files[0]&&bR(n.files[0],t,e),!0):z&&(s.tf==="date"||s.tf==="done")?(z.v[s.tf]=n.type==="checkbox"?n.checked:n.value,s.tf==="date"&&!n.value&&(z.v.time=""),e(),!0):!1}function AR(n,e,t){if(n.key==="Enter"&&n.target.dataset&&"cqv"in n.target.dataset){n.preventDefault(),Y.quick=n.target.value,yb(t),e();const s=document.querySelector("[data-cqv]");return s&&s.focus(),!0}return!1}let Er=null;function vb(n,e){if(!n.target.closest||!n.target.closest("#mgrid")){Er=null;return}if(n.type==="touchstart")Er=n.touches[0].clientX;else if(n.type==="touchend"&&Er!==null){const t=n.changedTouches[0].clientX-Er;Er=null,Math.abs(t)>70&&(Y.sel=ua(Ui().slice(0,8)+"01",t<0?1:-1),e())}}function SR(){const n=ye(),e=Tu().filter(t=>!t.done);return{today:Tu().filter(t=>t.date===n).sort(ha),late:e.filter(t=>t.date&&t.date<n).sort((t,s)=>t.date.localeCompare(s.date)),dues:e.filter(t=>t.kind==="due"&&t.date&&t.date>n&&t.date<=Vt(n,14)).sort((t,s)=>t.date.localeCompare(s.date))}}let _m=null,wm="";function kR(){!Cn||!Fr.tasks||(clearTimeout(_m),_m=setTimeout(()=>{const n={};A.tasks.forEach(r=>{const a={...r};delete a.id,n[r.id]=a});const e=JSON.stringify(n),t=A.emps.map(r=>({id:r.id,name:r.name||""})),s=Lc(),i=e.length+":"+e+JSON.stringify(t)+JSON.stringify(s);i!==wm&&(wm=i,be.setTasks(e,t,s))},400))}const mn=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Xd=(n,e)=>(n||[]).find(t=>t.id===e),nc="https://graph.microsoft.com/v1.0",RR="TechMate/Τιμολόγια",PR="TechMate/Φωτογραφίες εγκαταστάσεων",Pl=n=>String(n||"").replace(/[\\/:*?"<>|#%]+/g," ").replace(/\s+/g," ").trim(),Cl=n=>(n=k(n,0),n>=1048576?(n/1048576).toFixed(1).replace(".",",")+" MB":Math.max(1,Math.round(n/1024))+" KB"),Im=n=>!(n&&n.war&&n.war.on===!1),CR=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(k(e.m,0))):k((ne()||{}).warrantyMonths,24)},$R=n=>n.install||{date:n.statusDate||"",months:Im(n)?CR(n):0,serials:"",nw:!Im(n)},xe={st:null,busy:"",msg:"",pick:""},Zd=()=>!!xe.busy,qi=n=>n&&n.install&&n.install.docs||[],fa=n=>n&&n.install&&n.install.photos||[];async function eh(n){xe.st=Hs?{connected:!0,account:"demo@hotmail.com"}:Cn?await be.filesStatus():{connected:!1,account:"",web:!0},n()}const sc=(n,e,t)=>n.install?Yo("quotes",n.id,"install."+e,t):Yo("quotes",n.id,"install",{...$R(n),[e]:t}),Su=(n,e)=>Ge("qlog",{id:ze(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:e}),th=async()=>{if(Hs)return"demo";const n=await be.filesToken();if(!n||!n.ok){const e=new Error(n&&n.error==="login"?"Συνδέσου στο OneDrive.":n&&n.error||"Δεν υπάρχει σύνδεση OneDrive.");throw e.login=!0,e}return n.token},Em=(n,e)=>"/me/drive/root:/"+e.split("/").map(encodeURIComponent).join("/")+"/"+encodeURIComponent(n);async function DR(n,e,t,s,i){if(Hs)return{id:"demo"+Date.now(),name:t,size:e.size,webUrl:""};const r={Authorization:"Bearer "+n},a=async h=>{if(!h.ok)throw new Error(h.status===507?"Γέμισε ο χώρος του OneDrive.":h.status===403||h.status===401?"Το OneDrive δεν επιτρέπει την πρόσβαση (άδεια Files.ReadWrite). Συνδέσου ξανά.":"Το OneDrive απέρριψε το αρχείο ("+h.status+").");return h.json()};if(e.size<=4e6)return a(await fetch(nc+Em(t,s)+":/content?@microsoft.graph.conflictBehavior=rename",{method:"PUT",headers:{"Content-Type":e.type||"application/octet-stream",...r},body:e}));const o=await a(await fetch(nc+Em(t,s)+":/createUploadSession",{method:"POST",headers:{"Content-Type":"application/json",...r},body:JSON.stringify({item:{"@microsoft.graph.conflictBehavior":"rename"}})})),l=327680*10;let u=0;for(;;){const h=Math.min(u+l,e.size);i&&i(Math.round(h/e.size*100));const p=await fetch(o.uploadUrl,{method:"PUT",headers:{"Content-Range":`bytes ${u}-${h-1}/${e.size}`},body:e.slice(u,h)});if(p.status===202){u=h;continue}return a(p)}}function xR(n){return!/^image\/(jpeg|png|webp)$/i.test(n.type)||n.size<4e5?Promise.resolve(n):new Promise(e=>{const t=URL.createObjectURL(n),s=new Image;s.onload=()=>{const i=Math.min(1,2e3/Math.max(s.naturalWidth,s.naturalHeight)),r=document.createElement("canvas");r.width=Math.round(s.naturalWidth*i),r.height=Math.round(s.naturalHeight*i);const a=r.getContext("2d");a.fillStyle="#fff",a.fillRect(0,0,r.width,r.height),a.drawImage(s,0,0,r.width,r.height),URL.revokeObjectURL(t),r.toBlob(o=>!o||o.size>=n.size?e(n):e(new File([o],n.name.replace(/\.[^.]+$/,"")+".jpg",{type:"image/jpeg"})),"image/jpeg",.82)},s.onerror=()=>{URL.revokeObjectURL(t),e(n)},s.src=t})}function NR(n,e,t){const s=Xd(A.quotes,n),i='<a class="ib" href="#/inst">←</a>';if(!s)return t(e("Τιμολόγια & φωτο","",i),'<div class="empty">Δεν βρέθηκε</div>',"menu");const r=xe.st,a=qi(s),o=fa(s),l=r&&r.connected,u=(h,p)=>{const m=o.filter(w=>w.kind===h);return`<div class="item"><div class="t"><b>${p} (${m.length})</b><span>${m.map(w=>Cl(w.size)).join(" · ")||"—"}</span></div>
    <div class="r"><label class="btn b2 sm">📷<input type="file" accept="image/*" capture="environment" hidden data-fl-ph="${h}"></label><label class="btn b2 sm">🖼️<input type="file" accept="image/*" hidden data-fl-ph="${h}"></label></div></div>
    ${m.map((w,E)=>`<div class="item sub"><div class="t"><b>${mn(w.name)}</b><span>${w.ts?new Date(w.ts).toLocaleDateString("el-GR"):""} · ${Cl(w.size)}</span></div><div class="r">${w.url?`<a class="btn b2 sm" href="${mn(w.url)}" target="_blank" rel="noopener">${E+1}</a>`:""}<button class="ib dk" data-fl-del="ph:${mn(w.id)}">🗑️</button></div></div>`).join("")}`};return t(e("Τιμολόγια & φωτογραφίες",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,i),`${r?l?`<div class="hint">OneDrive: <b>${mn(r.account||"συνδεδεμένο")}</b> · <a href="#" data-fl="logout">αποσύνδεση</a></div>`:`<div class="card pad"><b>Σύνδεση OneDrive</b><div class="muted small" style="margin:6px 0 10px">Τα αρχεία ανεβαίνουν στο OneDrive του λογαριασμού αποστολής (όπως στο PWA), φάκελος «TechMate». ${r.web?"Η σύνδεση γίνεται μόνο από την εφαρμογή στο κινητό.":""}</div>${r.web?"":'<button class="btn b1 wide" data-fl="login">🔗 Σύνδεση λογαριασμού Microsoft</button>'}</div>`:'<div class="empty">Φόρτωση…</div>'}
    ${xe.busy?`<div class="upd">${mn(xe.busy)}</div>`:""}${xe.msg?`<div class="err box">${mn(xe.msg)}</div>`:""}
    <div class="h">Τιμολόγια (${a.length})</div><div class="card">${a.map(h=>`<div class="item"><div class="t"><b>${mn(h.name)}</b><span>${h.ts?new Date(h.ts).toLocaleDateString("el-GR"):""} · ${Cl(h.size)}</span></div><div class="r"><button class="btn b2 sm" data-fl-open="${mn(h.id)}">Άνοιγμα</button><button class="ib dk" data-fl-del="doc:${mn(h.id)}">🗑️</button></div></div>`).join("")||'<div class="empty">Κανένα τιμολόγιο.</div>'}
      <div class="pad"><label class="btn b1 wide ${l?"":"dis"}">🧾 Προσθήκη τιμολογίου<input type="file" accept="application/pdf,image/*" hidden data-fl-doc ${l?"":"disabled"}></label></div></div>
    <div class="h">Φωτογραφίες εγκατάστασης</div><div class="card ${l?"":"off"}">${u("before","Πριν")}${u("after","Μετά")}</div>
    <div class="hint">Η διαγραφή στέλνει το αρχείο και στον Κάδο ανακύκλωσης του OneDrive.</div>`,"menu")}async function VR(n,e,t,s){if(e.size>6e7)return xe.msg="Το αρχείο είναι πολύ μεγάλο (πάνω από 60 MB).",s();xe.busy="Ανέβασμα…",xe.msg="",s();try{const i=await xR(e),r=await th(),a=Pl(n.customer&&n.customer.name);let o=(/\.[a-z0-9]{2,5}$/i.exec(i.name)||[""])[0];i!==e&&(o=".jpg"),t&&!o&&(o=".jpg");const l=t?Pl([n.number||"έργο",a,t==="before"?"ΠΡΙΝ":"ΜΕΤΑ",Date.now().toString(36)].join("_")).slice(0,150)+".jpg":Pl([n.number,a,e.name.replace(/\.[^.]+$/,"")].filter(Boolean).join("_")).slice(0,150)+o.toLowerCase(),u=await DR(r,i,l,t?PR:RR,m=>{xe.busy="Ανέβασμα… "+m+"%",s()}),h=Xd(A.quotes,n.id)||n,p=Date.now().toString(36)+Math.random().toString(36).slice(2,6);t?(sc(h,"photos",fa(h).concat([{id:p,odId:u.id,name:u.name||l,kind:t,size:u.size||i.size,url:u.webUrl||"",ts:Date.now()}])),Su(h,"Φωτογραφία "+(t==="before"?"ΠΡΙΝ":"ΜΕΤΑ")+" στο OneDrive.")):(sc(h,"docs",qi(h).concat([{id:p,odId:u.id,name:u.name||l,orig:e.name,size:u.size||i.size,mime:i.type||"",url:u.webUrl||"",ts:Date.now()}])),Su(h,"Τιμολόγιο στο OneDrive: "+(u.name||l))),xe.busy="",xe.msg=""}catch(i){xe.busy="",xe.msg=i&&i.message||"Το ανέβασμα απέτυχε."}s()}async function OR(n,e,t,s){if(Hs)return t("Στο δοκιμαστικό δεν ανοίγουν αρχεία.");xe.busy="Λήψη…",s();try{const i=await th(),r=await fetch(nc+"/me/drive/items/"+encodeURIComponent(e.odId)+"/content",{headers:{Authorization:"Bearer "+i}});if(r.status===404)throw new Error("Το αρχείο δεν βρέθηκε στο OneDrive (ίσως σβήστηκε από εκεί).");if(!r.ok)throw new Error("Το OneDrive δεν έδωσε το αρχείο ("+r.status+").");const a=await r.arrayBuffer(),o=new Uint8Array(a);let l="";for(let h=0;h<o.length;h+=32768)l+=String.fromCharCode.apply(null,o.subarray(h,h+32768));const u=e.mime||(/\.pdf$/i.test(e.name)?"application/pdf":"application/octet-stream");if(Cn){const h=await be.shareFile({name:e.name,b64:btoa(l),mime:u,view:!0});if(h&&h.error)throw new Error(h.error)}else{const h=URL.createObjectURL(new Blob([a],{type:u})),p=document.createElement("a");p.href=h,p.download=e.name,p.click(),setTimeout(()=>URL.revokeObjectURL(h),5e3)}xe.busy=""}catch(i){xe.busy="",xe.msg=i&&i.message||"Η λήψη απέτυχε."}s()}async function MR(n,e,t){const[s,i]=e.split(":"),r=(s==="ph"?fa(n):qi(n)).find(a=>a.id===i);if(r&&confirm("Να αφαιρεθεί «"+r.name+`»;
Θα πάει και στον Κάδο ανακύκλωσης του OneDrive (μπορείς να το επαναφέρεις από εκεί).`)){xe.busy="Αφαίρεση…",xe.msg="",t();try{if(!Hs){const a=await th(),o=await fetch(nc+"/me/drive/items/"+encodeURIComponent(r.odId),{method:"DELETE",headers:{Authorization:"Bearer "+a}});if(!o.ok&&o.status!==404)throw new Error("Το OneDrive δεν το έσβησε ("+o.status+").")}s==="ph"?sc(n,"photos",fa(n).filter(a=>a.id!==i)):sc(n,"docs",qi(n).filter(a=>a.id!==i)),Su(n,"Αφαιρέθηκε "+(s==="ph"?"φωτογραφία":"τιμολόγιο")+": "+r.name)}catch(a){xe.msg=a&&a.message||"Η διαγραφή απέτυχε."}xe.busy="",t()}}const bb=()=>Xd(A.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));function LR(n,e,t){const s=n.closest("[data-fl],[data-fl-open],[data-fl-del]");if(!s)return!1;const i=s.dataset,r=bb();return i.fl==="login"?be.filesLogin():i.fl==="logout"?confirm("Αποσύνδεση του OneDrive από την εφαρμογή;")&&be.filesDisconnect().then(()=>eh(e)):r&&i.flOpen?OR(r,qi(r).find(a=>a.id===i.flOpen),t,e):r&&i.flDel&&MR(r,i.flDel,e),!0}function FR(n,e){const t=n.dataset;if(!("flDoc"in t)&&!t.flPh)return!1;const s=n.files&&n.files[0],i=bb();return n.value="",s&&i&&VR(i,s,t.flPh||"",e),!0}const gn=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),It={list:null,err:"",busy:!1};function UR(n){It.busy||(It.busy=!0,HS().then(e=>{It.list=e,It.err=""},()=>{It.err="Δεν φορτώθηκαν τα μηνύματα. Έλεγξε τη σύνδεση.",It.list=It.list||[]}).finally(()=>{It.busy=!1,n()}))}function qR(n,e){const t=It.list,s=(t||[]).filter(i=>!i.read).length;return e(n("Μηνύματα ιστοσελίδας",s?s+" νέα":"",'<a class="ib" href="#/menu">←</a>'),`${It.err?`<div class="err box">${gn(It.err)}</div>`:""}<div class="card">${(t||[]).map(i=>{const r=String(i.phone||"").replace(/[^\d+]/g,""),a=i.at?new Date(i.at).toLocaleString("el-GR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"";return`<div class="item" style="align-items:flex-start;${i.read?"opacity:.7":""}"><div class="t" style="white-space:normal"><b>${i.read?"":"● "}${gn(i.name)}</b><span>${gn(a)}${[i.svc,i.area,i.day].filter(Boolean).length?" · "+[i.svc,i.area,i.day].filter(Boolean).map(gn).join(" · "):""}</span>
        <div style="margin:6px 0;white-space:pre-wrap">${gn(i.msg)}</div>
        <div class="actions">${r?`<a class="btn b2 sm" href="tel:${gn(r)}">📞 ${gn(i.phone)}</a>`:""}${i.email?`<a class="btn b2 sm" href="mailto:${gn(i.email)}">✉️ Email</a>`:""}${i.read?"":`<button class="btn b2 sm" data-mread="${gn(i.id)}">✔ Διαβάστηκε</button>`}</div></div></div>`}).join("")||`<div class="empty">${t?"Κανένα μήνυμα ακόμα.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Η διαγραφή μηνυμάτων γίνεται από το PWA.</div>`,"menu")}function BR(n,e){const t=n.closest("[data-mread]");if(!t)return!1;const s=(It.list||[]).find(i=>i.id===t.dataset.mread);return s&&(s.read=!0,QS(s.id)),e(),!0}const X=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),jR=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),lt=n=>jR.format(Math.round((n||0)*100)/100),we=n=>String(q(k(n))).replace(".",","),Wt=n=>k(String(n??"").replace(",","."),NaN),Tm=n=>n<10?"0"+n:""+n,nh=n=>n.getFullYear()+"-"+Tm(n.getMonth()+1)+"-"+Tm(n.getDate()),ss=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},WR=n=>{try{return new Date(n+"T12:00").toLocaleDateString("el-GR",{weekday:"short"})}catch{return""}},Te=(n,e)=>(n||[]).find(t=>t.id===e),zR=["Ιανουάριος","Φεβρουάριος","Μάρτιος","Απρίλιος","Μάιος","Ιούνιος","Ιούλιος","Αύγουστος","Σεπτέμβριος","Οκτώβριος","Νοέμβριος","Δεκέμβριος"],GR=n=>{const e=n.split("-");return zR[+e[1]-1]+" "+e[0]},ls=n=>!!Fr[n]||!!A[n].length,M={openNext:"",emp:"",month:"",f:null,stTab:"stock",stQ:"",stAll:!1,sheet:null,inQ:""},sh=()=>!!M.f||!!M.sheet;function KR(){M.f=null,M.sheet=null}function ic(n){let e=0,t=0,s=0;return A.wdays.forEach(i=>{i.empId===n&&(e+=k(i.amount),s+=k(i.days))}),A.wpays.forEach(i=>{i.empId===n&&(t+=k(i.amount))}),{earned:q(e),paid:q(t),bal:q(e-t),days:q(s)}}function Am(n){if(!n||!n.from||!n.until)return null;const e=n.from.split(":"),t=n.until.split(":");let s=+t[0]*60+ +t[1]-(+e[0]*60+ +e[1]);return s<=0&&(s+=1440),{txt:n.from+"–"+n.until,h:q(s/60)}}const ih=()=>A.emps.filter(n=>n.name&&(!Ie()||n.id===Kt())).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),"el")),Un=n=>n?JSON.parse(JSON.stringify(n)):null;function ri(n,e,t,s,i){if(Ie())return;const r=i||s||{},a=n==="emps"?t:r.empId||"",o=Te(A.emps,a);Ge("pbuys",{id:ze(),ts:Date.now(),kind:"hist",area:"wages",coll:n,act:e,recId:t,empId:a,empName:n==="emps"?r.name||"":o&&o.name||"",partner:"",at:new Date().toISOString(),before:Un(s),after:Un(i)})}const $l=(n,e)=>Object.keys({...n,...e}).some(t=>t!=="id"&&t!=="ts"&&JSON.stringify(n[t])!==JSON.stringify(e[t]));function HR(n,e){const t=ih();if(Ie()){const r=t[0];return r?_b(r.id,n,e,!0):e(n("Μεροκάματα",""),`<div class="card"><div class="empty">${ls("emps")?"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει.":"Φόρτωση…"}</div></div>`,"menu")}const s=t.reduce((r,a)=>r+Math.max(0,ic(a.id).bal),0),i=`<div class="kpis"><div class="kpi"><b class="${s>0?"bad":""}">${lt(s)}</b><span>Χρωστάω σε υπαλλήλους</span></div><div class="kpi"><b>${t.length}</b><span>Υπάλληλοι</span></div></div>
    <div class="card">${t.map(r=>{const a=ic(r.id);return`<a class="row" href="#/wage/${encodeURIComponent(r.id)}"><div class="av">👷</div><div class="t"><b>${X(r.name)}</b><span>${lt(r.rate||0)} / ημέρα · ${we(a.days)} ημέρες</span></div>
      <div class="r"><div class="amt ${a.bal>.004?"bad":""}">${a.bal>.004?lt(a.bal):a.bal<-.004?"−"+lt(-a.bal):"✓"}</div><span class="muted">${a.bal>.004?"του χρωστάω":a.bal<-.004?"προπληρωμή":"τακτοποιημένο"}</span></div></a>`}).join("")||`<div class="empty">${ls("emps")?"Δεν υπάρχουν υπάλληλοι.":"Φόρτωση…"}</div>`}</div>
    <button class="btn b2 wide" data-wa="emp-new">＋ Νέος υπάλληλος</button>
    <div class="hint" style="margin-top:10px">Η διαγραφή μεροκάματων/πληρωμών γίνεται από το PWA, που τις κρατά στον κάδο.</div>`;return e(n("Μεροκάματα","Υπάλληλοι · υπόλοιπα"),i+Ib(),"menu",'<button class="fab" data-wa="work-new" aria-label="Νέο μεροκάματο">＋</button>')}function _b(n,e,t,s){const i=Te(A.emps,n);if(!i)return t(e("Υπάλληλος","",'<a class="ib" href="#/wages">←</a>'),`<div class="card"><div class="empty">${ls("emps")?"Δεν βρέθηκε.":"Φόρτωση…"}</div></div>`,null);const r=ic(n),a=!Ie(),o=[];A.wdays.forEach(E=>{E.empId===n&&o.push({t:"work",id:E.id,date:E.date,ts:E.ts||0,amt:k(E.amount),desc:(Am(E)?Am(E).txt+" · ":"")+we(E.days)+(k(E.days)===1?" ημέρα":" ημέρες")+" × "+lt(E.rate)+(E.note?" · "+E.note:"")})}),A.wpays.forEach(E=>{E.empId===n&&o.push({t:"pay",id:E.id,date:E.date,ts:E.ts||0,amt:-k(E.amount),desc:(E.method==="bank"?"Τράπεζα":"Μετρητά")+(E.note?" · "+E.note:"")})});const l=[...new Set(o.map(E=>String(E.date).slice(0,7)))].sort().reverse(),u=M.month&&l.includes(M.month)?M.month:"",h=o.filter(E=>!u||String(E.date).startsWith(u)).sort((E,x)=>E.date<x.date?1:E.date>x.date?-1:x.ts-E.ts),p=h.filter(E=>E.amt>0).reduce((E,x)=>E+x.amt,0),m=h.filter(E=>E.amt<0).reduce((E,x)=>E-x.amt,0),w=`<div class="kpis"><div class="kpi"><b class="${r.bal>.004?"bad":""}">${lt(r.bal)}</b><span>${s?"Μου χρωστάνε":"Του χρωστάω"}</span></div><div class="kpi"><b>${we(r.days)}</b><span>Ημέρες συνολικά</span></div>
    <div class="kpi"><b>${lt(r.earned)}</b><span>Μεροκάματα</span></div><div class="kpi"><b>${lt(r.paid)}</b><span>Πληρωμές</span></div></div>
    <div class="actions"><button class="btn b1" data-wa="work-new" data-emp="${X(n)}">＋ Μεροκάματο</button>${a?`<button class="btn b2" data-wa="pay-new" data-emp="${X(n)}">💶 Πληρωμή</button>`:""}</div>
    ${l.length>1?`<div class="chips"><button data-wm="" class="${u?"":"on"}">Όλοι οι μήνες</button>${l.map(E=>`<button data-wm="${E}" class="${u===E?"on":""}">${GR(E)}</button>`).join("")}</div>`:""}
    <div class="card">${h.map(E=>`<${a?`button class="row prow" data-wa="${E.t}-edit" data-id="${X(E.id)}"`:'div class="row"'}><div class="av">${E.t==="work"?"🛠️":"💶"}</div>
      <div class="t"><b>${ss(E.date)} · ${WR(E.date)}</b><span>${X(E.desc)}</span></div><div class="r"><div class="amt ${E.amt<0?"ok":""}">${E.amt>0?"+":"−"}${lt(Math.abs(E.amt))}</div><span class="muted">${E.t==="work"?"μεροκάματο":"πληρωμή"}</span></div></${a?"button":"div"}>`).join("")||`<div class="empty">${ls("wdays")?"Καμία κίνηση.":"Φόρτωση…"}</div>`}
    ${h.length?`<div class="tot"><span>Μεροκάματα ${lt(p)} · Πληρωμές ${lt(m)}</span><b>${lt(p-m)}</b></div>`:""}</div>
    ${a?`<button class="btn b2 wide" data-wa="emp-edit" data-emp="${X(n)}">✏️ Στοιχεία υπαλλήλου</button>`:'<div class="hint">Τα μεροκάματα που καταχωρείς μπαίνουν με το ημερομίσθιο που έχει ορίσει ο διαχειριστής. Αλλαγές και πληρωμές τις κάνει εκείνος.</div>'}`;return t(e(i.name,`${lt(i.rate||0)} / ημέρα`,s?"":'<a class="ib" href="#/wages">←</a>'),w+Ib(),s?"menu":null)}function QR(n,e,t){const s=[],i=n.split("-"),r=e.split("-"),a=new Date(+i[0],+i[1]-1,+i[2],12),o=new Date(+r[0],+r[1]-1,+r[2],12);for(;a<=o&&s.length<93;){const l=a.getDay();t&&(l===0||l===6)||s.push(nh(a)),a.setDate(a.getDate()+1)}return s}function wb(n){return n.date?n.id||!n.to||n.to<=n.date?[n.date]:QR(n.date,n.to,!!n.skipWe):[]}function ai(n,e,t){const s=e||(Ie()?Kt():M.emp)||(ih()[0]||{}).id||"";if(n==="work"){const i=t&&Te(A.wdays,t),r=Te(A.emps,i?i.empId:s);M.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,days:we(i.days),rate:we(i.rate!=null&&i.rate!==""?i.rate:k(i.days)?k(i.amount)/k(i.days):r&&r.rate||0),note:i.note||"",from:i.from||"",until:i.until||""}:{empId:s,date:ye(),to:"",skipWe:!0,days:"1",rate:we(r&&r.rate||0),note:"",from:"",until:""},msg:""}}else if(n==="pay"){const i=t&&Te(A.wpays,t);M.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,amount:we(i.amount),method:i.method||"cash",note:i.note||""}:{empId:s,date:ye(),amount:"",method:"cash",note:""},msg:""}}else{const i=t&&Te(A.emps,t);M.f={kind:"emp",v:i?{id:i.id,name:i.name||"",rate:we(i.rate||0),phone:i.phone||"",email:i.email||""}:{name:"",rate:"",phone:"",email:""},msg:""}}}const kt=(n,e,t="")=>`<label class="f">${e}<input class="in" data-wf="${n}" value="${X(M.f.v[n]??"")}" ${t}></label>`;function Ib(){const n=M.f;if(!n)return"";const e=n.v,t=Ie(),s=ih();let i="",r="";const a=`<label class="f">Υπάλληλος<select class="in" data-wf="empId" ${t||e.id?"disabled":""}>${s.map(o=>`<option value="${X(o.id)}" ${o.id===e.empId?"selected":""}>${X(o.name)}</option>`).join("")}</select></label>`;if(n.kind==="work"){i=e.id?"Διόρθωση μεροκάματου":"Νέο μεροκάματο";const o=wb(e).length,l=Wt(e.days),u=t?k((Te(A.emps,Kt())||{}).rate):Wt(e.rate);r=`${a}<div class="two">${kt("date","Ημερομηνία",'type="date"')}${e.id?"":kt("to","Έως (για πολλές μέρες)",'type="date"')}</div>
      ${!e.id&&e.to&&e.to>e.date?`<label class="chk2"><input type="checkbox" data-wf="skipWe" ${e.skipWe?"checked":""}> Χωρίς Σάββατο/Κυριακή</label>`:""}
      <div class="f">Ημέρες ανά ημερομηνία</div><div class="chips wrap">${["1","0,5","1,5","2"].map(h=>`<button data-wd="${h}" class="${e.days===h?"on":""}">${h}</button>`).join("")}</div>
      <div class="two">${kt("days","Ημέρες",'inputmode="decimal"')}${kt("rate","Ημερομίσθιο €",`inputmode="decimal" ${t?"disabled":""}`)}</div>
      <div class="two">${kt("from","Από ώρα (προαιρετικό)",'type="time"')}${kt("until","Έως ώρα",'type="time"')}</div>
      ${kt("note","Σημείωση",'placeholder="π.χ. εγκατάσταση Βόνιτσα"')}
      <div class="ask">${o?`${o} ${o===1?"ημέρα":"ημέρες"} × ${isNaN(l)?"—":we(l)} × ${lt(isNaN(u)?0:u)} = <b>${lt(q(o*(isNaN(l)?0:l)*(isNaN(u)?0:u)))}</b>`:"Βάλε ημερομηνία."}</div>`}else n.kind==="pay"?(i=e.id?"Διόρθωση πληρωμής":"Πληρωμή στον υπάλληλο",r=`${a}<div class="two">${kt("date","Ημερομηνία",'type="date"')}${kt("amount","Ποσό €",'inputmode="decimal"')}</div>
      <div class="seg">${[["cash","💵 Μετρητά"],["bank","🏦 Τράπεζα"]].map(([o,l])=>`<button data-wpm="${o}" class="${e.method===o?"on":""}">${l}</button>`).join("")}</div>
      ${kt("note","Σημείωση")}${e.empId?`<div class="ask">Του χρωστάω τώρα <b>${lt(ic(e.empId).bal)}</b></div>`:""}`):(i=e.id?"Στοιχεία υπαλλήλου":"Νέος υπάλληλος",r=`${kt("name","Όνομα",'autocomplete="off"')}${kt("rate","Ημερομίσθιο €",'inputmode="decimal"')}${kt("phone","Κινητό",'inputmode="tel"')}${kt("email","Email",'inputmode="email"')}
      ${e.id?'<div class="hint">Η αλλαγή ημερομισθίου ισχύει για τα νέα μεροκάματα· τα παλιά μένουν όπως είναι.</div>':""}`);return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${i}</b><button class="ib dk" data-wa="close">✕</button></div>
    <div class="sheet-list pad">${r}${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-wa="close">Άκυρο</button><button class="btn b1" data-wa="save">💾 Αποθήκευση</button></div></div></div>`}function JR(n){const e=M.f,t=e.v,s=Ie();if(!ls("emps"))return e.msg="Περίμενε να φορτώσουν τα δεδομένα.";if(e.kind==="emp"){const m=String(t.name||"").trim(),w=Wt(t.rate);if(!m)return e.msg="Γράψε όνομα.";if(isNaN(w)||w<0)return e.msg="Βάλε ημερομίσθιο.";const E={name:m,rate:q(w),phone:String(t.phone||"").trim(),email:String(t.email||"").trim()};if(t.id){const x=Un(Te(A.emps,t.id));zt("emps",t.id,E);const C=Te(A.emps,t.id);$l(x,C)&&ri("emps","edit",t.id,x,Un(C))}else{const x={id:ze(),ts:Date.now(),...E};Ge("emps",x),ri("emps","create",x.id,null,x)}return M.f=null,n(t.id?"Ο υπάλληλος ενημερώθηκε.":"Ο υπάλληλος προστέθηκε."),""}const i=s?Kt():t.empId,r=Te(A.emps,i);if(!r)return e.msg="Διάλεξε υπάλληλο.";if(e.kind==="pay"){const m=Wt(t.amount);if(!t.date)return e.msg="Βάλε ημερομηνία.";if(isNaN(m))return e.msg="Βάλε ποσό.";const w={empId:i,date:t.date,amount:q(m),method:t.method==="bank"?"bank":"cash",note:String(t.note||"").trim()};if(t.id){const E=Un(Te(A.wpays,t.id));zt("wpays",t.id,w);const x=Te(A.wpays,t.id);$l(E,x)&&ri("wpays","edit",t.id,E,Un(x))}else{const E={id:ze(),ts:Date.now(),...w};Ge("wpays",E),ri("wpays","create",E.id,null,E)}return M.f=null,n(t.id?"Η πληρωμή ενημερώθηκε.":"Η πληρωμή αποθηκεύτηκε."),""}const a=wb(t);if(!a.length)return e.msg="Βάλε ημερομηνία.";const o=Wt(t.days);let l=Wt(t.rate);if(s&&(l=k(r.rate,0),t.id))return e.msg="Τις αλλαγές τις κάνει ο διαχειριστής.";if(isNaN(o)||o<=0||o>31)return e.msg="Βάλε πόσες ημέρες δούλεψε (π.χ. 1 ή 0,5).";if(isNaN(l))return e.msg="Βάλε ημερομίσθιο.";const u=t.from||"",h=t.until||"";if(!!u!=!!h)return e.msg="Βάλε και τις δύο ώρες (από – έως) ή καμία.";const p={empId:i,days:o,rate:l,amount:q(o*l),note:String(t.note||"").trim(),from:u,until:h};if(t.id){const m=Un(Te(A.wdays,t.id));zt("wdays",t.id,{...p,date:a[0]});const w=Te(A.wdays,t.id);$l(m,w)&&ri("wdays","edit",t.id,m,Un(w))}else{const m=Date.now(),w=ze();a.forEach((E,x)=>{const C={id:w+x,...p,date:E,ts:m+x};Ge("wdays",C),ri("wdays","create",C.id,null,C)})}return M.f=null,n(t.id?"Το μεροκάματο ενημερώθηκε.":a.length===1?"Το μεροκάματο αποθηκεύτηκε.":`Προστέθηκαν ${a.length} μεροκάματα.`),""}function Fc(n,e){let t=0,s=0,i=0,r=0;return A.ldocs.forEach(a=>{a.kind==="purchase"&&a.items&&a.items.forEach(o=>{o.pid===n&&(t+=k(o.qty))})}),A.smoves.forEach(a=>{a.pid===n&&(t+=k(a.qty))}),A.quotes.forEach(a=>{if(a.id===e)return;const o=dt(a);(a.lines||[]).forEach(l=>{if(l.pid!==n||l.src!=="stock")return;const u=k(l.qty);o==="done"?a.noStock||(s+=u):o==="accepted"?i+=u:o==="pending"&&(r+=u)})}),{inQ:q(t),onHand:q(t-s),reserved:q(i),pending:q(r),avail:q(t-s-i)}}const Eb=n=>n&&Array.isArray(n.links)&&n.links.length?n.links:n&&(n.sup||n.url)?[{sup:n.sup||"",url:n.url||""}]:[];function So(){const n={},e=(t,s)=>n[t]||(n[t]={pid:t,qty:0,sup:0,stk:0,qs:[],desc:s||"",why:[]});return A.quotes.forEach(t=>{dt(t)==="accepted"&&(t.lines||[]).forEach(s=>{if(!s.pid||s.src!=="supplier")return;const i=e(s.pid,s.desc);i.sup+=k(s.qty),i.qs.includes(t.number)||i.qs.push(t.number)})}),A.products.forEach(t=>{const s=k(t.minQty,0),i=Fc(t.id),r=Math.max(0,s-i.avail);if(r>.004){const a=e(t.id,t.model);a.stk=q(r),a.why.push(i.avail<0?"λείπουν "+we(-i.avail)+" για δεσμευμένες"+(s?" + ελάχιστο "+we(s):""):"απόθεμα "+we(i.avail)+" < ελάχιστο "+we(s))}}),Object.values(n).map(t=>(t.qty=q(t.sup+t.stk),t.sup&&t.why.unshift(we(t.sup)+" για προσφορές "+t.qs.join(", ")),t)).filter(t=>t.qty>0).sort((t,s)=>{const i=Te(A.products,t.pid),r=Te(A.products,s.pid);return String(i?i.model:t.desc).localeCompare(String(r?r.model:s.desc),"el")})}function YR(){const n={};return So().forEach(e=>{const t=Te(A.products,e.pid),s=t?Eb(t)[0]:null,i=s&&s.sup||"Χωρίς προμηθευτή";(n[i]=n[i]||[]).push("• "+(t?t.model:e.desc)+" × "+we(e.qty))}),Object.keys(n).sort().map(e=>e+`:
`+n[e].join(`
`)).join(`

`)}const XR={in:"Χειροκίνητη εισαγωγή",out:"Χειροκίνητη έξοδος",set:"Διόρθωση αποθέματος"};function ZR(n,e){Ie()&&(M.stTab="needs");const t=Ie()?[["needs","🧰 Εργαλεία που λείπουν"]]:[["stock","📦 Απόθεμα"],["order","🛒 Παραγγελία"],["moves","↕ Κινήσεις"],["needs","🧰 Λείπουν"]],s=M.stTab;let i=t.length>1?`<div class="chips">${t.map(([r,a])=>`<button data-stt="${r}" class="${s===r?"on":""}">${a}${r==="order"&&So().length?` (${So().length})`:""}${r==="needs"?` (${A.needs.filter(o=>!o.gone&&!o.done).length})`:""}</button>`).join("")}</div>`:"";if(s==="stock"){const r=A.products.map(m=>({p:m,i:Fc(m.id)}));let a=0,o=0,l=0,u=0;r.forEach(m=>{m.i.onHand>0&&(a++,o+=m.i.onHand,l+=m.i.onHand*k(m.p.cost)),m.i.avail<0&&u++});const h=Me(M.stQ),p=r.filter(m=>(M.stAll||m.i.inQ!==0||m.i.onHand!==0||m.i.reserved||m.i.pending||k(m.p.minQty,0)>0)&&Me((m.p.cat||"")+" "+m.p.model+" "+(m.p.desc||"")).includes(h)).sort((m,w)=>String(m.p.model).localeCompare(String(w.p.model),"el"));i+=`<div class="kpis"><div class="kpi"><b>${a}</b><span>Είδη στο ράφι</span></div><div class="kpi"><b>${we(o)}</b><span>Τεμάχια</span></div><div class="kpi"><b>${lt(l)}</b><span>Αξία (τιμή αγοράς)</span></div><div class="kpi"><b class="${u?"bad":""}">${u}</b><span>Ελλείψεις</span></div></div>
      <input class="search" id="stq" data-stq placeholder="🔍 Αναζήτηση προϊόντος" value="${X(M.stQ)}">
      <label class="chk2"><input type="checkbox" data-stall ${M.stAll?"checked":""}> Όλα τα προϊόντα του καταλόγου</label>
      <div class="card">${p.slice(0,200).map(({p:m,i:w})=>{const E=k(m.minQty,0);return`<button class="row prow" data-sp="${X(m.id)}">${m.img?`<img class="pth" src="${X(m.img)}" alt="" loading="lazy">`:'<span class="pth ph">📦</span>'}<div class="t"><b>${X(m.model)}</b><span>${X([m.cat,m.desc].filter(Boolean).join(" · "))}${w.reserved?` · δεσμευμένα ${we(w.reserved)}`:""}${w.pending?` · σε προσφορές ${we(w.pending)}`:""}${E?` · ελάχ. ${we(E)}`:""}</span></div>
        <div class="r"><div class="amt">${we(w.onHand)}</div><span class="pill ${w.avail<0?"p-b":E&&w.avail<E?"p-w":w.avail>0?"p-ok":"p-a"}">διαθ. ${we(w.avail)}</span></div></button>`}).join("")||`<div class="empty">${ls("products")?A.products.length?"Δεν υπάρχουν προϊόντα στην αποθήκη. Τσέκαρε «Όλα τα προϊόντα» για να βάλεις απόθεμα.":"Ο κατάλογος είναι άδειος.":"Φόρτωση…"}</div>`}</div>`}else if(s==="order"){const r=So();i+=`<div class="card">${r.map(a=>{const o=Te(A.products,a.pid),l=o?Eb(o):[];return`<div class="item"><div class="t"><b>${X(o?o.model:a.desc)} × ${we(a.qty)}</b><span style="white-space:normal">${X(a.why.join(" · "))}</span>
      ${l.map(u=>`<span>${X(u.sup||"")}${u.code?" · "+X(u.code):""}${/^https?:\/\//.test(u.url||"")?` · <a class="lnk" href="${X(u.url)}">άνοιγμα</a>`:""}</span>`).join("")}</div></div>`}).join("")||'<div class="empty">Τίποτα προς παραγγελία. Εδώ μπαίνουν οι γραμμές «Από προμηθευτή» των δεκτών προσφορών, οι ελλείψεις και ό,τι είναι κάτω από το ελάχιστο απόθεμα.</div>'}</div>
      ${r.length?'<button class="btn b1 wide" data-sa="ocopy">📋 Αντιγραφή λίστας ανά προμηθευτή</button>':""}`}else if(s==="moves"){const r=[];A.smoves.forEach(a=>r.push({date:a.date,ts:a.ts||0,pid:a.pid,qty:k(a.qty),why:XR[a.kind]||"Κίνηση",note:a.note})),A.ldocs.forEach(a=>{a.kind==="purchase"&&a.items&&a.items.forEach(o=>r.push({date:a.date,ts:a.ts||0,pid:o.pid,qty:k(o.qty),why:"Αγορά από "+a.party+(a.number?" ("+a.number+")":""),note:""}))}),r.sort((a,o)=>a.date<o.date?1:a.date>o.date?-1:o.ts-a.ts),i+=`<div class="card">${r.slice(0,80).map(a=>{const o=Te(A.products,a.pid);return`<div class="item"><div class="t"><b>${X(o?o.model:"(διαγραμμένο προϊόν)")}</b><span>${ss(a.date)} · ${X(a.why)}${a.note?" · "+X(a.note):""}</span></div><div class="amt ${a.qty<0?"bad":"ok"}">${a.qty>0?"+":""}${we(a.qty)}</div></div>`}).join("")||'<div class="empty">Δεν υπάρχουν κινήσεις ακόμα.</div>'}</div>`}else i+=nP();return e(n(Ie()?"Εργαλεία που λείπουν":"Αποθήκη",Ie()?"Ό,τι λείπει από το συνεργείο":"Απόθεμα · παραγγελίες · εργαλεία"),i+eP(),"menu",s==="needs"?'<button class="fab" data-na="new" aria-label="Προσθήκη">＋</button>':"")}function eP(){const n=M.sheet;if(!n)return"";if(n.kind==="need"){const a=n.v;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${a.id?"Αλλαγή":"Τι λείπει;"}</b><button class="ib dk" data-na="close">✕</button></div><div class="sheet-list pad">
      <label class="f">Εργαλείο / υλικό<input class="in" data-nf="title" maxlength="120" value="${X(a.title)}" placeholder="π.χ. Κρουστικό δράπανο"></label>
      <div class="two"><label class="f">Ποσότητα<input class="in" data-nf="qty" maxlength="20" value="${X(a.qty)}"></label><label class="f">Σημείωση<input class="in" data-nf="notes" maxlength="300" value="${X(a.notes)}"></label></div>
      ${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}</div><div class="actions"><button class="btn b2" data-na="close">Άκυρο</button><button class="btn b1" data-na="save">💾 Αποθήκευση</button></div></div></div>`}const e=Te(A.products,n.pid);if(!e)return"";const t=Fc(e.id),s=n.v,i=Wt(s.qty),r=isNaN(i)?null:s.type==="in"?t.onHand+i:s.type==="out"?t.onHand-i:i;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${X(e.model)}</b><button class="ib dk" data-sa="close">✕</button></div><div class="sheet-list pad">
    <div class="kpis"><div class="kpi"><b>${we(t.onHand)}</b><span>Στο ράφι</span></div><div class="kpi"><b class="${t.avail<0?"bad":""}">${we(t.avail)}</b><span>Διαθέσιμα (μετά τις δεσμευμένες)</span></div></div>
    <div class="seg">${[["in","➕ Εισαγωγή"],["out","➖ Έξοδος"],["set","✏️ Διόρθωση"]].map(([a,o])=>`<button data-smt="${a}" class="${s.type===a?"on":""}">${o}</button>`).join("")}</div>
    <div class="two"><label class="f">${s.type==="set"?"Πραγματική ποσότητα στο ράφι":"Ποσότητα"}<input class="in" data-sf="qty" inputmode="decimal" value="${X(s.qty)}"></label><label class="f">Ημερομηνία<input class="in" type="date" data-sf="date" value="${X(s.date)}"></label></div>
    <label class="f">Σημείωση<input class="in" data-sf="note" value="${X(s.note)}"></label>
    <div class="ask" id="smprev">Τώρα στο ράφι: ${we(t.onHand)} τεμ.${r!==null&&s.qty!==""?` → μετά: <b>${we(q(r))}</b>`:""}</div>
    <label class="f" style="margin-top:10px">Ελάχιστο απόθεμα (κάτω από αυτό μπαίνει στη λίστα παραγγελίας)<input class="in" data-sf="min" inputmode="decimal" value="${X(s.min)}" placeholder="—"></label>
    ${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-sa="close">Άκυρο</button><button class="btn b1" data-sa="save">💾 Αποθήκευση</button></div></div></div>`}function tP(n){const e=M.sheet,t=e.v,s=Te(A.products,e.pid);if(!s)return M.sheet=null;const i=t.min.trim()===""?0:Math.max(0,Wt(t.min));if(isNaN(i))return e.msg="Το ελάχιστο απόθεμα πρέπει να είναι αριθμός.";let r=[];if(t.qty.trim()!==""){const a=Wt(t.qty);if(isNaN(a)||a<0)return e.msg="Βάλε ποσότητα.";const o=Fc(s.id),l=t.type==="in"?a:t.type==="out"?-a:q(a-o.onHand);if(!l)return e.msg="Δεν υπάρχει αλλαγή στην ποσότητα.";Ge("smoves",{id:ze(),pid:s.id,qty:q(l),kind:t.type,date:t.date||ye(),note:t.note.trim(),ts:Date.now()}),r.push("Η κίνηση αποθηκεύτηκε")}k(s.minQty,0)!==i&&(zt("products",s.id,{minQty:i}),r.push(i?"ελάχιστο "+we(i):"χωρίς ελάχιστο")),M.sheet=null,n(r.length?r.join(" · ")+".":"Καμία αλλαγή.")}const rc=n=>!Ie()||!!(Mi()&&n.by&&n.by.uid===Mi().uid),Sm=n=>n?ss(nh(new Date(n))):"";function nP(){const n=A.needs.filter(i=>!i.gone),e=n.filter(i=>!i.done).sort((i,r)=>(r.ts||0)-(i.ts||0)),t=n.filter(i=>i.done).sort((i,r)=>(r.doneAt||r.ts||0)-(i.doneAt||i.ts||0)),s=(i,r)=>`<div class="tc${r?" dn":""}" style="--c:${r?"var(--ok)":"var(--warn)"}">
    ${Ie()?`<span class="tick${r?" on":""}" style="display:flex;align-items:center;justify-content:center">${r?"✓":""}</span>`:`<button class="tick${r?" on":""}" data-na="done" data-id="${X(i.id)}" aria-label="Παραγγέλθηκε">${r?"✓":""}</button>`}
    <div class="t" style="flex:1"><b>${X(i.title)}${i.qty?" × "+X(i.qty):""}</b><span>${X(i.by&&i.by.name||"—")} · ${X(Sm(i.ts))}${r&&i.doneAt?" · ✔ παραγγέλθηκε "+X(Sm(i.doneAt)):""}${i.notes?" · "+X(i.notes):""}</span></div>
    ${rc(i)?`<button class="x" style="background:var(--accs);color:var(--acc)" data-na="edit" data-id="${X(i.id)}" aria-label="Αλλαγή">✏️</button><button class="x" data-na="gone" data-id="${X(i.id)}" aria-label="Αφαίρεση">✕</button>`:""}</div>`;return`<div class="hint">${Ie()?"Ό,τι γράφεις εδώ το βλέπει και ο διαχειριστής και μπαίνει στη λίστα παραγγελιών του.":"Το PWA τα συγχρονίζει με τη λίστα «Εργαλεία που λείπουν» του Microsoft To Do."}</div>
    <div class="h">Να παραγγελθούν (${e.length})${!Ie()&&e.length?'<a class="hl" data-na="copy">📋 Αντιγραφή</a>':""}</div>
    <div class="card">${e.map(i=>s(i,!1)).join("")||`<div class="empty">${ls("needs")?"Δεν λείπει τίποτα αυτή τη στιγμή.":"Φόρτωση…"}</div>`}</div>
    ${t.length?`<div class="h">Παραγγέλθηκαν (${t.length})</div><div class="card">${t.slice(0,40).map(i=>s(i,!0)).join("")}</div>`:""}`}function sP(n){const e=M.sheet,t=e.v,s=String(t.title||"").trim().slice(0,120);if(!s)return e.msg="Γράψε ποιο εργαλείο λείπει.";const i=Date.now(),r=String(t.qty||"").trim().slice(0,20),a=String(t.notes||"").trim().slice(0,300);if(t.id){const o=Te(A.needs,t.id);if(!o||!rc(o))return M.sheet=null;zt("needs",o.id,{title:s,qty:r,notes:a,by:o.by||{uid:"",name:""},upd:i,dirty:!0}),n("Η καταχώριση ενημερώθηκε.")}else Ge("needs",{id:ze(),ts:i,title:s,qty:r,notes:a,done:!1,gone:!1,msId:"",msList:"",by:ts()||{uid:"",name:"Διαχειριστής"},upd:i,dirty:!0}),n("Προστέθηκε: "+s+".");M.sheet=null}const Tb=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(k(e.m,0))):k(ne()&&ne().warrantyMonths,24)},km=n=>!(n&&n.war&&n.war.on===!1),$s=n=>n.install||{date:n.statusDate||"",months:km(n)?Tb(n):0,serials:"",nw:!km(n)},Uc=(n,e)=>{if(!n)return"";const t=new Date(n+"T00:00:00");return isNaN(t)?"":(t.setMonth(t.getMonth()+k(e,0)),nh(t))};function Rm(n){const e=$s(n);if(e.nw)return{k:"na",t:"Χωρίς εγγύηση",end:""};const t=Uc(e.date,e.months);if(!t)return{k:"na",t:"—",end:""};const s=Math.ceil((new Date(t+"T23:59:59")-Date.now())/864e5);return s<0?{k:"ex",t:"Έληξε",end:t,days:s}:s<=60?{k:"warn",t:"Λήγει σε "+s+" ημ.",end:t,days:s}:{k:"okp",t:"Ενεργή",end:t,days:s}}const iP=n=>{const e=$s(n);return k(e.mt,0)>0?Uc(e.mtLast||e.date,e.mt):""},rP={okp:"p-ok",warn:"p-w",ex:"p-b",na:"p-a"};function aP(n,e){const t=A.quotes.filter(u=>dt(u)==="done").sort((u,h)=>($s(h).date||"")<($s(u).date||"")?-1:1),s={okp:0,warn:0,ex:0};t.forEach(u=>{const h=Rm(u);s[h.k]!=null&&s[h.k]++});const i=Me(M.inQ),r=t.filter(u=>!i||Me([u.number,u.subject,u.customer&&u.customer.name,u.customer&&u.customer.address].join(" ")).includes(i)),a=ye().slice(0,10),o=Uc(a,1),l=`<div class="kpis"><div class="kpi"><b>${t.length}</b><span>Εγκαταστάσεις</span></div><div class="kpi"><b>${s.okp}</b><span>Ενεργές εγγυήσεις</span></div>
    <div class="kpi"><b class="${s.warn?"bad":""}">${s.warn}</b><span>Λήγουν σε 60 ημέρες</span></div><div class="kpi"><b>${s.ex}</b><span>Έληξαν</span></div></div>
    <input class="search" id="inq" data-inq placeholder="🔍 Πελάτης, αριθμός, περιοχή" value="${X(M.inQ)}">
    <div class="card">${r.map(u=>{const h=$s(u),p=Rm(u),m=iP(u),w=u.customer&&u.customer.name||"";return`<button class="row prow" data-ie="${X(u.id)}"><div class="av">${cn(u)?"🛠️":"🛡️"}</div><div class="t"><b>${cn(u)?X(u.subject||"Παλιά εγκατάσταση"):"#"+X(u.number||"—")+" · "+X(w)}</b>
        <span>${cn(u)?X(w)+" · ":u.subject?X(u.subject)+" · ":""}${h.date?"εγκατ. "+ss(h.date):"χωρίς ημερομηνία"}${p.end?" · λήξη "+ss(p.end):""}${m?" · 🔧 "+ss(m):""}</span></div>
        <div class="r"><span class="pill ${rP[p.k]}">${X(p.t)}</span>${m&&m<=o?'<span class="pill p-w">🔧 συντήρηση</span>':""}</div></button>`}).join("")||`<div class="empty">${ls("quotes")?"Δεν υπάρχουν ολοκληρωμένες εγκαταστάσεις.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Βεβαίωση, υπογραφή και κωδικοί εγκατάστασης: από το PWA.</div>`;return e(n("Εγκαταστάσεις","Εγγυήσεις · συντηρήσεις"),l+oP(),"menu")}function oP(){const n=M.sheet;if(!n||n.kind!=="inst")return"";const e=Te(A.quotes,n.id);if(!e)return"";const t=n.v,s=t.nw?"":Uc(t.date,k(t.months,0));return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${cn(e)?X(e.subject||"Εγκατάσταση"):"#"+X(e.number)+" · "+X(e.customer&&e.customer.name||"")}</b><button class="ib dk" data-ia="close">✕</button></div><div class="sheet-list pad">
    <label class="f">Ημερομηνία εγκατάστασης<input class="in" type="date" data-if="date" value="${X(t.date)}"></label>
    <label class="chk2"><input type="checkbox" data-if="war" ${t.nw?"":"checked"}> Με εγγύηση</label>
    ${t.nw?"":`<label class="f">Μήνες εγγύησης<input class="in" data-if="months" inputmode="numeric" value="${X(t.months)}"></label><div class="hint">Λήξη: <b>${s?ss(s):"—"}</b></div>`}
    <a class="btn b2 wide" href="#/files/${encodeURIComponent(e.id)}">🧾 Τιμολόγια & φωτογραφίες (${(e.install&&e.install.docs||[]).length}/${(e.install&&e.install.photos||[]).length})</a>
    <a class="btn b2 wide" href="#/sn/${encodeURIComponent(e.id)}">🔢 Σειριακοί (${(e.install&&e.install.sns||[]).length})</a>
    <div class="f">🔧 Περιοδική συντήρηση</div><div class="chips wrap">${[[0,"Καμία"],[6,"Κάθε 6 μήνες"],[12,"Κάθε 12 μήνες"]].map(([i,r])=>`<button data-imt="${i}" class="${k(t.mt,0)===i?"on":""}">${r}</button>`).join("")}</div>
    ${k(t.mt,0)?`<label class="f">Τιμή συντήρησης €<input class="in" data-if="mtp" inputmode="decimal" value="${X(t.mtp)}" placeholder="π.χ. 120"></label>`:""}
    ${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}
    <a class="btn b2 wide" href="#/q/${encodeURIComponent(e.id)}">📄 Άνοιγμα ${cn(e)?"έργου":"προσφοράς"}</a></div>
    <div class="actions"><button class="btn b2" data-ia="close">Άκυρο</button><button class="btn b1" data-ia="save">💾 Αποθήκευση</button></div></div></div>`}function cP(n){const e=M.sheet,t=Te(A.quotes,e.id);if(!t)return M.sheet=null;const s=e.v,i=Ce($s(t));if(i.date=s.date||"",i.nw=!!s.nw,!i.nw){const a=Math.floor(Wt(s.months));if(isNaN(a)||a<0)return e.msg="Βάλε μήνες εγγύησης.";i.months=a}const r=Math.max(0,Math.floor(k(s.mt,0)));if(r){i.mt=r;const a=Wt(s.mtp);a>0?i.mtp=q(a):delete i.mtp}else delete i.mt,delete i.mtLast,delete i.mtp;zt("quotes",t.id,{install:i}),M.sheet=null,n("Αποθηκεύτηκε.")}function Ab(n){const e=Te(A.products,n);return e?(M.stTab="stock",M.sheet={kind:"stock",pid:n,v:{type:"in",qty:"",date:ye(),note:"",min:k(e.minQty,0)?we(e.minQty):""},msg:""},!0):!1}function lP(n,e,t){const s=n.closest("[data-wa],[data-wm],[data-wd],[data-wpm],[data-stt],[data-sp],[data-sa],[data-smt],[data-na],[data-ie],[data-ia],[data-imt]");if(!s)return!1;const i=s.dataset;if(i.wa){const r=i.wa;r==="close"?M.f=null:r==="save"?JR(t):r==="work-new"?ai("work",i.emp):r==="pay-new"?ai("pay",i.emp):r==="work-edit"?ai("work","",i.id):r==="pay-edit"?ai("pay","",i.id):r==="emp-new"?ai("emp"):r==="emp-edit"&&ai("emp","",i.emp)}else if(i.wm!==void 0)M.month=i.wm;else if(i.wd)M.f&&(M.f.v.days=i.wd);else if(i.wpm)M.f&&(M.f.v.method=i.wpm);else if(i.stt)M.stTab=i.stt;else if(i.sp){const r=Te(A.products,i.sp);M.sheet={kind:"stock",pid:i.sp,v:{type:"in",qty:"",date:ye(),note:"",min:r&&k(r.minQty,0)?we(r.minQty):""},msg:""}}else if(i.smt)M.sheet&&(M.sheet.v.type=i.smt);else if(i.sa){if(i.sa==="close")M.sheet=null;else if(i.sa==="save")tP(t);else if(i.sa==="ocopy"){const r=YR();return r&&(be.copy("Λίστα παραγγελίας ("+ss(ye())+`)

`+r),t("Η λίστα αντιγράφηκε, ανά προμηθευτή.")),!0}}else if(i.na){const r=i.id&&Te(A.needs,i.id);if(i.na==="close")M.sheet=null;else if(i.na==="new")M.sheet={kind:"need",v:{title:"",qty:"",notes:""},msg:""};else if(i.na==="edit"&&r&&rc(r))M.sheet={kind:"need",v:{id:r.id,title:r.title||"",qty:r.qty||"",notes:r.notes||""},msg:""};else if(i.na==="save")sP(t);else if(i.na==="done"&&r&&!Ie()){const a=!r.done,o=Date.now();zt("needs",r.id,{done:a,doneAt:a?o:void 0,upd:o,dirty:!0}),t(a?"Σημειώθηκε ως παραγγελμένο.":"Ξαναμπήκε στη λίστα.")}else if(i.na==="gone"&&r&&rc(r))zt("needs",r.id,{gone:!0,upd:Date.now(),dirty:!0}),t("Αφαιρέθηκε: "+r.title,{label:"Αναίρεση",fn:()=>{zt("needs",r.id,{gone:!1,msId:"",upd:Date.now(),dirty:!0}),e()}});else if(i.na==="copy"){const a=A.needs.filter(o=>!o.gone&&!o.done).sort((o,l)=>(o.ts||0)-(l.ts||0)).map(o=>"• "+o.title+(o.qty?" × "+o.qty:"")+(o.notes?" ("+o.notes+")":"")).join(`
`);return a&&(be.copy(a),t("Η λίστα αντιγράφηκε.")),!0}}else if(i.ie){const r=Te(A.quotes,i.ie);if(r){const a=$s(r);M.sheet={kind:"inst",id:r.id,v:{date:a.date||"",nw:!!a.nw,months:String(k(a.months,Tb(r))),mt:k(a.mt,0),mtp:a.mtp?we(a.mtp):""},msg:""}}}else i.imt!==void 0?M.sheet&&(M.sheet.v.mt=+i.imt):i.ia&&(i.ia==="close"?M.sheet=null:i.ia==="save"&&cP(t));return e(),!0}function uP(n,e){const t=n.dataset,s=i=>{e();const r=document.getElementById(i);r&&(r.focus(),r.setSelectionRange(r.value.length,r.value.length))};return"stq"in t?(M.stQ=n.value,s("stq"),!0):"inq"in t?(M.inQ=n.value,s("inq"),!0):t.wf&&M.f?(M.f.v[t.wf]=n.type==="checkbox"?n.checked:n.value,M.f.msg="",!0):t.nf&&M.sheet?(M.sheet.v[t.nf]=n.value,!0):t.sf&&M.sheet?(M.sheet.v[t.sf]=n.value,!0):t.if&&M.sheet?(M.sheet.v[t.if]=n.value,!0):!1}function dP(n,e){const t=n.dataset;if("stall"in t)return M.stAll=n.checked,e(),!0;if(t.wf&&M.f){if(M.f.v[t.wf]=n.type==="checkbox"?n.checked:n.value,t.wf==="empId"&&!M.f.v.id&&M.f.kind==="work"){const s=Te(A.emps,n.value);s&&(M.f.v.rate=we(s.rate||0))}return e(),!0}return t.sf&&M.sheet?(M.sheet.v[t.sf]=n.value,e(),!0):t.if&&M.sheet?(t.if==="war"?M.sheet.v.nw=!n.checked:M.sheet.v[t.if]=n.value,e(),!0):!1}const Mt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),hP=n=>String(Math.round(k(n)*100)/100).replace(".",","),is=(n,e)=>(n||[]).find(t=>t.id===e),fP=["ean_13","ean_8","upc_a","upc_e","EAN_13","EAN_8","UPC_A","UPC_E"],W={stream:null,det:null,zx:null,t:0,ref:"",label:"",last:"",lastT:0,lastDup:"",added:[],track:null,torch:!1,qid:""},rh=()=>!!W.stream||!!document.getElementById("scan-ov"),Pm=n=>!(n&&n.war&&n.war.on===!1),pP=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(k(e.m,0))):k((ne()||{}).warrantyMonths,24)},mP=n=>n.install||{date:n.statusDate||"",months:Pm(n)?pP(n):0,serials:"",nw:!Pm(n)};function Sb(n){const e=[],t={};return(n.lines||[]).forEach((s,i)=>{const r=s.pid?"p:"+s.pid:"l:"+i;if(t[r]){t[r].qty+=k(s.qty,0);return}t[r]={ref:r,label:s.desc||"(χωρίς περιγραφή)",qty:k(s.qty,0)},e.push(t[r])}),e}const ah=(n,e)=>{const t=Sb(n).find(s=>s.ref===e);return t?t.label:""},Dl=(n,e)=>Ge("qlog",{id:ze(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:e});function ac(n,e){n.install?Yo("quotes",n.id,"install.sns",e):Yo("quotes",n.id,"install",{...mP(n),sns:e})}const kb=n=>String(n||"").split(/[\r\n]+/)[0].trim().replace(/^(S\/?N|SN|SER(IAL)?(\s*NO\.?)?)\s*[:#.\-]?\s*/i,"").replace(/\s+/g," ").trim(),gP=n=>/^([0-9A-F]{2}[:\-]?){5}[0-9A-F]{2}$/i.test(n);function Rb(n,e,t,s,i){if(!i&&fP.includes(s))return"skip";const r=i?String(t||"").trim():kb(t);if(!r||r.length<3||r.length>64||!i&&(gP(r)||/^https?:\/\//i.test(r)))return"skip";const a=(n.install&&n.install.sns||[]).slice(),o=r.toUpperCase();if(a.some(u=>String(u.sn).toUpperCase()===o))return"dup";const l={id:ze(),sn:r,ref:e,item:ah(n,e),name:"",ts:Date.now()};return a.push(l),W.added.push(l.id),ac(n,a),"added"}function yP(n,e,t){const s=is(A.quotes,n);if(!s)return t(e("Σειριακοί","",'<a class="ib" href="#/inst">←</a>'),'<div class="empty">Δεν βρέθηκε</div>',"menu");const i=s.install&&s.install.sns||[],r=Sb(s),a={};r.forEach(l=>a[l.ref]=1);const o=i.filter(l=>!a[l.ref]);return o.length&&r.push({ref:"__other",label:"Άλλα (προϊόντα που δεν υπάρχουν πια στην προσφορά)",qty:0}),t(e("Σειριακοί",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,'<a class="ib" href="#/inst">←</a>'),'<div class="hint">Πάτα «📷 Σάρωση» στο προϊόν και σκάναρε τα barcode ή QR των συσκευών. Δίπλα σε κάθε σειριακό γράψε όνομα θέσης (π.χ. «Κάμερα εισόδου»).</div>'+r.map(l=>{const u=l.ref==="__other"?o:i.filter(h=>h.ref===l.ref);return`<div class="card pad sn-g"><div class="sn-h"><div><b>${Mt(l.label)}</b> <span class="muted">(${u.length}${l.qty?" / "+hP(l.qty):""})</span></div>${l.ref==="__other"?"":`<button class="btn b1 sm" data-sn-scan="${Mt(l.ref)}">📷 Σάρωση</button>`}</div>
      ${u.map(h=>`<div class="sn-row"><code>${Mt(h.sn)}</code><input class="in" data-sn-name="${Mt(h.id)}" value="${Mt(h.name||"")}" placeholder="Όνομα / θέση"><button class="ib dk" data-sn-del="${Mt(h.id)}" aria-label="Διαγραφή">🗑️</button></div>`).join("")}
      ${l.ref==="__other"?"":`<div class="sn-add"><input class="in" data-sn-add="${Mt(l.ref)}" placeholder="ή πληκτρολόγησε σειριακό" autocapitalize="characters" spellcheck="false"><button class="btn b2 sm" data-sn-addb="${Mt(l.ref)}">＋</button></div>`}</div>`}).join("")||'<div class="empty">Η προσφορά δεν έχει γραμμές.</div>',"menu")}let Cm=null;const vP=()=>Cm||(Cm=Fn(()=>import("./zxing-CRxvinjV.js"),[]).then(n=>new Function(n.default+"; return ZXing;")()));function Pb(){try{const n=window.AudioContext||window.webkitAudioContext;W.ac=W.ac||new n;const e=W.ac.createOscillator(),t=W.ac.createGain();e.frequency.value=1250,t.gain.value=.12,e.connect(t),t.connect(W.ac.destination),e.start(),e.stop(W.ac.currentTime+.09)}catch{}}function bP(){let n=document.getElementById("scan-ov");return n||(n=document.createElement("div"),n.id="scan-ov",document.body.appendChild(n)),n}function oh(){const n=is(A.quotes,W.qid),e=n?(n.install&&n.install.sns||[]).filter(i=>i.ref===W.ref).length:0,t=document.getElementById("sc-count");t&&(t.textContent=`Σκαναρισμένοι σε αυτό το προϊόν: ${e} · σε αυτή τη σάρωση: ${W.added.length}`);const s=document.getElementById("sc-undo");s&&(s.disabled=!W.added.length)}const _P=n=>String(n.code||"").split(/[\s,;]+/).filter(Boolean).map(e=>e.toUpperCase()),wP=n=>{const e=String(n).trim().toUpperCase();return e&&(A.products.find(t=>_P(t).includes(e))||A.products.find(t=>String(t.model||"").trim().toUpperCase()===e))||null};function Cb(n){const e=String(n||"").split(/[\r\n]+/)[0].trim();if(!e||e.length>64)return;const t=Date.now();if(e===W.last&&t-W.lastT<1800)return;W.last=e,W.lastT=t;const s=wP(e),i=document.getElementById("sc-last"),r=document.getElementById("sc-flash");if(s){try{navigator.vibrate&&navigator.vibrate(80)}catch{}Pb();const a=W.rerender;ch(),location.hash.startsWith("#/stock")?(Ab(s.id),a&&a()):(M.openNext=s.id,location.hash="#/stock")}else r&&(r.className="dup",setTimeout(()=>r.className="",350)),i&&(i.innerHTML="❓ Άγνωστος κωδικός <b>"+Mt(e)+"</b>")}function $m(n,e,t){if(W.mode==="find")return Cb(n);const s=is(A.quotes,W.qid);if(!s)return;const i=Date.now(),r=kb(n);if(r===W.last&&i-W.lastT<2500)return;const a=Rb(s,W.ref,n,e,!1);if(a==="skip")return;W.last=r,W.lastT=i;const o=document.getElementById("sc-last"),l=document.getElementById("sc-flash"),u=h=>{l&&(l.className=h,setTimeout(()=>l.className="",350))};if(a==="added"){W.lastDup=r;try{navigator.vibrate&&navigator.vibrate(90)}catch{}Pb(),u("ok"),o&&(o.innerHTML="✅ <b>"+Mt(r)+"</b>")}else r!==W.lastDup&&(W.lastDup=r,u("dup"),o&&(o.innerHTML="Υπάρχει ήδη: <b>"+Mt(r)+"</b>"));oh()}async function Dm(n,e,t,s){const i=n==="",r=is(A.quotes,n);if(!r&&!i)return;if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return t("Η κάμερα δεν είναι διαθέσιμη εδώ.");Object.assign(W,{mode:i?"find":"sn",qid:n,ref:e,label:i?"Σάρωση προϊόντος":ah(r,e),added:[],last:"",lastT:0,lastDup:"",rerender:s});const a=bP();a.innerHTML=`<div class="sc-top"><b id="sc-title">${Mt(W.label)}</b><button class="ib dk" data-sc="close">✕</button></div><video id="sc-video" playsinline muted></video><div id="sc-flash"></div>
  <div class="sc-bot"><div id="sc-last">${i?"Σκάναρε το barcode ενός προϊόντος για να δεις το απόθεμά του.":"Στρέψε την κάμερα στο barcode ή στο QR του σειριακού."}</div><div id="sc-count"></div>
  <div class="sc-btns">${i?"":'<button class="btn b2" data-sc="undo" id="sc-undo" disabled>↶ Αναίρεση</button>'}<button class="btn b2" data-sc="torch" id="sc-torch" hidden>🔦</button><button class="btn b1" data-sc="close">Τέλος</button></div></div>`,a.onclick=o=>$b(o.target,s,t),oh();try{const o=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920},height:{ideal:1080}},audio:!1});if(!document.getElementById("scan-ov")){o.getTracks().forEach(h=>h.stop());return}W.stream=o,W.track=o.getVideoTracks()[0];const l=document.getElementById("sc-video");l.srcObject=o,l.muted=!0,await l.play();try{const h=W.track.getCapabilities&&W.track.getCapabilities();h&&h.torch&&(document.getElementById("sc-torch").hidden=!1)}catch{}let u=!1;if("BarcodeDetector"in window)try{const h=(await Promise.race([BarcodeDetector.getSupportedFormats(),new Promise((p,m)=>setTimeout(()=>m(1),1500))])).filter(p=>p!=="unknown");if(h.length){W.det=new BarcodeDetector({formats:h}),u=!0;const p=()=>{!W.stream||!W.det||W.det.detect(l).then(m=>(m||[]).forEach(w=>$m(w.rawValue,w.format,t)),()=>{}).then(()=>{W.stream&&(W.t=setTimeout(p,160))})};p()}}catch{}if(!u){const h=await vP();if(!W.stream)return;W.zx=new h.BrowserMultiFormatReader,l.srcObject=null,W.zx.decodeFromStream(W.stream,l,p=>{if(p){let m="";try{m=h.BarcodeFormat[p.getBarcodeFormat()]||""}catch{}$m(p.getText(),m,t)}})}}catch(o){ch(),t(o&&o.name==="NotAllowedError"?"Δεν δόθηκε άδεια για την κάμερα. Δώσ' την από τις ρυθμίσεις του κινητού.":"Δεν άνοιξε η κάμερα.")}}function ch(){if(clearTimeout(W.t),W.det=null,W.zx){try{W.zx.reset()}catch{}W.zx=null}W.stream&&(W.stream.getTracks().forEach(e=>e.stop()),W.stream=null),W.track=null,W.torch=!1;const n=document.getElementById("scan-ov");n&&n.remove()}function $b(n,e,t){const s=n.closest("[data-sn-scan],[data-sn-del],[data-sn-addb],[data-sc],[data-bcscan]");if(!s)return!1;if(s.dataset.bcscan!==void 0)return Dm("","",t,e),!0;const i=s.dataset,r=location.hash.replace(/^#\//,"").split("/");if(i.sc){if(i.sc==="close"){const o=is(A.quotes,W.qid),l=W.added.length;ch(),o&&l&&W.mode!=="find"&&(Dl(o,"Σάρωση σειριακών: "+l+" για «"+W.label+"»"),t("Προστέθηκαν "+l+" σειριακοί.")),e()}else if(i.sc==="undo"){const o=is(A.quotes,W.qid);if(o&&W.added.length){const l=W.added.pop();ac(o,(o.install&&o.install.sns||[]).filter(u=>u.id!==l)),W.last="",oh()}}else i.sc==="torch"&&W.track&&(W.torch=!W.torch,W.track.applyConstraints({advanced:[{torch:W.torch}]}).catch(()=>W.torch=!1));return!0}const a=is(A.quotes,decodeURIComponent(r[1]||""));if(!a)return!0;if(i.snScan)Dm(a.id,i.snScan,t,e);else if(i.snDel){const o=(a.install&&a.install.sns||[]).find(l=>l.id===i.snDel);o&&confirm("Διαγραφή του σειριακού "+o.sn+";")&&(ac(a,a.install.sns.filter(l=>l.id!==i.snDel)),Dl(a,"Διαγραφή σειριακού "+o.sn),e())}else if(i.snAddb){const o=document.querySelector(`[data-sn-add="${CSS.escape(i.snAddb)}"]`),l=o&&o.value,u=Rb(a,i.snAddb,l,"",!0);u==="dup"?t("Αυτός ο σειριακός υπάρχει ήδη."):u==="skip"?t("Γράψε έναν σειριακό αριθμό."):(Dl(a,"Σειριακός "+String(l).trim()+" ("+ah(a,i.snAddb)+")"),e())}return!0}function IP(n){if(!n.dataset.snName)return!1;const e=is(A.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));if(!e||!e.install)return!0;const t=(e.install.sns||[]).map(s=>s.id===n.dataset.snName?{...s,name:n.value.trim()}:s);return ac(e,t),!0}const EP="TechMate · Κάμερες, δίκτυα και έξυπνες εγκαταστάσεις",TP="TechMate – Powered by Smart Electric. Εγκατάσταση καμερών ασφαλείας, WiFi και δικτύων, συναγερμών και έξυπνων λύσεων για σπίτια και επιχειρήσεις.",AP="Ασφάλεια · Δίκτυα · Έξυπνες λύσεις",SP="Τεχνολογία που",kP="δουλεύει",RP="εγκατάσταση που κρατάει.",PP="Κάμερες ασφαλείας, WiFi και δίκτυα, συναγερμοί και έξυπνο σπίτι για κατοικίες και επιχειρήσεις. Μελέτη, εγκατάσταση και υποστήριξη από ένα συνεργείο.",CP="Smart Electric",$P=[{ic:"📷",t:"Δωρεάν αυτοψία & προσφορά",s:"Live προσφορά που τη βλέπετε online"},{ic:"🛡️",t:"Εγγύηση εγκατάστασης",s:"24 μήνες σε εξοπλισμό και εργασία"},{ic:"📱",t:"Προβολή από το κινητό",s:"Ρύθμιση εφαρμογών και απομακρυσμένης πρόσβασης"},{ic:"🔧",t:"Υποστήριξη μετά την εγκατάσταση",s:"Συντήρηση και άμεση εξυπηρέτηση"},{ic:"🔌",t:"Προσεκτική διέλευση καλωδίων",s:"Κρυφές ή τακτοποιημένες διαδρομές, σε κανάλια και σωλήνες"},{ic:"🧹",t:"Χωρίς μερεμέτια",s:"Προστατεύουμε τον χώρο σας και τον αφήνουμε καθαρό"},{ic:"🏷️",t:"Επαγγελματικός εξοπλισμός",s:"Αξιόπιστα μοντέλα από κορυφαίους κατασκευαστές"},{ic:"🧰",t:"Επαγγελματικά εργαλεία",s:"Σωστές τερματίσεις, μετρήσεις και δοκιμή σε κάθε σημείο"},{ic:"🎓",t:"Παράδοση με εκπαίδευση",s:"Σας δείχνουμε τη χρήση και σας αφήνουμε τους κωδικούς"}],DP="Ό,τι χρειάζεστε, από ένα συνεργείο",xP="Επιλέγουμε τον σωστό εξοπλισμό για τον χώρο σας και τον εγκαθιστούμε καθαρά και σωστά.",NP=[{ic:"📷",t:"Κάμερες ασφαλείας (CCTV)",d:"IP κάμερες, καταγραφικά, νυχτερινή όραση, προβολή από το κινητό.",m:`## Τι προσέχουμε στην επιλογή μοντέλου

- **Νυχτερινή λήψη:** μοντέλα με υπέρυθρο φωτισμό και, όπου χρειάζεται, έγχρωμη εικόνα και τη νύχτα.
- **Έξυπνη ανίχνευση με AI:** διακρίνει άνθρωπο και όχημα, ώστε να έχετε λιγότερες άσκοπες ειδοποιήσεις από σκιές, ζώα ή βροχή.
- **Καθαρή εικόνα:** ανάλυση ανάλογη με τον χώρο και αυτό που θέλετε να φαίνεται, π.χ. είσοδος, αυλή, πινακίδες.
- **Αντοχή:** στεγανές κάμερες για εξωτερικούς χώρους, που αντέχουν στη βροχή και στη σκόνη.
- **Αρκετή αποθήκευση:** καταγραφικό και δίσκος για τις ημέρες καταγραφής που χρειάζεστε.
- **Στο κινητό:** ζωντανή εικόνα, αναπαραγωγή και ειδοποιήσεις από οπουδήποτε.

## Πώς δουλεύουμε

Επισκεπτόμαστε τον χώρο, προτείνουμε θέσεις και μοντέλα, κάνουμε προσφορά, εγκαθιστούμε με καθαρή καλωδίωση, ρυθμίζουμε και σας δείχνουμε πώς το χρησιμοποιείτε.`},{ic:"📶",t:"WiFi & δίκτυα",d:"Κάλυψη WiFi χωρίς νεκρά σημεία, access points, καλωδιώσεις, rack.",m:`## Τι περιλαμβάνει

- **Μελέτη χώρου:** τοποθετούμε τα access points εκεί που χρειάζεται, ώστε να μην υπάρχουν νεκρά σημεία.
- **Ενσύρματη σύνδεση:** τα access points συνδέονται με καλώδιο δικτύου, για σταθερή ταχύτητα.
- **Ξεχωριστό δίκτυο επισκεπτών**, ώστε οι φιλοξενούμενοι να μην έχουν πρόσβαση στα δικά σας συστήματα.
- **Καλωδίωση και rack:** τακτοποιημένα, με σήμανση και ευκολία στην επέκταση.
- **Ασφάλεια και ρυθμίσεις:** ισχυρούς κωδικούς και σωστές ρυθμίσεις του router.`},{ic:"🚨",t:"Συναγερμοί",d:"Ενσύρματα και ασύρματα συστήματα με ειδοποιήσεις στο κινητό.",m:`## Τι περιλαμβάνει

- **Ανιχνευτές κίνησης και ανοίγματος** στα σημεία που χρειάζονται, με σειρήνα.
- **Ειδοποιήσεις στο κινητό** όταν ενεργοποιείται ο συναγερμός.
- **Ενσύρματο ή ασύρματο σύστημα**, ανάλογα με το κτίριο και τον προϋπολογισμό σας.
- **Μπαταρία υποστήριξης**, ώστε να δουλεύει και σε διακοπή ρεύματος.
- **Σύνδεση με τις κάμερες**, όπου θέλετε να βλέπετε την εικόνα όταν χτυπήσει ο συναγερμός.`},{ic:"🌡️",t:"Αισθητήρες & ανιχνευτές",d:"Θερμοκρασία, υγρασία, φωτιά και καπνός, με ειδοποίηση στο κινητό.",m:`## Τι περιλαμβάνει

- **Αισθητήρες θερμοκρασίας και υγρασίας:** παρακολουθείτε από το κινητό τον χώρο σας, π.χ. αποθήκη, ψυγείο, κάβα, serverroom ή σπίτι που μένει κλειστό.
- **Ειδοποίηση όταν ξεπεραστούν τα όρια** που θα ορίσετε, π.χ. πολύ υψηλή θερμοκρασία ή υγρασία που ευνοεί μούχλα.
- **Ανιχνευτές καπνού και πυρκαγιάς:** ηχούν τοπικά και σας ειδοποιούν στο κινητό, ακόμη κι όταν λείπετε.
- **Σύνδεση με το σύστημα συναγερμού ή τους αυτοματισμούς**, όπου θέλετε να ενεργοποιείται σειρήνα ή σκηνή.
- **Ασύρματοι αισθητήρες με μπαταρία**, χωρίς μεγάλες παρεμβάσεις στον χώρο.
- **Ιστορικό μετρήσεων**, όπου το υποστηρίζει η εφαρμογή.`},{ic:"🚪",t:"Θυροτηλέφωνα & πρόσβαση",d:"Θυροτηλεόραση, κάρτες, κωδικοί και έλεγχος εισόδου.",m:`## Τι περιλαμβάνει

- **Θυροτηλεόραση:** βλέπετε ποιος είναι στην πόρτα, ακόμη και από το κινητό.
- **Πρόσβαση με κάρτα ή κωδικό**, για να μην χρειάζεστε κλειδιά.
- **Ηλεκτρικές κλειδαριές και ανοιχτήρια** για πόρτες και πύλες.
- **Δικαιώματα ανά άτομο:** προσθέτετε ή αφαιρείτε κάρτες όποτε χρειάζεται.`},{ic:"🏠",t:"Έξυπνο σπίτι",d:"Αυτοματισμοί φωτισμού, ρολών και κλιματισμού από το κινητό.",m:`## Τι περιλαμβάνει

- **Φωτισμός, ρολά και κλιματισμός** από το κινητό ή με χρονοπρογραμματισμό.
- **Σκηνές:** ένα πάτημα για «φεύγω» ή «βράδυ».
- **Φωνητικός έλεγχος**, όπου το υποστηρίζουν οι συσκευές.
- **Σταδιακή επέκταση:** ξεκινάτε από ό,τι χρειάζεστε και προσθέτετε αργότερα.`},{ic:"⚡",t:"Ηλεκτρολογικά",d:"Ηλεκτρολογικές εργασίες με τη Smart Electric.",m:`## Τι αναλαμβάνουμε

- **Νέες γραμμές και πίνακες** σε σπίτια και επαγγελματικούς χώρους.
- **Φωτισμός και πρίζες**, επεκτάσεις και αντικαταστάσεις.
- **Αποκατάσταση βλαβών.**
- **Σε συνεργασία με τη Smart Electric.**`}],VP="Συνεργαζόμαστε με κορυφαίους κατασκευαστές",OP="Τοποθετούμε αξιόπιστο εξοπλισμό από εταιρείες που ξέρουμε σε βάθος.",MP=[{t:"TP-Link",s:"Omada · δίκτυα & WiFi"},{t:"Hikvision",s:"Κάμερες & καταγραφικά"},{t:"Dahua",s:"Κάμερες & καταγραφικά"},{t:"Ubiquiti",s:"UniFi · δίκτυα & WiFi"},{t:"Ajax",s:"Συστήματα συναγερμού"}],LP="Δουλειές που έχουμε παραδώσει",FP="Μερικές από τις εγκαταστάσεις μας. Πατήστε σε μια φωτογραφία για να τη δείτε μεγάλη.",UP="Μικρό συνεργείο, μεγάλη φροντίδα",qP="Η TechMate είναι ομάδα τεχνικών με εμπειρία σε συστήματα ασφαλείας, δίκτυα και ηλεκτρολογικά, σε συνεργασία με τη Smart Electric. Αναλαμβάνουμε από ένα διαμέρισμα μέχρι καταστήματα και αποθήκες, με καθαρή δουλειά και σαφή προσφορά από την αρχή.",BP="Μετά την εγκατάσταση δεν εξαφανιζόμαστε: σας δίνουμε τα στοιχεία πρόσβασης, βεβαίωση εγκατάστασης με εγγύηση και είμαστε εδώ για ό,τι χρειαστείτε.",jP=[{v:"150+",l:"εγκαταστάσεις"},{v:"24μ",l:"εγγύηση"},{v:"48ω",l:"απόκριση σε βλάβη"},{v:"1",l:"υπεύθυνος για όλα"}],WP="Ας μιλήσουμε για τον χώρο σας",zP="Πείτε μας τι χρειάζεστε και θα σας στείλουμε προσφορά — συνήθως μέσα στην ίδια μέρα.",GP="",KP="",HP="",QP="",JP="",YP="Δευτέρα–Σάββατο 08:00–20:00",XP="Πρέβεζα, Λευκάδα, Βόνιτσα & Πάλαιρος",ZP="Εξυπηρετούμε και γύρω περιοχές κατόπιν συνεννόησης",eC="",tC="",nC=[{t:"Αυτοψία",d:"Έρχόμαστε στο χώρο σας (ή βλέπουμε φωτογραφίες) και καταγράφουμε τι ακριβώς χρειάζεστε."},{t:"Προσφορά",d:"Παίρνετε γραπτή προσφορά με τα μοντέλα και τις τιμές, και μπορείτε να τη δείτε online."},{t:"Εγκατάσταση",d:"Τοποθετούμε με προσεκτική διέλευση καλωδίων και δοκιμάζουμε κάθε σημείο."},{t:"Παράδοση & υποστήριξη",d:"Σας δείχνουμε τη χρήση, σας δίνουμε τα στοιχεία πρόσβασης και μένουμε δίπλα σας μετά την εγκατάσταση."}],sC=[{q:"Πώς γίνεται η προσφορά;",a:"Κάνουμε αυτοψία στο χώρο (ή βλέπουμε φωτογραφίες) και σας στέλνουμε γραπτή προσφορά με τα μοντέλα και τις τιμές. Μπορείτε να τη δείτε και online."},{q:"Πόσο χρόνο παίρνει μια εγκατάσταση;",a:"Εξαρτάται από το μέγεθος του έργου. Σας ενημερώνουμε για τον χρόνο μαζί με την προσφορά."},{q:"Μπορώ να βλέπω τις κάμερες από το κινητό μου;",a:"Ναι. Ρυθμίζουμε την εφαρμογή στο κινητό σας για προβολή και απομακρυσμένη πρόσβαση, και σας δείχνουμε πώς να τη χρησιμοποιείτε."},{q:"Υπάρχει εγγύηση;",a:"Ναι. Οι ακριβείς όροι της εγγύησης αναγράφονται στην προσφορά, και μετά την εγκατάσταση τους βλέπετε και στην Περιοχή πελάτη."},{q:"Τι γίνεται μετά την εγκατάσταση;",a:"Σας παραδίδουμε τα στοιχεία πρόσβασης και μένουμε διαθέσιμοι για υποστήριξη, ρυθμίσεις ή προσθήκες."},{q:"Σε ποιες περιοχές εξυπηρετείτε;",a:"Στην Πρέβεζα, τη Λευκάδα, τη Βόνιτσα και τον Πάλαιρο, και σε γύρω περιοχές κατόπιν συνεννόησης."}],xm={title:EP,desc:TP,eyebrow:AP,h1a:SP,h1b:kP,h1c:RP,lead:PP,powered:CP,cards:$P,svcTitle:DP,svcLead:xP,services:NP,partnersTitle:VP,partnersLead:OP,partners:MP,workTitle:LP,workLead:FP,aboutTitle:UP,about1:qP,about2:BP,stats:jP,contactTitle:WP,contactLead:zP,phone:GP,mobile:KP,reviewUrl:HP,cfToken:QP,email:JP,hours:YP,area:XP,areaNote:ZP,facebook:eC,instagram:tC,steps:nC,faq:sC},iC="TechMate · CCTV, networks and smart installations in Greece",rC="TechMate – Powered by Smart Electric. Installation of security cameras, Wi-Fi and networks, alarm systems and smart solutions for homes and businesses in Greece.",aC="Security · Networks · Smart installations",oC="Technology that",cC="works",lC="installation that lasts.",uC="Security cameras, Wi-Fi and networks, alarms and smart homes for residences and businesses. Design, installation and support from one team.",dC="Smart Electric",hC=[{ic:"📷",t:"Free site visit and quote",s:"A live quote you can view online"},{ic:"🛡️",t:"Installation warranty",s:"24 months on equipment and labour"},{ic:"📱",t:"View from your phone",s:"We set up the apps and remote access"},{ic:"🔧",t:"Support after installation",s:"Maintenance and quick service"},{ic:"🔌",t:"Careful cable routing",s:"Hidden or tidy routes, in trunking and conduit"},{ic:"🧹",t:"No mess",s:"We protect your space and leave it clean"},{ic:"🏷️",t:"Professional equipment",s:"Reliable models from leading manufacturers"},{ic:"🧰",t:"Professional tools",s:"Proper terminations, measurements and testing at every point"},{ic:"🎓",t:"Hand-over with training",s:"We show you how to use it and leave you the passwords"}],fC="Everything you need, from one team",pC="We choose the right equipment for your space and install it cleanly and correctly.",mC=[{ic:"📷",t:"CCTV security cameras",d:"IP cameras, recorders, night vision and viewing from your phone.",m:`## What we look for when choosing a model

- **Night vision:** models with infrared lighting and, where needed, colour images at night too.
- **Smart AI detection:** tells people and vehicles apart, so you get fewer false alerts from shadows, animals or rain.
- **Clear picture:** resolution matched to the area and what must be visible, such as an entrance, yard or number plates.
- **Durability:** weatherproof cameras for outdoor use that withstand rain and dust.
- **Enough storage:** a recorder and disk sized for the number of days you need.
- **On your phone:** live view, playback and alerts from anywhere.

## How we work

We visit the site, suggest positions and models, give you a quote, install with tidy cabling, set everything up and show you how to use it.`},{ic:"📶",t:"Wi-Fi and networks",d:"Wi-Fi without dead spots, access points, cabling and racks.",m:`## What is included

- **Site survey:** access points placed where they are needed, so there are no dead spots.
- **Wired backbone:** access points connected by network cable for stable speed.
- **Separate guest network**, so visitors cannot reach your own systems.
- **Cabling and rack:** neat, labelled and easy to extend.
- **Security and settings:** strong passwords and correct router configuration.`},{ic:"🚨",t:"Alarm systems",d:"Wired and wireless systems with phone notifications.",m:`## What is included

- **Motion and door/window sensors** where they are needed, with a siren.
- **Phone notifications** when the alarm is triggered.
- **Wired or wireless system**, depending on the building and your budget.
- **Backup battery**, so it keeps working during a power cut.
- **Link to your cameras**, if you want to see the picture when the alarm goes off.`},{ic:"🌡️",t:"Sensors and detectors",d:"Temperature, humidity, fire and smoke, with a notification to your phone.",m:`## What is included

- **Temperature and humidity sensors:** monitor your space from your phone, such as a storeroom, fridge, wine cellar, server room or a home that stays empty.
- **Alerts when the limits you set are exceeded**, for example very high temperature or humidity that encourages mould.
- **Smoke and fire detectors:** they sound locally and notify your phone, even when you are away.
- **Link to the alarm system or your automations**, where you want a siren or a scene to be triggered.
- **Wireless battery-powered sensors**, with no major work in your space.
- **Measurement history**, where the app supports it.`},{ic:"🚪",t:"Intercoms and access control",d:"Video intercoms, cards, codes and entry control.",m:`## What is included

- **Video intercom:** see who is at the door, even from your phone.
- **Card or code access**, so you do not need keys.
- **Electric locks and door openers** for doors and gates.
- **Rights per person:** add or remove cards whenever needed.`},{ic:"🏠",t:"Smart home",d:"Lighting, shutter and air-conditioning automation from your phone.",m:`## What is included

- **Lights, shutters and air conditioning** from your phone or on a schedule.
- **Scenes:** one tap for “leaving” or “evening”.
- **Voice control**, where the devices support it.
- **Step-by-step growth:** start with what you need and add more later.`},{ic:"⚡",t:"Electrical work",d:"Electrical work together with Smart Electric.",m:`## What we take care of

- **New lines and distribution boards** in homes and business premises.
- **Lighting and sockets**, extensions and replacements.
- **Fault repair.**
- **In cooperation with Smart Electric.**`}],gC="We work with leading manufacturers",yC="We install reliable equipment from companies we know in depth.",vC=[{t:"TP-Link",s:"Omada · networks and Wi-Fi"},{t:"Hikvision",s:"Cameras and recorders"},{t:"Dahua",s:"Cameras and recorders"},{t:"Ubiquiti",s:"UniFi · networks and Wi-Fi"},{t:"Ajax",s:"Alarm systems"}],bC="Jobs we have delivered",_C="A selection of our installations. Tap a photo to see it larger.",wC="A small team that cares",IC="TechMate is a team of technicians experienced in security systems, networks and electrical work, in cooperation with Smart Electric. We take on everything from a flat to shops and warehouses, with tidy work and a clear quote from the start.",EC="We do not disappear after the installation: we give you the access details, an installation certificate with warranty, and we are here for whatever you need.",TC=[{v:"150+",l:"installations"},{v:"24m",l:"warranty"},{v:"48h",l:"fault response"},{v:"1",l:"person responsible for everything"}],AC="Let's talk about your space",SC="Tell us what you need and we will send you a quote, usually the same day.",kC="Monday–Saturday 08:00–20:00",RC="Preveza, Lefkada, Vonitsa & Palairos",PC="We also serve nearby areas by arrangement",CC=[{t:"Site visit",d:"We come to your space (or look at photos) and note exactly what you need."},{t:"Quote",d:"You receive a written quote with the models and prices, and you can view it online."},{t:"Installation",d:"We install with careful cable routing and test every point."},{t:"Hand-over and support",d:"We show you how to use it, give you the access details and stay by your side after the installation."}],$C=[{q:"How does the quote work?",a:"We do a site visit (or look at photos) and send you a written quote with the models and prices. You can also view it online."},{q:"How long does an installation take?",a:"It depends on the size of the job. We tell you the time frame together with the quote."},{q:"Can I watch the cameras on my phone?",a:"Yes. We set up the app on your phone for viewing and remote access, and show you how to use it."},{q:"Is there a warranty?",a:"Yes. The exact warranty terms are written in the quote, and after the installation you can also see them in the Customer area."},{q:"What happens after the installation?",a:"We hand over the access details and remain available for support, settings or additions."},{q:"Which areas do you serve?",a:"Preveza, Lefkada, Vonitsa and Palairos, and nearby areas by arrangement."}],Nm={title:iC,desc:rC,eyebrow:aC,h1a:oC,h1b:cC,h1c:lC,lead:uC,powered:dC,cards:hC,svcTitle:fC,svcLead:pC,services:mC,partnersTitle:gC,partnersLead:yC,partners:vC,workTitle:bC,workLead:_C,aboutTitle:wC,about1:IC,about2:EC,stats:TC,contactTitle:AC,contactLead:SC,hours:kC,area:RC,areaNote:PC,steps:CC,faq:$C},Vm=[{id:"cctv-plan",on:!0,el:{t:"Πόσες κάμερες χρειάζεται ο χώρος σας και πού μπαίνουν",d:"Πρακτικός οδηγός για τον σχεδιασμό καμερών ασφαλείας σε σπίτι ή επαγγελματικό χώρο: σημεία κάλυψης, ανάλυση, νυχτερινή λήψη, αποθήκευση.",b:`Δεν υπάρχει μαγικός αριθμός καμερών. Ο σωστός σχεδιασμός ξεκινά από το **τι θέλετε να προστατέψετε** και όχι από το πόσες κάμερες χωράνε στο budget.

## 1. Ξεκινήστε από τα σημεία εισόδου

Οι περισσότερες παρεμβάσεις γίνονται από την κύρια είσοδο, τις πίσω πόρτες, τα ισόγεια παράθυρα και τα γκαράζ. Αυτά καλύπτονται πρώτα. Μια καλά τοποθετημένη κάμερα στην είσοδο αξίζει περισσότερο από τρεις που κοιτούν τον κενό χώρο.

## 2. Σκεφτείτε τον στόχο κάθε κάμερας

- **Επισκόπηση:** μια ευρεία εικόνα του χώρου, ώστε να βλέπετε τι συμβαίνει.
- **Αναγνώριση:** πιο κοντινή λήψη σε πόρτες και σημεία διέλευσης, ώστε να φαίνεται ποιος περνά.
- **Αποτροπή:** ορατή κάμερα και σήμανση, που από μόνες τους κάνουν πολλούς να το ξανασκεφτούν.

## 3. Ανάλυση, νυχτερινή λήψη και φως

Περισσότερα pixel βοηθούν στη λεπτομέρεια, αλλά μια κάμερα απέναντι σε δυνατό φως (ήλιος, προβολέας) δίνει κακή εικόνα όσο ακριβή κι αν είναι. Σημασία έχει η θέση, η γωνία και η νυχτερινή λήψη για τις ώρες που πραγματικά χρειάζεστε.

## 4. Αποθήκευση και πρόσβαση

Ο καταγραφέας (ή η αποθήκευση) πρέπει να επιλεγεί σύμφωνα με τον αριθμό των καμερών και τις ημέρες καταγραφής που θέλετε. Σκεφτείτε επίσης ποιος θα έχει απομακρυσμένη πρόσβαση από το κινητό και με ποιον κωδικό.

## 5. Προσοχή στον χώρο των άλλων

Οι κάμερες δεν πρέπει να κοιτούν το σπίτι ή την αυλή του γείτονα ή τον δημόσιο δρόμο περισσότερο από όσο είναι αναγκαίο. Δείτε και το άρθρο μας για τα προσωπικά δεδομένα.

**Τι να κάνετε στη συνέχεια:** κάντε μια βόλτα στον χώρο και σημειώστε τις εισόδους και τα σημεία που σας ανησυχούν. Με αυτή τη λίστα, μια αυτοψία βγάζει γρήγορα σαφή πρόταση.`},en:{t:"How many security cameras you need, and where to put them",d:"A practical guide to planning CCTV for a home or business: coverage points, resolution, night vision and storage.",b:`There is no magic number of cameras. Good planning starts from **what you want to protect**, not from how many cameras fit the budget.

## 1. Start with entry points

Most break-ins happen through the main entrance, back doors, ground-floor windows and garages. Cover those first. One well-placed camera at the door is worth more than three that watch empty space.

## 2. Decide what each camera is for

- **Overview:** a wide picture of the space, so you can see what is going on.
- **Identification:** a closer view of doors and choke points, so you can see who passes.
- **Deterrence:** a visible camera and signage, which on their own make many people think twice.

## 3. Resolution, night vision and light

More pixels help with detail, but a camera facing strong light (sun, floodlight) gives a poor picture however expensive it is. Position, angle and night vision for the hours you actually need matter most.

## 4. Storage and access

The recorder (or storage) should be sized to the number of cameras and the number of days you want to keep. Also think about who gets remote access from a phone, and with which password.

## 5. Respect other people's space

Cameras should not look at a neighbour's home or yard, or at the public street, more than is necessary. See also our article on personal data.

**Next step:** walk around the property and note the entrances and the spots that worry you. With that list, a site visit quickly produces a clear proposal.`}},{id:"wifi",on:!0,el:{t:"Αδύναμο Wi-Fi στο σπίτι ή στο μαγαζί: αιτίες και λύσεις",d:"Γιατί το Wi-Fi χάνεται σε κάποια δωμάτια και τι πραγματικά το διορθώνει: τοποθέτηση, access points, καλωδίωση.",b:`Όταν το Wi-Fi «δεν πιάνει» στο πίσω δωμάτιο, το πρώτο ένστικτο είναι να αγοραστεί ένας δυνατότερος router. Συνήθως δεν είναι εκεί το πρόβλημα.

## Οι πιο συχνές αιτίες

- **Ο router είναι σε κακό σημείο:** σε ντουλάπι, στη γωνία ή πίσω από τηλεόραση.
- **Τοίχοι και πλάκες:** το σκυρόδεμα και οι μεταλλικές επιφάνειες κόβουν το σήμα πολύ.
- **Παρεμβολές:** πολλά δίκτυα στο ίδιο κανάλι, ιδιαίτερα σε πολυκατοικίες.
- **Πολλές συσκευές:** ένας παλιός router δυσκολεύεται όταν συνδέονται δεκάδες.

## Τι λειτουργεί στην πράξη

1. **Μετακίνηση του router** σε κεντρικό, ψηλό και ανοιχτό σημείο, αν γίνεται.
2. **Περισσότερα σημεία πρόσβασης (access points)** που συνδέονται με καλώδιο δικτύου. Είναι η πιο σταθερή λύση για μεγάλους χώρους.
3. **Ενσύρματη σύνδεση** για ό,τι δεν κινείται (τηλεόραση, υπολογιστής, κάμερες): ελαφρύνει το Wi-Fi.
4. **Mesh συστήματα:** βολικά όταν δεν μπορεί να περαστεί καλώδιο, αλλά δουλεύουν καλύτερα όταν τα σημεία τους συνδέονται μεταξύ τους με καλώδιο.

## Πότε χρειάζεται καλωδίωση

Σε μαγαζιά, γραφεία και μεγάλα σπίτια, η σωστή λύση είναι συνήθως λίγα καλώδια δικτύου σε στρατηγικά σημεία και access points στο ταβάνι. Κοστίζει περισσότερο στην αρχή, αλλά λύνει το πρόβλημα μόνιμα.

**Πριν αγοράσετε κάτι:** γράψτε σε ποια δωμάτια χάνεται το σήμα και σε ποιες ώρες. Αυτή η πληροφορία δείχνει συχνά την αιτία πριν από οποιαδήποτε μέτρηση.`},en:{t:"Weak Wi-Fi at home or in the shop: causes and fixes",d:"Why Wi-Fi drops in some rooms and what actually fixes it: placement, access points and cabling.",b:`When Wi-Fi “doesn’t reach” the back room, the first instinct is to buy a stronger router. That is usually not where the problem is.

## The most common causes

- **The router is in a bad spot:** in a cabinet, in a corner or behind a TV.
- **Walls and slabs:** concrete and metal surfaces block signal heavily.
- **Interference:** many networks on the same channel, especially in apartment buildings.
- **Too many devices:** an old router struggles when dozens connect.

## What works in practice

1. **Move the router** to a central, high and open spot if you can.
2. **More access points** connected by network cable. This is the most stable solution for larger spaces.
3. **Wired connections** for anything that does not move (TV, computer, cameras), which takes load off the Wi-Fi.
4. **Mesh systems:** handy when you cannot run cable, but they work better when their nodes are also wired together.

## When cabling is needed

In shops, offices and large homes the right answer is usually a few network cables at strategic points and ceiling access points. It costs more up front but solves the problem for good.

**Before you buy anything:** note which rooms lose signal and at what times. That alone often points to the cause before any measurement.`}},{id:"cctv-law",on:!0,el:{t:"Κάμερες ασφαλείας και προσωπικά δεδομένα: τι πρέπει να ξέρετε",d:"Βασικές αρχές για νόμιμη χρήση καμερών σε σπίτι ή επιχείρηση στην Ελλάδα: σήμανση, χρόνος διατήρησης, πού επιτρέπεται να κοιτούν.",b:`*Γενική ενημέρωση και όχι νομική συμβουλή. Οι κανόνες αλλάζουν, γι’ αυτό ελέγχετε τις τρέχουσες οδηγίες της [Αρχής Προστασίας Δεδομένων](https://www.dpa.gr) ή ζητήστε νομική γνώμη για τη δική σας περίπτωση.*

Μια κάμερα που καταγράφει ανθρώπους επεξεργάζεται προσωπικά δεδομένα. Αυτό σημαίνει ότι υπάρχουν υποχρεώσεις, ιδιαίτερα όταν καταγράφονται άλλοι εκτός από τους ίδιους τους ιδιοκτήτες.

## Σήμανση

Σε επαγγελματικούς χώρους και γενικά όπου καταγράφονται τρίτοι, πρέπει να υπάρχει **ευδιάκριτη πινακίδα** που ενημερώνει ότι ο χώρος παρακολουθείται, με τον υπεύθυνο και τρόπο επικοινωνίας.

## Σκοπός και αναλογικότητα

Οι κάμερες πρέπει να εξυπηρετούν συγκεκριμένο σκοπό, όπως η προστασία προσώπων και περιουσίας, και να καταγράφουν μόνο ό,τι είναι αναγκαίο. Δεν τοποθετούνται σε χώρους όπως αποδυτήρια ή τουαλέτες και δεν στοχεύουν συστηματικά τους εργαζομένους.

## Πού κοιτούν

Αποφεύγετε να καλύπτετε είσοδο ή εσωτερικό γειτονικής κατοικίας και τον δημόσιο δρόμο πέρα από το απολύτως αναγκαίο.

## Πόσο κρατιούνται οι εγγραφές

Οι εγγραφές δεν πρέπει να φυλάσσονται περισσότερο από όσο χρειάζεται. Η Αρχή έχει συνήθως ως γενικό πλαίσιο μερικές δεκάδες ημέρες το πολύ, εκτός αν υπάρχει συγκεκριμένη ανάγκη, για παράδειγμα ένα περιστατικό. Ελέγξτε την τρέχουσα οδηγία.

## Ασφάλεια του ίδιου του συστήματος

Αλλάξτε τους προεπιλεγμένους κωδικούς, περιορίστε ποιοι έχουν πρόσβαση και κρατήστε το σύστημα ενημερωμένο. Μια κάμερα με ανοιχτή πρόσβαση είναι κίνδυνος και για την ιδιωτικότητά σας.

Στις εγκαταστάσεις μας ρυθμίζουμε τους κωδικούς και τον χρόνο καταγραφής μαζί σας και σας υποδεικνύουμε πού χρειάζεται πινακίδα.`},en:{t:"Security cameras and personal data: what you should know",d:"Basic principles for lawful use of cameras at home or in a business in Greece: signage, retention, and where cameras may point.",b:`*General information, not legal advice. Rules change, so check the current guidance of the [Hellenic Data Protection Authority](https://www.dpa.gr) or ask for legal advice on your own case.*

A camera that records people processes personal data. That brings obligations, especially when people other than the owners are recorded.

## Signage

In business premises, and generally wherever third parties are recorded, there should be a **clearly visible sign** saying the area is monitored, with the controller and contact details.

## Purpose and proportionality

Cameras must serve a specific purpose, such as protecting people and property, and record only what is necessary. They are not placed in areas such as changing rooms or toilets and do not systematically target employees.

## Where they point

Avoid covering a neighbour’s entrance or interior, and the public street beyond what is strictly necessary.

## How long recordings are kept

Recordings should not be kept longer than needed. The Authority’s general framework is usually a few dozen days at most, unless there is a specific need such as an incident. Check the current guidance.

## Security of the system itself

Change default passwords, limit who has access and keep the system up to date. A camera with open access is a risk to your own privacy too.

In our installations we set up passwords and recording time with you and point out where signage is needed.`}},{id:"wired-wireless",on:!0,el:{t:"Ενσύρματες ή ασύρματες κάμερες; Πώς να διαλέξετε",d:"Συγκριτικά πλεονεκτήματα και περιορισμοί των καμερών με καλώδιο PoE, Wi-Fi και μπαταρίας.",b:`Η ερώτηση «ασύρματες ή ενσύρματες;» εμφανίζεται σε κάθε αυτοψία. Η απάντηση εξαρτάται από τον χώρο και από το πόσο σταθερό θέλετε το αποτέλεσμα.

## Ενσύρματες (δίκτυο με PoE)

Ένα καλώδιο δικτύου φέρνει και δεδομένα και ρεύμα. **Πλεονεκτήματα:** σταθερή εικόνα, χωρίς εξάρτηση από το Wi-Fi, κεντρική καταγραφή. **Περιορισμοί:** χρειάζεται καλωδίωση, που σε έτοιμα κτίρια θέλει σχεδιασμό.

## Wi-Fi κάμερες (με τροφοδοσία από πρίζα)

Δεν χρειάζονται καλώδιο δεδομένων, αλλά θέλουν ρεύμα και καλό σήμα. **Πλεονεκτήματα:** εύκολη τοποθέτηση. **Περιορισμοί:** η ποιότητα εξαρτάται από το Wi-Fi και ένα αδύναμο δίκτυο δίνει κομμένη εικόνα.

## Κάμερες μπαταρίας

Κατάλληλες για σημεία χωρίς καθόλου καλώδιο. **Περιορισμοί:** χρειάζονται φόρτιση, συνήθως καταγράφουν μόνο σε κίνηση και δεν ταιριάζουν σε συνεχή καταγραφή.

## Πρακτικός κανόνας

- Για **σταθερή, μόνιμη κάλυψη** (είσοδοι, επαγγελματικός χώρος): ενσύρματες.
- Για **πρόσθετο σημείο** όπου δεν περνά καλώδιο: Wi-Fi ή μπαταρίας, αφού ελεγχθεί το σήμα.

Στην αυτοψία ελέγχουμε διαδρομές καλωδίων και σήμα, και προτείνουμε συνδυασμό που ταιριάζει στον χώρο σας.`},en:{t:"Wired or wireless cameras? How to choose",d:"Strengths and limits of PoE wired, Wi-Fi and battery cameras.",b:`The question “wireless or wired?” comes up at every site visit. The answer depends on the space and on how stable you want the result to be.

## Wired (PoE network cameras)

One network cable carries both data and power. **Strengths:** stable picture, no dependence on Wi-Fi, central recording. **Limits:** it needs cabling, which in existing buildings takes planning.

## Wi-Fi cameras (mains powered)

No data cable needed, but they need power and a good signal. **Strengths:** easy to place. **Limits:** quality depends on your Wi-Fi, and a weak network gives a choppy picture.

## Battery cameras

Suitable for spots with no cable at all. **Limits:** they need charging, usually record only on motion and are not suited to continuous recording.

## A practical rule

- For **stable, permanent coverage** (entrances, business premises): wired.
- For an **extra point** where no cable can run: Wi-Fi or battery, once the signal has been checked.

During the site visit we check cable routes and signal, and suggest a mix that suits your space.`}},{id:"maintenance",on:!0,el:{t:"Συντήρηση συστήματος ασφαλείας: τι ελέγχουμε και κάθε πότε",d:"Λίστα ελέγχου για κάμερες, καταγραφέα, δίκτυο και συναγερμό: καθαρισμός, ενημερώσεις, κωδικοί, μπαταρίες.",b:`Ένα σύστημα ασφαλείας που δεν ελέγχεται μπορεί να έχει σταματήσει να καταγράφει χωρίς να το ξέρετε. Ένας περιοδικός έλεγχος, συνήθως μία ή δύο φορές τον χρόνο, αποτρέπει δυσάρεστες εκπλήξεις.

## Τι ελέγχουμε

- **Κάμερες:** καθαρισμός φακών και καλύτερη γωνία. Ιστοί, σκόνη ή βλάστηση μπορούν να χαλάσουν την εικόνα.
- **Καταγραφή:** ότι όντως αποθηκεύονται εγγραφές και για πόσες ημέρες πίσω, καθώς και η κατάσταση του δίσκου.
- **Δίκτυο:** σύνδεση καμερών, καλωδίωση και βύσματα.
- **Ενημερώσεις λογισμικού:** του καταγραφέα και των καμερών, όπου αυτές προσφέρονται.
- **Κωδικοί και πρόσβαση:** ποιος έχει απομακρυσμένη πρόσβαση, αλλαγή κωδικών όταν αλλάζουν τα πρόσωπα.
- **Παροχή ρεύματος:** UPS ή μπαταρίες εφεδρείας, όπου υπάρχουν.
- **Συναγερμός:** μπαταρίες αισθητήρων και δοκιμή ειδοποιήσεων.

## Κάθε πότε

Για τους περισσότερους χώρους αρκεί ένας έλεγχος τον χρόνο. Σε χώρους με μεγάλο φόρτο ή υψηλές απαιτήσεις, κάθε έξι μήνες.

## Τι μπορείτε να κάνετε μόνοι σας

Ανοίξτε μία φορά τον μήνα μια εγγραφή των προηγούμενων ημερών και βεβαιωθείτε ότι υπάρχει και ότι η εικόνα είναι καθαρή. Αν κάτι δεν φαίνεται σωστό, καλέστε μας.

Προσφέρουμε περιοδική συντήρηση κάθε 6 ή 12 μήνες και σας υπενθυμίζουμε εμείς πότε έρχεται η ώρα.`},en:{t:"Maintaining a security system: what we check and how often",d:"A checklist for cameras, recorder, network and alarm: cleaning, updates, passwords, batteries.",b:`A security system that is never checked can stop recording without you knowing. A periodic check, usually once or twice a year, prevents unpleasant surprises.

## What we check

- **Cameras:** cleaning the lenses and adjusting the angle. Webs, dust or vegetation can spoil the picture.
- **Recording:** that footage is really being stored, how many days back, and the state of the disk.
- **Network:** camera connections, cabling and connectors.
- **Software updates:** for the recorder and the cameras, where available.
- **Passwords and access:** who has remote access, and changing passwords when people change.
- **Power:** UPS or backup batteries, where fitted.
- **Alarm:** sensor batteries and a test of notifications.

## How often

For most places one check a year is enough. For busy sites or high requirements, every six months.

## What you can do yourself

Once a month, open a recording from the previous days and make sure it exists and the picture is clear. If something looks wrong, call us.

We offer periodic maintenance every 6 or 12 months and we remind you when it is due.`}},{id:"starlink-order",on:!0,pin:!0,ref:!0,el:{t:"Πώς να παραγγείλετε Starlink μόνοι σας: οδηγός βήμα-βήμα",d:"Βήμα-βήμα οδηγός με φωτογραφίες για να παραγγείλετε το Starlink, ποιο πακέτο και kit να διαλέξετε, παύση της σύνδεσης για καταλύματα Airbnb και δωρεάν μήνας με link από εμάς.",b:`Αρκετοί πελάτες δυσκολεύονται να παραγγείλουν μόνοι τους το Starlink. Εδώ είναι ένας σύντομος οδηγός, βήμα προς βήμα και με φωτογραφίες από την ίδια την παραγγελία. Αν κολλήσετε σε οποιοδήποτε σημείο, γράψτε μας ή καλέστε μας και σας βοηθάμε.

## Πριν ξεκινήσετε

- Έχετε έτοιμη την **ακριβή διεύθυνση εγκατάστασης** (εκεί που θα μπει η κεραία).
- Έχετε μια **κάρτα πληρωμής** (ή Apple Pay).
- Σκεφτείτε πού θα μπει η κεραία: χρειάζεται **ελεύθερη θέα στον ουρανό**, χωρίς δέντρα ή ψηλά εμπόδια.
- Έχετε ένα κινητό για την εφαρμογή Starlink (App Store ή Google Play).

## Βήμα 1: Μπείτε στο starlink.com/gr

Γράψτε στο πεδίο «Διεύθυνση» τη διεύθυνση εγκατάστασης και πατήστε «Ξεκινήστε».

![Η αρχική σελίδα του Starlink. Γράφετε τη διεύθυνση στο πεδίο «Διεύθυνση» και πατάτε «Ξεκινήστε».](img/sl-1-home.jpg)

## Βήμα 2: Διαλέξτε τη σωστή διεύθυνση

Καθώς γράφετε, εμφανίζονται προτάσεις. Πατήστε αυτή που ταιριάζει ακριβώς. Αν η περιοχή δεν είναι διαθέσιμη, η Starlink θα σας το πει εδώ. (Στις εικόνες χρησιμοποιούμε μια δημόσια διεύθυνση ως παράδειγμα.)

![Διαλέξτε τη σωστή διεύθυνση από τη λίστα προτάσεων.](img/sl-2-address.jpg)

## Βήμα 3: Διαλέξτε πακέτο: 200 Mbps και πάνω

Ανοίγει η σελίδα «Παραγγελία κιτ για Οικιακή χρήση». Πάνω-πάνω βλέπετε ότι υπάρχει δοκιμαστική περίοδος 30 ημερών και ότι η αποστολή γίνεται εντός 1-2 εβδομάδων. Υπάρχουν τρεις καρτέλες: **100 Mbps**, **200 Mbps** και **Max**. Προτείνουμε πάντα **200 Mbps ή Max** (δείτε παρακάτω γιατί).

![Οι τρεις καρτέλες πακέτων: 100 Mbps, 200 Mbps και Max.](img/sl-3-plans.jpg)

## Βήμα 4: Δείτε τι κοστίζει και τι περιλαμβάνεται

Κάτω από την καρτέλα βλέπετε τη μηνιαία τιμή της υπηρεσίας και τον εξοπλισμό. Την ημέρα που γράφτηκε ο οδηγός, ο εξοπλισμός είχε **0 € προκαταβολικό κόστος και 0 € τον μήνα**. Δίνεται με ενοικίαση, οπότε **αν ακυρώσετε την υπηρεσία πρέπει να τον επιστρέψετε**. Οι τιμές και οι προσφορές αλλάζουν συχνά, γι' αυτό κοιτάξτε πάντα τις τρέχουσες στη σελίδα.

![Η τιμή του πακέτου 200 Mbps και τα έξοδα εξοπλισμού (οι τιμές αλλάζουν, δείτε πάντα τις τρέχουσες).](img/sl-4-price-200.jpg)

## Βήμα 5: Ελέγξτε ποιο kit παίρνετε

Πατήστε «Λεπτομέρειες προϊόντος» για να δείτε το kit του πακέτου. Με το πακέτο 200 Mbps παίρνετε το **Standard 4** (μεγαλύτερη κεραία, κατανάλωση 75-100 W, αντοχή σε άνεμο 96 km/h+, μαζί με router Starlink Mini Wi-Fi 6).

![Το kit «Standard 4» που περιλαμβάνεται στο πακέτο 200 Mbps.](img/sl-5-kit-200.jpg)

Με το πακέτο 100 Mbps παίρνετε το μικρότερο **Mini X** (κατανάλωση 25-40 W), που ταιριάζει σε μικρά νοικοκυριά.

![Το kit «Mini X» που περιλαμβάνεται στο πακέτο 100 Mbps.](img/sl-6-kit-100.jpg)

## Βήμα 6: Εγκατάσταση

Στην ενότητα «Εγκατάσταση» η Starlink προσφέρει εγκατάσταση από επαγγελματία με επιπλέον χρέωση. Μπορείτε να τη δείτε εκεί ή να μας ζητήσετε να αναλάβουμε εμείς τοποθέτηση, καλωδίωση και ρύθμιση Wi-Fi σε όλο το σπίτι.

## Βήμα 7: Ολοκλήρωση παραγγελίας

Πατήστε «Ολοκλήρωση παραγγελίας», συμπληρώστε τα στοιχεία παράδοσης και πληρωμής και ελέγξτε το «Σύνολο οφειλή σήμερα» πριν πληρώσετε. Η Starlink αναφέρει ότι, αν ακυρώσετε και επιστρέψετε το kit χωρίς ζημιά εντός 30 ημερών από την προθεσμία εξόφλησης, δικαιούστε πλήρη επιστροφή χρημάτων για το kit και τον πρώτο μήνα.

## Βήμα 8: Παραλαβή και εγκατάσταση

Όταν φτάσει το kit, ακολουθήστε την εφαρμογή Starlink. Σας δείχνει αν η θέση της κεραίας είναι καλή.

## Γιατί προτείνουμε 200 Mbps και πάνω

Όπως φαίνεται στη σελίδα παραγγελίας, το πακέτο 200 Mbps έρχεται με το μεγαλύτερο και πιο ισχυρό kit **Standard 4**, ενώ το 100 Mbps με το μικρότερο **Mini X**. Η μεγαλύτερη ταχύτητα βολεύει και σε σπίτια με πολλές συσκευές, τηλεργασία ή καταλύματα με πολλούς επισκέπτες. Πριν πληρώσετε, ελέγξτε πάντα ποιο kit αναγράφεται για το πακέτο που διαλέξατε.

## Airbnb και καταλύματα: παύση τον χειμώνα

Αν η σύνδεση είναι για κατάλυμα που δεν λειτουργεί τον χειμώνα, δεν χρειάζεται να πληρώνετε όλο τον χρόνο πλήρη λογαριασμό. Μπορείτε να **βάλετε τη σύνδεση σε παύση** (λειτουργία αναμονής) για τους μήνες που το κατάλυμα είναι κλειστό και να την ενεργοποιήσετε ξανά την άνοιξη. Η Starlink μπορεί να χρεώνει μικρό μηνιαίο ποσό για την αναμονή και να έχει όρια διάρκειας, γι' αυτό δείτε τους τρέχοντες όρους στον λογαριασμό σας.

## Link παραγγελίας από εμάς: δωρεάν μήνας

Αν ζητήσετε από εμάς **link για να παραγγείλετε το Starlink**, θα πάρετε **έναν μήνα δωρεάν εσείς και έναν μήνα δωρεάν εμείς**, μέσω του προγράμματος παραπομπής της Starlink. Ο μήνας ισχύει όταν η παραγγελία και η ενεργοποίηση γίνουν από το δικό μας link. Δεν πληρώνετε τίποτα παραπάνω.

Πατήστε το κουμπί παρακάτω, αφήστε τα στοιχεία σας και θα σας στείλουμε το link.`},en:{t:"How to order Starlink yourself: a step-by-step guide",d:"A step-by-step guide with photos for ordering Starlink, which plan and kit to pick, pausing the service for Airbnb properties in winter, and a free month with a link from us.",b:`Many customers find it hard to order Starlink on their own. This short guide walks you through it step by step, with photos from the actual order. If you get stuck anywhere, message or call us and we will help.

## Before you start

- Have the **exact installation address** ready (where the dish will go).
- Have a **payment card** ready (or Apple Pay).
- Think about where the dish will go: it needs a **clear view of the sky**, with no trees or tall obstacles.
- Have a phone ready for the Starlink app (App Store or Google Play).

## Step 1: Go to starlink.com/gr

Type your installation address into the "Διεύθυνση" (Address) field and press "Ξεκινήστε" (Get started). The Starlink site is shown in Greek in these photos.

![The Starlink home page. Enter the address in the "Διεύθυνση" field and press "Ξεκινήστε".](img/sl-1-home.jpg)

## Step 2: Pick the right address

Suggestions appear as you type. Tap the one that matches exactly. If your area is not available, Starlink tells you here. (The photos use a public landmark address as an example.)

![Pick the right address from the suggestion list.](img/sl-2-address.jpg)

## Step 3: Choose a plan: 200 Mbps and above

The "Home kit order" page opens. At the top you can see a 30-day trial period and shipping within 1-2 weeks. There are three tabs: **100 Mbps**, **200 Mbps** and **Max**. We always recommend **200 Mbps or Max** (see below why).

![The three plan tabs: 100 Mbps, 200 Mbps and Max.](img/sl-3-plans.jpg)

## Step 4: See the price and what is included

Under the tab you see the monthly service price and the equipment. On the day this guide was written the equipment had **€0 upfront and €0 per month**. It is supplied as a rental, so **if you cancel the service you must return it**. Prices and offers change often, so always check the current ones on the site.

![The 200 Mbps plan price and equipment costs (prices change, always check the current ones).](img/sl-4-price-200.jpg)

## Step 5: Check which kit you get

Tap "Λεπτομέρειες προϊόντος" (Product details) to see the plan's kit. With the 200 Mbps plan you get the **Standard 4** (larger dish, 75-100 W, wind resistance 96 km/h+, plus a Starlink Mini Wi-Fi 6 router).

![The "Standard 4" kit included with the 200 Mbps plan.](img/sl-5-kit-200.jpg)

With the 100 Mbps plan you get the smaller **Mini X** (25-40 W), which suits small households.

![The "Mini X" kit included with the 100 Mbps plan.](img/sl-6-kit-100.jpg)

## Step 6: Installation

In the "Installation" section Starlink offers installation by a professional for an extra fee. You can see it there, or ask us to take care of placement, cabling and Wi-Fi coverage across the whole house.

## Step 7: Complete the order

Press "Ολοκλήρωση παραγγελίας" (Complete order), fill in your delivery and payment details, and check the "Σύνολο οφειλή σήμερα" (Total due today) before you pay. Starlink states that if you cancel and return the undamaged kit within 30 days of the payment due date, you are entitled to a full refund for the kit and the first month.

## Step 8: Delivery and setup

When the kit arrives, follow the Starlink app. It shows whether the dish position is good.

## Why we recommend 200 Mbps and above

As shown on the order page, the 200 Mbps plan comes with the larger, more powerful **Standard 4** kit, while 100 Mbps comes with the smaller **Mini X**. The extra speed also helps in homes with many devices, remote work or busy holiday rentals. Before you pay, always check which kit is listed for the plan you picked.

## Airbnb and holiday lets: pause in winter

If the connection is for a property that is closed in winter, you do not need to pay a full bill all year. You can **pause the connection** (standby mode) for the months the property is closed and switch it back on in spring. Starlink may charge a small monthly fee for standby and may limit how long it lasts, so check the current terms in your account.

## Order link from us: a free month

If you ask us for a **link to order Starlink**, you get **one free month and we get one free month**, through Starlink's referral programme. The free month applies when the order and activation are made through our link. It costs you nothing extra.

Press the button below, leave your details and we will send you the link.`},cat:"tut"}],Se=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),S={tab:"c",lang:"el",site:null,orig:null,photos:[],pdirty:{},arts:null,seeded:!1,busy:!1,loading:!1,edit:null,draft:null,msg:"",ok:"",del:"",started:!1},lh=()=>S.started&&(S.dirty()||!!S.edit);S.dirty=()=>!!S.site&&(JSON.stringify(S.site)!==JSON.stringify(S.orig)||Object.keys(S.pdirty).length>0);const DC=()=>{S.started=!1,S.site=null,S.orig=null,S.photos=[],S.pdirty={},S.arts=null,S.edit=null,S.draft=null,S.msg="",S.ok="",S.del="",S.tab="c",S.lang="el"},ko=()=>(ne()&&ne().pubUrl||"https://tech-mate.gr").replace(/\/?$/,"/"),sn=()=>S.lang==="en"?S.site.en:S.site,xC=()=>{const n={};return Object.keys(xm).forEach(e=>n[e]=Ce(xm[e])),n};async function NC(n){if(!S.loading){S.loading=!0,S.started=!0,n();try{const[e,t]=await Promise.all([Qv("public/site"),GS("public_photos")]),s=e||{},i=xC();Object.keys(s).forEach(o=>i[o]=s[o]),!i.email&&ne()&&ne().bizEmail&&(i.email=ne().bizEmail);const r=s.en&&typeof s.en=="object"?s.en:{};i.en={},Object.keys(Nm).forEach(o=>i.en[o]=r[o]!=null?r[o]:Ce(Nm[o])),delete i.logo,delete i.photos,delete i.vis;const a=s.photos||[];t.sort((o,l)=>{let u=a.indexOf(o.id),h=a.indexOf(l.id);return u<0&&(u=999),h<0&&(h=999),u-h||(l.ts||0)-(o.ts||0)}),S.site=i,S.orig=Ce(i),S.photos=t,S.pdirty={},S.msg=""}catch(e){S.msg="Δεν φορτώθηκε η ιστοσελίδα ("+(e&&e.code||e&&e.message||"σφάλμα")+"). Έλεγξε τους κανόνες ασφαλείας.",S.started=!1}S.loading=!1,n()}}const xl=["cards","services","stats","partners","steps","faq"],io=n=>(n||[]).filter(e=>e&&(e.t||e.v||e.q));async function VC(){const n=S.photos.map(r=>r.id),e=S.photos.filter(r=>r.show!==!1).map(r=>r.id),t={};Object.keys(S.site).forEach(r=>{if(r==="en")return;const a=xl.includes(r)?io(S.site[r]):S.site[r];JSON.stringify(a)!==JSON.stringify(S.orig[r])&&(t[r]=a)});const s={};Object.keys(S.site.en).forEach(r=>{const a=xl.includes(r)?io(S.site.en[r]):S.site.en[r];JSON.stringify(a)!==JSON.stringify(S.orig.en[r])&&(s[r]=a)}),Object.keys(s).length&&(t.en=s);const i=Object.keys(t).length>0;Object.assign(t,{photos:n,vis:e,upd:Date.now(),cardsV:2,svcV:1}),await Li("public/site",t);for(const r of Object.keys(S.pdirty)){const a=S.photos.find(o=>o.id===r);a&&await Li("public_photos/"+r,{t:a.t||"",p:a.p||"",te:a.te||"",pe:a.pe||"",show:a.show!==!1})}S.pdirty={},S.orig=Ce(S.site),S.ok=i||n.length?"Η ιστοσελίδα ενημερώθηκε. Οι αλλαγές φαίνονται ήδη στο "+ko().replace(/^https?:\/\//,"")+" (ανανέωσε τη σελίδα).":"";for(const r of xl)S.site[r]=io(S.site[r]),S.site.en[r]=io(S.site.en[r]);S.orig=Ce(S.site)}const Ro=()=>Li("public/site",{photos:S.photos.map(n=>n.id),vis:S.photos.filter(n=>n.show!==!1).map(n=>n.id)}),OC=n=>{const e={α:"a",β:"v",γ:"g",δ:"d",ε:"e",ζ:"z",η:"i",θ:"th",ι:"i",κ:"k",λ:"l",μ:"m",ν:"n",ξ:"x",ο:"o",π:"p",ρ:"r",σ:"s",ς:"s",τ:"t",υ:"y",φ:"f",χ:"ch",ψ:"ps",ω:"o"},t=String(n||"").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").split("").map(s=>e[s]||s).join("").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,50);return t.length>=2?t:"arthro-"+Date.now().toString(36)};async function Om(n){S.loading=!0,n();try{const e=await Qv("public/articles");let t=null;try{e&&(t=JSON.parse(e.json))}catch{}S.seeded=Array.isArray(t),S.arts=S.seeded?t:Ce(Vm),Vm.forEach(s=>{s.pin&&!S.arts.some(i=>i.id===s.id)&&S.arts.push(Ce(s))})}catch{S.msg="Δεν φορτώθηκαν τα άρθρα."}S.loading=!1,n()}async function MC(n){const e=JSON.stringify(n);if(e.length>9e5)throw new Error("Τα άρθρα είναι πολύ μεγάλα (όριο ~900KB).");await Li("public/articles",{json:e,upd:Date.now()}),S.arts=n,S.seeded=!0}const me=(n,e,t,s)=>{const i=sn()[n]==null?"":sn()[n];return`<label class="f">${e}${t?`<textarea class="in" data-w="${n}" rows="3" ${s?`placeholder="${Se(s)}"`:""}>${Se(i)}</textarea>`:`<input class="in" data-w="${n}" value="${Se(i)}" ${s?`placeholder="${Se(s)}"`:""}>`}</label>`};function oi(n,e,t,s){return(sn()[n]||[]).map((r,a)=>`<div class="card pad" style="margin:0 0 8px">${e.map(([o,l])=>`<input class="in" style="margin-bottom:6px" data-wl="${n}:${a}:${o}" value="${Se(r[o]||"")}" placeholder="${Se(l)}">`).join("")}
    ${s?`<textarea class="in" data-wl="${n}:${a}:m" rows="5" placeholder="${Se(s)}">${Se(r.m||"")}</textarea>`:""}
    ${n==="partners"&&S.lang==="el"?`${r.l?`<img class="logo-prev" src="${Se(r.l)}" style="max-height:48px">`:""}<label class="btn b2">🖼️ ${r.l?"Αλλαγή":"Λογότυπο"}<input type="file" accept="image/*" data-wlogo="${a}" hidden></label>${r.l?`<button class="btn b2" data-web-ldel="${a}">🗑️</button>`:""}`:""}
    <div class="actions"><button class="btn b2" data-web-up="${n}:${a}" ${a?"":"disabled"}>↑</button><button class="btn b2" data-web-del="${n}:${a}">✕ Αφαίρεση</button></div></div>`).join("")+`<button class="btn b2 wide" data-web-add="${n}">＋ ${t}</button>`}function Yt(n){return`<div class="grp" style="margin-top:14px">${n}</div>`}function LC(){const n=S.lang==="en";return`<div class="actions"><button class="btn ${n?"b2":"b1"}" data-web-lang="el">🇬🇷 Ελληνικά</button><button class="btn ${n?"b1":"b2"}" data-web-lang="en">🇬🇧 English</button></div>
  ${n?'<div class="muted small">Επεξεργάζεσαι τα αγγλικά κείμενα. Τηλέφωνα, email και λογότυπα είναι κοινά και αλλάζουν από τα ελληνικά.</div>':""}
  <div class="card pad">${Yt("🏠 Κεντρικό")}${me("eyebrow","Μικρή γραμμή πάνω")}${me("h1a","Τίτλος (αρχή)")}${me("h1b","Τίτλος (κίτρινη λέξη)")}${me("h1c","Τίτλος (τέλος)")}${me("lead","Κείμενο κάτω από τον τίτλο",1)}${me("powered","Powered by")}
  <div class="lbl">Κάρτες δίπλα στον τίτλο</div>${oi("cards",[["ic","😀 εικονίδιο"],["t","Τίτλος"],["s","Περιγραφή"]],"Κάρτα")}
  ${Yt("🧰 Υπηρεσίες")}${me("svcTitle","Τίτλος ενότητας")}${me("svcLead","Υπότιτλος",1)}${oi("services",[["ic","😀 εικονίδιο"],["t","Υπηρεσία"],["d","Περιγραφή"]],"Υπηρεσία","Περισσότερες πληροφορίες (ανοίγουν όταν ο πελάτης πατήσει την υπηρεσία). ## Τίτλος · - λίστα · **έντονο**")}
  ${Yt("🪜 Πώς δουλεύουμε")}${oi("steps",[["t","Τίτλος"],["d","Περιγραφή"]],"Βήμα")}
  ${Yt("❓ Συχνές ερωτήσεις")}${oi("faq",[["q","Ερώτηση"],["a","Απάντηση"]],"Ερώτηση")}
  ${Yt("🤝 Συνεργάτες (κατασκευαστές)")}${me("partnersTitle","Τίτλος ενότητας")}${me("partnersLead","Υπότιτλος",1)}${oi("partners",[["t",n?"Company (ίδιο όνομα με τα ελληνικά)":"Εταιρεία (π.χ. Hikvision)"],["s",n?"What it does (English)":"Τι κάνει (π.χ. Κάμερες)"]],"Συνεργάτης")}
  ${Yt("👥 Ποιοι είμαστε")}${me("aboutTitle","Τίτλος")}${me("about1","Παράγραφος 1",1)}${me("about2","Παράγραφος 2",1)}<div class="lbl">Αριθμοί (π.χ. «150+» · «εγκαταστάσεις»)</div>${oi("stats",[["v","Αριθμός"],["l","Τι μετράει"]],"Αριθμός")}
  ${Yt("📞 Επικοινωνία")}${me("contactTitle","Τίτλος")}${me("contactLead","Κείμενο",1)}${n?"":me("phone","Τηλέφωνο",0,"210 0000000")+me("mobile","Κινητό (Viber / WhatsApp)",0,"69xxxxxxxx")+me("email","Email")}${me("hours","Ωράριο")}${me("area","Περιοχή")}${me("areaNote","Σημείωση περιοχής")}
  ${n?"":me("facebook","Facebook (link)")+me("instagram","Instagram (link)")+me("cfToken","Cloudflare Web Analytics (token, 32 χαρακτήρες)")+me("reviewUrl","Google αξιολογήσεις (link «Γράψε κριτική»)")}
  ${n?"":Yt("🏢 Στοιχεία επιχείρησης (υποσέλιδο & πολιτική απορρήτου)")+'<div class="muted small">Εμφανίζονται μόνο όσα συμπληρώσεις.</div>'+me("bizName","Επωνυμία / διακριτικός τίτλος")+me("afm","ΑΦΜ")+me("doy","ΔΟΥ")+me("gemi","ΓΕΜΗ (προαιρετικό)")+me("bizAddr","Διεύθυνση έδρας")}
  ${Yt("🔎 Google")}${me("title","Τίτλος σελίδας (καρτέλα / Google)")}${me("desc","Περιγραφή για το Google",1)}</div>`}function FC(){const n=S.lang==="en",e=S.photos,t=e.filter(s=>!(s.t||"").trim()&&s.show!==!1).length;return`<div class="card pad"><div class="actions"><button class="btn b2" data-web-lang="el" ${n?"":'style="font-weight:700"'}>🇬🇷 Ελληνικά</button><button class="btn b2" data-web-lang="en" ${n?'style="font-weight:700"':""}>🇬🇧 English</button></div>
  ${n?'<div class="muted small">Αγγλικός τίτλος και περιοχή για κάθε φωτογραφία. Αν μείνει κενό, φαίνεται χωρίς λεζάντα.</div>':t?`<div class="err box">⚠️ ${t} φωτογραφί${t===1?"α":"ες"} χωρίς τίτλο. Ο τίτλος βοηθά τη Google και τους ανθρώπους με προβλήματα όρασης.</div>`:""}
  ${me("workTitle","Τίτλος ενότητας «Έργα»")}${me("workLead","Υπότιτλος",1)}
  ${e.map((s,i)=>`<div class="card pad" style="margin:8px 0;${s.show===!1?"opacity:.6":""}"><img class="logo-prev" src="${Se(s.thumb||"")}" style="max-height:140px">
    <input class="in" style="margin-top:6px" data-wp="${i}:${n?"te":"t"}" placeholder="${n?"Title (English)":"Τίτλος (π.χ. Εγκατάσταση καμερών σε ξενοδοχείο)"}" value="${Se(n?s.te||"":s.t||"")}">
    <input class="in" style="margin-top:6px" data-wp="${i}:${n?"pe":"p"}" placeholder="${n?"Area (English)":"Περιοχή"}" value="${Se(n?s.pe||"":s.p||"")}">
    <div class="actions"><button class="btn b2" data-web-pup="${i}" ${i?"":"disabled"}>↑</button><button class="btn b2" data-web-pshow="${i}">${s.show===!1?"Εμφάνιση":"Απόκρυψη"}</button><button class="btn b2" data-web-pdel="${i}">${S.del==="p"+s.id?"Σίγουρα;":"✕"}</button></div></div>`).join("")||'<div class="muted small">Δεν υπάρχουν φωτογραφίες ακόμα· η ενότητα «Έργα» δεν εμφανίζεται μέχρι να προσθέσεις.</div>'}
  <label class="btn b1 wide" style="margin-top:8px">📷 Προσθήκη φωτογραφιών<input type="file" accept="image/*" multiple data-wph hidden></label>
  <div class="muted small">Οι φωτογραφίες μικραίνουν αυτόματα. Πρόσεξε να μη φαίνονται διευθύνσεις, πρόσωπα ή πινακίδες.</div></div>`}function UC(){if(!S.arts)return'<div class="card pad"><button class="btn b1 wide" data-web-aload>📰 Φόρτωση άρθρων</button></div>';if(S.edit){const n=S.draft,e=(t,s)=>{const i=n[t]||{};return`${Yt(s)}<label class="f">Τίτλος<input class="in" maxlength="140" data-wa="${t}:t" value="${Se(i.t||"")}"></label><label class="f">Σύντομη περιγραφή (για τη λίστα)<textarea class="in" rows="2" data-wa="${t}:d">${Se(i.d||"")}</textarea></label><label class="f">Κείμενο<textarea class="in" rows="14" data-wa="${t}:b">${Se(i.b||"")}</textarea></label>`};return`<div class="card pad"><b>${S.edit==="__new"?"Νέο άρθρο":"Επεξεργασία άρθρου"}</b>
    <div class="muted small">Κενή γραμμή = νέα παράγραφος · ## Τίτλος ενότητας · - λίστα (ή 1. αριθμημένη) · **έντονο** · *πλάγιο* · [κείμενο](https://σύνδεσμος)</div>
    <label class="f">Πού εμφανίζεται<select class="in" data-wa="cat"><option value="">📰 Άρθρα</option><option value="tut"${n.cat==="tut"?" selected":""}>🛠️ Βοηθήματα (tutorials)</option></select></label>
    <label class="chk"><input type="checkbox" data-wa="on" ${n.on===!1?"":"checked"}> Εμφανίζεται στο site</label>
    ${e("el","🇬🇷 Ελληνικά")}${e("en","🇬🇧 Αγγλικά (προαιρετικά)")}${S.msg?`<div class="err box">${Se(S.msg)}</div>`:""}
    <div class="actions"><button class="btn b2" data-web-acancel>Άκυρο</button><button class="btn b1" data-web-asave>💾 Αποθήκευση</button></div></div>`}return`<div class="card pad"><button class="btn b1 wide" data-web-anew>➕ Νέο άρθρο</button><div class="muted small">Οι αλλαγές φαίνονται αμέσως στο site.${S.seeded?"":" Τώρα εμφανίζονται τα προεπιλεγμένα άρθρα· αποθηκεύονται στη βάση μόλις αλλάξεις κάτι."}</div></div>
  <div class="card">${S.arts.map((n,e)=>`<div class="item" style="${n.on===!1?"opacity:.6":""}"><div class="t"><b>${Se(n.el&&n.el.t||n.en&&n.en.t||"(χωρίς τίτλο)")}</b><span>${n.on===!1?"κρυφό · ":""}${n.cat==="tut"?"🛠️ Βοηθήματα":"📰 Άρθρο"}${n.en&&n.en.t?"":" · χωρίς αγγλικά"}</span></div>
    <div class="actions" style="margin-top:6px"><button class="btn b2" data-web-aedit="${Se(n.id)}">✏️</button><button class="btn b2" data-web-aup="${Se(n.id)}" ${e?"":"disabled"}>↑</button><button class="btn b2" data-web-adn="${Se(n.id)}" ${e<S.arts.length-1?"":"disabled"}>↓</button><button class="btn b2" data-web-atog="${Se(n.id)}">${n.on===!1?"Εμφάνιση":"Απόκρυψη"}</button><button class="btn b2" data-web-adel="${Se(n.id)}">${S.del==="a"+n.id?"Σίγουρα;":"✕"}</button></div></div>`).join("")||'<div class="empty">Δεν υπάρχουν άρθρα.</div>'}</div>`}function qC(n,e){if(!S.site)return e(n("Ιστοσελίδα","",'<a class="ib" href="#/menu">←</a>'),`<div class="card pad"><div class="muted small">Η δημόσια σελίδα που βλέπουν οι πελάτες στο ${Se(ko().replace(/^https?:\/\//,""))}. Αλλάζεις κείμενα, τηλέφωνα, φωτογραφίες έργων και άρθρα από εδώ — χωρίς ανέβασμα.</div>
    ${S.msg?`<div class="err box">${Se(S.msg)}</div>`:""}<button class="btn b1 wide" data-web-open ${S.loading?"disabled":""}>${S.loading?"Φόρτωση…":"✏️ Επεξεργασία ιστοσελίδας"}</button><a class="btn b2 wide" href="${Se(ko())}" target="_blank" rel="noopener" style="margin-top:8px">👁️ Άνοιγμα σελίδας</a></div>
    <div class="card"><a class="mi" href="#/msgs"><div class="ic">📨</div><div class="t"><b>Μηνύματα ιστοσελίδας</b><span>Αιτήματα από τη φόρμα επικοινωνίας</span></div></a></div>`,"menu");const t=[["c","Περιεχόμενο"],["p","Φωτογραφίες"],["a","Άρθρα"]],s=S.dirty();return e(n("Ιστοσελίδα",s?"Υπάρχουν αλλαγές που δεν δημοσιεύτηκαν":"",'<a class="ib" data-web-close>←</a>'),`<div class="actions" style="margin:0 0 8px">${t.map(([i,r])=>`<button class="btn ${S.tab===i?"b1":"b2"}" data-web-tab="${i}">${r}</button>`).join("")}</div>
    ${S.ok?`<div class="upd">${Se(S.ok)}</div>`:""}${S.msg&&S.tab!=="a"?`<div class="err box">${Se(S.msg)}</div>`:""}
    ${S.tab==="c"?LC():S.tab==="p"?FC():UC()}
    ${S.tab!=="a"?`<div class="card pad"><button class="btn b1 wide" data-web-save ${S.busy?"disabled":""}>🌐 Δημοσίευση αλλαγών</button><a class="btn b2 wide" href="${Se(ko())}" target="_blank" rel="noopener" style="margin-top:8px">👁️ Άνοιγμα σελίδας</a></div>`:""}`,"menu")}function BC(n){return new Promise((e,t)=>{const s=URL.createObjectURL(n),i=new Image;i.onload=()=>{const r=(l,u)=>{const h=Math.min(1,l/Math.max(i.naturalWidth,i.naturalHeight)),p=document.createElement("canvas");p.width=Math.round(i.naturalWidth*h),p.height=Math.round(i.naturalHeight*h),p.getContext("2d").drawImage(i,0,0,p.width,p.height);let m=p.toDataURL("image/webp",u);return m.indexOf("data:image/webp")!==0&&(m=p.toDataURL("image/jpeg",u)),m},a=r(640,.72);let o=r(1600,.8);o.length>9e5&&(o=r(1280,.7)),URL.revokeObjectURL(s),e({thumb:a,full:o})},i.onerror=()=>{URL.revokeObjectURL(s),t(new Error("Η εικόνα δεν διαβάζεται (π.χ. HEIC). Δοκίμασε JPG/PNG."))},i.src=s})}function jC(n){return new Promise((e,t)=>{const s=URL.createObjectURL(n),i=new Image;i.onload=()=>{const r=Math.min(1,320/i.width,120/i.height),a=Math.max(1,Math.round(i.width*r)),o=Math.max(1,Math.round(i.height*r)),l=document.createElement("canvas");l.width=a,l.height=o,l.getContext("2d").drawImage(i,0,0,a,o),URL.revokeObjectURL(s);let u=l.toDataURL("image/webp",.92);if(u.indexOf("data:image/webp")!==0&&(u=l.toDataURL("image/png")),u.length>9e4&&(u=l.toDataURL("image/webp",.7)),u.length>12e4)return t(new Error("Το λογότυπο είναι πολύ βαρύ· δοκίμασε πιο απλή εικόνα."));e(u)},i.onerror=()=>{URL.revokeObjectURL(s),t(new Error("Δεν διαβάστηκε η εικόνα."))},i.src=s})}const WC="[data-web-open],[data-web-close],[data-web-tab],[data-web-lang],[data-web-add],[data-web-del],[data-web-up],[data-web-ldel],[data-web-save],[data-web-pup],[data-web-pshow],[data-web-pdel],[data-web-aload],[data-web-anew],[data-web-aedit],[data-web-aup],[data-web-adn],[data-web-atog],[data-web-adel],[data-web-asave],[data-web-acancel]";function zC(n,e,t){const s=n.closest(WC);if(!s)return!1;const i=s.dataset;S.ok="",!i.webPdel&&!i.webAdel&&(S.del="");const r=o=>o==="stats"?{v:"",l:""}:o==="partners"?{t:"",s:""}:o==="steps"?{t:"",d:""}:o==="faq"?{q:"",a:""}:o==="cards"?{ic:"✅",t:"",s:""}:{ic:"🔧",t:"",d:""},a=async(o,l,u)=>{try{await MC(o),l&&t(l)}catch(h){S.msg=h.message||"Δεν αποθηκεύτηκε."}u&&u(),e()};if(i.webOpen!==void 0)return NC(e),!0;if(i.webClose!==void 0){if(S.dirty()&&!confirm("Έχεις αλλαγές που δεν δημοσιεύτηκαν. Κλείσιμο χωρίς δημοσίευση;"))return!0;DC()}else if(i.webTab){if(S.tab=i.webTab,S.msg="",S.tab==="a"&&!S.arts&&!S.loading)return Om(e),!0}else if(i.webLang)S.lang=i.webLang;else if(i.webAdd)(sn()[i.webAdd]=sn()[i.webAdd]||[]).push(r(i.webAdd));else if(i.webDel){const[o,l]=i.webDel.split(":");sn()[o].splice(+l,1)}else if(i.webUp){const[o,l]=i.webUp.split(":"),u=sn()[o],h=+l;if(h>0){const p=u[h];u[h]=u[h-1],u[h-1]=p}}else if(i.webLdel!==void 0)delete S.site.partners[+i.webLdel].l;else if(i.webSave!==void 0){if(S.busy)return!0;S.busy=!0,S.msg="",VC().then(()=>{S.busy=!1,t("Η ιστοσελίδα ενημερώθηκε."),e()},o=>{S.busy=!1,S.msg="Δεν δημοσιεύτηκε ("+(o&&o.code||"σφάλμα")+"). Έλεγξε τους κανόνες ασφαλείας.",e()})}else if(i.webPup!==void 0){const o=+i.webPup,l=S.photos;if(o>0){const u=l[o];l[o]=l[o-1],l[o-1]=u,Ro().catch(()=>{})}}else if(i.webPshow!==void 0){const o=S.photos[+i.webPshow];o.show=o.show===!1,S.pdirty[o.id]=1,Ro().catch(()=>{})}else if(i.webPdel!==void 0){const o=S.photos[+i.webPdel];S.del!=="p"+o.id?S.del="p"+o.id:(S.del="",S.photos.splice(+i.webPdel,1),delete S.pdirty[o.id],Promise.all([tm("public_photos/"+o.id),tm("public_photos_full/"+o.id)]).then(Ro).then(()=>t("Η φωτογραφία αφαιρέθηκε από τη σελίδα."),()=>t("Δεν διαγράφηκε.")))}else{if(i.webAload!==void 0)return Om(e),!0;if(i.webAnew!==void 0)S.edit="__new",S.draft={id:"",on:!0,el:{t:"",d:"",b:""},en:{t:"",d:"",b:""}},S.msg="",scrollTo(0,0);else if(i.webAedit){const o=S.arts.find(l=>l.id===i.webAedit);o&&(S.edit=o.id,S.draft=Ce(o),S.msg="",scrollTo(0,0))}else if(i.webAcancel!==void 0)S.edit=null,S.draft=null,S.msg="";else if(i.webAsave!==void 0){const o=S.draft;if(o.el=o.el||{},o.en=o.en||{},["el","en"].forEach(u=>["t","d","b"].forEach(h=>o[u][h]=String(o[u][h]||"").trim())),!o.el.t||!o.el.b)return S.msg="Γράψε τίτλο και κείμενο στα ελληνικά.",e(),!0;if(o.en.t&&!o.en.b)return S.msg="Στα αγγλικά έχεις τίτλο αλλά όχι κείμενο.",e(),!0;if(o.el.b.length>2e4||o.en.b.length>2e4)return S.msg="Το κείμενο είναι πολύ μεγάλο.",e(),!0;let l=S.arts.slice();if(S.edit==="__new"){const u=OC(o.el.t);let h=u,p=2;for(;l.some(m=>m.id===h);)h=u+"-"+p++;o.id=h,l.push(o)}else l=l.map(u=>u.id===S.edit?o:u);return S.msg="",a(l,"✅ Το άρθρο αποθηκεύτηκε και φαίνεται ήδη στο site.",()=>{S.msg||(S.edit=null,S.draft=null)}),!0}else if(i.webAup||i.webAdn){const o=i.webAup||i.webAdn,l=S.arts.slice(),u=l.findIndex(p=>p.id===o),h=i.webAup?u-1:u+1;if(u>=0&&h>=0&&h<l.length){const p=l[u];return l[u]=l[h],l[h]=p,a(l),!0}}else{if(i.webAtog)return a(S.arts.map(o=>o.id===i.webAtog?{...o,on:o.on===!1}:o)),!0;if(i.webAdel)if(S.del!=="a"+i.webAdel)S.del="a"+i.webAdel;else return S.del="",a(S.arts.filter(o=>o.id!==i.webAdel),"Το άρθρο διαγράφηκε."),!0}}return e(),!0}function uh(n){const e=n.dataset;if(!S.site&&!S.draft)return!1;if(e.w&&S.site)return sn()[e.w]=n.value,!0;if(e.wl&&S.site){const[t,s,i]=e.wl.split(":"),r=sn()[t]&&sn()[t][+s];return r&&(r[i]=n.value),!0}if(e.wp!==void 0&&S.site){const[t,s]=e.wp.split(":"),i=S.photos[+t];return i&&(i[s]=n.value,S.pdirty[i.id]=1),!0}if(e.wa&&S.draft){const[t,s]=e.wa.split(":");return s?(S.draft[t]=S.draft[t]||{},S.draft[t][s]=n.value):t==="on"?S.draft.on=n.checked:t==="cat"&&(n.value==="tut"?S.draft.cat="tut":delete S.draft.cat),!0}return!1}function GC(n,e,t){const s=n.dataset;return s.wa&&S.draft?(uh(n),!0):s.wlogo!==void 0||s.wph!==void 0?(KC(n,e,t),!0):!1}async function KC(n,e,t){const s=n.dataset;if(s.wa&&S.draft)return uh(n),!0;if(s.wlogo!==void 0&&n.files&&n.files[0]){try{S.site.partners[+s.wlogo].l=await jC(n.files[0]),S.msg=""}catch(i){S.msg=i.message}return e(),!0}if(s.wph!==void 0&&n.files&&n.files.length){const i=[...n.files];n.value="";let r=0;t("Ανέβασμα φωτογραφιών…");for(const a of i)try{const o=await BC(a),l=ze(),u={t:a.name.replace(/\.[^.]+$/,"").replace(/[_-]+/g," ").replace(/^(IMG|DSC|PXL|WP)\s*\d.*$/i,""),p:"",thumb:o.thumb,ts:Date.now(),show:!0,od:""};await Li("public_photos/"+l,u),await Li("public_photos_full/"+l,{full:o.full,ts:u.ts}),S.photos.push({...u,id:l}),r++,e()}catch(o){S.msg=o&&o.message?o.message:"Μια φωτογραφία δεν ανέβηκε."}if(r){try{await Ro()}catch{}t("Προστέθηκαν "+r+" φωτογραφίες. Γράψε τίτλο σε κάθε μία και πάτα «Δημοσίευση».")}return e(),!0}return!1}const nt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Nl=n=>String(n??"").replace(".",","),jr=n=>{const e=parseFloat(String(n??"").replace(",","."));return isNaN(e)?NaN:e},pa=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Mm=n=>{if(n=String(n||"").trim(),!n)return"";/^https?:\/\//i.test(n)||(n="https://"+n);try{const e=new URL(n);return e.protocol==="http:"||e.protocol==="https:"?e.href:""}catch{return""}},oc=n=>Array.isArray(n.links)&&n.links.length?n.links:n.sup||n.url?[{sup:n.sup||"",url:n.url||""}]:[],re={q:"",cat:"",f:null,msg:""},dh=()=>!!re.f,HC=()=>{re.f=null,re.msg=""};function QC(){return{id:"",cat:re.cat||"",model:"",desc:"",descEn:"",code:"",cost:"",mtype:"pct",mval:"",links:[{sup:"",url:""}],notes:"",imgPdf:!0,img:void 0,hist:""}}function JC(n){const e=n.marginEur!=null&&n.marginEur!=="",t=(n.costHist||[]).slice(-6).map(s=>(s.ts?new Date(s.ts).toLocaleDateString("el-GR")+": ":"")+pa.format(k(s.cost))).join("  →  ");return{id:n.id,cat:n.cat||"",model:n.model||"",desc:n.desc||"",descEn:n.descEn||"",code:n.code||"",cost:Nl(k(n.cost,0)),mtype:e?"eur":"pct",mval:e?Nl(k(n.marginEur)):n.margin==null||n.margin===""?"":Nl(k(n.margin)),links:oc(n).length?oc(n).map(s=>({sup:s.sup||"",url:s.url||""})):[{sup:"",url:""}],notes:n.notes||"",imgPdf:n.imgPdf!==!1,img:void 0,hist:t}}const Db=()=>[...new Set(A.products.map(n=>n.cat).filter(Boolean))].sort((n,e)=>n.localeCompare(e,"el")),YC=()=>[...new Set(A.products.flatMap(n=>oc(n).map(e=>e.sup)).filter(Boolean))].sort((n,e)=>n.localeCompare(e,"el"));function xb(n){const e=n.mtype==="eur",t=String(n.mval).trim();return{cost:jr(n.cost)||0,margin:!e&&t!==""?jr(t):null,marginEur:e&&t!==""?jr(t):null}}function Nb(n){if(!String(n.cost).trim())return"";const e=xb(n),t=Nc(e);return`Τιμή πώλησης <b>${pa.format(t)}</b> · κέρδος <b>${pa.format(q(t-e.cost))}</b>`}function XC(n,e){if(re.f)return ZC(n,e);const t=re.q.trim().toLowerCase(),s=A.products.filter(a=>(!re.cat||a.cat===re.cat)&&(!t||[a.model,a.desc,a.cat,a.code,a.sup].join(" ").toLowerCase().includes(t))).sort((a,o)=>String(a.cat||"").localeCompare(String(o.cat||""),"el")||String(a.model).localeCompare(String(o.model),"el"));let i=null;const r=s.map(a=>{const o=a.cat!==i?`<div class="grp">${nt(a.cat||"Χωρίς κατηγορία")}</div>`:"";return i=a.cat,o+`<a class="item" data-cat-edit="${nt(a.id)}"><div class="t" style="display:flex;gap:10px;align-items:center">${a.img?`<img class="pth" src="${nt(a.img)}">`:'<span class="pth ph">📦</span>'}<span style="flex:1;min-width:0"><b>${nt(a.model)}</b><span>${nt(a.desc||"")}</span></span><span style="text-align:right"><b>${pa.format(Nc(a))}</b><span>κόστος ${pa.format(k(a.cost))}</span></span></div></a>`}).join("");return e(n("Κατάλογος",s.length+" προϊόντα",'<a class="ib" href="#/menu">←</a>'),`<div class="card pad"><input class="in" data-cat-q placeholder="🔍 Αναζήτηση (μοντέλο, περιγραφή, barcode)" value="${nt(re.q)}">
    <select class="in" data-cat-f style="margin-top:8px"><option value="">Όλες οι κατηγορίες</option>${Db().map(a=>`<option${a===re.cat?" selected":""}>${nt(a)}</option>`).join("")}</select>
    <button class="btn b1 wide" data-cat-new style="margin-top:8px">＋ Νέο προϊόν</button></div>
    <div class="card">${r||'<div class="empty">Κανένα προϊόν.</div>'}</div>
    <div class="muted small" style="padding:0 6px 10px">Η διαγραφή προϊόντων γίνεται μόνο από το PWA.</div>`,"menu")}function ZC(n,e){const t=re.f,s=!t.id,i=(a,o,l="",u="")=>`<label class="f">${o}<input class="in" data-cf="${a}" value="${nt(t[a])}" ${l} ${u?`list="${u}"`:""}></label>`,r=t.img===void 0?(A.products.find(a=>a.id===t.id)||{}).img:t.img&&t.img.thumb;return e(n(s?"Νέο προϊόν":"Επεξεργασία προϊόντος","",'<a class="ib" data-cat-cancel>←</a>'),`<div class="card pad">
    <datalist id="cl-cats">${Db().map(a=>`<option value="${nt(a)}">`).join("")}</datalist><datalist id="cl-sups">${YC().map(a=>`<option value="${nt(a)}">`).join("")}</datalist>
    ${i("cat","Κατηγορία","","cl-cats")}${i("model","Μοντέλο")}
    <label class="f">Περιγραφή (ελληνικά)<textarea class="in" data-cf="desc" rows="3">${nt(t.desc)}</textarea></label>
    <label class="f">Περιγραφή στα αγγλικά (για PDF στα αγγλικά)<textarea class="in" data-cf="descEn" rows="3">${nt(t.descEn)}</textarea></label>
    ${i("code","Barcode / κωδικός",'autocapitalize="off"')}${i("cost","Κόστος αγοράς € (χωρίς ΦΠΑ)",'inputmode="decimal"')}
    <label class="f">Κέρδος<select class="in" data-cf="mtype"><option value="pct"${t.mtype==="pct"?" selected":""}>Ποσοστό %</option><option value="eur"${t.mtype==="eur"?" selected":""}>Ποσό € ανά τεμάχιο</option></select></label>
    ${i("mval",t.mtype==="eur"?"Κέρδος € ανά τεμάχιο":"Κέρδος % (κενό = προεπιλογή "+k(ne()&&ne().margin,25)+"%)",'inputmode="decimal"')}
    <div class="upd" id="cat-prev">${Nb(t)}</div>
    ${t.hist?`<div class="muted small">Ιστορικό κόστους: ${nt(t.hist)}</div>`:""}
    <div class="lbl">Προμηθευτές / links</div>
    ${t.links.map((a,o)=>`<div class="card pad" style="margin:0 0 8px"><label class="f">Προμηθευτής<input class="in" data-cl="${o}:sup" list="cl-sups" value="${nt(a.sup)}"></label>
      <label class="f">Link προϊόντος ή προμηθευτή<input class="in" data-cl="${o}:url" inputmode="url" autocapitalize="off" value="${nt(a.url)}"></label>
      ${t.links.length>1?`<button class="btn b2" data-cat-ldel="${o}">🗑️ Αφαίρεση</button>`:""}</div>`).join("")}
    <button class="btn b2 wide" data-cat-ladd>＋ Άλλος προμηθευτής</button>
    <label class="f">Σημειώσεις<textarea class="in" data-cf="notes" rows="2">${nt(t.notes)}</textarea></label>
    <div class="lbl">Φωτογραφία</div>${r?`<img class="logo-prev" src="${nt(r)}">`:'<div class="muted small">Δεν υπάρχει φωτογραφία.</div>'}
    <label class="btn b2 wide">📷 ${r?"Αλλαγή":"Προσθήκη"} φωτογραφίας<input type="file" accept="image/*" data-cimg hidden></label>
    ${r?'<button class="btn b2 wide" data-cat-imgdel style="margin-top:6px">Αφαίρεση φωτογραφίας</button>':""}
    <label class="chk"><input type="checkbox" data-cf="imgPdf" ${t.imgPdf?"checked":""}> Να μπαίνει η φωτογραφία στο PDF της προσφοράς</label>
    ${re.msg?`<div class="err box">${nt(re.msg)}</div>`:""}
    <div class="actions"><button class="btn b2" data-cat-cancel>Άκυρο</button><button class="btn b1" data-cat-save>${s?"➕ Προσθήκη":"💾 Αποθήκευση"}</button></div></div>`,"menu")}function e$(n){return new Promise((e,t)=>{const s=new FileReader;s.onerror=()=>t(new Error("Δεν διαβάστηκε")),s.onload=()=>{const i=new Image;i.onerror=()=>t(new Error("Δεν είναι εικόνα")),i.onload=()=>{const r=l=>{const u=Math.min(1,l/Math.max(i.naturalWidth,i.naturalHeight)),h=document.createElement("canvas");h.width=Math.max(1,Math.round(i.naturalWidth*u)),h.height=Math.max(1,Math.round(i.naturalHeight*u));const p=h.getContext("2d");return p.fillStyle="#fff",p.fillRect(0,0,h.width,h.height),p.drawImage(i,0,0,h.width,h.height),h},a=r(900),o=r(200);e({full:a.toDataURL("image/jpeg",.8),thumb:o.toDataURL("image/jpeg",.78),w:a.width,h:a.height})},i.src=s.result},s.readAsDataURL(n)})}function t$(n){const e=re.f,t=!e.id,s=e.model.trim();if(!s)return re.msg="Βάλε μοντέλο.";const i=jr(e.cost);if(isNaN(i)||i<0)return re.msg="Βάλε έγκυρο κόστος.";const r=String(e.mval).trim();if(r!==""&&isNaN(jr(r)))return re.msg="Το κέρδος δεν είναι αριθμός.";const a=e.links.map(u=>({sup:u.sup.trim(),url:u.url.trim()})).filter(u=>u.sup||u.url);for(const u of a){if(u.url&&!Mm(u.url))return re.msg="Το link «"+u.url+"» δεν είναι έγκυρο.";u.url=u.url?Mm(u.url):""}const o=xb(e),l={cat:e.cat.trim(),model:s,desc:e.desc.trim(),descEn:e.descEn.trim(),code:e.code.trim(),cost:i,margin:o.margin,marginEur:o.marginEur,links:a,sup:a.length?a[0].sup:"",url:a.length?a[0].url:"",notes:e.notes.trim(),imgPdf:!!e.imgPdf};if(t){const u=ze(),h={...l,id:u,costHist:[{ts:Date.now(),cost:i}],img:"",imgW:0,imgH:0};e.img&&(em(u,{d:e.img.full,w:e.img.w,h:e.img.h}),Object.assign(h,{img:e.img.thumb,imgW:e.img.w,imgH:e.img.h,imgFull:!0})),Ge("products",h)}else{const u=A.products.find(p=>p.id===e.id);if(!u)return re.msg="Το προϊόν δεν βρέθηκε.";const h={};if(Object.keys(l).forEach(p=>{const m=u[p]===void 0?p==="links"?oc(u):p==="imgPdf"?!0:null:u[p];JSON.stringify(m)!==JSON.stringify(l[p])&&!((m==null||m==="")&&(l[p]==null||l[p]===""))&&(h[p]=l[p])}),k(u.cost)!==i){const p=u.costHist&&u.costHist.length?u.costHist.slice():[{ts:0,cost:k(u.cost)}];p.push({ts:Date.now(),cost:i}),h.costHist=p.slice(-20)}e.img?(em(e.id,{d:e.img.full,w:e.img.w,h:e.img.h}),Object.assign(h,{img:e.img.thumb,imgW:e.img.w,imgH:e.img.h,imgFull:!0})):e.img===!1&&(u.imgFull&&zS(e.id),Object.assign(h,{img:"",imgW:0,imgH:0,imgFull:!1})),Object.keys(h).length&&zt("products",e.id,h)}re.f=null,re.msg="",n(t?"Το προϊόν προστέθηκε.":"Το προϊόν ενημερώθηκε.")}function n$(n,e,t){const s=n.closest("[data-cat-edit],[data-cat-new],[data-cat-cancel],[data-cat-save],[data-cat-ladd],[data-cat-ldel],[data-cat-imgdel]");if(!s)return!1;const i=s.dataset;if(i.catEdit){const r=A.products.find(a=>a.id===i.catEdit);r&&(re.f=JC(r),re.msg="",scrollTo(0,0))}else i.catNew!==void 0?(re.f=QC(),re.msg="",scrollTo(0,0)):i.catCancel!==void 0?(re.f=null,re.msg=""):i.catSave!==void 0?t$(t):i.catLadd!==void 0?re.f.links.push({sup:"",url:""}):i.catLdel!==void 0?re.f.links.splice(+i.catLdel,1):i.catImgdel!==void 0&&(re.f.img=!1);return e(),!0}function s$(n,e){const t=n.dataset;if(t.catQ!==void 0){re.q=n.value,e();const s=document.querySelector("[data-cat-q]");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(!re.f)return!1;if(t.cf){re.f[t.cf]=n.type==="checkbox"?n.checked:n.value,re.msg="";const s=document.getElementById("cat-prev");return s&&(s.innerHTML=Nb(re.f)),!0}if(t.cl){const[s,i]=t.cl.split(":");return re.f.links[+s][i]=n.value,re.msg="",!0}return!1}function i$(n,e){const t=n.dataset;return t.catF!==void 0?(re.cat=n.value,e(),!0):re.f?t.cimg!==void 0&&n.files&&n.files[0]?((async()=>{try{re.f.img=await e$(n.files[0]),re.msg=""}catch(s){re.msg=s.message}e()})(),!0):t.cf&&n.tagName==="SELECT"?(re.f[t.cf]=n.value,e(),!0):!1:!1}const r$=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),a$=new Intl.NumberFormat("en-GB",{style:"currency",currency:"EUR"}),o$=n=>r$.format(Math.round((n||0)*100)/100),c$=n=>a$.format(Math.round((n||0)*100)/100),l$=n=>String(q(n)).replace(".",","),u$=n=>String(q(n)),Vb=n=>n.qty*n.price*(1-(n.disc||0)/100),d$=864e5,Lm={el:{war:"Εγγύηση ",mUnit:"μήνες",noWar:"Χωρίς εγγύηση",planTitle:"Κάτοψη και θέσεις εξοπλισμού",planCam:"Κάμερα",planAp:"Access Point",planOther:"Σημείο",option:"Εναλλακτική: ",valid:"Ισχύει έως: ",payTitle:"Στοιχεία πληρωμής",payBank:"Τράπεζα",payIban:"IBAN",payHolder:"Δικαιούχος",payAfm:"ΑΦΜ",payRef:"Αιτιολογία",payRefVal:"Προσφορά ",payNote:"Παρακαλούμε ελέγξτε το όνομα δικαιούχου και το ΑΦΜ πριν στείλετε την πληρωμή.",notesTitle:"Σημειώσεις",termsTitle:"Όροι και προϋποθέσεις",page:"Σελίδα",of:"από",lang:"el",benTitle:"Τι κερδίζετε",file:"Prosfora_"},en:{war:"Warranty ",mUnit:"months",noWar:"No warranty",planTitle:"Layout and equipment positions",planCam:"Camera",planAp:"Access Point",planOther:"Point",option:"Option: ",valid:"Valid until: ",payTitle:"Payment details",payBank:"Bank",payIban:"IBAN",payHolder:"Beneficiary",payAfm:"VAT No.",payRef:"Reference",payRefVal:"Quotation ",payNote:"Please verify the beneficiary name and VAT number before sending your payment.",notesTitle:"Notes",termsTitle:"Terms and conditions",page:"Page",of:"of",lang:"en",benTitle:"What you gain",title:"QUOTATION",no:"No.: ",date:"Date: ",to:"To",subject:"Subject: ",desc:"Description",qty:"Qty",unit:"Unit price",disc:"Disc.",total:"Total",net:"Net amount",vat:"VAT ",grand:"TOTAL",grandNoVat:"TOTAL (no VAT)",file:"Quotation_"}},h$=n=>!(n&&n.war&&n.war.on===!1),f$=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(k(e.m,0))):k(ne().warrantyMonths,24)},p$=(n,e,t)=>{e=e||{};const s=k(e.val,0);return t=t||0,e.type==="eurnet"?q(Math.min(Math.max(0,s)*(1+t/100),n)):e.type==="pct"?q(n*Math.min(100,Math.max(0,s))/100):e.type==="eur"?q(Math.min(Math.max(0,s),n)):0};function Ob(n){let e=0;(n.lines||[]).forEach(u=>e+=Vb(u)),e=q(e);const t=n.vatMode==="off",s=k(ne().vat,24),i=t?0:q(e*s/100),r=q(e+i),a=n.prepay||{},o=t?0:s,l=p$(r,a,o);return{preNet:a.type==="eurnet"?q(l/(1+o/100)):0,sub:e,vat:i,vp:s,vatOff:t,total:r,pre:l,rest:q(r-l),preType:a.type||"",preVal:k(a.val,0)}}const m$=n=>{if(n.descEn)return n.descEn;const e=n.pid&&A.products.find(t=>t.id===n.pid);if(e&&e.descEn){const t=e.model+(e.desc?" - "+e.desc:"");if(!n.desc||n.desc===t)return e.model+" - "+e.descEn}return n.desc},g$=n=>{const e=String(n||"").trim().match(/^(https:\/\/[a-z0-9.-]+\.[a-z]{2,})(:\d+)?\/?$/i);return e?e[1].toLowerCase()+(e[2]||"")+"/":""},y$=n=>String(n&&n.info||"").replace(/\{email\}/gi,n&&n.bizEmail||""),v$=n=>{const e=n.validDays,t=e!=null&&e!==""?k(e,0):ne().validDays==null?15:k(ne().validDays,15);return t?new Date((n.ts||Date.now())+t*d$).toLocaleDateString("el-GR"):""};let ro=null;async function b$(){if(ro)return ro;const[{jsPDF:n},e,t,s,i]=await Promise.all([Fn(()=>import("./jspdf.es.min-BcDp-96k.js").then(o=>o.j),[]),Fn(()=>import("./jspdf.plugin.autotable-DYHf0IZ0.js"),[]),Fn(()=>import("./reg-DWYsL-bi.js"),[]),Fn(()=>import("./bold-BPkZ6IBK.js"),[]),Fn(()=>import("./qrlib-Bgozeulj.js"),[])]);(e.applyPlugin||e.default&&e.default.applyPlugin)(n);const r=new Function(i.default+"; return qrcode;")(),a=await Fn(()=>import("./gen-C78E_0f9.js"),[]);return ro={jsPDF:n,fonts:{reg:t.default.trim(),bold:s.default.trim()},qrcode:r,gen:a},ro}function _$(n,e){try{const t=n(0,"M");t.addData(e),t.make();const s=t.getModuleCount(),i=[];for(let r=0;r<s;r++){let a="";for(let o=0;o<s;o++)a+=t.isDark(r,o)?"1":"0";i.push(a)}return i}catch{return null}}async function w$(n,e){e=e==="en"?"en":"el";const{jsPDF:t,fonts:s,qrcode:i,gen:r}=await b$(),a=ne(),o=A.st.logo||{};let l=JSON.parse(JSON.stringify(n));e==="en"&&(l.lines=l.lines.map(x=>({...x,desc:m$(x)}))),l.war={on:h$(l),m:f$(l)};const u=g$(a.pubUrl),p={qr:a.qrOn!==!1&&u?_$(i,u+"portal.html"):null,qrT1:e==="en"?"View your documents online":"Δείτε τα έγγραφά σας online",qrT2:e==="en"?"Scan the code and sign in with your personal access code.":"Σκανάρετε το QR και μπείτε με τον προσωπικό σας κωδικό πρόσβασης.",validTo:v$(l),banks:a.banks||[],name:a.name,info:y$(a),terms:e==="en"&&a.termsEn&&a.termsEn.trim()?a.termsEn:a.terms,logoMM:a.logoMM,color:a.pdfColor,logo:o.data,logoW:o.w,logoH:o.h,plan:null},m={};l.lines.forEach((x,C)=>{const j=x.pid&&A.products.find(J=>J.id===x.pid);x.showImg&&j&&j.img&&j.imgW&&j.imgH&&(m[C]={data:j.img,w:j.imgW,h:j.imgH})});const w=r.makePdf(t,s,p,l,Ob(l),e==="en"?c$:o$,e==="en"?u$:l$,Vb,m,Lm[e]),E=(l.customer.name||"").replace(/[^\p{L}\p{N}]+/gu,"_").replace(/^_|_$/g,"");return{buf:w,fn:Lm[e].file+l.number+(E?"_"+E:"")+".pdf"}}const Fm=Ob,ao=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),I$=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Um=(n,e,t)=>{const s=t==="en"?new Intl.NumberFormat("en-GB",{style:"currency",currency:"EUR"}).format(Fm(e).total):I$.format(Fm(e).total),i=e.customer&&e.customer.name||"";return String(n??"").split(`
`).filter(r=>!r.includes("{link}")).join(`
`).replace(/\n{3,}/g,`

`).replace(/\{(πελάτης|customer)\}/g,i).replace(/\{(αριθμός|number)\}/g,e.number||"").replace(/\{(θέμα|subject)\}/g,e.subject||"").replace(/\{(σύνολο|total)\}/g,s).replace(/\{(εταιρεία|company)\}/g,ne().name||"").replace(/ για «»/g,"").replace(/ for «»/g,"").replace(/ ,/g,",").replace(/Dear ,/g,"Dear Sir/Madam,")},Hn={el:{subj:"Προσφορά {αριθμός} – {εταιρεία}",body:`Καλησπέρα σας {πελάτης},

σας στέλνουμε την προσφορά μας με αριθμό {αριθμός} για «{θέμα}».

Θα βρείτε την προσφορά σε PDF στο συνημμένο.

Είμαστε στη διάθεσή σας για οποιαδήποτε απορία.

Με εκτίμηση,
{εταιρεία}`},en:{subj:"Quotation {number} – {company}",body:`Dear {customer},

please find our quotation no. {number}.

The quotation is attached as a PDF.

Please do not hesitate to contact us if you have any questions.

Kind regards,
{company}`}},E$=n=>{const e=ne();return n==="en"?{subj:e.mailSubjEn||Hn.en.subj,body:e.mailBodyEn||Hn.en.body}:{subj:e.mailSubj||Hn.el.subj,body:e.mailBody||Hn.el.body}};let ve=null;const hh=()=>!!ve;function T$(){ve=null}function A$(n){if(!A.quotes.find(s=>s.id===n))return;let t="el";try{t=localStorage.getItem("tm-pdflang")==="en"?"en":"el"}catch{}ve={id:n,lang:t,busy:"",msg:""}}function S$(){if(!ve)return"";const n=A.quotes.find(t=>t.id===ve.id);if(!n)return ve=null,"";const e=n.customer&&n.customer.email||"";return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>PDF προσφοράς #${ao(n.number)}</b><button class="ib dk" data-sd="close">✕</button></div>
  <div class="sheet-list pad"><div class="lbl">Γλώσσα PDF</div>
  <div class="seg"><button data-sdl="el" class="${ve.lang==="el"?"on":""}">Ελληνικά</button><button data-sdl="en" class="${ve.lang==="en"?"on":""}">English</button></div>
  <div class="sd-btns">
    <button class="btn b1 wide" data-sd="share" ${ve.busy?"disabled":""}>📤 Αποστολή (WhatsApp, Viber, Drive…)</button>
    <button class="btn b2 wide" data-sd="mail" ${ve.busy?"disabled":""}>✉️ Email${e?" στον "+ao(e):""}</button>
    <button class="btn b2 wide" data-sd="view" ${ve.busy?"disabled":""}>👁️ Προβολή / Αποθήκευση</button>
  </div>
  ${ve.busy?`<div class="upd">${ao(ve.busy)}</div>`:""}${ve.msg?`<div class="err box">${ao(ve.msg)}</div>`:""}
  <div class="muted small">Δεν αλλάζει τίποτα στην προσφορά· καταγράφεται μόνο στο ιστορικό της.</div></div></div></div>`}const k$=n=>{const e=new Uint8Array(n);let t="";const s=32768;for(let i=0;i<e.length;i+=s)t+=String.fromCharCode.apply(null,e.subarray(i,i+s));return btoa(t)};async function R$(n,e,t){const s=A.quotes.find(i=>i.id===ve.id);if(s){ve.busy="Φτιάχνω το PDF…",ve.msg="",e();try{const{buf:i,fn:r}=await w$(s,ve.lang);try{localStorage.setItem("tm-pdflang",ve.lang)}catch{}const a=E$(ve.lang),o=Um(a.subj,s,ve.lang),l=Um(a.body,s,ve.lang);let u={ok:!0};if(Cn)u=await be.shareFile({name:r,b64:k$(i),mime:"application/pdf",text:l,subject:o,email:n==="mail"&&s.customer&&s.customer.email||"",view:n==="view"});else{const h=URL.createObjectURL(new Blob([i],{type:"application/pdf"})),p=document.createElement("a");p.href=h,p.download=r,document.body.appendChild(p),p.click(),p.remove(),setTimeout(()=>URL.revokeObjectURL(h),5e3)}if(u&&u.error)return ve.busy="",ve.msg=u.error,e();Ge("qlog",{id:ze(),qid:s.id,number:s.number||"",customer:s.customer&&s.customer.name||"",ts:Date.now(),type:"pdf",text:"Εξαγωγή PDF ("+(ve.lang==="en"?"αγγλικά":"ελληνικά")+") από την εφαρμογή Android."}),ve=null,t("Το PDF είναι έτοιμο."),e()}catch(i){ve.busy="",ve.msg="Δεν δημιουργήθηκε το PDF. "+(i&&i.message||""),e()}}}function P$(n,e,t){const s=n.closest("[data-sd],[data-sdl],[data-sdq]");if(!s)return!1;const i=s.dataset;return i.sdq?(A$(i.sdq),e(),!0):ve?i.sdl?(ve.lang=i.sdl,e(),!0):(i.sd==="close"?(ve=null,e()):ve.busy||R$(i.sd,e,t),!0):!1}const Zt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Vl=n=>String(n??"").replace(".",","),yn=n=>{const e=parseFloat(String(n??"").replace(",","."));return isNaN(e)?NaN:e},G={open:"company",f:null,msg:"",ok:""},fh=()=>!!G.f,C$=()=>{G.f=null,G.msg="",G.ok=""},$$=[["company","🏢","Εταιρεία & PDF",()=>ne().name||""],["prices","💶","Τιμές & αρίθμηση",()=>"ΦΠΑ "+k(ne().vat,24)+"% · κέρδος "+k(ne().margin,25)+"%"],["banks","🏦","Τραπεζικοί λογαριασμοί",()=>(ne().banks||[]).filter(n=>n.iban).length+" λογαριασμοί"],["mail","✉️","Πρότυπα email",()=>"Ελληνικά & αγγλικά"],["alerts","⏰","Καιρός, υπενθυμίσεις & εγγύηση",()=>ne().wxCity||"—"],["books","📒","Λογιστικά & αντίγραφα",()=>"Αρχικό υπόλοιπο · κατηγορίες"],["team","👥","Χρήστες ομάδας",()=>Object.keys((A.st.roles||{}).users||{}).length+" χρήστες"]],qm={company:()=>{const n=ne();return{name:n.name||"",info:n.info||"",bizEmail:n.bizEmail||"",pdfColor:n.pdfColor||"#1d4e89",logoMM:String(k(n.logoMM,18)),terms:n.terms||"",termsEn:n.termsEn||"",pubUrl:n.pubUrl||"",qrOn:n.qrOn!==!1}},prices:()=>{const n=ne();return{vat:Vl(k(n.vat,24)),margin:Vl(k(n.margin,25)),next:String(k(n.next,1)),validDays:String(n.validDays==null?15:k(n.validDays,15)),followDays:String(n.followDays==null?7:k(n.followDays,7)),warrantyMonths:String(k(n.warrantyMonths,24)),autoSale:n.autoSale!==!1}},mail:()=>{const n=ne();return{mailSubj:n.mailSubj||Hn.el.subj,mailBody:n.mailBody||Hn.el.body,mailSubjEn:n.mailSubjEn||Hn.en.subj,mailBodyEn:n.mailBodyEn||Hn.en.body}},alerts:()=>{const n=ne();return{wxCity:n.wxCity||"",wxCity2:n.wxCity2||"",autoRem:n.autoRem!==!1,remDays:String(n.remDays==null?3:k(n.remDays,3)),warrantyTerms:n.warrantyTerms||""}},books:()=>{const n=A.st.books||{},e=A.st.meta||{};return{opening:Vl(k(n.opening,0)),costCats:(n.costCats||[]).join(", "),backupDays:String(e.backupDays==null?7:k(e.backupDays,7))}},banks:()=>({banks:(ne().banks||[]).map(n=>({id:n.id||ze(),bank:n.bank||"",iban:n.iban||"",holder:n.holder||"",afm:n.afm||""}))})},ot=(n,e,t="")=>`<label class="f">${e}<input class="in" data-sf="${n}" value="${Zt(G.f.v[n]??"")}" ${t}></label>`,ci=(n,e,t=3)=>`<label class="f">${e}<textarea class="in" data-sf="${n}" rows="${t}">${Zt(G.f.v[n]??"")}</textarea></label>`,Ol=(n,e)=>`<label class="chk"><input type="checkbox" data-sf="${n}" ${G.f.v[n]?"checked":""}> ${e}</label>`;function D$(n){const e=G.f&&G.f.k===n?G.f:null;if(n==="team")return`<div class="muted small" style="margin-bottom:6px">Οι χρήστες ομάδας (τεχνικοί) προστίθενται και αφαιρούνται από το PWA, γιατί χρειάζονται λογαριασμό στο Firebase. Εδώ φαίνονται μόνο.</div>
    ${Object.entries((A.st.roles||{}).users||{}).map(([i,r])=>`<div class="item"><div class="t"><b>${Zt(r.name||"—")}</b><span>${r.role==="team"?"Τεχνικός":"Διαχειριστής"}${r.empId?" · υπάλληλος":""}</span></div></div>`).join("")||'<div class="empty">Δεν υπάρχουν χρήστες ομάδας.</div>'}`;if(!e)return`<button class="btn b2 wide" data-st-edit="${n}">✏️ Αλλαγή</button>`+x$(n);let t="";if(n==="company"){const s=e.logo||A.st.logo||{};t=`${ot("name","Επωνυμία")}${ci("info","Στοιχεία (διεύθυνση, τηλ., email, ΑΦΜ)",5)}${ot("bizEmail","Email επιχείρησης",'inputmode="email" autocapitalize="off"')}
    <div class="lbl">Λογότυπο PDF ${s.data?"":"(δεν υπάρχει)"}</div>${s.data?`<img class="logo-prev" src="${Zt(s.data)}">`:""}
    <label class="btn b2 wide">🖼️ ${s.data?"Αλλαγή":"Επιλογή"} λογοτύπου<input type="file" accept="image/png,image/jpeg" data-sl hidden></label>
    <label class="f">Μέγεθος λογοτύπου<select class="in" data-sf="logoMM">${[["12","Μικρό"],["18","Μεσαίο"],["26","Μεγάλο"]].map(([i,r])=>`<option value="${i}"${String(e.v.logoMM)===i?" selected":""}>${r}</option>`).join("")}</select></label>
    <label class="f">Χρώμα PDF<input class="in" type="color" data-sf="pdfColor" value="${Zt(e.v.pdfColor)}" style="height:42px;padding:2px;max-width:120px"></label>
    ${ci("terms","Όροι (κάτω στο PDF, ελληνικά)",4)}${ci("termsEn","Όροι στα αγγλικά (κενό = τα ελληνικά)",4)}
    ${ot("pubUrl","Διεύθυνση συνδέσμων προς πελάτες",'inputmode="url" placeholder="https://tech-mate.gr" autocapitalize="off"')}${Ol("qrOn","QR στο PDF προς την Περιοχή πελάτη")}`}else n==="prices"?t=`${ot("vat","ΦΠΑ %",'inputmode="decimal"')}${ot("margin","Προεπιλεγμένο κέρδος % (για προϊόντα χωρίς δικό τους)",'inputmode="decimal"')}
    ${ot("next","Επόμενος αριθμός προσφοράς",'inputmode="numeric"')}${ot("validDays","Ισχύς προσφοράς (ημέρες, 0 = χωρίς)",'inputmode="numeric"')}
    ${ot("followDays","Υπενθύμιση για προσφορά χωρίς απάντηση μετά από (ημέρες, 0 = καμία)",'inputmode="numeric"')}${ot("warrantyMonths","Εγγύηση εγκατάστασης (μήνες)",'inputmode="numeric"')}
    ${Ol("autoSale","Όταν μια προσφορά γίνεται δεκτή, να φτιάχνεται αυτόματα παραστατικό πώλησης")}
    <div class="upd">Προσοχή στον «Επόμενο αριθμό»: αν τον κατεβάσεις, θα ξαναδοθούν αριθμοί που υπάρχουν ήδη.</div>`:n==="mail"?t=`<div class="muted small">Μεταβλητές: {πελάτης} {αριθμός} {θέμα} {σύνολο} {εταιρεία} (αγγλικά: {customer} {number} {subject} {total} {company}). Το link της live προσφοράς δεν χρησιμοποιείται στην εφαρμογή.</div>
    ${ot("mailSubj","Θέμα email (πρότυπο)")}${ci("mailBody","Κείμενο email (πρότυπο)",9)}${ot("mailSubjEn","Θέμα email στα αγγλικά (πρότυπο)")}${ci("mailBodyEn","Κείμενο email στα αγγλικά (πρότυπο)",9)}`:n==="alerts"?t=`${ot("wxCity","Καιρός: τοποθεσία 1 (πάνω, δίπλα στο λογότυπο)")}${ot("wxCity2","Καιρός: τοποθεσία 2 (προαιρετικά)")}
    ${Ol("autoRem","Αυτόματη υπενθύμιση για προσφορά χωρίς απάντηση")}${ot("remDays","…μετά από (ημέρες)",'inputmode="numeric"')}
    ${ci("warrantyTerms","Όροι εγγύησης στη βεβαίωση (κενό = προεπιλεγμένο κείμενο)",5)}`:n==="books"?t=`${ot("opening","Αρχικό υπόλοιπο τράπεζας €",'inputmode="decimal"')}${ot("costCats","Κατηγορίες κόστους (χωρισμένες με κόμμα)")}
    ${ot("backupDays","Υπενθύμιση όταν περάσουν Χ ημέρες χωρίς αντίγραφο (0 = καμία)",'inputmode="numeric"')}
    <div class="muted small">Η δημιουργία/επαναφορά αντιγράφου ασφαλείας γίνεται από το «Ειδοποιήσεις, widget & backup».</div>`:n==="banks"&&(t=e.v.banks.map((s,i)=>`<div class="card pad" style="margin:0 0 8px">
      ${["bank:Τράπεζα","iban:IBAN","holder:Δικαιούχος","afm:ΑΦΜ δικαιούχου"].map(r=>{const[a,o]=r.split(":");return`<label class="f">${o}<input class="in" data-sb="${i}:${a}" value="${Zt(s[a])}" ${a==="iban"?'autocapitalize="characters"':""}></label>`}).join("")}
      <button class="btn b2" data-st-bdel="${i}">🗑️ Αφαίρεση</button></div>`).join("")+'<button class="btn b2 wide" data-st-badd>＋ Νέος λογαριασμός</button>');return`${t}${G.msg?`<div class="err box">${Zt(G.msg)}</div>`:""}<div class="actions"><button class="btn b2" data-st-cancel>Άκυρο</button><button class="btn b1" data-st-save="${n}">Αποθήκευση</button></div>
  <div class="muted small">Αλλάζουν μόνο τα πεδία αυτής της ενότητας· όλα τα υπόλοιπα στοιχεία μένουν όπως είναι.</div>`}function x$(n){const e=ne(),t=(s,i)=>`<div class="fld"><label>${s}</label><div class="v">${Zt(i)||"—"}</div></div>`;return n==="company"?`<div class="sm">${t("Επωνυμία",e.name)}${t("Email",e.bizEmail)}${t("Σύνδεσμοι πελατών",e.pubUrl)}</div>`:n==="prices"?`<div class="sm">${t("Επόμενη προσφορά","#"+k(e.next,1))}${t("Ισχύς προσφοράς",(e.validDays==null?15:e.validDays)+" ημέρες")}${t("Εγγύηση",k(e.warrantyMonths,24)+" μήνες")}</div>`:n==="banks"?`<div class="sm">${(e.banks||[]).filter(s=>s.iban).map(s=>t(s.bank||"Τράπεζα",s.iban)).join("")||'<div class="muted small">Κανένας λογαριασμός.</div>'}</div>`:""}function N$(n,e){return e(n("Ρυθμίσεις","Εταιρεία · PDF · Τιμές · Τράπεζες",'<a class="ib" href="#/menu">←</a>'),`<div class="card">${$$.map(([t,s,i,r])=>`<div class="acc${G.open===t?" open":""}"><button class="acc-h" data-st-open="${t}"><span class="ic">${s}</span><span class="t"><b>${i}</b><span>${Zt(r())}</span></span><span class="chev">${G.open===t?"▾":"▸"}</span></button>
      ${G.open===t?`<div class="acc-b">${D$(t)}</div>`:""}</div>`).join("")}</div>
    ${G.ok?`<div class="upd">${Zt(G.ok)}</div>`:""}
    <div class="card"><a class="mi" href="#/cset"><div class="ic">🔔</div><div class="t"><b>Ειδοποιήσεις, widget & backup</b><span>Υπενθυμίσεις · Microsoft To Do · Αντίγραφα ημερολογίου</span></div></a></div>
    <div class="muted small" style="padding:0 6px 10px">Push (Firebase), σύνδεση Microsoft για αποστολή email, PIN, ιστοσελίδα και Περιοχή πελάτη ρυθμίζονται μόνο από το PWA.</div>`,"menu")}function V$(n){return new Promise((e,t)=>{const s=new FileReader;s.onerror=()=>t(new Error("Δεν διαβάστηκε")),s.onload=()=>{const i=new Image;i.onerror=()=>t(new Error("Δεν είναι εικόνα")),i.onload=()=>{const r=Math.min(1,700/Math.max(i.naturalWidth,i.naturalHeight)),a=Math.max(1,Math.round(i.naturalWidth*r)),o=Math.max(1,Math.round(i.naturalHeight*r)),l=document.createElement("canvas");l.width=a,l.height=o;const u=l.getContext("2d"),h=n.type==="image/png";h||(u.fillStyle="#fff",u.fillRect(0,0,a,o)),u.drawImage(i,0,0,a,o),e({data:l.toDataURL(h?"image/png":"image/jpeg",.9),w:a,h:o})},i.src=s.result},s.readAsDataURL(n)})}function O$(n,e){const t=G.f.v,s={};if(n==="company"){const a=String(t.name||"").trim();if(!a)return G.msg="Γράψε επωνυμία.";const o=String(t.bizEmail||"").trim();if(o&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(o))return G.msg="Το email δεν φαίνεται σωστό.";const l=String(t.pubUrl||"").trim();if(l&&!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}(:\d+)?\/?$/i.test(l))return G.msg="Η διεύθυνση πρέπει να είναι σαν https://tech-mate.gr";Object.assign(s,{name:a,info:t.info,bizEmail:o,pdfColor:t.pdfColor,logoMM:k(t.logoMM,18),terms:t.terms,termsEn:t.termsEn,pubUrl:l,qrOn:!!t.qrOn})}else if(n==="prices"){const a=yn(t.vat),o=yn(t.margin),l=yn(t.next),u=yn(t.validDays),h=yn(t.followDays),p=yn(t.warrantyMonths);if([a,o,l,u,h,p].some(isNaN)||a<0||a>30||o<0||l<1||u<0||h<0||p<0)return G.msg="Έλεγξε τους αριθμούς (δεν μπορούν να είναι κενοί ή αρνητικοί).";const m=A.quotes.reduce((w,E)=>Math.max(w,k(E.number,0)),0);if(Math.floor(l)<=m&&Math.floor(l)!==k(ne().next,1))return G.msg="Υπάρχουν ήδη προσφορές μέχρι το #"+m+". Ο επόμενος αριθμός πρέπει να είναι μεγαλύτερος.";Object.assign(s,{vat:a,margin:o,next:Math.floor(l),validDays:Math.floor(u),followDays:Math.floor(h),warrantyMonths:Math.floor(p),autoSale:!!t.autoSale})}else if(n==="mail")Object.assign(s,{mailSubj:t.mailSubj,mailBody:t.mailBody,mailSubjEn:t.mailSubjEn,mailBodyEn:t.mailBodyEn});else if(n==="alerts"){const a=yn(t.remDays);if(isNaN(a)||a<1)return G.msg="Οι ημέρες υπενθύμισης πρέπει να είναι τουλάχιστον 1.";Object.assign(s,{wxCity:String(t.wxCity||"").trim(),wxCity2:String(t.wxCity2||"").trim(),autoRem:!!t.autoRem,remDays:Math.floor(a),warrantyTerms:t.warrantyTerms})}else if(n==="books"){const a=yn(t.opening),o=yn(t.backupDays);if(isNaN(a)||isNaN(o)||o<0)return G.msg="Έλεγξε τους αριθμούς.";const l={opening:a,costCats:String(t.costCats||"").split(",").map(h=>h.trim()).filter(Boolean)},u={};Object.keys(l).forEach(h=>{const p=G.f.v0,m=G.f.v;(h==="opening"?m.opening===p.opening:m.costCats===p.costCats)||(u[h]=l[h])}),Object.keys(u).length&&no("books",u),t.backupDays!==G.f.v0.backupDays&&no("meta",{backupDays:Math.floor(o)}),G.f=null,G.msg="",G.ok="Αποθηκεύτηκε.",e(G.ok);return}else if(n==="banks"&&(s.banks=t.banks.map(a=>({id:a.id,bank:a.bank.trim(),iban:a.iban.replace(/\s+/g,"").toUpperCase(),holder:a.holder.trim(),afm:a.afm.trim()})).filter(a=>a.bank||a.iban||a.holder),s.banks.some(a=>a.iban&&!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(a.iban))))return G.msg="Ένα IBAN δεν φαίνεται σωστό.";const i={};Object.keys(s).forEach(a=>{JSON.stringify(G.f.v[a])!==JSON.stringify(G.f.v0[a])&&(i[a]=s[a])}),n==="company"&&G.f.logo&&no("logo",G.f.logo),Object.keys(i).length&&no("main",i);const r=Object.keys(i).length+(G.f.logo?1:0);G.f=null,G.msg="",G.ok=r?"Αποθηκεύτηκε.":"Καμία αλλαγή.",e(G.ok)}function M$(n,e,t){const s=n.closest("[data-st-open],[data-st-edit],[data-st-cancel],[data-st-save],[data-st-badd],[data-st-bdel]");if(!s)return!1;const i=s.dataset;if(i.stOpen){if(G.f)return!0;G.open=G.open===i.stOpen?"":i.stOpen,G.ok=""}else i.stEdit?(G.f={k:i.stEdit,v:qm[i.stEdit](),v0:JSON.parse(JSON.stringify(qm[i.stEdit]())),logo:null},G.msg="",G.ok=""):i.stCancel!==void 0?(G.f=null,G.msg=""):i.stSave?O$(i.stSave,t):i.stBadd!==void 0?G.f.v.banks.push({id:ze(),bank:"",iban:"",holder:"",afm:""}):i.stBdel!==void 0&&G.f.v.banks.splice(+i.stBdel,1);return e(),!0}function L$(n){const e=n.dataset;if(e.sf&&G.f)return G.f.v[e.sf]=n.type==="checkbox"?n.checked:n.value,G.msg="",!0;if(e.sb&&G.f){const[t,s]=e.sb.split(":");return G.f.v.banks[+t][s]=n.value,G.msg="",!0}return!1}function F$(n,e){const t=n.dataset;return t.sl!==void 0&&G.f&&n.files&&n.files[0]?((async()=>{try{G.f.logo=await V$(n.files[0]),G.msg=""}catch(s){G.msg=s.message}e()})(),!0):t.sf&&G.f&&n.tagName==="SELECT"?(G.f.v[t.sf]=n.value,!0):!1}const Ht=document.getElementById("app"),ue=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),oo=n=>k(n).toLocaleString("el-GR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €",Bi=n=>Math.round(k(n)).toLocaleString("el-GR")+" €",U$=n=>n?new Date(n).toLocaleDateString("el-GR",{day:"numeric",month:"short"}):"",Mb=n=>String(n||"?").split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]).join("").toUpperCase(),q$={pending:"p-a",accepted:"p-ok",done:"p-ok",rejected:"p-b"};let En=null,Ft=!1;const Ye={qf:"all",cq:"",stAsk:null};let Oe=null;const B$=[["home","🏠","Αρχική"],["cal","📅","Ημερολόγιο"],["quotes","📄","Προσφορές"],["custs","👥","Πελάτες"],["menu","☰","Μενού"]],j$=n=>`<nav class="nav">${B$.filter(([e])=>!Ie()||e==="cal"||e==="menu").map(([e,t,s])=>`<a href="#/${e}" class="${e===n?"on":""}"><i>${t}</i>${s}</a>`).join("")}</nav>`,Pe=(n,e,t="",s="")=>`<header class="top">${t}<h1>${ue(n)}${e?`<span class="sm">${ue(e)}</span>`:""}</h1>${s}</header>`,ji=n=>`<a class="ib" href="#/${n}">←</a>`,De=(n,e,t,s="")=>`${n}<main class="body">${e}</main>${s}${t?j$(t):""}`;function W$(n=""){return`<div class="login"><img class="lico" src="/icon-192.png" alt=""><div class="logo">TechMate</div><p>Συνδέσου με τον ίδιο λογαριασμό που έχεις στο PWA.</p>
  <form id="lf"><label>Email<input name="e" type="email" autocomplete="username" required></label>
  <label>Κωδικός<input name="p" type="password" autocomplete="current-password" required></label>
  <label class="chk"><input type="checkbox" id="sp"> Εμφάνιση κωδικού</label>
  ${n?`<div class="err">${ue(n)}</div>`:""}<button class="btn b1">Σύνδεση</button></form></div>`}function z$(){return A.quotes.filter(n=>!cn(n)&&dt(n)==="pending")}function ku(){return Be.state==="downloading"?`<div class="upd">⬇️ Κατεβαίνει η έκδοση ${ue(Be.latest.version)}… ${Be.pct}%</div>`:Be.state!=="available"?"":`<div class="upd">⬇️ Νέα έκδοση ${ue(Be.latest.version)}${Be.latest.notes?": "+ue(Be.latest.notes):""}${Be.needApk?"<br>Χρειάζεται νέο αρχείο εγκατάστασης (APK).":""}${Be.err?`<br><span class="bad">${ue(Be.err)}</span>`:""}
    <button class="btn b1 sm" data-up="apply">${Be.needApk?"Λήψη APK":"Ενημέρωση τώρα"}</button></div>`}function Bm(){const n={checking:"Έλεγχος…",none:"Έχεις την τελευταία έκδοση.",error:Be.err}[Be.state]||"";return`<div class="card pad ver"><div><b>TechMate ${ue(Zv)}</b>${n?`<span>${ue(n)}</span>`:""}</div><button class="btn b2 sm" data-up="check">Έλεγχος ενημέρωσης</button></div>`}function jm(){const n=new Date,e=new Date(n.getFullYear(),n.getMonth(),1).getTime(),t=A.quotes.filter(o=>!cn(o)&&["accepted","done"].includes(dt(o))&&(o.ts||0)>=e).reduce((o,l)=>o+k(l.total),0),s=A.ldocs.filter(o=>o.kind==="sale").reduce((o,l)=>o+Gv(l),0),i=SR(),r=n.getHours(),a=r<12?"Καλημέρα":r<18?"Καλησπέρα":"Καλό βράδυ";return De(Pe("TechMate",`${a} · ${n.toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}`,"",'<a class="ib" href="#/menu">👤</a>'),`${Hs?'<div class="upd">🧪 Δοκιμαστικά δεδομένα (preview)</div>':""}${ku()}
    <div class="qa six"><a href="#/edit/new"><i>📝</i>Προσφορά</a><a data-hnew=""><i>📅</i>Ραντεβού</a><a data-hnew="due"><i>💶</i>Λήξη</a><a href="#/books/newdoc"><i>🧾</i>Έξοδο</a><a href="#/soon/Φωτογραφίες"><i>📷</i>Φωτο</a><a data-bcscan><i>🔍</i>Barcode</a></div>
    <div class="kpis">
      <a class="kpi" href="#/quotes"><b>${z$().length}</b><span>Σε αναμονή απάντησης</span></a>
      <div class="kpi"><b>${Bi(t)}</b><span>Δεκτές αυτόν τον μήνα</span></div>
      <a class="kpi" href="#/custs"><b>${un().length}</b><span>Πελάτες</span></a>
      <div class="kpi"><b class="${s>0?"bad":""}">${Bi(s)}</b><span>Μου χρωστούν</span></div>
    </div>
    <div class="h">Σήμερα <a class="hl" href="#/cal">Ημερολόγιο ›</a></div>
    <div class="card">${i.today.length?i.today.map(o=>ns(o,!1)).join(""):'<div class="empty">Τίποτα για σήμερα 🙂</div>'}</div>
    ${i.late.length?`<div class="h badh">⚠️ Εκκρεμούν από πριν (${i.late.length})</div><div class="card">${i.late.slice(0,5).map(o=>ns(o,!0)).join("")}${i.late.length>5?`<a class="empty" href="#/cal">+${i.late.length-5} ακόμα ›</a>`:""}</div>`:""}
    ${i.dues.length?`<div class="h">💶 Λήξεις & πληρωμές (14 μέρες)</div><div class="card">${i.dues.map(o=>ns(o,!0)).join("")}</div>`:""}`,"home")}function Lb(n){const e=dt(n),t=n.customer&&n.customer.name||"";return`<a class="row" href="#/q/${encodeURIComponent(n.id)}"><div class="av">${ue(Mb(t))}</div>
  <div class="t"><b>${ue(n.subject||"(χωρίς θέμα)")}</b><span>#${ue(n.number||"—")} · ${ue(t)} · ${U$(n.ts)}</span></div>
  <div class="r"><div class="amt">${Bi(n.total)}</div><span class="pill ${q$[e]||"p-a"}">${Io[e]||e}</span></div></a>`}function G$(){const n=A.quotes.filter(s=>!cn(s)).sort((s,i)=>(i.ts||0)-(s.ts||0)),e=[["all","Όλες"],["pending","Σε αναμονή"],["accepted","Δεκτές"],["done","Ολοκληρ."],["rejected","Απορρίφθ."]],t=Ye.qf==="all"?n:n.filter(s=>dt(s)===Ye.qf);return De(Pe("Προσφορές",`${n.length} συνολικά`),`<div class="chips">${e.map(([s,i])=>`<button data-qf="${s}" class="${Ye.qf===s?"on":""}">${i}</button>`).join("")}</div>
    <div class="card">${t.length?t.map(Lb).join(""):`<div class="empty">${Ft?"Καμία προσφορά":"Φόρτωση…"}</div>`}</div>`,"quotes",'<a class="fab" href="#/edit/new">＋</a>')}function K$(n){const e=A.quotes.find(a=>a.id===n);if(!e)return De(Pe("Προσφορά","",ji("quotes")),`<div class="empty">${Ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"quotes");const t=dt(e),s=e.customer||{},i=e.lines||[],r=i.reduce((a,o)=>a+k(o.qty)*k(o.price)*(1-k(o.disc)/100),0);return De(Pe(`#${e.number||"—"}`,Io[t],ji("quotes")),`<div class="card"><div class="fld"><label>Πελάτης</label><a class="v" href="#/c/${encodeURIComponent(Me(s.name)||"_none")}">${ue(s.name)} ›</a></div>
    <div class="fld" style="margin:0"><label>Θέμα</label><div class="v">${ue(e.subject)}</div></div></div>
    <div class="h">Κατάσταση</div>
    <div class="card pad"><div class="seg four">${Object.keys(Io).map(a=>`<button data-st="${a}" class="${a===t?"on":""}">${Io[a]}</button>`).join("")}</div>
    ${Ye.stAsk&&Ye.stAsk.id===e.id?`<div class="ask"><b>Αλλαγή σε «${ue(Eo[Ye.stAsk.st])}»;</b>${vk(e,Ye.stAsk.st).map(a=>`<div>• ${ue(a)}</div>`).join("")}
      <div class="actions"><button class="btn b2" data-stno>Άκυρο</button><button class="btn b1" data-stok>Ναι, αλλαγή</button></div></div>`:""}</div>
    <div class="h">Είδη (${i.length})</div>
    <div class="card">${i.map(a=>`<div class="item"><div class="t"><b>${ue(a.desc)}</b><span>${k(a.qty)} × ${oo(a.price)}${k(a.disc)?` · −${k(a.disc)}%`:""}</span></div><div class="amt">${oo(k(a.qty)*k(a.price)*(1-k(a.disc)/100))}</div></div>`).join("")||'<div class="empty">Χωρίς είδη</div>'}</div>
    <div class="card"><div class="tot"><span>Καθαρό</span><span>${oo(r)}</span></div>
    <div class="tot big"><span>Σύνολο${e.vatMode==="off"?" (χωρίς ΦΠΑ)":" με ΦΠΑ"}</span><span>${oo(e.total)}</span></div></div>${S$()}`,null,`<div class="bar"><a class="btn b2" href="#/edit/${encodeURIComponent(e.id)}">✏️ Επεξεργασία</a><button class="btn b2" data-qappt="${ue(e.id)}">📅 Ραντεβού</button><button class="btn b1" data-sdq="${ue(e.id)}">📤 PDF</button></div>`)}function H$(){const n=Me(Ye.cq),e=un().filter(t=>!n||Me(t.name).includes(n)).sort((t,s)=>(s.last||0)-(t.last||0));return De(Pe("Πελάτες",`${e.length}`),`<input class="search" id="cq" placeholder="🔍 Αναζήτηση πελάτη" value="${ue(Ye.cq)}">
    <div class="card">${e.map(t=>`<a class="row" href="#/c/${encodeURIComponent(t.k)}"><div class="av">${ue(Mb(t.name))}</div>
      <div class="t"><b>${ue(t.name)}</b><span>${t.quotes.length} προσφορές${t.info.phone?" · "+ue(t.info.phone):""}</span></div>
      <div class="r">${t.owed>0?`<div class="amt bad">${Bi(t.owed)}</div><span class="muted">χρωστάει</span>`:""}</div></a>`).join("")||`<div class="empty">${Ft?"Κανένας πελάτης":"Φόρτωση…"}</div>`}</div>`,"custs",'<a class="fab" href="#/ce/new">＋</a>')}function Q$(n){const e=un().find(i=>i.k===n);if(!e)return De(Pe("Πελάτης","",ji("custs")),`<div class="empty">${Ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"custs");const t=e.info,s=t.phone.replace(/\s/g,"");return De(Pe(e.name,[t.address,t.phone].filter(Boolean).join(" · "),ji("custs"),s?`<a class="ib" href="tel:${ue(s)}">📞</a>`:""),`<div class="kpis"><div class="kpi"><b>${Bi(e.won)}</b><span>Δεκτές προσφορές</span></div><div class="kpi"><b class="${e.owed>0?"bad":""}">${Bi(e.owed)}</b><span>Υπόλοιπο</span></div></div>
    <div class="actions">${s?`<a class="btn b2" href="viber://chat?number=${ue(s.startsWith("+")?s:"+30"+s)}">💬 Viber</a>`:""}
    ${t.address?`<a class="btn b2" href="https://maps.google.com/?q=${encodeURIComponent(t.address)}">🗺️ Οδηγίες</a>`:""}
    ${t.email?`<a class="btn b2" href="mailto:${ue(t.email)}">✉️ Email</a>`:""}</div>
    <div class="actions"><a class="btn b2" href="#/ce/${encodeURIComponent(e.k)}">✏️ Στοιχεία</a><button class="btn b2" data-newq="${ue(e.k)}">＋ Προσφορά</button><button class="btn b2" data-newt="${ue(e.k)}">＋ Εργασία</button></div>
    ${e.rec&&e.rec.notes?`<div class="card pad note">${ue(e.rec.notes)}</div>`:""}
    <div class="h">Προσφορές (${e.quotes.length})</div>
    <div class="card">${e.quotes.sort((i,r)=>(r.ts||0)-(i.ts||0)).map(Lb).join("")||'<div class="empty">Καμία</div>'}</div>
    ${e.mins.length?`<div class="h">Παλιές εγκαταστάσεις (${e.mins.length})</div>`:""}
    <div class="h">Τιμολόγια & φωτογραφίες</div><div class="card">${e.quotes.filter(i=>dt(i)==="done").map(i=>`<a class="row" href="#/files/${encodeURIComponent(i.id)}"><div class="av">📷</div><div class="t"><b>#${ue(i.number||"—")} ${ue(i.subject||"")}</b><span>${qi(i).length} τιμολόγια · ${fa(i).length} φωτογραφίες</span></div></a>`).join("")||'<div class="empty">Θα εμφανιστούν όταν υπάρχει ολοκληρωμένη εγκατάσταση.</div>'}</div>`,"custs")}const Tr=(n,e,t="")=>`<label class="f">${e}<input class="in" data-f="${n}" value="${ue(Oe.v[n]||"")}" ${t}></label>`,J$=n=>`${Oe.msg?`<div class="err box">${ue(Oe.msg)}</div>`:""}`,Y$='<div class="bar"><button class="btn b2" data-fa="cancel">Άκυρο</button><button class="btn b1" data-fa="save">💾 Αποθήκευση</button></div>';function X$(n){if(!Oe||Oe.kind!=="cust"||Oe.arg!==n){const e=n!=="new"&&un().find(t=>t.k===n);if(n!=="new"&&!e)return De(Pe("Πελάτης","",ji("custs")),`<div class="empty">${Ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);Oe={kind:"cust",arg:n,v:e?{name:e.name,...e.info,notes:e.rec&&e.rec.notes||""}:{name:""}}}return`${Pe(n==="new"?"Νέος πελάτης":"Στοιχεία πελάτη","",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${Tr("name","Όνομα",'autocomplete="off"')}${Tr("phone","Τηλέφωνο",'inputmode="tel"')}${Tr("email","Email",'inputmode="email"')}${Tr("afm","ΑΦΜ",'inputmode="numeric"')}${Tr("address","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${ue(Oe.v.notes||"")}</textarea></label></div>
    ${n!=="new"&&Me(Oe.v.name)!==n?'<div class="upd">Η αλλαγή ονόματος θα περάσει και στις προσφορές, στα παραστατικά και στις εισπράξεις του πελάτη.</div>':""}${J$()}</main>${Y$}`}function Z$(n){if(n==="cancel"){const t=Oe.arg;return Oe=null,location.replace(t==="new"?"#/custs":"#/c/"+encodeURIComponent(t))}const e=_k(Oe.arg==="new"?"":Oe.arg,Oe.v);if(!e.ok)return Oe.msg=e.msg,le();Oe=null,location.replace("#/c/"+encodeURIComponent(e.k))}const eD=[["📄","Προσφορές","Νέα · Κατάλογος · Αποθηκευμένες · Κατάσταση · Δεκτές & παραγγελίες · Ιστορικό αλλαγών · Διαγραμμένα","#/quotes"],["📒","Λογιστικά","Σύνοψη · Παραστατικά · Πληρωμές · Υπόλοιπα","#/books/sum"],["🗂️","Κατάλογος προϊόντων","Προσθήκη · Αλλαγή · Τιμές · Φωτογραφίες · Προμηθευτές","#/cat"],["🛡️","Εγκαταστάσεις","Εγγυήσεις · Συντηρήσεις","#/inst"],["👷","Μεροκάματα","Καταχώρηση · Πληρωμή υπαλλήλου · Υπόλοιπα","#/wages"],["📦","Αποθήκη","Απόθεμα · Κινήσεις · Λίστα παραγγελίας · Εργαλεία που λείπουν","#/stock"],["📨","Μηνύματα ιστοσελίδας","Αιτήματα από τη φόρμα επικοινωνίας","#/msgs"],["🌐","Ιστοσελίδα","Περιεχόμενο · Φωτογραφίες έργων · Άρθρα · Βοηθήματα","#/web"],["📅","Ημερολόγιο & ειδοποιήσεις","Υπενθυμίσεις · Widget · Χρώματα · Backup · Microsoft To Do","#/cset"],["⚙️","Ρυθμίσεις","Εταιρεία & PDF · Τιμές/αρίθμηση · Τράπεζες · Χρήστες ομάδας · Ειδοποιήσεις · Backup","#/set"]];function tD(){return Ie()?De(Pe("Μενού",En?En.email:""),`<div class="card"><a class="mi" href="#/wages"><div class="ic">👷</div><div class="t"><b>Τα μεροκάματά μου</b><span>Καταχώρηση · Υπόλοιπο · Πληρωμές</span></div></a><a class="mi" href="#/stock"><div class="ic">🧰</div><div class="t"><b>Εργαλεία που λείπουν</b><span>Γράψε ό,τι χρειάζεται να παραγγελθεί</span></div></a><a class="mi" href="#/cset"><div class="ic">📅</div><div class="t"><b>Ημερολόγιο & ειδοποιήσεις</b><span>Υπενθυμίσεις · Widget · Χρώματα</span></div></a></div>${ku()}${Bm()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu"):De(Pe("Μενού",En?En.email:""),`<div class="card">${eD.map(([n,e,t,s])=>`<a class="mi" href="${s||"#/soon/"+e}"><div class="ic">${n}</div><div class="t"><b>${e}${s?"":' <span class="soon">από το PWA</span>'}</b><span>${t}</span></div></a>`).join("")}</div>
    ${ku()}${Bm()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu")}function nD(n){const e=(ne()&&ne().pubUrl||"").replace(/\/?$/,"/");return De(Pe(n,"",'<a class="ib" href="javascript:history.back()">←</a>'),`<div class="card"><div class="empty">🛠️ Το «${ue(n)}» γίνεται προς το παρόν από το PWA και φαίνεται αμέσως εδώ όπου χρειάζεται.${ne()&&ne().pubUrl?`<br><br><a class="btn b1" href="${ue(e)}app/" target="_blank" rel="noopener">Άνοιγμα του PWA</a>`:""}</div></div>`,null)}function le(){if(!En)return;const[n,e]=location.hash.replace(/^#\//,"").split("/").map(decodeURIComponent),t={home:jm,quotes:G$,q:()=>K$(e),custs:H$,c:()=>Q$(e),cal:()=>ym(Ft,Pe,De,e),agenda:()=>ym(Ft,Pe,De),t:()=>mR(e,Ft,Pe,De),cset:()=>yR(Pe,De),wages:()=>HR(Pe,De),wage:()=>_b(e,Pe,De,!1),stock:()=>ZR(Pe,De),inst:()=>aP(Pe,De),set:()=>N$(Pe,De),cat:()=>XC(Pe,De),web:()=>qC(Pe,De),sn:()=>yP(e,Pe,De),msgs:()=>qR(Pe,De),files:()=>NR(e,Pe,De),menu:tD,soon:()=>nD(e)};if(n==="edit")return Fb(e);Wk(),Object.assign(t,{ce:()=>X$(e),books:()=>Ok(e,Ft)}),n!=="ce"&&(Oe=null),n!=="t"&&aR(),n!==Ye.lastR&&(KR(),T$(),C$(),HC(),Ye.lastR=n),M.openNext&&(Ab(M.openNext),M.openNext=""),n!=="q"&&(Ye.stAsk=null),n==="files"&&!xe.st&&eh(le),n!=="files"&&(xe.st=null,xe.msg=""),n==="msgs"&&!It.list&&!It.busy&&UR(le),n!=="msgs"&&(It.list=null),n!=="books"&&kk();const s=scrollY,i=Ie()&&!["cal","t","menu","cset","wages","stock"].includes(n)?t.cal:t[n]||jm;if(Ht.innerHTML=i(),n==="custs"){const a=document.getElementById("cq");a.oninput=()=>{Ye.cq=a.value,le();const o=document.getElementById("cq");o.focus(),o.setSelectionRange(o.value.length,o.value.length)}}const r=document.getElementById("out");r&&(r.onclick=()=>{confirm("Αποσύνδεση; Οι υπενθυμίσεις σε αυτό το κινητό θα σταματήσουν μέχρι να ξανασυνδεθείς.")&&(be.clearSession(),cc="",jS())}),scrollTo(0,s)}const sD=(n,e)=>e?location.replace(n):location.hash=n;Ht.addEventListener("change",n=>{FR(n.target,le)||IP(n.target)||F$(n.target,le)||i$(n.target,le)||GC(n.target,le,ct)||TR(n.target,le,ct)||dP(n.target,le)||Uk(n.target,le)});Ht.addEventListener("keydown",n=>AR(n,le,ct));Ht.addEventListener("touchstart",n=>vb(n,le),{passive:!0});Ht.addEventListener("touchend",n=>vb(n,le),{passive:!0});Ht.addEventListener("click",n=>{if(IR(n.target,le,ct)||LR(n.target,le,ct)||BR(n.target,le)||$b(n.target,le,ct)||M$(n.target,le,ct)||n$(n.target,le,ct)||zC(n.target,le,ct)||P$(n.target,le,ct)||lP(n.target,le,ct)||Lk(n.target,sD,le,ct))return;const e=n.target.closest("[data-up],[data-qf],[data-st],[data-stok],[data-stno],[data-fa],[data-newq],[data-newt],[data-hnew],[data-qappt]");if(!e)return;const t=e.dataset,s=decodeURIComponent(location.hash.split("/")[2]||"");if(t.up){t.up==="apply"?fk():_u(!0);return}if(t.hnew!==void 0){Ii({kind:t.hnew,date:ye()}),location.hash="#/t/new";return}if(t.qappt){const i=A.quotes.find(a=>a.id===t.qappt),r=i&&i.customer||{};Ii({quoteId:t.qappt,cust:r.name||"",tel:r.phone||"",addr:r.address||"",title:"Εγκατάσταση – "+(r.name||""),date:ye()}),location.hash="#/t/new";return}if(t.qf)Ye.qf=t.qf;else if(t.st){const i=A.quotes.find(r=>r.id===s);Ye.stAsk=i&&dt(i)!==t.st?{id:s,st:t.st}:null}else if("stno"in t)Ye.stAsk=null;else if("stok"in t){const i=bk(Ye.stAsk.id,Ye.stAsk.st);Ye.stAsk=null,i.msg&&ct(i.msg)}else{if(t.fa)return Oe&&Z$(t.fa);if(t.newq){const i=un().find(r=>r.k===t.newq);i&&zk({name:i.name,...i.info}),location.hash="#/edit/new";return}else if(t.newt){const i=un().find(r=>r.k===t.newt);i&&Ii({cust:i.name,tel:i.info.phone||"",addr:i.info.address||"",date:ye()}),location.hash="#/t/new";return}}le()});Ht.addEventListener("input",n=>{const e=n.target;L$(e)||s$(e,le)||uh(e)||ER(e,le)||uP(e,le)||Fk(e,le)||Oe&&e.dataset.f&&(Oe.v[e.dataset.f]=e.type==="checkbox"?e.checked:e.value,Oe.msg&&(Oe.msg=""))});addEventListener("hashchange",()=>{scrollTo(0,0),location.hash.startsWith("#/cset")&&Yd(le),le()});function Fb(n){const e=scrollY,t=Qk(n);if(t===null){Ht.innerHTML=De(Pe("Προσφορά","",ji("quotes")),`<div class="empty">${Ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);return}Ht.innerHTML=t,Jk(Ht,()=>Fb(n),s=>location.replace(s?"#/q/"+encodeURIComponent(s):"#/quotes")),scrollTo(0,e)}function ct(n,e){let t=document.getElementById("toast");if(t||(t=document.createElement("div"),t.id="toast",document.body.appendChild(t)),t.textContent=n,e){const s=document.createElement("button");s.textContent=e.label,s.onclick=()=>{t.className="",e.fn()},t.appendChild(s)}t.className="show"+(e?" act":""),clearTimeout(ct.t),ct.t=setTimeout(()=>t.className="",6e3)}WS(n=>ct(n&&n.code==="permission-denied"?"Δεν έχεις δικαίωμα για αυτή την αλλαγή. Δεν αποθηκεύτηκε.":"Η αποθήκευση απέτυχε: "+(n&&(n.code||n.message)||"άγνωστο σφάλμα")));dk(()=>{En&&!jd()&&!Oe&&!qd()&&!Jd()&&!sh()&&!hh()&&!fh()&&!dh()&&!lh()&&!rh()&&!Zd()&&le()});hk();Hs&&(window.__tm={data:A,hitFind:Cb,get goBack(){return Bb}});let cc="";function iD(){const n=FS();if(!Cn||!n||!Object.keys(A.st).length)return;const e=ts()||{},t={uid:n.uid,email:n.email||"",role:Ie()?"team":"owner",empId:Kt(),name:e.name||"",rt:n.refreshToken||"",apiKey:yu.apiKey,project:yu.projectId},s=JSON.stringify(t);s!==cc&&(cc=s,be.setSession(t))}function Ub(n){!n||!En||(n.task?location.hash="#/t/"+encodeURIComponent(n.task):n.isNew&&(Ii({date:ye()}),location.hash="#/t/new"))}Xi("open",Ub);Xi("toast",n=>n&&n.text&&ct(n.text));Xi("files",()=>{location.hash.startsWith("#/files")&&eh(le)});Xi("ms",()=>{location.hash.startsWith("#/cset")&&Yd(le)});let Wm=!1,Ru=!1;LS(()=>{Ft=!0,iD(),kR(),!Ru&&A.tasks.length&&A.quotes.length&&(Ru=!0,setTimeout(()=>vR(Ft),4e3)),!(jd()||Oe||qd()||Jd()||sh()||hh()||fh()||dh()||lh()||rh()||Zd())&&le()});document.addEventListener("visibilitychange",()=>{!document.hidden&&En&&(Ru=!1,le())});oa().then(()=>{US(n=>{if(En=n,!n){cc="",qb();return}location.hash.startsWith("#/cset")&&Yd(le),le(),Wm||(Wm=!0,be.takeLaunch().then(Ub))})});function qb(n="",e=""){Ht.innerHTML=W$(n);const t=document.getElementById("lf");t.e.value=e,document.getElementById("sp").onchange=s=>{t.p.type=s.target.checked?"text":"password"},document.getElementById("lf").onsubmit=s=>{s.preventDefault();const i=s.target;BS(i.e.value.trim(),i.p.value).catch(r=>{const a=r&&r.code||"",l=["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(a)?"Λάθος email ή κωδικός.":a==="auth/network-request-failed"?"Δεν υπάρχει σύνδεση στο internet.":a==="auth/too-many-requests"?"Πολλές προσπάθειες. Δοκίμασε ξανά σε λίγα λεπτά.":"Η σύνδεση μπλοκαρίστηκε.";qb(l+" ["+(a||r&&r.message||"άγνωστο")+"]",i.e.value)})}}const zm=n=>{const e=document.querySelector(n);return e?(e.click(),!0):!1};function Bb(){if(zm('#scan-ov [data-sc="close"]')||zm(".sheet .sheet-h button"))return;if((location.hash.replace(/^#\//,"").split("/")[0]||"home")==="home")return be.minimize();const e=[...document.querySelectorAll(".top .ib")].find(t=>t.textContent.trim()==="←");if(e)return e.click();location.hash="#/home"}Xi("back",Bb);let Ml=0,jb=0;const rD=()=>jb=Date.now()+18e4;document.addEventListener("click",n=>{n.target.closest&&n.target.closest('input[type=file],label:has(input[type=file]),[data-sd],[data-sn-scan],[data-bcscan],[data-fl="login"]')&&rD()},!0);document.addEventListener("visibilitychange",()=>{if(document.hidden){Ml=Date.now();return}const n=Date.now()-Ml;if(!Ml||n<8e3||Date.now()<jb||jd()||Oe||qd()||Jd()||sh()||hh()||fh()||dh()||lh()||rh()||Zd())return;(location.hash.replace(/^#\//,"").split("/")[0]||"home")!=="home"&&(location.hash="#/home")});export{cm as A,Ld as W,Fn as _};
