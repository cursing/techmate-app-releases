(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&s(a)}).observe(document,{childList:!0,subtree:!0});function t(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(i){if(i.ep)return;i.ep=!0;const r=t(i);fetch(i.href,r)}})();var Vf={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fg=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let i=n.charCodeAt(s);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++s)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},Z_=function(n){const e=[];let t=0,s=0;for(;t<n.length;){const i=n[t++];if(i<128)e[s++]=String.fromCharCode(i);else if(i>191&&i<224){const r=n[t++];e[s++]=String.fromCharCode((i&31)<<6|r&63)}else if(i>239&&i<365){const r=n[t++],a=n[t++],o=n[t++],l=((i&7)<<18|(r&63)<<12|(a&63)<<6|o&63)-65536;e[s++]=String.fromCharCode(55296+(l>>10)),e[s++]=String.fromCharCode(56320+(l&1023))}else{const r=n[t++],a=n[t++];e[s++]=String.fromCharCode((i&15)<<12|(r&63)<<6|a&63)}}return e.join("")},pg={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let i=0;i<n.length;i+=3){const r=n[i],a=i+1<n.length,o=a?n[i+1]:0,l=i+2<n.length,u=l?n[i+2]:0,h=r>>2,p=(r&3)<<4|o>>4;let m=(o&15)<<2|u>>6,w=u&63;l||(w=64,a||(m=64)),s.push(t[h],t[p],t[m],t[w])}return s.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(fg(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):Z_(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let i=0;i<n.length;){const r=t[n.charAt(i++)],o=i<n.length?t[n.charAt(i)]:0;++i;const u=i<n.length?t[n.charAt(i)]:64;++i;const p=i<n.length?t[n.charAt(i)]:64;if(++i,r==null||o==null||u==null||p==null)throw new ew;const m=r<<2|o>>4;if(s.push(m),u!==64){const w=o<<4&240|u>>2;if(s.push(w),p!==64){const E=u<<6&192|p;s.push(E)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class ew extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const tw=function(n){const e=fg(n);return pg.encodeByteArray(e,!0)},mg=function(n){return tw(n).replace(/\./g,"")},gg=function(n){try{return pg.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nw(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sw=()=>nw().__FIREBASE_DEFAULTS__,iw=()=>{if(typeof process>"u"||typeof Vf>"u")return;const n=Vf.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},rw=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&gg(n[1]);return e&&JSON.parse(e)},Ac=()=>{try{return sw()||iw()||rw()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},aw=n=>{var e,t;return(t=(e=Ac())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},yg=()=>{var n;return(n=Ac())===null||n===void 0?void 0:n.config},vg=n=>{var e;return(e=Ac())===null||e===void 0?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ow{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function et(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function cw(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(et())}function lw(){var n;const e=(n=Ac())===null||n===void 0?void 0:n.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function uw(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function dw(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function hw(){const n=et();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function bg(){return!lw()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function _g(){try{return typeof indexedDB=="object"}catch{return!1}}function fw(){return new Promise((n,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(s);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(s),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var r;e(((r=i.error)===null||r===void 0?void 0:r.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pw="FirebaseError";class Nn extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=pw,Object.setPrototypeOf(this,Nn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Sa.prototype.create)}}class Sa{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},i=`${this.service}/${e}`,r=this.errors[e],a=r?mw(r,s):"Error",o=`${this.serviceName}: ${a} (${i}).`;return new Nn(i,o,s)}}function mw(n,e){return n.replace(gw,(t,s)=>{const i=e[s];return i!=null?String(i):`<${s}?>`})}const gw=/\{\$([^}]+)}/g;function yw(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function ta(n,e){if(n===e)return!0;const t=Object.keys(n),s=Object.keys(e);for(const i of t){if(!s.includes(i))return!1;const r=n[i],a=e[i];if(Of(r)&&Of(a)){if(!ta(r,a))return!1}else if(r!==a)return!1}for(const i of s)if(!t.includes(i))return!1;return!0}function Of(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Aa(n){const e=[];for(const[t,s]of Object.entries(n))Array.isArray(s)?s.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function Vr(n){const e={};return n.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[i,r]=s.split("=");e[decodeURIComponent(i)]=decodeURIComponent(r)}}),e}function Or(n){const e=n.indexOf("?");if(!e)return"";const t=n.indexOf("#",e);return n.substring(e,t>0?t:void 0)}function vw(n,e){const t=new bw(n,e);return t.subscribe.bind(t)}class bw{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let i;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");_w(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:s},i.next===void 0&&(i.next=Rl),i.error===void 0&&(i.error=Rl),i.complete===void 0&&(i.complete=Rl);const r=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),r}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function _w(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function Rl(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function at(n){return n&&n._delegate?n._delegate:n}class Us{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const As="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ww{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new ow;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&s.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const s=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),i=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(r){if(i)return null;throw r}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Ew(e))try{this.getOrInitializeService({instanceIdentifier:As})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const r=this.getOrInitializeService({instanceIdentifier:i});s.resolve(r)}catch{}}}}clearInstance(e=As){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=As){return this.instances.has(e)}getOptions(e=As){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[r,a]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(r);s===o&&a.resolve(i)}return i}onInit(e,t){var s;const i=this.normalizeInstanceIdentifier(t),r=(s=this.onInitCallbacks.get(i))!==null&&s!==void 0?s:new Set;r.add(e),this.onInitCallbacks.set(i,r);const a=this.instances.get(i);return a&&e(a,i),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const i of s)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:Iw(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=As){return this.component?this.component.multipleInstances?e:As:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Iw(n){return n===As?void 0:n}function Ew(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tw{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new ww(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var he;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(he||(he={}));const kw={debug:he.DEBUG,verbose:he.VERBOSE,info:he.INFO,warn:he.WARN,error:he.ERROR,silent:he.SILENT},Sw=he.INFO,Aw={[he.DEBUG]:"log",[he.VERBOSE]:"log",[he.INFO]:"info",[he.WARN]:"warn",[he.ERROR]:"error"},Pw=(n,e,...t)=>{if(e<n.logLevel)return;const s=new Date().toISOString(),i=Aw[e];if(i)console[i](`[${s}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Hu{constructor(e){this.name=e,this._logLevel=Sw,this._logHandler=Pw,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in he))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?kw[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,he.DEBUG,...e),this._logHandler(this,he.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,he.VERBOSE,...e),this._logHandler(this,he.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,he.INFO,...e),this._logHandler(this,he.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,he.WARN,...e),this._logHandler(this,he.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,he.ERROR,...e),this._logHandler(this,he.ERROR,...e)}}const Rw=(n,e)=>e.some(t=>n instanceof t);let Mf,Lf;function $w(){return Mf||(Mf=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Cw(){return Lf||(Lf=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const wg=new WeakMap,su=new WeakMap,Ig=new WeakMap,$l=new WeakMap,Qu=new WeakMap;function Dw(n){const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("success",r),n.removeEventListener("error",a)},r=()=>{t(es(n.result)),i()},a=()=>{s(n.error),i()};n.addEventListener("success",r),n.addEventListener("error",a)});return e.then(t=>{t instanceof IDBCursor&&wg.set(t,n)}).catch(()=>{}),Qu.set(e,n),e}function Nw(n){if(su.has(n))return;const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("complete",r),n.removeEventListener("error",a),n.removeEventListener("abort",a)},r=()=>{t(),i()},a=()=>{s(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",r),n.addEventListener("error",a),n.addEventListener("abort",a)});su.set(n,e)}let iu={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return su.get(n);if(e==="objectStoreNames")return n.objectStoreNames||Ig.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return es(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function xw(n){iu=n(iu)}function Vw(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=n.call(Cl(this),e,...t);return Ig.set(s,e.sort?e.sort():[e]),es(s)}:Cw().includes(n)?function(...e){return n.apply(Cl(this),e),es(wg.get(this))}:function(...e){return es(n.apply(Cl(this),e))}}function Ow(n){return typeof n=="function"?Vw(n):(n instanceof IDBTransaction&&Nw(n),Rw(n,$w())?new Proxy(n,iu):n)}function es(n){if(n instanceof IDBRequest)return Dw(n);if($l.has(n))return $l.get(n);const e=Ow(n);return e!==n&&($l.set(n,e),Qu.set(e,n)),e}const Cl=n=>Qu.get(n);function Mw(n,e,{blocked:t,upgrade:s,blocking:i,terminated:r}={}){const a=indexedDB.open(n,e),o=es(a);return s&&a.addEventListener("upgradeneeded",l=>{s(es(a.result),l.oldVersion,l.newVersion,es(a.transaction),l)}),t&&a.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),o.then(l=>{r&&l.addEventListener("close",()=>r()),i&&l.addEventListener("versionchange",u=>i(u.oldVersion,u.newVersion,u))}).catch(()=>{}),o}const Lw=["get","getKey","getAll","getAllKeys","count"],Fw=["put","add","delete","clear"],Dl=new Map;function Ff(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Dl.get(e))return Dl.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,i=Fw.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(i||Lw.includes(t)))return;const r=async function(a,...o){const l=this.transaction(a,i?"readwrite":"readonly");let u=l.store;return s&&(u=u.index(o.shift())),(await Promise.all([u[t](...o),i&&l.done]))[0]};return Dl.set(e,r),r}xw(n=>({...n,get:(e,t,s)=>Ff(e,t)||n.get(e,t,s),has:(e,t)=>!!Ff(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uw{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(qw(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function qw(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const ru="@firebase/app",Uf="0.10.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qs=new Hu("@firebase/app"),jw="@firebase/app-compat",Bw="@firebase/analytics-compat",Ww="@firebase/analytics",zw="@firebase/app-check-compat",Gw="@firebase/app-check",Kw="@firebase/auth",Hw="@firebase/auth-compat",Qw="@firebase/database",Jw="@firebase/database-compat",Yw="@firebase/functions",Xw="@firebase/functions-compat",Zw="@firebase/installations",eI="@firebase/installations-compat",tI="@firebase/messaging",nI="@firebase/messaging-compat",sI="@firebase/performance",iI="@firebase/performance-compat",rI="@firebase/remote-config",aI="@firebase/remote-config-compat",oI="@firebase/storage",cI="@firebase/storage-compat",lI="@firebase/firestore",uI="@firebase/vertexai-preview",dI="@firebase/firestore-compat",hI="firebase",fI="10.12.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const au="[DEFAULT]",pI={[ru]:"fire-core",[jw]:"fire-core-compat",[Ww]:"fire-analytics",[Bw]:"fire-analytics-compat",[Gw]:"fire-app-check",[zw]:"fire-app-check-compat",[Kw]:"fire-auth",[Hw]:"fire-auth-compat",[Qw]:"fire-rtdb",[Jw]:"fire-rtdb-compat",[Yw]:"fire-fn",[Xw]:"fire-fn-compat",[Zw]:"fire-iid",[eI]:"fire-iid-compat",[tI]:"fire-fcm",[nI]:"fire-fcm-compat",[sI]:"fire-perf",[iI]:"fire-perf-compat",[rI]:"fire-rc",[aI]:"fire-rc-compat",[oI]:"fire-gcs",[cI]:"fire-gcs-compat",[lI]:"fire-fst",[dI]:"fire-fst-compat",[uI]:"fire-vertex","fire-js":"fire-js",[hI]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wo=new Map,mI=new Map,ou=new Map;function qf(n,e){try{n.container.addComponent(e)}catch(t){qs.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function xi(n){const e=n.name;if(ou.has(e))return qs.debug(`There were multiple attempts to register component ${e}.`),!1;ou.set(e,n);for(const t of Wo.values())qf(t,n);for(const t of mI.values())qf(t,n);return!0}function Ju(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Sn(n){return n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gI={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},ts=new Sa("app","Firebase",gI);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yI{constructor(e,t,s){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new Us("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw ts.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tr=fI;function Eg(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const s=Object.assign({name:au,automaticDataCollectionEnabled:!1},e),i=s.name;if(typeof i!="string"||!i)throw ts.create("bad-app-name",{appName:String(i)});if(t||(t=yg()),!t)throw ts.create("no-options");const r=Wo.get(i);if(r){if(ta(t,r.options)&&ta(s,r.config))return r;throw ts.create("duplicate-app",{appName:i})}const a=new Tw(i);for(const l of ou.values())a.addComponent(l);const o=new yI(t,s,a);return Wo.set(i,o),o}function vI(n=au){const e=Wo.get(n);if(!e&&n===au&&yg())return Eg();if(!e)throw ts.create("no-app",{appName:n});return e}function ns(n,e,t){var s;let i=(s=pI[n])!==null&&s!==void 0?s:n;t&&(i+=`-${t}`);const r=i.match(/\s|\//),a=e.match(/\s|\//);if(r||a){const o=[`Unable to register library "${i}" with version "${e}":`];r&&o.push(`library name "${i}" contains illegal characters (whitespace or "/")`),r&&a&&o.push("and"),a&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),qs.warn(o.join(" "));return}xi(new Us(`${i}-version`,()=>({library:i,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bI="firebase-heartbeat-database",_I=1,na="firebase-heartbeat-store";let Nl=null;function Tg(){return Nl||(Nl=Mw(bI,_I,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(na)}catch(t){console.warn(t)}}}}).catch(n=>{throw ts.create("idb-open",{originalErrorMessage:n.message})})),Nl}async function wI(n){try{const t=(await Tg()).transaction(na),s=await t.objectStore(na).get(kg(n));return await t.done,s}catch(e){if(e instanceof Nn)qs.warn(e.message);else{const t=ts.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});qs.warn(t.message)}}}async function jf(n,e){try{const s=(await Tg()).transaction(na,"readwrite");await s.objectStore(na).put(e,kg(n)),await s.done}catch(t){if(t instanceof Nn)qs.warn(t.message);else{const s=ts.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});qs.warn(s.message)}}}function kg(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const II=1024,EI=30*24*60*60*1e3;class TI{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new SI(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=Bf();if(!(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(a=>a.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:i}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(a=>{const o=new Date(a.date).valueOf();return Date.now()-o<=EI}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var e;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=Bf(),{heartbeatsToSend:s,unsentEntries:i}=kI(this._heartbeatsCache.heartbeats),r=mg(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),r}}function Bf(){return new Date().toISOString().substring(0,10)}function kI(n,e=II){const t=[];let s=n.slice();for(const i of n){const r=t.find(a=>a.agent===i.agent);if(r){if(r.dates.push(i.date),Wf(t)>e){r.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),Wf(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class SI{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return _g()?fw().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await wI(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return jf(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return jf(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}else return}}function Wf(n){return mg(JSON.stringify({version:2,heartbeats:n})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function AI(n){xi(new Us("platform-logger",e=>new Uw(e),"PRIVATE")),xi(new Us("heartbeat",e=>new TI(e),"PRIVATE")),ns(ru,Uf,n),ns(ru,Uf,"esm2017"),ns("fire-js","")}AI("");var PI="firebase",RI="10.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ns(PI,RI,"app");function Yu(n,e){var t={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&e.indexOf(s)<0&&(t[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var i=0,s=Object.getOwnPropertySymbols(n);i<s.length;i++)e.indexOf(s[i])<0&&Object.prototype.propertyIsEnumerable.call(n,s[i])&&(t[s[i]]=n[s[i]]);return t}function Sg(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const $I=Sg,Ag=new Sa("auth","Firebase",Sg());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zo=new Hu("@firebase/auth");function CI(n,...e){zo.logLevel<=he.WARN&&zo.warn(`Auth (${tr}): ${n}`,...e)}function To(n,...e){zo.logLevel<=he.ERROR&&zo.error(`Auth (${tr}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tn(n,...e){throw Xu(n,...e)}function hn(n,...e){return Xu(n,...e)}function Pg(n,e,t){const s=Object.assign(Object.assign({},$I()),{[e]:t});return new Sa("auth","Firebase",s).create(e,{appName:n.name})}function ss(n){return Pg(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Xu(n,...e){if(typeof n!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=n.name),n._errorFactory.create(t,...s)}return Ag.create(n,...e)}function ne(n,e,...t){if(!n)throw Xu(e,...t)}function An(n){const e="INTERNAL ASSERTION FAILED: "+n;throw To(e),new Error(e)}function Cn(n,e){n||An(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cu(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function DI(){return zf()==="http:"||zf()==="https:"}function zf(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function NI(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(DI()||uw()||"connection"in navigator)?navigator.onLine:!0}function xI(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pa{constructor(e,t){this.shortDelay=e,this.longDelay=t,Cn(t>e,"Short delay should be less than long delay!"),this.isMobile=cw()||dw()}get(){return NI()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zu(n,e){Cn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rg{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;An("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;An("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;An("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VI={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const OI=new Pa(3e4,6e4);function Zs(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function gs(n,e,t,s,i={}){return $g(n,i,async()=>{let r={},a={};s&&(e==="GET"?a=s:r={body:JSON.stringify(s)});const o=Aa(Object.assign({key:n.config.apiKey},a)).slice(1),l=await n._getAdditionalHeaders();return l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode),Rg.fetch()(Cg(n,n.config.apiHost,t,o),Object.assign({method:e,headers:l,referrerPolicy:"no-referrer"},r))})}async function $g(n,e,t){n._canInitEmulator=!1;const s=Object.assign(Object.assign({},VI),e);try{const i=new LI(n),r=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const a=await r.json();if("needConfirmation"in a)throw oo(n,"account-exists-with-different-credential",a);if(r.ok&&!("errorMessage"in a))return a;{const o=r.ok?a.errorMessage:a.error.message,[l,u]=o.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw oo(n,"credential-already-in-use",a);if(l==="EMAIL_EXISTS")throw oo(n,"email-already-in-use",a);if(l==="USER_DISABLED")throw oo(n,"user-disabled",a);const h=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw Pg(n,h,u);tn(n,h)}}catch(i){if(i instanceof Nn)throw i;tn(n,"network-request-failed",{message:String(i)})}}async function Pc(n,e,t,s,i={}){const r=await gs(n,e,t,s,i);return"mfaPendingCredential"in r&&tn(n,"multi-factor-auth-required",{_serverResponse:r}),r}function Cg(n,e,t,s){const i=`${e}${t}?${s}`;return n.config.emulator?Zu(n.config,i):`${n.config.apiScheme}://${i}`}function MI(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class LI{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(hn(this.auth,"network-request-failed")),OI.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function oo(n,e,t){const s={appName:n.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const i=hn(n,e,s);return i.customData._tokenResponse=t,i}function Gf(n){return n!==void 0&&n.enterprise!==void 0}class FI{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return MI(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}}async function UI(n,e){return gs(n,"GET","/v2/recaptchaConfig",Zs(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qI(n,e){return gs(n,"POST","/v1/accounts:delete",e)}async function Dg(n,e){return gs(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jr(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function jI(n,e=!1){const t=at(n),s=await t.getIdToken(e),i=ed(s);ne(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const r=typeof i.firebase=="object"?i.firebase:void 0,a=r==null?void 0:r.sign_in_provider;return{claims:i,token:s,authTime:jr(xl(i.auth_time)),issuedAtTime:jr(xl(i.iat)),expirationTime:jr(xl(i.exp)),signInProvider:a||null,signInSecondFactor:(r==null?void 0:r.sign_in_second_factor)||null}}function xl(n){return Number(n)*1e3}function ed(n){const[e,t,s]=n.split(".");if(e===void 0||t===void 0||s===void 0)return To("JWT malformed, contained fewer than 3 sections"),null;try{const i=gg(t);return i?JSON.parse(i):(To("Failed to decode base64 JWT payload"),null)}catch(i){return To("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function Kf(n){const e=ed(n);return ne(e,"internal-error"),ne(typeof e.exp<"u","internal-error"),ne(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sa(n,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof Nn&&BI(s)&&n.auth.currentUser===n&&await n.auth.signOut(),s}}function BI({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WI{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const s=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),s}else{this.errorBackoff=3e4;const i=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lu{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=jr(this.lastLoginAt),this.creationTime=jr(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Go(n){var e;const t=n.auth,s=await n.getIdToken(),i=await sa(n,Dg(t,{idToken:s}));ne(i==null?void 0:i.users.length,t,"internal-error");const r=i.users[0];n._notifyReloadListener(r);const a=!((e=r.providerUserInfo)===null||e===void 0)&&e.length?Ng(r.providerUserInfo):[],o=GI(n.providerData,a),l=n.isAnonymous,u=!(n.email&&r.passwordHash)&&!(o!=null&&o.length),h=l?u:!1,p={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:o,metadata:new lu(r.createdAt,r.lastLoginAt),isAnonymous:h};Object.assign(n,p)}async function zI(n){const e=at(n);await Go(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function GI(n,e){return[...n.filter(s=>!e.some(i=>i.providerId===s.providerId)),...e]}function Ng(n){return n.map(e=>{var{providerId:t}=e,s=Yu(e,["providerId"]);return{providerId:t,uid:s.rawId||"",displayName:s.displayName||null,email:s.email||null,phoneNumber:s.phoneNumber||null,photoURL:s.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function KI(n,e){const t=await $g(n,{},async()=>{const s=Aa({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:r}=n.config,a=Cg(n,i,"/v1/token",`key=${r}`),o=await n._getAdditionalHeaders();return o["Content-Type"]="application/x-www-form-urlencoded",Rg.fetch()(a,{method:"POST",headers:o,body:s})});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function HI(n,e){return gs(n,"POST","/v2/accounts:revokeToken",Zs(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ai{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){ne(e.idToken,"internal-error"),ne(typeof e.idToken<"u","internal-error"),ne(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Kf(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){ne(e.length!==0,"internal-error");const t=Kf(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(ne(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:i,expiresIn:r}=await KI(e,t);this.updateTokensAndExpiration(s,i,Number(r))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:i,expirationTime:r}=t,a=new Ai;return s&&(ne(typeof s=="string","internal-error",{appName:e}),a.refreshToken=s),i&&(ne(typeof i=="string","internal-error",{appName:e}),a.accessToken=i),r&&(ne(typeof r=="number","internal-error",{appName:e}),a.expirationTime=r),a}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Ai,this.toJSON())}_performRefresh(){return An("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qn(n,e){ne(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class Pn{constructor(e){var{uid:t,auth:s,stsTokenManager:i}=e,r=Yu(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new WI(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=s,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new lu(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(e){const t=await sa(this,this.stsTokenManager.getToken(this.auth,e));return ne(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return jI(this,e)}reload(){return zI(this)}_assign(e){this!==e&&(ne(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Pn(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){ne(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await Go(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Sn(this.auth.app))return Promise.reject(ss(this.auth));const e=await this.getIdToken();return await sa(this,qI(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var s,i,r,a,o,l,u,h;const p=(s=t.displayName)!==null&&s!==void 0?s:void 0,m=(i=t.email)!==null&&i!==void 0?i:void 0,w=(r=t.phoneNumber)!==null&&r!==void 0?r:void 0,E=(a=t.photoURL)!==null&&a!==void 0?a:void 0,N=(o=t.tenantId)!==null&&o!==void 0?o:void 0,$=(l=t._redirectEventId)!==null&&l!==void 0?l:void 0,B=(u=t.createdAt)!==null&&u!==void 0?u:void 0,J=(h=t.lastLoginAt)!==null&&h!==void 0?h:void 0,{uid:H,emailVerified:ae,isAnonymous:O,providerData:U,stsTokenManager:_}=t;ne(H&&_,e,"internal-error");const y=Ai.fromJSON(this.name,_);ne(typeof H=="string",e,"internal-error"),qn(p,e.name),qn(m,e.name),ne(typeof ae=="boolean",e,"internal-error"),ne(typeof O=="boolean",e,"internal-error"),qn(w,e.name),qn(E,e.name),qn(N,e.name),qn($,e.name),qn(B,e.name),qn(J,e.name);const v=new Pn({uid:H,auth:e,email:m,emailVerified:ae,displayName:p,isAnonymous:O,photoURL:E,phoneNumber:w,tenantId:N,stsTokenManager:y,createdAt:B,lastLoginAt:J});return U&&Array.isArray(U)&&(v.providerData=U.map(I=>Object.assign({},I))),$&&(v._redirectEventId=$),v}static async _fromIdTokenResponse(e,t,s=!1){const i=new Ai;i.updateFromServerResponse(t);const r=new Pn({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:s});return await Go(r),r}static async _fromGetAccountInfoResponse(e,t,s){const i=t.users[0];ne(i.localId!==void 0,"internal-error");const r=i.providerUserInfo!==void 0?Ng(i.providerUserInfo):[],a=!(i.email&&i.passwordHash)&&!(r!=null&&r.length),o=new Ai;o.updateFromIdToken(s);const l=new Pn({uid:i.localId,auth:e,stsTokenManager:o,isAnonymous:a}),u={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:r,metadata:new lu(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(r!=null&&r.length)};return Object.assign(l,u),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hf=new Map;function Rn(n){Cn(n instanceof Function,"Expected a class definition");let e=Hf.get(n);return e?(Cn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,Hf.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xg{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}xg.type="NONE";const Qf=xg;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ko(n,e,t){return`firebase:${n}:${e}:${t}`}class Pi{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:i,name:r}=this.auth;this.fullUserKey=ko(this.userKey,i.apiKey,r),this.fullPersistenceKey=ko("persistence",i.apiKey,r),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?Pn._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new Pi(Rn(Qf),e,s);const i=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let r=i[0]||Rn(Qf);const a=ko(s,e.config.apiKey,e.name);let o=null;for(const u of t)try{const h=await u._get(a);if(h){const p=Pn._fromJSON(e,h);u!==r&&(o=p),r=u;break}}catch{}const l=i.filter(u=>u._shouldAllowMigration);return!r._shouldAllowMigration||!l.length?new Pi(r,e,s):(r=l[0],o&&await r._set(a,o.toJSON()),await Promise.all(t.map(async u=>{if(u!==r)try{await u._remove(a)}catch{}})),new Pi(r,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jf(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Mg(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Vg(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Fg(e))return"Blackberry";if(Ug(e))return"Webos";if(td(e))return"Safari";if((e.includes("chrome/")||Og(e))&&!e.includes("edge/"))return"Chrome";if(Lg(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=n.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function Vg(n=et()){return/firefox\//i.test(n)}function td(n=et()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Og(n=et()){return/crios\//i.test(n)}function Mg(n=et()){return/iemobile/i.test(n)}function Lg(n=et()){return/android/i.test(n)}function Fg(n=et()){return/blackberry/i.test(n)}function Ug(n=et()){return/webos/i.test(n)}function Rc(n=et()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function QI(n=et()){var e;return Rc(n)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function JI(){return hw()&&document.documentMode===10}function qg(n=et()){return Rc(n)||Lg(n)||Ug(n)||Fg(n)||/windows phone/i.test(n)||Mg(n)}function YI(){try{return!!(window&&window!==window.top)}catch{return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jg(n,e=[]){let t;switch(n){case"Browser":t=Jf(et());break;case"Worker":t=`${Jf(et())}-${n}`;break;default:t=n}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${tr}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XI{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=r=>new Promise((a,o)=>{try{const l=e(r);a(l)}catch(l){o(l)}});s.onAbort=t,this.queue.push(s);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ZI(n,e={}){return gs(n,"GET","/v2/passwordPolicy",Zs(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const eE=6;class tE{constructor(e){var t,s,i,r;const a=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=a.minPasswordLength)!==null&&t!==void 0?t:eE,a.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=a.maxPasswordLength),a.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=a.containsLowercaseCharacter),a.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=a.containsUppercaseCharacter),a.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=a.containsNumericCharacter),a.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=a.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(s=e.allowedNonAlphanumericCharacters)===null||s===void 0?void 0:s.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(r=e.forceUpgradeOnSignin)!==null&&r!==void 0?r:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,s,i,r,a,o;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,l),this.validatePasswordCharacterOptions(e,l),l.isValid&&(l.isValid=(t=l.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),l.isValid&&(l.isValid=(s=l.meetsMaxPasswordLength)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(i=l.containsLowercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(r=l.containsUppercaseLetter)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(a=l.containsNumericCharacter)!==null&&a!==void 0?a:!0),l.isValid&&(l.isValid=(o=l.containsNonAlphanumericCharacter)!==null&&o!==void 0?o:!0),l}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let i=0;i<e.length;i++)s=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,i,r){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nE{constructor(e,t,s,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Yf(this),this.idTokenSubscription=new Yf(this),this.beforeStateQueue=new XI(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Ag,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Rn(t)),this._initializationPromise=this.queue(async()=>{var s,i;if(!this._deleted&&(this.persistenceManager=await Pi.create(this,e),!this._deleted)){if(!((s=this._popupRedirectResolver)===null||s===void 0)&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((i=this.currentUser)===null||i===void 0?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Dg(this,{idToken:e}),s=await Pn._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(Sn(this.app)){const a=this.app.settings.authIdToken;return a?new Promise(o=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(a).then(o,o))}):this.directlySetCurrentUser(null)}const s=await this.assertedPersistence.getCurrentUser();let i=s,r=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const a=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,o=i==null?void 0:i._redirectEventId,l=await this.tryRedirectSignIn(e);(!a||a===o)&&(l!=null&&l.user)&&(i=l.user,r=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(i)}catch(a){i=s,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(a))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return ne(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Go(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=xI()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Sn(this.app))return Promise.reject(ss(this));const t=e?at(e):null;return t&&ne(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&ne(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Sn(this.app)?Promise.reject(ss(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Sn(this.app)?Promise.reject(ss(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Rn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await ZI(this),t=new tE(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new Sa("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await HI(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Rn(e)||this._popupRedirectResolver;ne(t,this,"argument-error"),this.redirectPersistenceManager=await Pi.create(this,[Rn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)===null||s===void 0?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const s=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==s&&(this.lastNotifiedUid=s,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,i){if(this._deleted)return()=>{};const r=typeof t=="function"?t:t.next.bind(t);let a=!1;const o=this._isInitialized?Promise.resolve():this._initializationPromise;if(ne(o,this,"internal-error"),o.then(()=>{a||r(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,s,i);return()=>{a=!0,l()}}else{const l=e.addObserver(t);return()=>{a=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return ne(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=jg(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const s=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());s&&(t["X-Firebase-Client"]=s);const i=await this._getAppCheckToken();return i&&(t["X-Firebase-AppCheck"]=i),t}async _getAppCheckToken(){var e;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&CI(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function nr(n){return at(n)}class Yf{constructor(e){this.auth=e,this.observer=null,this.addObserver=vw(t=>this.observer=t)}get next(){return ne(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let $c={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function sE(n){$c=n}function Bg(n){return $c.loadJS(n)}function iE(){return $c.recaptchaEnterpriseScript}function rE(){return $c.gapiScript}function aE(n){return`__${n}${Math.floor(Math.random()*1e6)}`}const oE="recaptcha-enterprise",cE="NO_RECAPTCHA";class lE{constructor(e){this.type=oE,this.auth=nr(e)}async verify(e="verify",t=!1){async function s(r){if(!t){if(r.tenantId==null&&r._agentRecaptchaConfig!=null)return r._agentRecaptchaConfig.siteKey;if(r.tenantId!=null&&r._tenantRecaptchaConfigs[r.tenantId]!==void 0)return r._tenantRecaptchaConfigs[r.tenantId].siteKey}return new Promise(async(a,o)=>{UI(r,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)o(new Error("recaptcha Enterprise site key undefined"));else{const u=new FI(l);return r.tenantId==null?r._agentRecaptchaConfig=u:r._tenantRecaptchaConfigs[r.tenantId]=u,a(u.siteKey)}}).catch(l=>{o(l)})})}function i(r,a,o){const l=window.grecaptcha;Gf(l)?l.enterprise.ready(()=>{l.enterprise.execute(r,{action:e}).then(u=>{a(u)}).catch(()=>{a(cE)})}):o(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((r,a)=>{s(this.auth).then(o=>{if(!t&&Gf(window.grecaptcha))i(o,r,a);else{if(typeof window>"u"){a(new Error("RecaptchaVerifier is only supported in browser"));return}let l=iE();l.length!==0&&(l+=o),Bg(l).then(()=>{i(o,r,a)}).catch(u=>{a(u)})}}).catch(o=>{a(o)})})}}async function Xf(n,e,t,s=!1){const i=new lE(n);let r;try{r=await i.verify(t)}catch{r=await i.verify(t,!0)}const a=Object.assign({},e);return s?Object.assign(a,{captchaResp:r}):Object.assign(a,{captchaResponse:r}),Object.assign(a,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(a,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),a}async function Zf(n,e,t,s){var i;if(!((i=n._getRecaptchaConfig())===null||i===void 0)&&i.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const r=await Xf(n,e,t,t==="getOobCode");return s(n,r)}else return s(n,e).catch(async r=>{if(r.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const a=await Xf(n,e,t,t==="getOobCode");return s(n,a)}else return Promise.reject(r)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uE(n,e){const t=Ju(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),r=t.getOptions();if(ta(r,e??{}))return i;tn(i,"already-initialized")}return t.initialize({options:e})}function dE(n,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(Rn);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function hE(n,e,t){const s=nr(n);ne(s._canInitEmulator,s,"emulator-config-failed"),ne(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const i=!1,r=Wg(e),{host:a,port:o}=fE(e),l=o===null?"":`:${o}`;s.config.emulator={url:`${r}//${a}${l}/`},s.settings.appVerificationDisabledForTesting=!0,s.emulatorConfig=Object.freeze({host:a,port:o,protocol:r.replace(":",""),options:Object.freeze({disableWarnings:i})}),pE()}function Wg(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function fE(n){const e=Wg(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(s);if(i){const r=i[1];return{host:r,port:ep(s.substr(r.length+1))}}else{const[r,a]=s.split(":");return{host:r,port:ep(a)}}}function ep(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function pE(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nd{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return An("not implemented")}_getIdTokenResponse(e){return An("not implemented")}_linkToIdToken(e,t){return An("not implemented")}_getReauthenticationResolver(e){return An("not implemented")}}async function mE(n,e){return gs(n,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function gE(n,e){return Pc(n,"POST","/v1/accounts:signInWithPassword",Zs(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yE(n,e){return Pc(n,"POST","/v1/accounts:signInWithEmailLink",Zs(n,e))}async function vE(n,e){return Pc(n,"POST","/v1/accounts:signInWithEmailLink",Zs(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ia extends nd{constructor(e,t,s,i=null){super("password",s),this._email=e,this._password=t,this._tenantId=i}static _fromEmailAndPassword(e,t){return new ia(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new ia(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Zf(e,t,"signInWithPassword",gE);case"emailLink":return yE(e,{email:this._email,oobCode:this._password});default:tn(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Zf(e,s,"signUpPassword",mE);case"emailLink":return vE(e,{idToken:t,email:this._email,oobCode:this._password});default:tn(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ri(n,e){return Pc(n,"POST","/v1/accounts:signInWithIdp",Zs(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bE="http://localhost";class js extends nd{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new js(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):tn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:i}=t,r=Yu(t,["providerId","signInMethod"]);if(!s||!i)return null;const a=new js(s,i);return a.idToken=r.idToken||void 0,a.accessToken=r.accessToken||void 0,a.secret=r.secret,a.nonce=r.nonce,a.pendingToken=r.pendingToken||null,a}_getIdTokenResponse(e){const t=this.buildRequest();return Ri(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,Ri(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,Ri(e,t)}buildRequest(){const e={requestUri:bE,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Aa(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _E(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function wE(n){const e=Vr(Or(n)).link,t=e?Vr(Or(e)).deep_link_id:null,s=Vr(Or(n)).deep_link_id;return(s?Vr(Or(s)).link:null)||s||t||e||n}class sd{constructor(e){var t,s,i,r,a,o;const l=Vr(Or(e)),u=(t=l.apiKey)!==null&&t!==void 0?t:null,h=(s=l.oobCode)!==null&&s!==void 0?s:null,p=_E((i=l.mode)!==null&&i!==void 0?i:null);ne(u&&h&&p,"argument-error"),this.apiKey=u,this.operation=p,this.code=h,this.continueUrl=(r=l.continueUrl)!==null&&r!==void 0?r:null,this.languageCode=(a=l.languageCode)!==null&&a!==void 0?a:null,this.tenantId=(o=l.tenantId)!==null&&o!==void 0?o:null}static parseLink(e){const t=wE(e);try{return new sd(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sr{constructor(){this.providerId=sr.PROVIDER_ID}static credential(e,t){return ia._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=sd.parseLink(t);return ne(s,"argument-error"),ia._fromEmailAndCode(e,s.code,s.tenantId)}}sr.PROVIDER_ID="password";sr.EMAIL_PASSWORD_SIGN_IN_METHOD="password";sr.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zg{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ra extends zg{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kn extends Ra{constructor(){super("facebook.com")}static credential(e){return js._fromParams({providerId:Kn.PROVIDER_ID,signInMethod:Kn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Kn.credentialFromTaggedObject(e)}static credentialFromError(e){return Kn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Kn.credential(e.oauthAccessToken)}catch{return null}}}Kn.FACEBOOK_SIGN_IN_METHOD="facebook.com";Kn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hn extends Ra{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return js._fromParams({providerId:Hn.PROVIDER_ID,signInMethod:Hn.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return Hn.credentialFromTaggedObject(e)}static credentialFromError(e){return Hn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return Hn.credential(t,s)}catch{return null}}}Hn.GOOGLE_SIGN_IN_METHOD="google.com";Hn.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qn extends Ra{constructor(){super("github.com")}static credential(e){return js._fromParams({providerId:Qn.PROVIDER_ID,signInMethod:Qn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Qn.credentialFromTaggedObject(e)}static credentialFromError(e){return Qn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Qn.credential(e.oauthAccessToken)}catch{return null}}}Qn.GITHUB_SIGN_IN_METHOD="github.com";Qn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jn extends Ra{constructor(){super("twitter.com")}static credential(e,t){return js._fromParams({providerId:Jn.PROVIDER_ID,signInMethod:Jn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Jn.credentialFromTaggedObject(e)}static credentialFromError(e){return Jn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return Jn.credential(t,s)}catch{return null}}}Jn.TWITTER_SIGN_IN_METHOD="twitter.com";Jn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vi{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,i=!1){const r=await Pn._fromIdTokenResponse(e,s,i),a=tp(s);return new Vi({user:r,providerId:a,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const i=tp(s);return new Vi({user:e,providerId:i,_tokenResponse:s,operationType:t})}}function tp(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ko extends Nn{constructor(e,t,s,i){var r;super(t.code,t.message),this.operationType=s,this.user=i,Object.setPrototypeOf(this,Ko.prototype),this.customData={appName:e.name,tenantId:(r=e.tenantId)!==null&&r!==void 0?r:void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,i){return new Ko(e,t,s,i)}}function Gg(n,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(r=>{throw r.code==="auth/multi-factor-auth-required"?Ko._fromErrorAndOperation(n,r,e,s):r})}async function IE(n,e,t=!1){const s=await sa(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return Vi._forOperation(n,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function EE(n,e,t=!1){const{auth:s}=n;if(Sn(s.app))return Promise.reject(ss(s));const i="reauthenticate";try{const r=await sa(n,Gg(s,i,e,n),t);ne(r.idToken,s,"internal-error");const a=ed(r.idToken);ne(a,s,"internal-error");const{sub:o}=a;return ne(n.uid===o,s,"user-mismatch"),Vi._forOperation(n,i,r)}catch(r){throw(r==null?void 0:r.code)==="auth/user-not-found"&&tn(s,"user-mismatch"),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Kg(n,e,t=!1){if(Sn(n.app))return Promise.reject(ss(n));const s="signIn",i=await Gg(n,s,e),r=await Vi._fromIdTokenResponse(n,s,i);return t||await n._updateCurrentUser(r.user),r}async function TE(n,e){return Kg(nr(n),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function kE(n){const e=nr(n);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}function SE(n,e,t){return Sn(n.app)?Promise.reject(ss(n)):TE(at(n),sr.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&kE(n),s})}function AE(n,e,t,s){return at(n).onIdTokenChanged(e,t,s)}function PE(n,e,t){return at(n).beforeAuthStateChanged(e,t)}function RE(n,e,t,s){return at(n).onAuthStateChanged(e,t,s)}function $E(n){return at(n).signOut()}const Ho="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hg{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Ho,"1"),this.storage.removeItem(Ho),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function CE(){const n=et();return td(n)||Rc(n)}const DE=1e3,NE=10;class Qg extends Hg{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=CE()&&YI(),this.fallbackToPolling=qg(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),i=this.localCache[t];s!==i&&e(t,i,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((a,o,l)=>{this.notifyListeners(a,l)});return}const s=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const a=this.storage.getItem(s);if(e.newValue!==a)e.newValue!==null?this.storage.setItem(s,e.newValue):this.storage.removeItem(s);else if(this.localCache[s]===e.newValue&&!t)return}const i=()=>{const a=this.storage.getItem(s);!t&&this.localCache[s]===a||this.notifyListeners(s,a)},r=this.storage.getItem(s);JI()&&r!==e.newValue&&e.newValue!==e.oldValue?setTimeout(i,NE):i()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const i of Array.from(s))i(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},DE)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Qg.type="LOCAL";const xE=Qg;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jg extends Hg{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Jg.type="SESSION";const Yg=Jg;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function VE(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cc{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(i=>i.isListeningto(e));if(t)return t;const s=new Cc(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:i,data:r}=t.data,a=this.handlersMap[i];if(!(a!=null&&a.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:i});const o=Array.from(a).map(async u=>u(t.origin,r)),l=await VE(o);t.ports[0].postMessage({status:"done",eventId:s,eventType:i,response:l})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Cc.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function id(n="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class OE{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let r,a;return new Promise((o,l)=>{const u=id("",20);i.port1.start();const h=setTimeout(()=>{l(new Error("unsupported_event"))},s);a={messageChannel:i,onMessage(p){const m=p;if(m.data.eventId===u)switch(m.data.status){case"ack":clearTimeout(h),r=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(r),o(m.data.response);break;default:clearTimeout(h),clearTimeout(r),l(new Error("invalid_response"));break}}},this.handlers.add(a),i.port1.addEventListener("message",a.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[i.port2])}).finally(()=>{a&&this.removeMessageHandler(a)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fn(){return window}function ME(n){fn().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xg(){return typeof fn().WorkerGlobalScope<"u"&&typeof fn().importScripts=="function"}async function LE(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function FE(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function UE(){return Xg()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zg="firebaseLocalStorageDb",qE=1,Qo="firebaseLocalStorage",ey="fbase_key";class $a{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function Dc(n,e){return n.transaction([Qo],e?"readwrite":"readonly").objectStore(Qo)}function jE(){const n=indexedDB.deleteDatabase(Zg);return new $a(n).toPromise()}function uu(){const n=indexedDB.open(Zg,qE);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const s=n.result;try{s.createObjectStore(Qo,{keyPath:ey})}catch(i){t(i)}}),n.addEventListener("success",async()=>{const s=n.result;s.objectStoreNames.contains(Qo)?e(s):(s.close(),await jE(),e(await uu()))})})}async function np(n,e,t){const s=Dc(n,!0).put({[ey]:e,value:t});return new $a(s).toPromise()}async function BE(n,e){const t=Dc(n,!1).get(e),s=await new $a(t).toPromise();return s===void 0?null:s.value}function sp(n,e){const t=Dc(n,!0).delete(e);return new $a(t).toPromise()}const WE=800,zE=3;class ty{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await uu(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>zE)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Xg()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Cc._getInstance(UE()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await LE(),!this.activeServiceWorker)return;this.sender=new OE(this.activeServiceWorker);const s=await this.sender._send("ping",{},800);s&&!((e=s[0])===null||e===void 0)&&e.fulfilled&&!((t=s[0])===null||t===void 0)&&t.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||FE()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await uu();return await np(e,Ho,"1"),await sp(e,Ho),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>np(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>BE(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>sp(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const r=Dc(i,!1).getAll();return new $a(r).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:i,value:r}of e)s.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(r)&&(this.notifyListeners(i,r),t.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!s.has(i)&&(this.notifyListeners(i,null),t.push(i));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const i of Array.from(s))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),WE)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}ty.type="LOCAL";const GE=ty;new Pa(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function KE(n,e){return e?Rn(e):(ne(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rd extends nd{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Ri(e,this._buildIdpRequest())}_linkToIdToken(e,t){return Ri(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return Ri(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function HE(n){return Kg(n.auth,new rd(n),n.bypassAuthState)}function QE(n){const{auth:e,user:t}=n;return ne(t,e,"internal-error"),EE(t,new rd(n),n.bypassAuthState)}async function JE(n){const{auth:e,user:t}=n;return ne(t,e,"internal-error"),IE(t,new rd(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ny{constructor(e,t,s,i,r=!1){this.auth=e,this.resolver=s,this.user=i,this.bypassAuthState=r,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:i,tenantId:r,error:a,type:o}=e;if(a){this.reject(a);return}const l={auth:this.auth,requestUri:t,sessionId:s,tenantId:r||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(o)(l))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return HE;case"linkViaPopup":case"linkViaRedirect":return JE;case"reauthViaPopup":case"reauthViaRedirect":return QE;default:tn(this.auth,"internal-error")}}resolve(e){Cn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Cn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const YE=new Pa(2e3,1e4);class ki extends ny{constructor(e,t,s,i,r){super(e,t,i,r),this.provider=s,this.authWindow=null,this.pollId=null,ki.currentPopupAction&&ki.currentPopupAction.cancel(),ki.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return ne(e,this.auth,"internal-error"),e}async onExecution(){Cn(this.filter.length===1,"Popup operations only handle one event");const e=id();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(hn(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(hn(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,ki.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if(!((s=(t=this.authWindow)===null||t===void 0?void 0:t.window)===null||s===void 0)&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(hn(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,YE.get())};e()}}ki.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const XE="pendingRedirect",So=new Map;class ZE extends ny{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=So.get(this.auth._key());if(!e){try{const s=await e0(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}So.set(this.auth._key(),e)}return this.bypassAuthState||So.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function e0(n,e){const t=s0(e),s=n0(n);if(!await s._isAvailable())return!1;const i=await s._get(t)==="true";return await s._remove(t),i}function t0(n,e){So.set(n._key(),e)}function n0(n){return Rn(n._redirectPersistence)}function s0(n){return ko(XE,n.config.apiKey,n.name)}async function i0(n,e,t=!1){if(Sn(n.app))return Promise.reject(ss(n));const s=nr(n),i=KE(s,e),a=await new ZE(s,i,t).execute();return a&&!t&&(delete a.user._redirectEventId,await s._persistUserIfCurrent(a.user),await s._setRedirectUser(null,e)),a}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const r0=10*60*1e3;class a0{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!o0(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!sy(e)){const i=((s=e.error.code)===null||s===void 0?void 0:s.split("auth/")[1])||"internal-error";t.onError(hn(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=r0&&this.cachedEventUids.clear(),this.cachedEventUids.has(ip(e))}saveEventToCache(e){this.cachedEventUids.add(ip(e)),this.lastProcessedEventTime=Date.now()}}function ip(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function sy({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function o0(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return sy(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function c0(n,e={}){return gs(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const l0=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,u0=/^https?/;async function d0(n){if(n.config.emulator)return;const{authorizedDomains:e}=await c0(n);for(const t of e)try{if(h0(t))return}catch{}tn(n,"unauthorized-domain")}function h0(n){const e=cu(),{protocol:t,hostname:s}=new URL(e);if(n.startsWith("chrome-extension://")){const a=new URL(n);return a.hostname===""&&s===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&a.hostname===s}if(!u0.test(t))return!1;if(l0.test(n))return s===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const f0=new Pa(3e4,6e4);function rp(){const n=fn().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function p0(n){return new Promise((e,t)=>{var s,i,r;function a(){rp(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{rp(),t(hn(n,"network-request-failed"))},timeout:f0.get()})}if(!((i=(s=fn().gapi)===null||s===void 0?void 0:s.iframes)===null||i===void 0)&&i.Iframe)e(gapi.iframes.getContext());else if(!((r=fn().gapi)===null||r===void 0)&&r.load)a();else{const o=aE("iframefcb");return fn()[o]=()=>{gapi.load?a():t(hn(n,"network-request-failed"))},Bg(`${rE()}?onload=${o}`).catch(l=>t(l))}}).catch(e=>{throw Ao=null,e})}let Ao=null;function m0(n){return Ao=Ao||p0(n),Ao}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const g0=new Pa(5e3,15e3),y0="__/auth/iframe",v0="emulator/auth/iframe",b0={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},_0=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function w0(n){const e=n.config;ne(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?Zu(e,v0):`https://${n.config.authDomain}/${y0}`,s={apiKey:e.apiKey,appName:n.name,v:tr},i=_0.get(n.config.apiHost);i&&(s.eid=i);const r=n._getFrameworks();return r.length&&(s.fw=r.join(",")),`${t}?${Aa(s).slice(1)}`}async function I0(n){const e=await m0(n),t=fn().gapi;return ne(t,n,"internal-error"),e.open({where:document.body,url:w0(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:b0,dontclear:!0},s=>new Promise(async(i,r)=>{await s.restyle({setHideOnLeave:!1});const a=hn(n,"network-request-failed"),o=fn().setTimeout(()=>{r(a)},g0.get());function l(){fn().clearTimeout(o),i(s)}s.ping(l).then(l,()=>{r(a)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const E0={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},T0=500,k0=600,S0="_blank",A0="http://localhost";class ap{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function P0(n,e,t,s=T0,i=k0){const r=Math.max((window.screen.availHeight-i)/2,0).toString(),a=Math.max((window.screen.availWidth-s)/2,0).toString();let o="";const l=Object.assign(Object.assign({},E0),{width:s.toString(),height:i.toString(),top:r,left:a}),u=et().toLowerCase();t&&(o=Og(u)?S0:t),Vg(u)&&(e=e||A0,l.scrollbars="yes");const h=Object.entries(l).reduce((m,[w,E])=>`${m}${w}=${E},`,"");if(QI(u)&&o!=="_self")return R0(e||"",o),new ap(null);const p=window.open(e||"",o,h);ne(p,n,"popup-blocked");try{p.focus()}catch{}return new ap(p)}function R0(n,e){const t=document.createElement("a");t.href=n,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $0="__/auth/handler",C0="emulator/auth/handler",D0=encodeURIComponent("fac");async function op(n,e,t,s,i,r){ne(n.config.authDomain,n,"auth-domain-config-required"),ne(n.config.apiKey,n,"invalid-api-key");const a={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:s,v:tr,eventId:i};if(e instanceof zg){e.setDefaultLanguage(n.languageCode),a.providerId=e.providerId||"",yw(e.getCustomParameters())||(a.customParameters=JSON.stringify(e.getCustomParameters()));for(const[h,p]of Object.entries({}))a[h]=p}if(e instanceof Ra){const h=e.getScopes().filter(p=>p!=="");h.length>0&&(a.scopes=h.join(","))}n.tenantId&&(a.tid=n.tenantId);const o=a;for(const h of Object.keys(o))o[h]===void 0&&delete o[h];const l=await n._getAppCheckToken(),u=l?`#${D0}=${encodeURIComponent(l)}`:"";return`${N0(n)}?${Aa(o).slice(1)}${u}`}function N0({config:n}){return n.emulator?Zu(n,C0):`https://${n.authDomain}/${$0}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vl="webStorageSupport";class x0{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Yg,this._completeRedirectFn=i0,this._overrideRedirectResult=t0}async _openPopup(e,t,s,i){var r;Cn((r=this.eventManagers[e._key()])===null||r===void 0?void 0:r.manager,"_initialize() not called before _openPopup()");const a=await op(e,t,s,cu(),i);return P0(e,a,id())}async _openRedirect(e,t,s,i){await this._originValidation(e);const r=await op(e,t,s,cu(),i);return ME(r),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:i,promise:r}=this.eventManagers[t];return i?Promise.resolve(i):(Cn(r,"If manager is not set, promise should be"),r)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await I0(e),s=new a0(e);return t.register("authEvent",i=>(ne(i==null?void 0:i.authEvent,e,"invalid-auth-event"),{status:s.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(Vl,{type:Vl},i=>{var r;const a=(r=i==null?void 0:i[0])===null||r===void 0?void 0:r[Vl];a!==void 0&&t(!!a),tn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=d0(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return qg()||td()||Rc()}}const V0=x0;var cp="@firebase/auth",lp="1.7.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class O0{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){ne(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function M0(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function L0(n){xi(new Us("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),r=e.getProvider("app-check-internal"),{apiKey:a,authDomain:o}=s.options;ne(a&&!a.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:a,authDomain:o,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:jg(n)},u=new nE(s,i,r,l);return dE(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),xi(new Us("auth-internal",e=>{const t=nr(e.getProvider("auth").getImmediate());return(s=>new O0(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),ns(cp,lp,M0(n)),ns(cp,lp,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F0=5*60,U0=vg("authIdTokenMaxAge")||F0;let up=null;const q0=n=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>U0)return;const i=t==null?void 0:t.token;up!==i&&(up=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function j0(n=vI()){const e=Ju(n,"auth");if(e.isInitialized())return e.getImmediate();const t=uE(n,{popupRedirectResolver:V0,persistence:[GE,xE,Yg]}),s=vg("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const r=new URL(s,location.origin);if(location.origin===r.origin){const a=q0(r.toString());PE(t,a,()=>a(t.currentUser)),AE(t,o=>a(o))}}const i=aw("auth");return i&&hE(t,`http://${i}`),t}function B0(){var n,e;return(e=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&e!==void 0?e:document}sE({loadJS(n){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",n),s.onload=e,s.onerror=i=>{const r=hn("internal-error");r.customData=i,t(r)},s.type="text/javascript",s.charset="UTF-8",B0().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});L0("Browser");var dp=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Os,iy;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(_,y){function v(){}v.prototype=y.prototype,_.D=y.prototype,_.prototype=new v,_.prototype.constructor=_,_.C=function(I,T,P){for(var b=Array(arguments.length-2),$t=2;$t<arguments.length;$t++)b[$t-2]=arguments[$t];return y.prototype[T].apply(I,b)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(s,t),s.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(_,y,v){v||(v=0);var I=Array(16);if(typeof y=="string")for(var T=0;16>T;++T)I[T]=y.charCodeAt(v++)|y.charCodeAt(v++)<<8|y.charCodeAt(v++)<<16|y.charCodeAt(v++)<<24;else for(T=0;16>T;++T)I[T]=y[v++]|y[v++]<<8|y[v++]<<16|y[v++]<<24;y=_.g[0],v=_.g[1],T=_.g[2];var P=_.g[3],b=y+(P^v&(T^P))+I[0]+3614090360&4294967295;y=v+(b<<7&4294967295|b>>>25),b=P+(T^y&(v^T))+I[1]+3905402710&4294967295,P=y+(b<<12&4294967295|b>>>20),b=T+(v^P&(y^v))+I[2]+606105819&4294967295,T=P+(b<<17&4294967295|b>>>15),b=v+(y^T&(P^y))+I[3]+3250441966&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(P^v&(T^P))+I[4]+4118548399&4294967295,y=v+(b<<7&4294967295|b>>>25),b=P+(T^y&(v^T))+I[5]+1200080426&4294967295,P=y+(b<<12&4294967295|b>>>20),b=T+(v^P&(y^v))+I[6]+2821735955&4294967295,T=P+(b<<17&4294967295|b>>>15),b=v+(y^T&(P^y))+I[7]+4249261313&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(P^v&(T^P))+I[8]+1770035416&4294967295,y=v+(b<<7&4294967295|b>>>25),b=P+(T^y&(v^T))+I[9]+2336552879&4294967295,P=y+(b<<12&4294967295|b>>>20),b=T+(v^P&(y^v))+I[10]+4294925233&4294967295,T=P+(b<<17&4294967295|b>>>15),b=v+(y^T&(P^y))+I[11]+2304563134&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(P^v&(T^P))+I[12]+1804603682&4294967295,y=v+(b<<7&4294967295|b>>>25),b=P+(T^y&(v^T))+I[13]+4254626195&4294967295,P=y+(b<<12&4294967295|b>>>20),b=T+(v^P&(y^v))+I[14]+2792965006&4294967295,T=P+(b<<17&4294967295|b>>>15),b=v+(y^T&(P^y))+I[15]+1236535329&4294967295,v=T+(b<<22&4294967295|b>>>10),b=y+(T^P&(v^T))+I[1]+4129170786&4294967295,y=v+(b<<5&4294967295|b>>>27),b=P+(v^T&(y^v))+I[6]+3225465664&4294967295,P=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(P^y))+I[11]+643717713&4294967295,T=P+(b<<14&4294967295|b>>>18),b=v+(P^y&(T^P))+I[0]+3921069994&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(T^P&(v^T))+I[5]+3593408605&4294967295,y=v+(b<<5&4294967295|b>>>27),b=P+(v^T&(y^v))+I[10]+38016083&4294967295,P=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(P^y))+I[15]+3634488961&4294967295,T=P+(b<<14&4294967295|b>>>18),b=v+(P^y&(T^P))+I[4]+3889429448&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(T^P&(v^T))+I[9]+568446438&4294967295,y=v+(b<<5&4294967295|b>>>27),b=P+(v^T&(y^v))+I[14]+3275163606&4294967295,P=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(P^y))+I[3]+4107603335&4294967295,T=P+(b<<14&4294967295|b>>>18),b=v+(P^y&(T^P))+I[8]+1163531501&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(T^P&(v^T))+I[13]+2850285829&4294967295,y=v+(b<<5&4294967295|b>>>27),b=P+(v^T&(y^v))+I[2]+4243563512&4294967295,P=y+(b<<9&4294967295|b>>>23),b=T+(y^v&(P^y))+I[7]+1735328473&4294967295,T=P+(b<<14&4294967295|b>>>18),b=v+(P^y&(T^P))+I[12]+2368359562&4294967295,v=T+(b<<20&4294967295|b>>>12),b=y+(v^T^P)+I[5]+4294588738&4294967295,y=v+(b<<4&4294967295|b>>>28),b=P+(y^v^T)+I[8]+2272392833&4294967295,P=y+(b<<11&4294967295|b>>>21),b=T+(P^y^v)+I[11]+1839030562&4294967295,T=P+(b<<16&4294967295|b>>>16),b=v+(T^P^y)+I[14]+4259657740&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(v^T^P)+I[1]+2763975236&4294967295,y=v+(b<<4&4294967295|b>>>28),b=P+(y^v^T)+I[4]+1272893353&4294967295,P=y+(b<<11&4294967295|b>>>21),b=T+(P^y^v)+I[7]+4139469664&4294967295,T=P+(b<<16&4294967295|b>>>16),b=v+(T^P^y)+I[10]+3200236656&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(v^T^P)+I[13]+681279174&4294967295,y=v+(b<<4&4294967295|b>>>28),b=P+(y^v^T)+I[0]+3936430074&4294967295,P=y+(b<<11&4294967295|b>>>21),b=T+(P^y^v)+I[3]+3572445317&4294967295,T=P+(b<<16&4294967295|b>>>16),b=v+(T^P^y)+I[6]+76029189&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(v^T^P)+I[9]+3654602809&4294967295,y=v+(b<<4&4294967295|b>>>28),b=P+(y^v^T)+I[12]+3873151461&4294967295,P=y+(b<<11&4294967295|b>>>21),b=T+(P^y^v)+I[15]+530742520&4294967295,T=P+(b<<16&4294967295|b>>>16),b=v+(T^P^y)+I[2]+3299628645&4294967295,v=T+(b<<23&4294967295|b>>>9),b=y+(T^(v|~P))+I[0]+4096336452&4294967295,y=v+(b<<6&4294967295|b>>>26),b=P+(v^(y|~T))+I[7]+1126891415&4294967295,P=y+(b<<10&4294967295|b>>>22),b=T+(y^(P|~v))+I[14]+2878612391&4294967295,T=P+(b<<15&4294967295|b>>>17),b=v+(P^(T|~y))+I[5]+4237533241&4294967295,v=T+(b<<21&4294967295|b>>>11),b=y+(T^(v|~P))+I[12]+1700485571&4294967295,y=v+(b<<6&4294967295|b>>>26),b=P+(v^(y|~T))+I[3]+2399980690&4294967295,P=y+(b<<10&4294967295|b>>>22),b=T+(y^(P|~v))+I[10]+4293915773&4294967295,T=P+(b<<15&4294967295|b>>>17),b=v+(P^(T|~y))+I[1]+2240044497&4294967295,v=T+(b<<21&4294967295|b>>>11),b=y+(T^(v|~P))+I[8]+1873313359&4294967295,y=v+(b<<6&4294967295|b>>>26),b=P+(v^(y|~T))+I[15]+4264355552&4294967295,P=y+(b<<10&4294967295|b>>>22),b=T+(y^(P|~v))+I[6]+2734768916&4294967295,T=P+(b<<15&4294967295|b>>>17),b=v+(P^(T|~y))+I[13]+1309151649&4294967295,v=T+(b<<21&4294967295|b>>>11),b=y+(T^(v|~P))+I[4]+4149444226&4294967295,y=v+(b<<6&4294967295|b>>>26),b=P+(v^(y|~T))+I[11]+3174756917&4294967295,P=y+(b<<10&4294967295|b>>>22),b=T+(y^(P|~v))+I[2]+718787259&4294967295,T=P+(b<<15&4294967295|b>>>17),b=v+(P^(T|~y))+I[9]+3951481745&4294967295,_.g[0]=_.g[0]+y&4294967295,_.g[1]=_.g[1]+(T+(b<<21&4294967295|b>>>11))&4294967295,_.g[2]=_.g[2]+T&4294967295,_.g[3]=_.g[3]+P&4294967295}s.prototype.u=function(_,y){y===void 0&&(y=_.length);for(var v=y-this.blockSize,I=this.B,T=this.h,P=0;P<y;){if(T==0)for(;P<=v;)i(this,_,P),P+=this.blockSize;if(typeof _=="string"){for(;P<y;)if(I[T++]=_.charCodeAt(P++),T==this.blockSize){i(this,I),T=0;break}}else for(;P<y;)if(I[T++]=_[P++],T==this.blockSize){i(this,I),T=0;break}}this.h=T,this.o+=y},s.prototype.v=function(){var _=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);_[0]=128;for(var y=1;y<_.length-8;++y)_[y]=0;var v=8*this.o;for(y=_.length-8;y<_.length;++y)_[y]=v&255,v/=256;for(this.u(_),_=Array(16),y=v=0;4>y;++y)for(var I=0;32>I;I+=8)_[v++]=this.g[y]>>>I&255;return _};function r(_,y){var v=o;return Object.prototype.hasOwnProperty.call(v,_)?v[_]:v[_]=y(_)}function a(_,y){this.h=y;for(var v=[],I=!0,T=_.length-1;0<=T;T--){var P=_[T]|0;I&&P==y||(v[T]=P,I=!1)}this.g=v}var o={};function l(_){return-128<=_&&128>_?r(_,function(y){return new a([y|0],0>y?-1:0)}):new a([_|0],0>_?-1:0)}function u(_){if(isNaN(_)||!isFinite(_))return p;if(0>_)return $(u(-_));for(var y=[],v=1,I=0;_>=v;I++)y[I]=_/v|0,v*=4294967296;return new a(y,0)}function h(_,y){if(_.length==0)throw Error("number format error: empty string");if(y=y||10,2>y||36<y)throw Error("radix out of range: "+y);if(_.charAt(0)=="-")return $(h(_.substring(1),y));if(0<=_.indexOf("-"))throw Error('number format error: interior "-" character');for(var v=u(Math.pow(y,8)),I=p,T=0;T<_.length;T+=8){var P=Math.min(8,_.length-T),b=parseInt(_.substring(T,T+P),y);8>P?(P=u(Math.pow(y,P)),I=I.j(P).add(u(b))):(I=I.j(v),I=I.add(u(b)))}return I}var p=l(0),m=l(1),w=l(16777216);n=a.prototype,n.m=function(){if(N(this))return-$(this).m();for(var _=0,y=1,v=0;v<this.g.length;v++){var I=this.i(v);_+=(0<=I?I:4294967296+I)*y,y*=4294967296}return _},n.toString=function(_){if(_=_||10,2>_||36<_)throw Error("radix out of range: "+_);if(E(this))return"0";if(N(this))return"-"+$(this).toString(_);for(var y=u(Math.pow(_,6)),v=this,I="";;){var T=ae(v,y).g;v=B(v,T.j(y));var P=((0<v.g.length?v.g[0]:v.h)>>>0).toString(_);if(v=T,E(v))return P+I;for(;6>P.length;)P="0"+P;I=P+I}},n.i=function(_){return 0>_?0:_<this.g.length?this.g[_]:this.h};function E(_){if(_.h!=0)return!1;for(var y=0;y<_.g.length;y++)if(_.g[y]!=0)return!1;return!0}function N(_){return _.h==-1}n.l=function(_){return _=B(this,_),N(_)?-1:E(_)?0:1};function $(_){for(var y=_.g.length,v=[],I=0;I<y;I++)v[I]=~_.g[I];return new a(v,~_.h).add(m)}n.abs=function(){return N(this)?$(this):this},n.add=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0,T=0;T<=y;T++){var P=I+(this.i(T)&65535)+(_.i(T)&65535),b=(P>>>16)+(this.i(T)>>>16)+(_.i(T)>>>16);I=b>>>16,P&=65535,b&=65535,v[T]=b<<16|P}return new a(v,v[v.length-1]&-2147483648?-1:0)};function B(_,y){return _.add($(y))}n.j=function(_){if(E(this)||E(_))return p;if(N(this))return N(_)?$(this).j($(_)):$($(this).j(_));if(N(_))return $(this.j($(_)));if(0>this.l(w)&&0>_.l(w))return u(this.m()*_.m());for(var y=this.g.length+_.g.length,v=[],I=0;I<2*y;I++)v[I]=0;for(I=0;I<this.g.length;I++)for(var T=0;T<_.g.length;T++){var P=this.i(I)>>>16,b=this.i(I)&65535,$t=_.i(T)>>>16,nn=_.i(T)&65535;v[2*I+2*T]+=b*nn,J(v,2*I+2*T),v[2*I+2*T+1]+=P*nn,J(v,2*I+2*T+1),v[2*I+2*T+1]+=b*$t,J(v,2*I+2*T+1),v[2*I+2*T+2]+=P*$t,J(v,2*I+2*T+2)}for(I=0;I<y;I++)v[I]=v[2*I+1]<<16|v[2*I];for(I=y;I<2*y;I++)v[I]=0;return new a(v,0)};function J(_,y){for(;(_[y]&65535)!=_[y];)_[y+1]+=_[y]>>>16,_[y]&=65535,y++}function H(_,y){this.g=_,this.h=y}function ae(_,y){if(E(y))throw Error("division by zero");if(E(_))return new H(p,p);if(N(_))return y=ae($(_),y),new H($(y.g),$(y.h));if(N(y))return y=ae(_,$(y)),new H($(y.g),y.h);if(30<_.g.length){if(N(_)||N(y))throw Error("slowDivide_ only works with positive integers.");for(var v=m,I=y;0>=I.l(_);)v=O(v),I=O(I);var T=U(v,1),P=U(I,1);for(I=U(I,2),v=U(v,2);!E(I);){var b=P.add(I);0>=b.l(_)&&(T=T.add(v),P=b),I=U(I,1),v=U(v,1)}return y=B(_,T.j(y)),new H(T,y)}for(T=p;0<=_.l(y);){for(v=Math.max(1,Math.floor(_.m()/y.m())),I=Math.ceil(Math.log(v)/Math.LN2),I=48>=I?1:Math.pow(2,I-48),P=u(v),b=P.j(y);N(b)||0<b.l(_);)v-=I,P=u(v),b=P.j(y);E(P)&&(P=m),T=T.add(P),_=B(_,b)}return new H(T,_)}n.A=function(_){return ae(this,_).h},n.and=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)&_.i(I);return new a(v,this.h&_.h)},n.or=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)|_.i(I);return new a(v,this.h|_.h)},n.xor=function(_){for(var y=Math.max(this.g.length,_.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)^_.i(I);return new a(v,this.h^_.h)};function O(_){for(var y=_.g.length+1,v=[],I=0;I<y;I++)v[I]=_.i(I)<<1|_.i(I-1)>>>31;return new a(v,_.h)}function U(_,y){var v=y>>5;y%=32;for(var I=_.g.length-v,T=[],P=0;P<I;P++)T[P]=0<y?_.i(P+v)>>>y|_.i(P+v+1)<<32-y:_.i(P+v);return new a(T,_.h)}s.prototype.digest=s.prototype.v,s.prototype.reset=s.prototype.s,s.prototype.update=s.prototype.u,iy=s,a.prototype.add=a.prototype.add,a.prototype.multiply=a.prototype.j,a.prototype.modulo=a.prototype.A,a.prototype.compare=a.prototype.l,a.prototype.toNumber=a.prototype.m,a.prototype.toString=a.prototype.toString,a.prototype.getBits=a.prototype.i,a.fromNumber=u,a.fromString=h,Os=a}).apply(typeof dp<"u"?dp:typeof self<"u"?self:typeof window<"u"?window:{});var co=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var ry,ay,Mr,oy,Po,du,cy,ly,uy;(function(){var n,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(c,d,f){return c==Array.prototype||c==Object.prototype||(c[d]=f.value),c};function t(c){c=[typeof globalThis=="object"&&globalThis,c,typeof window=="object"&&window,typeof self=="object"&&self,typeof co=="object"&&co];for(var d=0;d<c.length;++d){var f=c[d];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var s=t(this);function i(c,d){if(d)e:{var f=s;c=c.split(".");for(var g=0;g<c.length-1;g++){var R=c[g];if(!(R in f))break e;f=f[R]}c=c[c.length-1],g=f[c],d=d(g),d!=g&&d!=null&&e(f,c,{configurable:!0,writable:!0,value:d})}}function r(c,d){c instanceof String&&(c+="");var f=0,g=!1,R={next:function(){if(!g&&f<c.length){var D=f++;return{value:d(D,c[D]),done:!1}}return g=!0,{done:!0,value:void 0}}};return R[Symbol.iterator]=function(){return R},R}i("Array.prototype.values",function(c){return c||function(){return r(this,function(d,f){return f})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var a=a||{},o=this||self;function l(c){var d=typeof c;return d=d!="object"?d:c?Array.isArray(c)?"array":d:"null",d=="array"||d=="object"&&typeof c.length=="number"}function u(c){var d=typeof c;return d=="object"&&c!=null||d=="function"}function h(c,d,f){return c.call.apply(c.bind,arguments)}function p(c,d,f){if(!c)throw Error();if(2<arguments.length){var g=Array.prototype.slice.call(arguments,2);return function(){var R=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(R,g),c.apply(d,R)}}return function(){return c.apply(d,arguments)}}function m(c,d,f){return m=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?h:p,m.apply(null,arguments)}function w(c,d){var f=Array.prototype.slice.call(arguments,1);return function(){var g=f.slice();return g.push.apply(g,arguments),c.apply(this,g)}}function E(c,d){function f(){}f.prototype=d.prototype,c.aa=d.prototype,c.prototype=new f,c.prototype.constructor=c,c.Qb=function(g,R,D){for(var F=Array(arguments.length-2),Ne=2;Ne<arguments.length;Ne++)F[Ne-2]=arguments[Ne];return d.prototype[R].apply(g,F)}}function N(c){const d=c.length;if(0<d){const f=Array(d);for(let g=0;g<d;g++)f[g]=c[g];return f}return[]}function $(c,d){for(let f=1;f<arguments.length;f++){const g=arguments[f];if(l(g)){const R=c.length||0,D=g.length||0;c.length=R+D;for(let F=0;F<D;F++)c[R+F]=g[F]}else c.push(g)}}class B{constructor(d,f){this.i=d,this.j=f,this.h=0,this.g=null}get(){let d;return 0<this.h?(this.h--,d=this.g,this.g=d.next,d.next=null):d=this.i(),d}}function J(c){return/^[\s\xa0]*$/.test(c)}function H(){var c=o.navigator;return c&&(c=c.userAgent)?c:""}function ae(c){return ae[" "](c),c}ae[" "]=function(){};var O=H().indexOf("Gecko")!=-1&&!(H().toLowerCase().indexOf("webkit")!=-1&&H().indexOf("Edge")==-1)&&!(H().indexOf("Trident")!=-1||H().indexOf("MSIE")!=-1)&&H().indexOf("Edge")==-1;function U(c,d,f){for(const g in c)d.call(f,c[g],g,c)}function _(c,d){for(const f in c)d.call(void 0,c[f],f,c)}function y(c){const d={};for(const f in c)d[f]=c[f];return d}const v="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function I(c,d){let f,g;for(let R=1;R<arguments.length;R++){g=arguments[R];for(f in g)c[f]=g[f];for(let D=0;D<v.length;D++)f=v[D],Object.prototype.hasOwnProperty.call(g,f)&&(c[f]=g[f])}}function T(c){var d=1;c=c.split(":");const f=[];for(;0<d&&c.length;)f.push(c.shift()),d--;return c.length&&f.push(c.join(":")),f}function P(c){o.setTimeout(()=>{throw c},0)}function b(){var c=rl;let d=null;return c.g&&(d=c.g,c.g=c.g.next,c.g||(c.h=null),d.next=null),d}class $t{constructor(){this.h=this.g=null}add(d,f){const g=nn.get();g.set(d,f),this.h?this.h.next=g:this.g=g,this.h=g}}var nn=new B(()=>new v_,c=>c.reset());class v_{constructor(){this.next=this.g=this.h=null}set(d,f){this.h=d,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let ur,dr=!1,rl=new $t,xh=()=>{const c=o.Promise.resolve(void 0);ur=()=>{c.then(b_)}};var b_=()=>{for(var c;c=b();){try{c.h.call(c.g)}catch(f){P(f)}var d=nn;d.j(c),100>d.h&&(d.h++,c.next=d.g,d.g=c)}dr=!1};function Mn(){this.s=this.s,this.C=this.C}Mn.prototype.s=!1,Mn.prototype.ma=function(){this.s||(this.s=!0,this.N())},Mn.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function mt(c,d){this.type=c,this.g=this.target=d,this.defaultPrevented=!1}mt.prototype.h=function(){this.defaultPrevented=!0};var __=function(){if(!o.addEventListener||!Object.defineProperty)return!1;var c=!1,d=Object.defineProperty({},"passive",{get:function(){c=!0}});try{const f=()=>{};o.addEventListener("test",f,d),o.removeEventListener("test",f,d)}catch{}return c}();function hr(c,d){if(mt.call(this,c?c.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,c){var f=this.type=c.type,g=c.changedTouches&&c.changedTouches.length?c.changedTouches[0]:null;if(this.target=c.target||c.srcElement,this.g=d,d=c.relatedTarget){if(O){e:{try{ae(d.nodeName);var R=!0;break e}catch{}R=!1}R||(d=null)}}else f=="mouseover"?d=c.fromElement:f=="mouseout"&&(d=c.toElement);this.relatedTarget=d,g?(this.clientX=g.clientX!==void 0?g.clientX:g.pageX,this.clientY=g.clientY!==void 0?g.clientY:g.pageY,this.screenX=g.screenX||0,this.screenY=g.screenY||0):(this.clientX=c.clientX!==void 0?c.clientX:c.pageX,this.clientY=c.clientY!==void 0?c.clientY:c.pageY,this.screenX=c.screenX||0,this.screenY=c.screenY||0),this.button=c.button,this.key=c.key||"",this.ctrlKey=c.ctrlKey,this.altKey=c.altKey,this.shiftKey=c.shiftKey,this.metaKey=c.metaKey,this.pointerId=c.pointerId||0,this.pointerType=typeof c.pointerType=="string"?c.pointerType:w_[c.pointerType]||"",this.state=c.state,this.i=c,c.defaultPrevented&&hr.aa.h.call(this)}}E(hr,mt);var w_={2:"touch",3:"pen",4:"mouse"};hr.prototype.h=function(){hr.aa.h.call(this);var c=this.i;c.preventDefault?c.preventDefault():c.returnValue=!1};var Ba="closure_listenable_"+(1e6*Math.random()|0),I_=0;function E_(c,d,f,g,R){this.listener=c,this.proxy=null,this.src=d,this.type=f,this.capture=!!g,this.ha=R,this.key=++I_,this.da=this.fa=!1}function Wa(c){c.da=!0,c.listener=null,c.proxy=null,c.src=null,c.ha=null}function za(c){this.src=c,this.g={},this.h=0}za.prototype.add=function(c,d,f,g,R){var D=c.toString();c=this.g[D],c||(c=this.g[D]=[],this.h++);var F=ol(c,d,g,R);return-1<F?(d=c[F],f||(d.fa=!1)):(d=new E_(d,this.src,D,!!g,R),d.fa=f,c.push(d)),d};function al(c,d){var f=d.type;if(f in c.g){var g=c.g[f],R=Array.prototype.indexOf.call(g,d,void 0),D;(D=0<=R)&&Array.prototype.splice.call(g,R,1),D&&(Wa(d),c.g[f].length==0&&(delete c.g[f],c.h--))}}function ol(c,d,f,g){for(var R=0;R<c.length;++R){var D=c[R];if(!D.da&&D.listener==d&&D.capture==!!f&&D.ha==g)return R}return-1}var cl="closure_lm_"+(1e6*Math.random()|0),ll={};function Vh(c,d,f,g,R){if(Array.isArray(d)){for(var D=0;D<d.length;D++)Vh(c,d[D],f,g,R);return null}return f=Lh(f),c&&c[Ba]?c.K(d,f,u(g)?!!g.capture:!1,R):T_(c,d,f,!1,g,R)}function T_(c,d,f,g,R,D){if(!d)throw Error("Invalid event type");var F=u(R)?!!R.capture:!!R,Ne=dl(c);if(Ne||(c[cl]=Ne=new za(c)),f=Ne.add(d,f,g,F,D),f.proxy)return f;if(g=k_(),f.proxy=g,g.src=c,g.listener=f,c.addEventListener)__||(R=F),R===void 0&&(R=!1),c.addEventListener(d.toString(),g,R);else if(c.attachEvent)c.attachEvent(Mh(d.toString()),g);else if(c.addListener&&c.removeListener)c.addListener(g);else throw Error("addEventListener and attachEvent are unavailable.");return f}function k_(){function c(f){return d.call(c.src,c.listener,f)}const d=S_;return c}function Oh(c,d,f,g,R){if(Array.isArray(d))for(var D=0;D<d.length;D++)Oh(c,d[D],f,g,R);else g=u(g)?!!g.capture:!!g,f=Lh(f),c&&c[Ba]?(c=c.i,d=String(d).toString(),d in c.g&&(D=c.g[d],f=ol(D,f,g,R),-1<f&&(Wa(D[f]),Array.prototype.splice.call(D,f,1),D.length==0&&(delete c.g[d],c.h--)))):c&&(c=dl(c))&&(d=c.g[d.toString()],c=-1,d&&(c=ol(d,f,g,R)),(f=-1<c?d[c]:null)&&ul(f))}function ul(c){if(typeof c!="number"&&c&&!c.da){var d=c.src;if(d&&d[Ba])al(d.i,c);else{var f=c.type,g=c.proxy;d.removeEventListener?d.removeEventListener(f,g,c.capture):d.detachEvent?d.detachEvent(Mh(f),g):d.addListener&&d.removeListener&&d.removeListener(g),(f=dl(d))?(al(f,c),f.h==0&&(f.src=null,d[cl]=null)):Wa(c)}}}function Mh(c){return c in ll?ll[c]:ll[c]="on"+c}function S_(c,d){if(c.da)c=!0;else{d=new hr(d,this);var f=c.listener,g=c.ha||c.src;c.fa&&ul(c),c=f.call(g,d)}return c}function dl(c){return c=c[cl],c instanceof za?c:null}var hl="__closure_events_fn_"+(1e9*Math.random()>>>0);function Lh(c){return typeof c=="function"?c:(c[hl]||(c[hl]=function(d){return c.handleEvent(d)}),c[hl])}function gt(){Mn.call(this),this.i=new za(this),this.M=this,this.F=null}E(gt,Mn),gt.prototype[Ba]=!0,gt.prototype.removeEventListener=function(c,d,f,g){Oh(this,c,d,f,g)};function Et(c,d){var f,g=c.F;if(g)for(f=[];g;g=g.F)f.push(g);if(c=c.M,g=d.type||d,typeof d=="string")d=new mt(d,c);else if(d instanceof mt)d.target=d.target||c;else{var R=d;d=new mt(g,c),I(d,R)}if(R=!0,f)for(var D=f.length-1;0<=D;D--){var F=d.g=f[D];R=Ga(F,g,!0,d)&&R}if(F=d.g=c,R=Ga(F,g,!0,d)&&R,R=Ga(F,g,!1,d)&&R,f)for(D=0;D<f.length;D++)F=d.g=f[D],R=Ga(F,g,!1,d)&&R}gt.prototype.N=function(){if(gt.aa.N.call(this),this.i){var c=this.i,d;for(d in c.g){for(var f=c.g[d],g=0;g<f.length;g++)Wa(f[g]);delete c.g[d],c.h--}}this.F=null},gt.prototype.K=function(c,d,f,g){return this.i.add(String(c),d,!1,f,g)},gt.prototype.L=function(c,d,f,g){return this.i.add(String(c),d,!0,f,g)};function Ga(c,d,f,g){if(d=c.i.g[String(d)],!d)return!0;d=d.concat();for(var R=!0,D=0;D<d.length;++D){var F=d[D];if(F&&!F.da&&F.capture==f){var Ne=F.listener,ut=F.ha||F.src;F.fa&&al(c.i,F),R=Ne.call(ut,g)!==!1&&R}}return R&&!g.defaultPrevented}function Fh(c,d,f){if(typeof c=="function")f&&(c=m(c,f));else if(c&&typeof c.handleEvent=="function")c=m(c.handleEvent,c);else throw Error("Invalid listener argument");return 2147483647<Number(d)?-1:o.setTimeout(c,d||0)}function Uh(c){c.g=Fh(()=>{c.g=null,c.i&&(c.i=!1,Uh(c))},c.l);const d=c.h;c.h=null,c.m.apply(null,d)}class A_ extends Mn{constructor(d,f){super(),this.m=d,this.l=f,this.h=null,this.i=!1,this.g=null}j(d){this.h=arguments,this.g?this.i=!0:Uh(this)}N(){super.N(),this.g&&(o.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function fr(c){Mn.call(this),this.h=c,this.g={}}E(fr,Mn);var qh=[];function jh(c){U(c.g,function(d,f){this.g.hasOwnProperty(f)&&ul(d)},c),c.g={}}fr.prototype.N=function(){fr.aa.N.call(this),jh(this)},fr.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var fl=o.JSON.stringify,P_=o.JSON.parse,R_=class{stringify(c){return o.JSON.stringify(c,void 0)}parse(c){return o.JSON.parse(c,void 0)}};function pl(){}pl.prototype.h=null;function Bh(c){return c.h||(c.h=c.i())}function Wh(){}var pr={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function ml(){mt.call(this,"d")}E(ml,mt);function gl(){mt.call(this,"c")}E(gl,mt);var Is={},zh=null;function Ka(){return zh=zh||new gt}Is.La="serverreachability";function Gh(c){mt.call(this,Is.La,c)}E(Gh,mt);function mr(c){const d=Ka();Et(d,new Gh(d))}Is.STAT_EVENT="statevent";function Kh(c,d){mt.call(this,Is.STAT_EVENT,c),this.stat=d}E(Kh,mt);function Tt(c){const d=Ka();Et(d,new Kh(d,c))}Is.Ma="timingevent";function Hh(c,d){mt.call(this,Is.Ma,c),this.size=d}E(Hh,mt);function gr(c,d){if(typeof c!="function")throw Error("Fn must not be null and must be a function");return o.setTimeout(function(){c()},d)}function yr(){this.g=!0}yr.prototype.xa=function(){this.g=!1};function $_(c,d,f,g,R,D){c.info(function(){if(c.g)if(D)for(var F="",Ne=D.split("&"),ut=0;ut<Ne.length;ut++){var Ie=Ne[ut].split("=");if(1<Ie.length){var yt=Ie[0];Ie=Ie[1];var vt=yt.split("_");F=2<=vt.length&&vt[1]=="type"?F+(yt+"="+Ie+"&"):F+(yt+"=redacted&")}}else F=null;else F=D;return"XMLHTTP REQ ("+g+") [attempt "+R+"]: "+d+`
`+f+`
`+F})}function C_(c,d,f,g,R,D,F){c.info(function(){return"XMLHTTP RESP ("+g+") [ attempt "+R+"]: "+d+`
`+f+`
`+D+" "+F})}function ri(c,d,f,g){c.info(function(){return"XMLHTTP TEXT ("+d+"): "+N_(c,f)+(g?" "+g:"")})}function D_(c,d){c.info(function(){return"TIMEOUT: "+d})}yr.prototype.info=function(){};function N_(c,d){if(!c.g)return d;if(!d)return null;try{var f=JSON.parse(d);if(f){for(c=0;c<f.length;c++)if(Array.isArray(f[c])){var g=f[c];if(!(2>g.length)){var R=g[1];if(Array.isArray(R)&&!(1>R.length)){var D=R[0];if(D!="noop"&&D!="stop"&&D!="close")for(var F=1;F<R.length;F++)R[F]=""}}}}return fl(f)}catch{return d}}var Ha={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},Qh={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},yl;function Qa(){}E(Qa,pl),Qa.prototype.g=function(){return new XMLHttpRequest},Qa.prototype.i=function(){return{}},yl=new Qa;function Ln(c,d,f,g){this.j=c,this.i=d,this.l=f,this.R=g||1,this.U=new fr(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new Jh}function Jh(){this.i=null,this.g="",this.h=!1}var Yh={},vl={};function bl(c,d,f){c.L=1,c.v=Za(bn(d)),c.m=f,c.P=!0,Xh(c,null)}function Xh(c,d){c.F=Date.now(),Ja(c),c.A=bn(c.v);var f=c.A,g=c.R;Array.isArray(g)||(g=[String(g)]),ff(f.i,"t",g),c.C=0,f=c.j.J,c.h=new Jh,c.g=Cf(c.j,f?d:null,!c.m),0<c.O&&(c.M=new A_(m(c.Y,c,c.g),c.O)),d=c.U,f=c.g,g=c.ca;var R="readystatechange";Array.isArray(R)||(R&&(qh[0]=R.toString()),R=qh);for(var D=0;D<R.length;D++){var F=Vh(f,R[D],g||d.handleEvent,!1,d.h||d);if(!F)break;d.g[F.key]=F}d=c.H?y(c.H):{},c.m?(c.u||(c.u="POST"),d["Content-Type"]="application/x-www-form-urlencoded",c.g.ea(c.A,c.u,c.m,d)):(c.u="GET",c.g.ea(c.A,c.u,null,d)),mr(),$_(c.i,c.u,c.A,c.l,c.R,c.m)}Ln.prototype.ca=function(c){c=c.target;const d=this.M;d&&_n(c)==3?d.j():this.Y(c)},Ln.prototype.Y=function(c){try{if(c==this.g)e:{const vt=_n(this.g);var d=this.g.Ba();const ci=this.g.Z();if(!(3>vt)&&(vt!=3||this.g&&(this.h.h||this.g.oa()||_f(this.g)))){this.J||vt!=4||d==7||(d==8||0>=ci?mr(3):mr(2)),_l(this);var f=this.g.Z();this.X=f;t:if(Zh(this)){var g=_f(this.g);c="";var R=g.length,D=_n(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){Es(this),vr(this);var F="";break t}this.h.i=new o.TextDecoder}for(d=0;d<R;d++)this.h.h=!0,c+=this.h.i.decode(g[d],{stream:!(D&&d==R-1)});g.length=0,this.h.g+=c,this.C=0,F=this.h.g}else F=this.g.oa();if(this.o=f==200,C_(this.i,this.u,this.A,this.l,this.R,vt,f),this.o){if(this.T&&!this.K){t:{if(this.g){var Ne,ut=this.g;if((Ne=ut.g?ut.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!J(Ne)){var Ie=Ne;break t}}Ie=null}if(f=Ie)ri(this.i,this.l,f,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,wl(this,f);else{this.o=!1,this.s=3,Tt(12),Es(this),vr(this);break e}}if(this.P){f=!0;let Qt;for(;!this.J&&this.C<F.length;)if(Qt=x_(this,F),Qt==vl){vt==4&&(this.s=4,Tt(14),f=!1),ri(this.i,this.l,null,"[Incomplete Response]");break}else if(Qt==Yh){this.s=4,Tt(15),ri(this.i,this.l,F,"[Invalid Chunk]"),f=!1;break}else ri(this.i,this.l,Qt,null),wl(this,Qt);if(Zh(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),vt!=4||F.length!=0||this.h.h||(this.s=1,Tt(16),f=!1),this.o=this.o&&f,!f)ri(this.i,this.l,F,"[Invalid Chunked Response]"),Es(this),vr(this);else if(0<F.length&&!this.W){this.W=!0;var yt=this.j;yt.g==this&&yt.ba&&!yt.M&&(yt.j.info("Great, no buffering proxy detected. Bytes received: "+F.length),Al(yt),yt.M=!0,Tt(11))}}else ri(this.i,this.l,F,null),wl(this,F);vt==4&&Es(this),this.o&&!this.J&&(vt==4?Af(this.j,this):(this.o=!1,Ja(this)))}else Y_(this.g),f==400&&0<F.indexOf("Unknown SID")?(this.s=3,Tt(12)):(this.s=0,Tt(13)),Es(this),vr(this)}}}catch{}finally{}};function Zh(c){return c.g?c.u=="GET"&&c.L!=2&&c.j.Ca:!1}function x_(c,d){var f=c.C,g=d.indexOf(`
`,f);return g==-1?vl:(f=Number(d.substring(f,g)),isNaN(f)?Yh:(g+=1,g+f>d.length?vl:(d=d.slice(g,g+f),c.C=g+f,d)))}Ln.prototype.cancel=function(){this.J=!0,Es(this)};function Ja(c){c.S=Date.now()+c.I,ef(c,c.I)}function ef(c,d){if(c.B!=null)throw Error("WatchDog timer not null");c.B=gr(m(c.ba,c),d)}function _l(c){c.B&&(o.clearTimeout(c.B),c.B=null)}Ln.prototype.ba=function(){this.B=null;const c=Date.now();0<=c-this.S?(D_(this.i,this.A),this.L!=2&&(mr(),Tt(17)),Es(this),this.s=2,vr(this)):ef(this,this.S-c)};function vr(c){c.j.G==0||c.J||Af(c.j,c)}function Es(c){_l(c);var d=c.M;d&&typeof d.ma=="function"&&d.ma(),c.M=null,jh(c.U),c.g&&(d=c.g,c.g=null,d.abort(),d.ma())}function wl(c,d){try{var f=c.j;if(f.G!=0&&(f.g==c||Il(f.h,c))){if(!c.K&&Il(f.h,c)&&f.G==3){try{var g=f.Da.g.parse(d)}catch{g=null}if(Array.isArray(g)&&g.length==3){var R=g;if(R[0]==0){e:if(!f.u){if(f.g)if(f.g.F+3e3<c.F)io(f),no(f);else break e;Sl(f),Tt(18)}}else f.za=R[1],0<f.za-f.T&&37500>R[2]&&f.F&&f.v==0&&!f.C&&(f.C=gr(m(f.Za,f),6e3));if(1>=sf(f.h)&&f.ca){try{f.ca()}catch{}f.ca=void 0}}else ks(f,11)}else if((c.K||f.g==c)&&io(f),!J(d))for(R=f.Da.g.parse(d),d=0;d<R.length;d++){let Ie=R[d];if(f.T=Ie[0],Ie=Ie[1],f.G==2)if(Ie[0]=="c"){f.K=Ie[1],f.ia=Ie[2];const yt=Ie[3];yt!=null&&(f.la=yt,f.j.info("VER="+f.la));const vt=Ie[4];vt!=null&&(f.Aa=vt,f.j.info("SVER="+f.Aa));const ci=Ie[5];ci!=null&&typeof ci=="number"&&0<ci&&(g=1.5*ci,f.L=g,f.j.info("backChannelRequestTimeoutMs_="+g)),g=f;const Qt=c.g;if(Qt){const ao=Qt.g?Qt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(ao){var D=g.h;D.g||ao.indexOf("spdy")==-1&&ao.indexOf("quic")==-1&&ao.indexOf("h2")==-1||(D.j=D.l,D.g=new Set,D.h&&(El(D,D.h),D.h=null))}if(g.D){const Pl=Qt.g?Qt.g.getResponseHeader("X-HTTP-Session-Id"):null;Pl&&(g.ya=Pl,Fe(g.I,g.D,Pl))}}f.G=3,f.l&&f.l.ua(),f.ba&&(f.R=Date.now()-c.F,f.j.info("Handshake RTT: "+f.R+"ms")),g=f;var F=c;if(g.qa=$f(g,g.J?g.ia:null,g.W),F.K){rf(g.h,F);var Ne=F,ut=g.L;ut&&(Ne.I=ut),Ne.B&&(_l(Ne),Ja(Ne)),g.g=F}else kf(g);0<f.i.length&&so(f)}else Ie[0]!="stop"&&Ie[0]!="close"||ks(f,7);else f.G==3&&(Ie[0]=="stop"||Ie[0]=="close"?Ie[0]=="stop"?ks(f,7):kl(f):Ie[0]!="noop"&&f.l&&f.l.ta(Ie),f.v=0)}}mr(4)}catch{}}var V_=class{constructor(c,d){this.g=c,this.map=d}};function tf(c){this.l=c||10,o.PerformanceNavigationTiming?(c=o.performance.getEntriesByType("navigation"),c=0<c.length&&(c[0].nextHopProtocol=="hq"||c[0].nextHopProtocol=="h2")):c=!!(o.chrome&&o.chrome.loadTimes&&o.chrome.loadTimes()&&o.chrome.loadTimes().wasFetchedViaSpdy),this.j=c?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function nf(c){return c.h?!0:c.g?c.g.size>=c.j:!1}function sf(c){return c.h?1:c.g?c.g.size:0}function Il(c,d){return c.h?c.h==d:c.g?c.g.has(d):!1}function El(c,d){c.g?c.g.add(d):c.h=d}function rf(c,d){c.h&&c.h==d?c.h=null:c.g&&c.g.has(d)&&c.g.delete(d)}tf.prototype.cancel=function(){if(this.i=af(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const c of this.g.values())c.cancel();this.g.clear()}};function af(c){if(c.h!=null)return c.i.concat(c.h.D);if(c.g!=null&&c.g.size!==0){let d=c.i;for(const f of c.g.values())d=d.concat(f.D);return d}return N(c.i)}function O_(c){if(c.V&&typeof c.V=="function")return c.V();if(typeof Map<"u"&&c instanceof Map||typeof Set<"u"&&c instanceof Set)return Array.from(c.values());if(typeof c=="string")return c.split("");if(l(c)){for(var d=[],f=c.length,g=0;g<f;g++)d.push(c[g]);return d}d=[],f=0;for(g in c)d[f++]=c[g];return d}function M_(c){if(c.na&&typeof c.na=="function")return c.na();if(!c.V||typeof c.V!="function"){if(typeof Map<"u"&&c instanceof Map)return Array.from(c.keys());if(!(typeof Set<"u"&&c instanceof Set)){if(l(c)||typeof c=="string"){var d=[];c=c.length;for(var f=0;f<c;f++)d.push(f);return d}d=[],f=0;for(const g in c)d[f++]=g;return d}}}function of(c,d){if(c.forEach&&typeof c.forEach=="function")c.forEach(d,void 0);else if(l(c)||typeof c=="string")Array.prototype.forEach.call(c,d,void 0);else for(var f=M_(c),g=O_(c),R=g.length,D=0;D<R;D++)d.call(void 0,g[D],f&&f[D],c)}var cf=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function L_(c,d){if(c){c=c.split("&");for(var f=0;f<c.length;f++){var g=c[f].indexOf("="),R=null;if(0<=g){var D=c[f].substring(0,g);R=c[f].substring(g+1)}else D=c[f];d(D,R?decodeURIComponent(R.replace(/\+/g," ")):"")}}}function Ts(c){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,c instanceof Ts){this.h=c.h,Ya(this,c.j),this.o=c.o,this.g=c.g,Xa(this,c.s),this.l=c.l;var d=c.i,f=new wr;f.i=d.i,d.g&&(f.g=new Map(d.g),f.h=d.h),lf(this,f),this.m=c.m}else c&&(d=String(c).match(cf))?(this.h=!1,Ya(this,d[1]||"",!0),this.o=br(d[2]||""),this.g=br(d[3]||"",!0),Xa(this,d[4]),this.l=br(d[5]||"",!0),lf(this,d[6]||"",!0),this.m=br(d[7]||"")):(this.h=!1,this.i=new wr(null,this.h))}Ts.prototype.toString=function(){var c=[],d=this.j;d&&c.push(_r(d,uf,!0),":");var f=this.g;return(f||d=="file")&&(c.push("//"),(d=this.o)&&c.push(_r(d,uf,!0),"@"),c.push(encodeURIComponent(String(f)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.s,f!=null&&c.push(":",String(f))),(f=this.l)&&(this.g&&f.charAt(0)!="/"&&c.push("/"),c.push(_r(f,f.charAt(0)=="/"?q_:U_,!0))),(f=this.i.toString())&&c.push("?",f),(f=this.m)&&c.push("#",_r(f,B_)),c.join("")};function bn(c){return new Ts(c)}function Ya(c,d,f){c.j=f?br(d,!0):d,c.j&&(c.j=c.j.replace(/:$/,""))}function Xa(c,d){if(d){if(d=Number(d),isNaN(d)||0>d)throw Error("Bad port number "+d);c.s=d}else c.s=null}function lf(c,d,f){d instanceof wr?(c.i=d,W_(c.i,c.h)):(f||(d=_r(d,j_)),c.i=new wr(d,c.h))}function Fe(c,d,f){c.i.set(d,f)}function Za(c){return Fe(c,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),c}function br(c,d){return c?d?decodeURI(c.replace(/%25/g,"%2525")):decodeURIComponent(c):""}function _r(c,d,f){return typeof c=="string"?(c=encodeURI(c).replace(d,F_),f&&(c=c.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c):null}function F_(c){return c=c.charCodeAt(0),"%"+(c>>4&15).toString(16)+(c&15).toString(16)}var uf=/[#\/\?@]/g,U_=/[#\?:]/g,q_=/[#\?]/g,j_=/[#\?@]/g,B_=/#/g;function wr(c,d){this.h=this.g=null,this.i=c||null,this.j=!!d}function Fn(c){c.g||(c.g=new Map,c.h=0,c.i&&L_(c.i,function(d,f){c.add(decodeURIComponent(d.replace(/\+/g," ")),f)}))}n=wr.prototype,n.add=function(c,d){Fn(this),this.i=null,c=ai(this,c);var f=this.g.get(c);return f||this.g.set(c,f=[]),f.push(d),this.h+=1,this};function df(c,d){Fn(c),d=ai(c,d),c.g.has(d)&&(c.i=null,c.h-=c.g.get(d).length,c.g.delete(d))}function hf(c,d){return Fn(c),d=ai(c,d),c.g.has(d)}n.forEach=function(c,d){Fn(this),this.g.forEach(function(f,g){f.forEach(function(R){c.call(d,R,g,this)},this)},this)},n.na=function(){Fn(this);const c=Array.from(this.g.values()),d=Array.from(this.g.keys()),f=[];for(let g=0;g<d.length;g++){const R=c[g];for(let D=0;D<R.length;D++)f.push(d[g])}return f},n.V=function(c){Fn(this);let d=[];if(typeof c=="string")hf(this,c)&&(d=d.concat(this.g.get(ai(this,c))));else{c=Array.from(this.g.values());for(let f=0;f<c.length;f++)d=d.concat(c[f])}return d},n.set=function(c,d){return Fn(this),this.i=null,c=ai(this,c),hf(this,c)&&(this.h-=this.g.get(c).length),this.g.set(c,[d]),this.h+=1,this},n.get=function(c,d){return c?(c=this.V(c),0<c.length?String(c[0]):d):d};function ff(c,d,f){df(c,d),0<f.length&&(c.i=null,c.g.set(ai(c,d),N(f)),c.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const c=[],d=Array.from(this.g.keys());for(var f=0;f<d.length;f++){var g=d[f];const D=encodeURIComponent(String(g)),F=this.V(g);for(g=0;g<F.length;g++){var R=D;F[g]!==""&&(R+="="+encodeURIComponent(String(F[g]))),c.push(R)}}return this.i=c.join("&")};function ai(c,d){return d=String(d),c.j&&(d=d.toLowerCase()),d}function W_(c,d){d&&!c.j&&(Fn(c),c.i=null,c.g.forEach(function(f,g){var R=g.toLowerCase();g!=R&&(df(this,g),ff(this,R,f))},c)),c.j=d}function z_(c,d){const f=new yr;if(o.Image){const g=new Image;g.onload=w(Un,f,"TestLoadImage: loaded",!0,d,g),g.onerror=w(Un,f,"TestLoadImage: error",!1,d,g),g.onabort=w(Un,f,"TestLoadImage: abort",!1,d,g),g.ontimeout=w(Un,f,"TestLoadImage: timeout",!1,d,g),o.setTimeout(function(){g.ontimeout&&g.ontimeout()},1e4),g.src=c}else d(!1)}function G_(c,d){const f=new yr,g=new AbortController,R=setTimeout(()=>{g.abort(),Un(f,"TestPingServer: timeout",!1,d)},1e4);fetch(c,{signal:g.signal}).then(D=>{clearTimeout(R),D.ok?Un(f,"TestPingServer: ok",!0,d):Un(f,"TestPingServer: server error",!1,d)}).catch(()=>{clearTimeout(R),Un(f,"TestPingServer: error",!1,d)})}function Un(c,d,f,g,R){try{R&&(R.onload=null,R.onerror=null,R.onabort=null,R.ontimeout=null),g(f)}catch{}}function K_(){this.g=new R_}function H_(c,d,f){const g=f||"";try{of(c,function(R,D){let F=R;u(R)&&(F=fl(R)),d.push(g+D+"="+encodeURIComponent(F))})}catch(R){throw d.push(g+"type="+encodeURIComponent("_badmap")),R}}function Ir(c){this.l=c.Ub||null,this.j=c.eb||!1}E(Ir,pl),Ir.prototype.g=function(){return new eo(this.l,this.j)},Ir.prototype.i=function(c){return function(){return c}}({});function eo(c,d){gt.call(this),this.D=c,this.o=d,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}E(eo,gt),n=eo.prototype,n.open=function(c,d){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=c,this.A=d,this.readyState=1,Tr(this)},n.send=function(c){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const d={headers:this.u,method:this.B,credentials:this.m,cache:void 0};c&&(d.body=c),(this.D||o).fetch(new Request(this.A,d)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,Er(this)),this.readyState=0},n.Sa=function(c){if(this.g&&(this.l=c,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=c.headers,this.readyState=2,Tr(this)),this.g&&(this.readyState=3,Tr(this),this.g)))if(this.responseType==="arraybuffer")c.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof o.ReadableStream<"u"&&"body"in c){if(this.j=c.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;pf(this)}else c.text().then(this.Ra.bind(this),this.ga.bind(this))};function pf(c){c.j.read().then(c.Pa.bind(c)).catch(c.ga.bind(c))}n.Pa=function(c){if(this.g){if(this.o&&c.value)this.response.push(c.value);else if(!this.o){var d=c.value?c.value:new Uint8Array(0);(d=this.v.decode(d,{stream:!c.done}))&&(this.response=this.responseText+=d)}c.done?Er(this):Tr(this),this.readyState==3&&pf(this)}},n.Ra=function(c){this.g&&(this.response=this.responseText=c,Er(this))},n.Qa=function(c){this.g&&(this.response=c,Er(this))},n.ga=function(){this.g&&Er(this)};function Er(c){c.readyState=4,c.l=null,c.j=null,c.v=null,Tr(c)}n.setRequestHeader=function(c,d){this.u.append(c,d)},n.getResponseHeader=function(c){return this.h&&this.h.get(c.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const c=[],d=this.h.entries();for(var f=d.next();!f.done;)f=f.value,c.push(f[0]+": "+f[1]),f=d.next();return c.join(`\r
`)};function Tr(c){c.onreadystatechange&&c.onreadystatechange.call(c)}Object.defineProperty(eo.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(c){this.m=c?"include":"same-origin"}});function mf(c){let d="";return U(c,function(f,g){d+=g,d+=":",d+=f,d+=`\r
`}),d}function Tl(c,d,f){e:{for(g in f){var g=!1;break e}g=!0}g||(f=mf(f),typeof c=="string"?f!=null&&encodeURIComponent(String(f)):Fe(c,d,f))}function ze(c){gt.call(this),this.headers=new Map,this.o=c||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}E(ze,gt);var Q_=/^https?$/i,J_=["POST","PUT"];n=ze.prototype,n.Ha=function(c){this.J=c},n.ea=function(c,d,f,g){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+c);d=d?d.toUpperCase():"GET",this.D=c,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():yl.g(),this.v=this.o?Bh(this.o):Bh(yl),this.g.onreadystatechange=m(this.Ea,this);try{this.B=!0,this.g.open(d,String(c),!0),this.B=!1}catch(D){gf(this,D);return}if(c=f||"",f=new Map(this.headers),g)if(Object.getPrototypeOf(g)===Object.prototype)for(var R in g)f.set(R,g[R]);else if(typeof g.keys=="function"&&typeof g.get=="function")for(const D of g.keys())f.set(D,g.get(D));else throw Error("Unknown input type for opt_headers: "+String(g));g=Array.from(f.keys()).find(D=>D.toLowerCase()=="content-type"),R=o.FormData&&c instanceof o.FormData,!(0<=Array.prototype.indexOf.call(J_,d,void 0))||g||R||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[D,F]of f)this.g.setRequestHeader(D,F);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{bf(this),this.u=!0,this.g.send(c),this.u=!1}catch(D){gf(this,D)}};function gf(c,d){c.h=!1,c.g&&(c.j=!0,c.g.abort(),c.j=!1),c.l=d,c.m=5,yf(c),to(c)}function yf(c){c.A||(c.A=!0,Et(c,"complete"),Et(c,"error"))}n.abort=function(c){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=c||7,Et(this,"complete"),Et(this,"abort"),to(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),to(this,!0)),ze.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?vf(this):this.bb())},n.bb=function(){vf(this)};function vf(c){if(c.h&&typeof a<"u"&&(!c.v[1]||_n(c)!=4||c.Z()!=2)){if(c.u&&_n(c)==4)Fh(c.Ea,0,c);else if(Et(c,"readystatechange"),_n(c)==4){c.h=!1;try{const F=c.Z();e:switch(F){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var d=!0;break e;default:d=!1}var f;if(!(f=d)){var g;if(g=F===0){var R=String(c.D).match(cf)[1]||null;!R&&o.self&&o.self.location&&(R=o.self.location.protocol.slice(0,-1)),g=!Q_.test(R?R.toLowerCase():"")}f=g}if(f)Et(c,"complete"),Et(c,"success");else{c.m=6;try{var D=2<_n(c)?c.g.statusText:""}catch{D=""}c.l=D+" ["+c.Z()+"]",yf(c)}}finally{to(c)}}}}function to(c,d){if(c.g){bf(c);const f=c.g,g=c.v[0]?()=>{}:null;c.g=null,c.v=null,d||Et(c,"ready");try{f.onreadystatechange=g}catch{}}}function bf(c){c.I&&(o.clearTimeout(c.I),c.I=null)}n.isActive=function(){return!!this.g};function _n(c){return c.g?c.g.readyState:0}n.Z=function(){try{return 2<_n(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(c){if(this.g){var d=this.g.responseText;return c&&d.indexOf(c)==0&&(d=d.substring(c.length)),P_(d)}};function _f(c){try{if(!c.g)return null;if("response"in c.g)return c.g.response;switch(c.H){case"":case"text":return c.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in c.g)return c.g.mozResponseArrayBuffer}return null}catch{return null}}function Y_(c){const d={};c=(c.g&&2<=_n(c)&&c.g.getAllResponseHeaders()||"").split(`\r
`);for(let g=0;g<c.length;g++){if(J(c[g]))continue;var f=T(c[g]);const R=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const D=d[R]||[];d[R]=D,D.push(f)}_(d,function(g){return g.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function kr(c,d,f){return f&&f.internalChannelParams&&f.internalChannelParams[c]||d}function wf(c){this.Aa=0,this.i=[],this.j=new yr,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=kr("failFast",!1,c),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=kr("baseRetryDelayMs",5e3,c),this.cb=kr("retryDelaySeedMs",1e4,c),this.Wa=kr("forwardChannelMaxRetries",2,c),this.wa=kr("forwardChannelRequestTimeoutMs",2e4,c),this.pa=c&&c.xmlHttpFactory||void 0,this.Xa=c&&c.Tb||void 0,this.Ca=c&&c.useFetchStreams||!1,this.L=void 0,this.J=c&&c.supportsCrossDomainXhr||!1,this.K="",this.h=new tf(c&&c.concurrentRequestLimit),this.Da=new K_,this.P=c&&c.fastHandshake||!1,this.O=c&&c.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=c&&c.Rb||!1,c&&c.xa&&this.j.xa(),c&&c.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&c&&c.detectBufferingProxy||!1,this.ja=void 0,c&&c.longPollingTimeout&&0<c.longPollingTimeout&&(this.ja=c.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=wf.prototype,n.la=8,n.G=1,n.connect=function(c,d,f,g){Tt(0),this.W=c,this.H=d||{},f&&g!==void 0&&(this.H.OSID=f,this.H.OAID=g),this.F=this.X,this.I=$f(this,null,this.W),so(this)};function kl(c){if(If(c),c.G==3){var d=c.U++,f=bn(c.I);if(Fe(f,"SID",c.K),Fe(f,"RID",d),Fe(f,"TYPE","terminate"),Sr(c,f),d=new Ln(c,c.j,d),d.L=2,d.v=Za(bn(f)),f=!1,o.navigator&&o.navigator.sendBeacon)try{f=o.navigator.sendBeacon(d.v.toString(),"")}catch{}!f&&o.Image&&(new Image().src=d.v,f=!0),f||(d.g=Cf(d.j,null),d.g.ea(d.v)),d.F=Date.now(),Ja(d)}Rf(c)}function no(c){c.g&&(Al(c),c.g.cancel(),c.g=null)}function If(c){no(c),c.u&&(o.clearTimeout(c.u),c.u=null),io(c),c.h.cancel(),c.s&&(typeof c.s=="number"&&o.clearTimeout(c.s),c.s=null)}function so(c){if(!nf(c.h)&&!c.s){c.s=!0;var d=c.Ga;ur||xh(),dr||(ur(),dr=!0),rl.add(d,c),c.B=0}}function X_(c,d){return sf(c.h)>=c.h.j-(c.s?1:0)?!1:c.s?(c.i=d.D.concat(c.i),!0):c.G==1||c.G==2||c.B>=(c.Va?0:c.Wa)?!1:(c.s=gr(m(c.Ga,c,d),Pf(c,c.B)),c.B++,!0)}n.Ga=function(c){if(this.s)if(this.s=null,this.G==1){if(!c){this.U=Math.floor(1e5*Math.random()),c=this.U++;const R=new Ln(this,this.j,c);let D=this.o;if(this.S&&(D?(D=y(D),I(D,this.S)):D=this.S),this.m!==null||this.O||(R.H=D,D=null),this.P)e:{for(var d=0,f=0;f<this.i.length;f++){t:{var g=this.i[f];if("__data__"in g.map&&(g=g.map.__data__,typeof g=="string")){g=g.length;break t}g=void 0}if(g===void 0)break;if(d+=g,4096<d){d=f;break e}if(d===4096||f===this.i.length-1){d=f+1;break e}}d=1e3}else d=1e3;d=Tf(this,R,d),f=bn(this.I),Fe(f,"RID",c),Fe(f,"CVER",22),this.D&&Fe(f,"X-HTTP-Session-Id",this.D),Sr(this,f),D&&(this.O?d="headers="+encodeURIComponent(String(mf(D)))+"&"+d:this.m&&Tl(f,this.m,D)),El(this.h,R),this.Ua&&Fe(f,"TYPE","init"),this.P?(Fe(f,"$req",d),Fe(f,"SID","null"),R.T=!0,bl(R,f,null)):bl(R,f,d),this.G=2}}else this.G==3&&(c?Ef(this,c):this.i.length==0||nf(this.h)||Ef(this))};function Ef(c,d){var f;d?f=d.l:f=c.U++;const g=bn(c.I);Fe(g,"SID",c.K),Fe(g,"RID",f),Fe(g,"AID",c.T),Sr(c,g),c.m&&c.o&&Tl(g,c.m,c.o),f=new Ln(c,c.j,f,c.B+1),c.m===null&&(f.H=c.o),d&&(c.i=d.D.concat(c.i)),d=Tf(c,f,1e3),f.I=Math.round(.5*c.wa)+Math.round(.5*c.wa*Math.random()),El(c.h,f),bl(f,g,d)}function Sr(c,d){c.H&&U(c.H,function(f,g){Fe(d,g,f)}),c.l&&of({},function(f,g){Fe(d,g,f)})}function Tf(c,d,f){f=Math.min(c.i.length,f);var g=c.l?m(c.l.Na,c.l,c):null;e:{var R=c.i;let D=-1;for(;;){const F=["count="+f];D==-1?0<f?(D=R[0].g,F.push("ofs="+D)):D=0:F.push("ofs="+D);let Ne=!0;for(let ut=0;ut<f;ut++){let Ie=R[ut].g;const yt=R[ut].map;if(Ie-=D,0>Ie)D=Math.max(0,R[ut].g-100),Ne=!1;else try{H_(yt,F,"req"+Ie+"_")}catch{g&&g(yt)}}if(Ne){g=F.join("&");break e}}}return c=c.i.splice(0,f),d.D=c,g}function kf(c){if(!c.g&&!c.u){c.Y=1;var d=c.Fa;ur||xh(),dr||(ur(),dr=!0),rl.add(d,c),c.v=0}}function Sl(c){return c.g||c.u||3<=c.v?!1:(c.Y++,c.u=gr(m(c.Fa,c),Pf(c,c.v)),c.v++,!0)}n.Fa=function(){if(this.u=null,Sf(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var c=2*this.R;this.j.info("BP detection timer enabled: "+c),this.A=gr(m(this.ab,this),c)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,Tt(10),no(this),Sf(this))};function Al(c){c.A!=null&&(o.clearTimeout(c.A),c.A=null)}function Sf(c){c.g=new Ln(c,c.j,"rpc",c.Y),c.m===null&&(c.g.H=c.o),c.g.O=0;var d=bn(c.qa);Fe(d,"RID","rpc"),Fe(d,"SID",c.K),Fe(d,"AID",c.T),Fe(d,"CI",c.F?"0":"1"),!c.F&&c.ja&&Fe(d,"TO",c.ja),Fe(d,"TYPE","xmlhttp"),Sr(c,d),c.m&&c.o&&Tl(d,c.m,c.o),c.L&&(c.g.I=c.L);var f=c.g;c=c.ia,f.L=1,f.v=Za(bn(d)),f.m=null,f.P=!0,Xh(f,c)}n.Za=function(){this.C!=null&&(this.C=null,no(this),Sl(this),Tt(19))};function io(c){c.C!=null&&(o.clearTimeout(c.C),c.C=null)}function Af(c,d){var f=null;if(c.g==d){io(c),Al(c),c.g=null;var g=2}else if(Il(c.h,d))f=d.D,rf(c.h,d),g=1;else return;if(c.G!=0){if(d.o)if(g==1){f=d.m?d.m.length:0,d=Date.now()-d.F;var R=c.B;g=Ka(),Et(g,new Hh(g,f)),so(c)}else kf(c);else if(R=d.s,R==3||R==0&&0<d.X||!(g==1&&X_(c,d)||g==2&&Sl(c)))switch(f&&0<f.length&&(d=c.h,d.i=d.i.concat(f)),R){case 1:ks(c,5);break;case 4:ks(c,10);break;case 3:ks(c,6);break;default:ks(c,2)}}}function Pf(c,d){let f=c.Ta+Math.floor(Math.random()*c.cb);return c.isActive()||(f*=2),f*d}function ks(c,d){if(c.j.info("Error code "+d),d==2){var f=m(c.fb,c),g=c.Xa;const R=!g;g=new Ts(g||"//www.google.com/images/cleardot.gif"),o.location&&o.location.protocol=="http"||Ya(g,"https"),Za(g),R?z_(g.toString(),f):G_(g.toString(),f)}else Tt(2);c.G=0,c.l&&c.l.sa(d),Rf(c),If(c)}n.fb=function(c){c?(this.j.info("Successfully pinged google.com"),Tt(2)):(this.j.info("Failed to ping google.com"),Tt(1))};function Rf(c){if(c.G=0,c.ka=[],c.l){const d=af(c.h);(d.length!=0||c.i.length!=0)&&($(c.ka,d),$(c.ka,c.i),c.h.i.length=0,N(c.i),c.i.length=0),c.l.ra()}}function $f(c,d,f){var g=f instanceof Ts?bn(f):new Ts(f);if(g.g!="")d&&(g.g=d+"."+g.g),Xa(g,g.s);else{var R=o.location;g=R.protocol,d=d?d+"."+R.hostname:R.hostname,R=+R.port;var D=new Ts(null);g&&Ya(D,g),d&&(D.g=d),R&&Xa(D,R),f&&(D.l=f),g=D}return f=c.D,d=c.ya,f&&d&&Fe(g,f,d),Fe(g,"VER",c.la),Sr(c,g),g}function Cf(c,d,f){if(d&&!c.J)throw Error("Can't create secondary domain capable XhrIo object.");return d=c.Ca&&!c.pa?new ze(new Ir({eb:f})):new ze(c.pa),d.Ha(c.J),d}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function Df(){}n=Df.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function ro(){}ro.prototype.g=function(c,d){return new Ot(c,d)};function Ot(c,d){gt.call(this),this.g=new wf(d),this.l=c,this.h=d&&d.messageUrlParams||null,c=d&&d.messageHeaders||null,d&&d.clientProtocolHeaderRequired&&(c?c["X-Client-Protocol"]="webchannel":c={"X-Client-Protocol":"webchannel"}),this.g.o=c,c=d&&d.initMessageHeaders||null,d&&d.messageContentType&&(c?c["X-WebChannel-Content-Type"]=d.messageContentType:c={"X-WebChannel-Content-Type":d.messageContentType}),d&&d.va&&(c?c["X-WebChannel-Client-Profile"]=d.va:c={"X-WebChannel-Client-Profile":d.va}),this.g.S=c,(c=d&&d.Sb)&&!J(c)&&(this.g.m=c),this.v=d&&d.supportsCrossDomainXhr||!1,this.u=d&&d.sendRawJson||!1,(d=d&&d.httpSessionIdParam)&&!J(d)&&(this.g.D=d,c=this.h,c!==null&&d in c&&(c=this.h,d in c&&delete c[d])),this.j=new oi(this)}E(Ot,gt),Ot.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},Ot.prototype.close=function(){kl(this.g)},Ot.prototype.o=function(c){var d=this.g;if(typeof c=="string"){var f={};f.__data__=c,c=f}else this.u&&(f={},f.__data__=fl(c),c=f);d.i.push(new V_(d.Ya++,c)),d.G==3&&so(d)},Ot.prototype.N=function(){this.g.l=null,delete this.j,kl(this.g),delete this.g,Ot.aa.N.call(this)};function Nf(c){ml.call(this),c.__headers__&&(this.headers=c.__headers__,this.statusCode=c.__status__,delete c.__headers__,delete c.__status__);var d=c.__sm__;if(d){e:{for(const f in d){c=f;break e}c=void 0}(this.i=c)&&(c=this.i,d=d!==null&&c in d?d[c]:void 0),this.data=d}else this.data=c}E(Nf,ml);function xf(){gl.call(this),this.status=1}E(xf,gl);function oi(c){this.g=c}E(oi,Df),oi.prototype.ua=function(){Et(this.g,"a")},oi.prototype.ta=function(c){Et(this.g,new Nf(c))},oi.prototype.sa=function(c){Et(this.g,new xf)},oi.prototype.ra=function(){Et(this.g,"b")},ro.prototype.createWebChannel=ro.prototype.g,Ot.prototype.send=Ot.prototype.o,Ot.prototype.open=Ot.prototype.m,Ot.prototype.close=Ot.prototype.close,uy=function(){return new ro},ly=function(){return Ka()},cy=Is,du={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Ha.NO_ERROR=0,Ha.TIMEOUT=8,Ha.HTTP_ERROR=6,Po=Ha,Qh.COMPLETE="complete",oy=Qh,Wh.EventType=pr,pr.OPEN="a",pr.CLOSE="b",pr.ERROR="c",pr.MESSAGE="d",gt.prototype.listen=gt.prototype.K,Mr=Wh,ay=Ir,ze.prototype.listenOnce=ze.prototype.L,ze.prototype.getLastError=ze.prototype.Ka,ze.prototype.getLastErrorCode=ze.prototype.Ba,ze.prototype.getStatus=ze.prototype.Z,ze.prototype.getResponseJson=ze.prototype.Oa,ze.prototype.getResponseText=ze.prototype.oa,ze.prototype.send=ze.prototype.ea,ze.prototype.setWithCredentials=ze.prototype.Ha,ry=ze}).apply(typeof co<"u"?co:typeof self<"u"?self:typeof window<"u"?window:{});const hp="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _t{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}_t.UNAUTHENTICATED=new _t(null),_t.GOOGLE_CREDENTIALS=new _t("google-credentials-uid"),_t.FIRST_PARTY=new _t("first-party-uid"),_t.MOCK_USER=new _t("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ir="10.12.1";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bs=new Hu("@firebase/firestore");function vi(){return Bs.logLevel}function V(n,...e){if(Bs.logLevel<=he.DEBUG){const t=e.map(ad);Bs.debug(`Firestore (${ir}): ${n}`,...t)}}function Xe(n,...e){if(Bs.logLevel<=he.ERROR){const t=e.map(ad);Bs.error(`Firestore (${ir}): ${n}`,...t)}}function ra(n,...e){if(Bs.logLevel<=he.WARN){const t=e.map(ad);Bs.warn(`Firestore (${ir}): ${n}`,...t)}}function ad(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function K(n="Unexpected state"){const e=`FIRESTORE (${ir}) INTERNAL ASSERTION FAILED: `+n;throw Xe(e),new Error(e)}function Z(n,e){n||K()}function Q(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const x={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class L extends Nn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pn{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W0{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class z0{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(_t.UNAUTHENTICATED))}shutdown(){}}class G0{constructor(e){this.t=e,this.currentUser=_t.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let s=this.i;const i=l=>this.i!==s?(s=this.i,t(l)):Promise.resolve();let r=new pn;this.o=()=>{this.i++,this.currentUser=this.u(),r.resolve(),r=new pn,e.enqueueRetryable(()=>i(this.currentUser))};const a=()=>{const l=r;e.enqueueRetryable(async()=>{await l.promise,await i(this.currentUser)})},o=l=>{V("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),a()};this.t.onInit(l=>o(l)),setTimeout(()=>{if(!this.auth){const l=this.t.getImmediate({optional:!0});l?o(l):(V("FirebaseAuthCredentialsProvider","Auth not yet detected"),r.resolve(),r=new pn)}},0),a()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(s=>this.i!==e?(V("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(Z(typeof s.accessToken=="string"),new W0(s.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const e=this.auth&&this.auth.getUid();return Z(e===null||typeof e=="string"),new _t(e)}}class K0{constructor(e,t,s){this.l=e,this.h=t,this.P=s,this.type="FirstParty",this.user=_t.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class H0{constructor(e,t,s){this.l=e,this.h=t,this.P=s}getToken(){return Promise.resolve(new K0(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(_t.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Q0{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class J0{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,t){const s=r=>{r.error!=null&&V("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${r.error.message}`);const a=r.token!==this.R;return this.R=r.token,V("FirebaseAppCheckTokenProvider",`Received ${a?"new":"existing"} token.`),a?t(r.token):Promise.resolve()};this.o=r=>{e.enqueueRetryable(()=>s(r))};const i=r=>{V("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=r,this.appCheck.addTokenListener(this.o)};this.A.onInit(r=>i(r)),setTimeout(()=>{if(!this.appCheck){const r=this.A.getImmediate({optional:!0});r?i(r):V("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(Z(typeof t.token=="string"),this.R=t.token,new Q0(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Y0(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<n;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dy{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length;let s="";for(;s.length<20;){const i=Y0(40);for(let r=0;r<i.length;++r)s.length<20&&i[r]<t&&(s+=e.charAt(i[r]%e.length))}return s}}function re(n,e){return n<e?-1:n>e?1:0}function Oi(n,e,t){return n.length===e.length&&n.every((s,i)=>t(s,e[i]))}function hy(n){return n+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Be{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new L(x.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new L(x.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800)throw new L(x.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new L(x.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return Be.fromMillis(Date.now())}static fromDate(e){return Be.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor(1e6*(e-1e3*t));return new Be(t,s)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?re(this.nanoseconds,e.nanoseconds):re(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ee{constructor(e){this.timestamp=e}static fromTimestamp(e){return new ee(e)}static min(){return new ee(new Be(0,0))}static max(){return new ee(new Be(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aa{constructor(e,t,s){t===void 0?t=0:t>e.length&&K(),s===void 0?s=e.length-t:s>e.length-t&&K(),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return aa.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof aa?e.forEach(s=>{t.push(s)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let i=0;i<s;i++){const r=e.get(i),a=t.get(i);if(r<a)return-1;if(r>a)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class ke extends aa{construct(e,t,s){return new ke(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new L(x.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter(i=>i.length>0))}return new ke(t)}static emptyPath(){return new ke([])}}const X0=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class je extends aa{construct(e,t,s){return new je(e,t,s)}static isValidIdentifier(e){return X0.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),je.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new je(["__name__"])}static fromServerFormat(e){const t=[];let s="",i=0;const r=()=>{if(s.length===0)throw new L(x.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let a=!1;for(;i<e.length;){const o=e[i];if(o==="\\"){if(i+1===e.length)throw new L(x.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const l=e[i+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new L(x.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=l,i+=2}else o==="`"?(a=!a,i++):o!=="."||a?(s+=o,i++):(r(),i++)}if(r(),a)throw new L(x.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new je(t)}static emptyPath(){return new je([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class j{constructor(e){this.path=e}static fromPath(e){return new j(ke.fromString(e))}static fromName(e){return new j(ke.fromString(e).popFirst(5))}static empty(){return new j(ke.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&ke.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return ke.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new j(new ke(e.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jo{constructor(e,t,s,i){this.indexId=e,this.collectionGroup=t,this.fields=s,this.indexState=i}}function hu(n){return n.fields.find(e=>e.kind===2)}function Ps(n){return n.fields.filter(e=>e.kind!==2)}Jo.UNKNOWN_ID=-1;class Ro{constructor(e,t){this.fieldPath=e,this.kind=t}}class oa{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new oa(0,jt.min())}}function fy(n,e){const t=n.toTimestamp().seconds,s=n.toTimestamp().nanoseconds+1,i=ee.fromTimestamp(s===1e9?new Be(t+1,0):new Be(t,s));return new jt(i,j.empty(),e)}function py(n){return new jt(n.readTime,n.key,-1)}class jt{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new jt(ee.min(),j.empty(),-1)}static max(){return new jt(ee.max(),j.empty(),-1)}}function od(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=j.comparator(n.documentKey,e.documentKey),t!==0?t:re(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const my="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class gy{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ys(n){if(n.code!==x.FAILED_PRECONDITION||n.message!==my)throw n;V("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class C{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&K(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new C((s,i)=>{this.nextCallback=r=>{this.wrapSuccess(e,r).next(s,i)},this.catchCallback=r=>{this.wrapFailure(t,r).next(s,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof C?t:C.resolve(t)}catch(t){return C.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):C.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):C.reject(t)}static resolve(e){return new C((t,s)=>{t(e)})}static reject(e){return new C((t,s)=>{s(e)})}static waitFor(e){return new C((t,s)=>{let i=0,r=0,a=!1;e.forEach(o=>{++i,o.next(()=>{++r,a&&r===i&&t()},l=>s(l))}),a=!0,r===i&&t()})}static or(e){let t=C.resolve(!1);for(const s of e)t=t.next(i=>i?C.resolve(i):s());return t}static forEach(e,t){const s=[];return e.forEach((i,r)=>{s.push(t.call(this,i,r))}),this.waitFor(s)}static mapArray(e,t){return new C((s,i)=>{const r=e.length,a=new Array(r);let o=0;for(let l=0;l<r;l++){const u=l;t(e[u]).next(h=>{a[u]=h,++o,o===r&&s(a)},h=>i(h))}})}static doWhile(e,t){return new C((s,i)=>{const r=()=>{e()===!0?t().next(()=>{r()},i):s()};r()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nc{constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.V=new pn,this.transaction.oncomplete=()=>{this.V.resolve()},this.transaction.onabort=()=>{t.error?this.V.reject(new Br(e,t.error)):this.V.resolve()},this.transaction.onerror=s=>{const i=cd(s.target.error);this.V.reject(new Br(e,i))}}static open(e,t,s,i){try{return new Nc(t,e.transaction(i,s))}catch(r){throw new Br(t,r)}}get m(){return this.V.promise}abort(e){e&&this.V.reject(e),this.aborted||(V("SimpleDb","Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}g(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new eT(t)}}class is{constructor(e,t,s){this.name=e,this.version=t,this.p=s,is.S(et())===12.2&&Xe("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(e){return V("SimpleDb","Removing database:",e),Rs(window.indexedDB.deleteDatabase(e)).toPromise()}static D(){if(!_g())return!1;if(is.C())return!0;const e=et(),t=is.S(e),s=0<t&&t<10,i=yy(e),r=0<i&&i<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||s||r)}static C(){var e;return typeof process<"u"&&((e=process.__PRIVATE_env)===null||e===void 0?void 0:e.v)==="YES"}static F(e,t){return e.store(t)}static S(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),s=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(s)}async M(e){return this.db||(V("SimpleDb","Opening database:",this.name),this.db=await new Promise((t,s)=>{const i=indexedDB.open(this.name,this.version);i.onsuccess=r=>{const a=r.target.result;t(a)},i.onblocked=()=>{s(new Br(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},i.onerror=r=>{const a=r.target.error;a.name==="VersionError"?s(new L(x.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):a.name==="InvalidStateError"?s(new L(x.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+a)):s(new Br(e,a))},i.onupgradeneeded=r=>{V("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',r.oldVersion);const a=r.target.result;this.p.O(a,i.transaction,r.oldVersion,this.version).next(()=>{V("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.N&&(this.db.onversionchange=t=>this.N(t)),this.db}L(e){this.N=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,s,i){const r=t==="readonly";let a=0;for(;;){++a;try{this.db=await this.M(e);const o=Nc.open(this.db,e,r?"readonly":"readwrite",s),l=i(o).next(u=>(o.g(),u)).catch(u=>(o.abort(u),C.reject(u))).toPromise();return l.catch(()=>{}),await o.m,l}catch(o){const l=o,u=l.name!=="FirebaseError"&&a<3;if(V("SimpleDb","Transaction failed with error:",l.message,"Retrying:",u),this.close(),!u)return Promise.reject(l)}}}close(){this.db&&this.db.close(),this.db=void 0}}function yy(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class Z0{constructor(e){this.B=e,this.k=!1,this.q=null}get isDone(){return this.k}get K(){return this.q}set cursor(e){this.B=e}done(){this.k=!0}$(e){this.q=e}delete(){return Rs(this.B.delete())}}class Br extends L{constructor(e,t){super(x.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function vs(n){return n.name==="IndexedDbTransactionError"}class eT{constructor(e){this.store=e}put(e,t){let s;return t!==void 0?(V("SimpleDb","PUT",this.store.name,e,t),s=this.store.put(t,e)):(V("SimpleDb","PUT",this.store.name,"<auto-key>",e),s=this.store.put(e)),Rs(s)}add(e){return V("SimpleDb","ADD",this.store.name,e,e),Rs(this.store.add(e))}get(e){return Rs(this.store.get(e)).next(t=>(t===void 0&&(t=null),V("SimpleDb","GET",this.store.name,e,t),t))}delete(e){return V("SimpleDb","DELETE",this.store.name,e),Rs(this.store.delete(e))}count(){return V("SimpleDb","COUNT",this.store.name),Rs(this.store.count())}U(e,t){const s=this.options(e,t),i=s.index?this.store.index(s.index):this.store;if(typeof i.getAll=="function"){const r=i.getAll(s.range);return new C((a,o)=>{r.onerror=l=>{o(l.target.error)},r.onsuccess=l=>{a(l.target.result)}})}{const r=this.cursor(s),a=[];return this.W(r,(o,l)=>{a.push(l)}).next(()=>a)}}G(e,t){const s=this.store.getAll(e,t===null?void 0:t);return new C((i,r)=>{s.onerror=a=>{r(a.target.error)},s.onsuccess=a=>{i(a.target.result)}})}j(e,t){V("SimpleDb","DELETE ALL",this.store.name);const s=this.options(e,t);s.H=!1;const i=this.cursor(s);return this.W(i,(r,a,o)=>o.delete())}J(e,t){let s;t?s=e:(s={},t=e);const i=this.cursor(s);return this.W(i,t)}Y(e){const t=this.cursor({});return new C((s,i)=>{t.onerror=r=>{const a=cd(r.target.error);i(a)},t.onsuccess=r=>{const a=r.target.result;a?e(a.primaryKey,a.value).next(o=>{o?a.continue():s()}):s()}})}W(e,t){const s=[];return new C((i,r)=>{e.onerror=a=>{r(a.target.error)},e.onsuccess=a=>{const o=a.target.result;if(!o)return void i();const l=new Z0(o),u=t(o.primaryKey,o.value,l);if(u instanceof C){const h=u.catch(p=>(l.done(),C.reject(p)));s.push(h)}l.isDone?i():l.K===null?o.continue():o.continue(l.K)}}).next(()=>C.waitFor(s))}options(e,t){let s;return e!==void 0&&(typeof e=="string"?s=e:t=e),{index:s,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const s=this.store.index(e.index);return e.H?s.openKeyCursor(e.range,t):s.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function Rs(n){return new C((e,t)=>{n.onsuccess=s=>{const i=s.target.result;e(i)},n.onerror=s=>{const i=cd(s.target.error);t(i)}})}let fp=!1;function cd(n){const e=is.S(et());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(n.message.indexOf(t)>=0){const s=new L("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return fp||(fp=!0,setTimeout(()=>{throw s},0)),s}}return n}class tT{constructor(e,t){this.asyncQueue=e,this.Z=t,this.task=null}start(){this.X(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}X(e){V("IndexBackfiller",`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,async()=>{this.task=null;try{V("IndexBackfiller",`Documents written: ${await this.Z.ee()}`)}catch(t){vs(t)?V("IndexBackfiller","Ignoring IndexedDB error during index backfill: ",t):await ys(t)}await this.X(6e4)})}}class nT{constructor(e,t){this.localStore=e,this.persistence=t}async ee(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",t=>this.te(t,e))}te(e,t){const s=new Set;let i=t,r=!0;return C.doWhile(()=>r===!0&&i>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next(a=>{if(a!==null&&!s.has(a))return V("IndexBackfiller",`Processing collection: ${a}`),this.ne(e,a,i).next(o=>{i-=o,s.add(a)});r=!1})).next(()=>t-i)}ne(e,t,s){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next(i=>this.localStore.localDocuments.getNextDocuments(e,t,i,s).next(r=>{const a=r.changes;return this.localStore.indexManager.updateIndexEntries(e,a).next(()=>this.re(i,r)).next(o=>(V("IndexBackfiller",`Updating offset: ${o}`),this.localStore.indexManager.updateCollectionGroup(e,t,o))).next(()=>a.size)}))}re(e,t){let s=e;return t.changes.forEach((i,r)=>{const a=py(r);od(a,s)>0&&(s=a)}),new jt(s.readTime,s.documentKey,Math.max(t.batchId,e.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nt{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.ie(s),this.se=s=>t.writeSequenceNumber(s))}ie(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.se&&this.se(e),e}}Nt.oe=-1;function xc(n){return n==null}function ca(n){return n===0&&1/n==-1/0}function vy(n){return typeof n=="number"&&Number.isInteger(n)&&!ca(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function At(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=pp(e)),e=sT(n.get(t),e);return pp(e)}function sT(n,e){let t=e;const s=n.length;for(let i=0;i<s;i++){const r=n.charAt(i);switch(r){case"\0":t+="";break;case"":t+="";break;default:t+=r}}return t}function pp(n){return n+""}function on(n){const e=n.length;if(Z(e>=2),e===2)return Z(n.charAt(0)===""&&n.charAt(1)===""),ke.emptyPath();const t=e-2,s=[];let i="";for(let r=0;r<e;){const a=n.indexOf("",r);switch((a<0||a>t)&&K(),n.charAt(a+1)){case"":const o=n.substring(r,a);let l;i.length===0?l=o:(i+=o,l=i,i=""),s.push(l);break;case"":i+=n.substring(r,a),i+="\0";break;case"":i+=n.substring(r,a+1);break;default:K()}r=a+2}return new ke(s)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mp=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $o(n,e){return[n,At(e)]}function by(n,e,t){return[n,At(e),t]}const iT={},rT=["prefixPath","collectionGroup","readTime","documentId"],aT=["prefixPath","collectionGroup","documentId"],oT=["collectionGroup","readTime","prefixPath","documentId"],cT=["canonicalId","targetId"],lT=["targetId","path"],uT=["path","targetId"],dT=["collectionId","parent"],hT=["indexId","uid"],fT=["uid","sequenceNumber"],pT=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],mT=["indexId","uid","orderedDocumentKey"],gT=["userId","collectionPath","documentId"],yT=["userId","collectionPath","largestBatchId"],vT=["userId","collectionGroup","largestBatchId"],_y=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],bT=[..._y,"documentOverlays"],wy=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],Iy=wy,Ey=[...Iy,"indexConfiguration","indexState","indexEntries"],_T=Ey;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fu extends gy{constructor(e,t){super(),this._e=e,this.currentSequenceNumber=t}}function lt(n,e){const t=Q(n);return is.F(t._e,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gp(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function ei(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function Ty(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(e,t){this.comparator=e,this.root=t||ft.EMPTY}insert(e,t){return new Le(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,ft.BLACK,null,null))}remove(e){return new Le(this.comparator,this.root.remove(e,this.comparator).copy(null,null,ft.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const i=this.comparator(e,s.key);if(i===0)return t+s.left.size;i<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,s)=>(e(t,s),!1))}toString(){const e=[];return this.inorderTraversal((t,s)=>(e.push(`${t}:${s}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new lo(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new lo(this.root,e,this.comparator,!1)}getReverseIterator(){return new lo(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new lo(this.root,e,this.comparator,!0)}}class lo{constructor(e,t,s,i){this.isReverse=i,this.nodeStack=[];let r=1;for(;!e.isEmpty();)if(r=t?s(e.key,t):1,t&&i&&(r*=-1),r<0)e=this.isReverse?e.left:e.right;else{if(r===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class ft{constructor(e,t,s,i,r){this.key=e,this.value=t,this.color=s??ft.RED,this.left=i??ft.EMPTY,this.right=r??ft.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,i,r){return new ft(e??this.key,t??this.value,s??this.color,i??this.left,r??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let i=this;const r=s(e,i.key);return i=r<0?i.copy(null,null,null,i.left.insert(e,t,s),null):r===0?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,s)),i.fixUp()}removeMin(){if(this.left.isEmpty())return ft.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,i=this;if(t(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),t(e,i.key)===0){if(i.right.isEmpty())return ft.EMPTY;s=i.right.min(),i=i.copy(s.key,s.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,ft.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,ft.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw K();const e=this.left.check();if(e!==this.right.check())throw K();return e+(this.isRed()?0:1)}}ft.EMPTY=null,ft.RED=!0,ft.BLACK=!1;ft.EMPTY=new class{constructor(){this.size=0}get key(){throw K()}get value(){throw K()}get color(){throw K()}get left(){throw K()}get right(){throw K()}copy(e,t,s,i,r){return this}insert(e,t,s){return new ft(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class De{constructor(e){this.comparator=e,this.data=new Le(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,s)=>(e(t),!1))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const i=s.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new yp(this.data.getIterator())}getIteratorFrom(e){return new yp(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(s=>{t=t.add(s)}),t}isEqual(e){if(!(e instanceof De)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const i=t.getNext().key,r=s.getNext().key;if(this.comparator(i,r)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new De(this.comparator);return t.data=e,t}}class yp{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function li(n){return n.hasNext()?n.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xt{constructor(e){this.fields=e,e.sort(je.comparator)}static empty(){return new xt([])}unionWith(e){let t=new De(je.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new xt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return Oi(this.fields,e.fields,(t,s)=>t.isEqual(s))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ky extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ct{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(i){try{return atob(i)}catch(r){throw typeof DOMException<"u"&&r instanceof DOMException?new ky("Invalid base64 string: "+r):r}}(e);return new ct(t)}static fromUint8Array(e){const t=function(i){let r="";for(let a=0;a<i.length;++a)r+=String.fromCharCode(i[a]);return r}(e);return new ct(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const s=new Uint8Array(t.length);for(let i=0;i<t.length;i++)s[i]=t.charCodeAt(i);return s}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return re(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}ct.EMPTY_BYTE_STRING=new ct("");const wT=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Dn(n){if(Z(!!n),typeof n=="string"){let e=0;const t=wT.exec(n);if(Z(!!t),t[1]){let i=t[1];i=(i+"000000000").substr(0,9),e=Number(i)}const s=new Date(n);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:Ke(n.seconds),nanos:Ke(n.nanos)}}function Ke(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function us(n){return typeof n=="string"?ct.fromBase64String(n):ct.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ld(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{}).__type__)===null||t===void 0?void 0:t.stringValue)==="server_timestamp"}function ud(n){const e=n.mapValue.fields.__previous_value__;return ld(e)?ud(e):e}function la(n){const e=Dn(n.mapValue.fields.__local_write_time__.timestampValue);return new Be(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IT{constructor(e,t,s,i,r,a,o,l,u){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=i,this.ssl=r,this.forceLongPolling=a,this.autoDetectLongPolling=o,this.longPollingOptions=l,this.useFetchStreams=u}}class Ws{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new Ws("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof Ws&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xn={mapValue:{fields:{__type__:{stringValue:"__max__"}}}},Co={nullValue:"NULL_VALUE"};function zs(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?ld(n)?4:Sy(n)?9007199254740991:10:K()}function gn(n,e){if(n===e)return!0;const t=zs(n);if(t!==zs(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return la(n).isEqual(la(e));case 3:return function(i,r){if(typeof i.timestampValue=="string"&&typeof r.timestampValue=="string"&&i.timestampValue.length===r.timestampValue.length)return i.timestampValue===r.timestampValue;const a=Dn(i.timestampValue),o=Dn(r.timestampValue);return a.seconds===o.seconds&&a.nanos===o.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,r){return us(i.bytesValue).isEqual(us(r.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,r){return Ke(i.geoPointValue.latitude)===Ke(r.geoPointValue.latitude)&&Ke(i.geoPointValue.longitude)===Ke(r.geoPointValue.longitude)}(n,e);case 2:return function(i,r){if("integerValue"in i&&"integerValue"in r)return Ke(i.integerValue)===Ke(r.integerValue);if("doubleValue"in i&&"doubleValue"in r){const a=Ke(i.doubleValue),o=Ke(r.doubleValue);return a===o?ca(a)===ca(o):isNaN(a)&&isNaN(o)}return!1}(n,e);case 9:return Oi(n.arrayValue.values||[],e.arrayValue.values||[],gn);case 10:return function(i,r){const a=i.mapValue.fields||{},o=r.mapValue.fields||{};if(gp(a)!==gp(o))return!1;for(const l in a)if(a.hasOwnProperty(l)&&(o[l]===void 0||!gn(a[l],o[l])))return!1;return!0}(n,e);default:return K()}}function ua(n,e){return(n.values||[]).find(t=>gn(t,e))!==void 0}function ds(n,e){if(n===e)return 0;const t=zs(n),s=zs(e);if(t!==s)return re(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return re(n.booleanValue,e.booleanValue);case 2:return function(r,a){const o=Ke(r.integerValue||r.doubleValue),l=Ke(a.integerValue||a.doubleValue);return o<l?-1:o>l?1:o===l?0:isNaN(o)?isNaN(l)?0:-1:1}(n,e);case 3:return vp(n.timestampValue,e.timestampValue);case 4:return vp(la(n),la(e));case 5:return re(n.stringValue,e.stringValue);case 6:return function(r,a){const o=us(r),l=us(a);return o.compareTo(l)}(n.bytesValue,e.bytesValue);case 7:return function(r,a){const o=r.split("/"),l=a.split("/");for(let u=0;u<o.length&&u<l.length;u++){const h=re(o[u],l[u]);if(h!==0)return h}return re(o.length,l.length)}(n.referenceValue,e.referenceValue);case 8:return function(r,a){const o=re(Ke(r.latitude),Ke(a.latitude));return o!==0?o:re(Ke(r.longitude),Ke(a.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return function(r,a){const o=r.values||[],l=a.values||[];for(let u=0;u<o.length&&u<l.length;++u){const h=ds(o[u],l[u]);if(h)return h}return re(o.length,l.length)}(n.arrayValue,e.arrayValue);case 10:return function(r,a){if(r===Xn.mapValue&&a===Xn.mapValue)return 0;if(r===Xn.mapValue)return 1;if(a===Xn.mapValue)return-1;const o=r.fields||{},l=Object.keys(o),u=a.fields||{},h=Object.keys(u);l.sort(),h.sort();for(let p=0;p<l.length&&p<h.length;++p){const m=re(l[p],h[p]);if(m!==0)return m;const w=ds(o[l[p]],u[h[p]]);if(w!==0)return w}return re(l.length,h.length)}(n.mapValue,e.mapValue);default:throw K()}}function vp(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return re(n,e);const t=Dn(n),s=Dn(e),i=re(t.seconds,s.seconds);return i!==0?i:re(t.nanos,s.nanos)}function Mi(n){return pu(n)}function pu(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const s=Dn(t);return`time(${s.seconds},${s.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return us(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return j.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let s="[",i=!0;for(const r of t.values||[])i?i=!1:s+=",",s+=pu(r);return s+"]"}(n.arrayValue):"mapValue"in n?function(t){const s=Object.keys(t.fields||{}).sort();let i="{",r=!0;for(const a of s)r?r=!1:i+=",",i+=`${a}:${pu(t.fields[a])}`;return i+"}"}(n.mapValue):K()}function da(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function mu(n){return!!n&&"integerValue"in n}function ha(n){return!!n&&"arrayValue"in n}function bp(n){return!!n&&"nullValue"in n}function _p(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function Do(n){return!!n&&"mapValue"in n}function Wr(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const e={mapValue:{fields:{}}};return ei(n.mapValue.fields,(t,s)=>e.mapValue.fields[t]=Wr(s)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=Wr(n.arrayValue.values[t]);return e}return Object.assign({},n)}function Sy(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}function ET(n){return"nullValue"in n?Co:"booleanValue"in n?{booleanValue:!1}:"integerValue"in n||"doubleValue"in n?{doubleValue:NaN}:"timestampValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in n?{stringValue:""}:"bytesValue"in n?{bytesValue:""}:"referenceValue"in n?da(Ws.empty(),j.empty()):"geoPointValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in n?{arrayValue:{}}:"mapValue"in n?{mapValue:{}}:K()}function TT(n){return"nullValue"in n?{booleanValue:!1}:"booleanValue"in n?{doubleValue:NaN}:"integerValue"in n||"doubleValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in n?{stringValue:""}:"stringValue"in n?{bytesValue:""}:"bytesValue"in n?da(Ws.empty(),j.empty()):"referenceValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in n?{arrayValue:{}}:"arrayValue"in n?{mapValue:{}}:"mapValue"in n?Xn:K()}function wp(n,e){const t=ds(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?-1:!n.inclusive&&e.inclusive?1:0}function Ip(n,e){const t=ds(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?1:!n.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(e){this.value=e}static empty(){return new wt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!Do(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Wr(t)}setAll(e){let t=je.emptyPath(),s={},i=[];e.forEach((a,o)=>{if(!t.isImmediateParentOf(o)){const l=this.getFieldsMap(t);this.applyChanges(l,s,i),s={},i=[],t=o.popLast()}a?s[o.lastSegment()]=Wr(a):i.push(o.lastSegment())});const r=this.getFieldsMap(t);this.applyChanges(r,s,i)}delete(e){const t=this.field(e.popLast());Do(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return gn(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let i=t.mapValue.fields[e.get(s)];Do(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,s){ei(t,(i,r)=>e[i]=r);for(const i of s)delete e[i]}clone(){return new wt(Wr(this.value))}}function Ay(n){const e=[];return ei(n.fields,(t,s)=>{const i=new je([t]);if(Do(s)){const r=Ay(s.mapValue).fields;if(r.length===0)e.push(i);else for(const a of r)e.push(i.child(a))}else e.push(i)}),new xt(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class He{constructor(e,t,s,i,r,a,o){this.key=e,this.documentType=t,this.version=s,this.readTime=i,this.createTime=r,this.data=a,this.documentState=o}static newInvalidDocument(e){return new He(e,0,ee.min(),ee.min(),ee.min(),wt.empty(),0)}static newFoundDocument(e,t,s,i){return new He(e,1,t,ee.min(),s,i,0)}static newNoDocument(e,t){return new He(e,2,t,ee.min(),ee.min(),wt.empty(),0)}static newUnknownDocument(e,t){return new He(e,3,t,ee.min(),ee.min(),wt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ee.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=wt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=wt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ee.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof He&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new He(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Li{constructor(e,t){this.position=e,this.inclusive=t}}function Ep(n,e,t){let s=0;for(let i=0;i<n.position.length;i++){const r=e[i],a=n.position[i];if(r.field.isKeyField()?s=j.comparator(j.fromName(a.referenceValue),t.key):s=ds(a,t.data.field(r.field)),r.dir==="desc"&&(s*=-1),s!==0)break}return s}function Tp(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!gn(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fa{constructor(e,t="asc"){this.field=e,this.dir=t}}function kT(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Py{}class fe extends Py{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new ST(e,t,s):t==="array-contains"?new RT(e,s):t==="in"?new xy(e,s):t==="not-in"?new $T(e,s):t==="array-contains-any"?new CT(e,s):new fe(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new AT(e,s):new PT(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&this.matchesComparison(ds(t,this.value)):t!==null&&zs(this.value)===zs(t)&&this.matchesComparison(ds(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return K()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Pe extends Py{constructor(e,t){super(),this.filters=e,this.op=t,this.ae=null}static create(e,t){return new Pe(e,t)}matches(e){return Fi(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.ae!==null||(this.ae=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ae}getFilters(){return Object.assign([],this.filters)}}function Fi(n){return n.op==="and"}function gu(n){return n.op==="or"}function dd(n){return Ry(n)&&Fi(n)}function Ry(n){for(const e of n.filters)if(e instanceof Pe)return!1;return!0}function yu(n){if(n instanceof fe)return n.field.canonicalString()+n.op.toString()+Mi(n.value);if(dd(n))return n.filters.map(e=>yu(e)).join(",");{const e=n.filters.map(t=>yu(t)).join(",");return`${n.op}(${e})`}}function $y(n,e){return n instanceof fe?function(s,i){return i instanceof fe&&s.op===i.op&&s.field.isEqual(i.field)&&gn(s.value,i.value)}(n,e):n instanceof Pe?function(s,i){return i instanceof Pe&&s.op===i.op&&s.filters.length===i.filters.length?s.filters.reduce((r,a,o)=>r&&$y(a,i.filters[o]),!0):!1}(n,e):void K()}function Cy(n,e){const t=n.filters.concat(e);return Pe.create(t,n.op)}function Dy(n){return n instanceof fe?function(t){return`${t.field.canonicalString()} ${t.op} ${Mi(t.value)}`}(n):n instanceof Pe?function(t){return t.op.toString()+" {"+t.getFilters().map(Dy).join(" ,")+"}"}(n):"Filter"}class ST extends fe{constructor(e,t,s){super(e,t,s),this.key=j.fromName(s.referenceValue)}matches(e){const t=j.comparator(e.key,this.key);return this.matchesComparison(t)}}class AT extends fe{constructor(e,t){super(e,"in",t),this.keys=Ny("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class PT extends fe{constructor(e,t){super(e,"not-in",t),this.keys=Ny("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function Ny(n,e){var t;return(((t=e.arrayValue)===null||t===void 0?void 0:t.values)||[]).map(s=>j.fromName(s.referenceValue))}class RT extends fe{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return ha(t)&&ua(t.arrayValue,this.value)}}class xy extends fe{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&ua(this.value.arrayValue,t)}}class $T extends fe{constructor(e,t){super(e,"not-in",t)}matches(e){if(ua(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&!ua(this.value.arrayValue,t)}}class CT extends fe{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!ha(t)||!t.arrayValue.values)&&t.arrayValue.values.some(s=>ua(this.value.arrayValue,s))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class DT{constructor(e,t=null,s=[],i=[],r=null,a=null,o=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=i,this.limit=r,this.startAt=a,this.endAt=o,this.ue=null}}function vu(n,e=null,t=[],s=[],i=null,r=null,a=null){return new DT(n,e,t,s,i,r,a)}function Gs(n){const e=Q(n);if(e.ue===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(s=>yu(s)).join(","),t+="|ob:",t+=e.orderBy.map(s=>function(r){return r.field.canonicalString()+r.dir}(s)).join(","),xc(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(s=>Mi(s)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(s=>Mi(s)).join(",")),e.ue=t}return e.ue}function Ca(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!kT(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!$y(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Tp(n.startAt,e.startAt)&&Tp(n.endAt,e.endAt)}function Yo(n){return j.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function Xo(n,e){return n.filters.filter(t=>t instanceof fe&&t.field.isEqual(e))}function kp(n,e,t){let s=Co,i=!0;for(const r of Xo(n,e)){let a=Co,o=!0;switch(r.op){case"<":case"<=":a=ET(r.value);break;case"==":case"in":case">=":a=r.value;break;case">":a=r.value,o=!1;break;case"!=":case"not-in":a=Co}wp({value:s,inclusive:i},{value:a,inclusive:o})<0&&(s=a,i=o)}if(t!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(e)){const a=t.position[r];wp({value:s,inclusive:i},{value:a,inclusive:t.inclusive})<0&&(s=a,i=t.inclusive);break}}return{value:s,inclusive:i}}function Sp(n,e,t){let s=Xn,i=!0;for(const r of Xo(n,e)){let a=Xn,o=!0;switch(r.op){case">=":case">":a=TT(r.value),o=!1;break;case"==":case"in":case"<=":a=r.value;break;case"<":a=r.value,o=!1;break;case"!=":case"not-in":a=Xn}Ip({value:s,inclusive:i},{value:a,inclusive:o})>0&&(s=a,i=o)}if(t!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(e)){const a=t.position[r];Ip({value:s,inclusive:i},{value:a,inclusive:t.inclusive})>0&&(s=a,i=t.inclusive);break}}return{value:s,inclusive:i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rr{constructor(e,t=null,s=[],i=[],r=null,a="F",o=null,l=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=i,this.limit=r,this.limitType=a,this.startAt=o,this.endAt=l,this.ce=null,this.le=null,this.he=null,this.startAt,this.endAt}}function Vy(n,e,t,s,i,r,a,o){return new rr(n,e,t,s,i,r,a,o)}function Da(n){return new rr(n)}function Ap(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function Oy(n){return n.collectionGroup!==null}function zr(n){const e=Q(n);if(e.ce===null){e.ce=[];const t=new Set;for(const r of e.explicitOrderBy)e.ce.push(r),t.add(r.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(a){let o=new De(je.comparator);return a.filters.forEach(l=>{l.getFlattenedFilters().forEach(u=>{u.isInequality()&&(o=o.add(u.field))})}),o})(e).forEach(r=>{t.has(r.canonicalString())||r.isKeyField()||e.ce.push(new fa(r,s))}),t.has(je.keyField().canonicalString())||e.ce.push(new fa(je.keyField(),s))}return e.ce}function Ut(n){const e=Q(n);return e.le||(e.le=NT(e,zr(n))),e.le}function NT(n,e){if(n.limitType==="F")return vu(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(i=>{const r=i.dir==="desc"?"asc":"desc";return new fa(i.field,r)});const t=n.endAt?new Li(n.endAt.position,n.endAt.inclusive):null,s=n.startAt?new Li(n.startAt.position,n.startAt.inclusive):null;return vu(n.path,n.collectionGroup,e,n.filters,n.limit,t,s)}}function bu(n,e){const t=n.filters.concat([e]);return new rr(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function Zo(n,e,t){return new rr(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function Vc(n,e){return Ca(Ut(n),Ut(e))&&n.limitType===e.limitType}function My(n){return`${Gs(Ut(n))}|lt:${n.limitType}`}function bi(n){return`Query(target=${function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map(i=>Dy(i)).join(", ")}]`),xc(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map(i=>function(a){return`${a.field.canonicalString()} (${a.dir})`}(i)).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map(i=>Mi(i)).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map(i=>Mi(i)).join(",")),`Target(${s})`}(Ut(n))}; limitType=${n.limitType})`}function Na(n,e){return e.isFoundDocument()&&function(s,i){const r=i.key.path;return s.collectionGroup!==null?i.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(r):j.isDocumentKey(s.path)?s.path.isEqual(r):s.path.isImmediateParentOf(r)}(n,e)&&function(s,i){for(const r of zr(s))if(!r.field.isKeyField()&&i.data.field(r.field)===null)return!1;return!0}(n,e)&&function(s,i){for(const r of s.filters)if(!r.matches(i))return!1;return!0}(n,e)&&function(s,i){return!(s.startAt&&!function(a,o,l){const u=Ep(a,o,l);return a.inclusive?u<=0:u<0}(s.startAt,zr(s),i)||s.endAt&&!function(a,o,l){const u=Ep(a,o,l);return a.inclusive?u>=0:u>0}(s.endAt,zr(s),i))}(n,e)}function Ly(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Fy(n){return(e,t)=>{let s=!1;for(const i of zr(n)){const r=xT(i,e,t);if(r!==0)return r;s=s||i.field.isKeyField()}return 0}}function xT(n,e,t){const s=n.field.isKeyField()?j.comparator(e.key,t.key):function(r,a,o){const l=a.data.field(r),u=o.data.field(r);return l!==null&&u!==null?ds(l,u):K()}(n.field,e,t);switch(n.dir){case"asc":return s;case"desc":return-1*s;default:return K()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bs{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[i,r]of s)if(this.equalsFn(i,e))return r}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),i=this.inner[s];if(i===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let r=0;r<i.length;r++)if(this.equalsFn(i[r][0],e))return void(i[r]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return s.length===1?delete this.inner[t]:s.splice(i,1),this.innerSize--,!0;return!1}forEach(e){ei(this.inner,(t,s)=>{for(const[i,r]of s)e(i,r)})}isEmpty(){return Ty(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VT=new Le(j.comparator);function Ft(){return VT}const Uy=new Le(j.comparator);function Lr(...n){let e=Uy;for(const t of n)e=e.insert(t.key,t);return e}function qy(n){let e=Uy;return n.forEach((t,s)=>e=e.insert(t,s.overlayedDocument)),e}function cn(){return Gr()}function jy(){return Gr()}function Gr(){return new bs(n=>n.toString(),(n,e)=>n.isEqual(e))}const OT=new Le(j.comparator),MT=new De(j.comparator);function le(...n){let e=MT;for(const t of n)e=e.add(t);return e}const LT=new De(re);function hd(){return LT}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function By(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:ca(e)?"-0":e}}function Wy(n){return{integerValue:""+n}}function FT(n,e){return vy(e)?Wy(e):By(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oc{constructor(){this._=void 0}}function UT(n,e,t){return n instanceof pa?function(i,r){const a={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return r&&ld(r)&&(r=ud(r)),r&&(a.fields.__previous_value__=r),{mapValue:a}}(t,e):n instanceof Ui?Gy(n,e):n instanceof qi?Ky(n,e):function(i,r){const a=zy(i,r),o=Pp(a)+Pp(i.Pe);return mu(a)&&mu(i.Pe)?Wy(o):By(i.serializer,o)}(n,e)}function qT(n,e,t){return n instanceof Ui?Gy(n,e):n instanceof qi?Ky(n,e):t}function zy(n,e){return n instanceof ma?function(s){return mu(s)||function(r){return!!r&&"doubleValue"in r}(s)}(e)?e:{integerValue:0}:null}class pa extends Oc{}class Ui extends Oc{constructor(e){super(),this.elements=e}}function Gy(n,e){const t=Hy(e);for(const s of n.elements)t.some(i=>gn(i,s))||t.push(s);return{arrayValue:{values:t}}}class qi extends Oc{constructor(e){super(),this.elements=e}}function Ky(n,e){let t=Hy(e);for(const s of n.elements)t=t.filter(i=>!gn(i,s));return{arrayValue:{values:t}}}class ma extends Oc{constructor(e,t){super(),this.serializer=e,this.Pe=t}}function Pp(n){return Ke(n.integerValue||n.doubleValue)}function Hy(n){return ha(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jT{constructor(e,t){this.field=e,this.transform=t}}function BT(n,e){return n.field.isEqual(e.field)&&function(s,i){return s instanceof Ui&&i instanceof Ui||s instanceof qi&&i instanceof qi?Oi(s.elements,i.elements,gn):s instanceof ma&&i instanceof ma?gn(s.Pe,i.Pe):s instanceof pa&&i instanceof pa}(n.transform,e.transform)}class WT{constructor(e,t){this.version=e,this.transformResults=t}}class St{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new St}static exists(e){return new St(void 0,e)}static updateTime(e){return new St(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function No(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class Mc{}function Qy(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new Lc(n.key,St.none()):new ar(n.key,n.data,St.none());{const t=n.data,s=wt.empty();let i=new De(je.comparator);for(let r of e.fields)if(!i.has(r)){let a=t.field(r);a===null&&r.length>1&&(r=r.popLast(),a=t.field(r)),a===null?s.delete(r):s.set(r,a),i=i.add(r)}return new xn(n.key,s,new xt(i.toArray()),St.none())}}function zT(n,e,t){n instanceof ar?function(i,r,a){const o=i.value.clone(),l=$p(i.fieldTransforms,r,a.transformResults);o.setAll(l),r.convertToFoundDocument(a.version,o).setHasCommittedMutations()}(n,e,t):n instanceof xn?function(i,r,a){if(!No(i.precondition,r))return void r.convertToUnknownDocument(a.version);const o=$p(i.fieldTransforms,r,a.transformResults),l=r.data;l.setAll(Jy(i)),l.setAll(o),r.convertToFoundDocument(a.version,l).setHasCommittedMutations()}(n,e,t):function(i,r,a){r.convertToNoDocument(a.version).setHasCommittedMutations()}(0,e,t)}function Kr(n,e,t,s){return n instanceof ar?function(r,a,o,l){if(!No(r.precondition,a))return o;const u=r.value.clone(),h=Cp(r.fieldTransforms,l,a);return u.setAll(h),a.convertToFoundDocument(a.version,u).setHasLocalMutations(),null}(n,e,t,s):n instanceof xn?function(r,a,o,l){if(!No(r.precondition,a))return o;const u=Cp(r.fieldTransforms,l,a),h=a.data;return h.setAll(Jy(r)),h.setAll(u),a.convertToFoundDocument(a.version,h).setHasLocalMutations(),o===null?null:o.unionWith(r.fieldMask.fields).unionWith(r.fieldTransforms.map(p=>p.field))}(n,e,t,s):function(r,a,o){return No(r.precondition,a)?(a.convertToNoDocument(a.version).setHasLocalMutations(),null):o}(n,e,t)}function GT(n,e){let t=null;for(const s of n.fieldTransforms){const i=e.data.field(s.field),r=zy(s.transform,i||null);r!=null&&(t===null&&(t=wt.empty()),t.set(s.field,r))}return t||null}function Rp(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(s,i){return s===void 0&&i===void 0||!(!s||!i)&&Oi(s,i,(r,a)=>BT(r,a))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class ar extends Mc{constructor(e,t,s,i=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class xn extends Mc{constructor(e,t,s,i,r=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=i,this.fieldTransforms=r,this.type=1}getFieldMask(){return this.fieldMask}}function Jy(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const s=n.data.field(t);e.set(t,s)}}),e}function $p(n,e,t){const s=new Map;Z(n.length===t.length);for(let i=0;i<t.length;i++){const r=n[i],a=r.transform,o=e.data.field(r.field);s.set(r.field,qT(a,o,t[i]))}return s}function Cp(n,e,t){const s=new Map;for(const i of n){const r=i.transform,a=t.data.field(i.field);s.set(i.field,UT(r,a,e))}return s}class Lc extends Mc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Yy extends Mc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fd{constructor(e,t,s,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=i}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let i=0;i<this.mutations.length;i++){const r=this.mutations[i];r.key.isEqual(e.key)&&zT(r,e,s[i])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=Kr(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=Kr(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=jy();return this.mutations.forEach(i=>{const r=e.get(i.key),a=r.overlayedDocument;let o=this.applyToLocalView(a,r.mutatedFields);o=t.has(i.key)?null:o;const l=Qy(a,o);l!==null&&s.set(i.key,l),a.isValidDocument()||a.convertToNoDocument(ee.min())}),s}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),le())}isEqual(e){return this.batchId===e.batchId&&Oi(this.mutations,e.mutations,(t,s)=>Rp(t,s))&&Oi(this.baseMutations,e.baseMutations,(t,s)=>Rp(t,s))}}class pd{constructor(e,t,s,i){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=i}static from(e,t,s){Z(e.mutations.length===s.length);let i=function(){return OT}();const r=e.mutations;for(let a=0;a<r.length;a++)i=i.insert(r[a].key,s[a].version);return new pd(e,t,s,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class md{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KT{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ze,me;function HT(n){switch(n){default:return K();case x.CANCELLED:case x.UNKNOWN:case x.DEADLINE_EXCEEDED:case x.RESOURCE_EXHAUSTED:case x.INTERNAL:case x.UNAVAILABLE:case x.UNAUTHENTICATED:return!1;case x.INVALID_ARGUMENT:case x.NOT_FOUND:case x.ALREADY_EXISTS:case x.PERMISSION_DENIED:case x.FAILED_PRECONDITION:case x.ABORTED:case x.OUT_OF_RANGE:case x.UNIMPLEMENTED:case x.DATA_LOSS:return!0}}function Xy(n){if(n===void 0)return Xe("GRPC error has no .code"),x.UNKNOWN;switch(n){case Ze.OK:return x.OK;case Ze.CANCELLED:return x.CANCELLED;case Ze.UNKNOWN:return x.UNKNOWN;case Ze.DEADLINE_EXCEEDED:return x.DEADLINE_EXCEEDED;case Ze.RESOURCE_EXHAUSTED:return x.RESOURCE_EXHAUSTED;case Ze.INTERNAL:return x.INTERNAL;case Ze.UNAVAILABLE:return x.UNAVAILABLE;case Ze.UNAUTHENTICATED:return x.UNAUTHENTICATED;case Ze.INVALID_ARGUMENT:return x.INVALID_ARGUMENT;case Ze.NOT_FOUND:return x.NOT_FOUND;case Ze.ALREADY_EXISTS:return x.ALREADY_EXISTS;case Ze.PERMISSION_DENIED:return x.PERMISSION_DENIED;case Ze.FAILED_PRECONDITION:return x.FAILED_PRECONDITION;case Ze.ABORTED:return x.ABORTED;case Ze.OUT_OF_RANGE:return x.OUT_OF_RANGE;case Ze.UNIMPLEMENTED:return x.UNIMPLEMENTED;case Ze.DATA_LOSS:return x.DATA_LOSS;default:return K()}}(me=Ze||(Ze={}))[me.OK=0]="OK",me[me.CANCELLED=1]="CANCELLED",me[me.UNKNOWN=2]="UNKNOWN",me[me.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",me[me.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",me[me.NOT_FOUND=5]="NOT_FOUND",me[me.ALREADY_EXISTS=6]="ALREADY_EXISTS",me[me.PERMISSION_DENIED=7]="PERMISSION_DENIED",me[me.UNAUTHENTICATED=16]="UNAUTHENTICATED",me[me.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",me[me.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",me[me.ABORTED=10]="ABORTED",me[me.OUT_OF_RANGE=11]="OUT_OF_RANGE",me[me.UNIMPLEMENTED=12]="UNIMPLEMENTED",me[me.INTERNAL=13]="INTERNAL",me[me.UNAVAILABLE=14]="UNAVAILABLE",me[me.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function QT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const JT=new Os([4294967295,4294967295],0);function Dp(n){const e=QT().encode(n),t=new iy;return t.update(e),new Uint8Array(t.digest())}function Np(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),i=e.getUint32(8,!0),r=e.getUint32(12,!0);return[new Os([t,s],0),new Os([i,r],0)]}class gd{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new Fr(`Invalid padding: ${t}`);if(s<0)throw new Fr(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new Fr(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new Fr(`Invalid padding when bitmap length is 0: ${t}`);this.Ie=8*e.length-t,this.Te=Os.fromNumber(this.Ie)}Ee(e,t,s){let i=e.add(t.multiply(Os.fromNumber(s)));return i.compare(JT)===1&&(i=new Os([i.getBits(0),i.getBits(1)],0)),i.modulo(this.Te).toNumber()}de(e){return(this.bitmap[Math.floor(e/8)]&1<<e%8)!=0}mightContain(e){if(this.Ie===0)return!1;const t=Dp(e),[s,i]=Np(t);for(let r=0;r<this.hashCount;r++){const a=this.Ee(s,i,r);if(!this.de(a))return!1}return!0}static create(e,t,s){const i=e%8==0?0:8-e%8,r=new Uint8Array(Math.ceil(e/8)),a=new gd(r,i,t);return s.forEach(o=>a.insert(o)),a}insert(e){if(this.Ie===0)return;const t=Dp(e),[s,i]=Np(t);for(let r=0;r<this.hashCount;r++){const a=this.Ee(s,i,r);this.Ae(a)}}Ae(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class Fr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xa{constructor(e,t,s,i,r){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=i,this.resolvedLimboDocuments=r}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const i=new Map;return i.set(e,Va.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new xa(ee.min(),i,new Le(re),Ft(),le())}}class Va{constructor(e,t,s,i,r){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=i,this.removedDocuments=r}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new Va(s,t,le(),le(),le())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xo{constructor(e,t,s,i){this.Re=e,this.removedTargetIds=t,this.key=s,this.Ve=i}}class Zy{constructor(e,t){this.targetId=e,this.me=t}}class ev{constructor(e,t,s=ct.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=i}}class xp{constructor(){this.fe=0,this.ge=Op(),this.pe=ct.EMPTY_BYTE_STRING,this.ye=!1,this.we=!0}get current(){return this.ye}get resumeToken(){return this.pe}get Se(){return this.fe!==0}get be(){return this.we}De(e){e.approximateByteSize()>0&&(this.we=!0,this.pe=e)}Ce(){let e=le(),t=le(),s=le();return this.ge.forEach((i,r)=>{switch(r){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:s=s.add(i);break;default:K()}}),new Va(this.pe,this.ye,e,t,s)}ve(){this.we=!1,this.ge=Op()}Fe(e,t){this.we=!0,this.ge=this.ge.insert(e,t)}Me(e){this.we=!0,this.ge=this.ge.remove(e)}xe(){this.fe+=1}Oe(){this.fe-=1,Z(this.fe>=0)}Ne(){this.we=!0,this.ye=!0}}class YT{constructor(e){this.Le=e,this.Be=new Map,this.ke=Ft(),this.qe=Vp(),this.Qe=new Le(re)}Ke(e){for(const t of e.Re)e.Ve&&e.Ve.isFoundDocument()?this.$e(t,e.Ve):this.Ue(t,e.key,e.Ve);for(const t of e.removedTargetIds)this.Ue(t,e.key,e.Ve)}We(e){this.forEachTarget(e,t=>{const s=this.Ge(t);switch(e.state){case 0:this.ze(t)&&s.De(e.resumeToken);break;case 1:s.Oe(),s.Se||s.ve(),s.De(e.resumeToken);break;case 2:s.Oe(),s.Se||this.removeTarget(t);break;case 3:this.ze(t)&&(s.Ne(),s.De(e.resumeToken));break;case 4:this.ze(t)&&(this.je(t),s.De(e.resumeToken));break;default:K()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.Be.forEach((s,i)=>{this.ze(i)&&t(i)})}He(e){const t=e.targetId,s=e.me.count,i=this.Je(t);if(i){const r=i.target;if(Yo(r))if(s===0){const a=new j(r.path);this.Ue(t,a,He.newNoDocument(a,ee.min()))}else Z(s===1);else{const a=this.Ye(t);if(a!==s){const o=this.Ze(e),l=o?this.Xe(o,e,a):1;if(l!==0){this.je(t);const u=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Qe=this.Qe.insert(t,u)}}}}}Ze(e){const t=e.me.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:i=0},hashCount:r=0}=t;let a,o;try{a=us(s).toUint8Array()}catch(l){if(l instanceof ky)return ra("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{o=new gd(a,i,r)}catch(l){return ra(l instanceof Fr?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return o.Ie===0?null:o}Xe(e,t,s){return t.me.count===s-this.nt(e,t.targetId)?0:2}nt(e,t){const s=this.Le.getRemoteKeysForTarget(t);let i=0;return s.forEach(r=>{const a=this.Le.tt(),o=`projects/${a.projectId}/databases/${a.database}/documents/${r.path.canonicalString()}`;e.mightContain(o)||(this.Ue(t,r,null),i++)}),i}rt(e){const t=new Map;this.Be.forEach((r,a)=>{const o=this.Je(a);if(o){if(r.current&&Yo(o.target)){const l=new j(o.target.path);this.ke.get(l)!==null||this.it(a,l)||this.Ue(a,l,He.newNoDocument(l,e))}r.be&&(t.set(a,r.Ce()),r.ve())}});let s=le();this.qe.forEach((r,a)=>{let o=!0;a.forEachWhile(l=>{const u=this.Je(l);return!u||u.purpose==="TargetPurposeLimboResolution"||(o=!1,!1)}),o&&(s=s.add(r))}),this.ke.forEach((r,a)=>a.setReadTime(e));const i=new xa(e,t,this.Qe,this.ke,s);return this.ke=Ft(),this.qe=Vp(),this.Qe=new Le(re),i}$e(e,t){if(!this.ze(e))return;const s=this.it(e,t.key)?2:0;this.Ge(e).Fe(t.key,s),this.ke=this.ke.insert(t.key,t),this.qe=this.qe.insert(t.key,this.st(t.key).add(e))}Ue(e,t,s){if(!this.ze(e))return;const i=this.Ge(e);this.it(e,t)?i.Fe(t,1):i.Me(t),this.qe=this.qe.insert(t,this.st(t).delete(e)),s&&(this.ke=this.ke.insert(t,s))}removeTarget(e){this.Be.delete(e)}Ye(e){const t=this.Ge(e).Ce();return this.Le.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}xe(e){this.Ge(e).xe()}Ge(e){let t=this.Be.get(e);return t||(t=new xp,this.Be.set(e,t)),t}st(e){let t=this.qe.get(e);return t||(t=new De(re),this.qe=this.qe.insert(e,t)),t}ze(e){const t=this.Je(e)!==null;return t||V("WatchChangeAggregator","Detected inactive target",e),t}Je(e){const t=this.Be.get(e);return t&&t.Se?null:this.Le.ot(e)}je(e){this.Be.set(e,new xp),this.Le.getRemoteKeysForTarget(e).forEach(t=>{this.Ue(e,t,null)})}it(e,t){return this.Le.getRemoteKeysForTarget(e).has(t)}}function Vp(){return new Le(j.comparator)}function Op(){return new Le(j.comparator)}const XT={asc:"ASCENDING",desc:"DESCENDING"},ZT={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},ek={and:"AND",or:"OR"};class tk{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function _u(n,e){return n.useProto3Json||xc(e)?e:{value:e}}function ji(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function tv(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function nk(n,e){return ji(n,e.toTimestamp())}function Pt(n){return Z(!!n),ee.fromTimestamp(function(t){const s=Dn(t);return new Be(s.seconds,s.nanos)}(n))}function yd(n,e){return wu(n,e).canonicalString()}function wu(n,e){const t=function(i){return new ke(["projects",i.projectId,"databases",i.database])}(n).child("documents");return e===void 0?t:t.child(e)}function nv(n){const e=ke.fromString(n);return Z(dv(e)),e}function ec(n,e){return yd(n.databaseId,e.path)}function Ms(n,e){const t=nv(e);if(t.get(1)!==n.databaseId.projectId)throw new L(x.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new L(x.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new j(rv(t))}function sv(n,e){return yd(n.databaseId,e)}function iv(n){const e=nv(n);return e.length===4?ke.emptyPath():rv(e)}function Iu(n){return new ke(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function rv(n){return Z(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function Mp(n,e,t){return{name:ec(n,e),fields:t.value.mapValue.fields}}function sk(n,e,t){const s=Ms(n,e.name),i=Pt(e.updateTime),r=e.createTime?Pt(e.createTime):ee.min(),a=new wt({mapValue:{fields:e.fields}}),o=He.newFoundDocument(s,i,r,a);return t&&o.setHasCommittedMutations(),t?o.setHasCommittedMutations():o}function ik(n,e){let t;if("targetChange"in e){e.targetChange;const s=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:K()}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],r=function(u,h){return u.useProto3Json?(Z(h===void 0||typeof h=="string"),ct.fromBase64String(h||"")):(Z(h===void 0||h instanceof Buffer||h instanceof Uint8Array),ct.fromUint8Array(h||new Uint8Array))}(n,e.targetChange.resumeToken),a=e.targetChange.cause,o=a&&function(u){const h=u.code===void 0?x.UNKNOWN:Xy(u.code);return new L(h,u.message||"")}(a);t=new ev(s,i,r,o||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const i=Ms(n,s.document.name),r=Pt(s.document.updateTime),a=s.document.createTime?Pt(s.document.createTime):ee.min(),o=new wt({mapValue:{fields:s.document.fields}}),l=He.newFoundDocument(i,r,a,o),u=s.targetIds||[],h=s.removedTargetIds||[];t=new xo(u,h,l.key,l)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const i=Ms(n,s.document),r=s.readTime?Pt(s.readTime):ee.min(),a=He.newNoDocument(i,r),o=s.removedTargetIds||[];t=new xo([],o,a.key,a)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const i=Ms(n,s.document),r=s.removedTargetIds||[];t=new xo([],r,i,null)}else{if(!("filter"in e))return K();{e.filter;const s=e.filter;s.targetId;const{count:i=0,unchangedNames:r}=s,a=new KT(i,r),o=s.targetId;t=new Zy(o,a)}}return t}function tc(n,e){let t;if(e instanceof ar)t={update:Mp(n,e.key,e.value)};else if(e instanceof Lc)t={delete:ec(n,e.key)};else if(e instanceof xn)t={update:Mp(n,e.key,e.data),updateMask:uk(e.fieldMask)};else{if(!(e instanceof Yy))return K();t={verify:ec(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(s=>function(r,a){const o=a.transform;if(o instanceof pa)return{fieldPath:a.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(o instanceof Ui)return{fieldPath:a.field.canonicalString(),appendMissingElements:{values:o.elements}};if(o instanceof qi)return{fieldPath:a.field.canonicalString(),removeAllFromArray:{values:o.elements}};if(o instanceof ma)return{fieldPath:a.field.canonicalString(),increment:o.Pe};throw K()}(0,s))),e.precondition.isNone||(t.currentDocument=function(i,r){return r.updateTime!==void 0?{updateTime:nk(i,r.updateTime)}:r.exists!==void 0?{exists:r.exists}:K()}(n,e.precondition)),t}function Eu(n,e){const t=e.currentDocument?function(r){return r.updateTime!==void 0?St.updateTime(Pt(r.updateTime)):r.exists!==void 0?St.exists(r.exists):St.none()}(e.currentDocument):St.none(),s=e.updateTransforms?e.updateTransforms.map(i=>function(a,o){let l=null;if("setToServerValue"in o)Z(o.setToServerValue==="REQUEST_TIME"),l=new pa;else if("appendMissingElements"in o){const h=o.appendMissingElements.values||[];l=new Ui(h)}else if("removeAllFromArray"in o){const h=o.removeAllFromArray.values||[];l=new qi(h)}else"increment"in o?l=new ma(a,o.increment):K();const u=je.fromServerFormat(o.fieldPath);return new jT(u,l)}(n,i)):[];if(e.update){e.update.name;const i=Ms(n,e.update.name),r=new wt({mapValue:{fields:e.update.fields}});if(e.updateMask){const a=function(l){const u=l.fieldPaths||[];return new xt(u.map(h=>je.fromServerFormat(h)))}(e.updateMask);return new xn(i,r,a,t,s)}return new ar(i,r,t,s)}if(e.delete){const i=Ms(n,e.delete);return new Lc(i,t)}if(e.verify){const i=Ms(n,e.verify);return new Yy(i,t)}return K()}function rk(n,e){return n&&n.length>0?(Z(e!==void 0),n.map(t=>function(i,r){let a=i.updateTime?Pt(i.updateTime):Pt(r);return a.isEqual(ee.min())&&(a=Pt(r)),new WT(a,i.transformResults||[])}(t,e))):[]}function av(n,e){return{documents:[sv(n,e.path)]}}function ov(n,e){const t={structuredQuery:{}},s=e.path;let i;e.collectionGroup!==null?(i=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(i=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=sv(n,i);const r=function(u){if(u.length!==0)return uv(Pe.create(u,"and"))}(e.filters);r&&(t.structuredQuery.where=r);const a=function(u){if(u.length!==0)return u.map(h=>function(m){return{field:_i(m.field),direction:ok(m.dir)}}(h))}(e.orderBy);a&&(t.structuredQuery.orderBy=a);const o=_u(n,e.limit);return o!==null&&(t.structuredQuery.limit=o),e.startAt&&(t.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(e.endAt)),{_t:t,parent:i}}function cv(n){let e=iv(n.parent);const t=n.structuredQuery,s=t.from?t.from.length:0;let i=null;if(s>0){Z(s===1);const h=t.from[0];h.allDescendants?i=h.collectionId:e=e.child(h.collectionId)}let r=[];t.where&&(r=function(p){const m=lv(p);return m instanceof Pe&&dd(m)?m.getFilters():[m]}(t.where));let a=[];t.orderBy&&(a=function(p){return p.map(m=>function(E){return new fa(wi(E.field),function($){switch($){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(E.direction))}(m))}(t.orderBy));let o=null;t.limit&&(o=function(p){let m;return m=typeof p=="object"?p.value:p,xc(m)?null:m}(t.limit));let l=null;t.startAt&&(l=function(p){const m=!!p.before,w=p.values||[];return new Li(w,m)}(t.startAt));let u=null;return t.endAt&&(u=function(p){const m=!p.before,w=p.values||[];return new Li(w,m)}(t.endAt)),Vy(e,i,a,r,o,"F",l,u)}function ak(n,e){const t=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return K()}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function lv(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=wi(t.unaryFilter.field);return fe.create(s,"==",{doubleValue:NaN});case"IS_NULL":const i=wi(t.unaryFilter.field);return fe.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const r=wi(t.unaryFilter.field);return fe.create(r,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const a=wi(t.unaryFilter.field);return fe.create(a,"!=",{nullValue:"NULL_VALUE"});default:return K()}}(n):n.fieldFilter!==void 0?function(t){return fe.create(wi(t.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return K()}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Pe.create(t.compositeFilter.filters.map(s=>lv(s)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return K()}}(t.compositeFilter.op))}(n):K()}function ok(n){return XT[n]}function ck(n){return ZT[n]}function lk(n){return ek[n]}function _i(n){return{fieldPath:n.canonicalString()}}function wi(n){return je.fromServerFormat(n.fieldPath)}function uv(n){return n instanceof fe?function(t){if(t.op==="=="){if(_p(t.value))return{unaryFilter:{field:_i(t.field),op:"IS_NAN"}};if(bp(t.value))return{unaryFilter:{field:_i(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(_p(t.value))return{unaryFilter:{field:_i(t.field),op:"IS_NOT_NAN"}};if(bp(t.value))return{unaryFilter:{field:_i(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:_i(t.field),op:ck(t.op),value:t.value}}}(n):n instanceof Pe?function(t){const s=t.getFilters().map(i=>uv(i));return s.length===1?s[0]:{compositeFilter:{op:lk(t.op),filters:s}}}(n):K()}function uk(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function dv(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $n{constructor(e,t,s,i,r=ee.min(),a=ee.min(),o=ct.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=i,this.snapshotVersion=r,this.lastLimboFreeSnapshotVersion=a,this.resumeToken=o,this.expectedCount=l}withSequenceNumber(e){return new $n(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new $n(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new $n(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new $n(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hv{constructor(e){this.ct=e}}function dk(n,e){let t;if(e.document)t=sk(n.ct,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const s=j.fromSegments(e.noDocument.path),i=Hs(e.noDocument.readTime);t=He.newNoDocument(s,i),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return K();{const s=j.fromSegments(e.unknownDocument.path),i=Hs(e.unknownDocument.version);t=He.newUnknownDocument(s,i)}}return e.readTime&&t.setReadTime(function(i){const r=new Be(i[0],i[1]);return ee.fromTimestamp(r)}(e.readTime)),t}function Lp(n,e){const t=e.key,s={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:nc(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())s.document=function(r,a){return{name:ec(r,a.key),fields:a.data.value.mapValue.fields,updateTime:ji(r,a.version.toTimestamp()),createTime:ji(r,a.createTime.toTimestamp())}}(n.ct,e);else if(e.isNoDocument())s.noDocument={path:t.path.toArray(),readTime:Ks(e.version)};else{if(!e.isUnknownDocument())return K();s.unknownDocument={path:t.path.toArray(),version:Ks(e.version)}}return s}function nc(n){const e=n.toTimestamp();return[e.seconds,e.nanoseconds]}function Ks(n){const e=n.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function Hs(n){const e=new Be(n.seconds,n.nanoseconds);return ee.fromTimestamp(e)}function $s(n,e){const t=(e.baseMutations||[]).map(r=>Eu(n.ct,r));for(let r=0;r<e.mutations.length-1;++r){const a=e.mutations[r];if(r+1<e.mutations.length&&e.mutations[r+1].transform!==void 0){const o=e.mutations[r+1];a.updateTransforms=o.transform.fieldTransforms,e.mutations.splice(r+1,1),++r}}const s=e.mutations.map(r=>Eu(n.ct,r)),i=Be.fromMillis(e.localWriteTimeMs);return new fd(e.batchId,i,t,s)}function Ur(n){const e=Hs(n.readTime),t=n.lastLimboFreeSnapshotVersion!==void 0?Hs(n.lastLimboFreeSnapshotVersion):ee.min();let s;return s=function(r){return r.documents!==void 0}(n.query)?function(r){return Z(r.documents.length===1),Ut(Da(iv(r.documents[0])))}(n.query):function(r){return Ut(cv(r))}(n.query),new $n(s,n.targetId,"TargetPurposeListen",n.lastListenSequenceNumber,e,t,ct.fromBase64String(n.resumeToken))}function fv(n,e){const t=Ks(e.snapshotVersion),s=Ks(e.lastLimboFreeSnapshotVersion);let i;i=Yo(e.target)?av(n.ct,e.target):ov(n.ct,e.target)._t;const r=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:Gs(e.target),readTime:t,resumeToken:r,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:s,query:i}}function pv(n){const e=cv({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Zo(e,e.limit,"L"):e}function Ol(n,e){return new md(e.largestBatchId,Eu(n.ct,e.overlayMutation))}function Fp(n,e){const t=e.path.lastSegment();return[n,At(e.path.popLast()),t]}function Up(n,e,t,s){return{indexId:n,uid:e,sequenceNumber:t,readTime:Ks(s.readTime),documentKey:At(s.documentKey.path),largestBatchId:s.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hk{getBundleMetadata(e,t){return qp(e).get(t).next(s=>{if(s)return function(r){return{id:r.bundleId,createTime:Hs(r.createTime),version:r.version}}(s)})}saveBundleMetadata(e,t){return qp(e).put(function(i){return{bundleId:i.id,createTime:Ks(Pt(i.createTime)),version:i.version}}(t))}getNamedQuery(e,t){return jp(e).get(t).next(s=>{if(s)return function(r){return{name:r.name,query:pv(r.bundledQuery),readTime:Hs(r.readTime)}}(s)})}saveNamedQuery(e,t){return jp(e).put(function(i){return{name:i.name,readTime:Ks(Pt(i.readTime)),bundledQuery:i.bundledQuery}}(t))}}function qp(n){return lt(n,"bundles")}function jp(n){return lt(n,"namedQueries")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fc{constructor(e,t){this.serializer=e,this.userId=t}static lt(e,t){const s=t.uid||"";return new Fc(e,s)}getOverlay(e,t){return Ar(e).get(Fp(this.userId,t)).next(s=>s?Ol(this.serializer,s):null)}getOverlays(e,t){const s=cn();return C.forEach(t,i=>this.getOverlay(e,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(e,t,s){const i=[];return s.forEach((r,a)=>{const o=new md(t,a);i.push(this.ht(e,o))}),C.waitFor(i)}removeOverlaysForBatchId(e,t,s){const i=new Set;t.forEach(a=>i.add(At(a.getCollectionPath())));const r=[];return i.forEach(a=>{const o=IDBKeyRange.bound([this.userId,a,s],[this.userId,a,s+1],!1,!0);r.push(Ar(e).j("collectionPathOverlayIndex",o))}),C.waitFor(r)}getOverlaysForCollection(e,t,s){const i=cn(),r=At(t),a=IDBKeyRange.bound([this.userId,r,s],[this.userId,r,Number.POSITIVE_INFINITY],!0);return Ar(e).U("collectionPathOverlayIndex",a).next(o=>{for(const l of o){const u=Ol(this.serializer,l);i.set(u.getKey(),u)}return i})}getOverlaysForCollectionGroup(e,t,s,i){const r=cn();let a;const o=IDBKeyRange.bound([this.userId,t,s],[this.userId,t,Number.POSITIVE_INFINITY],!0);return Ar(e).J({index:"collectionGroupOverlayIndex",range:o},(l,u,h)=>{const p=Ol(this.serializer,u);r.size()<i||p.largestBatchId===a?(r.set(p.getKey(),p),a=p.largestBatchId):h.done()}).next(()=>r)}ht(e,t){return Ar(e).put(function(i,r,a){const[o,l,u]=Fp(r,a.mutation.key);return{userId:r,collectionPath:l,documentId:u,collectionGroup:a.mutation.key.getCollectionGroup(),largestBatchId:a.largestBatchId,overlayMutation:tc(i.ct,a.mutation)}}(this.serializer,this.userId,t))}}function Ar(n){return lt(n,"documentOverlays")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cs{constructor(){}Pt(e,t){this.It(e,t),t.Tt()}It(e,t){if("nullValue"in e)this.Et(t,5);else if("booleanValue"in e)this.Et(t,10),t.dt(e.booleanValue?1:0);else if("integerValue"in e)this.Et(t,15),t.dt(Ke(e.integerValue));else if("doubleValue"in e){const s=Ke(e.doubleValue);isNaN(s)?this.Et(t,13):(this.Et(t,15),ca(s)?t.dt(0):t.dt(s))}else if("timestampValue"in e){let s=e.timestampValue;this.Et(t,20),typeof s=="string"&&(s=Dn(s)),t.At(`${s.seconds||""}`),t.dt(s.nanos||0)}else if("stringValue"in e)this.Rt(e.stringValue,t),this.Vt(t);else if("bytesValue"in e)this.Et(t,30),t.ft(us(e.bytesValue)),this.Vt(t);else if("referenceValue"in e)this.gt(e.referenceValue,t);else if("geoPointValue"in e){const s=e.geoPointValue;this.Et(t,45),t.dt(s.latitude||0),t.dt(s.longitude||0)}else"mapValue"in e?Sy(e)?this.Et(t,Number.MAX_SAFE_INTEGER):(this.yt(e.mapValue,t),this.Vt(t)):"arrayValue"in e?(this.wt(e.arrayValue,t),this.Vt(t)):K()}Rt(e,t){this.Et(t,25),this.St(e,t)}St(e,t){t.At(e)}yt(e,t){const s=e.fields||{};this.Et(t,55);for(const i of Object.keys(s))this.Rt(i,t),this.It(s[i],t)}wt(e,t){const s=e.values||[];this.Et(t,50);for(const i of s)this.It(i,t)}gt(e,t){this.Et(t,37),j.fromName(e).path.forEach(s=>{this.Et(t,60),this.St(s,t)})}Et(e,t){e.dt(t)}Vt(e){e.dt(2)}}Cs.bt=new Cs;function fk(n){if(n===0)return 8;let e=0;return!(n>>4)&&(e+=4,n<<=4),!(n>>6)&&(e+=2,n<<=2),!(n>>7)&&(e+=1),e}function Bp(n){const e=64-function(s){let i=0;for(let r=0;r<8;++r){const a=fk(255&s[r]);if(i+=a,a!==8)break}return i}(n);return Math.ceil(e/8)}class pk{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Dt(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Ct(s.value),s=t.next();this.vt()}Ft(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Mt(s.value),s=t.next();this.xt()}Ot(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Ct(s);else if(s<2048)this.Ct(960|s>>>6),this.Ct(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Ct(480|s>>>12),this.Ct(128|63&s>>>6),this.Ct(128|63&s);else{const i=t.codePointAt(0);this.Ct(240|i>>>18),this.Ct(128|63&i>>>12),this.Ct(128|63&i>>>6),this.Ct(128|63&i)}}this.vt()}Nt(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Mt(s);else if(s<2048)this.Mt(960|s>>>6),this.Mt(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Mt(480|s>>>12),this.Mt(128|63&s>>>6),this.Mt(128|63&s);else{const i=t.codePointAt(0);this.Mt(240|i>>>18),this.Mt(128|63&i>>>12),this.Mt(128|63&i>>>6),this.Mt(128|63&i)}}this.xt()}Lt(e){const t=this.Bt(e),s=Bp(t);this.kt(1+s),this.buffer[this.position++]=255&s;for(let i=t.length-s;i<t.length;++i)this.buffer[this.position++]=255&t[i]}qt(e){const t=this.Bt(e),s=Bp(t);this.kt(1+s),this.buffer[this.position++]=~(255&s);for(let i=t.length-s;i<t.length;++i)this.buffer[this.position++]=~(255&t[i])}Qt(){this.Kt(255),this.Kt(255)}$t(){this.Ut(255),this.Ut(255)}reset(){this.position=0}seed(e){this.kt(e.length),this.buffer.set(e,this.position),this.position+=e.length}Wt(){return this.buffer.slice(0,this.position)}Bt(e){const t=function(r){const a=new DataView(new ArrayBuffer(8));return a.setFloat64(0,r,!1),new Uint8Array(a.buffer)}(e),s=(128&t[0])!=0;t[0]^=s?255:128;for(let i=1;i<t.length;++i)t[i]^=s?255:0;return t}Ct(e){const t=255&e;t===0?(this.Kt(0),this.Kt(255)):t===255?(this.Kt(255),this.Kt(0)):this.Kt(t)}Mt(e){const t=255&e;t===0?(this.Ut(0),this.Ut(255)):t===255?(this.Ut(255),this.Ut(0)):this.Ut(e)}vt(){this.Kt(0),this.Kt(1)}xt(){this.Ut(0),this.Ut(1)}Kt(e){this.kt(1),this.buffer[this.position++]=e}Ut(e){this.kt(1),this.buffer[this.position++]=~e}kt(e){const t=e+this.position;if(t<=this.buffer.length)return;let s=2*this.buffer.length;s<t&&(s=t);const i=new Uint8Array(s);i.set(this.buffer),this.buffer=i}}class mk{constructor(e){this.Gt=e}ft(e){this.Gt.Dt(e)}At(e){this.Gt.Ot(e)}dt(e){this.Gt.Lt(e)}Tt(){this.Gt.Qt()}}class gk{constructor(e){this.Gt=e}ft(e){this.Gt.Ft(e)}At(e){this.Gt.Nt(e)}dt(e){this.Gt.qt(e)}Tt(){this.Gt.$t()}}class Pr{constructor(){this.Gt=new pk,this.zt=new mk(this.Gt),this.jt=new gk(this.Gt)}seed(e){this.Gt.seed(e)}Ht(e){return e===0?this.zt:this.jt}Wt(){return this.Gt.Wt()}reset(){this.Gt.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ds{constructor(e,t,s,i){this.indexId=e,this.documentKey=t,this.arrayValue=s,this.directionalValue=i}Jt(){const e=this.directionalValue.length,t=e===0||this.directionalValue[e-1]===255?e+1:e,s=new Uint8Array(t);return s.set(this.directionalValue,0),t!==e?s.set([0],this.directionalValue.length):++s[s.length-1],new Ds(this.indexId,this.documentKey,this.arrayValue,s)}}function jn(n,e){let t=n.indexId-e.indexId;return t!==0?t:(t=Wp(n.arrayValue,e.arrayValue),t!==0?t:(t=Wp(n.directionalValue,e.directionalValue),t!==0?t:j.comparator(n.documentKey,e.documentKey)))}function Wp(n,e){for(let t=0;t<n.length&&t<e.length;++t){const s=n[t]-e[t];if(s!==0)return s}return n.length-e.length}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zp{constructor(e){this.Yt=new De((t,s)=>je.comparator(t.field,s.field)),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.Zt=e.orderBy,this.Xt=[];for(const t of e.filters){const s=t;s.isInequality()?this.Yt=this.Yt.add(s):this.Xt.push(s)}}get en(){return this.Yt.size>1}tn(e){if(Z(e.collectionGroup===this.collectionId),this.en)return!1;const t=hu(e);if(t!==void 0&&!this.nn(t))return!1;const s=Ps(e);let i=new Set,r=0,a=0;for(;r<s.length&&this.nn(s[r]);++r)i=i.add(s[r].fieldPath.canonicalString());if(r===s.length)return!0;if(this.Yt.size>0){const o=this.Yt.getIterator().getNext();if(!i.has(o.field.canonicalString())){const l=s[r];if(!this.rn(o,l)||!this.sn(this.Zt[a++],l))return!1}++r}for(;r<s.length;++r){const o=s[r];if(a>=this.Zt.length||!this.sn(this.Zt[a++],o))return!1}return!0}on(){if(this.en)return null;let e=new De(je.comparator);const t=[];for(const s of this.Xt)if(!s.field.isKeyField())if(s.op==="array-contains"||s.op==="array-contains-any")t.push(new Ro(s.field,2));else{if(e.has(s.field))continue;e=e.add(s.field),t.push(new Ro(s.field,0))}for(const s of this.Zt)s.field.isKeyField()||e.has(s.field)||(e=e.add(s.field),t.push(new Ro(s.field,s.dir==="asc"?0:1)));return new Jo(Jo.UNKNOWN_ID,this.collectionId,t,oa.empty())}nn(e){for(const t of this.Xt)if(this.rn(t,e))return!0;return!1}rn(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const s=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===s}sn(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mv(n){var e,t;if(Z(n instanceof fe||n instanceof Pe),n instanceof fe){if(n instanceof xy){const i=((t=(e=n.value.arrayValue)===null||e===void 0?void 0:e.values)===null||t===void 0?void 0:t.map(r=>fe.create(n.field,"==",r)))||[];return Pe.create(i,"or")}return n}const s=n.filters.map(i=>mv(i));return Pe.create(s,n.op)}function yk(n){if(n.getFilters().length===0)return[];const e=Su(mv(n));return Z(gv(e)),Tu(e)||ku(e)?[e]:e.getFilters()}function Tu(n){return n instanceof fe}function ku(n){return n instanceof Pe&&dd(n)}function gv(n){return Tu(n)||ku(n)||function(t){if(t instanceof Pe&&gu(t)){for(const s of t.getFilters())if(!Tu(s)&&!ku(s))return!1;return!0}return!1}(n)}function Su(n){if(Z(n instanceof fe||n instanceof Pe),n instanceof fe)return n;if(n.filters.length===1)return Su(n.filters[0]);const e=n.filters.map(s=>Su(s));let t=Pe.create(e,n.op);return t=sc(t),gv(t)?t:(Z(t instanceof Pe),Z(Fi(t)),Z(t.filters.length>1),t.filters.reduce((s,i)=>vd(s,i)))}function vd(n,e){let t;return Z(n instanceof fe||n instanceof Pe),Z(e instanceof fe||e instanceof Pe),t=n instanceof fe?e instanceof fe?function(i,r){return Pe.create([i,r],"and")}(n,e):Gp(n,e):e instanceof fe?Gp(e,n):function(i,r){if(Z(i.filters.length>0&&r.filters.length>0),Fi(i)&&Fi(r))return Cy(i,r.getFilters());const a=gu(i)?i:r,o=gu(i)?r:i,l=a.filters.map(u=>vd(u,o));return Pe.create(l,"or")}(n,e),sc(t)}function Gp(n,e){if(Fi(e))return Cy(e,n.getFilters());{const t=e.filters.map(s=>vd(n,s));return Pe.create(t,"or")}}function sc(n){if(Z(n instanceof fe||n instanceof Pe),n instanceof fe)return n;const e=n.getFilters();if(e.length===1)return sc(e[0]);if(Ry(n))return n;const t=e.map(i=>sc(i)),s=[];return t.forEach(i=>{i instanceof fe?s.push(i):i instanceof Pe&&(i.op===n.op?s.push(...i.filters):s.push(i))}),s.length===1?s[0]:Pe.create(s,n.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vk{constructor(){this._n=new bd}addToCollectionParentIndex(e,t){return this._n.add(t),C.resolve()}getCollectionParents(e,t){return C.resolve(this._n.getEntries(t))}addFieldIndex(e,t){return C.resolve()}deleteFieldIndex(e,t){return C.resolve()}deleteAllFieldIndexes(e){return C.resolve()}createTargetIndexes(e,t){return C.resolve()}getDocumentsMatchingTarget(e,t){return C.resolve(null)}getIndexType(e,t){return C.resolve(0)}getFieldIndexes(e,t){return C.resolve([])}getNextCollectionGroupToUpdate(e){return C.resolve(null)}getMinOffset(e,t){return C.resolve(jt.min())}getMinOffsetFromCollectionGroup(e,t){return C.resolve(jt.min())}updateCollectionGroup(e,t,s){return C.resolve()}updateIndexEntries(e,t){return C.resolve()}}class bd{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),i=this.index[t]||new De(ke.comparator),r=!i.has(s);return this.index[t]=i.add(s),r}has(e){const t=e.lastSegment(),s=e.popLast(),i=this.index[t];return i&&i.has(s)}getEntries(e){return(this.index[e]||new De(ke.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uo=new Uint8Array(0);class bk{constructor(e,t){this.databaseId=t,this.an=new bd,this.un=new bs(s=>Gs(s),(s,i)=>Ca(s,i)),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.an.has(t)){const s=t.lastSegment(),i=t.popLast();e.addOnCommittedListener(()=>{this.an.add(t)});const r={collectionId:s,parent:At(i)};return Kp(e).put(r)}return C.resolve()}getCollectionParents(e,t){const s=[],i=IDBKeyRange.bound([t,""],[hy(t),""],!1,!0);return Kp(e).U(i).next(r=>{for(const a of r){if(a.collectionId!==t)break;s.push(on(a.parent))}return s})}addFieldIndex(e,t){const s=Rr(e),i=function(o){return{indexId:o.indexId,collectionGroup:o.collectionGroup,fields:o.fields.map(l=>[l.fieldPath.canonicalString(),l.kind])}}(t);delete i.indexId;const r=s.add(i);if(t.indexState){const a=di(e);return r.next(o=>{a.put(Up(o,this.uid,t.indexState.sequenceNumber,t.indexState.offset))})}return r.next()}deleteFieldIndex(e,t){const s=Rr(e),i=di(e),r=ui(e);return s.delete(t.indexId).next(()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))).next(()=>r.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))}deleteAllFieldIndexes(e){const t=Rr(e),s=ui(e),i=di(e);return t.j().next(()=>s.j()).next(()=>i.j())}createTargetIndexes(e,t){return C.forEach(this.cn(t),s=>this.getIndexType(e,s).next(i=>{if(i===0||i===1){const r=new zp(s).on();if(r!=null)return this.addFieldIndex(e,r)}}))}getDocumentsMatchingTarget(e,t){const s=ui(e);let i=!0;const r=new Map;return C.forEach(this.cn(t),a=>this.ln(e,a).next(o=>{i&&(i=!!o),r.set(a,o)})).next(()=>{if(i){let a=le();const o=[];return C.forEach(r,(l,u)=>{V("IndexedDbIndexManager",`Using index ${function(H){return`id=${H.indexId}|cg=${H.collectionGroup}|f=${H.fields.map(ae=>`${ae.fieldPath}:${ae.kind}`).join(",")}`}(l)} to execute ${Gs(t)}`);const h=function(H,ae){const O=hu(ae);if(O===void 0)return null;for(const U of Xo(H,O.fieldPath))switch(U.op){case"array-contains-any":return U.value.arrayValue.values||[];case"array-contains":return[U.value]}return null}(u,l),p=function(H,ae){const O=new Map;for(const U of Ps(ae))for(const _ of Xo(H,U.fieldPath))switch(_.op){case"==":case"in":O.set(U.fieldPath.canonicalString(),_.value);break;case"not-in":case"!=":return O.set(U.fieldPath.canonicalString(),_.value),Array.from(O.values())}return null}(u,l),m=function(H,ae){const O=[];let U=!0;for(const _ of Ps(ae)){const y=_.kind===0?kp(H,_.fieldPath,H.startAt):Sp(H,_.fieldPath,H.startAt);O.push(y.value),U&&(U=y.inclusive)}return new Li(O,U)}(u,l),w=function(H,ae){const O=[];let U=!0;for(const _ of Ps(ae)){const y=_.kind===0?Sp(H,_.fieldPath,H.endAt):kp(H,_.fieldPath,H.endAt);O.push(y.value),U&&(U=y.inclusive)}return new Li(O,U)}(u,l),E=this.hn(l,u,m),N=this.hn(l,u,w),$=this.Pn(l,u,p),B=this.In(l.indexId,h,E,m.inclusive,N,w.inclusive,$);return C.forEach(B,J=>s.G(J,t.limit).next(H=>{H.forEach(ae=>{const O=j.fromSegments(ae.documentKey);a.has(O)||(a=a.add(O),o.push(O))})}))}).next(()=>o)}return C.resolve(null)})}cn(e){let t=this.un.get(e);return t||(e.filters.length===0?t=[e]:t=yk(Pe.create(e.filters,"and")).map(s=>vu(e.path,e.collectionGroup,e.orderBy,s.getFilters(),e.limit,e.startAt,e.endAt)),this.un.set(e,t),t)}In(e,t,s,i,r,a,o){const l=(t!=null?t.length:1)*Math.max(s.length,r.length),u=l/(t!=null?t.length:1),h=[];for(let p=0;p<l;++p){const m=t?this.Tn(t[p/u]):uo,w=this.En(e,m,s[p%u],i),E=this.dn(e,m,r[p%u],a),N=o.map($=>this.En(e,m,$,!0));h.push(...this.createRange(w,E,N))}return h}En(e,t,s,i){const r=new Ds(e,j.empty(),t,s);return i?r:r.Jt()}dn(e,t,s,i){const r=new Ds(e,j.empty(),t,s);return i?r.Jt():r}ln(e,t){const s=new zp(t),i=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,i).next(r=>{let a=null;for(const o of r)s.tn(o)&&(!a||o.fields.length>a.fields.length)&&(a=o);return a})}getIndexType(e,t){let s=2;const i=this.cn(t);return C.forEach(i,r=>this.ln(e,r).next(a=>{a?s!==0&&a.fields.length<function(l){let u=new De(je.comparator),h=!1;for(const p of l.filters)for(const m of p.getFlattenedFilters())m.field.isKeyField()||(m.op==="array-contains"||m.op==="array-contains-any"?h=!0:u=u.add(m.field));for(const p of l.orderBy)p.field.isKeyField()||(u=u.add(p.field));return u.size+(h?1:0)}(r)&&(s=1):s=0})).next(()=>function(a){return a.limit!==null}(t)&&i.length>1&&s===2?1:s)}An(e,t){const s=new Pr;for(const i of Ps(e)){const r=t.data.field(i.fieldPath);if(r==null)return null;const a=s.Ht(i.kind);Cs.bt.Pt(r,a)}return s.Wt()}Tn(e){const t=new Pr;return Cs.bt.Pt(e,t.Ht(0)),t.Wt()}Rn(e,t){const s=new Pr;return Cs.bt.Pt(da(this.databaseId,t),s.Ht(function(r){const a=Ps(r);return a.length===0?0:a[a.length-1].kind}(e))),s.Wt()}Pn(e,t,s){if(s===null)return[];let i=[];i.push(new Pr);let r=0;for(const a of Ps(e)){const o=s[r++];for(const l of i)if(this.Vn(t,a.fieldPath)&&ha(o))i=this.mn(i,a,o);else{const u=l.Ht(a.kind);Cs.bt.Pt(o,u)}}return this.fn(i)}hn(e,t,s){return this.Pn(e,t,s.position)}fn(e){const t=[];for(let s=0;s<e.length;++s)t[s]=e[s].Wt();return t}mn(e,t,s){const i=[...e],r=[];for(const a of s.arrayValue.values||[])for(const o of i){const l=new Pr;l.seed(o.Wt()),Cs.bt.Pt(a,l.Ht(t.kind)),r.push(l)}return r}Vn(e,t){return!!e.filters.find(s=>s instanceof fe&&s.field.isEqual(t)&&(s.op==="in"||s.op==="not-in"))}getFieldIndexes(e,t){const s=Rr(e),i=di(e);return(t?s.U("collectionGroupIndex",IDBKeyRange.bound(t,t)):s.U()).next(r=>{const a=[];return C.forEach(r,o=>i.get([o.indexId,this.uid]).next(l=>{a.push(function(h,p){const m=p?new oa(p.sequenceNumber,new jt(Hs(p.readTime),new j(on(p.documentKey)),p.largestBatchId)):oa.empty(),w=h.fields.map(([E,N])=>new Ro(je.fromServerFormat(E),N));return new Jo(h.indexId,h.collectionGroup,w,m)}(o,l))})).next(()=>a)})}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next(t=>t.length===0?null:(t.sort((s,i)=>{const r=s.indexState.sequenceNumber-i.indexState.sequenceNumber;return r!==0?r:re(s.collectionGroup,i.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(e,t,s){const i=Rr(e),r=di(e);return this.gn(e).next(a=>i.U("collectionGroupIndex",IDBKeyRange.bound(t,t)).next(o=>C.forEach(o,l=>r.put(Up(l.indexId,this.uid,a,s)))))}updateIndexEntries(e,t){const s=new Map;return C.forEach(t,(i,r)=>{const a=s.get(i.collectionGroup);return(a?C.resolve(a):this.getFieldIndexes(e,i.collectionGroup)).next(o=>(s.set(i.collectionGroup,o),C.forEach(o,l=>this.pn(e,i,l).next(u=>{const h=this.yn(r,l);return u.isEqual(h)?C.resolve():this.wn(e,r,l,u,h)}))))})}Sn(e,t,s,i){return ui(e).put({indexId:i.indexId,uid:this.uid,arrayValue:i.arrayValue,directionalValue:i.directionalValue,orderedDocumentKey:this.Rn(s,t.key),documentKey:t.key.path.toArray()})}bn(e,t,s,i){return ui(e).delete([i.indexId,this.uid,i.arrayValue,i.directionalValue,this.Rn(s,t.key),t.key.path.toArray()])}pn(e,t,s){const i=ui(e);let r=new De(jn);return i.J({index:"documentKeyIndex",range:IDBKeyRange.only([s.indexId,this.uid,this.Rn(s,t)])},(a,o)=>{r=r.add(new Ds(s.indexId,t,o.arrayValue,o.directionalValue))}).next(()=>r)}yn(e,t){let s=new De(jn);const i=this.An(t,e);if(i==null)return s;const r=hu(t);if(r!=null){const a=e.data.field(r.fieldPath);if(ha(a))for(const o of a.arrayValue.values||[])s=s.add(new Ds(t.indexId,e.key,this.Tn(o),i))}else s=s.add(new Ds(t.indexId,e.key,uo,i));return s}wn(e,t,s,i,r){V("IndexedDbIndexManager","Updating index entries for document '%s'",t.key);const a=[];return function(l,u,h,p,m){const w=l.getIterator(),E=u.getIterator();let N=li(w),$=li(E);for(;N||$;){let B=!1,J=!1;if(N&&$){const H=h(N,$);H<0?J=!0:H>0&&(B=!0)}else N!=null?J=!0:B=!0;B?(p($),$=li(E)):J?(m(N),N=li(w)):(N=li(w),$=li(E))}}(i,r,jn,o=>{a.push(this.Sn(e,t,s,o))},o=>{a.push(this.bn(e,t,s,o))}),C.waitFor(a)}gn(e){let t=1;return di(e).J({index:"sequenceNumberIndex",reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(s,i,r)=>{r.done(),t=i.sequenceNumber+1}).next(()=>t)}createRange(e,t,s){s=s.sort((a,o)=>jn(a,o)).filter((a,o,l)=>!o||jn(a,l[o-1])!==0);const i=[];i.push(e);for(const a of s){const o=jn(a,e),l=jn(a,t);if(o===0)i[0]=e.Jt();else if(o>0&&l<0)i.push(a),i.push(a.Jt());else if(l>0)break}i.push(t);const r=[];for(let a=0;a<i.length;a+=2){if(this.Dn(i[a],i[a+1]))return[];const o=[i[a].indexId,this.uid,i[a].arrayValue,i[a].directionalValue,uo,[]],l=[i[a+1].indexId,this.uid,i[a+1].arrayValue,i[a+1].directionalValue,uo,[]];r.push(IDBKeyRange.bound(o,l))}return r}Dn(e,t){return jn(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(Hp)}getMinOffset(e,t){return C.mapArray(this.cn(t),s=>this.ln(e,s).next(i=>i||K())).next(Hp)}}function Kp(n){return lt(n,"collectionParents")}function ui(n){return lt(n,"indexEntries")}function Rr(n){return lt(n,"indexConfiguration")}function di(n){return lt(n,"indexState")}function Hp(n){Z(n.length!==0);let e=n[0].indexState.offset,t=e.largestBatchId;for(let s=1;s<n.length;s++){const i=n[s].indexState.offset;od(i,e)<0&&(e=i),t<i.largestBatchId&&(t=i.largestBatchId)}return new jt(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qp={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class Dt{constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}static withCacheSize(e){return new Dt(e,Dt.DEFAULT_COLLECTION_PERCENTILE,Dt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yv(n,e,t){const s=n.store("mutations"),i=n.store("documentMutations"),r=[],a=IDBKeyRange.only(t.batchId);let o=0;const l=s.J({range:a},(h,p,m)=>(o++,m.delete()));r.push(l.next(()=>{Z(o===1)}));const u=[];for(const h of t.mutations){const p=by(e,h.key.path,t.batchId);r.push(i.delete(p)),u.push(h.key)}return C.waitFor(r).next(()=>u)}function ic(n){if(!n)return 0;let e;if(n.document)e=n.document;else if(n.unknownDocument)e=n.unknownDocument;else{if(!n.noDocument)throw K();e=n.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Dt.DEFAULT_COLLECTION_PERCENTILE=10,Dt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Dt.DEFAULT=new Dt(41943040,Dt.DEFAULT_COLLECTION_PERCENTILE,Dt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Dt.DISABLED=new Dt(-1,0,0);class Uc{constructor(e,t,s,i){this.userId=e,this.serializer=t,this.indexManager=s,this.referenceDelegate=i,this.Cn={}}static lt(e,t,s,i){Z(e.uid!=="");const r=e.isAuthenticated()?e.uid:"";return new Uc(r,t,s,i)}checkEmpty(e){let t=!0;const s=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Bn(e).J({index:"userMutationsIndex",range:s},(i,r,a)=>{t=!1,a.done()}).next(()=>t)}addMutationBatch(e,t,s,i){const r=Ii(e),a=Bn(e);return a.add({}).next(o=>{Z(typeof o=="number");const l=new fd(o,t,s,i),u=function(w,E,N){const $=N.baseMutations.map(J=>tc(w.ct,J)),B=N.mutations.map(J=>tc(w.ct,J));return{userId:E,batchId:N.batchId,localWriteTimeMs:N.localWriteTime.toMillis(),baseMutations:$,mutations:B}}(this.serializer,this.userId,l),h=[];let p=new De((m,w)=>re(m.canonicalString(),w.canonicalString()));for(const m of i){const w=by(this.userId,m.key.path,o);p=p.add(m.key.path.popLast()),h.push(a.put(u)),h.push(r.put(w,iT))}return p.forEach(m=>{h.push(this.indexManager.addToCollectionParentIndex(e,m))}),e.addOnCommittedListener(()=>{this.Cn[o]=l.keys()}),C.waitFor(h).next(()=>l)})}lookupMutationBatch(e,t){return Bn(e).get(t).next(s=>s?(Z(s.userId===this.userId),$s(this.serializer,s)):null)}vn(e,t){return this.Cn[t]?C.resolve(this.Cn[t]):this.lookupMutationBatch(e,t).next(s=>{if(s){const i=s.keys();return this.Cn[t]=i,i}return null})}getNextMutationBatchAfterBatchId(e,t){const s=t+1,i=IDBKeyRange.lowerBound([this.userId,s]);let r=null;return Bn(e).J({index:"userMutationsIndex",range:i},(a,o,l)=>{o.userId===this.userId&&(Z(o.batchId>=s),r=$s(this.serializer,o)),l.done()}).next(()=>r)}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let s=-1;return Bn(e).J({index:"userMutationsIndex",range:t,reverse:!0},(i,r,a)=>{s=r.batchId,a.done()}).next(()=>s)}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return Bn(e).U("userMutationsIndex",t).next(s=>s.map(i=>$s(this.serializer,i)))}getAllMutationBatchesAffectingDocumentKey(e,t){const s=$o(this.userId,t.path),i=IDBKeyRange.lowerBound(s),r=[];return Ii(e).J({range:i},(a,o,l)=>{const[u,h,p]=a,m=on(h);if(u===this.userId&&t.path.isEqual(m))return Bn(e).get(p).next(w=>{if(!w)throw K();Z(w.userId===this.userId),r.push($s(this.serializer,w))});l.done()}).next(()=>r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new De(re);const i=[];return t.forEach(r=>{const a=$o(this.userId,r.path),o=IDBKeyRange.lowerBound(a),l=Ii(e).J({range:o},(u,h,p)=>{const[m,w,E]=u,N=on(w);m===this.userId&&r.path.isEqual(N)?s=s.add(E):p.done()});i.push(l)}),C.waitFor(i).next(()=>this.Fn(e,s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,i=s.length+1,r=$o(this.userId,s),a=IDBKeyRange.lowerBound(r);let o=new De(re);return Ii(e).J({range:a},(l,u,h)=>{const[p,m,w]=l,E=on(m);p===this.userId&&s.isPrefixOf(E)?E.length===i&&(o=o.add(w)):h.done()}).next(()=>this.Fn(e,o))}Fn(e,t){const s=[],i=[];return t.forEach(r=>{i.push(Bn(e).get(r).next(a=>{if(a===null)throw K();Z(a.userId===this.userId),s.push($s(this.serializer,a))}))}),C.waitFor(i).next(()=>s)}removeMutationBatch(e,t){return yv(e._e,this.userId,t).next(s=>(e.addOnCommittedListener(()=>{this.Mn(t.batchId)}),C.forEach(s,i=>this.referenceDelegate.markPotentiallyOrphaned(e,i))))}Mn(e){delete this.Cn[e]}performConsistencyCheck(e){return this.checkEmpty(e).next(t=>{if(!t)return C.resolve();const s=IDBKeyRange.lowerBound(function(a){return[a]}(this.userId)),i=[];return Ii(e).J({range:s},(r,a,o)=>{if(r[0]===this.userId){const l=on(r[1]);i.push(l)}else o.done()}).next(()=>{Z(i.length===0)})})}containsKey(e,t){return vv(e,this.userId,t)}xn(e){return bv(e).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:-1,lastStreamToken:""})}}function vv(n,e,t){const s=$o(e,t.path),i=s[1],r=IDBKeyRange.lowerBound(s);let a=!1;return Ii(n).J({range:r,H:!0},(o,l,u)=>{const[h,p,m]=o;h===e&&p===i&&(a=!0),u.done()}).next(()=>a)}function Bn(n){return lt(n,"mutations")}function Ii(n){return lt(n,"documentMutations")}function bv(n){return lt(n,"mutationQueues")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qs{constructor(e){this.On=e}next(){return this.On+=2,this.On}static Nn(){return new Qs(0)}static Ln(){return new Qs(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _k{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.Bn(e).next(t=>{const s=new Qs(t.highestTargetId);return t.highestTargetId=s.next(),this.kn(e,t).next(()=>t.highestTargetId)})}getLastRemoteSnapshotVersion(e){return this.Bn(e).next(t=>ee.fromTimestamp(new Be(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(e){return this.Bn(e).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(e,t,s){return this.Bn(e).next(i=>(i.highestListenSequenceNumber=t,s&&(i.lastRemoteSnapshotVersion=s.toTimestamp()),t>i.highestListenSequenceNumber&&(i.highestListenSequenceNumber=t),this.kn(e,i)))}addTargetData(e,t){return this.qn(e,t).next(()=>this.Bn(e).next(s=>(s.targetCount+=1,this.Qn(t,s),this.kn(e,s))))}updateTargetData(e,t){return this.qn(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next(()=>hi(e).delete(t.targetId)).next(()=>this.Bn(e)).next(s=>(Z(s.targetCount>0),s.targetCount-=1,this.kn(e,s)))}removeTargets(e,t,s){let i=0;const r=[];return hi(e).J((a,o)=>{const l=Ur(o);l.sequenceNumber<=t&&s.get(l.targetId)===null&&(i++,r.push(this.removeTargetData(e,l)))}).next(()=>C.waitFor(r)).next(()=>i)}forEachTarget(e,t){return hi(e).J((s,i)=>{const r=Ur(i);t(r)})}Bn(e){return Jp(e).get("targetGlobalKey").next(t=>(Z(t!==null),t))}kn(e,t){return Jp(e).put("targetGlobalKey",t)}qn(e,t){return hi(e).put(fv(this.serializer,t))}Qn(e,t){let s=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,s=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,s=!0),s}getTargetCount(e){return this.Bn(e).next(t=>t.targetCount)}getTargetData(e,t){const s=Gs(t),i=IDBKeyRange.bound([s,Number.NEGATIVE_INFINITY],[s,Number.POSITIVE_INFINITY]);let r=null;return hi(e).J({range:i,index:"queryTargetsIndex"},(a,o,l)=>{const u=Ur(o);Ca(t,u.target)&&(r=u,l.done())}).next(()=>r)}addMatchingKeys(e,t,s){const i=[],r=Yn(e);return t.forEach(a=>{const o=At(a.path);i.push(r.put({targetId:s,path:o})),i.push(this.referenceDelegate.addReference(e,s,a))}),C.waitFor(i)}removeMatchingKeys(e,t,s){const i=Yn(e);return C.forEach(t,r=>{const a=At(r.path);return C.waitFor([i.delete([s,a]),this.referenceDelegate.removeReference(e,s,r)])})}removeMatchingKeysForTargetId(e,t){const s=Yn(e),i=IDBKeyRange.bound([t],[t+1],!1,!0);return s.delete(i)}getMatchingKeysForTargetId(e,t){const s=IDBKeyRange.bound([t],[t+1],!1,!0),i=Yn(e);let r=le();return i.J({range:s,H:!0},(a,o,l)=>{const u=on(a[1]),h=new j(u);r=r.add(h)}).next(()=>r)}containsKey(e,t){const s=At(t.path),i=IDBKeyRange.bound([s],[hy(s)],!1,!0);let r=0;return Yn(e).J({index:"documentTargetsIndex",H:!0,range:i},([a,o],l,u)=>{a!==0&&(r++,u.done())}).next(()=>r>0)}ot(e,t){return hi(e).get(t).next(s=>s?Ur(s):null)}}function hi(n){return lt(n,"targets")}function Jp(n){return lt(n,"targetGlobal")}function Yn(n){return lt(n,"targetDocuments")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yp([n,e],[t,s]){const i=re(n,t);return i===0?re(e,s):i}class wk{constructor(e){this.Kn=e,this.buffer=new De(Yp),this.$n=0}Un(){return++this.$n}Wn(e){const t=[e,this.Un()];if(this.buffer.size<this.Kn)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();Yp(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class Ik{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.Gn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.zn(6e4)}stop(){this.Gn&&(this.Gn.cancel(),this.Gn=null)}get started(){return this.Gn!==null}zn(e){V("LruGarbageCollector",`Garbage collection scheduled in ${e}ms`),this.Gn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Gn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){vs(t)?V("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",t):await ys(t)}await this.zn(3e5)})}}class Ek{constructor(e,t){this.jn=e,this.params=t}calculateTargetCount(e,t){return this.jn.Hn(e).next(s=>Math.floor(t/100*s))}nthSequenceNumber(e,t){if(t===0)return C.resolve(Nt.oe);const s=new wk(t);return this.jn.forEachTarget(e,i=>s.Wn(i.sequenceNumber)).next(()=>this.jn.Jn(e,i=>s.Wn(i))).next(()=>s.maxValue)}removeTargets(e,t,s){return this.jn.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.jn.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(V("LruGarbageCollector","Garbage collection skipped; disabled"),C.resolve(Qp)):this.getCacheSize(e).next(s=>s<this.params.cacheSizeCollectionThreshold?(V("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Qp):this.Yn(e,t))}getCacheSize(e){return this.jn.getCacheSize(e)}Yn(e,t){let s,i,r,a,o,l,u;const h=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(p=>(p>this.params.maximumSequenceNumbersToCollect?(V("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${p}`),i=this.params.maximumSequenceNumbersToCollect):i=p,a=Date.now(),this.nthSequenceNumber(e,i))).next(p=>(s=p,o=Date.now(),this.removeTargets(e,s,t))).next(p=>(r=p,l=Date.now(),this.removeOrphanedDocuments(e,s))).next(p=>(u=Date.now(),vi()<=he.DEBUG&&V("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${a-h}ms
	Determined least recently used ${i} in `+(o-a)+`ms
	Removed ${r} targets in `+(l-o)+`ms
	Removed ${p} documents in `+(u-l)+`ms
Total Duration: ${u-h}ms`),C.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:r,documentsRemoved:p})))}}function Tk(n,e){return new Ek(n,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kk{constructor(e,t){this.db=e,this.garbageCollector=Tk(this,t)}Hn(e){const t=this.Zn(e);return this.db.getTargetCache().getTargetCount(e).next(s=>t.next(i=>s+i))}Zn(e){let t=0;return this.Jn(e,s=>{t++}).next(()=>t)}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}Jn(e,t){return this.Xn(e,(s,i)=>t(i))}addReference(e,t,s){return ho(e,s)}removeReference(e,t,s){return ho(e,s)}removeTargets(e,t,s){return this.db.getTargetCache().removeTargets(e,t,s)}markPotentiallyOrphaned(e,t){return ho(e,t)}er(e,t){return function(i,r){let a=!1;return bv(i).Y(o=>vv(i,o,r).next(l=>(l&&(a=!0),C.resolve(!l)))).next(()=>a)}(e,t)}removeOrphanedDocuments(e,t){const s=this.db.getRemoteDocumentCache().newChangeBuffer(),i=[];let r=0;return this.Xn(e,(a,o)=>{if(o<=t){const l=this.er(e,a).next(u=>{if(!u)return r++,s.getEntry(e,a).next(()=>(s.removeEntry(a,ee.min()),Yn(e).delete(function(p){return[0,At(p.path)]}(a))))});i.push(l)}}).next(()=>C.waitFor(i)).next(()=>s.apply(e)).next(()=>r)}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,s)}updateLimboDocument(e,t){return ho(e,t)}Xn(e,t){const s=Yn(e);let i,r=Nt.oe;return s.J({index:"documentTargetsIndex"},([a,o],{path:l,sequenceNumber:u})=>{a===0?(r!==Nt.oe&&t(new j(on(i)),r),r=u,i=l):r=Nt.oe}).next(()=>{r!==Nt.oe&&t(new j(on(i)),r)})}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function ho(n,e){return Yn(n).put(function(s,i){return{targetId:0,path:At(s.path),sequenceNumber:i}}(e,n.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _v{constructor(){this.changes=new bs(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,He.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?C.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sk{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,s){return Ss(e).put(s)}removeEntry(e,t,s){return Ss(e).delete(function(r,a){const o=r.path.toArray();return[o.slice(0,o.length-2),o[o.length-2],nc(a),o[o.length-1]]}(t,s))}updateMetadata(e,t){return this.getMetadata(e).next(s=>(s.byteSize+=t,this.tr(e,s)))}getEntry(e,t){let s=He.newInvalidDocument(t);return Ss(e).J({index:"documentKeyIndex",range:IDBKeyRange.only($r(t))},(i,r)=>{s=this.nr(t,r)}).next(()=>s)}rr(e,t){let s={size:0,document:He.newInvalidDocument(t)};return Ss(e).J({index:"documentKeyIndex",range:IDBKeyRange.only($r(t))},(i,r)=>{s={document:this.nr(t,r),size:ic(r)}}).next(()=>s)}getEntries(e,t){let s=Ft();return this.ir(e,t,(i,r)=>{const a=this.nr(i,r);s=s.insert(i,a)}).next(()=>s)}sr(e,t){let s=Ft(),i=new Le(j.comparator);return this.ir(e,t,(r,a)=>{const o=this.nr(r,a);s=s.insert(r,o),i=i.insert(r,ic(a))}).next(()=>({documents:s,_r:i}))}ir(e,t,s){if(t.isEmpty())return C.resolve();let i=new De(em);t.forEach(l=>i=i.add(l));const r=IDBKeyRange.bound($r(i.first()),$r(i.last())),a=i.getIterator();let o=a.getNext();return Ss(e).J({index:"documentKeyIndex",range:r},(l,u,h)=>{const p=j.fromSegments([...u.prefixPath,u.collectionGroup,u.documentId]);for(;o&&em(o,p)<0;)s(o,null),o=a.getNext();o&&o.isEqual(p)&&(s(o,u),o=a.hasNext()?a.getNext():null),o?h.$($r(o)):h.done()}).next(()=>{for(;o;)s(o,null),o=a.hasNext()?a.getNext():null})}getDocumentsMatchingQuery(e,t,s,i,r){const a=t.path,o=[a.popLast().toArray(),a.lastSegment(),nc(s.readTime),s.documentKey.path.isEmpty()?"":s.documentKey.path.lastSegment()],l=[a.popLast().toArray(),a.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return Ss(e).U(IDBKeyRange.bound(o,l,!0)).next(u=>{r==null||r.incrementDocumentReadCount(u.length);let h=Ft();for(const p of u){const m=this.nr(j.fromSegments(p.prefixPath.concat(p.collectionGroup,p.documentId)),p);m.isFoundDocument()&&(Na(t,m)||i.has(m.key))&&(h=h.insert(m.key,m))}return h})}getAllFromCollectionGroup(e,t,s,i){let r=Ft();const a=Zp(t,s),o=Zp(t,jt.max());return Ss(e).J({index:"collectionGroupIndex",range:IDBKeyRange.bound(a,o,!0)},(l,u,h)=>{const p=this.nr(j.fromSegments(u.prefixPath.concat(u.collectionGroup,u.documentId)),u);r=r.insert(p.key,p),r.size===i&&h.done()}).next(()=>r)}newChangeBuffer(e){return new Ak(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next(t=>t.byteSize)}getMetadata(e){return Xp(e).get("remoteDocumentGlobalKey").next(t=>(Z(!!t),t))}tr(e,t){return Xp(e).put("remoteDocumentGlobalKey",t)}nr(e,t){if(t){const s=dk(this.serializer,t);if(!(s.isNoDocument()&&s.version.isEqual(ee.min())))return s}return He.newInvalidDocument(e)}}function wv(n){return new Sk(n)}class Ak extends _v{constructor(e,t){super(),this.ar=e,this.trackRemovals=t,this.ur=new bs(s=>s.toString(),(s,i)=>s.isEqual(i))}applyChanges(e){const t=[];let s=0,i=new De((r,a)=>re(r.canonicalString(),a.canonicalString()));return this.changes.forEach((r,a)=>{const o=this.ur.get(r);if(t.push(this.ar.removeEntry(e,r,o.readTime)),a.isValidDocument()){const l=Lp(this.ar.serializer,a);i=i.add(r.path.popLast());const u=ic(l);s+=u-o.size,t.push(this.ar.addEntry(e,r,l))}else if(s-=o.size,this.trackRemovals){const l=Lp(this.ar.serializer,a.convertToNoDocument(ee.min()));t.push(this.ar.addEntry(e,r,l))}}),i.forEach(r=>{t.push(this.ar.indexManager.addToCollectionParentIndex(e,r))}),t.push(this.ar.updateMetadata(e,s)),C.waitFor(t)}getFromCache(e,t){return this.ar.rr(e,t).next(s=>(this.ur.set(t,{size:s.size,readTime:s.document.readTime}),s.document))}getAllFromCache(e,t){return this.ar.sr(e,t).next(({documents:s,_r:i})=>(i.forEach((r,a)=>{this.ur.set(r,{size:a,readTime:s.get(r).readTime})}),s))}}function Xp(n){return lt(n,"remoteDocumentGlobal")}function Ss(n){return lt(n,"remoteDocumentsV14")}function $r(n){const e=n.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function Zp(n,e){const t=e.documentKey.path.toArray();return[n,nc(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function em(n,e){const t=n.path.toArray(),s=e.path.toArray();let i=0;for(let r=0;r<t.length-2&&r<s.length-2;++r)if(i=re(t[r],s[r]),i)return i;return i=re(t.length,s.length),i||(i=re(t[t.length-2],s[s.length-2]),i||re(t[t.length-1],s[s.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pk{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Iv{constructor(e,t,s,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=i}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(s=i,this.remoteDocumentCache.getEntry(e,t))).next(i=>(s!==null&&Kr(s.mutation,i,xt.empty(),Be.now()),i))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.getLocalViewOfDocuments(e,s,le()).next(()=>s))}getLocalViewOfDocuments(e,t,s=le()){const i=cn();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,s).next(r=>{let a=Lr();return r.forEach((o,l)=>{a=a.insert(o,l.overlayedDocument)}),a}))}getOverlayedDocuments(e,t){const s=cn();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,le()))}populateOverlays(e,t,s){const i=[];return s.forEach(r=>{t.has(r)||i.push(r)}),this.documentOverlayCache.getOverlays(e,i).next(r=>{r.forEach((a,o)=>{t.set(a,o)})})}computeViews(e,t,s,i){let r=Ft();const a=Gr(),o=function(){return Gr()}();return t.forEach((l,u)=>{const h=s.get(u.key);i.has(u.key)&&(h===void 0||h.mutation instanceof xn)?r=r.insert(u.key,u):h!==void 0?(a.set(u.key,h.mutation.getFieldMask()),Kr(h.mutation,u,h.mutation.getFieldMask(),Be.now())):a.set(u.key,xt.empty())}),this.recalculateAndSaveOverlays(e,r).next(l=>(l.forEach((u,h)=>a.set(u,h)),t.forEach((u,h)=>{var p;return o.set(u,new Pk(h,(p=a.get(u))!==null&&p!==void 0?p:null))}),o))}recalculateAndSaveOverlays(e,t){const s=Gr();let i=new Le((a,o)=>a-o),r=le();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(a=>{for(const o of a)o.keys().forEach(l=>{const u=t.get(l);if(u===null)return;let h=s.get(l)||xt.empty();h=o.applyToLocalView(u,h),s.set(l,h);const p=(i.get(o.batchId)||le()).add(l);i=i.insert(o.batchId,p)})}).next(()=>{const a=[],o=i.getReverseIterator();for(;o.hasNext();){const l=o.getNext(),u=l.key,h=l.value,p=jy();h.forEach(m=>{if(!r.has(m)){const w=Qy(t.get(m),s.get(m));w!==null&&p.set(m,w),r=r.add(m)}}),a.push(this.documentOverlayCache.saveOverlays(e,u,p))}return C.waitFor(a)}).next(()=>s)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.recalculateAndSaveOverlays(e,s))}getDocumentsMatchingQuery(e,t,s,i){return function(a){return j.isDocumentKey(a.path)&&a.collectionGroup===null&&a.filters.length===0}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):Oy(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,i):this.getDocumentsMatchingCollectionQuery(e,t,s,i)}getNextDocuments(e,t,s,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,i).next(r=>{const a=i-r.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,i-r.size):C.resolve(cn());let o=-1,l=r;return a.next(u=>C.forEach(u,(h,p)=>(o<p.largestBatchId&&(o=p.largestBatchId),r.get(h)?C.resolve():this.remoteDocumentCache.getEntry(e,h).next(m=>{l=l.insert(h,m)}))).next(()=>this.populateOverlays(e,u,r)).next(()=>this.computeViews(e,l,u,le())).next(h=>({batchId:o,changes:qy(h)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new j(t)).next(s=>{let i=Lr();return s.isFoundDocument()&&(i=i.insert(s.key,s)),i})}getDocumentsMatchingCollectionGroupQuery(e,t,s,i){const r=t.collectionGroup;let a=Lr();return this.indexManager.getCollectionParents(e,r).next(o=>C.forEach(o,l=>{const u=function(p,m){return new rr(m,null,p.explicitOrderBy.slice(),p.filters.slice(),p.limit,p.limitType,p.startAt,p.endAt)}(t,l.child(r));return this.getDocumentsMatchingCollectionQuery(e,u,s,i).next(h=>{h.forEach((p,m)=>{a=a.insert(p,m)})})}).next(()=>a))}getDocumentsMatchingCollectionQuery(e,t,s,i){let r;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next(a=>(r=a,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,r,i))).next(a=>{r.forEach((l,u)=>{const h=u.getKey();a.get(h)===null&&(a=a.insert(h,He.newInvalidDocument(h)))});let o=Lr();return a.forEach((l,u)=>{const h=r.get(l);h!==void 0&&Kr(h.mutation,u,xt.empty(),Be.now()),Na(t,u)&&(o=o.insert(l,u))}),o})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rk{constructor(e){this.serializer=e,this.cr=new Map,this.lr=new Map}getBundleMetadata(e,t){return C.resolve(this.cr.get(t))}saveBundleMetadata(e,t){return this.cr.set(t.id,function(i){return{id:i.id,version:i.version,createTime:Pt(i.createTime)}}(t)),C.resolve()}getNamedQuery(e,t){return C.resolve(this.lr.get(t))}saveNamedQuery(e,t){return this.lr.set(t.name,function(i){return{name:i.name,query:pv(i.bundledQuery),readTime:Pt(i.readTime)}}(t)),C.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $k{constructor(){this.overlays=new Le(j.comparator),this.hr=new Map}getOverlay(e,t){return C.resolve(this.overlays.get(t))}getOverlays(e,t){const s=cn();return C.forEach(t,i=>this.getOverlay(e,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(e,t,s){return s.forEach((i,r)=>{this.ht(e,t,r)}),C.resolve()}removeOverlaysForBatchId(e,t,s){const i=this.hr.get(s);return i!==void 0&&(i.forEach(r=>this.overlays=this.overlays.remove(r)),this.hr.delete(s)),C.resolve()}getOverlaysForCollection(e,t,s){const i=cn(),r=t.length+1,a=new j(t.child("")),o=this.overlays.getIteratorFrom(a);for(;o.hasNext();){const l=o.getNext().value,u=l.getKey();if(!t.isPrefixOf(u.path))break;u.path.length===r&&l.largestBatchId>s&&i.set(l.getKey(),l)}return C.resolve(i)}getOverlaysForCollectionGroup(e,t,s,i){let r=new Le((u,h)=>u-h);const a=this.overlays.getIterator();for(;a.hasNext();){const u=a.getNext().value;if(u.getKey().getCollectionGroup()===t&&u.largestBatchId>s){let h=r.get(u.largestBatchId);h===null&&(h=cn(),r=r.insert(u.largestBatchId,h)),h.set(u.getKey(),u)}}const o=cn(),l=r.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((u,h)=>o.set(u,h)),!(o.size()>=i)););return C.resolve(o)}ht(e,t,s){const i=this.overlays.get(s.key);if(i!==null){const a=this.hr.get(i.largestBatchId).delete(s.key);this.hr.set(i.largestBatchId,a)}this.overlays=this.overlays.insert(s.key,new md(t,s));let r=this.hr.get(t);r===void 0&&(r=le(),this.hr.set(t,r)),this.hr.set(t,r.add(s.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _d{constructor(){this.Pr=new De(ot.Ir),this.Tr=new De(ot.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(e,t){const s=new ot(e,t);this.Pr=this.Pr.add(s),this.Tr=this.Tr.add(s)}dr(e,t){e.forEach(s=>this.addReference(s,t))}removeReference(e,t){this.Ar(new ot(e,t))}Rr(e,t){e.forEach(s=>this.removeReference(s,t))}Vr(e){const t=new j(new ke([])),s=new ot(t,e),i=new ot(t,e+1),r=[];return this.Tr.forEachInRange([s,i],a=>{this.Ar(a),r.push(a.key)}),r}mr(){this.Pr.forEach(e=>this.Ar(e))}Ar(e){this.Pr=this.Pr.delete(e),this.Tr=this.Tr.delete(e)}gr(e){const t=new j(new ke([])),s=new ot(t,e),i=new ot(t,e+1);let r=le();return this.Tr.forEachInRange([s,i],a=>{r=r.add(a.key)}),r}containsKey(e){const t=new ot(e,0),s=this.Pr.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class ot{constructor(e,t){this.key=e,this.pr=t}static Ir(e,t){return j.comparator(e.key,t.key)||re(e.pr,t.pr)}static Er(e,t){return re(e.pr,t.pr)||j.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ck{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.yr=1,this.wr=new De(ot.Ir)}checkEmpty(e){return C.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,i){const r=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const a=new fd(r,t,s,i);this.mutationQueue.push(a);for(const o of i)this.wr=this.wr.add(new ot(o.key,r)),this.indexManager.addToCollectionParentIndex(e,o.key.path.popLast());return C.resolve(a)}lookupMutationBatch(e,t){return C.resolve(this.Sr(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,i=this.br(s),r=i<0?0:i;return C.resolve(this.mutationQueue.length>r?this.mutationQueue[r]:null)}getHighestUnacknowledgedBatchId(){return C.resolve(this.mutationQueue.length===0?-1:this.yr-1)}getAllMutationBatches(e){return C.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new ot(t,0),i=new ot(t,Number.POSITIVE_INFINITY),r=[];return this.wr.forEachInRange([s,i],a=>{const o=this.Sr(a.pr);r.push(o)}),C.resolve(r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new De(re);return t.forEach(i=>{const r=new ot(i,0),a=new ot(i,Number.POSITIVE_INFINITY);this.wr.forEachInRange([r,a],o=>{s=s.add(o.pr)})}),C.resolve(this.Dr(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,i=s.length+1;let r=s;j.isDocumentKey(r)||(r=r.child(""));const a=new ot(new j(r),0);let o=new De(re);return this.wr.forEachWhile(l=>{const u=l.key.path;return!!s.isPrefixOf(u)&&(u.length===i&&(o=o.add(l.pr)),!0)},a),C.resolve(this.Dr(o))}Dr(e){const t=[];return e.forEach(s=>{const i=this.Sr(s);i!==null&&t.push(i)}),t}removeMutationBatch(e,t){Z(this.Cr(t.batchId,"removed")===0),this.mutationQueue.shift();let s=this.wr;return C.forEach(t.mutations,i=>{const r=new ot(i.key,t.batchId);return s=s.delete(r),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.wr=s})}Mn(e){}containsKey(e,t){const s=new ot(t,0),i=this.wr.firstAfterOrEqual(s);return C.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,C.resolve()}Cr(e,t){return this.br(e)}br(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Sr(e){const t=this.br(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dk{constructor(e){this.vr=e,this.docs=function(){return new Le(j.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,i=this.docs.get(s),r=i?i.size:0,a=this.vr(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:a}),this.size+=a-r,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return C.resolve(s?s.document.mutableCopy():He.newInvalidDocument(t))}getEntries(e,t){let s=Ft();return t.forEach(i=>{const r=this.docs.get(i);s=s.insert(i,r?r.document.mutableCopy():He.newInvalidDocument(i))}),C.resolve(s)}getDocumentsMatchingQuery(e,t,s,i){let r=Ft();const a=t.path,o=new j(a.child("")),l=this.docs.getIteratorFrom(o);for(;l.hasNext();){const{key:u,value:{document:h}}=l.getNext();if(!a.isPrefixOf(u.path))break;u.path.length>a.length+1||od(py(h),s)<=0||(i.has(h.key)||Na(t,h))&&(r=r.insert(h.key,h.mutableCopy()))}return C.resolve(r)}getAllFromCollectionGroup(e,t,s,i){K()}Fr(e,t){return C.forEach(this.docs,s=>t(s))}newChangeBuffer(e){return new Nk(this)}getSize(e){return C.resolve(this.size)}}class Nk extends _v{constructor(e){super(),this.ar=e}applyChanges(e){const t=[];return this.changes.forEach((s,i)=>{i.isValidDocument()?t.push(this.ar.addEntry(e,i)):this.ar.removeEntry(s)}),C.waitFor(t)}getFromCache(e,t){return this.ar.getEntry(e,t)}getAllFromCache(e,t){return this.ar.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xk{constructor(e){this.persistence=e,this.Mr=new bs(t=>Gs(t),Ca),this.lastRemoteSnapshotVersion=ee.min(),this.highestTargetId=0,this.Or=0,this.Nr=new _d,this.targetCount=0,this.Lr=Qs.Nn()}forEachTarget(e,t){return this.Mr.forEach((s,i)=>t(i)),C.resolve()}getLastRemoteSnapshotVersion(e){return C.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return C.resolve(this.Or)}allocateTargetId(e){return this.highestTargetId=this.Lr.next(),C.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.Or&&(this.Or=t),C.resolve()}qn(e){this.Mr.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Lr=new Qs(t),this.highestTargetId=t),e.sequenceNumber>this.Or&&(this.Or=e.sequenceNumber)}addTargetData(e,t){return this.qn(t),this.targetCount+=1,C.resolve()}updateTargetData(e,t){return this.qn(t),C.resolve()}removeTargetData(e,t){return this.Mr.delete(t.target),this.Nr.Vr(t.targetId),this.targetCount-=1,C.resolve()}removeTargets(e,t,s){let i=0;const r=[];return this.Mr.forEach((a,o)=>{o.sequenceNumber<=t&&s.get(o.targetId)===null&&(this.Mr.delete(a),r.push(this.removeMatchingKeysForTargetId(e,o.targetId)),i++)}),C.waitFor(r).next(()=>i)}getTargetCount(e){return C.resolve(this.targetCount)}getTargetData(e,t){const s=this.Mr.get(t)||null;return C.resolve(s)}addMatchingKeys(e,t,s){return this.Nr.dr(t,s),C.resolve()}removeMatchingKeys(e,t,s){this.Nr.Rr(t,s);const i=this.persistence.referenceDelegate,r=[];return i&&t.forEach(a=>{r.push(i.markPotentiallyOrphaned(e,a))}),C.waitFor(r)}removeMatchingKeysForTargetId(e,t){return this.Nr.Vr(t),C.resolve()}getMatchingKeysForTargetId(e,t){const s=this.Nr.gr(t);return C.resolve(s)}containsKey(e,t){return C.resolve(this.Nr.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ev{constructor(e,t){this.Br={},this.overlays={},this.kr=new Nt(0),this.qr=!1,this.qr=!0,this.referenceDelegate=e(this),this.Qr=new xk(this),this.indexManager=new vk,this.remoteDocumentCache=function(i){return new Dk(i)}(s=>this.referenceDelegate.Kr(s)),this.serializer=new hv(t),this.$r=new Rk(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new $k,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this.Br[e.toKey()];return s||(s=new Ck(t,this.referenceDelegate),this.Br[e.toKey()]=s),s}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(e,t,s){V("MemoryPersistence","Starting transaction:",e);const i=new Vk(this.kr.next());return this.referenceDelegate.Ur(),s(i).next(r=>this.referenceDelegate.Wr(i).next(()=>r)).toPromise().then(r=>(i.raiseOnCommittedEvent(),r))}Gr(e,t){return C.or(Object.values(this.Br).map(s=>()=>s.containsKey(e,t)))}}class Vk extends gy{constructor(e){super(),this.currentSequenceNumber=e}}class qc{constructor(e){this.persistence=e,this.zr=new _d,this.jr=null}static Hr(e){return new qc(e)}get Jr(){if(this.jr)return this.jr;throw K()}addReference(e,t,s){return this.zr.addReference(s,t),this.Jr.delete(s.toString()),C.resolve()}removeReference(e,t,s){return this.zr.removeReference(s,t),this.Jr.add(s.toString()),C.resolve()}markPotentiallyOrphaned(e,t){return this.Jr.add(t.toString()),C.resolve()}removeTarget(e,t){this.zr.Vr(t.targetId).forEach(i=>this.Jr.add(i.toString()));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next(i=>{i.forEach(r=>this.Jr.add(r.toString()))}).next(()=>s.removeTargetData(e,t))}Ur(){this.jr=new Set}Wr(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return C.forEach(this.Jr,s=>{const i=j.fromPath(s);return this.Yr(e,i).next(r=>{r||t.removeEntry(i,ee.min())})}).next(()=>(this.jr=null,t.apply(e)))}updateLimboDocument(e,t){return this.Yr(e,t).next(s=>{s?this.Jr.delete(t.toString()):this.Jr.add(t.toString())})}Kr(e){return 0}Yr(e,t){return C.or([()=>C.resolve(this.zr.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gr(e,t)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ok{constructor(e){this.serializer=e}O(e,t,s,i){const r=new Nc("createOrUpgrade",t);s<1&&i>=1&&(function(l){l.createObjectStore("owner")}(e),function(l){l.createObjectStore("mutationQueues",{keyPath:"userId"}),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",mp,{unique:!0}),l.createObjectStore("documentMutations")}(e),tm(e),function(l){l.createObjectStore("remoteDocuments")}(e));let a=C.resolve();return s<3&&i>=3&&(s!==0&&(function(l){l.deleteObjectStore("targetDocuments"),l.deleteObjectStore("targets"),l.deleteObjectStore("targetGlobal")}(e),tm(e)),a=a.next(()=>function(l){const u=l.store("targetGlobal"),h={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:ee.min().toTimestamp(),targetCount:0};return u.put("targetGlobalKey",h)}(r))),s<4&&i>=4&&(s!==0&&(a=a.next(()=>function(l,u){return u.store("mutations").U().next(h=>{l.deleteObjectStore("mutations"),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",mp,{unique:!0});const p=u.store("mutations"),m=h.map(w=>p.put(w));return C.waitFor(m)})}(e,r))),a=a.next(()=>{(function(l){l.createObjectStore("clientMetadata",{keyPath:"clientId"})})(e)})),s<5&&i>=5&&(a=a.next(()=>this.Xr(r))),s<6&&i>=6&&(a=a.next(()=>(function(l){l.createObjectStore("remoteDocumentGlobal")}(e),this.ei(r)))),s<7&&i>=7&&(a=a.next(()=>this.ti(r))),s<8&&i>=8&&(a=a.next(()=>this.ni(e,r))),s<9&&i>=9&&(a=a.next(()=>{(function(l){l.objectStoreNames.contains("remoteDocumentChanges")&&l.deleteObjectStore("remoteDocumentChanges")})(e)})),s<10&&i>=10&&(a=a.next(()=>this.ri(r))),s<11&&i>=11&&(a=a.next(()=>{(function(l){l.createObjectStore("bundles",{keyPath:"bundleId"})})(e),function(l){l.createObjectStore("namedQueries",{keyPath:"name"})}(e)})),s<12&&i>=12&&(a=a.next(()=>{(function(l){const u=l.createObjectStore("documentOverlays",{keyPath:gT});u.createIndex("collectionPathOverlayIndex",yT,{unique:!1}),u.createIndex("collectionGroupOverlayIndex",vT,{unique:!1})})(e)})),s<13&&i>=13&&(a=a.next(()=>function(l){const u=l.createObjectStore("remoteDocumentsV14",{keyPath:rT});u.createIndex("documentKeyIndex",aT),u.createIndex("collectionGroupIndex",oT)}(e)).next(()=>this.ii(e,r)).next(()=>e.deleteObjectStore("remoteDocuments"))),s<14&&i>=14&&(a=a.next(()=>this.si(e,r))),s<15&&i>=15&&(a=a.next(()=>function(l){l.createObjectStore("indexConfiguration",{keyPath:"indexId",autoIncrement:!0}).createIndex("collectionGroupIndex","collectionGroup",{unique:!1}),l.createObjectStore("indexState",{keyPath:hT}).createIndex("sequenceNumberIndex",fT,{unique:!1}),l.createObjectStore("indexEntries",{keyPath:pT}).createIndex("documentKeyIndex",mT,{unique:!1})}(e))),s<16&&i>=16&&(a=a.next(()=>{t.objectStore("indexState").clear()}).next(()=>{t.objectStore("indexEntries").clear()})),a}ei(e){let t=0;return e.store("remoteDocuments").J((s,i)=>{t+=ic(i)}).next(()=>{const s={byteSize:t};return e.store("remoteDocumentGlobal").put("remoteDocumentGlobalKey",s)})}Xr(e){const t=e.store("mutationQueues"),s=e.store("mutations");return t.U().next(i=>C.forEach(i,r=>{const a=IDBKeyRange.bound([r.userId,-1],[r.userId,r.lastAcknowledgedBatchId]);return s.U("userMutationsIndex",a).next(o=>C.forEach(o,l=>{Z(l.userId===r.userId);const u=$s(this.serializer,l);return yv(e,r.userId,u).next(()=>{})}))}))}ti(e){const t=e.store("targetDocuments"),s=e.store("remoteDocuments");return e.store("targetGlobal").get("targetGlobalKey").next(i=>{const r=[];return s.J((a,o)=>{const l=new ke(a),u=function(p){return[0,At(p)]}(l);r.push(t.get(u).next(h=>h?C.resolve():(p=>t.put({targetId:0,path:At(p),sequenceNumber:i.highestListenSequenceNumber}))(l)))}).next(()=>C.waitFor(r))})}ni(e,t){e.createObjectStore("collectionParents",{keyPath:dT});const s=t.store("collectionParents"),i=new bd,r=a=>{if(i.add(a)){const o=a.lastSegment(),l=a.popLast();return s.put({collectionId:o,parent:At(l)})}};return t.store("remoteDocuments").J({H:!0},(a,o)=>{const l=new ke(a);return r(l.popLast())}).next(()=>t.store("documentMutations").J({H:!0},([a,o,l],u)=>{const h=on(o);return r(h.popLast())}))}ri(e){const t=e.store("targets");return t.J((s,i)=>{const r=Ur(i),a=fv(this.serializer,r);return t.put(a)})}ii(e,t){const s=t.store("remoteDocuments"),i=[];return s.J((r,a)=>{const o=t.store("remoteDocumentsV14"),l=function(p){return p.document?new j(ke.fromString(p.document.name).popFirst(5)):p.noDocument?j.fromSegments(p.noDocument.path):p.unknownDocument?j.fromSegments(p.unknownDocument.path):K()}(a).path.toArray(),u={prefixPath:l.slice(0,l.length-2),collectionGroup:l[l.length-2],documentId:l[l.length-1],readTime:a.readTime||[0,0],unknownDocument:a.unknownDocument,noDocument:a.noDocument,document:a.document,hasCommittedMutations:!!a.hasCommittedMutations};i.push(o.put(u))}).next(()=>C.waitFor(i))}si(e,t){const s=t.store("mutations"),i=wv(this.serializer),r=new Ev(qc.Hr,this.serializer.ct);return s.U().next(a=>{const o=new Map;return a.forEach(l=>{var u;let h=(u=o.get(l.userId))!==null&&u!==void 0?u:le();$s(this.serializer,l).keys().forEach(p=>h=h.add(p)),o.set(l.userId,h)}),C.forEach(o,(l,u)=>{const h=new _t(u),p=Fc.lt(this.serializer,h),m=r.getIndexManager(h),w=Uc.lt(h,this.serializer,m,r.referenceDelegate);return new Iv(i,w,p,m).recalculateAndSaveOverlaysForDocumentKeys(new fu(t,Nt.oe),l).next()})})}}function tm(n){n.createObjectStore("targetDocuments",{keyPath:lT}).createIndex("documentTargetsIndex",uT,{unique:!0}),n.createObjectStore("targets",{keyPath:"targetId"}).createIndex("queryTargetsIndex",cT,{unique:!0}),n.createObjectStore("targetGlobal")}const Ml="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class wd{constructor(e,t,s,i,r,a,o,l,u,h,p=16){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=s,this.oi=r,this.window=a,this.document=o,this._i=u,this.ai=h,this.ui=p,this.kr=null,this.qr=!1,this.isPrimary=!1,this.networkEnabled=!0,this.ci=null,this.inForeground=!1,this.li=null,this.hi=null,this.Pi=Number.NEGATIVE_INFINITY,this.Ii=m=>Promise.resolve(),!wd.D())throw new L(x.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new kk(this,i),this.Ti=t+"main",this.serializer=new hv(l),this.Ei=new is(this.Ti,this.ui,new Ok(this.serializer)),this.Qr=new _k(this.referenceDelegate,this.serializer),this.remoteDocumentCache=wv(this.serializer),this.$r=new hk,this.window&&this.window.localStorage?this.di=this.window.localStorage:(this.di=null,h===!1&&Xe("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ai().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new L(x.FAILED_PRECONDITION,Ml);return this.Ri(),this.Vi(),this.mi(),this.runTransaction("getHighestListenSequenceNumber","readonly",e=>this.Qr.getHighestSequenceNumber(e))}).then(e=>{this.kr=new Nt(e,this._i)}).then(()=>{this.qr=!0}).catch(e=>(this.Ei&&this.Ei.close(),Promise.reject(e)))}fi(e){return this.Ii=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.Ei.L(async t=>{t.newVersion===null&&await e()})}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.oi.enqueueAndForget(async()=>{this.started&&await this.Ai()}))}Ai(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",e=>fo(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.gi(e).next(t=>{t||(this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)))})}).next(()=>this.pi(e)).next(t=>this.isPrimary&&!t?this.yi(e).next(()=>!1):!!t&&this.wi(e).next(()=>!0))).catch(e=>{if(vs(e))return V("IndexedDbPersistence","Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return V("IndexedDbPersistence","Releasing owner lease after error during lease refresh",e),!1}).then(e=>{this.isPrimary!==e&&this.oi.enqueueRetryable(()=>this.Ii(e)),this.isPrimary=e})}gi(e){return Cr(e).get("owner").next(t=>C.resolve(this.Si(t)))}bi(e){return fo(e).delete(this.clientId)}async Di(){if(this.isPrimary&&!this.Ci(this.Pi,18e5)){this.Pi=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const s=lt(t,"clientMetadata");return s.U().next(i=>{const r=this.vi(i,18e5),a=i.filter(o=>r.indexOf(o)===-1);return C.forEach(a,o=>s.delete(o.clientId)).next(()=>a)})}).catch(()=>[]);if(this.di)for(const t of e)this.di.removeItem(this.Fi(t.clientId))}}mi(){this.hi=this.oi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Ai().then(()=>this.Di()).then(()=>this.mi()))}Si(e){return!!e&&e.ownerId===this.clientId}pi(e){return this.ai?C.resolve(!0):Cr(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)){if(this.Si(t)&&this.networkEnabled)return!0;if(!this.Si(t)){if(!t.allowTabSynchronization)throw new L(x.FAILED_PRECONDITION,Ml);return!1}}return!(!this.networkEnabled||!this.inForeground)||fo(e).U().next(s=>this.vi(s,5e3).find(i=>{if(this.clientId!==i.clientId){const r=!this.networkEnabled&&i.networkEnabled,a=!this.inForeground&&i.inForeground,o=this.networkEnabled===i.networkEnabled;if(r||a&&o)return!0}return!1})===void 0)}).next(t=>(this.isPrimary!==t&&V("IndexedDbPersistence",`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.qr=!1,this.xi(),this.hi&&(this.hi.cancel(),this.hi=null),this.Oi(),this.Ni(),await this.Ei.runTransaction("shutdown","readwrite",["owner","clientMetadata"],e=>{const t=new fu(e,Nt.oe);return this.yi(t).next(()=>this.bi(t))}),this.Ei.close(),this.Li()}vi(e,t){return e.filter(s=>this.Ci(s.updateTimeMs,t)&&!this.Mi(s.clientId))}Bi(){return this.runTransaction("getActiveClients","readonly",e=>fo(e).U().next(t=>this.vi(t,18e5).map(s=>s.clientId)))}get started(){return this.qr}getMutationQueue(e,t){return Uc.lt(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new bk(e,this.serializer.ct.databaseId)}getDocumentOverlayCache(e){return Fc.lt(this.serializer,e)}getBundleCache(){return this.$r}runTransaction(e,t,s){V("IndexedDbPersistence","Starting transaction:",e);const i=t==="readonly"?"readonly":"readwrite",r=function(l){return l===16?_T:l===15?Ey:l===14?Iy:l===13?wy:l===12?bT:l===11?_y:void K()}(this.ui);let a;return this.Ei.runTransaction(e,i,r,o=>(a=new fu(o,this.kr?this.kr.next():Nt.oe),t==="readwrite-primary"?this.gi(a).next(l=>!!l||this.pi(a)).next(l=>{if(!l)throw Xe(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)),new L(x.FAILED_PRECONDITION,my);return s(a)}).next(l=>this.wi(a).next(()=>l)):this.ki(a).next(()=>s(a)))).then(o=>(a.raiseOnCommittedEvent(),o))}ki(e){return Cr(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)&&!this.Si(t)&&!(this.ai||this.allowTabSynchronization&&t.allowTabSynchronization))throw new L(x.FAILED_PRECONDITION,Ml)})}wi(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return Cr(e).put("owner",t)}static D(){return is.D()}yi(e){const t=Cr(e);return t.get("owner").next(s=>this.Si(s)?(V("IndexedDbPersistence","Releasing primary lease."),t.delete("owner")):C.resolve())}Ci(e,t){const s=Date.now();return!(e<s-t)&&(!(e>s)||(Xe(`Detected an update time that is in the future: ${e} > ${s}`),!1))}Ri(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.li=()=>{this.oi.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.Ai()))},this.document.addEventListener("visibilitychange",this.li),this.inForeground=this.document.visibilityState==="visible")}Oi(){this.li&&(this.document.removeEventListener("visibilitychange",this.li),this.li=null)}Vi(){var e;typeof((e=this.window)===null||e===void 0?void 0:e.addEventListener)=="function"&&(this.ci=()=>{this.xi();const t=/(?:Version|Mobile)\/1[456]/;bg()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.oi.enterRestrictedMode(!0),this.oi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.ci))}Ni(){this.ci&&(this.window.removeEventListener("pagehide",this.ci),this.ci=null)}Mi(e){var t;try{const s=((t=this.di)===null||t===void 0?void 0:t.getItem(this.Fi(e)))!==null;return V("IndexedDbPersistence",`Client '${e}' ${s?"is":"is not"} zombied in LocalStorage`),s}catch(s){return Xe("IndexedDbPersistence","Failed to get zombied client id.",s),!1}}xi(){if(this.di)try{this.di.setItem(this.Fi(this.clientId),String(Date.now()))}catch(e){Xe("Failed to set zombie client id.",e)}}Li(){if(this.di)try{this.di.removeItem(this.Fi(this.clientId))}catch{}}Fi(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function Cr(n){return lt(n,"owner")}function fo(n){return lt(n,"clientMetadata")}function Tv(n,e){let t=n.projectId;return n.isDefaultDatabase||(t+="."+n.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Id{constructor(e,t,s,i){this.targetId=e,this.fromCache=t,this.qi=s,this.Qi=i}static Ki(e,t){let s=le(),i=le();for(const r of t.docChanges)switch(r.type){case 0:s=s.add(r.doc.key);break;case 1:i=i.add(r.doc.key)}return new Id(e,t.fromCache,s,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mk{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kv{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=function(){return bg()?8:yy(et())>0?6:4}()}initialize(e,t){this.zi=e,this.indexManager=t,this.$i=!0}getDocumentsMatchingQuery(e,t,s,i){const r={result:null};return this.ji(e,t).next(a=>{r.result=a}).next(()=>{if(!r.result)return this.Hi(e,t,i,s).next(a=>{r.result=a})}).next(()=>{if(r.result)return;const a=new Mk;return this.Ji(e,t,a).next(o=>{if(r.result=o,this.Ui)return this.Yi(e,t,a,o.size)})}).next(()=>r.result)}Yi(e,t,s,i){return s.documentReadCount<this.Wi?(vi()<=he.DEBUG&&V("QueryEngine","SDK will not create cache indexes for query:",bi(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),C.resolve()):(vi()<=he.DEBUG&&V("QueryEngine","Query:",bi(t),"scans",s.documentReadCount,"local documents and returns",i,"documents as results."),s.documentReadCount>this.Gi*i?(vi()<=he.DEBUG&&V("QueryEngine","The SDK decides to create cache indexes for query:",bi(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,Ut(t))):C.resolve())}ji(e,t){if(Ap(t))return C.resolve(null);let s=Ut(t);return this.indexManager.getIndexType(e,s).next(i=>i===0?null:(t.limit!==null&&i===1&&(t=Zo(t,null,"F"),s=Ut(t)),this.indexManager.getDocumentsMatchingTarget(e,s).next(r=>{const a=le(...r);return this.zi.getDocuments(e,a).next(o=>this.indexManager.getMinOffset(e,s).next(l=>{const u=this.Zi(t,o);return this.Xi(t,u,a,l.readTime)?this.ji(e,Zo(t,null,"F")):this.es(e,u,t,l)}))})))}Hi(e,t,s,i){return Ap(t)||i.isEqual(ee.min())?C.resolve(null):this.zi.getDocuments(e,s).next(r=>{const a=this.Zi(t,r);return this.Xi(t,a,s,i)?C.resolve(null):(vi()<=he.DEBUG&&V("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),bi(t)),this.es(e,a,t,fy(i,-1)).next(o=>o))})}Zi(e,t){let s=new De(Fy(e));return t.forEach((i,r)=>{Na(e,r)&&(s=s.add(r))}),s}Xi(e,t,s,i){if(e.limit===null)return!1;if(s.size!==t.size)return!0;const r=e.limitType==="F"?t.last():t.first();return!!r&&(r.hasPendingWrites||r.version.compareTo(i)>0)}Ji(e,t,s){return vi()<=he.DEBUG&&V("QueryEngine","Using full collection scan to execute query:",bi(t)),this.zi.getDocumentsMatchingQuery(e,t,jt.min(),s)}es(e,t,s,i){return this.zi.getDocumentsMatchingQuery(e,s,i).next(r=>(t.forEach(a=>{r=r.insert(a.key,a)}),r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lk{constructor(e,t,s,i){this.persistence=e,this.ts=t,this.serializer=i,this.ns=new Le(re),this.rs=new bs(r=>Gs(r),Ca),this.ss=new Map,this.os=e.getRemoteDocumentCache(),this.Qr=e.getTargetCache(),this.$r=e.getBundleCache(),this._s(s)}_s(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new Iv(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.ns))}}function Sv(n,e,t,s){return new Lk(n,e,t,s)}async function Av(n,e){const t=Q(n);return await t.persistence.runTransaction("Handle user change","readonly",s=>{let i;return t.mutationQueue.getAllMutationBatches(s).next(r=>(i=r,t._s(e),t.mutationQueue.getAllMutationBatches(s))).next(r=>{const a=[],o=[];let l=le();for(const u of i){a.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}for(const u of r){o.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}return t.localDocuments.getDocuments(s,l).next(u=>({us:u,removedBatchIds:a,addedBatchIds:o}))})})}function Fk(n,e){const t=Q(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",s=>{const i=e.batch.keys(),r=t.os.newChangeBuffer({trackRemovals:!0});return function(o,l,u,h){const p=u.batch,m=p.keys();let w=C.resolve();return m.forEach(E=>{w=w.next(()=>h.getEntry(l,E)).next(N=>{const $=u.docVersions.get(E);Z($!==null),N.version.compareTo($)<0&&(p.applyToRemoteDocument(N,u),N.isValidDocument()&&(N.setReadTime(u.commitVersion),h.addEntry(N)))})}),w.next(()=>o.mutationQueue.removeMutationBatch(l,p))}(t,s,e,r).next(()=>r.apply(s)).next(()=>t.mutationQueue.performConsistencyCheck(s)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(s,i,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,function(o){let l=le();for(let u=0;u<o.mutationResults.length;++u)o.mutationResults[u].transformResults.length>0&&(l=l.add(o.batch.mutations[u].key));return l}(e))).next(()=>t.localDocuments.getDocuments(s,i))})}function Pv(n){const e=Q(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Qr.getLastRemoteSnapshotVersion(t))}function Uk(n,e){const t=Q(n),s=e.snapshotVersion;let i=t.ns;return t.persistence.runTransaction("Apply remote event","readwrite-primary",r=>{const a=t.os.newChangeBuffer({trackRemovals:!0});i=t.ns;const o=[];e.targetChanges.forEach((h,p)=>{const m=i.get(p);if(!m)return;o.push(t.Qr.removeMatchingKeys(r,h.removedDocuments,p).next(()=>t.Qr.addMatchingKeys(r,h.addedDocuments,p)));let w=m.withSequenceNumber(r.currentSequenceNumber);e.targetMismatches.get(p)!==null?w=w.withResumeToken(ct.EMPTY_BYTE_STRING,ee.min()).withLastLimboFreeSnapshotVersion(ee.min()):h.resumeToken.approximateByteSize()>0&&(w=w.withResumeToken(h.resumeToken,s)),i=i.insert(p,w),function(N,$,B){return N.resumeToken.approximateByteSize()===0||$.snapshotVersion.toMicroseconds()-N.snapshotVersion.toMicroseconds()>=3e8?!0:B.addedDocuments.size+B.modifiedDocuments.size+B.removedDocuments.size>0}(m,w,h)&&o.push(t.Qr.updateTargetData(r,w))});let l=Ft(),u=le();if(e.documentUpdates.forEach(h=>{e.resolvedLimboDocuments.has(h)&&o.push(t.persistence.referenceDelegate.updateLimboDocument(r,h))}),o.push(qk(r,a,e.documentUpdates).next(h=>{l=h.cs,u=h.ls})),!s.isEqual(ee.min())){const h=t.Qr.getLastRemoteSnapshotVersion(r).next(p=>t.Qr.setTargetsMetadata(r,r.currentSequenceNumber,s));o.push(h)}return C.waitFor(o).next(()=>a.apply(r)).next(()=>t.localDocuments.getLocalViewOfDocuments(r,l,u)).next(()=>l)}).then(r=>(t.ns=i,r))}function qk(n,e,t){let s=le(),i=le();return t.forEach(r=>s=s.add(r)),e.getEntries(n,s).next(r=>{let a=Ft();return t.forEach((o,l)=>{const u=r.get(o);l.isFoundDocument()!==u.isFoundDocument()&&(i=i.add(o)),l.isNoDocument()&&l.version.isEqual(ee.min())?(e.removeEntry(o,l.readTime),a=a.insert(o,l)):!u.isValidDocument()||l.version.compareTo(u.version)>0||l.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(l),a=a.insert(o,l)):V("LocalStore","Ignoring outdated watch update for ",o,". Current version:",u.version," Watch version:",l.version)}),{cs:a,ls:i}})}function jk(n,e){const t=Q(n);return t.persistence.runTransaction("Get next mutation batch","readonly",s=>(e===void 0&&(e=-1),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e)))}function rc(n,e){const t=Q(n);return t.persistence.runTransaction("Allocate target","readwrite",s=>{let i;return t.Qr.getTargetData(s,e).next(r=>r?(i=r,C.resolve(i)):t.Qr.allocateTargetId(s).next(a=>(i=new $n(e,a,"TargetPurposeListen",s.currentSequenceNumber),t.Qr.addTargetData(s,i).next(()=>i))))}).then(s=>{const i=t.ns.get(s.targetId);return(i===null||s.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(t.ns=t.ns.insert(s.targetId,s),t.rs.set(e,s.targetId)),s})}async function Bi(n,e,t){const s=Q(n),i=s.ns.get(e),r=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",r,a=>s.persistence.referenceDelegate.removeTarget(a,i))}catch(a){if(!vs(a))throw a;V("LocalStore",`Failed to update sequence numbers for target ${e}: ${a}`)}s.ns=s.ns.remove(e),s.rs.delete(i.target)}function Au(n,e,t){const s=Q(n);let i=ee.min(),r=le();return s.persistence.runTransaction("Execute query","readwrite",a=>function(l,u,h){const p=Q(l),m=p.rs.get(h);return m!==void 0?C.resolve(p.ns.get(m)):p.Qr.getTargetData(u,h)}(s,a,Ut(e)).next(o=>{if(o)return i=o.lastLimboFreeSnapshotVersion,s.Qr.getMatchingKeysForTargetId(a,o.targetId).next(l=>{r=l})}).next(()=>s.ts.getDocumentsMatchingQuery(a,e,t?i:ee.min(),t?r:le())).next(o=>(Cv(s,Ly(e),o),{documents:o,hs:r})))}function Rv(n,e){const t=Q(n),s=Q(t.Qr),i=t.ns.get(e);return i?Promise.resolve(i.target):t.persistence.runTransaction("Get target data","readonly",r=>s.ot(r,e).next(a=>a?a.target:null))}function $v(n,e){const t=Q(n),s=t.ss.get(e)||ee.min();return t.persistence.runTransaction("Get new document changes","readonly",i=>t.os.getAllFromCollectionGroup(i,e,fy(s,-1),Number.MAX_SAFE_INTEGER)).then(i=>(Cv(t,e,i),i))}function Cv(n,e,t){let s=n.ss.get(e)||ee.min();t.forEach((i,r)=>{r.readTime.compareTo(s)>0&&(s=r.readTime)}),n.ss.set(e,s)}function nm(n,e){return`firestore_clients_${n}_${e}`}function sm(n,e,t){let s=`firestore_mutations_${n}_${t}`;return e.isAuthenticated()&&(s+=`_${e.uid}`),s}function Ll(n,e){return`firestore_targets_${n}_${e}`}class ac{constructor(e,t,s,i){this.user=e,this.batchId=t,this.state=s,this.error=i}static Es(e,t,s){const i=JSON.parse(s);let r,a=typeof i=="object"&&["pending","acknowledged","rejected"].indexOf(i.state)!==-1&&(i.error===void 0||typeof i.error=="object");return a&&i.error&&(a=typeof i.error.message=="string"&&typeof i.error.code=="string",a&&(r=new L(i.error.code,i.error.message))),a?new ac(e,t,i.state,r):(Xe("SharedClientState",`Failed to parse mutation state for ID '${t}': ${s}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Hr{constructor(e,t,s){this.targetId=e,this.state=t,this.error=s}static Es(e,t){const s=JSON.parse(t);let i,r=typeof s=="object"&&["not-current","current","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return r&&s.error&&(r=typeof s.error.message=="string"&&typeof s.error.code=="string",r&&(i=new L(s.error.code,s.error.message))),r?new Hr(e,s.state,i):(Xe("SharedClientState",`Failed to parse target state for ID '${e}': ${t}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class oc{constructor(e,t){this.clientId=e,this.activeTargetIds=t}static Es(e,t){const s=JSON.parse(t);let i=typeof s=="object"&&s.activeTargetIds instanceof Array,r=hd();for(let a=0;i&&a<s.activeTargetIds.length;++a)i=vy(s.activeTargetIds[a]),r=r.add(s.activeTargetIds[a]);return i?new oc(e,r):(Xe("SharedClientState",`Failed to parse client data for instance '${e}': ${t}`),null)}}class Ed{constructor(e,t){this.clientId=e,this.onlineState=t}static Es(e){const t=JSON.parse(e);return typeof t=="object"&&["Unknown","Online","Offline"].indexOf(t.onlineState)!==-1&&typeof t.clientId=="string"?new Ed(t.clientId,t.onlineState):(Xe("SharedClientState",`Failed to parse online state: ${e}`),null)}}class Pu{constructor(){this.activeTargetIds=hd()}As(e){this.activeTargetIds=this.activeTargetIds.add(e)}Rs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ds(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class Fl{constructor(e,t,s,i,r){this.window=e,this.oi=t,this.persistenceKey=s,this.Vs=i,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.fs=this.gs.bind(this),this.ps=new Le(re),this.started=!1,this.ys=[];const a=s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=r,this.ws=nm(this.persistenceKey,this.Vs),this.Ss=function(l){return`firestore_sequence_number_${l}`}(this.persistenceKey),this.ps=this.ps.insert(this.Vs,new Pu),this.bs=new RegExp(`^firestore_clients_${a}_([^_]*)$`),this.Ds=new RegExp(`^firestore_mutations_${a}_(\\d+)(?:_(.*))?$`),this.Cs=new RegExp(`^firestore_targets_${a}_(\\d+)$`),this.vs=function(l){return`firestore_online_state_${l}`}(this.persistenceKey),this.Fs=function(l){return`firestore_bundle_loaded_v2_${l}`}(this.persistenceKey),this.window.addEventListener("storage",this.fs)}static D(e){return!(!e||!e.localStorage)}async start(){const e=await this.syncEngine.Bi();for(const s of e){if(s===this.Vs)continue;const i=this.getItem(nm(this.persistenceKey,s));if(i){const r=oc.Es(s,i);r&&(this.ps=this.ps.insert(r.clientId,r))}}this.Ms();const t=this.storage.getItem(this.vs);if(t){const s=this.xs(t);s&&this.Os(s)}for(const s of this.ys)this.gs(s);this.ys=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(e){this.setItem(this.Ss,JSON.stringify(e))}getAllActiveQueryTargets(){return this.Ns(this.ps)}isActiveQueryTarget(e){let t=!1;return this.ps.forEach((s,i)=>{i.activeTargetIds.has(e)&&(t=!0)}),t}addPendingMutation(e){this.Ls(e,"pending")}updateMutationState(e,t,s){this.Ls(e,t,s),this.Bs(e)}addLocalQueryTarget(e){let t="not-current";if(this.isActiveQueryTarget(e)){const s=this.storage.getItem(Ll(this.persistenceKey,e));if(s){const i=Hr.Es(e,s);i&&(t=i.state)}}return this.ks.As(e),this.Ms(),t}removeLocalQueryTarget(e){this.ks.Rs(e),this.Ms()}isLocalQueryTarget(e){return this.ks.activeTargetIds.has(e)}clearQueryState(e){this.removeItem(Ll(this.persistenceKey,e))}updateQueryState(e,t,s){this.qs(e,t,s)}handleUserChange(e,t,s){t.forEach(i=>{this.Bs(i)}),this.currentUser=e,s.forEach(i=>{this.addPendingMutation(i)})}setOnlineState(e){this.Qs(e)}notifyBundleLoaded(e){this.Ks(e)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.fs),this.removeItem(this.ws),this.started=!1)}getItem(e){const t=this.storage.getItem(e);return V("SharedClientState","READ",e,t),t}setItem(e,t){V("SharedClientState","SET",e,t),this.storage.setItem(e,t)}removeItem(e){V("SharedClientState","REMOVE",e),this.storage.removeItem(e)}gs(e){const t=e;if(t.storageArea===this.storage){if(V("SharedClientState","EVENT",t.key,t.newValue),t.key===this.ws)return void Xe("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.oi.enqueueRetryable(async()=>{if(this.started){if(t.key!==null){if(this.bs.test(t.key)){if(t.newValue==null){const s=this.$s(t.key);return this.Us(s,null)}{const s=this.Ws(t.key,t.newValue);if(s)return this.Us(s.clientId,s)}}else if(this.Ds.test(t.key)){if(t.newValue!==null){const s=this.Gs(t.key,t.newValue);if(s)return this.zs(s)}}else if(this.Cs.test(t.key)){if(t.newValue!==null){const s=this.js(t.key,t.newValue);if(s)return this.Hs(s)}}else if(t.key===this.vs){if(t.newValue!==null){const s=this.xs(t.newValue);if(s)return this.Os(s)}}else if(t.key===this.Ss){const s=function(r){let a=Nt.oe;if(r!=null)try{const o=JSON.parse(r);Z(typeof o=="number"),a=o}catch(o){Xe("SharedClientState","Failed to read sequence number from WebStorage",o)}return a}(t.newValue);s!==Nt.oe&&this.sequenceNumberHandler(s)}else if(t.key===this.Fs){const s=this.Js(t.newValue);await Promise.all(s.map(i=>this.syncEngine.Ys(i)))}}}else this.ys.push(t)})}}get ks(){return this.ps.get(this.Vs)}Ms(){this.setItem(this.ws,this.ks.ds())}Ls(e,t,s){const i=new ac(this.currentUser,e,t,s),r=sm(this.persistenceKey,this.currentUser,e);this.setItem(r,i.ds())}Bs(e){const t=sm(this.persistenceKey,this.currentUser,e);this.removeItem(t)}Qs(e){const t={clientId:this.Vs,onlineState:e};this.storage.setItem(this.vs,JSON.stringify(t))}qs(e,t,s){const i=Ll(this.persistenceKey,e),r=new Hr(e,t,s);this.setItem(i,r.ds())}Ks(e){const t=JSON.stringify(Array.from(e));this.setItem(this.Fs,t)}$s(e){const t=this.bs.exec(e);return t?t[1]:null}Ws(e,t){const s=this.$s(e);return oc.Es(s,t)}Gs(e,t){const s=this.Ds.exec(e),i=Number(s[1]),r=s[2]!==void 0?s[2]:null;return ac.Es(new _t(r),i,t)}js(e,t){const s=this.Cs.exec(e),i=Number(s[1]);return Hr.Es(i,t)}xs(e){return Ed.Es(e)}Js(e){return JSON.parse(e)}async zs(e){if(e.user.uid===this.currentUser.uid)return this.syncEngine.Zs(e.batchId,e.state,e.error);V("SharedClientState",`Ignoring mutation for non-active user ${e.user.uid}`)}Hs(e){return this.syncEngine.Xs(e.targetId,e.state,e.error)}Us(e,t){const s=t?this.ps.insert(e,t):this.ps.remove(e),i=this.Ns(this.ps),r=this.Ns(s),a=[],o=[];return r.forEach(l=>{i.has(l)||a.push(l)}),i.forEach(l=>{r.has(l)||o.push(l)}),this.syncEngine.eo(a,o).then(()=>{this.ps=s})}Os(e){this.ps.get(e.clientId)&&this.onlineStateHandler(e.onlineState)}Ns(e){let t=hd();return e.forEach((s,i)=>{t=t.unionWith(i.activeTargetIds)}),t}}class Dv{constructor(){this.no=new Pu,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e){return this.no.As(e),this.ro[e]||"not-current"}updateQueryState(e,t,s){this.ro[e]=t}removeLocalQueryTarget(e){this.no.Rs(e)}isLocalQueryTarget(e){return this.no.activeTargetIds.has(e)}clearQueryState(e){delete this.ro[e]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(e){return this.no.activeTargetIds.has(e)}start(){return this.no=new Pu,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bk{io(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class im{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(e){this.uo.push(e)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){V("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const e of this.uo)e(0)}ao(){V("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const e of this.uo)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let po=null;function Ul(){return po===null?po=function(){return 268435456+Math.round(2147483648*Math.random())}():po++,"0x"+po.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wk={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zk{constructor(e){this.lo=e.lo,this.ho=e.ho}Po(e){this.Io=e}To(e){this.Eo=e}Ao(e){this.Ro=e}onMessage(e){this.Vo=e}close(){this.ho()}send(e){this.lo(e)}mo(){this.Io()}fo(){this.Eo()}po(e){this.Ro(e)}yo(e){this.Vo(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bt="WebChannelConnection";class Gk extends class{constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const s=t.ssl?"https":"http",i=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.wo=s+"://"+t.host,this.So=`projects/${i}/databases/${r}`,this.bo=this.databaseId.database==="(default)"?`project_id=${i}`:`project_id=${i}&database_id=${r}`}get Do(){return!1}Co(t,s,i,r,a){const o=Ul(),l=this.vo(t,s.toUriEncodedString());V("RestConnection",`Sending RPC '${t}' ${o}:`,l,i);const u={"google-cloud-resource-prefix":this.So,"x-goog-request-params":this.bo};return this.Fo(u,r,a),this.Mo(t,l,u,i).then(h=>(V("RestConnection",`Received RPC '${t}' ${o}: `,h),h),h=>{throw ra("RestConnection",`RPC '${t}' ${o} failed with error: `,h,"url: ",l,"request:",i),h})}xo(t,s,i,r,a,o){return this.Co(t,s,i,r,a)}Fo(t,s,i){t["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+ir}(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),s&&s.headers.forEach((r,a)=>t[a]=r),i&&i.headers.forEach((r,a)=>t[a]=r)}vo(t,s){const i=Wk[t];return`${this.wo}/v1/${s}:${i}`}terminate(){}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Mo(e,t,s,i){const r=Ul();return new Promise((a,o)=>{const l=new ry;l.setWithCredentials(!0),l.listenOnce(oy.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case Po.NO_ERROR:const h=l.getResponseJson();V(bt,`XHR for RPC '${e}' ${r} received:`,JSON.stringify(h)),a(h);break;case Po.TIMEOUT:V(bt,`RPC '${e}' ${r} timed out`),o(new L(x.DEADLINE_EXCEEDED,"Request time out"));break;case Po.HTTP_ERROR:const p=l.getStatus();if(V(bt,`RPC '${e}' ${r} failed with status:`,p,"response text:",l.getResponseText()),p>0){let m=l.getResponseJson();Array.isArray(m)&&(m=m[0]);const w=m==null?void 0:m.error;if(w&&w.status&&w.message){const E=function($){const B=$.toLowerCase().replace(/_/g,"-");return Object.values(x).indexOf(B)>=0?B:x.UNKNOWN}(w.status);o(new L(E,w.message))}else o(new L(x.UNKNOWN,"Server responded with status "+l.getStatus()))}else o(new L(x.UNAVAILABLE,"Connection failed."));break;default:K()}}finally{V(bt,`RPC '${e}' ${r} completed.`)}});const u=JSON.stringify(i);V(bt,`RPC '${e}' ${r} sending request:`,i),l.send(t,"POST",u,s,15)})}Oo(e,t,s){const i=Ul(),r=[this.wo,"/","google.firestore.v1.Firestore","/",e,"/channel"],a=uy(),o=ly(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.xmlHttpFactory=new ay({})),this.Fo(l.initMessageHeaders,t,s),l.encodeInitMessageHeaders=!0;const h=r.join("");V(bt,`Creating RPC '${e}' stream ${i}: ${h}`,l);const p=a.createWebChannel(h,l);let m=!1,w=!1;const E=new zk({lo:$=>{w?V(bt,`Not sending because RPC '${e}' stream ${i} is closed:`,$):(m||(V(bt,`Opening RPC '${e}' stream ${i} transport.`),p.open(),m=!0),V(bt,`RPC '${e}' stream ${i} sending:`,$),p.send($))},ho:()=>p.close()}),N=($,B,J)=>{$.listen(B,H=>{try{J(H)}catch(ae){setTimeout(()=>{throw ae},0)}})};return N(p,Mr.EventType.OPEN,()=>{w||(V(bt,`RPC '${e}' stream ${i} transport opened.`),E.mo())}),N(p,Mr.EventType.CLOSE,()=>{w||(w=!0,V(bt,`RPC '${e}' stream ${i} transport closed`),E.po())}),N(p,Mr.EventType.ERROR,$=>{w||(w=!0,ra(bt,`RPC '${e}' stream ${i} transport errored:`,$),E.po(new L(x.UNAVAILABLE,"The operation could not be completed")))}),N(p,Mr.EventType.MESSAGE,$=>{var B;if(!w){const J=$.data[0];Z(!!J);const H=J,ae=H.error||((B=H[0])===null||B===void 0?void 0:B.error);if(ae){V(bt,`RPC '${e}' stream ${i} received error:`,ae);const O=ae.status;let U=function(v){const I=Ze[v];if(I!==void 0)return Xy(I)}(O),_=ae.message;U===void 0&&(U=x.INTERNAL,_="Unknown error status: "+O+" with message "+ae.message),w=!0,E.po(new L(U,_)),p.close()}else V(bt,`RPC '${e}' stream ${i} received:`,J),E.yo(J)}}),N(o,cy.STAT_EVENT,$=>{$.stat===du.PROXY?V(bt,`RPC '${e}' stream ${i} detected buffering proxy`):$.stat===du.NOPROXY&&V(bt,`RPC '${e}' stream ${i} detected no buffering proxy`)}),setTimeout(()=>{E.fo()},0),E}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nv(){return typeof window<"u"?window:null}function Vo(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jc(n){return new tk(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xv{constructor(e,t,s=1e3,i=1.5,r=6e4){this.oi=e,this.timerId=t,this.No=s,this.Lo=i,this.Bo=r,this.ko=0,this.qo=null,this.Qo=Date.now(),this.reset()}reset(){this.ko=0}Ko(){this.ko=this.Bo}$o(e){this.cancel();const t=Math.floor(this.ko+this.Uo()),s=Math.max(0,Date.now()-this.Qo),i=Math.max(0,t-s);i>0&&V("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.ko} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.qo=this.oi.enqueueAfterDelay(this.timerId,i,()=>(this.Qo=Date.now(),e())),this.ko*=this.Lo,this.ko<this.No&&(this.ko=this.No),this.ko>this.Bo&&(this.ko=this.Bo)}Wo(){this.qo!==null&&(this.qo.skipDelay(),this.qo=null)}cancel(){this.qo!==null&&(this.qo.cancel(),this.qo=null)}Uo(){return(Math.random()-.5)*this.ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vv{constructor(e,t,s,i,r,a,o,l){this.oi=e,this.Go=s,this.zo=i,this.connection=r,this.authCredentialsProvider=a,this.appCheckCredentialsProvider=o,this.listener=l,this.state=0,this.jo=0,this.Ho=null,this.Jo=null,this.stream=null,this.Yo=new xv(e,t)}Zo(){return this.state===1||this.state===5||this.Xo()}Xo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.e_()}async stop(){this.Zo()&&await this.close(0)}t_(){this.state=0,this.Yo.reset()}n_(){this.Xo()&&this.Ho===null&&(this.Ho=this.oi.enqueueAfterDelay(this.Go,6e4,()=>this.r_()))}i_(e){this.s_(),this.stream.send(e)}async r_(){if(this.Xo())return this.close(0)}s_(){this.Ho&&(this.Ho.cancel(),this.Ho=null)}o_(){this.Jo&&(this.Jo.cancel(),this.Jo=null)}async close(e,t){this.s_(),this.o_(),this.Yo.cancel(),this.jo++,e!==4?this.Yo.reset():t&&t.code===x.RESOURCE_EXHAUSTED?(Xe(t.toString()),Xe("Using maximum backoff delay to prevent overloading the backend."),this.Yo.Ko()):t&&t.code===x.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.__(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Ao(t)}__(){}auth(){this.state=1;const e=this.a_(this.jo),t=this.jo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([s,i])=>{this.jo===t&&this.u_(s,i)},s=>{e(()=>{const i=new L(x.UNKNOWN,"Fetching auth token failed: "+s.message);return this.c_(i)})})}u_(e,t){const s=this.a_(this.jo);this.stream=this.l_(e,t),this.stream.Po(()=>{s(()=>this.listener.Po())}),this.stream.To(()=>{s(()=>(this.state=2,this.Jo=this.oi.enqueueAfterDelay(this.zo,1e4,()=>(this.Xo()&&(this.state=3),Promise.resolve())),this.listener.To()))}),this.stream.Ao(i=>{s(()=>this.c_(i))}),this.stream.onMessage(i=>{s(()=>this.onMessage(i))})}e_(){this.state=5,this.Yo.$o(async()=>{this.state=0,this.start()})}c_(e){return V("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}a_(e){return t=>{this.oi.enqueueAndForget(()=>this.jo===e?t():(V("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class Kk extends Vv{constructor(e,t,s,i,r,a){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,i,a),this.serializer=r}l_(e,t){return this.connection.Oo("Listen",e,t)}onMessage(e){this.Yo.reset();const t=ik(this.serializer,e),s=function(r){if(!("targetChange"in r))return ee.min();const a=r.targetChange;return a.targetIds&&a.targetIds.length?ee.min():a.readTime?Pt(a.readTime):ee.min()}(e);return this.listener.h_(t,s)}P_(e){const t={};t.database=Iu(this.serializer),t.addTarget=function(r,a){let o;const l=a.target;if(o=Yo(l)?{documents:av(r,l)}:{query:ov(r,l)._t},o.targetId=a.targetId,a.resumeToken.approximateByteSize()>0){o.resumeToken=tv(r,a.resumeToken);const u=_u(r,a.expectedCount);u!==null&&(o.expectedCount=u)}else if(a.snapshotVersion.compareTo(ee.min())>0){o.readTime=ji(r,a.snapshotVersion.toTimestamp());const u=_u(r,a.expectedCount);u!==null&&(o.expectedCount=u)}return o}(this.serializer,e);const s=ak(this.serializer,e);s&&(t.labels=s),this.i_(t)}I_(e){const t={};t.database=Iu(this.serializer),t.removeTarget=e,this.i_(t)}}class Hk extends Vv{constructor(e,t,s,i,r,a){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,i,a),this.serializer=r,this.T_=!1}get E_(){return this.T_}start(){this.T_=!1,this.lastStreamToken=void 0,super.start()}__(){this.T_&&this.d_([])}l_(e,t){return this.connection.Oo("Write",e,t)}onMessage(e){if(Z(!!e.streamToken),this.lastStreamToken=e.streamToken,this.T_){this.Yo.reset();const t=rk(e.writeResults,e.commitTime),s=Pt(e.commitTime);return this.listener.A_(s,t)}return Z(!e.writeResults||e.writeResults.length===0),this.T_=!0,this.listener.R_()}V_(){const e={};e.database=Iu(this.serializer),this.i_(e)}d_(e){const t={streamToken:this.lastStreamToken,writes:e.map(s=>tc(this.serializer,s))};this.i_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qk extends class{}{constructor(e,t,s,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=i,this.m_=!1}f_(){if(this.m_)throw new L(x.FAILED_PRECONDITION,"The client has already been terminated.")}Co(e,t,s,i){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([r,a])=>this.connection.Co(e,wu(t,s),i,r,a)).catch(r=>{throw r.name==="FirebaseError"?(r.code===x.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),r):new L(x.UNKNOWN,r.toString())})}xo(e,t,s,i,r){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([a,o])=>this.connection.xo(e,wu(t,s),i,a,o,r)).catch(a=>{throw a.name==="FirebaseError"?(a.code===x.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),a):new L(x.UNKNOWN,a.toString())})}terminate(){this.m_=!0,this.connection.terminate()}}class Jk{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.g_=0,this.p_=null,this.y_=!0}w_(){this.g_===0&&(this.S_("Unknown"),this.p_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.p_=null,this.b_("Backend didn't respond within 10 seconds."),this.S_("Offline"),Promise.resolve())))}D_(e){this.state==="Online"?this.S_("Unknown"):(this.g_++,this.g_>=1&&(this.C_(),this.b_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.S_("Offline")))}set(e){this.C_(),this.g_=0,e==="Online"&&(this.y_=!1),this.S_(e)}S_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}b_(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.y_?(Xe(t),this.y_=!1):V("OnlineStateTracker",t)}C_(){this.p_!==null&&(this.p_.cancel(),this.p_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yk{constructor(e,t,s,i,r){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.v_=[],this.F_=new Map,this.M_=new Set,this.x_=[],this.O_=r,this.O_.io(a=>{s.enqueueAndForget(async()=>{ti(this)&&(V("RemoteStore","Restarting streams for network reachability change."),await async function(l){const u=Q(l);u.M_.add(4),await Oa(u),u.N_.set("Unknown"),u.M_.delete(4),await Bc(u)}(this))})}),this.N_=new Jk(s,i)}}async function Bc(n){if(ti(n))for(const e of n.x_)await e(!0)}async function Oa(n){for(const e of n.x_)await e(!1)}function Wc(n,e){const t=Q(n);t.F_.has(e.targetId)||(t.F_.set(e.targetId,e),Sd(t)?kd(t):cr(t).Xo()&&Td(t,e))}function Wi(n,e){const t=Q(n),s=cr(t);t.F_.delete(e),s.Xo()&&Ov(t,e),t.F_.size===0&&(s.Xo()?s.n_():ti(t)&&t.N_.set("Unknown"))}function Td(n,e){if(n.L_.xe(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ee.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}cr(n).P_(e)}function Ov(n,e){n.L_.xe(e),cr(n).I_(e)}function kd(n){n.L_=new YT({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),ot:e=>n.F_.get(e)||null,tt:()=>n.datastore.serializer.databaseId}),cr(n).start(),n.N_.w_()}function Sd(n){return ti(n)&&!cr(n).Zo()&&n.F_.size>0}function ti(n){return Q(n).M_.size===0}function Mv(n){n.L_=void 0}async function Xk(n){n.N_.set("Online")}async function Zk(n){n.F_.forEach((e,t)=>{Td(n,e)})}async function eS(n,e){Mv(n),Sd(n)?(n.N_.D_(e),kd(n)):n.N_.set("Unknown")}async function tS(n,e,t){if(n.N_.set("Online"),e instanceof ev&&e.state===2&&e.cause)try{await async function(i,r){const a=r.cause;for(const o of r.targetIds)i.F_.has(o)&&(await i.remoteSyncer.rejectListen(o,a),i.F_.delete(o),i.L_.removeTarget(o))}(n,e)}catch(s){V("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),s),await cc(n,s)}else if(e instanceof xo?n.L_.Ke(e):e instanceof Zy?n.L_.He(e):n.L_.We(e),!t.isEqual(ee.min()))try{const s=await Pv(n.localStore);t.compareTo(s)>=0&&await function(r,a){const o=r.L_.rt(a);return o.targetChanges.forEach((l,u)=>{if(l.resumeToken.approximateByteSize()>0){const h=r.F_.get(u);h&&r.F_.set(u,h.withResumeToken(l.resumeToken,a))}}),o.targetMismatches.forEach((l,u)=>{const h=r.F_.get(l);if(!h)return;r.F_.set(l,h.withResumeToken(ct.EMPTY_BYTE_STRING,h.snapshotVersion)),Ov(r,l);const p=new $n(h.target,l,u,h.sequenceNumber);Td(r,p)}),r.remoteSyncer.applyRemoteEvent(o)}(n,t)}catch(s){V("RemoteStore","Failed to raise snapshot:",s),await cc(n,s)}}async function cc(n,e,t){if(!vs(e))throw e;n.M_.add(1),await Oa(n),n.N_.set("Offline"),t||(t=()=>Pv(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{V("RemoteStore","Retrying IndexedDB access"),await t(),n.M_.delete(1),await Bc(n)})}function Lv(n,e){return e().catch(t=>cc(n,t,e))}async function or(n){const e=Q(n),t=hs(e);let s=e.v_.length>0?e.v_[e.v_.length-1].batchId:-1;for(;nS(e);)try{const i=await jk(e.localStore,s);if(i===null){e.v_.length===0&&t.n_();break}s=i.batchId,sS(e,i)}catch(i){await cc(e,i)}Fv(e)&&Uv(e)}function nS(n){return ti(n)&&n.v_.length<10}function sS(n,e){n.v_.push(e);const t=hs(n);t.Xo()&&t.E_&&t.d_(e.mutations)}function Fv(n){return ti(n)&&!hs(n).Zo()&&n.v_.length>0}function Uv(n){hs(n).start()}async function iS(n){hs(n).V_()}async function rS(n){const e=hs(n);for(const t of n.v_)e.d_(t.mutations)}async function aS(n,e,t){const s=n.v_.shift(),i=pd.from(s,e,t);await Lv(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await or(n)}async function oS(n,e){e&&hs(n).E_&&await async function(s,i){if(function(a){return HT(a)&&a!==x.ABORTED}(i.code)){const r=s.v_.shift();hs(s).t_(),await Lv(s,()=>s.remoteSyncer.rejectFailedWrite(r.batchId,i)),await or(s)}}(n,e),Fv(n)&&Uv(n)}async function rm(n,e){const t=Q(n);t.asyncQueue.verifyOperationInProgress(),V("RemoteStore","RemoteStore received new credentials");const s=ti(t);t.M_.add(3),await Oa(t),s&&t.N_.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.M_.delete(3),await Bc(t)}async function Ru(n,e){const t=Q(n);e?(t.M_.delete(2),await Bc(t)):e||(t.M_.add(2),await Oa(t),t.N_.set("Unknown"))}function cr(n){return n.B_||(n.B_=function(t,s,i){const r=Q(t);return r.f_(),new Kk(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:Xk.bind(null,n),To:Zk.bind(null,n),Ao:eS.bind(null,n),h_:tS.bind(null,n)}),n.x_.push(async e=>{e?(n.B_.t_(),Sd(n)?kd(n):n.N_.set("Unknown")):(await n.B_.stop(),Mv(n))})),n.B_}function hs(n){return n.k_||(n.k_=function(t,s,i){const r=Q(t);return r.f_(),new Hk(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:()=>Promise.resolve(),To:iS.bind(null,n),Ao:oS.bind(null,n),R_:rS.bind(null,n),A_:aS.bind(null,n)}),n.x_.push(async e=>{e?(n.k_.t_(),await or(n)):(await n.k_.stop(),n.v_.length>0&&(V("RemoteStore",`Stopping write stream with ${n.v_.length} pending writes`),n.v_=[]))})),n.k_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ad{constructor(e,t,s,i,r){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=i,this.removalCallback=r,this.deferred=new pn,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(a=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,i,r){const a=Date.now()+s,o=new Ad(e,t,a,i,r);return o.start(s),o}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new L(x.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Pd(n,e){if(Xe("AsyncQueue",`${e}: ${n}`),vs(n))return new L(x.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $i{constructor(e){this.comparator=e?(t,s)=>e(t,s)||j.comparator(t.key,s.key):(t,s)=>j.comparator(t.key,s.key),this.keyedMap=Lr(),this.sortedSet=new Le(this.comparator)}static emptySet(e){return new $i(e.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,s)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof $i)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const i=t.getNext().key,r=s.getNext().key;if(!i.isEqual(r))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new $i;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class am{constructor(){this.q_=new Le(j.comparator)}track(e){const t=e.doc.key,s=this.q_.get(t);s?e.type!==0&&s.type===3?this.q_=this.q_.insert(t,e):e.type===3&&s.type!==1?this.q_=this.q_.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.q_=this.q_.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.q_=this.q_.remove(t):e.type===1&&s.type===2?this.q_=this.q_.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):K():this.q_=this.q_.insert(t,e)}Q_(){const e=[];return this.q_.inorderTraversal((t,s)=>{e.push(s)}),e}}class zi{constructor(e,t,s,i,r,a,o,l,u){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=i,this.mutatedKeys=r,this.fromCache=a,this.syncStateChanged=o,this.excludesMetadataChanges=l,this.hasCachedResults=u}static fromInitialDocuments(e,t,s,i,r){const a=[];return t.forEach(o=>{a.push({type:0,doc:o})}),new zi(e,t,$i.emptySet(t),a,s,i,!0,!1,r)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&Vc(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==s[i].type||!t[i].doc.isEqual(s[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cS{constructor(){this.K_=void 0,this.U_=[]}W_(){return this.U_.some(e=>e.G_())}}class lS{constructor(){this.queries=new bs(e=>My(e),Vc),this.onlineState="Unknown",this.z_=new Set}}async function Rd(n,e){const t=Q(n);let s=3;const i=e.query;let r=t.queries.get(i);r?!r.W_()&&e.G_()&&(s=2):(r=new cS,s=e.G_()?0:1);try{switch(s){case 0:r.K_=await t.onListen(i,!0);break;case 1:r.K_=await t.onListen(i,!1);break;case 2:await t.onFirstRemoteStoreListen(i)}}catch(a){const o=Pd(a,`Initialization of query '${bi(e.query)}' failed`);return void e.onError(o)}t.queries.set(i,r),r.U_.push(e),e.j_(t.onlineState),r.K_&&e.H_(r.K_)&&Cd(t)}async function $d(n,e){const t=Q(n),s=e.query;let i=3;const r=t.queries.get(s);if(r){const a=r.U_.indexOf(e);a>=0&&(r.U_.splice(a,1),r.U_.length===0?i=e.G_()?0:1:!r.W_()&&e.G_()&&(i=2))}switch(i){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function uS(n,e){const t=Q(n);let s=!1;for(const i of e){const r=i.query,a=t.queries.get(r);if(a){for(const o of a.U_)o.H_(i)&&(s=!0);a.K_=i}}s&&Cd(t)}function dS(n,e,t){const s=Q(n),i=s.queries.get(e);if(i)for(const r of i.U_)r.onError(t);s.queries.delete(e)}function Cd(n){n.z_.forEach(e=>{e.next()})}var $u,om;(om=$u||($u={})).J_="default",om.Cache="cache";class Dd{constructor(e,t,s){this.query=e,this.Y_=t,this.Z_=!1,this.X_=null,this.onlineState="Unknown",this.options=s||{}}H_(e){if(!this.options.includeMetadataChanges){const s=[];for(const i of e.docChanges)i.type!==3&&s.push(i);e=new zi(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Z_?this.ea(e)&&(this.Y_.next(e),t=!0):this.ta(e,this.onlineState)&&(this.na(e),t=!0),this.X_=e,t}onError(e){this.Y_.error(e)}j_(e){this.onlineState=e;let t=!1;return this.X_&&!this.Z_&&this.ta(this.X_,e)&&(this.na(this.X_),t=!0),t}ta(e,t){if(!e.fromCache||!this.G_())return!0;const s=t!=="Offline";return(!this.options.ra||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}ea(e){if(e.docChanges.length>0)return!0;const t=this.X_&&this.X_.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}na(e){e=zi.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Z_=!0,this.Y_.next(e)}G_(){return this.options.source!==$u.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qv{constructor(e){this.key=e}}class jv{constructor(e){this.key=e}}class hS{constructor(e,t){this.query=e,this.la=t,this.ha=null,this.hasCachedResults=!1,this.current=!1,this.Pa=le(),this.mutatedKeys=le(),this.Ia=Fy(e),this.Ta=new $i(this.Ia)}get Ea(){return this.la}da(e,t){const s=t?t.Aa:new am,i=t?t.Ta:this.Ta;let r=t?t.mutatedKeys:this.mutatedKeys,a=i,o=!1;const l=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,u=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((h,p)=>{const m=i.get(h),w=Na(this.query,p)?p:null,E=!!m&&this.mutatedKeys.has(m.key),N=!!w&&(w.hasLocalMutations||this.mutatedKeys.has(w.key)&&w.hasCommittedMutations);let $=!1;m&&w?m.data.isEqual(w.data)?E!==N&&(s.track({type:3,doc:w}),$=!0):this.Ra(m,w)||(s.track({type:2,doc:w}),$=!0,(l&&this.Ia(w,l)>0||u&&this.Ia(w,u)<0)&&(o=!0)):!m&&w?(s.track({type:0,doc:w}),$=!0):m&&!w&&(s.track({type:1,doc:m}),$=!0,(l||u)&&(o=!0)),$&&(w?(a=a.add(w),r=N?r.add(h):r.delete(h)):(a=a.delete(h),r=r.delete(h)))}),this.query.limit!==null)for(;a.size>this.query.limit;){const h=this.query.limitType==="F"?a.last():a.first();a=a.delete(h.key),r=r.delete(h.key),s.track({type:1,doc:h})}return{Ta:a,Aa:s,Xi:o,mutatedKeys:r}}Ra(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,i){const r=this.Ta;this.Ta=e.Ta,this.mutatedKeys=e.mutatedKeys;const a=e.Aa.Q_();a.sort((h,p)=>function(w,E){const N=$=>{switch($){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return K()}};return N(w)-N(E)}(h.type,p.type)||this.Ia(h.doc,p.doc)),this.Va(s),i=i!=null&&i;const o=t&&!i?this.ma():[],l=this.Pa.size===0&&this.current&&!i?1:0,u=l!==this.ha;return this.ha=l,a.length!==0||u?{snapshot:new zi(this.query,e.Ta,r,a,e.mutatedKeys,l===0,u,!1,!!s&&s.resumeToken.approximateByteSize()>0),fa:o}:{fa:o}}j_(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Ta:this.Ta,Aa:new am,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{fa:[]}}ga(e){return!this.la.has(e)&&!!this.Ta.has(e)&&!this.Ta.get(e).hasLocalMutations}Va(e){e&&(e.addedDocuments.forEach(t=>this.la=this.la.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.la=this.la.delete(t)),this.current=e.current)}ma(){if(!this.current)return[];const e=this.Pa;this.Pa=le(),this.Ta.forEach(s=>{this.ga(s.key)&&(this.Pa=this.Pa.add(s.key))});const t=[];return e.forEach(s=>{this.Pa.has(s)||t.push(new jv(s))}),this.Pa.forEach(s=>{e.has(s)||t.push(new qv(s))}),t}pa(e){this.la=e.hs,this.Pa=le();const t=this.da(e.documents);return this.applyChanges(t,!0)}ya(){return zi.fromInitialDocuments(this.query,this.Ta,this.mutatedKeys,this.ha===0,this.hasCachedResults)}}class fS{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class pS{constructor(e){this.key=e,this.wa=!1}}class mS{constructor(e,t,s,i,r,a){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=i,this.currentUser=r,this.maxConcurrentLimboResolutions=a,this.Sa={},this.ba=new bs(o=>My(o),Vc),this.Da=new Map,this.Ca=new Set,this.va=new Le(j.comparator),this.Fa=new Map,this.Ma=new _d,this.xa={},this.Oa=new Map,this.Na=Qs.Ln(),this.onlineState="Unknown",this.La=void 0}get isPrimaryClient(){return this.La===!0}}async function gS(n,e,t=!0){const s=zc(n);let i;const r=s.ba.get(e);return r?(s.sharedClientState.addLocalQueryTarget(r.targetId),i=r.view.ya()):i=await Bv(s,e,t,!0),i}async function yS(n,e){const t=zc(n);await Bv(t,e,!0,!1)}async function Bv(n,e,t,s){const i=await rc(n.localStore,Ut(e)),r=i.targetId,a=t?n.sharedClientState.addLocalQueryTarget(r):"not-current";let o;return s&&(o=await Nd(n,e,r,a==="current",i.resumeToken)),n.isPrimaryClient&&t&&Wc(n.remoteStore,i),o}async function Nd(n,e,t,s,i){n.Ba=(p,m,w)=>async function(N,$,B,J){let H=$.view.da(B);H.Xi&&(H=await Au(N.localStore,$.query,!1).then(({documents:_})=>$.view.da(_,H)));const ae=J&&J.targetChanges.get($.targetId),O=J&&J.targetMismatches.get($.targetId)!=null,U=$.view.applyChanges(H,N.isPrimaryClient,ae,O);return Cu(N,$.targetId,U.fa),U.snapshot}(n,p,m,w);const r=await Au(n.localStore,e,!0),a=new hS(e,r.hs),o=a.da(r.documents),l=Va.createSynthesizedTargetChangeForCurrentChange(t,s&&n.onlineState!=="Offline",i),u=a.applyChanges(o,n.isPrimaryClient,l);Cu(n,t,u.fa);const h=new fS(e,t,a);return n.ba.set(e,h),n.Da.has(t)?n.Da.get(t).push(e):n.Da.set(t,[e]),u.snapshot}async function vS(n,e,t){const s=Q(n),i=s.ba.get(e),r=s.Da.get(i.targetId);if(r.length>1)return s.Da.set(i.targetId,r.filter(a=>!Vc(a,e))),void s.ba.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(i.targetId),s.sharedClientState.isActiveQueryTarget(i.targetId)||await Bi(s.localStore,i.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(i.targetId),t&&Wi(s.remoteStore,i.targetId),Gi(s,i.targetId)}).catch(ys)):(Gi(s,i.targetId),await Bi(s.localStore,i.targetId,!0))}async function bS(n,e){const t=Q(n),s=t.ba.get(e),i=t.Da.get(s.targetId);t.isPrimaryClient&&i.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),Wi(t.remoteStore,s.targetId))}async function _S(n,e,t){const s=Md(n);try{const i=await function(a,o){const l=Q(a),u=Be.now(),h=o.reduce((w,E)=>w.add(E.key),le());let p,m;return l.persistence.runTransaction("Locally write mutations","readwrite",w=>{let E=Ft(),N=le();return l.os.getEntries(w,h).next($=>{E=$,E.forEach((B,J)=>{J.isValidDocument()||(N=N.add(B))})}).next(()=>l.localDocuments.getOverlayedDocuments(w,E)).next($=>{p=$;const B=[];for(const J of o){const H=GT(J,p.get(J.key).overlayedDocument);H!=null&&B.push(new xn(J.key,H,Ay(H.value.mapValue),St.exists(!0)))}return l.mutationQueue.addMutationBatch(w,u,B,o)}).next($=>{m=$;const B=$.applyToLocalDocumentSet(p,N);return l.documentOverlayCache.saveOverlays(w,$.batchId,B)})}).then(()=>({batchId:m.batchId,changes:qy(p)}))}(s.localStore,e);s.sharedClientState.addPendingMutation(i.batchId),function(a,o,l){let u=a.xa[a.currentUser.toKey()];u||(u=new Le(re)),u=u.insert(o,l),a.xa[a.currentUser.toKey()]=u}(s,i.batchId,t),await _s(s,i.changes),await or(s.remoteStore)}catch(i){const r=Pd(i,"Failed to persist write");t.reject(r)}}async function Wv(n,e){const t=Q(n);try{const s=await Uk(t.localStore,e);e.targetChanges.forEach((i,r)=>{const a=t.Fa.get(r);a&&(Z(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1),i.addedDocuments.size>0?a.wa=!0:i.modifiedDocuments.size>0?Z(a.wa):i.removedDocuments.size>0&&(Z(a.wa),a.wa=!1))}),await _s(t,s,e)}catch(s){await ys(s)}}function cm(n,e,t){const s=Q(n);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const i=[];s.ba.forEach((r,a)=>{const o=a.view.j_(e);o.snapshot&&i.push(o.snapshot)}),function(a,o){const l=Q(a);l.onlineState=o;let u=!1;l.queries.forEach((h,p)=>{for(const m of p.U_)m.j_(o)&&(u=!0)}),u&&Cd(l)}(s.eventManager,e),i.length&&s.Sa.h_(i),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function wS(n,e,t){const s=Q(n);s.sharedClientState.updateQueryState(e,"rejected",t);const i=s.Fa.get(e),r=i&&i.key;if(r){let a=new Le(j.comparator);a=a.insert(r,He.newNoDocument(r,ee.min()));const o=le().add(r),l=new xa(ee.min(),new Map,new Le(re),a,o);await Wv(s,l),s.va=s.va.remove(r),s.Fa.delete(e),Od(s)}else await Bi(s.localStore,e,!1).then(()=>Gi(s,e,t)).catch(ys)}async function IS(n,e){const t=Q(n),s=e.batch.batchId;try{const i=await Fk(t.localStore,e);Vd(t,s,null),xd(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await _s(t,i)}catch(i){await ys(i)}}async function ES(n,e,t){const s=Q(n);try{const i=await function(a,o){const l=Q(a);return l.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let h;return l.mutationQueue.lookupMutationBatch(u,o).next(p=>(Z(p!==null),h=p.keys(),l.mutationQueue.removeMutationBatch(u,p))).next(()=>l.mutationQueue.performConsistencyCheck(u)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(u,h,o)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,h)).next(()=>l.localDocuments.getDocuments(u,h))})}(s.localStore,e);Vd(s,e,t),xd(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await _s(s,i)}catch(i){await ys(i)}}function xd(n,e){(n.Oa.get(e)||[]).forEach(t=>{t.resolve()}),n.Oa.delete(e)}function Vd(n,e,t){const s=Q(n);let i=s.xa[s.currentUser.toKey()];if(i){const r=i.get(e);r&&(t?r.reject(t):r.resolve(),i=i.remove(e)),s.xa[s.currentUser.toKey()]=i}}function Gi(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const s of n.Da.get(e))n.ba.delete(s),t&&n.Sa.ka(s,t);n.Da.delete(e),n.isPrimaryClient&&n.Ma.Vr(e).forEach(s=>{n.Ma.containsKey(s)||zv(n,s)})}function zv(n,e){n.Ca.delete(e.path.canonicalString());const t=n.va.get(e);t!==null&&(Wi(n.remoteStore,t),n.va=n.va.remove(e),n.Fa.delete(t),Od(n))}function Cu(n,e,t){for(const s of t)s instanceof qv?(n.Ma.addReference(s.key,e),TS(n,s)):s instanceof jv?(V("SyncEngine","Document no longer in limbo: "+s.key),n.Ma.removeReference(s.key,e),n.Ma.containsKey(s.key)||zv(n,s.key)):K()}function TS(n,e){const t=e.key,s=t.path.canonicalString();n.va.get(t)||n.Ca.has(s)||(V("SyncEngine","New document in limbo: "+t),n.Ca.add(s),Od(n))}function Od(n){for(;n.Ca.size>0&&n.va.size<n.maxConcurrentLimboResolutions;){const e=n.Ca.values().next().value;n.Ca.delete(e);const t=new j(ke.fromString(e)),s=n.Na.next();n.Fa.set(s,new pS(t)),n.va=n.va.insert(t,s),Wc(n.remoteStore,new $n(Ut(Da(t.path)),s,"TargetPurposeLimboResolution",Nt.oe))}}async function _s(n,e,t){const s=Q(n),i=[],r=[],a=[];s.ba.isEmpty()||(s.ba.forEach((o,l)=>{a.push(s.Ba(l,e,t).then(u=>{if((u||t)&&s.isPrimaryClient){const h=u&&!u.fromCache;s.sharedClientState.updateQueryState(l.targetId,h?"current":"not-current")}if(u){i.push(u);const h=Id.Ki(l.targetId,u);r.push(h)}}))}),await Promise.all(a),s.Sa.h_(i),await async function(l,u){const h=Q(l);try{await h.persistence.runTransaction("notifyLocalViewChanges","readwrite",p=>C.forEach(u,m=>C.forEach(m.qi,w=>h.persistence.referenceDelegate.addReference(p,m.targetId,w)).next(()=>C.forEach(m.Qi,w=>h.persistence.referenceDelegate.removeReference(p,m.targetId,w)))))}catch(p){if(!vs(p))throw p;V("LocalStore","Failed to update sequence numbers: "+p)}for(const p of u){const m=p.targetId;if(!p.fromCache){const w=h.ns.get(m),E=w.snapshotVersion,N=w.withLastLimboFreeSnapshotVersion(E);h.ns=h.ns.insert(m,N)}}}(s.localStore,r))}async function kS(n,e){const t=Q(n);if(!t.currentUser.isEqual(e)){V("SyncEngine","User change. New user:",e.toKey());const s=await Av(t.localStore,e);t.currentUser=e,function(r,a){r.Oa.forEach(o=>{o.forEach(l=>{l.reject(new L(x.CANCELLED,a))})}),r.Oa.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await _s(t,s.us)}}function SS(n,e){const t=Q(n),s=t.Fa.get(e);if(s&&s.wa)return le().add(s.key);{let i=le();const r=t.Da.get(e);if(!r)return i;for(const a of r){const o=t.ba.get(a);i=i.unionWith(o.view.Ea)}return i}}async function AS(n,e){const t=Q(n),s=await Au(t.localStore,e.query,!0),i=e.view.pa(s);return t.isPrimaryClient&&Cu(t,e.targetId,i.fa),i}async function PS(n,e){const t=Q(n);return $v(t.localStore,e).then(s=>_s(t,s))}async function RS(n,e,t,s){const i=Q(n),r=await function(o,l){const u=Q(o),h=Q(u.mutationQueue);return u.persistence.runTransaction("Lookup mutation documents","readonly",p=>h.vn(p,l).next(m=>m?u.localDocuments.getDocuments(p,m):C.resolve(null)))}(i.localStore,e);r!==null?(t==="pending"?await or(i.remoteStore):t==="acknowledged"||t==="rejected"?(Vd(i,e,s||null),xd(i,e),function(o,l){Q(Q(o).mutationQueue).Mn(l)}(i.localStore,e)):K(),await _s(i,r)):V("SyncEngine","Cannot apply mutation batch with id: "+e)}async function $S(n,e){const t=Q(n);if(zc(t),Md(t),e===!0&&t.La!==!0){const s=t.sharedClientState.getAllActiveQueryTargets(),i=await lm(t,s.toArray());t.La=!0,await Ru(t.remoteStore,!0);for(const r of i)Wc(t.remoteStore,r)}else if(e===!1&&t.La!==!1){const s=[];let i=Promise.resolve();t.Da.forEach((r,a)=>{t.sharedClientState.isLocalQueryTarget(a)?s.push(a):i=i.then(()=>(Gi(t,a),Bi(t.localStore,a,!0))),Wi(t.remoteStore,a)}),await i,await lm(t,s),function(a){const o=Q(a);o.Fa.forEach((l,u)=>{Wi(o.remoteStore,u)}),o.Ma.mr(),o.Fa=new Map,o.va=new Le(j.comparator)}(t),t.La=!1,await Ru(t.remoteStore,!1)}}async function lm(n,e,t){const s=Q(n),i=[],r=[];for(const a of e){let o;const l=s.Da.get(a);if(l&&l.length!==0){o=await rc(s.localStore,Ut(l[0]));for(const u of l){const h=s.ba.get(u),p=await AS(s,h);p.snapshot&&r.push(p.snapshot)}}else{const u=await Rv(s.localStore,a);o=await rc(s.localStore,u),await Nd(s,Gv(u),a,!1,o.resumeToken)}i.push(o)}return s.Sa.h_(r),i}function Gv(n){return Vy(n.path,n.collectionGroup,n.orderBy,n.filters,n.limit,"F",n.startAt,n.endAt)}function CS(n){return function(t){return Q(Q(t).persistence).Bi()}(Q(n).localStore)}async function DS(n,e,t,s){const i=Q(n);if(i.La)return void V("SyncEngine","Ignoring unexpected query state notification.");const r=i.Da.get(e);if(r&&r.length>0)switch(t){case"current":case"not-current":{const a=await $v(i.localStore,Ly(r[0])),o=xa.createSynthesizedRemoteEventForCurrentChange(e,t==="current",ct.EMPTY_BYTE_STRING);await _s(i,a,o);break}case"rejected":await Bi(i.localStore,e,!0),Gi(i,e,s);break;default:K()}}async function NS(n,e,t){const s=zc(n);if(s.La){for(const i of e){if(s.Da.has(i)&&s.sharedClientState.isActiveQueryTarget(i)){V("SyncEngine","Adding an already active target "+i);continue}const r=await Rv(s.localStore,i),a=await rc(s.localStore,r);await Nd(s,Gv(r),a.targetId,!1,a.resumeToken),Wc(s.remoteStore,a)}for(const i of t)s.Da.has(i)&&await Bi(s.localStore,i,!1).then(()=>{Wi(s.remoteStore,i),Gi(s,i)}).catch(ys)}}function zc(n){const e=Q(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Wv.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=SS.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=wS.bind(null,e),e.Sa.h_=uS.bind(null,e.eventManager),e.Sa.ka=dS.bind(null,e.eventManager),e}function Md(n){const e=Q(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=IS.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=ES.bind(null,e),e}class Du{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=jc(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){return Sv(this.persistence,new kv,e.initialUser,this.serializer)}createPersistence(e){return new Ev(qc.Hr,this.serializer)}createSharedClientState(e){return new Dv}async terminate(){var e,t;(e=this.gcScheduler)===null||e===void 0||e.stop(),(t=this.indexBackfillerScheduler)===null||t===void 0||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class Kv extends Du{constructor(e,t,s){super(),this.Qa=e,this.cacheSizeBytes=t,this.forceOwnership=s,this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Qa.initialize(this,e),await Md(this.Qa.syncEngine),await or(this.Qa.remoteStore),await this.persistence.fi(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}createLocalStore(e){return Sv(this.persistence,new kv,e.initialUser,this.serializer)}createGarbageCollectionScheduler(e,t){const s=this.persistence.referenceDelegate.garbageCollector;return new Ik(s,e.asyncQueue,t)}createIndexBackfillerScheduler(e,t){const s=new nT(t,this.persistence);return new tT(e.asyncQueue,s)}createPersistence(e){const t=Tv(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),s=this.cacheSizeBytes!==void 0?Dt.withCacheSize(this.cacheSizeBytes):Dt.DEFAULT;return new wd(this.synchronizeTabs,t,e.clientId,s,e.asyncQueue,Nv(),Vo(),this.serializer,this.sharedClientState,!!this.forceOwnership)}createSharedClientState(e){return new Dv}}class xS extends Kv{constructor(e,t){super(e,t,!1),this.Qa=e,this.cacheSizeBytes=t,this.synchronizeTabs=!0}async initialize(e){await super.initialize(e);const t=this.Qa.syncEngine;this.sharedClientState instanceof Fl&&(this.sharedClientState.syncEngine={Zs:RS.bind(null,t),Xs:DS.bind(null,t),eo:NS.bind(null,t),Bi:CS.bind(null,t),Ys:PS.bind(null,t)},await this.sharedClientState.start()),await this.persistence.fi(async s=>{await $S(this.Qa.syncEngine,s),this.gcScheduler&&(s&&!this.gcScheduler.started?this.gcScheduler.start():s||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(s&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():s||this.indexBackfillerScheduler.stop())})}createSharedClientState(e){const t=Nv();if(!Fl.D(t))throw new L(x.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const s=Tv(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey);return new Fl(t,e.asyncQueue,s,e.clientId,e.initialUser)}}class Ld{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>cm(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=kS.bind(null,this.syncEngine),await Ru(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new lS}()}createDatastore(e){const t=jc(e.databaseInfo.databaseId),s=function(r){return new Gk(r)}(e.databaseInfo);return function(r,a,o,l){return new Qk(r,a,o,l)}(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return function(s,i,r,a,o){return new Yk(s,i,r,a,o)}(this.localStore,this.datastore,e.asyncQueue,t=>cm(this.syncEngine,t,0),function(){return im.D()?new im:new Bk}())}createSyncEngine(e,t){return function(i,r,a,o,l,u,h){const p=new mS(i,r,a,o,l,u);return h&&(p.La=!0),p}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e;await async function(s){const i=Q(s);V("RemoteStore","RemoteStore shutting down."),i.M_.add(5),await Oa(i),i.O_.shutdown(),i.N_.set("Unknown")}(this.remoteStore),(e=this.datastore)===null||e===void 0||e.terminate()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fd{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Ka(this.observer.next,e)}error(e){this.observer.error?this.Ka(this.observer.error,e):Xe("Uncaught Error in snapshot listener:",e.toString())}$a(){this.muted=!0}Ka(e,t){this.muted||setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VS{constructor(e,t,s,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this.databaseInfo=i,this.user=_t.UNAUTHENTICATED,this.clientId=dy.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(s,async r=>{V("FirestoreClient","Received user=",r.uid),await this.authCredentialListener(r),this.user=r}),this.appCheckCredentials.start(s,r=>(V("FirestoreClient","Received new app check token=",r),this.appCheckCredentialListener(r,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new L(x.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const e=new pn;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=Pd(t,"Failed to shutdown persistence");e.reject(s)}}),e.promise}}async function ql(n,e){n.asyncQueue.verifyOperationInProgress(),V("FirestoreClient","Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let s=t.initialUser;n.setCredentialChangeListener(async i=>{s.isEqual(i)||(await Av(e.localStore,i),s=i)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function um(n,e){n.asyncQueue.verifyOperationInProgress();const t=await MS(n);V("FirestoreClient","Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(s=>rm(e.remoteStore,s)),n.setAppCheckTokenChangeListener((s,i)=>rm(e.remoteStore,i)),n._onlineComponents=e}function OS(n){return n.name==="FirebaseError"?n.code===x.FAILED_PRECONDITION||n.code===x.UNIMPLEMENTED:!(typeof DOMException<"u"&&n instanceof DOMException)||n.code===22||n.code===20||n.code===11}async function MS(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){V("FirestoreClient","Using user provided OfflineComponentProvider");try{await ql(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!OS(t))throw t;ra("Error using user provided cache. Falling back to memory cache: "+t),await ql(n,new Du)}}else V("FirestoreClient","Using default OfflineComponentProvider"),await ql(n,new Du);return n._offlineComponents}async function Hv(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(V("FirestoreClient","Using user provided OnlineComponentProvider"),await um(n,n._uninitializedComponentsProvider._online)):(V("FirestoreClient","Using default OnlineComponentProvider"),await um(n,new Ld))),n._onlineComponents}function LS(n){return Hv(n).then(e=>e.syncEngine)}async function lc(n){const e=await Hv(n),t=e.eventManager;return t.onListen=gS.bind(null,e.syncEngine),t.onUnlisten=vS.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=yS.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=bS.bind(null,e.syncEngine),t}function FS(n,e,t={}){const s=new pn;return n.asyncQueue.enqueueAndForget(async()=>function(r,a,o,l,u){const h=new Fd({next:m=>{a.enqueueAndForget(()=>$d(r,p));const w=m.docs.has(o);!w&&m.fromCache?u.reject(new L(x.UNAVAILABLE,"Failed to get document because the client is offline.")):w&&m.fromCache&&l&&l.source==="server"?u.reject(new L(x.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):u.resolve(m)},error:m=>u.reject(m)}),p=new Dd(Da(o.path),h,{includeMetadataChanges:!0,ra:!0});return Rd(r,p)}(await lc(n),n.asyncQueue,e,t,s)),s.promise}function US(n,e,t={}){const s=new pn;return n.asyncQueue.enqueueAndForget(async()=>function(r,a,o,l,u){const h=new Fd({next:m=>{a.enqueueAndForget(()=>$d(r,p)),m.fromCache&&l.source==="server"?u.reject(new L(x.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):u.resolve(m)},error:m=>u.reject(m)}),p=new Dd(o,h,{includeMetadataChanges:!0,ra:!0});return Rd(r,p)}(await lc(n),n.asyncQueue,e,t,s)),s.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qv(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dm=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jv(n,e,t){if(!t)throw new L(x.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function qS(n,e,t,s){if(e===!0&&s===!0)throw new L(x.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function hm(n){if(!j.isDocumentKey(n))throw new L(x.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function fm(n){if(j.isDocumentKey(n))throw new L(x.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Gc(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(s){return s.constructor?s.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":K()}function Gt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new L(x.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=Gc(n);throw new L(x.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function jS(n,e){if(e<=0)throw new L(x.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pm{constructor(e){var t,s;if(e.host===void 0){if(e.ssl!==void 0)throw new L(x.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(t=e.ssl)===null||t===void 0||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new L(x.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}qS("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Qv((s=e.experimentalLongPollingOptions)!==null&&s!==void 0?s:{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new L(x.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new L(x.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new L(x.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(s,i){return s.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Ud{constructor(e,t,s,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new pm({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new L(x.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(e){if(this._settingsFrozen)throw new L(x.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new pm(e),e.credentials!==void 0&&(this._authCredentials=function(s){if(!s)return new z0;switch(s.type){case"firstParty":return new H0(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new L(x.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const s=dm.get(t);s&&(V("ComponentProvider","Removing Datastore"),dm.delete(t),s.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vn{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new Vn(this.firestore,e,this._query)}}class It{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new rs(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new It(this.firestore,e,this._key)}}class rs extends Vn{constructor(e,t,s){super(e,t,Da(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new It(this.firestore,null,new j(e))}withConverter(e){return new rs(this.firestore,e,this._path)}}function kn(n,e,...t){if(n=at(n),Jv("collection","path",e),n instanceof Ud){const s=ke.fromString(e,...t);return fm(s),new rs(n,null,s)}{if(!(n instanceof It||n instanceof rs))throw new L(x.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(ke.fromString(e,...t));return fm(s),new rs(n.firestore,null,s)}}function Rt(n,e,...t){if(n=at(n),arguments.length===1&&(e=dy.newId()),Jv("doc","path",e),n instanceof Ud){const s=ke.fromString(e,...t);return hm(s),new It(n,null,new j(s))}{if(!(n instanceof It||n instanceof rs))throw new L(x.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(ke.fromString(e,...t));return hm(s),new It(n.firestore,n instanceof rs?n.converter:null,new j(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BS{constructor(){this.iu=Promise.resolve(),this.su=[],this.ou=!1,this._u=[],this.au=null,this.uu=!1,this.cu=!1,this.lu=[],this.Yo=new xv(this,"async_queue_retry"),this.hu=()=>{const t=Vo();t&&V("AsyncQueue","Visibility state changed to "+t.visibilityState),this.Yo.Wo()};const e=Vo();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.hu)}get isShuttingDown(){return this.ou}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Pu(),this.Iu(e)}enterRestrictedMode(e){if(!this.ou){this.ou=!0,this.cu=e||!1;const t=Vo();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.hu)}}enqueue(e){if(this.Pu(),this.ou)return new Promise(()=>{});const t=new pn;return this.Iu(()=>this.ou&&this.cu?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.su.push(e),this.Tu()))}async Tu(){if(this.su.length!==0){try{await this.su[0](),this.su.shift(),this.Yo.reset()}catch(e){if(!vs(e))throw e;V("AsyncQueue","Operation failed with retryable error: "+e)}this.su.length>0&&this.Yo.$o(()=>this.Tu())}}Iu(e){const t=this.iu.then(()=>(this.uu=!0,e().catch(s=>{this.au=s,this.uu=!1;const i=function(a){let o=a.message||"";return a.stack&&(o=a.stack.includes(a.message)?a.stack:a.message+`
`+a.stack),o}(s);throw Xe("INTERNAL UNHANDLED ERROR: ",i),s}).then(s=>(this.uu=!1,s))));return this.iu=t,t}enqueueAfterDelay(e,t,s){this.Pu(),this.lu.indexOf(e)>-1&&(t=0);const i=Ad.createAndSchedule(this,e,t,s,r=>this.Eu(r));return this._u.push(i),i}Pu(){this.au&&K()}verifyOperationInProgress(){}async du(){let e;do e=this.iu,await e;while(e!==this.iu)}Au(e){for(const t of this._u)if(t.timerId===e)return!0;return!1}Ru(e){return this.du().then(()=>{this._u.sort((t,s)=>t.targetTimeMs-s.targetTimeMs);for(const t of this._u)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.du()})}Vu(e){this.lu.push(e)}Eu(e){const t=this._u.indexOf(e);this._u.splice(t,1)}}function mm(n){return function(t,s){if(typeof t!="object"||t===null)return!1;const i=t;for(const r of s)if(r in i&&typeof i[r]=="function")return!0;return!1}(n,["next","error","complete"])}class fs extends Ud{constructor(e,t,s,i){super(e,t,s,i),this.type="firestore",this._queue=function(){return new BS}(),this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||Yv(this),this._firestoreClient.terminate()}}function WS(n,e,t){t||(t="(default)");const s=Ju(n,"firestore");if(s.isInitialized(t)){const i=s.getImmediate({identifier:t}),r=s.getOptions(t);if(ta(r,e))return i;throw new L(x.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new L(x.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new L(x.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return s.initialize({options:e,instanceIdentifier:t})}function Kc(n){return n._firestoreClient||Yv(n),n._firestoreClient.verifyNotTerminated(),n._firestoreClient}function Yv(n){var e,t,s;const i=n._freezeSettings(),r=function(o,l,u,h){return new IT(o,l,u,h.host,h.ssl,h.experimentalForceLongPolling,h.experimentalAutoDetectLongPolling,Qv(h.experimentalLongPollingOptions),h.useFetchStreams)}(n._databaseId,((e=n._app)===null||e===void 0?void 0:e.options.appId)||"",n._persistenceKey,i);n._firestoreClient=new VS(n._authCredentials,n._appCheckCredentials,n._queue,r),!((t=i.localCache)===null||t===void 0)&&t._offlineComponentProvider&&(!((s=i.localCache)===null||s===void 0)&&s._onlineComponentProvider)&&(n._firestoreClient._uninitializedComponentsProvider={_offlineKind:i.localCache.kind,_offline:i.localCache._offlineComponentProvider,_online:i.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ki{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Ki(ct.fromBase64String(e))}catch(t){throw new L(x.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Ki(ct.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hc{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new L(x.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new je(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qd{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jd{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new L(x.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new L(x.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return re(this._lat,e._lat)||re(this._long,e._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zS=/^__.*__$/;class GS{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new xn(e,this.data,this.fieldMask,t,this.fieldTransforms):new ar(e,this.data,t,this.fieldTransforms)}}class Xv{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new xn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Zv(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw K()}}class Bd{constructor(e,t,s,i,r,a){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=i,r===void 0&&this.mu(),this.fieldTransforms=r||[],this.fieldMask=a||[]}get path(){return this.settings.path}get fu(){return this.settings.fu}gu(e){return new Bd(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}pu(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),i=this.gu({path:s,yu:!1});return i.wu(e),i}Su(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),i=this.gu({path:s,yu:!1});return i.mu(),i}bu(e){return this.gu({path:void 0,yu:!0})}Du(e){return uc(e,this.settings.methodName,this.settings.Cu||!1,this.path,this.settings.vu)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}mu(){if(this.path)for(let e=0;e<this.path.length;e++)this.wu(this.path.get(e))}wu(e){if(e.length===0)throw this.Du("Document fields must not be empty");if(Zv(this.fu)&&zS.test(e))throw this.Du('Document fields cannot begin and end with "__"')}}class KS{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||jc(e)}Fu(e,t,s,i=!1){return new Bd({fu:e,methodName:t,vu:s,path:je.emptyPath(),yu:!1,Cu:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Wd(n){const e=n._freezeSettings(),t=jc(n._databaseId);return new KS(n._databaseId,!!e.ignoreUndefinedProperties,t)}function HS(n,e,t,s,i,r={}){const a=n.Fu(r.merge||r.mergeFields?2:0,e,t,i);zd("Data must be an object, but it was:",a,s);const o=eb(s,a);let l,u;if(r.merge)l=new xt(a.fieldMask),u=a.fieldTransforms;else if(r.mergeFields){const h=[];for(const p of r.mergeFields){const m=Nu(e,p,t);if(!a.contains(m))throw new L(x.INVALID_ARGUMENT,`Field '${m}' is specified in your field mask but missing from your input data.`);nb(h,m)||h.push(m)}l=new xt(h),u=a.fieldTransforms.filter(p=>l.covers(p.field))}else l=null,u=a.fieldTransforms;return new GS(new wt(o),l,u)}class Ma extends qd{_toFieldTransform(e){if(e.fu!==2)throw e.fu===1?e.Du(`${this._methodName}() can only appear at the top level of your update data`):e.Du(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Ma}}function QS(n,e,t,s){const i=n.Fu(1,e,t);zd("Data must be an object, but it was:",i,s);const r=[],a=wt.empty();ei(s,(l,u)=>{const h=Gd(e,l,t);u=at(u);const p=i.Su(h);if(u instanceof Ma)r.push(h);else{const m=La(u,p);m!=null&&(r.push(h),a.set(h,m))}});const o=new xt(r);return new Xv(a,o,i.fieldTransforms)}function JS(n,e,t,s,i,r){const a=n.Fu(1,e,t),o=[Nu(e,s,t)],l=[i];if(r.length%2!=0)throw new L(x.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let m=0;m<r.length;m+=2)o.push(Nu(e,r[m])),l.push(r[m+1]);const u=[],h=wt.empty();for(let m=o.length-1;m>=0;--m)if(!nb(u,o[m])){const w=o[m];let E=l[m];E=at(E);const N=a.Su(w);if(E instanceof Ma)u.push(w);else{const $=La(E,N);$!=null&&(u.push(w),h.set(w,$))}}const p=new xt(u);return new Xv(h,p,a.fieldTransforms)}function YS(n,e,t,s=!1){return La(t,n.Fu(s?4:3,e))}function La(n,e){if(tb(n=at(n)))return zd("Unsupported field value:",e,n),eb(n,e);if(n instanceof qd)return function(s,i){if(!Zv(i.fu))throw i.Du(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.Du(`${s._methodName}() is not currently supported inside arrays`);const r=s._toFieldTransform(i);r&&i.fieldTransforms.push(r)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.yu&&e.fu!==4)throw e.Du("Nested arrays are not supported");return function(s,i){const r=[];let a=0;for(const o of s){let l=La(o,i.bu(a));l==null&&(l={nullValue:"NULL_VALUE"}),r.push(l),a++}return{arrayValue:{values:r}}}(n,e)}return function(s,i){if((s=at(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return FT(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const r=Be.fromDate(s);return{timestampValue:ji(i.serializer,r)}}if(s instanceof Be){const r=new Be(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:ji(i.serializer,r)}}if(s instanceof jd)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof Ki)return{bytesValue:tv(i.serializer,s._byteString)};if(s instanceof It){const r=i.databaseId,a=s.firestore._databaseId;if(!a.isEqual(r))throw i.Du(`Document reference is for database ${a.projectId}/${a.database} but should be for database ${r.projectId}/${r.database}`);return{referenceValue:yd(s.firestore._databaseId||i.databaseId,s._key.path)}}throw i.Du(`Unsupported field value: ${Gc(s)}`)}(n,e)}function eb(n,e){const t={};return Ty(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):ei(n,(s,i)=>{const r=La(i,e.pu(s));r!=null&&(t[s]=r)}),{mapValue:{fields:t}}}function tb(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Be||n instanceof jd||n instanceof Ki||n instanceof It||n instanceof qd)}function zd(n,e,t){if(!tb(t)||!function(i){return typeof i=="object"&&i!==null&&(Object.getPrototypeOf(i)===Object.prototype||Object.getPrototypeOf(i)===null)}(t)){const s=Gc(t);throw s==="an object"?e.Du(n+" a custom object"):e.Du(n+" "+s)}}function Nu(n,e,t){if((e=at(e))instanceof Hc)return e._internalPath;if(typeof e=="string")return Gd(n,e);throw uc("Field path arguments must be of type string or ",n,!1,void 0,t)}const XS=new RegExp("[~\\*/\\[\\]]");function Gd(n,e,t){if(e.search(XS)>=0)throw uc(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Hc(...e.split("."))._internalPath}catch{throw uc(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function uc(n,e,t,s,i){const r=s&&!s.isEmpty(),a=i!==void 0;let o=`Function ${e}() called with invalid data`;t&&(o+=" (via `toFirestore()`)"),o+=". ";let l="";return(r||a)&&(l+=" (found",r&&(l+=` in field ${s}`),a&&(l+=` in document ${i}`),l+=")"),new L(x.INVALID_ARGUMENT,o+n+l)}function nb(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sb{constructor(e,t,s,i,r){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=i,this._converter=r}get id(){return this._key.path.lastSegment()}get ref(){return new It(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new ZS(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field(Qc("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class ZS extends sb{data(){return super.data()}}function Qc(n,e){return typeof e=="string"?Gd(n,e):e instanceof Hc?e._internalPath:e._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ib(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new L(x.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Kd{}class Hd extends Kd{}function dc(n,e,...t){let s=[];e instanceof Kd&&s.push(e),s=s.concat(t),function(r){const a=r.filter(l=>l instanceof Qd).length,o=r.filter(l=>l instanceof Jc).length;if(a>1||a>0&&o>0)throw new L(x.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(s);for(const i of s)n=i._apply(n);return n}class Jc extends Hd{constructor(e,t,s){super(),this._field=e,this._op=t,this._value=s,this.type="where"}static _create(e,t,s){return new Jc(e,t,s)}_apply(e){const t=this._parse(e);return ob(e._query,t),new Vn(e.firestore,e.converter,bu(e._query,t))}_parse(e){const t=Wd(e.firestore);return function(r,a,o,l,u,h,p){let m;if(u.isKeyField()){if(h==="array-contains"||h==="array-contains-any")throw new L(x.INVALID_ARGUMENT,`Invalid Query. You can't perform '${h}' queries on documentId().`);if(h==="in"||h==="not-in"){vm(p,h);const w=[];for(const E of p)w.push(ym(l,r,E));m={arrayValue:{values:w}}}else m=ym(l,r,p)}else h!=="in"&&h!=="not-in"&&h!=="array-contains-any"||vm(p,h),m=YS(o,a,p,h==="in"||h==="not-in");return fe.create(u,h,m)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function gm(n,e,t){const s=e,i=Qc("where",n);return Jc._create(i,s,t)}class Qd extends Kd{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Qd(e,t)}_parse(e){const t=this._queryConstraints.map(s=>s._parse(e)).filter(s=>s.getFilters().length>0);return t.length===1?t[0]:Pe.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(i,r){let a=i;const o=r.getFlattenedFilters();for(const l of o)ob(a,l),a=bu(a,l)}(e._query,t),new Vn(e.firestore,e.converter,bu(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Jd extends Hd{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new Jd(e,t)}_apply(e){const t=function(i,r,a){if(i.startAt!==null)throw new L(x.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(i.endAt!==null)throw new L(x.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new fa(r,a)}(e._query,this._field,this._direction);return new Vn(e.firestore,e.converter,function(i,r){const a=i.explicitOrderBy.concat([r]);return new rr(i.path,i.collectionGroup,a,i.filters.slice(),i.limit,i.limitType,i.startAt,i.endAt)}(e._query,t))}}function rb(n,e="asc"){const t=e,s=Qc("orderBy",n);return Jd._create(s,t)}class Yd extends Hd{constructor(e,t,s){super(),this.type=e,this._limit=t,this._limitType=s}static _create(e,t,s){return new Yd(e,t,s)}_apply(e){return new Vn(e.firestore,e.converter,Zo(e._query,this._limit,this._limitType))}}function ab(n){return jS("limit",n),Yd._create("limit",n,"F")}function ym(n,e,t){if(typeof(t=at(t))=="string"){if(t==="")throw new L(x.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!Oy(e)&&t.indexOf("/")!==-1)throw new L(x.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const s=e.path.child(ke.fromString(t));if(!j.isDocumentKey(s))throw new L(x.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return da(n,new j(s))}if(t instanceof It)return da(n,t._key);throw new L(x.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Gc(t)}.`)}function vm(n,e){if(!Array.isArray(n)||n.length===0)throw new L(x.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function ob(n,e){const t=function(i,r){for(const a of i)for(const o of a.getFlattenedFilters())if(r.indexOf(o.op)>=0)return o.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new L(x.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new L(x.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}class eA{convertValue(e,t="none"){switch(zs(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Ke(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(us(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw K()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return ei(e,(i,r)=>{s[i]=this.convertValue(r,t)}),s}convertGeoPoint(e){return new jd(Ke(e.latitude),Ke(e.longitude))}convertArray(e,t){return(e.values||[]).map(s=>this.convertValue(s,t))}convertServerTimestamp(e,t){switch(t){case"previous":const s=ud(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(la(e));default:return null}}convertTimestamp(e){const t=Dn(e);return new Be(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=ke.fromString(e);Z(dv(s));const i=new Ws(s.get(1),s.get(3)),r=new j(s.popFirst(5));return i.isEqual(t)||Xe(`Document ${r} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tA(n,e,t){let s;return s=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qr{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class cb extends sb{constructor(e,t,s,i,r,a){super(e,t,s,i,a),this._firestore=e,this._firestoreImpl=e,this.metadata=r}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new Oo(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field(Qc("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}}class Oo extends cb{data(e={}){return super.data(e)}}class lb{constructor(e,t,s,i){this._firestore=e,this._userDataWriter=t,this._snapshot=i,this.metadata=new qr(i.hasPendingWrites,i.fromCache),this.query=s}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(s=>{e.call(t,new Oo(this._firestore,this._userDataWriter,s.key,s,new qr(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new L(x.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(i,r){if(i._snapshot.oldDocs.isEmpty()){let a=0;return i._snapshot.docChanges.map(o=>{const l=new Oo(i._firestore,i._userDataWriter,o.doc.key,o.doc,new qr(i._snapshot.mutatedKeys.has(o.doc.key),i._snapshot.fromCache),i.query.converter);return o.doc,{type:"added",doc:l,oldIndex:-1,newIndex:a++}})}{let a=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(o=>r||o.type!==3).map(o=>{const l=new Oo(i._firestore,i._userDataWriter,o.doc.key,o.doc,new qr(i._snapshot.mutatedKeys.has(o.doc.key),i._snapshot.fromCache),i.query.converter);let u=-1,h=-1;return o.type!==0&&(u=a.indexOf(o.doc.key),a=a.delete(o.doc.key)),o.type!==1&&(a=a.add(o.doc),h=a.indexOf(o.doc.key)),{type:nA(o.type),doc:l,oldIndex:u,newIndex:h}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function nA(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return K()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sA(n){n=Gt(n,It);const e=Gt(n.firestore,fs);return FS(Kc(e),n._key).then(t=>db(e,n,t))}class Xd extends eA{constructor(e){super(),this.firestore=e}convertBytes(e){return new Ki(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new It(this.firestore,null,t)}}function Zd(n){n=Gt(n,Vn);const e=Gt(n.firestore,fs),t=Kc(e),s=new Xd(e);return ib(n._query),US(t,n._query).then(i=>new lb(e,s,n,i))}function ws(n,e,t){n=Gt(n,It);const s=Gt(n.firestore,fs),i=tA(n.converter,e,t);return th(s,[HS(Wd(s),"setDoc",n._key,i,n.converter!==null,t).toMutation(n._key,St.none())])}function ub(n,e,t,...s){n=Gt(n,It);const i=Gt(n.firestore,fs),r=Wd(i);let a;return a=typeof(e=at(e))=="string"||e instanceof Hc?JS(r,"updateDoc",n._key,e,t,s):QS(r,"updateDoc",n._key,e),th(i,[a.toMutation(n._key,St.exists(!0))])}function eh(n){return th(Gt(n.firestore,fs),[new Lc(n._key,St.none())])}function xu(n,...e){var t,s,i;n=at(n);let r={includeMetadataChanges:!1,source:"default"},a=0;typeof e[a]!="object"||mm(e[a])||(r=e[a],a++);const o={includeMetadataChanges:r.includeMetadataChanges,source:r.source};if(mm(e[a])){const p=e[a];e[a]=(t=p.next)===null||t===void 0?void 0:t.bind(p),e[a+1]=(s=p.error)===null||s===void 0?void 0:s.bind(p),e[a+2]=(i=p.complete)===null||i===void 0?void 0:i.bind(p)}let l,u,h;if(n instanceof It)u=Gt(n.firestore,fs),h=Da(n._key.path),l={next:p=>{e[a]&&e[a](db(u,n,p))},error:e[a+1],complete:e[a+2]};else{const p=Gt(n,Vn);u=Gt(p.firestore,fs),h=p._query;const m=new Xd(u);l={next:w=>{e[a]&&e[a](new lb(u,m,p,w))},error:e[a+1],complete:e[a+2]},ib(n._query)}return function(m,w,E,N){const $=new Fd(N),B=new Dd(w,$,E);return m.asyncQueue.enqueueAndForget(async()=>Rd(await lc(m),B)),()=>{$.$a(),m.asyncQueue.enqueueAndForget(async()=>$d(await lc(m),B))}}(Kc(u),h,o,l)}function th(n,e){return function(s,i){const r=new pn;return s.asyncQueue.enqueueAndForget(async()=>_S(await LS(s),i,r)),r.promise}(Kc(n),e)}function db(n,e,t){const s=t.docs.get(e._key),i=new Xd(n);return new cb(n,i,e._key,s,new qr(t.hasPendingWrites,t.fromCache),e.converter)}class iA{constructor(e){let t;this.kind="persistent",e!=null&&e.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=cA(),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function rA(n){return new iA(n)}class aA{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Ld,this._offlineComponentProvider=new Kv(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes,this.forceOwnership)}}class oA{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Ld,this._offlineComponentProvider=new xS(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes)}}function cA(n){return new aA(void 0)}function lA(){return new oA}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hb(){return new Ma("deleteField")}(function(e,t=!0){(function(i){ir=i})(tr),xi(new Us("firestore",(s,{instanceIdentifier:i,options:r})=>{const a=s.getProvider("app").getImmediate(),o=new fs(new G0(s.getProvider("auth-internal")),new J0(s.getProvider("app-check-internal")),function(u,h){if(!Object.prototype.hasOwnProperty.apply(u.options,["projectId"]))throw new L(x.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Ws(u.options.projectId,h)}(a,i),a);return r=Object.assign({useFetchStreams:t},r),o._setSettings(r),o},"PUBLIC").setMultipleInstances(!0)),ns(hp,"4.6.3",e),ns(hp,"4.6.3","esm2017")})();const Vu={apiKey:"AIzaSyC9Um4cxmF3LT_f9Ade5gYSj4ZjMbPHZU4",authDomain:"cursing-offers.firebaseapp.com",projectId:"cursing-offers",storageBucket:"cursing-offers.firebasestorage.app",messagingSenderId:"782347533500",appId:"1:782347533500:web:5da31b9357632fc055a4b9"};function uA(){const n=Date.now(),e=864e5,t=new Date().toISOString().slice(0,10),s=(r,a,o)=>({desc:r,qty:a,price:o,disc:0}),i=(r,a,o,l,u,h,p,m,w,E)=>({id:r,number:a,ts:n-w*e,date:new Date(n-w*e).toISOString().slice(0,10),customer:{name:o,phone:l,email:"",afm:"",address:u},subject:h,status:p,total:m,vatMode:"on",lines:E});return{quotes:[i("q1","2311","Γιώργος Παπαδόπουλος","6900000001","Πρέβεζα","Εγκατάσταση CCTV και WiFi","accepted",1437.16,3,[s("Hikvision IP 4MP Bullet",4,89),s("NVR 8 καναλιών + 2TB",1,245),s("UniFi U6 Lite",2,119),s("Εργασία εγκατάστασης",1,320)]),i("q2","2310","Hotel Aktaion","6900000002","Βόνιτσα","WiFi ξενοδοχείου 40 δωμάτια","pending",6920,5,[s("UniFi U6+",20,159),s("Switch PoE 24 θυρών",1,420),s("Εργασία",1,1700)]),i("q3","2309","Μαρία Νικολάου","6900000003","Λευκάδα","Συναγερμός Paradox","done",780,700,[s("Paradox MG5050 set",1,480),s("Εργασία",1,149)]),i("q4","2307","Κώστας Δήμου","6900000004","Πρέβεζα","Κάμερες καταστήματος","rejected",1150,12,[s("Dahua 4MP Dome",6,95),s("Εργασία",1,357)]),i("q5","2306","Σταύρος Σταύρου","6900000005","Πάλαιρος","Θυροτηλέφωνο + κάμερα","pending",540,1,[s("Θυροτηλέφωνο IP",1,290),s("Εργασία",1,145)])],products:[{id:"p1",img:"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100'><rect width='100' height='100' fill='%23eef'/><circle cx='50' cy='50' r='26' fill='%231d5c8a'/><circle cx='50' cy='50' r='10' fill='%23fff'/></svg>",imgW:100,imgH:100,cat:"Κάμερες",model:"Hikvision IP 4MP Bullet",desc:"DS-2CD2043",cost:71.2,minQty:8,links:[{sup:"Xpatit",url:"https://xpatit.gr",code:"HK-2043"}]},{id:"p2",cat:"Κάμερες",model:"Dahua 4MP Dome",desc:"",cost:76},{id:"p3",cat:"Καταγραφικά",model:"NVR 8 καναλιών",desc:"με δίσκο 2TB",cost:196},{id:"p4",cat:"WiFi",model:"UniFi U6 Lite",desc:"Access Point",cost:95.2},{id:"p5",cat:"WiFi",model:"UniFi U6+",desc:"",cost:127.2},{id:"p6",cat:"Συναγερμοί",model:"Paradox MG5050",desc:"set",cost:384}],smoves:[{id:"m1",pid:"p1",qty:6}],custs:[{id:"c1",name:"Γιώργος Παπαδόπουλος",phone:"6900000001",address:"Πρέβεζα",ts:n-30*e}],tasks:[{id:"t1",title:"Εγκατάσταση CCTV",date:t,time:"09:00",cust:"Γιώργος Παπαδόπουλος",tel:"6900000001",addr:"Πρέβεζα",emps:["e1"],rems:[60,0],done:!1,chk:[{tx:"4 κάμερες",dn:!0},{tx:"NVR + δίσκος",dn:!1},{tx:"Ρύθμιση εφαρμογής",dn:!1}],quoteId:"q1"},{id:"t2",title:"Αυτοψία WiFi ξενοδοχείου",date:t,time:"13:30",cust:"Hotel Aktaion",addr:"Βόνιτσα",done:!1,clr:9},{id:"t3",title:"Service συναγερμού",date:t,time:"17:00",cust:"Μαρία Νικολάου",addr:"Λευκάδα",done:!0},{id:"t4",title:"Ασφάλεια βαν",kind:"due",rep:"y",date:new Date(n+5*e).toISOString().slice(0,10),done:!1,rems:[1440,0]},{id:"t5",title:"Παραγγελία Xpatit",date:new Date(n-2*e).toISOString().slice(0,10),done:!1},{id:"t6",title:"Τηλέφωνο σε Σταύρο για θυροτηλέφωνο",date:"",done:!1},{id:"t7",title:"Συνδρομή Starlink",kind:"due",rep:"m",date:new Date(n+9*e).toISOString().slice(0,10),done:!1},{id:"t8",title:"Εγκατάσταση WiFi",date:new Date(n+e).toISOString().slice(0,10),time:"10:00",cust:"Hotel Aktaion",addr:"Βόνιτσα",emps:["e1"],done:!1}],ldocs:[{id:"d3",kind:"purchase",party:"Xpatit",number:"ΤΔΑ 1182",cat:"Εμπορεύματα",net:820,vat:196.8,rate:24,gross:1016.8,date:t,ts:n-e,items:[]},{id:"d4",kind:"purchase",party:"Cosmote",number:"",cat:"Τηλεπικοινωνίες",net:45,vat:10.8,rate:24,gross:55.8,date:t,ts:n-3*e,items:[]},{id:"d1",kind:"sale",qid:"q1",number:"2311",party:"Γιώργος Παπαδόπουλος",net:1159,vat:278.16,rate:24,gross:1437.16,date:t,ts:n-2*e},{id:"d2",kind:"sale",party:"Μαρία Νικολάου",gross:780,date:t,ts:n-30*e}],wdays:[{id:"w1",empId:"e1",date:t,days:1,amount:60},{id:"w2",empId:"e1",date:t,days:1,amount:60}],needs:[{id:"n1",ts:n-e,title:"Κρουστικό δράπανο",qty:"1",notes:"",by:{uid:"e",name:"Νίκος Τεχνικός"},done:!1},{id:"n2",ts:n-3*e,title:"Βίδες γυψοσανίδας",qty:"2 κουτιά",by:{uid:"demo",name:"Διαχειριστής"},done:!0,doneAt:n-e}],wpays:[{id:"wp1",empId:"e1",date:t,amount:50,method:"cash"}],lpays:[{id:"p3",dir:"out",date:t,party:"Xpatit",docId:"d3",amount:400,method:"bank",note:""},{id:"p1",docId:"d1",amount:500,dir:"in",date:t,party:"Γιώργος Παπαδόπουλος",method:"bank",note:"Προκαταβολή"},{id:"p2",docId:"d2",amount:780,dir:"in",date:t,party:"Μαρία Νικολάου",method:"cash",note:""}],emps:[{id:"e1",name:"Νίκος Τεχνικός",rate:60}],st:{main:{vat:24,margin:25,next:2312},books:{opening:1500,costCats:["Εμπορεύματα","Υλικά","Καύσιμα","Τηλεπικοινωνίες","Λοιπά έξοδα"]}}}}const Ou={quotes:"quotes",custs:"customers",tasks:"tasks",ldocs:"ledger_docs",lpays:"ledger_pays",emps:"employees",products:"products",smoves:"stock_moves",wdays:"workdays",wpays:"wagepays",needs:"tool_needs"},Fa={...Ou,qlog:"quote_log",pbuys:"partner_buys"},k={quotes:[],custs:[],tasks:[],ldocs:[],lpays:[],emps:[],products:[],smoves:[],wdays:[],wpays:[],needs:[],st:{}},fb=new Set;function dA(n){fb.add(n)}function Wt(){fb.forEach(n=>n())}const Je=new URLSearchParams(location.search).has("demo"),ni=Je;let Kt=null,Me=null,hc=[];const Qr={},hA=()=>Kt&&Kt.currentUser||null;function fA(n){if(Je){Object.assign(k,uA()),n({email:"demo@techmate"}),setTimeout(Wt,0);return}const e=Eg(Vu);Kt=j0(e),Me=WS(e,{localCache:rA({tabManager:lA()})}),RE(Kt,t=>{hc.forEach(s=>s()),hc=[],t&&pA(),n(t)})}let Si=[],Dr=null;function pA(){Dr=null,hc.push(xu(kn(Me,"settings"),n=>{const e={};n.docs.forEach(r=>e[r.id]=r.data()),k.st=e;const t=Kt.currentUser,s=t&&(e.roles&&e.roles.users||{})[t.uid],i=s&&s.role==="team"?"team:"+(s.empId||""):"owner";i!==Dr&&(Dr=i,bm(i)),Wt()},()=>{Dr===null&&(Dr="owner",bm("owner"))})),hc.push(()=>{Si.forEach(n=>n()),Si=[]})}function bm(n){Si.forEach(s=>s()),Si=[],Object.keys(Ou).forEach(s=>{s!=="tasks"&&(k[s]=[],delete Qr[s])});const e=(s,i)=>Si.push(xu(i,r=>{k[s]=r.docs.map(a=>({...a.data(),id:a.id})),Qr[s]=!0,Wt()},()=>{k[s]=[],Wt()}));if(n==="owner"){Object.entries(Ou).forEach(([s,i])=>e(s,kn(Me,i)));return}const t=n.slice(5);e("tasks",kn(Me,"tasks")),e("needs",kn(Me,"tool_needs")),t&&(e("wdays",dc(kn(Me,"workdays"),gm("empId","==",t))),e("wpays",dc(kn(Me,"wagepays"),gm("empId","==",t))),Si.push(xu(Rt(Me,"employees",t),s=>{k.emps=s.exists()?[{...s.data(),id:s.id}]:[],Qr.emps=!0,Wt()},()=>{k.emps=[],Wt()})))}function mA(n,e){return SE(Kt,n,e)}function pb(){return Je?location.assign(location.pathname):$E(Kt)}const qe=n=>String(n||"").trim().toLowerCase(),A=(n,e=0)=>{const t=parseFloat(n);return isNaN(t)?e:t},q=n=>Math.round(n*100)/100,pt=n=>n.status||"pending",mn=n=>!!(n&&n.kind==="install"),Mo={pending:"Σε αναμονή",accepted:"Δεκτή",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"};function Yc(n){let e=0;return k.lpays.forEach(t=>{t.docId===n&&(e+=A(t.amount))}),q(e)}function mb(n){return Math.max(0,q(A(n.gross)-Yc(n.id)))}function yn(){const n={},e=t=>{const s=qe(t)||"_none";return n[s]||(n[s]={k:s,name:t||"(χωρίς όνομα)",quotes:[],mins:[],last:0})};return k.custs.forEach(t=>{const s=e(t.name);s.name=t.name,s.rec=t,s.last=Math.max(s.last,t.upd||t.ts||0)}),k.quotes.forEach(t=>{const s=e(t.customer&&t.customer.name);(mn(t)?s.mins:s.quotes).push(t),s.last=Math.max(s.last,t.ts||0)}),k.ldocs.forEach(t=>{t.kind==="sale"&&e(t.party)}),Object.values(n).map(t=>{t.won=0,t.owed=0,t.docs=k.ldocs.filter(r=>r.kind==="sale"&&qe(r.party)===t.k),t.quotes.forEach(r=>{const a=pt(r);(a==="accepted"||a==="done")&&(t.won+=A(r.total))}),t.docs.forEach(r=>{t.owed+=mb(r),t.last=Math.max(t.last,r.ts||0)}),t.owed=q(t.owed),t.won=q(t.won);const s=t.quotes.slice().sort((r,a)=>(a.ts||0)-(r.ts||0))[0],i=s&&s.customer||{};return t.info={},["phone","email","afm","address"].forEach(r=>t.info[r]=t.rec&&t.rec[r]||i[r]||""),t})}const Qe=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),Se=n=>JSON.parse(JSON.stringify(n)),se=()=>k.st.main;let gb=()=>{};function gA(n){gb=n}const vn=n=>{n.catch(e=>gb(e))},yb={quotes:"Προσφορά",custs:"Πελάτης",tasks:"Εργασία",ldocs:"Παραστατικό",lpays:"Πληρωμή",emps:"Υπάλληλος",products:"Προϊόν",smoves:"Κίνηση αποθήκης",wdays:"Μεροκάματο",wpays:"Πληρωμή υπαλλήλου",needs:"Εργαλείο που λείπει"},yA=new Set(["id","upd","ts","dirty","img","imgW","imgH","imgFull","costHist","msId","msList","created","updated"]),vA=yb,Jr=[],bA=n=>{if(!n)return"";const e=n.number?"#"+n.number+(n.customer&&n.customer.name?" · "+n.customer.name:""):n.name||n.model||n.title||n.subject||n.desc||n.note||n.item||"";return String(e).slice(0,80)},_m=n=>{if(n==null||n==="")return"—";const e=typeof n=="object"?JSON.stringify(n):String(n);return e.length>100?e.slice(0,100)+"…":e};function ps(n,e,t,s,i,r,a){if(e!=="set"&&e!=="web"&&!yb[e])return;const o=[],l={};if(n==="edit"&&((r||Object.keys(i||{})).forEach(h=>{if(yA.has(h))return;const p=s?s[h]:void 0,m=i?i[h]:void 0;if(JSON.stringify(p)!==JSON.stringify(m)){o.push({k:h,o:_m(p),n:_m(m)});try{JSON.stringify(p??null).length<5e3&&(l[h]=p===void 0?null:p)}catch{}}}),!o.length))return;const u={id:Math.random().toString(36).slice(2)+Date.now().toString(36),ts:Date.now(),user:Kt&&Kt.currentUser&&Kt.currentUser.email||(Je?"demo":""),area:e,act:n,rid:t||"",name:a||bA(i||s)};if(o.length&&(u.diff=o.slice(0,30),u.old=l),n==="delete"&&s)try{JSON.stringify(s).length<6e4?u.before=s:u.big=!0}catch{}Jr.unshift(u),Jr.length>300&&Jr.pop(),!Je&&Me&&ws(Rt(Me,"app_log",u.id),JSON.parse(JSON.stringify(u))).catch(()=>{})}async function _A(){let n=[];if(!Je)try{n=(await Zd(dc(kn(Me,"app_log"),rb("ts","desc"),ab(300)))).docs.map(s=>s.data())}catch{}const e=new Set(Jr.map(t=>t.id));return[...Jr,...n.filter(t=>!e.has(t.id))].sort((t,s)=>s.ts-t.ts)}function We(n,e){const t=Se(e);delete t.id;const s=k[n];let i=null;if(s){const r=s.findIndex(a=>a.id===e.id);r>=0?(i=s[r],s[r]=Se(e)):s.push(Se(e))}ps(i?"edit":"create",n,e.id,i,e),Je||vn(ws(Rt(Me,Fa[n],e.id),t)),Wt()}function vb(n,e){ps("delete",n,e,(k[n]||[]).find(t=>t.id===e)||null,null),k[n]&&(k[n]=k[n].filter(t=>t.id!==e)),Je||vn(eh(Rt(Me,Fa[n],e))),Wt()}const Hi=()=>Je?{uid:"demo",email:"demo@techmate"}:Kt&&Kt.currentUser;function Js(n,e,t){const s=(k[n]||[]).find(r=>r.id===e);if(s){const r=Se(s);Object.keys(t).forEach(a=>{t[a]===void 0?delete s[a]:s[a]=t[a]}),ps("edit",n,e,r,s,Object.keys(t))}const i={};Object.keys(t).forEach(r=>i[r]=t[r]===void 0?hb():t[r]),Je||vn(ub(Rt(Me,Fa[n],e),i)),Wt()}function Ht(n,e,t){const s=k[n];let i=s&&s.find(o=>o.id===e),r=i?Se(i):null;s&&!i&&(i={id:e},s.push(i)),i&&Object.keys(t).forEach(o=>{t[o]===void 0?delete i[o]:i[o]=Se(t[o])}),i&&ps(r?"edit":"create",n,e,r,i,Object.keys(t));const a={};Object.keys(t).forEach(o=>{o!=="id"&&(a[o]=t[o]===void 0?hb():Se(t[o]))}),Je||vn(ws(Rt(Me,Fa[n],e),a,{merge:!0})),Wt()}function wm(n,e){Je||vn(ws(Rt(Me,"product_imgs",n),{d:e.d,w:e.w,h:e.h}))}function wA(n){Je||vn(eh(Rt(Me,"product_imgs",n)))}const Ys={};async function bb(n){if(Je)return Ys[n]?Se(Ys[n]):null;const e=await sA(Rt(Me,n));return e.exists()?e.data():null}async function IA(n){return Je?Object.keys(Ys).filter(t=>t.startsWith(n+"/")).map(t=>({...Se(Ys[t]),id:t.slice(n.length+1)})):(await Zd(kn(Me,n))).docs.map(t=>({...t.data(),id:t.id}))}async function Qi(n,e){const t=Object.keys(e).filter(s=>!["json","full","thumb","upd","photos","vis","cardsV","svcV","ts"].includes(s));if(!n.startsWith("public_photos_full/")&&(t.length||e.json)&&ps("web","web",n,null,null,null,"Ιστοσελίδα: "+(n==="public/articles"?"άρθρα":n==="public/site"?"περιεχόμενο":n.startsWith("public_photos/")?"φωτογραφία":n)+(t.length&&n!=="public/articles"?" ("+t.join(", ")+")":"")),Je){Ys[n]={...Ys[n]||{},...Se(e)};return}await ws(Rt(Me,n),e,{merge:!0})}async function Im(n){if(ps("web","web",n,null,null,null,"Ιστοσελίδα: διαγραφή "+n),Je){delete Ys[n];return}await eh(Rt(Me,n))}function EA(n){k.st.main&&(k.st.main.next=n),Je||vn(ws(Rt(Me,"settings","main"),{next:n},{merge:!0}))}const nh=n=>A(n.qty)*A(n.price)*(1-A(n.disc)/100),sh=n=>q((n.lines||[]).reduce((e,t)=>e+nh(t),0));function _b(n){const e=sh(n),t=n.vatMode==="off",s=A(se()&&se().vat,24),i=t?0:q(e*s/100);return{sub:e,vat:i,vp:s,off:t,total:q(e+i)}}function Xc(n){const e=A(n.cost,0);if(n.marginEur!=null&&n.marginEur!=="")return q(e+A(n.marginEur));const t=n.margin==null||n.margin===""?A(se()&&se().margin,25):A(n.margin);return q(e*(1+t/100))}function wb(n,e){let t=0,s=0,i=0;return k.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(a=>{a.pid===n&&(t+=A(a.qty))})}),k.smoves.forEach(r=>{r.pid===n&&(t+=A(r.qty))}),k.quotes.forEach(r=>{if(r.id===e)return;const a=pt(r);(r.lines||[]).forEach(o=>{if(o.pid!==n||o.src!=="stock")return;const l=A(o.qty);a==="done"?r.noStock||(s+=l):a==="accepted"&&(i+=l)})}),q(t-s-i)}function mo(n,e){if(!["main","logo","books","meta"].includes(n))return;const t=k.st[n]||(k.st[n]={}),s=Se(t);Object.keys(e).forEach(r=>{t[r]=Se(e[r])}),n!=="logo"?ps("edit","set",n,s,t,Object.keys(e),"Ρυθμίσεις ("+n+")"):ps("edit","set",n,null,null,null,"Ρυθμίσεις: αλλαγή λογοτύπου");const i={};Object.keys(e).forEach(r=>i[r]=Se(e[r])),Je||vn(ws(Rt(Me,"settings",n),i,{merge:!0})),Wt()}function fc(n,e,t,s){const i=(k[n]||[]).find(o=>o.id===e);if(!i)return;const r=t.split(".");let a=i;for(let o=0;o<r.length-1;o++)(!a[r[o]]||typeof a[r[o]]!="object")&&(a[r[o]]={}),a=a[r[o]];a[r[r.length-1]]=Se(s),Je||vn(ub(Rt(Me,Fa[n],e),{[t]:Se(s)})),Wt()}async function TA(){return Je?[{id:"m1",name:"Νίκος Δημητρίου",phone:"6911111111",email:"",msg:"Θέλω προσφορά για 4 κάμερες σε κατάστημα.",svc:"Κάμερες",area:"Χαλκίδα",day:"Απόγευμα",at:new Date().toISOString(),read:!1},{id:"m2",name:"Ελένη Κ.",phone:"",email:"eleni@example.gr",msg:"Πρόβλημα με το WiFi στο ξενοδοχείο.",svc:"WiFi",area:"",day:"",at:new Date(Date.now()-864e5*3).toISOString(),read:!0}]:(await Zd(dc(kn(Me,"contact"),rb("at","desc"),ab(50)))).docs.map(e=>({...e.data(),id:e.id}))}function kA(n){Je||vn(ws(Rt(Me,"contact",n),{read:!0},{merge:!0}))}/*! Capacitor: https://capacitorjs.com/ - MIT License */var Ji;(function(n){n.Unimplemented="UNIMPLEMENTED",n.Unavailable="UNAVAILABLE"})(Ji||(Ji={}));class jl extends Error{constructor(e,t,s){super(e),this.message=e,this.code=t,this.data=s}}const SA=n=>{var e,t;return n!=null&&n.androidBridge?"android":!((t=(e=n==null?void 0:n.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||t===void 0)&&t.bridge?"ios":"web"},AA=n=>{const e=n.CapacitorCustomPlatform||null,t=n.Capacitor||{},s=t.Plugins=t.Plugins||{},i=()=>e!==null?e.name:SA(n),r=()=>i()!=="web",a=p=>{const m=u.get(p);return!!(m!=null&&m.platforms.has(i())||o(p))},o=p=>{var m;return(m=t.PluginHeaders)===null||m===void 0?void 0:m.find(w=>w.name===p)},l=p=>n.console.error(p),u=new Map,h=(p,m={})=>{const w=u.get(p);if(w)return console.warn(`Capacitor plugin "${p}" already registered. Cannot register plugins twice.`),w.proxy;const E=i(),N=o(p);let $;const B=async()=>(!$&&E in m?$=typeof m[E]=="function"?$=await m[E]():$=m[E]:e!==null&&!$&&"web"in m&&($=typeof m.web=="function"?$=await m.web():$=m.web),$),J=(y,v)=>{var I,T;if(N){const P=N==null?void 0:N.methods.find(b=>v===b.name);if(P)return P.rtype==="promise"?b=>t.nativePromise(p,v.toString(),b):(b,$t)=>t.nativeCallback(p,v.toString(),b,$t);if(y)return(I=y[v])===null||I===void 0?void 0:I.bind(y)}else{if(y)return(T=y[v])===null||T===void 0?void 0:T.bind(y);throw new jl(`"${p}" plugin is not implemented on ${E}`,Ji.Unimplemented)}},H=y=>{let v;const I=(...T)=>{const P=B().then(b=>{const $t=J(b,y);if($t){const nn=$t(...T);return v=nn==null?void 0:nn.remove,nn}else throw new jl(`"${p}.${y}()" is not implemented on ${E}`,Ji.Unimplemented)});return y==="addListener"&&(P.remove=async()=>v()),P};return I.toString=()=>`${y.toString()}() { [capacitor code] }`,Object.defineProperty(I,"name",{value:y,writable:!1,configurable:!1}),I},ae=H("addListener"),O=H("removeListener"),U=(y,v)=>{const I=ae({eventName:y},v).then(b=>b),T=async()=>{const b=await I;await O({eventName:y,callbackId:b})},P=new Promise(b=>I.then(()=>b({remove:T})));return P.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await T()},P},_=new Proxy({},{get(y,v){switch(v){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return N?U:ae;case"removeListener":return O;default:return H(v)}}});return s[p]=_,u.set(p,{name:p,proxy:_,platforms:new Set([...Object.keys(m),...N?[E]:[]])}),_};return t.convertFileSrc||(t.convertFileSrc=p=>p),t.getPlatform=i,t.handleError=l,t.isNativePlatform=r,t.isPluginAvailable=a,t.registerPlugin=h,t.Exception=jl,t.DEBUG=!!t.DEBUG,t.isLoggingEnabled=!!t.isLoggingEnabled,t},PA=n=>n.Capacitor=AA(n),ga=PA(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),Ua=ga.registerPlugin;class ih{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let s=!1;this.listeners[e]||(this.listeners[e]=[],s=!0),this.listeners[e].push(t);const r=this.windowListeners[e];r&&!r.registered&&this.addWindowListener(r),s&&this.sendRetainedArgumentsForEvent(e);const a=async()=>this.removeListener(e,t);return Promise.resolve({remove:a})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,s){const i=this.listeners[e];if(!i){if(s){let r=this.retainedEventArguments[e];r||(r=[]),r.push(t),this.retainedEventArguments[e]=r}return}i.forEach(r=>r(t))}hasListeners(e){var t;return!!(!((t=this.listeners[e])===null||t===void 0)&&t.length)}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:s=>{this.notifyListeners(t,s)}}}unimplemented(e="not implemented"){return new ga.Exception(e,Ji.Unimplemented)}unavailable(e="not available"){return new ga.Exception(e,Ji.Unavailable)}async removeListener(e,t){const s=this.listeners[e];if(!s)return;const i=s.indexOf(t);i!==-1&&this.listeners[e].splice(i,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(s=>{this.notifyListeners(e,s)}))}}const Em=n=>encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Tm=n=>n.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class RA extends ih{async getCookies(){const e=document.cookie,t={};return e.split(";").forEach(s=>{if(s.length<=0)return;let[i,r]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");i=Tm(i).trim(),r=Tm(r).trim(),t[i]=r}),t}async setCookie(e){try{const t=Em(e.key),s=Em(e.value),i=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",r=(e.path||"/").replace("path=",""),a=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${t}=${s||""}${i}; path=${r}; ${a};`}catch(t){return Promise.reject(t)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(t){return Promise.reject(t)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const t of e)document.cookie=t.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}Ua("CapacitorCookies",{web:()=>new RA});const $A=async n=>new Promise((e,t)=>{const s=new FileReader;s.onload=()=>{const i=s.result;e(i.indexOf(",")>=0?i.split(",")[1]:i)},s.onerror=i=>t(i),s.readAsDataURL(n)}),CA=(n={})=>{const e=Object.keys(n);return Object.keys(n).map(i=>i.toLocaleLowerCase()).reduce((i,r,a)=>(i[r]=n[e[a]],i),{})},DA=(n,e=!0)=>n?Object.entries(n).reduce((s,i)=>{const[r,a]=i;let o,l;return Array.isArray(a)?(l="",a.forEach(u=>{o=e?encodeURIComponent(u):u,l+=`${r}=${o}&`}),l.slice(0,-1)):(o=e?encodeURIComponent(a):a,l=`${r}=${o}`),`${s}&${l}`},"").substr(1):null,NA=(n,e={})=>{const t=Object.assign({method:n.method||"GET",headers:n.headers},e),i=CA(n.headers)["content-type"]||"";if(typeof n.data=="string")t.body=n.data;else if(i.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[a,o]of Object.entries(n.data||{}))r.set(a,o);t.body=r.toString()}else if(i.includes("multipart/form-data")||n.data instanceof FormData){const r=new FormData;if(n.data instanceof FormData)n.data.forEach((o,l)=>{r.append(l,o)});else for(const o of Object.keys(n.data))r.append(o,n.data[o]);t.body=r;const a=new Headers(t.headers);a.delete("content-type"),t.headers=a}else(i.includes("application/json")||typeof n.data=="object")&&(t.body=JSON.stringify(n.data));return t};class xA extends ih{async request(e){const t=NA(e,e.webFetchExtra),s=DA(e.params,e.shouldEncodeUrlParams),i=s?`${e.url}?${s}`:e.url,r=await fetch(i,t),a=r.headers.get("content-type")||"";let{responseType:o="text"}=r.ok?e:{};a.includes("application/json")&&(o="json");let l,u;switch(o){case"arraybuffer":case"blob":u=await r.blob(),l=await $A(u);break;case"json":l=await r.json();break;case"document":case"text":default:l=await r.text()}const h={};return r.headers.forEach((p,m)=>{h[m]=p}),{data:l,headers:h,status:r.status,url:r.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}Ua("CapacitorHttp",{web:()=>new xA});var km;(function(n){n.Dark="DARK",n.Light="LIGHT",n.Default="DEFAULT"})(km||(km={}));var Sm;(function(n){n.StatusBar="StatusBar",n.NavigationBar="NavigationBar"})(Sm||(Sm={}));class VA extends ih{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}Ua("SystemBars",{web:()=>new VA});const OA="modulepreload",MA=function(n){return"/"+n},Am={},zn=function(e,t,s){let i=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),o=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));i=Promise.allSettled(t.map(l=>{if(l=MA(l),l in Am)return;Am[l]=!0;const u=l.endsWith(".css"),h=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${h}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":OA,u||(p.as="script"),p.crossOrigin="",p.href=l,o&&p.setAttribute("nonce",o),document.head.appendChild(p),u)return new Promise((m,w)=>{p.addEventListener("load",m),p.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${l}`)))})}))}function r(a){const o=new Event("vite:preloadError",{cancelable:!0});if(o.payload=a,window.dispatchEvent(o),!o.defaultPrevented)throw a}return i.then(a=>{for(const o of a||[])o.status==="rejected"&&r(o.reason);return e().catch(r)})},LA="__capgo_keep_url_path_after_reload",Bl="__capgo_history_stack__",Pm=100,FA=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(FA){const n=window;if(!n.__capgoHistoryPatched){n.__capgoHistoryPatched=!0;const e=()=>{try{if(n.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(LA)==="1"}catch{return!1}},t=()=>{try{const O=window.sessionStorage.getItem(Bl);if(!O)return{stack:[],index:-1};const U=JSON.parse(O);return!U||!Array.isArray(U.stack)||typeof U.index!="number"?{stack:[],index:-1}:U}catch{return{stack:[],index:-1}}},s=(O,U)=>{try{window.sessionStorage.setItem(Bl,JSON.stringify({stack:O,index:U}))}catch{}},i=()=>{try{window.sessionStorage.removeItem(Bl)}catch{}},r=O=>{try{const U=O??window.location.href,_=new URL(U instanceof URL?U.toString():U,window.location.href);return`${_.pathname}${_.search}${_.hash}`}catch{return null}},a=(O,U)=>{if(O.length<=Pm)return{stack:O,index:U};const _=O.length-Pm,y=O.slice(_),v=Math.max(0,U-_);return{stack:y,index:v}},o=O=>{document.readyState==="complete"||document.readyState==="interactive"?O():window.addEventListener("DOMContentLoaded",O,{once:!0})};let l=!1,u=!1,h=!1;const p=()=>{if(!l)return;const O=t(),U=r();if(U){if(O.stack.length===0){O.stack.push(U),O.index=0,s(O.stack,O.index);return}(O.index<0||O.index>=O.stack.length)&&(O.index=O.stack.length-1),O.stack[O.index]!==U&&(O.stack[O.index]=U,s(O.stack,O.index))}},m=(O,U)=>{if(!l||u)return;const _=r(O);if(!_)return;let{stack:y,index:v}=t();y.length===0?(y.push(_),v=y.length-1):U?((v<0||v>=y.length)&&(v=y.length-1),y[v]=_):v>=y.length-1?(y.push(_),v=y.length-1):(y=y.slice(0,v+1),y.push(_),v=y.length-1),{stack:y,index:v}=a(y,v),s(y,v)},w=()=>{if(!l||u)return;const O=t();if(O.stack.length===0){p();return}const U=O.index>=0&&O.index<O.stack.length?O.index:O.stack.length-1,_=r();if(O.stack.length===1&&_===O.stack[0])return;const y=O.stack[0];if(!y)return;u=!0;try{history.replaceState(history.state,document.title,y);for(let T=1;T<O.stack.length;T+=1)history.pushState(history.state,document.title,O.stack[T])}catch{u=!1;return}u=!1;const v=O.stack.length-1,I=U-v;I!==0?history.go(I):(history.replaceState(history.state,document.title,O.stack[U]),window.dispatchEvent(new PopStateEvent("popstate")))},E=()=>{!l||h||(h=!0,o(()=>{h=!1,w()}))};let N=null,$=null;const B=()=>{if(!l||u)return;const O=r();if(!O)return;const U=t(),_=U.stack.lastIndexOf(O);_>=0?U.index=_:(U.stack.push(O),U.index=U.stack.length-1);const y=a(U.stack,U.index);s(y.stack,y.index)},J=()=>{N&&$||(N=history.pushState,$=history.replaceState,history.pushState=function(U,_,y){const v=N==null?void 0:N.call(history,U,_,y);return m(y,!1),v},history.replaceState=function(U,_,y){const v=$==null?void 0:$.call(history,U,_,y);return m(y,!0),v},window.addEventListener("popstate",B))},H=()=>{N&&(history.pushState=N,N=null),$&&(history.replaceState=$,$=null),window.removeEventListener("popstate",B)},ae=O=>{if(l===O){l&&(p(),E());return}l=O,l?(J(),p(),E()):(H(),i())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",O=>{var U;const _=O,y=(U=_==null?void 0:_.detail)===null||U===void 0?void 0:U.enabled;typeof y=="boolean"?(n.__capgoKeepUrlPathAfterReload=y,ae(y)):(n.__capgoKeepUrlPathAfterReload=!0,ae(!0))}),ae(e())}}var Rm;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",n[n.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",n[n.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(Rm||(Rm={}));var $m;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.PENDING=1]="PENDING",n[n.DOWNLOADING=2]="DOWNLOADING",n[n.INSTALLING=3]="INSTALLING",n[n.INSTALLED=4]="INSTALLED",n[n.FAILED=5]="FAILED",n[n.CANCELED=6]="CANCELED",n[n.DOWNLOADED=11]="DOWNLOADED"})($m||($m={}));var Cm;(function(n){n[n.OK=0]="OK",n[n.CANCELED=1]="CANCELED",n[n.FAILED=2]="FAILED",n[n.NOT_AVAILABLE=3]="NOT_AVAILABLE",n[n.NOT_ALLOWED=4]="NOT_ALLOWED",n[n.INFO_MISSING=5]="INFO_MISSING"})(Cm||(Cm={}));const ya=Ua("CapacitorUpdater",{web:()=>zn(()=>import("./web-DbLqhzUZ.js"),[]).then(n=>new n.CapacitorUpdaterWeb)}),On=ga.isNativePlatform(),Lt=On?Ua("TechMate"):null,Mu={accent:0,view:"lists",sun:!1,showDone:!0,compact:!1,defRems:"60,0",dueRems:"1440,0",rep:!0,repMin:5,repMax:6,snooze:10,alarmSound:!1,clockMode:!1,syncMin:60,notifyNew:!0,wAlpha:95,wMode:"todo",wList:"",wDays:2,autoUpd:!0,empClr:"{}",bUri:"",bAuto:!0,bLast:0};let Ls={...Mu};const Ib="tm-settings",rt=()=>Ls;async function va(){if(Lt)try{const n=await Lt.getSettings();Ls={...Mu,...n||{}}}catch{}else try{Ls={...Mu,...JSON.parse(localStorage.getItem(Ib)||"{}")}}catch{}return Ls}async function Yr(n,e){if(Ls={...Ls,[n]:e},Lt)try{await Lt.setSetting({k:n,v:e})}catch{}else try{localStorage.setItem(Ib,JSON.stringify(Ls))}catch{}}const Re=async(n,e={},t=null)=>{if(!Lt)return t;try{return await Lt[n](e)}catch(s){return{error:s&&s.message||"σφάλμα"}}},ue={setSession:n=>Re("setSession",n),clearSession:()=>Re("clearSession"),setTasks:(n,e,t)=>Re("setTasks",{json:n,emps:e,lists:t}),testNotif:()=>Re("testNotif"),openBattery:()=>Re("openBattery"),openNotifSettings:()=>Re("openNotifSettings"),exactAlarms:()=>Re("exactAlarms",{},{ok:!0}),msStatus:()=>Re("msStatus",{},{connected:!1}),msLogin:()=>Re("msLogin"),msSync:()=>Re("msSync",{},{ok:!1}),msDisconnect:()=>Re("msDisconnect"),pull:()=>Re("pull",{},{ok:!1}),backupPick:()=>Re("backupPick",{},{error:"Μόνο στο κινητό"}),backupWrite:n=>Re("backupWrite",{json:n},{error:"Μόνο στο κινητό"}),takeLaunch:()=>Re("takeLaunch",{},{}),installApk:(n,e)=>Re("installApk",{url:n,size:e}),copy:async n=>{if(Lt)return Re("copy",{text:n});try{await navigator.clipboard.writeText(n)}catch{}},paste:async()=>{if(Lt){const n=await Re("paste");return n&&n.text||""}try{return await navigator.clipboard.readText()}catch{return""}},share:n=>Lt?Re("share",{text:n}):ue.copy(n),filesStatus:()=>Re("filesStatus",{},{connected:!1,account:""}),filesLogin:()=>Re("filesLogin"),filesDisconnect:()=>Re("filesDisconnect"),filesToken:()=>Re("filesToken",{},{ok:!1,error:"Μόνο στο κινητό"}),minimize:()=>Re("minimize"),bioStatus:()=>Re("bioStatus",{},{available:!1}),bioAuth:()=>Re("bioAuth",{},{ok:!1,error:"Μόνο στο κινητό"}),on:(n,e)=>{Lt&&Lt.addListener(n,e)},shareFile:n=>Re("shareFile",n,{error:"Μόνο στο κινητό"}),refreshWidgets:()=>Re("refreshWidgets")};function si(n,e){Lt&&Lt.addListener(n,e)}const Eb="1.5.0",UA="https://raw.githubusercontent.com/cursing/techmate-app-releases/main/latest.json",Tb=ga.isNativePlatform(),Dm=(n,e)=>{const t=String(n).split(".").map(Number),s=String(e).split(".").map(Number);for(let i=0;i<3;i++){const r=(t[i]||0)-(s[i]||0);if(r)return r}return 0},Ge={state:"idle",latest:null,pct:0,err:"",needApk:!1,checkedAt:0};let kb=()=>{};function qA(n){kb=n}const Jt=n=>{Object.assign(Ge,n),kb()};function jA(){Tb&&(ya.notifyAppReady().catch(()=>{}),ya.addListener("download",n=>{Ge.state==="downloading"&&Jt({pct:Math.round(n.percent||0)})}),si("apk",n=>{Ge.state==="downloading"&&Jt({pct:n&&n.pct||0})}),Lu(),document.addEventListener("visibilitychange",()=>{!document.hidden&&Date.now()-Ge.checkedAt>30*6e4&&Lu()}))}async function Lu(n){if(!Tb){n&&Jt({state:"none"});return}if(Ge.state!=="downloading"){n&&Jt({state:"checking",err:""});try{const e=await fetch(UA+"?t="+Date.now(),{cache:"no-store"});if(!e.ok)throw new Error("HTTP "+e.status);const t=await e.json();if(Ge.checkedAt=Date.now(),!t.version||Dm(t.version,Eb)<=0)return Jt({state:n?"none":"idle",latest:null});let s="0";try{s=(await ya.getBuiltinVersion()).version||"0"}catch{}Jt({state:"available",latest:t,needApk:!!t.minNative&&Dm(s,t.minNative)<0,err:""})}catch{Jt({state:n?"error":"idle",err:n?"Δεν μπόρεσα να ελέγξω για ενημέρωση. Έλεγξε τη σύνδεση.":""})}}}async function BA(){const n=Ge.latest;if(!(!n||Ge.state==="downloading")){if(Ge.needApk){Jt({state:"downloading",pct:0,err:""});const e=await ue.installApk(n.apk,n.apkSize||0);Jt({state:"available",err:e&&e.error?e.error:""});return}Jt({state:"downloading",pct:0,err:""});try{const e=await ya.download({url:n.zip,version:n.version,checksum:n.sha256||""});await ya.set(e)}catch(e){Jt({state:"available",err:"Η λήψη απέτυχε: "+(e&&(e.message||e.code)||"άγνωστο σφάλμα")})}}}const WA=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Fu=n=>WA.format(Math.round((n||0)*100)/100),Nm=n=>n<10?"0"+n:""+n,ve=()=>{const n=new Date;return n.getFullYear()+"-"+Nm(n.getMonth()+1)+"-"+Nm(n.getDate())},zA=n=>(n=A(n,24),[24,13,6,0].includes(n)?n:24),rh=()=>{const n=Hi();return n&&(k.st.roles&&k.st.roles.users||{})[n.uid]||null},Te=()=>{const n=rh();return!!(n&&n.role==="team")},Zt=()=>{const n=rh();return n&&n.empId||""},as=()=>{const n=Hi();if(!n)return null;const e=rh();return{uid:n.uid,name:e?e.name||"Υπάλληλος":"Διαχειριστής"}},ah=n=>!Te()||!!(n&&n.by&&Hi()&&n.by.uid===Hi().uid),Lo={pending:"Σε αναμονή απάντησης",accepted:"Έγινε δεκτή, προς εγκατάσταση",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"},Wl=(n,e,t)=>We("qlog",{id:Qe(),qid:n.id||"",number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:e,text:t}),Sb=n=>k.ldocs.find(e=>e.kind==="sale"&&(e.qid===n.id||!e.qid&&n.number&&e.number===n.number&&qe(e.party)===qe(n.customer&&n.customer.name)))||null,xm=n=>!(n&&n.war&&n.war.on===!1),GA=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(A(e.m,0))):A(se().warrantyMonths,24)};function KA(n,e){let t=0,s=0,i=0;return k.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(a=>{a.pid===n&&(t+=A(a.qty))})}),k.smoves.forEach(r=>{r.pid===n&&(t+=A(r.qty))}),k.quotes.forEach(r=>{if(r.id===e)return;const a=pt(r);(r.lines||[]).forEach(o=>{if(o.pid!==n||o.src!=="stock")return;const l=A(o.qty);a==="done"?r.noStock||(s+=l):a==="accepted"&&(i+=l)})}),q(t-s-i)}function HA(n,e){const t=[],s=Sb(n);if(e==="pending"||e==="rejected"?s&&s.qid===n.id&&s.note==="Από προσφορά "+(n.number||"")&&Yc(s.id)===0&&t.push("Θα αφαιρεθεί το παραστατικό πώλησης που είχε δημιουργηθεί αυτόματα."):!s&&se()&&se().autoSale!==!1&&t.push("Θα δημιουργηθεί παραστατικό πώλησης "+Fu(Ab(n).gross)+" στα Λογιστικά."),e==="done"&&!n.install&&t.push("Θα καταχωρηθεί ως εγκατάσταση με σημερινή ημερομηνία."),(e==="accepted"||e==="done")&&n.gid){const i=k.quotes.filter(r=>r.gid===n.gid&&r.id!==n.id&&pt(r)==="pending").length;i&&t.push("Οι "+i+" άλλες εναλλακτικές θα μπουν ως «Απορρίφθηκε».")}return t}function Ab(n){const e=n.vatMode==="off"?0:zA(se().vat),t=sh(n),s=q(t*e/100);return{rate:e,net:t,vat:s,gross:q(t+s)}}function QA(n,e){const t=k.quotes.find(o=>o.id===n);if(!t||pt(t)===e)return{ok:!1};if(!se())return{ok:!1,msg:"Δεν έχουν φορτώσει οι ρυθμίσεις. Περίμενε λίγο ή έλεγξε τη σύνδεση."};const s=Se(t);Wl(s,"status",Lo[pt(s)]+" → "+Lo[e]),e==="done"&&!s.install&&(s.install={date:ve(),months:xm(s)?GA(s):0,serials:"",nw:!xm(s)}),s.status=e,s.statusDate=ve();const i=[];e==="accepted"&&(s.lines||[]).forEach(o=>{if(o.pid&&o.src==="stock"&&A(o.qty)>KA(o.pid,s.id)){const l=k.products.find(u=>u.id===o.pid);i.push(l?l.model:o.desc)}});const r=[],a=Sb(s);if(e==="pending"||e==="rejected")a&&a.qid===s.id&&a.note==="Από προσφορά "+(s.number||"")&&Yc(a.id)===0&&(vb("ldocs",a.id),r.push("Αφαιρέθηκε το αυτόματο παραστατικό πώλησης."));else if(!a&&se().autoSale!==!1){const o=Ab(s),l={id:Qe(),ts:Date.now(),kind:"sale",date:ve(),party:s.customer&&s.customer.name||"Πελάτης",number:s.number||"",cat:"",net:o.net,vat:o.vat,gross:o.gross,rate:o.rate,note:"Από προσφορά "+(s.number||""),items:[],qid:s.id};We("ldocs",l),k.lpays.forEach(u=>{u.qid===s.id&&!u.docId&&Js("lpays",u.id,{docId:l.id,party:l.party||u.party})}),Wl(s,"edit","Δημιουργήθηκε αυτόματα παραστατικό πώλησης ("+Fu(o.gross)+")."),r.push("Δημιουργήθηκε παραστατικό πώλησης "+Fu(o.gross)+" στα Λογιστικά.")}return s.gid&&(e==="accepted"||e==="done")&&k.quotes.filter(o=>o.gid===s.gid&&o.id!==s.id&&pt(o)==="pending").forEach(o=>{const l=Se(o);l.status="rejected",l.statusDate=ve(),Wl(l,"status","Σε αναμονή → Απορρίφθηκε (έγινε δεκτή η εναλλακτική "+(s.number||"")+")"),We("quotes",l)}),We("quotes",s),i.length&&r.push("Δεν επαρκεί το απόθεμα για: "+i.join(", ")+"."),{ok:!0,msg:["Η κατάσταση άλλαξε: "+Lo[e]+"."].concat(r).join(" ")}}function JA(n,e){const t=String(e.name||"").trim();if(!t)return{msg:"Γράψε όνομα πελάτη."};const s=qe(t),i=yn(),r=n&&i.find(u=>u.k===n);if((!n||n!==s)&&i.some(u=>u.k===s))return{msg:"Υπάρχει ήδη πελάτης «"+t+"». Άνοιξε τον φάκελό του."};const a=n&&k.custs.find(u=>qe(u.name)===n),o=a?Se(a):{id:Qe(),ts:Date.now()},l=u=>String(e[u]||"").trim();return Object.assign(o,{name:t,phone:l("phone"),email:l("email"),afm:l("afm"),address:l("address"),notes:l("notes"),upd:Date.now()}),We("custs",o),n&&n!==s&&r&&(r.quotes.concat(r.mins).forEach(u=>{const h=Se(u);h.customer=Object.assign({},h.customer||{},{name:t}),We("quotes",h)}),k.ldocs.forEach(u=>{u.kind==="sale"&&qe(u.party)===n&&Js("ldocs",u.id,{party:t})}),k.lpays.forEach(u=>{u.dir==="in"&&qe(u.party)===n&&Js("lpays",u.id,{party:t})})),{ok:!0,k:s}}const it=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),YA=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),pe=n=>YA.format(Math.round((n||0)*100)/100),Pb=n=>String(q(n)).replace(".",","),Ci=n=>A(String(n).replace(",","."),NaN),ba=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},Vm=n=>n<10?"0"+n:""+n,fi=n=>n.getFullYear()+"-"+Vm(n.getMonth()+1)+"-"+Vm(n.getDate()),Rb=()=>k.st.books||{},XA=n=>(n=A(n,24),[24,13,6,0].includes(n)?n:24);let _a="month";try{_a=localStorage.getItem("tm_period")||"month"}catch{}const ZA=[["month","Μήνας"],["prevmonth","Προηγ. μήνας"],["quarter","Τρίμηνο"],["year","Έτος"],["all","Όλα"]];function $b(){const n=new Date,e=n.getFullYear(),t=n.getMonth();switch(_a){case"month":return[fi(new Date(e,t,1)),fi(new Date(e,t+1,0))];case"prevmonth":return[fi(new Date(e,t-1,1)),fi(new Date(e,t,0))];case"quarter":{const s=Math.floor(t/3)*3;return[fi(new Date(e,s,1)),fi(new Date(e,s+3,0))]}case"year":return[e+"-01-01",e+"-12-31"];default:return["",""]}}const Ns=n=>{const e=$b();return(!e[0]||n>=e[0])&&(!e[1]||n<=e[1])},eP=()=>{const n=$b();return!n[0]&&!n[1]?"Όλες οι κινήσεις":ba(n[0])+" έως "+ba(n[1])};function Cb(n){let e=0,t=0;return k.wdays.forEach(s=>{s.empId===n&&(e+=A(s.amount))}),k.wpays.forEach(s=>{s.empId===n&&(t+=A(s.amount))}),{earned:q(e),paid:q(t),bal:q(e-t)}}function Zc(){const n={},e={},t=(i,r)=>{const a=qe(r)||"—";return i[a]||(i[a]={name:(r||"").trim()||"Χωρίς όνομα",inv:0,paid:0})};k.ldocs.forEach(i=>{t(i.kind==="sale"?e:n,i.party).inv+=A(i.gross)}),k.lpays.forEach(i=>{t(i.dir==="in"?e:n,i.party).paid+=A(i.amount)});const s=i=>Object.values(i).map(r=>(r.inv=q(r.inv),r.paid=q(r.paid),r.bal=q(r.inv-r.paid),r)).sort((r,a)=>a.bal-r.bal);return{sup:s(n),cus:s(e)}}function tP(){const n={sNet:0,sVat:0,pNet:0,pVat:0,inBank:0,inCash:0,outBank:0,outCash:0,wages:0,cats:{}};k.ldocs.forEach(i=>{if(!(i.opening||!Ns(i.date)))if(i.kind==="sale")n.sNet+=A(i.net),n.sVat+=A(i.vat);else{n.pNet+=A(i.net),n.pVat+=A(i.vat);const r=i.cat||"Χωρίς κατηγορία";n.cats[r]=(n.cats[r]||0)+A(i.net)}}),k.lpays.forEach(i=>{Ns(i.date)&&(i.dir==="in"?i.method==="bank"?n.inBank+=A(i.amount):n.inCash+=A(i.amount):i.method==="bank"?n.outBank+=A(i.amount):n.outCash+=A(i.amount))}),k.wdays.forEach(i=>{Ns(i.date)&&(n.wages+=A(i.amount))}),k.wpays.forEach(i=>{Ns(i.date)&&(i.method==="bank"?n.outBank+=A(i.amount):n.outCash+=A(i.amount))}),Object.keys(n).forEach(i=>{typeof n[i]=="number"&&(n[i]=q(n[i]))}),n.vatDue=q(n.sVat-n.pVat),n.profit=q(n.sNet-n.pNet-n.wages);let e=A(Rb().opening,0),t=0;k.lpays.forEach(i=>{const r=i.dir==="in"?A(i.amount):-A(i.amount);i.method==="bank"?e+=r:t+=r}),k.wpays.forEach(i=>{i.method==="bank"?e-=A(i.amount):t-=A(i.amount)}),n.bank=q(e),n.cash=q(t),n.rcvAll=q(n.inBank+n.inCash),n.nRcv=k.lpays.filter(i=>i.dir==="in"&&Ns(i.date)).length;const s=Zc();return n.owe=0,n.due=0,n.nOwe=0,n.nDue=0,n.wOwe=0,n.nW=0,s.sup.forEach(i=>{i.bal>.004&&(n.owe+=i.bal,n.nOwe++)}),s.cus.forEach(i=>{i.bal>.004&&(n.due+=i.bal,n.nDue++)}),k.emps.forEach(i=>{const r=Cb(i.id).bal;r>.004&&(n.wOwe+=r,n.nW++)}),n.owe=q(n.owe),n.due=q(n.due),n.wOwe=q(n.wOwe),n}function qa(n){const e=Yc(n.id),t=q(A(n.gross)-e);return A(n.gross)!==0&&t<=.004?{k:"paid",t:n.kind==="sale"?"Εισπράχθηκε":"Πληρώθηκε",rem:0}:e>0?{k:"part",t:"Μερικώς",rem:t}:{k:"open",t:n.kind==="sale"?"Δεν εισπράχθηκε":"Ανεξόφλητο",rem:t}}const nP=(n,e)=>{const t=e==="in"?"sale":"purchase",s=qe(n);return k.ldocs.filter(i=>i.kind===t&&(!s||qe(i.party)===s)&&qa(i).k!=="paid").sort((i,r)=>i.date<r.date?1:-1)},Db=[["sum","Σύνοψη"],["docs","Παραστατικά"],["pays","Πληρωμές"],["bal","Υπόλοιπα"]];let Fo="all",ye=null;const oh=()=>!!ye;function sP(){ye=null}const go=(n,e,t="")=>`<div class="kpi"><b class="${t}">${n}</b><span>${e}</span></div>`,iP={paid:"p-ok",part:"p-w",open:"p-b"},rP=(n,e)=>`<div class="chips">${Db.map(([t,s])=>`<a href="#/books/${t}" class="chip${t===n?" on":""}">${s}</a>`).join("")}</div>
  ${n==="bal"?"":`<div class="chips">${ZA.map(([t,s])=>`<button data-bper="${t}" class="${t===_a?"on":""}">${s}</button>`).join("")}</div><div class="plabel">${eP()}</div>`}${e?"":'<div class="upd">Φόρτωση…</div>'}`;function aP(){const n=tP(),e=Object.entries(n.cats).sort((t,s)=>s[1]-t[1]);return`<div class="kpis">${go(pe(n.sNet),"Έσοδα (καθαρά)","ok")}${go(pe(n.pNet),"Αγορές και έξοδα (καθαρά)","bad")}${go(pe(n.wages),"Μεροκάματα")}${go(pe(n.profit),"Κέρδος περιόδου",n.profit<0?"bad":"")}</div>
  ${n.sVat||n.pVat?`<div class="h">ΦΠΑ</div><div class="card"><div class="tot"><span>ΦΠΑ πωλήσεων</span><span>${pe(n.sVat)}</span></div><div class="tot"><span>ΦΠΑ αγορών</span><span>${pe(n.pVat)}</span></div>
    <div class="tot big"><span>${n.vatDue>=0?"ΦΠΑ προς απόδοση":"ΦΠΑ πιστωτικό"}</span><span>${pe(Math.abs(n.vatDue))}</span></div></div>`:""}
  <div class="h">Χρήματα</div><div class="card"><div class="tot"><span>Εισπράξεις περιόδου${n.nRcv?" ("+n.nRcv+")":""}</span><span>${pe(n.rcvAll)}</span></div>
    <div class="tot"><span>· τράπεζα ${pe(n.inBank)} · μετρητά ${pe(n.inCash)}</span><span></span></div>
    <div class="tot"><span>Πληρωμές περιόδου</span><span>${pe(q(n.outBank+n.outCash))}</span></div>
    <div class="tot big"><span>Τράπεζα σήμερα</span><span>${pe(n.bank)}</span></div><div class="tot big"><span>Μετρητά στο ταμείο</span><span>${pe(n.cash)}</span></div></div>
  <div class="h">Υπόλοιπα</div><div class="card">
    <a class="row" href="#/books/bal"><div class="av">👥</div><div class="t"><b>Πελάτες μου χρωστούν</b><span>${n.nDue} πελάτες</span></div><span class="amt">${pe(n.due)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">🏭</div><div class="t"><b>Χρωστάω σε προμηθευτές</b><span>${n.nOwe} προμηθευτές</span></div><span class="amt">${pe(n.owe)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">👷</div><div class="t"><b>Μεροκάματα που χρωστάω</b><span>${n.nW} υπάλληλοι</span></div><span class="amt">${pe(n.wOwe)}</span></a></div>
  ${e.length?`<div class="h">Έξοδα ανά κατηγορία</div><div class="card">${e.map(([t,s])=>`<div class="tot"><span>${it(t)}</span><span>${pe(s)}</span></div>`).join("")}</div>`:""}`}function oP(){const n=k.ldocs.filter(e=>Ns(e.date)&&(Fo==="all"||e.kind===Fo)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0));return`<div class="chips">${[["all","Όλα"],["sale","Πωλήσεις"],["purchase","Αγορές"]].map(([e,t])=>`<button data-bdk="${e}" class="${Fo===e?"on":""}">${t}</button>`).join("")}</div>
  <div class="card">${n.map(e=>{const t=qa(e);return`<div class="row"><div class="av">${e.kind==="sale"?"📤":"📥"}</div>
    <div class="t"><b>${it(e.party)}</b><span>${ba(e.date)}${e.number?" · "+it(e.number):""}${e.cat?" · "+it(e.cat):""}${e.opening?" · παλιό υπόλοιπο":""}</span>${e.note?`<span>${it(e.note)}</span>`:""}
    ${t.k!=="paid"?`<button class="lnk" data-bpay="${it(e.id)}">${e.kind==="sale"?"💶 Είσπραξη":"💶 Πληρωμή"} ${pe(t.rem)}</button>`:""}</div>
    <div class="r"><div class="amt">${pe(e.gross)}</div><span class="pill ${iP[t.k]}">${t.t}</span></div></div>`}).join("")||'<div class="empty">Κανένα παραστατικό στην περίοδο</div>'}</div>`}function cP(){return`<div class="card">${k.lpays.filter(e=>Ns(e.date)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0)).map(e=>`<div class="row"><div class="av">${e.dir==="in"?"⬇️":"⬆️"}</div>
    <div class="t"><b>${it(e.party)}</b><span>${ba(e.date)} · ${e.method==="bank"?"τράπεζα":"μετρητά"}${e.note?" · "+it(e.note):""}</span></div>
    <div class="r"><div class="amt ${e.dir==="in"?"ok":"bad"}">${e.dir==="in"?"+":"−"}${pe(e.amount)}</div></div></div>`).join("")||'<div class="empty">Καμία κίνηση στην περίοδο</div>'}</div>`}function lP(){const n=Zc(),e=(s,i,r)=>s.map(a=>`<div class="row"><div class="t"><b>${it(a.name)}</b><span>τιμολογημένα ${pe(a.inv)} · πληρωμένα ${pe(a.paid)}</span>
    ${a.bal>.004?`<button class="lnk" data-bnew="${i}" data-party="${it(a.name)}">${i==="in"?"💶 Νέα είσπραξη":"💶 Νέα πληρωμή"}</button>`:""}</div>
    <div class="r"><span class="pill ${a.bal>.004?"p-b":a.bal<-.004?"p-w":"p-ok"}">${a.bal>.004?pe(a.bal):a.bal<-.004?"πιστωτικό "+pe(-a.bal):"εξοφλημένο"}</span></div></div>`).join("")||`<div class="empty">${r}</div>`,t=k.emps.slice().sort((s,i)=>String(s.name).localeCompare(i.name,"el"));return`<div class="h">Πελάτες</div><div class="card">${e(n.cus,"in","Δεν υπάρχουν πελάτες με παραστατικά")}</div>
  <div class="h">Προμηθευτές</div><div class="card">${e(n.sup,"out","Δεν υπάρχουν προμηθευτές")}</div>
  ${t.length?`<div class="h">Υπάλληλοι</div><div class="card">${t.map(s=>{const i=Cb(s.id);return`<div class="row"><div class="t"><b>${it(s.name)}</b><span>δεδουλευμένα ${pe(i.earned)} · πληρωμένα ${pe(i.paid)}</span></div>
    <div class="r"><span class="pill ${i.bal>.004?"p-b":i.bal<-.004?"p-w":"p-ok"}">${i.bal>.004?pe(i.bal):i.bal<-.004?"προπληρωμή "+pe(-i.bal):"τακτοποιημένο"}</span></div></div>`}).join("")}</div>`:""}`}const rn=(n,e,t="")=>`<label class="f">${e}<input class="in" data-bf="${n}" value="${it(ye.v[n]??"")}" ${t}></label>`,Xr=(n,e)=>`<div class="seg">${e.map(([t,s])=>`<button data-bseg="${n}" data-v="${t}" class="${ye.v[n]===t?"on":""}">${s}</button>`).join("")}</div>`;function uP(){const n=ye.v,e=nP(n.party,n.dir),t=Zc();return n.docId&&!e.some(s=>s.id===n.docId)&&(n.docId=""),`<div class="card pad">${Xr("dir",[["in","Είσπραξη από πελάτη"],["out","Πληρωμή σε προμηθευτή"]])}
    ${rn("date","Ημερομηνία",'type="date"')}${rn("party",n.dir==="in"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.dir==="in"?t.cus:t.sup).map(s=>`<option value="${it(s.name)}">`).join("")}</datalist>
    <label class="f">Παραστατικό<select class="in" data-bf="docId"><option value="">Χωρίς σύνδεση με παραστατικό</option>${e.map(s=>`<option value="${it(s.id)}" ${s.id===n.docId?"selected":""}>${ba(s.date)} · ${it(s.party)}${s.number?" · "+it(s.number):""} · υπόλοιπο ${pe(qa(s).rem)}</option>`).join("")}</select></label>
    ${rn("amount","Ποσό €",'inputmode="decimal"')}${Xr("method",[["bank","Τράπεζα"],["cash","Μετρητά"]])}${rn("note","Σημείωση")}</div>`}function ch(n){const e=Ci(n.amount),t=A(n.rate,24);let s,i,r;return n.mode==="net"?(s=q(e),i=q(s*t/100),r=q(s+i)):(r=q(e),s=q(r/(1+t/100)),i=q(r-s)),{net:s,vat:i,gross:r,rate:t}}function dP(){const n=ye.v,e=Zc(),t=isNaN(Ci(n.amount))?null:ch(n);return`<div class="card pad">${Xr("kind",[["purchase","Αγορά / έξοδο"],["sale","Πώληση"]])}
    ${rn("date","Ημερομηνία",'type="date"')}${rn("party",n.kind==="sale"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.kind==="sale"?e.cus:e.sup).map(s=>`<option value="${it(s.name)}">`).join("")}</datalist>
    ${rn("number","Αριθμός παραστατικού")}
    ${n.kind==="purchase"?`${rn("cat","Κατηγορία εξόδου",'list="bcl" autocomplete="off"')}<datalist id="bcl">${(Rb().costCats||[]).map(s=>`<option value="${it(s)}">`).join("")}</datalist>`:""}
    ${rn("amount","Ποσό €",'inputmode="decimal"')}${Xr("mode",[["gross","Το ποσό είναι με ΦΠΑ"],["net","Το ποσό είναι χωρίς ΦΠΑ"]])}
    <div class="f">Συντελεστής ΦΠΑ</div>${Xr("rate",[["24","24%"],["13","13%"],["6","6%"],["0","0%"]])}
    <div id="bprev" class="plabel">${t?`Καθαρό ${pe(t.net)} · ΦΠΑ ${pe(t.vat)} · Σύνολο ${pe(t.gross)}`:""}</div>${rn("note","Σημείωση")}</div>`}function hP(n,e){if(n==="newpay"||n==="newdoc"){const s=n==="newpay"?"pay":"doc";return(!ye||ye.kind!==s)&&(ye={kind:s,v:s==="pay"?{dir:"in",date:ve(),party:"",docId:"",amount:"",method:"bank",note:"",...pc||{}}:{kind:"purchase",date:ve(),party:"",number:"",cat:"",amount:"",mode:"gross",rate:String(XA(se()&&se().vat)),note:""}}),pc=null,`<header class="top"><a class="ib" data-bact="cancel">←</a><h1>${s==="pay"?"Νέα κίνηση":"Νέο παραστατικό"}</h1></header><main class="body ed">${s==="pay"?uP():dP()}
      ${ye.msg?`<div class="err box">${it(ye.msg)}</div>`:""}</main><div class="bar"><button class="btn b2" data-bact="cancel">Άκυρο</button><button class="btn b1" data-bact="save">💾 Αποθήκευση</button></div>`}ye=null;const t=Db.some(([s])=>s===n)?n:"sum";return`<header class="top"><a class="ib" href="#/menu">←</a><h1>Λογιστικά</h1></header><main class="body">${rP(t,e)}${{sum:aP,docs:oP,pays:cP,bal:lP}[t]()}</main>
    <div class="fab2"><a class="btn b2" href="#/books/newdoc">＋ Παραστατικό</a><a class="btn b1" href="#/books/newpay">＋ Είσπραξη / πληρωμή</a></div>`}let pc=null;function fP(){const n=ye.v;if(!n.date)return"Βάλε ημερομηνία.";if(ye.kind==="pay"){let s=String(n.party||"").trim();const i=n.docId&&k.ldocs.find(r=>r.id===n.docId);return i&&(s=i.party),s?!String(n.amount).trim()||isNaN(Ci(n.amount))?"Βάλε ποσό.":(We("lpays",{dir:n.dir,date:n.date,party:s,docId:n.docId||"",amount:q(Ci(n.amount)),method:n.method,note:String(n.note||"").trim(),id:Qe(),ts:Date.now()}),""):"Βάλε "+(n.dir==="in"?"πελάτη":"προμηθευτή")+"."}const e=String(n.party||"").trim();if(!e)return"Βάλε "+(n.kind==="sale"?"πελάτη":"προμηθευτή")+".";if(!String(n.amount).trim()||isNaN(Ci(n.amount)))return"Βάλε ποσό.";const t=ch(n);return We("ldocs",{kind:n.kind,date:n.date,party:e,number:String(n.number||"").trim(),cat:n.kind==="purchase"?String(n.cat||"").trim():"",net:t.net,vat:t.vat,gross:t.gross,rate:t.rate,note:String(n.note||"").trim(),items:[],id:Qe(),ts:Date.now()}),""}function pP(n,e,t,s){const i=n.closest("[data-bper],[data-bdk],[data-bpay],[data-bnew],[data-bseg],[data-bact]");if(!i)return!1;const r=i.dataset;if(r.bper){_a=r.bper;try{localStorage.setItem("tm_period",_a)}catch{}}else if(r.bdk)Fo=r.bdk;else if(r.bpay){const a=k.ldocs.find(o=>o.id===r.bpay);return a&&(pc={dir:a.kind==="sale"?"in":"out",party:a.party,docId:a.id,amount:Pb(qa(a).rem)}),ye=null,e("#/books/newpay"),!0}else{if(r.bnew)return pc={dir:r.bnew,party:r.party},ye=null,e("#/books/newpay"),!0;if(r.bseg)ye.v[r.bseg]=r.v,r.bseg==="dir"&&(ye.v.docId="");else if(r.bact==="cancel"){const a=ye&&ye.kind;return ye=null,e(a==="doc"?"#/books/docs":"#/books/pays",!0),!0}else if(r.bact==="save"){const a=fP();if(a)ye.msg=a;else{const o=ye.kind;return ye=null,s(o==="pay"?"Η κίνηση αποθηκεύτηκε.":"Το παραστατικό αποθηκεύτηκε."),e(o==="doc"?"#/books/docs":"#/books/pays",!0),!0}}}return t(),!0}function mP(n,e){if(!ye||!n.dataset.bf)return!1;const t=n.dataset.bf;if(ye.v[t]=n.value,ye.msg="",t==="docId"){const s=k.ldocs.find(i=>i.id===n.value);s&&(ye.v.party=s.party,ye.v.amount=Pb(qa(s).rem)),e()}else if(!(t==="party"&&ye.kind==="pay")){if(t==="amount"&&ye.kind==="doc"){const s=document.getElementById("bprev");if(s){const i=isNaN(Ci(n.value))?null:ch(ye.v);s.textContent=i?`Καθαρό ${pe(i.net)} · ΦΠΑ ${pe(i.vat)} · Σύνολο ${pe(i.gross)}`:""}}}return!0}function gP(n,e){ye&&ye.kind==="pay"&&n.dataset.bf==="party"&&e()}const Ye=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),yP=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Yt=n=>yP.format(Math.round((n||0)*100)/100),ln=n=>String(q(n)).replace(".",","),vP=n=>A(String(n).replace(",","."),0),bP=()=>({war:{on:!0,m:null},id:null,number:null,date:null,ts:0,customer:{name:"",phone:"",email:"",afm:"",address:""},subject:"",notes:"",status:"pending",vatMode:"on",benefits:[],benShow:!0,planMarks:[],planOn:!0,gid:null,optName:"",validDays:null,payShow:!1,payIds:null,prepay:{type:"",val:0},lines:[]}),mc=n=>n===null||typeof n!="object"?JSON.stringify(n===void 0?null:n):Array.isArray(n)?"["+n.map(mc).join(",")+"]":"{"+Object.keys(n).sort().map(e=>JSON.stringify(e)+":"+mc(n[e])).join(",")+"}";let ie=null;const lh=()=>!!ie;function _P(){ie=null}let Uo=null;function wP(n){Uo=n}function IP(n){if(n==="new"){const s=bP();return Uo&&(Object.assign(s.customer,Uo),Uo=null),ie={arg:n,q:s,base:null,pick:!1,pq:"",pcat:""}}const e=k.quotes.find(s=>s.id===n);if(!e)return null;const t=Se(e);return t.customer=Object.assign({name:"",phone:"",email:"",afm:"",address:""},t.customer),t.lines=t.lines||[],ie={arg:n,q:t,base:mc(e),pick:!1,pq:"",pcat:""}}function EP(n,e){return`<div class="ln-ed" data-i="${e}">
    <div class="ln-top"><input class="in" data-l="desc" value="${Ye(n.desc)}" placeholder="Περιγραφή"><button class="x" data-act="del" aria-label="Διαγραφή γραμμής">✕</button></div>
    <div class="ln-bot">
      <div class="step"><button data-act="dec">−</button><input class="in" data-l="qty" inputmode="decimal" value="${Ye(ln(A(n.qty)))}"><button data-act="inc">＋</button></div>
      <label>Τιμή €<input class="in" data-l="price" inputmode="decimal" value="${Ye(ln(A(n.price)))}"></label>
      <label>Έκπτ. %<input class="in" data-l="disc" inputmode="decimal" value="${Ye(ln(A(n.disc)))}"></label>
      <div class="ln-sum" data-sum>${Yt(nh(n))}</div>
    </div></div>`}function Nb(){const n=_b(ie.q);return`<div class="tot"><span>Καθαρό</span><span>${Yt(n.sub)}</span></div>
  ${n.off?"":`<div class="tot"><span>ΦΠΑ ${ln(n.vp)}%</span><span>${Yt(n.vat)}</span></div>`}
  <div class="tot big"><span>Σύνολο${n.off?" (χωρίς ΦΠΑ)":""}</span><span>${Yt(n.total)}</span></div>`}function TP(){const n=[...new Set(k.products.map(s=>s.cat).filter(Boolean))].sort((s,i)=>s.localeCompare(i,"el")),e=qe(ie.pq),t=k.products.filter(s=>(!ie.pcat||s.cat===ie.pcat)&&(!e||qe((s.model||"")+" "+(s.desc||"")+" "+(s.cat||"")).includes(e))).sort((s,i)=>((s.cat||"")+(s.model||"")).localeCompare((i.cat||"")+(i.model||""),"el")).slice(0,80);return`<div class="sheet"><div class="sheet-in">
    <div class="sheet-h"><b>Κατάλογος</b><button class="btn b1 sm" data-act="pick-close">Τέλος</button></div>
    <input class="search" id="pq" placeholder="🔍 Αναζήτηση προϊόντος" value="${Ye(ie.pq)}">
    <select class="search" data-pcatsel><option value="">Όλες οι κατηγορίες (${n.length})</option>${n.map(s=>`<option value="${Ye(s)}"${ie.pcat===s?" selected":""}>${Ye(s)}</option>`).join("")}</select>
    <div class="sheet-list">${t.map(s=>{const i=ie.q.lines.find(a=>a.pid===s.id),r=wb(s.id,ie.q.id);return`<button class="prow${i?" has":""}" data-pid="${Ye(s.id)}">${s.img?`<img class="pth" src="${Ye(s.img)}" alt="" loading="lazy">`:'<span class="pth ph">📦</span>'}<div class="t"><b>${Ye(s.model)}</b><span>${Ye([s.cat,s.desc].filter(Boolean).join(" · "))}${r>=1?` · 📦 ${ln(r)} στο ράφι`:""}</span></div>
      <div class="r"><div class="amt">${Yt(Xc(s))}</div>${i?`<span class="pill p-ok">×${ln(A(i.qty))}</span>`:'<span class="muted">＋ προσθήκη</span>'}</div></button>`}).join("")||`<div class="empty">${k.products.length?"Δεν βρέθηκε προϊόν":"Ο κατάλογος είναι άδειος"}</div>`}</div>
  </div></div>`}function kP(n){if((!ie||ie.arg!==n)&&(ie=null,!IP(n)))return null;const e=ie.q,t=e.customer,s=yn().map(i=>i.name).filter(i=>i&&i!=="(χωρίς όνομα)");return`<header class="top"><a class="ib" data-act="cancel">←</a><h1>${e.id?"Προσφορά #"+Ye(e.number||"—"):"Νέα προσφορά"}<span class="sm">${e.id?"Επεξεργασία":"Δεν έχει αποθηκευτεί ακόμα"}</span></h1></header>
  <main class="body ed">
    <div class="card pad">
      <label class="f">Πελάτης<input class="in" data-c="name" list="cl" value="${Ye(t.name)}" placeholder="Όνομα πελάτη" autocomplete="off"></label>
      <datalist id="cl">${s.map(i=>`<option value="${Ye(i)}">`).join("")}</datalist>
      <details><summary>Τηλέφωνο, email, ΑΦΜ, διεύθυνση</summary>
        <label class="f">Τηλέφωνο<input class="in" data-c="phone" inputmode="tel" value="${Ye(t.phone)}"></label>
        <label class="f">Email<input class="in" data-c="email" inputmode="email" value="${Ye(t.email)}"></label>
        <label class="f">ΑΦΜ<input class="in" data-c="afm" inputmode="numeric" value="${Ye(t.afm)}"></label>
        <label class="f">Διεύθυνση<input class="in" data-c="address" value="${Ye(t.address)}"></label>
      </details>
      <label class="f">Θέμα<input class="in" data-q="subject" value="${Ye(e.subject)}" placeholder="π.χ. Εγκατάσταση CCTV"></label>
    </div>
    <div class="h">Είδη (${e.lines.length})</div>
    <div class="card pad" id="lines">${e.lines.map(EP).join("")||'<div class="empty">Πρόσθεσε είδη από τον κατάλογο ή γράψε δική σου γραμμή.</div>'}</div>
    <div class="actions"><button class="btn b1" data-act="pick">📦 Κατάλογος</button><button class="btn b2" data-act="free">＋ Γραμμή</button><button class="btn b2" data-act="work">🛠️ Εργασία</button></div>
    <div class="card pad">
      <div class="seg"><button data-vat="on" class="${e.vatMode==="off"?"":"on"}">Με ΦΠΑ</button><button data-vat="off" class="${e.vatMode==="off"?"on":""}">Χωρίς ΦΠΑ</button></div>
      <div id="tots">${Nb()}</div>
    </div>
    <div class="card pad"><label class="f">Σημειώσεις<textarea class="in" data-q="notes" rows="3">${Ye(e.notes)}</textarea></label></div>
    ${ie.msg?`<div class="err box">${Ye(ie.msg)}</div>`:""}
  </main>
  <div class="bar"><button class="btn b2" data-act="cancel">Άκυρο</button><button class="btn b1" data-act="save">💾 ${ie.force?"Αποθήκευση (αντικατάσταση)":"Αποθήκευση"}</button></div>
  ${ie.pick?TP():""}`}function SP(n,e,t){const s=()=>{const i=n.querySelector("#tots");i&&(i.innerHTML=Nb())};n.oninput=i=>{const r=i.target,a=ie&&ie.q;if(a){if(r.dataset.c){if(a.customer[r.dataset.c]=r.value,r.dataset.c==="name"){const o=yn().find(l=>l.k===qe(r.value));if(o){let l=!1;if(["phone","email","afm","address"].forEach(u=>{!a.customer[u]&&o.info[u]&&(a.customer[u]=o.info[u],l=!0)}),l){e();const u=n.querySelector('[data-c="name"]');u.focus(),u.setSelectionRange(u.value.length,u.value.length)}}}}else if(r.dataset.q)a[r.dataset.q]=r.value;else if(r.dataset.l){const o=r.closest(".ln-ed"),l=a.lines[+o.dataset.i];if(!l)return;l[r.dataset.l]=r.dataset.l==="desc"?r.value:vP(r.value),o.querySelector("[data-sum]").textContent=Yt(nh(l)),s()}else if(r.dataset.pcatsel!==void 0)ie.pcat=r.value,e();else if(r.id==="pq"){ie.pq=r.value,e();const o=n.querySelector("#pq");o.focus(),o.setSelectionRange(o.value.length,o.value.length)}}},n.onclick=i=>{const r=ie&&ie.q;if(!r)return;const a=i.target.closest("[data-act],[data-vat],[data-pcat],[data-pid]");if(!a)return;const o=a.closest(".ln-ed"),l=o&&r.lines[+o.dataset.i],u=a.dataset.act;if(a.dataset.vat)r.vatMode=a.dataset.vat;else if(a.dataset.pcat!==void 0)ie.pcat=a.dataset.pcat;else if(a.dataset.pid)AP(a.dataset.pid);else if(u==="inc")l.qty=q(A(l.qty)+1);else if(u==="dec")l.qty=Math.max(0,q(A(l.qty)-1));else if(u==="del")r.lines.splice(+o.dataset.i,1);else if(u==="free")r.lines.push({desc:"",qty:1,price:0,disc:0,showImg:!0});else if(u==="work")r.lines.push({desc:"Εργασία / εγκατάσταση",qty:1,price:0,disc:0,showImg:!0});else if(u==="pick")ie.pick=!0;else if(u==="pick-close")ie.pick=!1;else if(u==="cancel"){const h=r.id;return ie=null,t(h)}else if(u==="save"){const h=$P();if(h)return ie=null,t(h)}if(ie.msg&&u!=="save"&&(ie.msg="",ie.force=!1),e(),u==="free"){const h=n.querySelectorAll('[data-l="desc"]');h[h.length-1].focus()}}}function AP(n){const e=k.products.find(s=>s.id===n);if(!e)return;const t=ie.q.lines.find(s=>s.pid===n);t?t.qty=q(A(t.qty)+1):ie.q.lines.push({pid:n,desc:e.model+(e.desc?" - "+e.desc:""),qty:1,price:Xc(e),disc:0,src:wb(n,ie.q.id)>=1?"stock":"supplier",showImg:!!(e.img&&e.imgPdf!==!1)})}function PP(n,e){const t=[],s=(o,l,u)=>{String(l||"")!==String(u||"")&&t.push(o+": «"+(l||"—")+"» → «"+(u||"—")+"»")};s("Πελάτης",n.customer&&n.customer.name,e.customer&&e.customer.name),s("Θέμα",n.subject,e.subject),s("ΦΠΑ",n.vatMode==="off"?"χωρίς":"με",e.vatMode==="off"?"χωρίς":"με"),(n.notes||"")!==(e.notes||"")&&t.push("Άλλαξαν οι σημειώσεις");const i={},r={};if((n.lines||[]).forEach(o=>i[o.pid||o.desc]=o),(e.lines||[]).forEach(o=>r[o.pid||o.desc]=o),Object.keys(r).forEach(o=>{if(!i[o])t.push("Προστέθηκε: "+r[o].desc+" ×"+ln(A(r[o].qty)));else{const l=i[o],u=r[o];A(l.qty)!==A(u.qty)&&t.push(u.desc+": ποσότητα "+ln(A(l.qty))+" → "+ln(A(u.qty))),A(l.price)!==A(u.price)&&t.push(u.desc+": τιμή "+Yt(A(l.price))+" → "+Yt(A(u.price))),A(l.disc)!==A(u.disc)&&t.push(u.desc+": έκπτωση "+ln(A(u.disc))+"%")}}),Object.keys(i).forEach(o=>{r[o]||t.push("Αφαιρέθηκε: "+i[o].desc)}),!t.length)return"";const a=q(A(e.total)-A(n.total));return t.join("; ")+(a?" (σύνολο "+Yt(A(n.total))+" → "+Yt(A(e.total))+")":"")}const RP=n=>(n=A(n,24),[24,13,6,0].includes(n)?n:24);function $P(){const n=ie.q,e=se();if(n.lines=n.lines.filter(o=>String(o.desc||"").trim()).map(o=>({...o,desc:String(o.desc).trim(),qty:A(o.qty),price:A(o.price),disc:A(o.disc)})),!n.lines.length)return ie.msg="Η προσφορά δεν έχει γραμμές.",null;if(!e)return ie.msg="Δεν έχουν φορτώσει οι ρυθμίσεις (αρίθμηση, ΦΠΑ). Περίμενε λίγο ή έλεγξε τη σύνδεση.",null;const t=n.id?k.quotes.find(o=>o.id===n.id):null;if(n.id&&!t)return ie.msg="Η προσφορά δεν υπάρχει πια (ίσως διαγράφηκε από άλλη συσκευή).",null;if(t&&mc(t)!==ie.base&&!ie.force)return ie.force=!0,ie.msg="Η προσφορά άλλαξε από άλλη συσκευή αφού την άνοιξες. Αν αποθηκεύσεις, οι αλλαγές εκείνες θα αντικατασταθούν. Πάτα ξανά «Αποθήκευση» για να συνεχίσεις, ή «Άκυρο».",null;let s=0;if(!n.number){const o=Math.max(1,Math.floor(A(e.next,1)));n.number=new Date().getFullYear()+"-"+String(o).padStart(3,"0"),s=o+1}n.date||(n.date=new Date().toLocaleDateString("el-GR")),n.id||(n.id=Qe(),n.ts=Date.now()),n.customer.name=String(n.customer.name||"").trim(),n.total=_b(n).total;const i=Se(n);We("quotes",i),s&&EA(s);const r=(o,l)=>We("qlog",{id:Qe(),qid:i.id,number:i.number||"",customer:i.customer.name||"",ts:Date.now(),type:o,text:l});if(!t)r("create","Νέα προσφορά, σύνολο "+Yt(i.total)+", "+i.lines.length+" γραμμές.");else{const o=PP(t,i);o&&r("edit",o)}const a=k.ldocs.find(o=>o.kind==="sale"&&(o.qid===i.id||!o.qid&&i.number&&o.number===i.number&&qe(o.party)===qe(i.customer.name)));if(a){const o=i.vatMode==="off"?0:RP(e.vat),l=sh(i),u=q(l*o/100),h=q(l+u),p=i.customer.name||a.party;a.qid===i.id&&a.net===l&&a.vat===u&&a.gross===h&&a.rate===o&&a.party===p&&a.number===(i.number||"")||Js("ldocs",a.id,{qid:i.id,net:l,vat:u,gross:h,rate:o,party:p,number:i.number||""})}return i.id}const ce=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Om=n=>n<10?"0"+n:""+n,uh=n=>n.getFullYear()+"-"+Om(n.getMonth()+1)+"-"+Om(n.getDate()),ii=n=>new Date(n+"T12:00:00"),qt=(n,e)=>{const t=ii(n);return t.setDate(t.getDate()+e),uh(t)},wa=(n,e)=>{const t=ii(n),s=t.getDate();t.setDate(1),t.setMonth(t.getMonth()+e);const i=new Date(t.getFullYear(),t.getMonth()+1,0).getDate();return t.setDate(Math.min(s,i)),uh(t)},lr="el-GR",xb=n=>n.charAt(0).toUpperCase()+n.slice(1),el=n=>xb(ii(n).toLocaleDateString(lr,{weekday:"long",day:"numeric",month:"long",year:"numeric"})),gc=n=>ii(n).toLocaleDateString(lr,{weekday:"short",day:"numeric",month:"numeric"}),CP=n=>xb(ii(n).toLocaleDateString(lr,{month:"long",year:"numeric"})),Vb=n=>{const e=ve();return n===e?"Σήμερα":n===qt(e,1)?"Αύριο":n===qt(e,-1)?"Χθες":gc(n)},Di=[["Μπλε TechMate","#1F4E79"],["Γαλάζιο","#0288D1"],["Τιρκουάζ","#00897B"],["Πράσινο","#2E7D32"],["Λαχανί","#7CB342"],["Κίτρινο","#F2A900"],["Πορτοκαλί","#EF6C00"],["Κόκκινο","#D32F2F"],["Ροζ","#C2185B"],["Μωβ","#7B1FA2"],["Λουλακί","#3949AB"],["Γκρι","#546E7A"]],xs=n=>(Di[n]||Di[0])[1],Ob=()=>{try{return JSON.parse(rt().empClr||"{}")}catch{return{}}},tl=n=>{const e=Ob()[n];return typeof e=="number"?e:-1};function Mb(n){if(typeof n.clr=="number"&&n.clr>=0)return xs(n.clr);for(const e of n.emps||[]){const t=tl(e);if(t>=0)return xs(t)}return n.kind==="due"?xs(6):xs(A(rt().accent,0))}const dh=-1,Lb=[0,15,30,60,120,1440,2880,10080,dh],yc=n=>String(n||"").split(",").map(e=>parseInt(e,10)).filter(e=>!isNaN(e));function hh(n){return Array.isArray(n.rems)?n.rems.map(Number).filter(e=>!isNaN(e)):{none:[],eve:[dh],15:[15],30:[30],60:[60],120:[120]}[n.remOff||"at"]||[0]}function Uu(n){return n===0?"Στην ώρα":n===dh?"Το προηγ. βράδυ":n<60?n+"΄ πριν":n===60?"1 ώρα πριν":n<1440?n/60+" ώρες πριν":n===1440?"1 μέρα πριν":n===10080?"1 εβδομάδα πριν":n/1440+" μέρες πριν"}const DP=n=>n.length?n.includes(0)?"at":{[-1]:"eve",15:"15",30:"30",60:"60",120:"120"}[n[0]]||"at":"none",qu={"":"Καμία",w:"Κάθε εβδομάδα",m:"Κάθε μήνα",y:"Κάθε χρόνο"},NP=n=>!Te()||!!Zt()&&(n.emps||[]).includes(Zt()),ju=()=>k.tasks.filter(n=>!n.del&&NP(n)),fh=n=>!Te()||(n.emps||[]).includes(Zt()),ph=n=>{const e=k.emps.find(t=>t.id===n);return e?e.name:""},Ia=()=>k.emps.filter(n=>n.name&&String(n.name).trim()).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),lr));function nl(){const n=k.st.main||{},e=n.msDefList||"",t=n.msToolList||"",s=n.msListNames||{},i=[...new Set((Array.isArray(n.msLists)?n.msLists:[]).filter(r=>r!==t).concat(e?[e]:[]))];return{def:e,lists:i.map(r=>({id:r,name:s[r]||"Λίστα"})).sort((r,a)=>(r.id===e?0:1)-(a.id===e?0:1))}}function mh(n,e){const t=String(e.title||"").trim();if(!t)return{msg:"Γράψε τίτλο πρώτα."};const s=n&&k.tasks.find(m=>m.id===n),i=!s;if(n&&!s)return{msg:"Η εργασία δεν υπάρχει πια (ίσως σβήστηκε)."};if(!i&&!ah(s))return{msg:"Μπορείς να αλλάξεις μόνο εργασίες που έγραψες εσύ."};if(Te()&&!Zt())return{msg:"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει."};const r=e.date||"",a=r&&e.time||"",o=Date.now(),l=!!(s&&s.done),u=(e.rems||[]).map(Number).filter((m,w,E)=>E.indexOf(m)===w).sort((m,w)=>w-m),h=i?{id:Qe(),ts:o,msId:"",msList:e.msList||"",rem:""}:{id:s.id};if(i){const m=as();m&&(h.by=m)}!i&&(s.date!==r||(s.time||"")!==a||JSON.stringify(hh(s).slice().sort((m,w)=>w-m))!==JSON.stringify(u))&&(h.rem="");let p=(e.emps||[]).slice();if(Te()&&(p=(i?e.emps||[]:s.emps||[]).slice(),p.includes(Zt())||p.push(Zt())),Object.assign(h,{title:t,date:r,time:a,emps:p,cust:String(e.cust||"").trim(),tel:String(e.tel||"").trim(),addr:String(e.addr||"").trim(),notes:String(e.notes||"").trim(),done:!!e.done,remOff:DP(u),rems:u,quoteId:e.quoteId||"",chk:(e.chk||[]).map(m=>({tx:String(m.tx||"").trim(),dn:!!m.dn})).filter(m=>m.tx),kind:e.kind||"",rep:e.rep||"",clr:typeof e.clr=="number"?e.clr:-1,upd:o,dirty:!0,del:!1}),h.done&&!l){h.doneAt=o;const m=as();m&&(h.doneBy=m.name)}else h.done||(h.doneAt=void 0,h.doneBy=void 0);if(i){if(delete h.doneAt,delete h.doneBy,h.done){h.doneAt=o;const m=as();m&&(h.doneBy=m.name)}We("tasks",h)}else Ht("tasks",h.id,h);return h.done&&!l&&Fb(k.tasks.find(m=>m.id===h.id)||h),{ok:!0,id:h.id}}function zl(n,e){if(!n||!fh(n))return;const t=Date.now(),s=as(),i=!!n.done;Js("tasks",n.id,e?{done:!0,upd:t,dirty:!0,doneAt:t,doneBy:s&&s.name||""}:{done:!1,upd:t,dirty:!0,doneAt:void 0,doneBy:void 0}),e&&!i&&Fb(n)}function xP(n,e){Js("tasks",n.id,{chk:e.map(t=>({tx:t.tx,dn:!!t.dn})),upd:Date.now(),dirty:!0})}function Fb(n){if(!n.date||!n.rep)return;const e=n.rep==="w"?qt(n.date,7):n.rep==="m"?wa(n.date,1):n.rep==="y"?wa(n.date,12):"";e&&mh(null,{...n,rems:hh(n),date:e,done:!1,chk:(n.chk||[]).map(t=>({tx:t.tx,dn:!1})),msList:n.msList||""})}function VP(n){return ah(n)?(n.msId?Js("tasks",n.id,{del:!0,dirty:!0,upd:Date.now()}):vb("tasks",n.id),{ok:!0}):{msg:"Μπορείς να σβήσεις μόνο εργασίες που έγραψες εσύ."}}const Y={view:"",sel:"",emp:"",q:"",srch:!1,list:"myday",showDone:!1,quick:"",preset:null,ms:null,emSel:""},Yi=()=>Y.sel||(Y.sel=ve());let z=null;const gh=()=>!!z,OP=()=>{z=null};function Ni(n){Y.preset=n}const Ea=(n,e)=>n.done-e.done||(n.time||"99:99").localeCompare(e.time||"99:99")||String(n.title||"").localeCompare(String(e.title||""),lr),MP=(n,e)=>(n.date?0:1)-(e.date?0:1)||(n.date||"").localeCompare(e.date||"")||(n.time||"99").localeCompare(e.time||"99")||(e.upd||0)-(n.upd||0),LP=(n,e)=>!e||[n.title,n.cust,n.addr,n.notes,n.tel].some(t=>String(t||"").toLowerCase().includes(e))||(n.chk||[]).some(t=>String(t.tx||"").toLowerCase().includes(e));function Mm(n){const e=Y.q.trim().toLowerCase();return ju().filter(t=>(n||rt().showDone||!t.done)&&(!Y.emp||(t.emps||[]).includes(Y.emp))&&LP(t,e))}function os(n,e){const t=!n.done&&n.date&&n.date<ve(),s=t?"var(--bad)":Mb(n),i=[e&&n.date?t?"Καθυστέρηση · "+gc(n.date):Vb(n.date):"",n.cust,n.addr].filter(Boolean).join(" · "),r=(n.emps||[]).map(ph).filter(Boolean),a=(n.chk||[]).length?`<em>☑ ${(n.chk||[]).filter(u=>u.dn).length}/${n.chk.length}</em>`:"",o=[n.kind==="due"?"<em>💶 Λήξη</em>":"",n.rep?`<em>🔁 ${ce(qu[n.rep]||"")}</em>`:"",a,!Te()&&r.length?`<em>👷 ${ce(r.join(", "))}</em>`:""].join(""),l=fh(n);return`<div class="tc${n.done?" dn":""}${rt().compact?" cp":""}" style="--c:${s}">
    <button class="tick${n.done?" on":""}" ${l?`data-tk="${ce(n.id)}"`:"disabled"} aria-label="Ολοκληρώθηκε">${n.done?"✓":""}</button>
    <a class="tcb" href="#/t/${encodeURIComponent(n.id)}"><div class="t"><b>${n.kind==="due"?"💶 ":""}${ce(n.title||"(χωρίς τίτλο)")}</b>${i?`<span>${ce(i)}</span>`:""}${o&&!rt().compact?`<div class="tags">${o}</div>`:""}</div>
    <div class="tcr" style="color:${s}">${ce(n.time||"")}</div></a></div>`}const Gl=(n,e,t,s="")=>e.length?`<div class="h ${s}">${n}</div><div class="card">${e.map(i=>os(i,t)).join("")}</div>`:"";function FP(n){const e=Yi(),t=ii(e.slice(0,8)+"01"),s=!!rt().sun,i=(t.getDay()+(s?0:6))%7,r=uh(new Date(t.getFullYear(),t.getMonth(),1-i)),a=s?["Κυρ","Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ"]:["Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ","Κυρ"],o=ve(),l=e.slice(0,7);let u="";for(let p=0;p<6;p++){const m=qt(r,p*7);if(p===5&&m.slice(0,7)!==l)break;for(let w=0;w<7;w++){const E=qt(m,w),N=(n[E]||[]).slice().sort(Ea);u+=`<button class="mc${E===e?" sel":""}${E===o?" now":""}${E.slice(0,7)!==l?" out":""}" data-csel="${E}"><b>${+E.slice(8)}</b><i>${N.slice(0,4).map($=>`<u style="background:${Mb($)};opacity:${$.done?.35:1}"></u>`).join("")}</i>${N.length>4?`<small>+${N.length-4}</small>`:""}</button>`}}const h=(n[e]||[]).slice().sort(Ea);return`<div class="mnav"><button data-cmon="-1">‹</button><b>${CP(e)}</b><button data-cmon="1">›</button></div>
    <div class="card mgrid" id="mgrid"><div class="mh">${a.map(p=>`<span>${p}</span>`).join("")}</div><div class="mg">${u}</div></div>
    <div class="h">${ce(el(e))}</div>
    <div class="card">${h.length?h.map(p=>os(p,!1)).join(""):'<div class="empty">Ελεύθερη μέρα. Πάτα «＋» για να προσθέσεις.</div>'}</div>`}function UP(n){const e=Yi(),t=!!rt().sun,s=qt(e,-((ii(e).getDay()+(t?0:6))%7)),i=ve();let r=`<div class="mnav"><button data-cwk="-1">‹</button><b>${gc(s)} – ${gc(qt(s,6))}</b><button data-cwk="1">›</button></div>`;for(let a=0;a<7;a++){const o=qt(s,a),l=(n[o]||[]).slice().sort(Ea);r+=`<div class="h wkh${o===i?" now":""}" data-csel="${o}">${o===i?"● ":""}${ce(el(o))}${l.length?` · ${l.length}`:""}</div>`,r+=l.length?`<div class="card">${l.map(u=>os(u,!1)).join("")}</div>`:'<div class="wke">—</div>'}return r}function qP(n){const e=ve(),t=(o,l)=>(o.date||"").localeCompare(l.date||"")||Ea(o,l),s=n.filter(o=>!o.done&&o.date&&o.date<e).sort(t),i={};n.filter(o=>o.date&&o.date>=e).sort(t).forEach(o=>(i[o.date]=i[o.date]||[]).push(o));const r=n.filter(o=>!o.date&&!o.done).sort((o,l)=>(l.upd||l.ts||0)-(o.upd||o.ts||0));return Gl(`⚠️ Εκκρεμότητες από πριν (${s.length})`,s,!0,"badh")+Object.keys(i).map(o=>Gl((o===e||o===qt(e,1)?Vb(o)+" · ":"")+el(o),i[o],!1)).join("")+Gl("Χωρίς ημερομηνία",r,!1)||'<div class="card"><div class="empty">Δεν υπάρχει τίποτα προγραμματισμένο.</div></div>'}function jP(n){const{def:e,lists:t}=nl(),s=ve(),i=Y.list,r=n.filter(u=>i==="myday"?u.date&&u.date<=s&&(!u.done||u.date===s):i==="planned"?!!u.date:i==="all"?!0:u.msList===i||!u.msList&&i===e),a=r.filter(u=>!u.done).sort(MP),o=r.filter(u=>u.done).sort((u,h)=>(h.upd||0)-(u.upd||0));return`<div class="chips">${[["myday","☀️ Η μέρα μου"],["planned","📅 Προγραμματισμένες"],["all","📥 Όλες"]].concat(t.map(u=>[u.id,"≡ "+u.name])).map(([u,h])=>`<button data-clist="${ce(u)}" class="${i===u?"on":""}">${ce(h)}</button>`).join("")}</div>
    <div class="qadd"><input class="search" data-cqv placeholder="＋ Προσθήκη εργασίας" value="${ce(Y.quick)}" enterkeyhint="done"><button class="btn b1 sm" data-cqa>Προσθήκη</button></div>
    ${a.length?`<div class="card">${a.map(u=>os(u,!0)).join("")}</div>`:o.length?"":`<div class="card"><div class="empty">${i==="myday"?"Τίποτα για σήμερα 🙂":"Η λίστα είναι άδεια."}</div></div>`}
    ${o.length?`<div class="h lnk2" data-cdone>${Y.showDone?"▾":"▸"} Ολοκληρωμένες (${o.length})</div>${Y.showDone?`<div class="card">${o.map(u=>os(u,!0)).join("")}</div>`:""}`:""}`}function Lm(n,e,t,s){s&&s!==Y.argV&&["lists","month","week","agenda"].includes(s)&&(Y.view=s,Y.argV=s),Y.view||(Y.view=rt().view||"lists");const i=Y.view,r=Mm(!1),a={};r.forEach(p=>{p.date&&(a[p.date]=a[p.date]||[]).push(p)});const o=[["lists","☑ Λίστες"],["month","🗓 Μήνας"],["week","Εβδ."],["agenda","Ατζέντα"]],l=Te()?[]:Ia(),u=e("Ημερολόγιο",Te()?(as()||{}).name||"":"Πρόγραμμα · εργασίες · λήξεις","",`<button class="ib" data-csrch aria-label="Αναζήτηση">${Y.srch?"✕":"🔍"}</button><button class="ib" data-ctoday aria-label="Σήμερα">◎</button><a class="ib" href="#/cset" aria-label="Ρυθμίσεις">⚙️</a>`),h=`${Y.srch?`<input class="search" id="csq" data-csq placeholder="🔍 Αναζήτηση σε τίτλο, πελάτη, σημειώσεις…" value="${ce(Y.q)}">`:""}
    <div class="seg">${o.map(([p,m])=>`<button data-cv="${p}" class="${i===p?"on":""}">${m}</button>`).join("")}</div>
    ${l.length?`<div class="chips"><button data-cemp="" class="${Y.emp?"":"on"}">Όλοι</button>${l.map(p=>{const m=tl(p.id);return`<button data-cemp="${ce(p.id)}" class="${Y.emp===p.id?"on":""}">${m>=0?`<u class="dot" style="background:${xs(m)}"></u>`:""}${ce(p.name)}</button>`}).join("")}</div>`:""}
    ${n?i==="month"?FP(a):i==="week"?UP(a):i==="agenda"?qP(r):jP(Mm(!0)):'<div class="card"><div class="empty">Φόρτωση…</div></div>'}`;return t(u,h,"cal",'<button class="fab" data-cnew aria-label="Νέα εργασία">＋</button>')}function BP(n){const e=n!=="new"&&k.tasks.find(i=>i.id===n);if(n!=="new"&&!e)return!1;const t=Y.preset||{};Y.preset=null;const s=yc(t.kind==="due"?rt().dueRems:rt().defRems);return z={arg:n,t0:e||null,isNew:!e,canEdit:!e||ah(e),canTick:!e||fh(e),msg:"",ask:!1,pick:null,err:!1,v:e?{kind:e.kind||"",title:e.title||"",date:e.date||"",time:e.time||"",rems:hh(e),rep:e.rep||"",cust:e.cust||"",tel:e.tel||"",addr:e.addr||"",quoteId:e.quoteId||"",emps:(e.emps||[]).slice(),clr:typeof e.clr=="number"?e.clr:-1,notes:e.notes||"",chk:(e.chk||[]).map(i=>({tx:i.tx||"",dn:!!i.dn})),done:!!e.done,msList:e.msList||""}:{kind:t.kind||"",title:t.title||"",date:t.date!==void 0?t.date:ve(),time:"",rems:t.rems||s,rep:"",cust:t.cust||"",tel:t.tel||"",addr:t.addr||"",quoteId:t.quoteId||"",emps:[],clr:-1,notes:"",chk:[],done:!1,msList:t.msList||""}},!0}const Zr=(n,e,t)=>`<div class="chips wrap">${n.map(([s,i])=>`<button ${t}="${ce(s)}" class="${e(s)?"on":""}">${i}</button>`).join("")}</div>`,WP=n=>{const e=k.quotes.find(t=>t.id===n);return e?`#${e.number||"—"} · ${e.customer&&e.customer.name||""}${e.subject?" · "+e.subject:""}`:"Συνδεδεμένη προσφορά"},Fm=n=>[n.kind==="due"?"💶 "+n.title:n.title,n.date?el(n.date)+(n.time?" "+n.time:""):"",n.cust?"Πελάτης: "+n.cust:"",n.tel?"Τηλ: "+n.tel:"",n.addr?"Διεύθυνση: "+n.addr:"",(n.emps||[]).length?"Τεχνικοί: "+n.emps.map(ph).filter(Boolean).join(", "):"",n.notes?`
`+n.notes:"",(n.chk||[]).length?`
`+n.chk.map(e=>(e.dn?"✔ ":"▫ ")+e.tx).join(`
`):""].filter(Boolean).join(`
`);function zP(n,e,t,s){if((!z||z.arg!==n)&&!BP(n))return s(t("Εργασία","",'<a class="ib" href="#/cal">←</a>'),`<div class="card"><div class="empty">${e?"Η εργασία δεν βρέθηκε (ίσως σβήστηκε).":"Φόρτωση…"}</div></div>`,null);const i=z.v,r=z.canEdit,a=r?"":"disabled",o=!Te(),l=($,B,J="",H="")=>`<label class="f">${B}<span class="fw"><input class="in${$==="title"&&z.err?" ine":""}" data-tf="${$}" value="${ce(i[$]||"")}" ${a} ${J}>${H}</span></label>`,{def:u,lists:h}=nl(),p=z.isNew?i.kind==="due"?"Νέα λήξη / πληρωμή":"Νέα εργασία":r?"Επεξεργασία":"Εργασία",m=i.tel.replace(/\s/g,""),w=i.chk.filter($=>$.dn).length,E=`${r?"":`<div class="upd">🔒 Την έγραψε ${ce(z.t0.by&&z.t0.by.name||"άλλος")}. Μπορείς να τη σημειώσεις ολοκληρωμένη και να τσεκάρεις το checklist.</div>`}
  <div class="card pad"><div class="ch">📅 Τι και πότε</div>
    ${r?`<div class="seg">${[["","🛠 Εργασία"],["due","💶 Λήξη / πληρωμή"]].map(([$,B])=>`<button data-tfk="${$}" class="${i.kind===$?"on":""}">${B}</button>`).join("")}</div>`:""}
    ${o&&z.isNew&&h.length>1?`<div class="f">Λίστα To Do</div>${Zr(h.map($=>[$.id,ce($.name)]),$=>$===i.msList||!i.msList&&$===u,"data-tlist")}`:!z.isNew&&i.msList&&h.find($=>$.id===i.msList)?`<div class="f">≡ Λίστα: ${ce(h.find($=>$.id===i.msList).name)}</div>`:""}
    ${l("title",i.kind==="due"?"Τι λήγει / τι πληρώνεται":"Τίτλος",'placeholder="π.χ. Εγκατάσταση καμερών" autocomplete="off"')}
    <div class="two">${l("date","Ημερομηνία",'type="date"')}${l("time","Ώρα",`type="time" ${i.date?"":"disabled"}`)}</div>
    ${r?`<div class="chips wrap">${[["Σήμερα",ve()],["Αύριο",qt(ve(),1)],["+1 εβδομάδα",qt(ve(),7)],["+1 μήνας",wa(ve(),1)]].map(([$,B])=>`<button data-tdq="${B}" class="${i.date===B?"on":""}">${$}</button>`).join("")}${i.date?'<button data-tdq="">✕ Χωρίς ημερομηνία</button>':""}</div>`:""}
  </div>
  <div class="card pad"><div class="ch">🔔 Υπενθυμίσεις</div>
    ${r?Zr(Lb.map($=>[$,Uu($)]),$=>i.rems.includes(+$),"data-trem")+(i.date&&!i.time?'<div class="hint">Χωρίς ώρα, οι υπενθυμίσεις υπολογίζονται από τις 08:00.</div>':"")+(i.date?"":'<div class="hint">Οι υπενθυμίσεις χρειάζονται ημερομηνία.</div>'):`<div class="hint">${i.rems.map(Uu).join(", ")||"Καμία"}</div>`}
    <div class="f" style="margin-top:8px">🔁 Επανάληψη</div>
    ${r?Zr(Object.entries(qu),$=>$===i.rep,"data-trep")+(i.rep?'<div class="hint">Όταν την ολοκληρώσεις, δημιουργείται αυτόματα η επόμενη.</div>':""):`<div class="hint">${qu[i.rep]||"Καμία"}</div>`}
  </div>
  <div class="card pad"><div class="ch">👤 Πελάτης</div>
    ${o&&r?`<div class="actions"><button class="btn b2" data-tpick="cust">📇 Από πελάτες</button><button class="btn b2" data-tpick="quote">📄 ${i.quoteId?"Άλλη προσφορά":"Προσφορά"}</button></div>`:""}
    ${i.quoteId?`<div class="qlink"><a href="#/q/${encodeURIComponent(i.quoteId)}">🔗 ${ce(WP(i.quoteId))}</a>${o&&r?'<button class="x" data-tunq aria-label="Αποσύνδεση">✕</button>':""}</div>`:""}
    ${l("cust","Όνομα πελάτη",'autocomplete="off"')}
    ${l("tel","Τηλέφωνο",'inputmode="tel"',m?`<a class="fa" href="tel:${ce(m)}">📞</a>`:"")}
    ${l("addr","Διεύθυνση","",i.addr?`<a class="fa" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i.addr)}">🗺️</a>`:"")}
  </div>
  ${o&&k.emps.length||r?`<div class="card pad"><div class="ch">👷 Ποιος και χρώμα</div>
    ${o&&Ia().length?`<div class="chips wrap">${Ia().map($=>{const B=tl($.id),J=i.emps.includes($.id);return`<button data-temp="${ce($.id)}" class="${J?"on":""}" ${a}>${J?"✓ ":B>=0?`<u class="dot" style="background:${xs(B)}"></u>`:""}${ce($.name)}</button>`}).join("")}</div>`:i.emps.length?`<div class="hint">${ce(i.emps.map(ph).filter(Boolean).join(", "))}</div>`:""}
    ${r?`<div class="f" style="margin-top:6px">Χρώμα</div><div class="clrs"><button data-tclr="-1" class="${i.clr<0?"on":""}">Αυτόματο</button>${Di.map(([$,B],J)=>`<button data-tclr="${J}" class="sw${i.clr===J?" on":""}" style="background:${B}" aria-label="${$}"></button>`).join("")}</div>`:""}
  </div>`:""}
  <div class="card pad"><div class="ch">📝 Σημειώσεις</div>
    <textarea class="in" data-tf="notes" rows="4" placeholder="Ό,τι χρειάζεται να θυμάσαι…" ${a}>${ce(i.notes)}</textarea>
    <div class="actions"><button class="btn b2" data-tncopy>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tnpaste>📋 Επικόλληση</button>':""}</div>
  </div>
  <div class="card pad"><div class="ch">☑ Checklist${i.chk.length?` <span class="muted">${w}/${i.chk.length}</span>`:""}</div>
    ${i.chk.length?`<div class="prog"><i style="width:${Math.round(w/i.chk.length*100)}%"></i></div>`:""}
    ${i.chk.map(($,B)=>`<div class="ci"><button class="tick${$.dn?" on":""}" data-tchktg="${B}" ${z.canTick?"":"disabled"}>${$.dn?"✓":""}</button>${r?`<input class="in" data-tchk="${B}" value="${ce($.tx)}"><button class="x" data-tchkdel="${B}">✕</button>`:`<span class="${$.dn?"strike":""}">${ce($.tx)}</span>`}</div>`).join("")}
    <div class="actions">${r?'<button class="btn b2" data-tchkadd>＋ Στοιχείο</button>':""}<button class="btn b2" data-tccopy ${i.chk.length?"":"disabled"}>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tcpaste>📋 Επικόλληση</button>':""}</div>
    ${r?'<div class="hint">Επικόλληση: κάθε γραμμή του προχείρου γίνεται ξεχωριστό στοιχείο.</div>':""}
  </div>
  <div class="card pad"><div class="ch">✅ Κατάσταση</div>
    <label class="chk2"><input type="checkbox" data-tf="done" ${i.done?"checked":""} ${z.canTick?"":"disabled"}> ${i.done?"Ολοκληρώθηκε":"Ανοιχτή"}</label>
    ${z.t0&&z.t0.by&&z.t0.by.name?`<div class="hint">Την έγραψε: ${ce(z.t0.by.uid===(as()||{}).uid?"εσύ":z.t0.by.name)}${z.t0.done&&z.t0.doneBy?" · ολοκλήρωσε: "+ce(z.t0.doneBy):""}</div>`:""}
  </div>
  ${z.msg?`<div class="err box">${ce(z.msg)}</div>`:""}
  ${!z.isNew&&r?`<button class="btn wide del" data-tdel>${z.ask?"Σίγουρα; Πάτα ξανά για διαγραφή":"🗑️ Διαγραφή"}</button>`:""}
  ${z.pick?GP():""}`;return`${t(p,"",'<a class="ib" data-tcancel>←</a>','<button class="ib" data-tcopy aria-label="Αντιγραφή">⧉</button><button class="ib" data-tshare aria-label="Αποστολή">📤</button>')}<main class="body ed">${E}</main><div class="bar"><button class="btn b2" data-tcancel>Άκυρο</button><button class="btn b1" data-tsave>💾 Αποθήκευση</button></div>`}function Ub(){return z.pick.kind==="cust"?yn().filter(n=>n.name&&n.name!=="(χωρίς όνομα)").sort((n,e)=>(e.last||0)-(n.last||0)).map(n=>({t:n.name,s:[n.info.phone,n.info.address].filter(Boolean).join(" · "),v:{cust:n.name,tel:n.info.phone||"",addr:n.info.address||""}})):k.quotes.filter(n=>!mn(n)).sort((n,e)=>(e.ts||0)-(n.ts||0)).map(n=>{const e=n.customer||{};return{t:`#${n.number||"—"} · ${e.name||""}`,s:[n.subject,e.address].filter(Boolean).join(" · "),v:{quoteId:n.id,cust:e.name||"",tel:e.phone||"",addr:e.address||"",q:!0}}})}function GP(){const n=z.pick.q.trim().toLowerCase(),e=Ub().map((t,s)=>({...t,i:s})).filter(t=>!n||(t.t+" "+t.s).toLowerCase().includes(n)).slice(0,150);return`<div class="sheet" data-pkx><div class="sheet-in"><div class="sheet-h"><b>${z.pick.kind==="cust"?"Πελάτες":"Προσφορές"}</b><button class="ib dk" data-pkx>✕</button></div>
    <input class="search" id="pq" data-pq placeholder="🔍 Αναζήτηση…" value="${ce(z.pick.q)}">
    <div class="sheet-list">${e.map(t=>`<button class="prow" data-pk="${t.i}"><div class="t"><b>${ce(t.t)}</b><span>${ce(t.s)}</span></div></button>`).join("")||'<div class="empty">Τίποτα</div>'}</div></div></div>`}const wn=(n,e)=>`<label class="tg"><span>${e}</span><input type="checkbox" data-stg="${n}" ${rt()[n]?"checked":""}></label>`,Wn=(n,e,t)=>`<div class="f">${e}</div>${Zr(t,s=>String(rt()[n])===String(s),`data-s="${n}" data-v`)}`,Um=(n,e)=>`<div class="f">${e}</div>${Zr(Lb.map(t=>[t,Uu(t)]),t=>yc(rt()[n]).includes(+t),`data-sr="${n}" data-v`)}`;async function yh(n){await va(),Y.ms=await ue.msStatus(),n()}function KP(n,e){const t=rt(),s=Y.ms||{},{lists:i}=nl(),r=!Te(),a=l=>l?new Date(l).toLocaleString(lr,{dateStyle:"short",timeStyle:"short"}):"",o=`${On?"":'<div class="upd">🧪 Preview στον browser: ειδοποιήσεις, widgets, backup και To Do λειτουργούν μόνο στο κινητό.</div>'}
  <div class="h">🎨 Εμφάνιση ημερολογίου</div><div class="card pad">
    ${Wn("view","Οθόνη έναρξης",[["lists","Λίστες"],["month","Μήνας"],["week","Εβδομάδα"],["agenda","Ατζέντα"]])}
    <div class="f">Χρώμα εργασιών (προεπιλογή)</div><div class="clrs">${Di.map(([l,u],h)=>`<button data-s="accent" data-v="${h}" class="sw${A(t.accent)===h?" on":""}" style="background:${u}" aria-label="${l}"></button>`).join("")}</div>
    ${wn("sun","Η εβδομάδα ξεκινά Κυριακή")}${wn("showDone","Εμφάνιση ολοκληρωμένων")}${wn("compact","Συμπαγής λίστα (περισσότερα στην οθόνη)")}
  </div>
  ${r&&Ia().length?`<div class="h">👷 Χρώμα ανά τεχνικό</div><div class="card pad"><div class="hint">Οι εργασίες χωρίς δικό τους χρώμα παίρνουν το χρώμα του τεχνικού.</div>
    ${Ia().map(l=>{const u=tl(l.id);return`<div class="erow" data-sec="${ce(l.id)}"><u class="dot lg" style="background:${u>=0?xs(u):"var(--line)"}"></u><b>${ce(l.name)}</b><span class="muted">${u>=0?Di[u][0]:"Αυτόματο"}</span></div>
      ${Y.emSel===l.id?`<div class="clrs"><button data-secv="${ce(l.id)}|-1" class="${u<0?"on":""}">Αυτόματο</button>${Di.map(([h,p],m)=>`<button data-secv="${ce(l.id)}|${m}" class="sw${u===m?" on":""}" style="background:${p}" aria-label="${h}"></button>`).join("")}</div>`:""}`}).join("")}</div>`:""}
  <div class="h">🔔 Υπενθυμίσεις</div><div class="card pad">
    ${Um("defRems","Προεπιλογή για νέες εργασίες")}${Um("dueRems","Προεπιλογή για λήξεις / πληρωμές")}
    ${wn("rep","Να ξαναχτυπά μέχρι να πατήσω «ΟΚ»")}
    ${t.rep?Wn("repMin","Κάθε",[2,5,10,15,30].map(l=>[l,l+"΄"]))+Wn("repMax","Μέχρι",[3,6,12,24].map(l=>[l,l+" φορές"])):""}
    ${Wn("snooze","Αναβολή",[5,10,15,30,60].map(l=>[l,l+"΄"]))}
    ${wn("alarmSound","Δυνατός ήχος ξυπνητηριού")}${wn("clockMode","Μέγιστη ακρίβεια (σαν ξυπνητήρι)")}
    <div class="actions"><button class="btn b2" data-sact="test">🔔 Δοκιμή</button><button class="btn b2" data-sact="notif">🔊 Ήχοι</button></div>
    <div class="hint">Αν το κινητό (Xiaomi, Huawei, Samsung) «κοιμίζει» τις εφαρμογές, βάλε το TechMate «Χωρίς περιορισμό» μπαταρίας:</div>
    <div class="actions"><button class="btn b2" data-sact="battery">🔋 Ρυθμίσεις μπαταρίας</button></div>
  </div>
  <div class="h">🔄 Συγχρονισμός και μπαταρία</div><div class="card pad">
    <div class="hint">Όσο η εφαρμογή είναι ανοιχτή, όλα ενημερώνονται αμέσως. Κλειστή, ελέγχει για νέες εργασίες μόνο όσο συχνά ορίσεις. Οι υπενθυμίσεις δεν εξαρτώνται από αυτό.</div>
    ${Wn("syncMin","Έλεγχος για νέες εργασίες",[[0,"Ποτέ"],[15,"15΄"],[30,"30΄"],[60,"1 ώρα"],[180,"3 ώρες"],[360,"6 ώρες"]])}
    ${wn("notifyNew","Ειδοποίηση για νέα / αλλαγμένη εργασία")}
  </div>
  <div class="h">🧩 Widget</div><div class="card pad">
    <label class="f">Διαφάνεια φόντου: <b id="wav">${t.wAlpha}%</b><input type="range" min="20" max="100" step="10" value="${t.wAlpha}" data-sw class="rng"></label>
    ${Wn("wMode","Τι δείχνει το widget-λίστα",[["todo","Εργασίες (όπως το To Do)"],["cal","Μόνο ραντεβού με ημερομηνία"]])}
    ${t.wMode==="todo"&&i.length>1?Wn("wList","Λίστα To Do στο widget",[["","Όλες"]].concat(i.map(l=>[l.id,ce(l.name)]))):""}
    ${Wn("wDays",t.wMode==="todo"?"Μαζί με ραντεβού για":"Η λίστα του widget δείχνει",[[1,"Σήμερα"],[2,"Σήμερα & αύριο"],[3,"3 μέρες"],[7,"Εβδομάδα"]])}
    <div class="hint">Για να το προσθέσεις: πάτα παρατεταμένα την αρχική οθόνη → Widgets → TechMate.</div>
  </div>
  ${r?`<div class="h">💾 Backup στη συσκευή / Google Drive</div><div class="card pad">
    <div class="hint">Σώζει ΟΛΟ το TechMate (προσφορές, πελάτες, λογιστικά, εργασίες…) σε αρχείο που διαλέγεις. Για Google Drive, πάτα ☰ στον επιλογέα και διάλεξε «Drive». Μόνο διαβάζει τη βάση, δεν αλλάζει τίποτα.</div>
    <div class="actions"><button class="btn b2" data-sact="bpick">📁 ${t.bUri?"Άλλο αρχείο":"Επιλογή αρχείου"}</button>${t.bUri?'<button class="btn b2" data-sact="bnow">☁️ Backup τώρα</button>':""}</div>
    ${t.bUri?wn("bAuto","Αυτόματο backup μία φορά τη μέρα (όταν ανοίγεις την εφαρμογή)")+`<div class="hint">${t.bLast?"Τελευταίο: "+a(t.bLast):"Δεν έχει γίνει ακόμα"}</div>`:""}
    <label class="btn b2 wide filebtn">♻️ Επαναφορά εργασιών που λείπουν, από backup…<input type="file" accept="application/json,.json" data-restore hidden></label>
    <div class="hint">Η επαναφορά προσθέτει ΜΟΝΟ εργασίες που δεν υπάρχουν πια. Όσες υπάρχουν δεν αλλάζουν.</div>
  </div>
  <div class="h">✅ Microsoft To Do</div><div class="card pad">
    ${s.connected?`<div class="hint">👤 ${ce(s.account||"Συνδεδεμένο")}</div><div class="hint">${s.status==="sync"?"⏳ Συγχρονισμός…":s.status==="login"?"⚠️ Χρειάζεται ξανά σύνδεση":s.status&&s.status!=="ok"?"⚠️ "+ce(s.status):s.last?"✓ Τελευταίος συγχρονισμός: "+a(s.last):"✓ Συνδεδεμένο"}</div>
        <div class="actions">${s.status==="login"?'<button class="btn b1" data-sact="mslogin">Σύνδεση</button>':'<button class="btn b2" data-sact="mssync">🔄 Συγχρονισμός τώρα</button>'}<button class="btn b2" data-sact="msout">Αποσύνδεση</button></div>
        <div class="hint">Συγχρονίζονται οι λίστες που έχεις διαλέξει στο TechMate. Οι νέες εργασίες πάνε στην κύρια λίστα.</div>`:'<div class="hint">Σύνδεσε τον λογαριασμό Microsoft: οι εργασίες πηγαίνουν και έρχονται από το To Do απευθείας από το κινητό, με την ίδια λογική με το PWA (χωρίς διπλές).</div><button class="btn b1 wide" data-sact="mslogin">Σύνδεση με Microsoft</button>'}
  </div>`:'<div class="card pad"><div class="hint">Τον συγχρονισμό με το To Do και τα backup τα κάνει ο διαχειριστής.</div></div>'}
  <div class="card pad">${wn("autoUpd","Αυτόματος έλεγχος για νέα έκδοση εφαρμογής")}</div>`;return e(n("Ρυθμίσεις ημερολογίου","Ειδοποιήσεις · widget · backup · To Do",'<a class="ib" href="#/cal">←</a>'),o,null)}function Bu(){const n=t=>Object.fromEntries((t||[]).map(s=>{const i={...s};return delete i.id,[s.id,i]})),e={};return["quotes","custs","tasks","ldocs","lpays","emps","products","smoves","wdays","wpays","needs"].forEach(t=>e[t]=n(k[t])),JSON.stringify({app:"TechMate",ver:2,at:new Date().toISOString(),tasks:e.tasks,data:e,settings:k.st},null,1)}async function HP(n){const e=rt();if(!On||!n||Te()||!e.bUri||!e.bAuto||!k.tasks.length||!k.quotes.length||Date.now()-A(e.bLast)<20*36e5)return;const t=await ue.backupWrite(Bu());t&&t.ok&&await va()}async function QP(n,e,t){try{const s=JSON.parse(await n.text()),i=s.tasks||s.data&&s.data.tasks||{},r=new Set(k.tasks.map(o=>o.id));let a=0;Object.keys(i).forEach(o=>{r.has(o)||!i[o]||typeof i[o]!="object"||(We("tasks",{...i[o],id:o}),a++)}),e(a?`Επαναφέρθηκαν ${a} εργασίες που έλειπαν.`:"Δεν έλειπε καμία εργασία. Δεν άλλαξε τίποτα.")}catch{e("Το αρχείο δεν είναι σωστό backup.")}t()}function qb(n){const e=Y.quick.trim();if(!e)return;const t=Y.list,s=mh(null,{title:e,date:t==="myday"?ve():"",rems:[],msList:["myday","planned","all"].includes(t)?"":t});if(s.msg)return n(s.msg);Y.quick="",n("Προστέθηκε: "+e)}function JP(){if(Y.view==="lists"){const e=Y.list;Ni({date:e==="myday"||e==="planned"?ve():"",msList:["myday","planned","all"].includes(e)?"":e})}else Ni({date:Yi()});location.hash="#/t/new"}async function YP(n,e,t){const s={test:async()=>{const i=await ue.testNotif();t(i&&i.error?i.error:On?"Στάλθηκε δοκιμαστική ειδοποίηση":"Μόνο στο κινητό")},notif:()=>ue.openNotifSettings(),battery:()=>ue.openBattery(),mslogin:()=>ue.msLogin(),mssync:async()=>{Y.ms={...Y.ms||{},status:"sync"},e();const i=await ue.msSync();t(i&&i.ok?"Συγχρονίστηκε με το To Do":"Ο συγχρονισμός απέτυχε")},msout:async()=>{await ue.msDisconnect(),t("Αποσυνδέθηκε το Microsoft To Do")},bpick:async()=>{const i=await ue.backupPick();if(i&&i.error)return t(i.error);if(i&&i.ok){await va();const r=await ue.backupWrite(Bu());t(r&&r.ok?"Έγινε το πρώτο backup":"Backup: "+(r&&r.error||"σφάλμα"))}},bnow:async()=>{const i=await ue.backupWrite(Bu());t(i&&i.ok?"Έγινε backup":"Backup: "+(i&&i.error||"σφάλμα"))}}[n];s&&await s(),await va(),Y.ms=await ue.msStatus(),e()}function XP(n,e,t){const s=n.closest("[data-tk],[data-cv],[data-csel],[data-cmon],[data-cwk],[data-cemp],[data-clist],[data-csrch],[data-ctoday],[data-cdone],[data-cnew],[data-cqa],[data-tfk],[data-trem],[data-trep],[data-temp],[data-tclr],[data-tdq],[data-tlist],[data-tunq],[data-tpick],[data-pk],[data-pkx],[data-tchkadd],[data-tchkdel],[data-tchktg],[data-tncopy],[data-tnpaste],[data-tccopy],[data-tcpaste],[data-tcopy],[data-tshare],[data-tsave],[data-tcancel],[data-tdel],[data-s],[data-sr],[data-sec],[data-secv],[data-sact]");if(!s)return!1;const i=s.dataset;if(i.tk){const a=k.tasks.find(l=>l.id===i.tk);if(!a)return!0;const o=!a.done;return zl(a,o),t((o?"✓ Ολοκληρώθηκε: ":"Άνοιξε ξανά: ")+(a.title||""),{label:"Αναίρεση",fn:()=>{const l=k.tasks.find(u=>u.id===a.id);l&&zl(l,!o)}}),!0}if(i.cv)return Y.view=i.cv,e(),!0;if(i.csel)return Y.sel=i.csel,Y.view==="week"&&(Y.view="month"),e(),!0;if(i.cmon)return Y.sel=wa(Yi().slice(0,8)+"01",+i.cmon),e(),!0;if(i.cwk)return Y.sel=qt(Yi(),7*i.cwk),e(),!0;if("cemp"in i)return Y.emp=Y.emp===i.cemp?"":i.cemp,e(),!0;if(i.clist)return Y.list=i.clist,e(),!0;if("csrch"in i){Y.srch=!Y.srch,Y.srch||(Y.q=""),e();const a=document.getElementById("csq");return a&&a.focus(),!0}if("ctoday"in i)return Y.sel=ve(),e(),!0;if("cdone"in i)return Y.showDone=!Y.showDone,e(),!0;if("cnew"in i)return JP(),!0;if("cqa"in i)return qb(t),e(),!0;if(i.s!==void 0&&i.v!==void 0){const a=rt()[i.s],o=typeof a=="number"?+i.v:typeof a=="boolean"?i.v==="true":i.v;return Yr(i.s,o).then(e),!0}if(i.sr){const a=yc(rt()[i.sr]),o=+i.v,l=a.includes(o)?a.filter(u=>u!==o):a.concat(o);return Yr(i.sr,l.join(",")).then(e),!0}if(i.secv){const[a,o]=i.secv.split("|"),l=Ob();return+o<0?delete l[a]:l[a]=+o,Y.emSel="",Yr("empClr",JSON.stringify(l)).then(e),!0}if(i.sec)return Y.emSel=Y.emSel===i.sec?"":i.sec,e(),!0;if(i.sact)return YP(i.sact,e,t),!0;if(!z)return!1;const r=z.v;if("pkx"in i)return s.classList.contains("sheet")&&n!==s?!0:(z.pick=null,e(),!0);if(i.pk){const a=Ub()[+i.pk];if(a){const o=a.v;o.q?(r.quoteId=o.quoteId,r.cust||(r.cust=o.cust),r.tel||(r.tel=o.tel),r.addr||(r.addr=o.addr),r.title||(r.title="Εγκατάσταση – "+o.cust)):(r.cust=o.cust,o.tel&&(r.tel=o.tel),o.addr&&(r.addr=o.addr))}return z.pick=null,e(),!0}if(i.tfk!==void 0)r.kind!==i.tfk&&z.isNew&&(r.rems=yc(i.tfk==="due"?rt().dueRems:rt().defRems)),r.kind=i.tfk;else if(i.trem!==void 0){const a=+i.trem;r.rems=r.rems.includes(a)?r.rems.filter(o=>o!==a):r.rems.concat(a)}else if(i.trep!==void 0)r.rep=i.trep;else if(i.temp){const a=r.emps.indexOf(i.temp);a>=0?r.emps.splice(a,1):r.emps.push(i.temp)}else if(i.tclr!==void 0)r.clr=+i.tclr;else if(i.tdq!==void 0)r.date=i.tdq,r.date||(r.time="");else if(i.tlist)r.msList=i.tlist;else if("tunq"in i)r.quoteId="";else if(i.tpick)z.pick={kind:i.tpick,q:""};else if("tchkadd"in i)r.chk.push({tx:"",dn:!1});else if(i.tchkdel)r.chk.splice(+i.tchkdel,1);else if(i.tchktg){const a=r.chk[+i.tchktg];a&&z.canTick&&(a.dn=!a.dn)}else{if("tncopy"in i)return ue.copy(r.notes),t("Αντιγράφηκαν οι σημειώσεις"),!0;if("tnpaste"in i)return ue.paste().then(a=>{if(!a)return t("Το πρόχειρο είναι άδειο");r.notes=r.notes.trim()?r.notes.trimEnd()+`
`+a:a,t("Επικολλήθηκε"),e()}),!0;if("tccopy"in i)return ue.copy(r.chk.map(a=>(a.dn?"✔ ":"▫ ")+a.tx).join(`
`)),t("Αντιγράφηκε το checklist"),!0;if("tcpaste"in i)return ue.paste().then(a=>{const o=String(a||"").split(/\r?\n/).map(l=>l.trim()).filter(Boolean).map(l=>({tx:l.replace(/^([-*•▫☐☑✔✓]|\[[ xX]?\]|\d+[.)])\s*/,""),dn:/^(☑|✔|✓|\[[xX]\])/.test(l)})).filter(l=>l.tx);if(!o.length)return t("Το πρόχειρο είναι άδειο");r.chk.push(...o),t(`Προστέθηκαν ${o.length} στοιχεία`),e()}),!0;if("tcopy"in i)return ue.copy(Fm(r)),t("Αντιγράφηκε η εργασία"),!0;if("tshare"in i)return ue.share(Fm(r)),!0;if("tcancel"in i)return z=null,history.length>1?history.back():location.replace("#/cal"),!0;if("tdel"in i)if(!z.ask)z.ask=!0;else{const a=VP(z.t0);if(a.msg)z.msg=a.msg,z.ask=!1;else{const o=z.t0.title;return z=null,t("Διαγράφηκε: "+o),location.replace("#/cal"),!0}}else if("tsave"in i){if(z.canEdit){const l=mh(z.isNew?null:z.arg,r);if(l.msg)return z.msg=l.msg,z.err=!r.title.trim(),e(),!0}else{const l=k.tasks.find(h=>h.id===z.arg)||z.t0,u=r.chk.filter(h=>h.tx.trim());JSON.stringify(u)!==JSON.stringify((l.chk||[]).map(h=>({tx:h.tx,dn:!!h.dn})))&&xP(l,u),!!r.done!=!!l.done&&zl(l,r.done)}const a=r.title.trim(),o=z.isNew;return z=null,t(o?"Προστέθηκε: "+a:"Αποθηκεύτηκε"),history.length>1?history.back():location.replace("#/cal"),!0}}return e(),!0}function ZP(n,e){const t=n.dataset;if("csq"in t){Y.q=n.value,e();const s=document.getElementById("csq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if("cqv"in t)return Y.quick=n.value,!0;if("sw"in t){const s=document.getElementById("wav");return s&&(s.textContent=n.value+"%"),!0}if(!z)return!1;if("pq"in t){z.pick.q=n.value,e();const s=document.getElementById("pq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(t.tchk!==void 0){const s=z.v.chk[+t.tchk];return s&&(s.tx=n.value),!0}return t.tf?(z.v[t.tf]=n.type==="checkbox"?n.checked:n.value,z.msg&&(z.msg=""),t.tf==="title"&&(z.err=!1),!0):!1}function eR(n,e,t){const s=n.dataset;return s.stg?(Yr(s.stg,n.checked).then(e),!0):"sw"in s?(Yr("wAlpha",+n.value).then(e),!0):"restore"in s?(n.files&&n.files[0]&&QP(n.files[0],t,e),!0):z&&(s.tf==="date"||s.tf==="done")?(z.v[s.tf]=n.type==="checkbox"?n.checked:n.value,s.tf==="date"&&!n.value&&(z.v.time=""),e(),!0):!1}function tR(n,e,t){if(n.key==="Enter"&&n.target.dataset&&"cqv"in n.target.dataset){n.preventDefault(),Y.quick=n.target.value,qb(t),e();const s=document.querySelector("[data-cqv]");return s&&s.focus(),!0}return!1}let Nr=null;function jb(n,e){if(!n.target.closest||!n.target.closest("#mgrid")){Nr=null;return}if(n.type==="touchstart")Nr=n.touches[0].clientX;else if(n.type==="touchend"&&Nr!==null){const t=n.changedTouches[0].clientX-Nr;Nr=null,Math.abs(t)>70&&(Y.sel=wa(Yi().slice(0,8)+"01",t<0?1:-1),e())}}function nR(){const n=ve(),e=ju().filter(t=>!t.done);return{today:ju().filter(t=>t.date===n).sort(Ea),late:e.filter(t=>t.date&&t.date<n).sort((t,s)=>t.date.localeCompare(s.date)),dues:e.filter(t=>t.kind==="due"&&t.date&&t.date>n&&t.date<=qt(n,14)).sort((t,s)=>t.date.localeCompare(s.date))}}let qm=null,jm="";function sR(){!On||!Qr.tasks||(clearTimeout(qm),qm=setTimeout(()=>{const n={};k.tasks.forEach(r=>{const a={...r};delete a.id,n[r.id]=a});const e=JSON.stringify(n),t=k.emps.map(r=>({id:r.id,name:r.name||""})),s=nl(),i=e.length+":"+e+JSON.stringify(t)+JSON.stringify(s);i!==jm&&(jm=i,ue.setTasks(e,t,s))},400))}const In=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),vh=(n,e)=>(n||[]).find(t=>t.id===e),vc="https://graph.microsoft.com/v1.0",iR="TechMate/Τιμολόγια",rR="TechMate/Φωτογραφίες εγκαταστάσεων",Kl=n=>String(n||"").replace(/[\\/:*?"<>|#%]+/g," ").replace(/\s+/g," ").trim(),Hl=n=>(n=A(n,0),n>=1048576?(n/1048576).toFixed(1).replace(".",",")+" MB":Math.max(1,Math.round(n/1024))+" KB"),Bm=n=>!(n&&n.war&&n.war.on===!1),aR=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(A(e.m,0))):A((se()||{}).warrantyMonths,24)},oR=n=>n.install||{date:n.statusDate||"",months:Bm(n)?aR(n):0,serials:"",nw:!Bm(n)},Oe={st:null,busy:"",msg:"",pick:""},bh=()=>!!Oe.busy,Xi=n=>n&&n.install&&n.install.docs||[],Ta=n=>n&&n.install&&n.install.photos||[];async function _h(n){Oe.st=ni?{connected:!0,account:"demo@hotmail.com"}:On?await ue.filesStatus():{connected:!1,account:"",web:!0},n()}const bc=(n,e,t)=>n.install?fc("quotes",n.id,"install."+e,t):fc("quotes",n.id,"install",{...oR(n),[e]:t}),Wu=(n,e)=>We("qlog",{id:Qe(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:e}),wh=async()=>{if(ni)return"demo";const n=await ue.filesToken();if(!n||!n.ok){const e=new Error(n&&n.error==="login"?"Συνδέσου στο OneDrive.":n&&n.error||"Δεν υπάρχει σύνδεση OneDrive.");throw e.login=!0,e}return n.token},Wm=(n,e)=>"/me/drive/root:/"+e.split("/").map(encodeURIComponent).join("/")+"/"+encodeURIComponent(n);async function cR(n,e,t,s,i){if(ni)return{id:"demo"+Date.now(),name:t,size:e.size,webUrl:""};const r={Authorization:"Bearer "+n},a=async h=>{if(!h.ok)throw new Error(h.status===507?"Γέμισε ο χώρος του OneDrive.":h.status===403||h.status===401?"Το OneDrive δεν επιτρέπει την πρόσβαση (άδεια Files.ReadWrite). Συνδέσου ξανά.":"Το OneDrive απέρριψε το αρχείο ("+h.status+").");return h.json()};if(e.size<=4e6)return a(await fetch(vc+Wm(t,s)+":/content?@microsoft.graph.conflictBehavior=rename",{method:"PUT",headers:{"Content-Type":e.type||"application/octet-stream",...r},body:e}));const o=await a(await fetch(vc+Wm(t,s)+":/createUploadSession",{method:"POST",headers:{"Content-Type":"application/json",...r},body:JSON.stringify({item:{"@microsoft.graph.conflictBehavior":"rename"}})})),l=327680*10;let u=0;for(;;){const h=Math.min(u+l,e.size);i&&i(Math.round(h/e.size*100));const p=await fetch(o.uploadUrl,{method:"PUT",headers:{"Content-Range":`bytes ${u}-${h-1}/${e.size}`},body:e.slice(u,h)});if(p.status===202){u=h;continue}return a(p)}}function lR(n){return!/^image\/(jpeg|png|webp)$/i.test(n.type)||n.size<4e5?Promise.resolve(n):new Promise(e=>{const t=URL.createObjectURL(n),s=new Image;s.onload=()=>{const i=Math.min(1,2e3/Math.max(s.naturalWidth,s.naturalHeight)),r=document.createElement("canvas");r.width=Math.round(s.naturalWidth*i),r.height=Math.round(s.naturalHeight*i);const a=r.getContext("2d");a.fillStyle="#fff",a.fillRect(0,0,r.width,r.height),a.drawImage(s,0,0,r.width,r.height),URL.revokeObjectURL(t),r.toBlob(o=>!o||o.size>=n.size?e(n):e(new File([o],n.name.replace(/\.[^.]+$/,"")+".jpg",{type:"image/jpeg"})),"image/jpeg",.82)},s.onerror=()=>{URL.revokeObjectURL(t),e(n)},s.src=t})}function uR(n,e,t){const s=vh(k.quotes,n),i='<a class="ib" href="#/inst">←</a>';if(!s)return t(e("Τιμολόγια & φωτο","",i),'<div class="empty">Δεν βρέθηκε</div>',"menu");const r=Oe.st,a=Xi(s),o=Ta(s),l=r&&r.connected,u=(h,p)=>{const m=o.filter(w=>w.kind===h);return`<div class="item"><div class="t"><b>${p} (${m.length})</b><span>${m.map(w=>Hl(w.size)).join(" · ")||"—"}</span></div>
    <div class="r"><label class="btn b2 sm">📷<input type="file" accept="image/*" capture="environment" hidden data-fl-ph="${h}"></label><label class="btn b2 sm">🖼️<input type="file" accept="image/*" hidden data-fl-ph="${h}"></label></div></div>
    ${m.map((w,E)=>`<div class="item sub"><div class="t"><b>${In(w.name)}</b><span>${w.ts?new Date(w.ts).toLocaleDateString("el-GR"):""} · ${Hl(w.size)}</span></div><div class="r">${w.url?`<a class="btn b2 sm" href="${In(w.url)}" target="_blank" rel="noopener">${E+1}</a>`:""}<button class="ib dk" data-fl-del="ph:${In(w.id)}">🗑️</button></div></div>`).join("")}`};return t(e("Τιμολόγια & φωτογραφίες",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,i),`${r?l?`<div class="hint">OneDrive: <b>${In(r.account||"συνδεδεμένο")}</b> · <a href="#" data-fl="logout">αποσύνδεση</a></div>`:`<div class="card pad"><b>Σύνδεση OneDrive</b><div class="muted small" style="margin:6px 0 10px">Τα αρχεία ανεβαίνουν στο OneDrive του λογαριασμού αποστολής (όπως στο PWA), φάκελος «TechMate». ${r.web?"Η σύνδεση γίνεται μόνο από την εφαρμογή στο κινητό.":""}</div>${r.web?"":'<button class="btn b1 wide" data-fl="login">🔗 Σύνδεση λογαριασμού Microsoft</button>'}</div>`:'<div class="empty">Φόρτωση…</div>'}
    ${Oe.busy?`<div class="upd">${In(Oe.busy)}</div>`:""}${Oe.msg?`<div class="err box">${In(Oe.msg)}</div>`:""}
    <div class="h">Τιμολόγια (${a.length})</div><div class="card">${a.map(h=>`<div class="item"><div class="t"><b>${In(h.name)}</b><span>${h.ts?new Date(h.ts).toLocaleDateString("el-GR"):""} · ${Hl(h.size)}</span></div><div class="r"><button class="btn b2 sm" data-fl-open="${In(h.id)}">Άνοιγμα</button><button class="ib dk" data-fl-del="doc:${In(h.id)}">🗑️</button></div></div>`).join("")||'<div class="empty">Κανένα τιμολόγιο.</div>'}
      <div class="pad"><label class="btn b1 wide ${l?"":"dis"}">🧾 Προσθήκη τιμολογίου<input type="file" accept="application/pdf,image/*" hidden data-fl-doc ${l?"":"disabled"}></label></div></div>
    <div class="h">Φωτογραφίες εγκατάστασης</div><div class="card ${l?"":"off"}">${u("before","Πριν")}${u("after","Μετά")}</div>
    <div class="hint">Η διαγραφή στέλνει το αρχείο και στον Κάδο ανακύκλωσης του OneDrive.</div>`,"menu")}async function dR(n,e,t,s){if(e.size>6e7)return Oe.msg="Το αρχείο είναι πολύ μεγάλο (πάνω από 60 MB).",s();Oe.busy="Ανέβασμα…",Oe.msg="",s();try{const i=await lR(e),r=await wh(),a=Kl(n.customer&&n.customer.name);let o=(/\.[a-z0-9]{2,5}$/i.exec(i.name)||[""])[0];i!==e&&(o=".jpg"),t&&!o&&(o=".jpg");const l=t?Kl([n.number||"έργο",a,t==="before"?"ΠΡΙΝ":"ΜΕΤΑ",Date.now().toString(36)].join("_")).slice(0,150)+".jpg":Kl([n.number,a,e.name.replace(/\.[^.]+$/,"")].filter(Boolean).join("_")).slice(0,150)+o.toLowerCase(),u=await cR(r,i,l,t?rR:iR,m=>{Oe.busy="Ανέβασμα… "+m+"%",s()}),h=vh(k.quotes,n.id)||n,p=Date.now().toString(36)+Math.random().toString(36).slice(2,6);t?(bc(h,"photos",Ta(h).concat([{id:p,odId:u.id,name:u.name||l,kind:t,size:u.size||i.size,url:u.webUrl||"",ts:Date.now()}])),Wu(h,"Φωτογραφία "+(t==="before"?"ΠΡΙΝ":"ΜΕΤΑ")+" στο OneDrive.")):(bc(h,"docs",Xi(h).concat([{id:p,odId:u.id,name:u.name||l,orig:e.name,size:u.size||i.size,mime:i.type||"",url:u.webUrl||"",ts:Date.now()}])),Wu(h,"Τιμολόγιο στο OneDrive: "+(u.name||l))),Oe.busy="",Oe.msg=""}catch(i){Oe.busy="",Oe.msg=i&&i.message||"Το ανέβασμα απέτυχε."}s()}async function hR(n,e,t,s){if(ni)return t("Στο δοκιμαστικό δεν ανοίγουν αρχεία.");Oe.busy="Λήψη…",s();try{const i=await wh(),r=await fetch(vc+"/me/drive/items/"+encodeURIComponent(e.odId)+"/content",{headers:{Authorization:"Bearer "+i}});if(r.status===404)throw new Error("Το αρχείο δεν βρέθηκε στο OneDrive (ίσως σβήστηκε από εκεί).");if(!r.ok)throw new Error("Το OneDrive δεν έδωσε το αρχείο ("+r.status+").");const a=await r.arrayBuffer(),o=new Uint8Array(a);let l="";for(let h=0;h<o.length;h+=32768)l+=String.fromCharCode.apply(null,o.subarray(h,h+32768));const u=e.mime||(/\.pdf$/i.test(e.name)?"application/pdf":"application/octet-stream");if(On){const h=await ue.shareFile({name:e.name,b64:btoa(l),mime:u,view:!0});if(h&&h.error)throw new Error(h.error)}else{const h=URL.createObjectURL(new Blob([a],{type:u})),p=document.createElement("a");p.href=h,p.download=e.name,p.click(),setTimeout(()=>URL.revokeObjectURL(h),5e3)}Oe.busy=""}catch(i){Oe.busy="",Oe.msg=i&&i.message||"Η λήψη απέτυχε."}s()}async function fR(n,e,t){const[s,i]=e.split(":"),r=(s==="ph"?Ta(n):Xi(n)).find(a=>a.id===i);if(r&&confirm("Να αφαιρεθεί «"+r.name+`»;
Θα πάει και στον Κάδο ανακύκλωσης του OneDrive (μπορείς να το επαναφέρεις από εκεί).`)){Oe.busy="Αφαίρεση…",Oe.msg="",t();try{if(!ni){const a=await wh(),o=await fetch(vc+"/me/drive/items/"+encodeURIComponent(r.odId),{method:"DELETE",headers:{Authorization:"Bearer "+a}});if(!o.ok&&o.status!==404)throw new Error("Το OneDrive δεν το έσβησε ("+o.status+").")}s==="ph"?bc(n,"photos",Ta(n).filter(a=>a.id!==i)):bc(n,"docs",Xi(n).filter(a=>a.id!==i)),Wu(n,"Αφαιρέθηκε "+(s==="ph"?"φωτογραφία":"τιμολόγιο")+": "+r.name)}catch(a){Oe.msg=a&&a.message||"Η διαγραφή απέτυχε."}Oe.busy="",t()}}const Bb=()=>vh(k.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));function pR(n,e,t){const s=n.closest("[data-fl],[data-fl-open],[data-fl-del]");if(!s)return!1;const i=s.dataset,r=Bb();return i.fl==="login"?ue.filesLogin():i.fl==="logout"?confirm("Αποσύνδεση του OneDrive από την εφαρμογή;")&&ue.filesDisconnect().then(()=>_h(e)):r&&i.flOpen?hR(r,Xi(r).find(a=>a.id===i.flOpen),t,e):r&&i.flDel&&fR(r,i.flDel,e),!0}function mR(n,e){const t=n.dataset;if(!("flDoc"in t)&&!t.flPh)return!1;const s=n.files&&n.files[0],i=Bb();return n.value="",s&&i&&dR(i,s,t.flPh||"",e),!0}const En=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),kt={list:null,err:"",busy:!1};function gR(n){kt.busy||(kt.busy=!0,TA().then(e=>{kt.list=e,kt.err=""},()=>{kt.err="Δεν φορτώθηκαν τα μηνύματα. Έλεγξε τη σύνδεση.",kt.list=kt.list||[]}).finally(()=>{kt.busy=!1,n()}))}function yR(n,e){const t=kt.list,s=(t||[]).filter(i=>!i.read).length;return e(n("Μηνύματα ιστοσελίδας",s?s+" νέα":"",'<a class="ib" href="#/menu">←</a>'),`${kt.err?`<div class="err box">${En(kt.err)}</div>`:""}<div class="card">${(t||[]).map(i=>{const r=String(i.phone||"").replace(/[^\d+]/g,""),a=i.at?new Date(i.at).toLocaleString("el-GR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"";return`<div class="item" style="align-items:flex-start;${i.read?"opacity:.7":""}"><div class="t" style="white-space:normal"><b>${i.read?"":"● "}${En(i.name)}</b><span>${En(a)}${[i.svc,i.area,i.day].filter(Boolean).length?" · "+[i.svc,i.area,i.day].filter(Boolean).map(En).join(" · "):""}</span>
        <div style="margin:6px 0;white-space:pre-wrap">${En(i.msg)}</div>
        <div class="actions">${r?`<a class="btn b2 sm" href="tel:${En(r)}">📞 ${En(i.phone)}</a>`:""}${i.email?`<a class="btn b2 sm" href="mailto:${En(i.email)}">✉️ Email</a>`:""}${i.read?"":`<button class="btn b2 sm" data-mread="${En(i.id)}">✔ Διαβάστηκε</button>`}</div></div></div>`}).join("")||`<div class="empty">${t?"Κανένα μήνυμα ακόμα.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Η διαγραφή μηνυμάτων γίνεται από το PWA.</div>`,"menu")}function vR(n,e){const t=n.closest("[data-mread]");if(!t)return!1;const s=(kt.list||[]).find(i=>i.id===t.dataset.mread);return s&&(s.read=!0,kA(s.id)),e(),!0}const X=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),bR=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),ht=n=>bR.format(Math.round((n||0)*100)/100),Ee=n=>String(q(A(n))).replace(".",","),Xt=n=>A(String(n??"").replace(",","."),NaN),zm=n=>n<10?"0"+n:""+n,Ih=n=>n.getFullYear()+"-"+zm(n.getMonth()+1)+"-"+zm(n.getDate()),cs=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},_R=n=>{try{return new Date(n+"T12:00").toLocaleDateString("el-GR",{weekday:"short"})}catch{return""}},Ae=(n,e)=>(n||[]).find(t=>t.id===e),wR=["Ιανουάριος","Φεβρουάριος","Μάρτιος","Απρίλιος","Μάιος","Ιούνιος","Ιούλιος","Αύγουστος","Σεπτέμβριος","Οκτώβριος","Νοέμβριος","Δεκέμβριος"],IR=n=>{const e=n.split("-");return wR[+e[1]-1]+" "+e[0]},ms=n=>!!Qr[n]||!!k[n].length,M={openNext:"",emp:"",month:"",f:null,stTab:"stock",stQ:"",stAll:!1,sheet:null,inQ:""},Eh=()=>!!M.f||!!M.sheet;function ER(){M.f=null,M.sheet=null}function _c(n){let e=0,t=0,s=0;return k.wdays.forEach(i=>{i.empId===n&&(e+=A(i.amount),s+=A(i.days))}),k.wpays.forEach(i=>{i.empId===n&&(t+=A(i.amount))}),{earned:q(e),paid:q(t),bal:q(e-t),days:q(s)}}function Gm(n){if(!n||!n.from||!n.until)return null;const e=n.from.split(":"),t=n.until.split(":");let s=+t[0]*60+ +t[1]-(+e[0]*60+ +e[1]);return s<=0&&(s+=1440),{txt:n.from+"–"+n.until,h:q(s/60)}}const Th=()=>k.emps.filter(n=>n.name&&(!Te()||n.id===Zt())).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),"el")),Gn=n=>n?JSON.parse(JSON.stringify(n)):null;function pi(n,e,t,s,i){if(Te())return;const r=i||s||{},a=n==="emps"?t:r.empId||"",o=Ae(k.emps,a);We("pbuys",{id:Qe(),ts:Date.now(),kind:"hist",area:"wages",coll:n,act:e,recId:t,empId:a,empName:n==="emps"?r.name||"":o&&o.name||"",partner:"",at:new Date().toISOString(),before:Gn(s),after:Gn(i)})}const Ql=(n,e)=>Object.keys({...n,...e}).some(t=>t!=="id"&&t!=="ts"&&JSON.stringify(n[t])!==JSON.stringify(e[t]));function TR(n,e){const t=Th();if(Te()){const r=t[0];return r?Wb(r.id,n,e,!0):e(n("Μεροκάματα",""),`<div class="card"><div class="empty">${ms("emps")?"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει.":"Φόρτωση…"}</div></div>`,"menu")}const s=t.reduce((r,a)=>r+Math.max(0,_c(a.id).bal),0),i=`<div class="kpis"><div class="kpi"><b class="${s>0?"bad":""}">${ht(s)}</b><span>Χρωστάω σε υπαλλήλους</span></div><div class="kpi"><b>${t.length}</b><span>Υπάλληλοι</span></div></div>
    <div class="card">${t.map(r=>{const a=_c(r.id);return`<a class="row" href="#/wage/${encodeURIComponent(r.id)}"><div class="av">👷</div><div class="t"><b>${X(r.name)}</b><span>${ht(r.rate||0)} / ημέρα · ${Ee(a.days)} ημέρες</span></div>
      <div class="r"><div class="amt ${a.bal>.004?"bad":""}">${a.bal>.004?ht(a.bal):a.bal<-.004?"−"+ht(-a.bal):"✓"}</div><span class="muted">${a.bal>.004?"του χρωστάω":a.bal<-.004?"προπληρωμή":"τακτοποιημένο"}</span></div></a>`}).join("")||`<div class="empty">${ms("emps")?"Δεν υπάρχουν υπάλληλοι.":"Φόρτωση…"}</div>`}</div>
    <button class="btn b2 wide" data-wa="emp-new">＋ Νέος υπάλληλος</button>
    <div class="hint" style="margin-top:10px">Η διαγραφή μεροκάματων/πληρωμών γίνεται από το PWA, που τις κρατά στον κάδο.</div>`;return e(n("Μεροκάματα","Υπάλληλοι · υπόλοιπα"),i+Gb(),"menu",'<button class="fab" data-wa="work-new" aria-label="Νέο μεροκάματο">＋</button>')}function Wb(n,e,t,s){const i=Ae(k.emps,n);if(!i)return t(e("Υπάλληλος","",'<a class="ib" href="#/wages">←</a>'),`<div class="card"><div class="empty">${ms("emps")?"Δεν βρέθηκε.":"Φόρτωση…"}</div></div>`,null);const r=_c(n),a=!Te(),o=[];k.wdays.forEach(E=>{E.empId===n&&o.push({t:"work",id:E.id,date:E.date,ts:E.ts||0,amt:A(E.amount),desc:(Gm(E)?Gm(E).txt+" · ":"")+Ee(E.days)+(A(E.days)===1?" ημέρα":" ημέρες")+" × "+ht(E.rate)+(E.note?" · "+E.note:"")})}),k.wpays.forEach(E=>{E.empId===n&&o.push({t:"pay",id:E.id,date:E.date,ts:E.ts||0,amt:-A(E.amount),desc:(E.method==="bank"?"Τράπεζα":"Μετρητά")+(E.note?" · "+E.note:"")})});const l=[...new Set(o.map(E=>String(E.date).slice(0,7)))].sort().reverse(),u=M.month&&l.includes(M.month)?M.month:"",h=o.filter(E=>!u||String(E.date).startsWith(u)).sort((E,N)=>E.date<N.date?1:E.date>N.date?-1:N.ts-E.ts),p=h.filter(E=>E.amt>0).reduce((E,N)=>E+N.amt,0),m=h.filter(E=>E.amt<0).reduce((E,N)=>E-N.amt,0),w=`<div class="kpis"><div class="kpi"><b class="${r.bal>.004?"bad":""}">${ht(r.bal)}</b><span>${s?"Μου χρωστάνε":"Του χρωστάω"}</span></div><div class="kpi"><b>${Ee(r.days)}</b><span>Ημέρες συνολικά</span></div>
    <div class="kpi"><b>${ht(r.earned)}</b><span>Μεροκάματα</span></div><div class="kpi"><b>${ht(r.paid)}</b><span>Πληρωμές</span></div></div>
    <div class="actions"><button class="btn b1" data-wa="work-new" data-emp="${X(n)}">＋ Μεροκάματο</button>${a?`<button class="btn b2" data-wa="pay-new" data-emp="${X(n)}">💶 Πληρωμή</button>`:""}</div>
    ${l.length>1?`<div class="chips"><button data-wm="" class="${u?"":"on"}">Όλοι οι μήνες</button>${l.map(E=>`<button data-wm="${E}" class="${u===E?"on":""}">${IR(E)}</button>`).join("")}</div>`:""}
    <div class="card">${h.map(E=>`<${a?`button class="row prow" data-wa="${E.t}-edit" data-id="${X(E.id)}"`:'div class="row"'}><div class="av">${E.t==="work"?"🛠️":"💶"}</div>
      <div class="t"><b>${cs(E.date)} · ${_R(E.date)}</b><span>${X(E.desc)}</span></div><div class="r"><div class="amt ${E.amt<0?"ok":""}">${E.amt>0?"+":"−"}${ht(Math.abs(E.amt))}</div><span class="muted">${E.t==="work"?"μεροκάματο":"πληρωμή"}</span></div></${a?"button":"div"}>`).join("")||`<div class="empty">${ms("wdays")?"Καμία κίνηση.":"Φόρτωση…"}</div>`}
    ${h.length?`<div class="tot"><span>Μεροκάματα ${ht(p)} · Πληρωμές ${ht(m)}</span><b>${ht(p-m)}</b></div>`:""}</div>
    ${a?`<button class="btn b2 wide" data-wa="emp-edit" data-emp="${X(n)}">✏️ Στοιχεία υπαλλήλου</button>`:'<div class="hint">Τα μεροκάματα που καταχωρείς μπαίνουν με το ημερομίσθιο που έχει ορίσει ο διαχειριστής. Αλλαγές και πληρωμές τις κάνει εκείνος.</div>'}`;return t(e(i.name,`${ht(i.rate||0)} / ημέρα`,s?"":'<a class="ib" href="#/wages">←</a>'),w+Gb(),s?"menu":null)}function kR(n,e,t){const s=[],i=n.split("-"),r=e.split("-"),a=new Date(+i[0],+i[1]-1,+i[2],12),o=new Date(+r[0],+r[1]-1,+r[2],12);for(;a<=o&&s.length<93;){const l=a.getDay();t&&(l===0||l===6)||s.push(Ih(a)),a.setDate(a.getDate()+1)}return s}function zb(n){return n.date?n.id||!n.to||n.to<=n.date?[n.date]:kR(n.date,n.to,!!n.skipWe):[]}function mi(n,e,t){const s=e||(Te()?Zt():M.emp)||(Th()[0]||{}).id||"";if(n==="work"){const i=t&&Ae(k.wdays,t),r=Ae(k.emps,i?i.empId:s);M.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,days:Ee(i.days),rate:Ee(i.rate!=null&&i.rate!==""?i.rate:A(i.days)?A(i.amount)/A(i.days):r&&r.rate||0),note:i.note||"",from:i.from||"",until:i.until||""}:{empId:s,date:ve(),to:"",skipWe:!0,days:"1",rate:Ee(r&&r.rate||0),note:"",from:"",until:""},msg:""}}else if(n==="pay"){const i=t&&Ae(k.wpays,t);M.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,amount:Ee(i.amount),method:i.method||"cash",note:i.note||""}:{empId:s,date:ve(),amount:"",method:"cash",note:""},msg:""}}else{const i=t&&Ae(k.emps,t);M.f={kind:"emp",v:i?{id:i.id,name:i.name||"",rate:Ee(i.rate||0),phone:i.phone||"",email:i.email||""}:{name:"",rate:"",phone:"",email:""},msg:""}}}const Ct=(n,e,t="")=>`<label class="f">${e}<input class="in" data-wf="${n}" value="${X(M.f.v[n]??"")}" ${t}></label>`;function Gb(){const n=M.f;if(!n)return"";const e=n.v,t=Te(),s=Th();let i="",r="";const a=`<label class="f">Υπάλληλος<select class="in" data-wf="empId" ${t||e.id?"disabled":""}>${s.map(o=>`<option value="${X(o.id)}" ${o.id===e.empId?"selected":""}>${X(o.name)}</option>`).join("")}</select></label>`;if(n.kind==="work"){i=e.id?"Διόρθωση μεροκάματου":"Νέο μεροκάματο";const o=zb(e).length,l=Xt(e.days),u=t?A((Ae(k.emps,Zt())||{}).rate):Xt(e.rate);r=`${a}<div class="two">${Ct("date","Ημερομηνία",'type="date"')}${e.id?"":Ct("to","Έως (για πολλές μέρες)",'type="date"')}</div>
      ${!e.id&&e.to&&e.to>e.date?`<label class="chk2"><input type="checkbox" data-wf="skipWe" ${e.skipWe?"checked":""}> Χωρίς Σάββατο/Κυριακή</label>`:""}
      <div class="f">Ημέρες ανά ημερομηνία</div><div class="chips wrap">${["1","0,5","1,5","2"].map(h=>`<button data-wd="${h}" class="${e.days===h?"on":""}">${h}</button>`).join("")}</div>
      <div class="two">${Ct("days","Ημέρες",'inputmode="decimal"')}${Ct("rate","Ημερομίσθιο €",`inputmode="decimal" ${t?"disabled":""}`)}</div>
      <div class="two">${Ct("from","Από ώρα (προαιρετικό)",'type="time"')}${Ct("until","Έως ώρα",'type="time"')}</div>
      ${Ct("note","Σημείωση",'placeholder="π.χ. εγκατάσταση Βόνιτσα"')}
      <div class="ask">${o?`${o} ${o===1?"ημέρα":"ημέρες"} × ${isNaN(l)?"—":Ee(l)} × ${ht(isNaN(u)?0:u)} = <b>${ht(q(o*(isNaN(l)?0:l)*(isNaN(u)?0:u)))}</b>`:"Βάλε ημερομηνία."}</div>`}else n.kind==="pay"?(i=e.id?"Διόρθωση πληρωμής":"Πληρωμή στον υπάλληλο",r=`${a}<div class="two">${Ct("date","Ημερομηνία",'type="date"')}${Ct("amount","Ποσό €",'inputmode="decimal"')}</div>
      <div class="seg">${[["cash","💵 Μετρητά"],["bank","🏦 Τράπεζα"]].map(([o,l])=>`<button data-wpm="${o}" class="${e.method===o?"on":""}">${l}</button>`).join("")}</div>
      ${Ct("note","Σημείωση")}${e.empId?`<div class="ask">Του χρωστάω τώρα <b>${ht(_c(e.empId).bal)}</b></div>`:""}`):(i=e.id?"Στοιχεία υπαλλήλου":"Νέος υπάλληλος",r=`${Ct("name","Όνομα",'autocomplete="off"')}${Ct("rate","Ημερομίσθιο €",'inputmode="decimal"')}${Ct("phone","Κινητό",'inputmode="tel"')}${Ct("email","Email",'inputmode="email"')}
      ${e.id?'<div class="hint">Η αλλαγή ημερομισθίου ισχύει για τα νέα μεροκάματα· τα παλιά μένουν όπως είναι.</div>':""}`);return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${i}</b><button class="ib dk" data-wa="close">✕</button></div>
    <div class="sheet-list pad">${r}${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-wa="close">Άκυρο</button><button class="btn b1" data-wa="save">💾 Αποθήκευση</button></div></div></div>`}function SR(n){const e=M.f,t=e.v,s=Te();if(!ms("emps"))return e.msg="Περίμενε να φορτώσουν τα δεδομένα.";if(e.kind==="emp"){const m=String(t.name||"").trim(),w=Xt(t.rate);if(!m)return e.msg="Γράψε όνομα.";if(isNaN(w)||w<0)return e.msg="Βάλε ημερομίσθιο.";const E={name:m,rate:q(w),phone:String(t.phone||"").trim(),email:String(t.email||"").trim()};if(t.id){const N=Gn(Ae(k.emps,t.id));Ht("emps",t.id,E);const $=Ae(k.emps,t.id);Ql(N,$)&&pi("emps","edit",t.id,N,Gn($))}else{const N={id:Qe(),ts:Date.now(),...E};We("emps",N),pi("emps","create",N.id,null,N)}return M.f=null,n(t.id?"Ο υπάλληλος ενημερώθηκε.":"Ο υπάλληλος προστέθηκε."),""}const i=s?Zt():t.empId,r=Ae(k.emps,i);if(!r)return e.msg="Διάλεξε υπάλληλο.";if(e.kind==="pay"){const m=Xt(t.amount);if(!t.date)return e.msg="Βάλε ημερομηνία.";if(isNaN(m))return e.msg="Βάλε ποσό.";const w={empId:i,date:t.date,amount:q(m),method:t.method==="bank"?"bank":"cash",note:String(t.note||"").trim()};if(t.id){const E=Gn(Ae(k.wpays,t.id));Ht("wpays",t.id,w);const N=Ae(k.wpays,t.id);Ql(E,N)&&pi("wpays","edit",t.id,E,Gn(N))}else{const E={id:Qe(),ts:Date.now(),...w};We("wpays",E),pi("wpays","create",E.id,null,E)}return M.f=null,n(t.id?"Η πληρωμή ενημερώθηκε.":"Η πληρωμή αποθηκεύτηκε."),""}const a=zb(t);if(!a.length)return e.msg="Βάλε ημερομηνία.";const o=Xt(t.days);let l=Xt(t.rate);if(s&&(l=A(r.rate,0),t.id))return e.msg="Τις αλλαγές τις κάνει ο διαχειριστής.";if(isNaN(o)||o<=0||o>31)return e.msg="Βάλε πόσες ημέρες δούλεψε (π.χ. 1 ή 0,5).";if(isNaN(l))return e.msg="Βάλε ημερομίσθιο.";const u=t.from||"",h=t.until||"";if(!!u!=!!h)return e.msg="Βάλε και τις δύο ώρες (από – έως) ή καμία.";const p={empId:i,days:o,rate:l,amount:q(o*l),note:String(t.note||"").trim(),from:u,until:h};if(t.id){const m=Gn(Ae(k.wdays,t.id));Ht("wdays",t.id,{...p,date:a[0]});const w=Ae(k.wdays,t.id);Ql(m,w)&&pi("wdays","edit",t.id,m,Gn(w))}else{const m=Date.now(),w=Qe();a.forEach((E,N)=>{const $={id:w+N,...p,date:E,ts:m+N};We("wdays",$),pi("wdays","create",$.id,null,$)})}return M.f=null,n(t.id?"Το μεροκάματο ενημερώθηκε.":a.length===1?"Το μεροκάματο αποθηκεύτηκε.":`Προστέθηκαν ${a.length} μεροκάματα.`),""}function sl(n,e){let t=0,s=0,i=0,r=0;return k.ldocs.forEach(a=>{a.kind==="purchase"&&a.items&&a.items.forEach(o=>{o.pid===n&&(t+=A(o.qty))})}),k.smoves.forEach(a=>{a.pid===n&&(t+=A(a.qty))}),k.quotes.forEach(a=>{if(a.id===e)return;const o=pt(a);(a.lines||[]).forEach(l=>{if(l.pid!==n||l.src!=="stock")return;const u=A(l.qty);o==="done"?a.noStock||(s+=u):o==="accepted"?i+=u:o==="pending"&&(r+=u)})}),{inQ:q(t),onHand:q(t-s),reserved:q(i),pending:q(r),avail:q(t-s-i)}}const Kb=n=>n&&Array.isArray(n.links)&&n.links.length?n.links:n&&(n.sup||n.url)?[{sup:n.sup||"",url:n.url||""}]:[];function qo(){const n={},e=(t,s)=>n[t]||(n[t]={pid:t,qty:0,sup:0,stk:0,qs:[],desc:s||"",why:[]});return k.quotes.forEach(t=>{pt(t)==="accepted"&&(t.lines||[]).forEach(s=>{if(!s.pid||s.src!=="supplier")return;const i=e(s.pid,s.desc);i.sup+=A(s.qty),i.qs.includes(t.number)||i.qs.push(t.number)})}),k.products.forEach(t=>{const s=A(t.minQty,0),i=sl(t.id),r=Math.max(0,s-i.avail);if(r>.004){const a=e(t.id,t.model);a.stk=q(r),a.why.push(i.avail<0?"λείπουν "+Ee(-i.avail)+" για δεσμευμένες"+(s?" + ελάχιστο "+Ee(s):""):"απόθεμα "+Ee(i.avail)+" < ελάχιστο "+Ee(s))}}),Object.values(n).map(t=>(t.qty=q(t.sup+t.stk),t.sup&&t.why.unshift(Ee(t.sup)+" για προσφορές "+t.qs.join(", ")),t)).filter(t=>t.qty>0).sort((t,s)=>{const i=Ae(k.products,t.pid),r=Ae(k.products,s.pid);return String(i?i.model:t.desc).localeCompare(String(r?r.model:s.desc),"el")})}function AR(){const n={};return qo().forEach(e=>{const t=Ae(k.products,e.pid),s=t?Kb(t)[0]:null,i=s&&s.sup||"Χωρίς προμηθευτή";(n[i]=n[i]||[]).push("• "+(t?t.model:e.desc)+" × "+Ee(e.qty))}),Object.keys(n).sort().map(e=>e+`:
`+n[e].join(`
`)).join(`

`)}const PR={in:"Χειροκίνητη εισαγωγή",out:"Χειροκίνητη έξοδος",set:"Διόρθωση αποθέματος"};function RR(n,e){Te()&&(M.stTab="needs");const t=Te()?[["needs","🧰 Εργαλεία που λείπουν"]]:[["stock","📦 Απόθεμα"],["order","🛒 Παραγγελία"],["moves","↕ Κινήσεις"],["needs","🧰 Λείπουν"]],s=M.stTab;let i=t.length>1?`<div class="chips">${t.map(([r,a])=>`<button data-stt="${r}" class="${s===r?"on":""}">${a}${r==="order"&&qo().length?` (${qo().length})`:""}${r==="needs"?` (${k.needs.filter(o=>!o.gone&&!o.done).length})`:""}</button>`).join("")}</div>`:"";if(s==="stock"){const r=k.products.map(m=>({p:m,i:sl(m.id)}));let a=0,o=0,l=0,u=0;r.forEach(m=>{m.i.onHand>0&&(a++,o+=m.i.onHand,l+=m.i.onHand*A(m.p.cost)),m.i.avail<0&&u++});const h=qe(M.stQ),p=r.filter(m=>(M.stAll||m.i.inQ!==0||m.i.onHand!==0||m.i.reserved||m.i.pending||A(m.p.minQty,0)>0)&&qe((m.p.cat||"")+" "+m.p.model+" "+(m.p.desc||"")).includes(h)).sort((m,w)=>String(m.p.model).localeCompare(String(w.p.model),"el"));i+=`<div class="kpis"><div class="kpi"><b>${a}</b><span>Είδη στο ράφι</span></div><div class="kpi"><b>${Ee(o)}</b><span>Τεμάχια</span></div><div class="kpi"><b>${ht(l)}</b><span>Αξία (τιμή αγοράς)</span></div><div class="kpi"><b class="${u?"bad":""}">${u}</b><span>Ελλείψεις</span></div></div>
      <input class="search" id="stq" data-stq placeholder="🔍 Αναζήτηση προϊόντος" value="${X(M.stQ)}">
      <label class="chk2"><input type="checkbox" data-stall ${M.stAll?"checked":""}> Όλα τα προϊόντα του καταλόγου</label>
      <div class="card">${p.slice(0,200).map(({p:m,i:w})=>{const E=A(m.minQty,0);return`<button class="row prow" data-sp="${X(m.id)}">${m.img?`<img class="pth" src="${X(m.img)}" alt="" loading="lazy">`:'<span class="pth ph">📦</span>'}<div class="t"><b>${X(m.model)}</b><span>${X([m.cat,m.desc].filter(Boolean).join(" · "))}${w.reserved?` · δεσμευμένα ${Ee(w.reserved)}`:""}${w.pending?` · σε προσφορές ${Ee(w.pending)}`:""}${E?` · ελάχ. ${Ee(E)}`:""}</span></div>
        <div class="r"><div class="amt">${Ee(w.onHand)}</div><span class="pill ${w.avail<0?"p-b":E&&w.avail<E?"p-w":w.avail>0?"p-ok":"p-a"}">διαθ. ${Ee(w.avail)}</span></div></button>`}).join("")||`<div class="empty">${ms("products")?k.products.length?"Δεν υπάρχουν προϊόντα στην αποθήκη. Τσέκαρε «Όλα τα προϊόντα» για να βάλεις απόθεμα.":"Ο κατάλογος είναι άδειος.":"Φόρτωση…"}</div>`}</div>`}else if(s==="order"){const r=qo();i+=`<div class="card">${r.map(a=>{const o=Ae(k.products,a.pid),l=o?Kb(o):[];return`<div class="item"><div class="t"><b>${X(o?o.model:a.desc)} × ${Ee(a.qty)}</b><span style="white-space:normal">${X(a.why.join(" · "))}</span>
      ${l.map(u=>`<span>${X(u.sup||"")}${u.code?" · "+X(u.code):""}${/^https?:\/\//.test(u.url||"")?` · <a class="lnk" href="${X(u.url)}">άνοιγμα</a>`:""}</span>`).join("")}</div></div>`}).join("")||'<div class="empty">Τίποτα προς παραγγελία. Εδώ μπαίνουν οι γραμμές «Από προμηθευτή» των δεκτών προσφορών, οι ελλείψεις και ό,τι είναι κάτω από το ελάχιστο απόθεμα.</div>'}</div>
      ${r.length?'<button class="btn b1 wide" data-sa="ocopy">📋 Αντιγραφή λίστας ανά προμηθευτή</button>':""}`}else if(s==="moves"){const r=[];k.smoves.forEach(a=>r.push({date:a.date,ts:a.ts||0,pid:a.pid,qty:A(a.qty),why:PR[a.kind]||"Κίνηση",note:a.note})),k.ldocs.forEach(a=>{a.kind==="purchase"&&a.items&&a.items.forEach(o=>r.push({date:a.date,ts:a.ts||0,pid:o.pid,qty:A(o.qty),why:"Αγορά από "+a.party+(a.number?" ("+a.number+")":""),note:""}))}),r.sort((a,o)=>a.date<o.date?1:a.date>o.date?-1:o.ts-a.ts),i+=`<div class="card">${r.slice(0,80).map(a=>{const o=Ae(k.products,a.pid);return`<div class="item"><div class="t"><b>${X(o?o.model:"(διαγραμμένο προϊόν)")}</b><span>${cs(a.date)} · ${X(a.why)}${a.note?" · "+X(a.note):""}</span></div><div class="amt ${a.qty<0?"bad":"ok"}">${a.qty>0?"+":""}${Ee(a.qty)}</div></div>`}).join("")||'<div class="empty">Δεν υπάρχουν κινήσεις ακόμα.</div>'}</div>`}else i+=DR();return e(n(Te()?"Εργαλεία που λείπουν":"Αποθήκη",Te()?"Ό,τι λείπει από το συνεργείο":"Απόθεμα · παραγγελίες · εργαλεία"),i+$R(),"menu",s==="needs"?'<button class="fab" data-na="new" aria-label="Προσθήκη">＋</button>':"")}function $R(){const n=M.sheet;if(!n)return"";if(n.kind==="need"){const a=n.v;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${a.id?"Αλλαγή":"Τι λείπει;"}</b><button class="ib dk" data-na="close">✕</button></div><div class="sheet-list pad">
      <label class="f">Εργαλείο / υλικό<input class="in" data-nf="title" maxlength="120" value="${X(a.title)}" placeholder="π.χ. Κρουστικό δράπανο"></label>
      <div class="two"><label class="f">Ποσότητα<input class="in" data-nf="qty" maxlength="20" value="${X(a.qty)}"></label><label class="f">Σημείωση<input class="in" data-nf="notes" maxlength="300" value="${X(a.notes)}"></label></div>
      ${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}</div><div class="actions"><button class="btn b2" data-na="close">Άκυρο</button><button class="btn b1" data-na="save">💾 Αποθήκευση</button></div></div></div>`}const e=Ae(k.products,n.pid);if(!e)return"";const t=sl(e.id),s=n.v,i=Xt(s.qty),r=isNaN(i)?null:s.type==="in"?t.onHand+i:s.type==="out"?t.onHand-i:i;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${X(e.model)}</b><button class="ib dk" data-sa="close">✕</button></div><div class="sheet-list pad">
    <div class="kpis"><div class="kpi"><b>${Ee(t.onHand)}</b><span>Στο ράφι</span></div><div class="kpi"><b class="${t.avail<0?"bad":""}">${Ee(t.avail)}</b><span>Διαθέσιμα (μετά τις δεσμευμένες)</span></div></div>
    <div class="seg">${[["in","➕ Εισαγωγή"],["out","➖ Έξοδος"],["set","✏️ Διόρθωση"]].map(([a,o])=>`<button data-smt="${a}" class="${s.type===a?"on":""}">${o}</button>`).join("")}</div>
    <div class="two"><label class="f">${s.type==="set"?"Πραγματική ποσότητα στο ράφι":"Ποσότητα"}<input class="in" data-sf="qty" inputmode="decimal" value="${X(s.qty)}"></label><label class="f">Ημερομηνία<input class="in" type="date" data-sf="date" value="${X(s.date)}"></label></div>
    <label class="f">Σημείωση<input class="in" data-sf="note" value="${X(s.note)}"></label>
    <div class="ask" id="smprev">Τώρα στο ράφι: ${Ee(t.onHand)} τεμ.${r!==null&&s.qty!==""?` → μετά: <b>${Ee(q(r))}</b>`:""}</div>
    <label class="f" style="margin-top:10px">Ελάχιστο απόθεμα (κάτω από αυτό μπαίνει στη λίστα παραγγελίας)<input class="in" data-sf="min" inputmode="decimal" value="${X(s.min)}" placeholder="—"></label>
    ${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-sa="close">Άκυρο</button><button class="btn b1" data-sa="save">💾 Αποθήκευση</button></div></div></div>`}function CR(n){const e=M.sheet,t=e.v,s=Ae(k.products,e.pid);if(!s)return M.sheet=null;const i=t.min.trim()===""?0:Math.max(0,Xt(t.min));if(isNaN(i))return e.msg="Το ελάχιστο απόθεμα πρέπει να είναι αριθμός.";let r=[];if(t.qty.trim()!==""){const a=Xt(t.qty);if(isNaN(a)||a<0)return e.msg="Βάλε ποσότητα.";const o=sl(s.id),l=t.type==="in"?a:t.type==="out"?-a:q(a-o.onHand);if(!l)return e.msg="Δεν υπάρχει αλλαγή στην ποσότητα.";We("smoves",{id:Qe(),pid:s.id,qty:q(l),kind:t.type,date:t.date||ve(),note:t.note.trim(),ts:Date.now()}),r.push("Η κίνηση αποθηκεύτηκε")}A(s.minQty,0)!==i&&(Ht("products",s.id,{minQty:i}),r.push(i?"ελάχιστο "+Ee(i):"χωρίς ελάχιστο")),M.sheet=null,n(r.length?r.join(" · ")+".":"Καμία αλλαγή.")}const wc=n=>!Te()||!!(Hi()&&n.by&&n.by.uid===Hi().uid),Km=n=>n?cs(Ih(new Date(n))):"";function DR(){const n=k.needs.filter(i=>!i.gone),e=n.filter(i=>!i.done).sort((i,r)=>(r.ts||0)-(i.ts||0)),t=n.filter(i=>i.done).sort((i,r)=>(r.doneAt||r.ts||0)-(i.doneAt||i.ts||0)),s=(i,r)=>`<div class="tc${r?" dn":""}" style="--c:${r?"var(--ok)":"var(--warn)"}">
    ${Te()?`<span class="tick${r?" on":""}" style="display:flex;align-items:center;justify-content:center">${r?"✓":""}</span>`:`<button class="tick${r?" on":""}" data-na="done" data-id="${X(i.id)}" aria-label="Παραγγέλθηκε">${r?"✓":""}</button>`}
    <div class="t" style="flex:1"><b>${X(i.title)}${i.qty?" × "+X(i.qty):""}</b><span>${X(i.by&&i.by.name||"—")} · ${X(Km(i.ts))}${r&&i.doneAt?" · ✔ παραγγέλθηκε "+X(Km(i.doneAt)):""}${i.notes?" · "+X(i.notes):""}</span></div>
    ${wc(i)?`<button class="x" style="background:var(--accs);color:var(--acc)" data-na="edit" data-id="${X(i.id)}" aria-label="Αλλαγή">✏️</button><button class="x" data-na="gone" data-id="${X(i.id)}" aria-label="Αφαίρεση">✕</button>`:""}</div>`;return`<div class="hint">${Te()?"Ό,τι γράφεις εδώ το βλέπει και ο διαχειριστής και μπαίνει στη λίστα παραγγελιών του.":"Το PWA τα συγχρονίζει με τη λίστα «Εργαλεία που λείπουν» του Microsoft To Do."}</div>
    <div class="h">Να παραγγελθούν (${e.length})${!Te()&&e.length?'<a class="hl" data-na="copy">📋 Αντιγραφή</a>':""}</div>
    <div class="card">${e.map(i=>s(i,!1)).join("")||`<div class="empty">${ms("needs")?"Δεν λείπει τίποτα αυτή τη στιγμή.":"Φόρτωση…"}</div>`}</div>
    ${t.length?`<div class="h">Παραγγέλθηκαν (${t.length})</div><div class="card">${t.slice(0,40).map(i=>s(i,!0)).join("")}</div>`:""}`}function NR(n){const e=M.sheet,t=e.v,s=String(t.title||"").trim().slice(0,120);if(!s)return e.msg="Γράψε ποιο εργαλείο λείπει.";const i=Date.now(),r=String(t.qty||"").trim().slice(0,20),a=String(t.notes||"").trim().slice(0,300);if(t.id){const o=Ae(k.needs,t.id);if(!o||!wc(o))return M.sheet=null;Ht("needs",o.id,{title:s,qty:r,notes:a,by:o.by||{uid:"",name:""},upd:i,dirty:!0}),n("Η καταχώριση ενημερώθηκε.")}else We("needs",{id:Qe(),ts:i,title:s,qty:r,notes:a,done:!1,gone:!1,msId:"",msList:"",by:as()||{uid:"",name:"Διαχειριστής"},upd:i,dirty:!0}),n("Προστέθηκε: "+s+".");M.sheet=null}const Hb=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(A(e.m,0))):A(se()&&se().warrantyMonths,24)},Hm=n=>!(n&&n.war&&n.war.on===!1),Fs=n=>n.install||{date:n.statusDate||"",months:Hm(n)?Hb(n):0,serials:"",nw:!Hm(n)},il=(n,e)=>{if(!n)return"";const t=new Date(n+"T00:00:00");return isNaN(t)?"":(t.setMonth(t.getMonth()+A(e,0)),Ih(t))};function Qm(n){const e=Fs(n);if(e.nw)return{k:"na",t:"Χωρίς εγγύηση",end:""};const t=il(e.date,e.months);if(!t)return{k:"na",t:"—",end:""};const s=Math.ceil((new Date(t+"T23:59:59")-Date.now())/864e5);return s<0?{k:"ex",t:"Έληξε",end:t,days:s}:s<=60?{k:"warn",t:"Λήγει σε "+s+" ημ.",end:t,days:s}:{k:"okp",t:"Ενεργή",end:t,days:s}}const xR=n=>{const e=Fs(n);return A(e.mt,0)>0?il(e.mtLast||e.date,e.mt):""},VR={okp:"p-ok",warn:"p-w",ex:"p-b",na:"p-a"};function OR(n,e){const t=k.quotes.filter(u=>pt(u)==="done").sort((u,h)=>(Fs(h).date||"")<(Fs(u).date||"")?-1:1),s={okp:0,warn:0,ex:0};t.forEach(u=>{const h=Qm(u);s[h.k]!=null&&s[h.k]++});const i=qe(M.inQ),r=t.filter(u=>!i||qe([u.number,u.subject,u.customer&&u.customer.name,u.customer&&u.customer.address].join(" ")).includes(i)),a=ve().slice(0,10),o=il(a,1),l=`<div class="kpis"><div class="kpi"><b>${t.length}</b><span>Εγκαταστάσεις</span></div><div class="kpi"><b>${s.okp}</b><span>Ενεργές εγγυήσεις</span></div>
    <div class="kpi"><b class="${s.warn?"bad":""}">${s.warn}</b><span>Λήγουν σε 60 ημέρες</span></div><div class="kpi"><b>${s.ex}</b><span>Έληξαν</span></div></div>
    <input class="search" id="inq" data-inq placeholder="🔍 Πελάτης, αριθμός, περιοχή" value="${X(M.inQ)}">
    <div class="card">${r.map(u=>{const h=Fs(u),p=Qm(u),m=xR(u),w=u.customer&&u.customer.name||"";return`<button class="row prow" data-ie="${X(u.id)}"><div class="av">${mn(u)?"🛠️":"🛡️"}</div><div class="t"><b>${mn(u)?X(u.subject||"Παλιά εγκατάσταση"):"#"+X(u.number||"—")+" · "+X(w)}</b>
        <span>${mn(u)?X(w)+" · ":u.subject?X(u.subject)+" · ":""}${h.date?"εγκατ. "+cs(h.date):"χωρίς ημερομηνία"}${p.end?" · λήξη "+cs(p.end):""}${m?" · 🔧 "+cs(m):""}</span></div>
        <div class="r"><span class="pill ${VR[p.k]}">${X(p.t)}</span>${m&&m<=o?'<span class="pill p-w">🔧 συντήρηση</span>':""}</div></button>`}).join("")||`<div class="empty">${ms("quotes")?"Δεν υπάρχουν ολοκληρωμένες εγκαταστάσεις.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Βεβαίωση, υπογραφή και κωδικοί εγκατάστασης: από το PWA.</div>`;return e(n("Εγκαταστάσεις","Εγγυήσεις · συντηρήσεις"),l+MR(),"menu")}function MR(){const n=M.sheet;if(!n||n.kind!=="inst")return"";const e=Ae(k.quotes,n.id);if(!e)return"";const t=n.v,s=t.nw?"":il(t.date,A(t.months,0));return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${mn(e)?X(e.subject||"Εγκατάσταση"):"#"+X(e.number)+" · "+X(e.customer&&e.customer.name||"")}</b><button class="ib dk" data-ia="close">✕</button></div><div class="sheet-list pad">
    <label class="f">Ημερομηνία εγκατάστασης<input class="in" type="date" data-if="date" value="${X(t.date)}"></label>
    <label class="chk2"><input type="checkbox" data-if="war" ${t.nw?"":"checked"}> Με εγγύηση</label>
    ${t.nw?"":`<label class="f">Μήνες εγγύησης<input class="in" data-if="months" inputmode="numeric" value="${X(t.months)}"></label><div class="hint">Λήξη: <b>${s?cs(s):"—"}</b></div>`}
    <a class="btn b2 wide" href="#/files/${encodeURIComponent(e.id)}">🧾 Τιμολόγια & φωτογραφίες (${(e.install&&e.install.docs||[]).length}/${(e.install&&e.install.photos||[]).length})</a>
    <a class="btn b2 wide" href="#/sn/${encodeURIComponent(e.id)}">🔢 Σειριακοί (${(e.install&&e.install.sns||[]).length})</a>
    <div class="f">🔧 Περιοδική συντήρηση</div><div class="chips wrap">${[[0,"Καμία"],[6,"Κάθε 6 μήνες"],[12,"Κάθε 12 μήνες"]].map(([i,r])=>`<button data-imt="${i}" class="${A(t.mt,0)===i?"on":""}">${r}</button>`).join("")}</div>
    ${A(t.mt,0)?`<label class="f">Τιμή συντήρησης €<input class="in" data-if="mtp" inputmode="decimal" value="${X(t.mtp)}" placeholder="π.χ. 120"></label>`:""}
    ${n.msg?`<div class="err box">${X(n.msg)}</div>`:""}
    <a class="btn b2 wide" href="#/q/${encodeURIComponent(e.id)}">📄 Άνοιγμα ${mn(e)?"έργου":"προσφοράς"}</a></div>
    <div class="actions"><button class="btn b2" data-ia="close">Άκυρο</button><button class="btn b1" data-ia="save">💾 Αποθήκευση</button></div></div></div>`}function LR(n){const e=M.sheet,t=Ae(k.quotes,e.id);if(!t)return M.sheet=null;const s=e.v,i=Se(Fs(t));if(i.date=s.date||"",i.nw=!!s.nw,!i.nw){const a=Math.floor(Xt(s.months));if(isNaN(a)||a<0)return e.msg="Βάλε μήνες εγγύησης.";i.months=a}const r=Math.max(0,Math.floor(A(s.mt,0)));if(r){i.mt=r;const a=Xt(s.mtp);a>0?i.mtp=q(a):delete i.mtp}else delete i.mt,delete i.mtLast,delete i.mtp;Ht("quotes",t.id,{install:i}),M.sheet=null,n("Αποθηκεύτηκε.")}function Qb(n){const e=Ae(k.products,n);return e?(M.stTab="stock",M.sheet={kind:"stock",pid:n,v:{type:"in",qty:"",date:ve(),note:"",min:A(e.minQty,0)?Ee(e.minQty):""},msg:""},!0):!1}function FR(n,e,t){const s=n.closest("[data-wa],[data-wm],[data-wd],[data-wpm],[data-stt],[data-sp],[data-sa],[data-smt],[data-na],[data-ie],[data-ia],[data-imt]");if(!s)return!1;const i=s.dataset;if(i.wa){const r=i.wa;r==="close"?M.f=null:r==="save"?SR(t):r==="work-new"?mi("work",i.emp):r==="pay-new"?mi("pay",i.emp):r==="work-edit"?mi("work","",i.id):r==="pay-edit"?mi("pay","",i.id):r==="emp-new"?mi("emp"):r==="emp-edit"&&mi("emp","",i.emp)}else if(i.wm!==void 0)M.month=i.wm;else if(i.wd)M.f&&(M.f.v.days=i.wd);else if(i.wpm)M.f&&(M.f.v.method=i.wpm);else if(i.stt)M.stTab=i.stt;else if(i.sp){const r=Ae(k.products,i.sp);M.sheet={kind:"stock",pid:i.sp,v:{type:"in",qty:"",date:ve(),note:"",min:r&&A(r.minQty,0)?Ee(r.minQty):""},msg:""}}else if(i.smt)M.sheet&&(M.sheet.v.type=i.smt);else if(i.sa){if(i.sa==="close")M.sheet=null;else if(i.sa==="save")CR(t);else if(i.sa==="ocopy"){const r=AR();return r&&(ue.copy("Λίστα παραγγελίας ("+cs(ve())+`)

`+r),t("Η λίστα αντιγράφηκε, ανά προμηθευτή.")),!0}}else if(i.na){const r=i.id&&Ae(k.needs,i.id);if(i.na==="close")M.sheet=null;else if(i.na==="new")M.sheet={kind:"need",v:{title:"",qty:"",notes:""},msg:""};else if(i.na==="edit"&&r&&wc(r))M.sheet={kind:"need",v:{id:r.id,title:r.title||"",qty:r.qty||"",notes:r.notes||""},msg:""};else if(i.na==="save")NR(t);else if(i.na==="done"&&r&&!Te()){const a=!r.done,o=Date.now();Ht("needs",r.id,{done:a,doneAt:a?o:void 0,upd:o,dirty:!0}),t(a?"Σημειώθηκε ως παραγγελμένο.":"Ξαναμπήκε στη λίστα.")}else if(i.na==="gone"&&r&&wc(r))Ht("needs",r.id,{gone:!0,upd:Date.now(),dirty:!0}),t("Αφαιρέθηκε: "+r.title,{label:"Αναίρεση",fn:()=>{Ht("needs",r.id,{gone:!1,msId:"",upd:Date.now(),dirty:!0}),e()}});else if(i.na==="copy"){const a=k.needs.filter(o=>!o.gone&&!o.done).sort((o,l)=>(o.ts||0)-(l.ts||0)).map(o=>"• "+o.title+(o.qty?" × "+o.qty:"")+(o.notes?" ("+o.notes+")":"")).join(`
`);return a&&(ue.copy(a),t("Η λίστα αντιγράφηκε.")),!0}}else if(i.ie){const r=Ae(k.quotes,i.ie);if(r){const a=Fs(r);M.sheet={kind:"inst",id:r.id,v:{date:a.date||"",nw:!!a.nw,months:String(A(a.months,Hb(r))),mt:A(a.mt,0),mtp:a.mtp?Ee(a.mtp):""},msg:""}}}else i.imt!==void 0?M.sheet&&(M.sheet.v.mt=+i.imt):i.ia&&(i.ia==="close"?M.sheet=null:i.ia==="save"&&LR(t));return e(),!0}function UR(n,e){const t=n.dataset,s=i=>{e();const r=document.getElementById(i);r&&(r.focus(),r.setSelectionRange(r.value.length,r.value.length))};return"stq"in t?(M.stQ=n.value,s("stq"),!0):"inq"in t?(M.inQ=n.value,s("inq"),!0):t.wf&&M.f?(M.f.v[t.wf]=n.type==="checkbox"?n.checked:n.value,M.f.msg="",!0):t.nf&&M.sheet?(M.sheet.v[t.nf]=n.value,!0):t.sf&&M.sheet?(M.sheet.v[t.sf]=n.value,!0):t.if&&M.sheet?(M.sheet.v[t.if]=n.value,!0):!1}function qR(n,e){const t=n.dataset;if("stall"in t)return M.stAll=n.checked,e(),!0;if(t.wf&&M.f){if(M.f.v[t.wf]=n.type==="checkbox"?n.checked:n.value,t.wf==="empId"&&!M.f.v.id&&M.f.kind==="work"){const s=Ae(k.emps,n.value);s&&(M.f.v.rate=Ee(s.rate||0))}return e(),!0}return t.sf&&M.sheet?(M.sheet.v[t.sf]=n.value,e(),!0):t.if&&M.sheet?(t.if==="war"?M.sheet.v.nw=!n.checked:M.sheet.v[t.if]=n.value,e(),!0):!1}const Bt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),jR=n=>String(Math.round(A(n)*100)/100).replace(".",","),ls=(n,e)=>(n||[]).find(t=>t.id===e),BR=["ean_13","ean_8","upc_a","upc_e","EAN_13","EAN_8","UPC_A","UPC_E"],W={stream:null,det:null,zx:null,t:0,ref:"",label:"",last:"",lastT:0,lastDup:"",added:[],track:null,torch:!1,qid:""},kh=()=>!!W.stream||!!document.getElementById("scan-ov"),Jm=n=>!(n&&n.war&&n.war.on===!1),WR=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(A(e.m,0))):A((se()||{}).warrantyMonths,24)},zR=n=>n.install||{date:n.statusDate||"",months:Jm(n)?WR(n):0,serials:"",nw:!Jm(n)};function Jb(n){const e=[],t={};return(n.lines||[]).forEach((s,i)=>{const r=s.pid?"p:"+s.pid:"l:"+i;if(t[r]){t[r].qty+=A(s.qty,0);return}t[r]={ref:r,label:s.desc||"(χωρίς περιγραφή)",qty:A(s.qty,0)},e.push(t[r])}),e}const Sh=(n,e)=>{const t=Jb(n).find(s=>s.ref===e);return t?t.label:""},Jl=(n,e)=>We("qlog",{id:Qe(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:e});function Ic(n,e){n.install?fc("quotes",n.id,"install.sns",e):fc("quotes",n.id,"install",{...zR(n),sns:e})}const Yb=n=>String(n||"").split(/[\r\n]+/)[0].trim().replace(/^(S\/?N|SN|SER(IAL)?(\s*NO\.?)?)\s*[:#.\-]?\s*/i,"").replace(/\s+/g," ").trim(),GR=n=>/^([0-9A-F]{2}[:\-]?){5}[0-9A-F]{2}$/i.test(n);function Xb(n,e,t,s,i){if(!i&&BR.includes(s))return"skip";const r=i?String(t||"").trim():Yb(t);if(!r||r.length<3||r.length>64||!i&&(GR(r)||/^https?:\/\//i.test(r)))return"skip";const a=(n.install&&n.install.sns||[]).slice(),o=r.toUpperCase();if(a.some(u=>String(u.sn).toUpperCase()===o))return"dup";const l={id:Qe(),sn:r,ref:e,item:Sh(n,e),name:"",ts:Date.now()};return a.push(l),W.added.push(l.id),Ic(n,a),"added"}function KR(n,e,t){const s=ls(k.quotes,n);if(!s)return t(e("Σειριακοί","",'<a class="ib" href="#/inst">←</a>'),'<div class="empty">Δεν βρέθηκε</div>',"menu");const i=s.install&&s.install.sns||[],r=Jb(s),a={};r.forEach(l=>a[l.ref]=1);const o=i.filter(l=>!a[l.ref]);return o.length&&r.push({ref:"__other",label:"Άλλα (προϊόντα που δεν υπάρχουν πια στην προσφορά)",qty:0}),t(e("Σειριακοί",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,'<a class="ib" href="#/inst">←</a>'),'<div class="hint">Πάτα «📷 Σάρωση» στο προϊόν και σκάναρε τα barcode ή QR των συσκευών. Δίπλα σε κάθε σειριακό γράψε όνομα θέσης (π.χ. «Κάμερα εισόδου»).</div>'+r.map(l=>{const u=l.ref==="__other"?o:i.filter(h=>h.ref===l.ref);return`<div class="card pad sn-g"><div class="sn-h"><div><b>${Bt(l.label)}</b> <span class="muted">(${u.length}${l.qty?" / "+jR(l.qty):""})</span></div>${l.ref==="__other"?"":`<button class="btn b1 sm" data-sn-scan="${Bt(l.ref)}">📷 Σάρωση</button>`}</div>
      ${u.map(h=>`<div class="sn-row"><code>${Bt(h.sn)}</code><input class="in" data-sn-name="${Bt(h.id)}" value="${Bt(h.name||"")}" placeholder="Όνομα / θέση"><button class="ib dk" data-sn-del="${Bt(h.id)}" aria-label="Διαγραφή">🗑️</button></div>`).join("")}
      ${l.ref==="__other"?"":`<div class="sn-add"><input class="in" data-sn-add="${Bt(l.ref)}" placeholder="ή πληκτρολόγησε σειριακό" autocapitalize="characters" spellcheck="false"><button class="btn b2 sm" data-sn-addb="${Bt(l.ref)}">＋</button></div>`}</div>`}).join("")||'<div class="empty">Η προσφορά δεν έχει γραμμές.</div>',"menu")}let Ym=null;const HR=()=>Ym||(Ym=zn(()=>import("./zxing-CRxvinjV.js"),[]).then(n=>new Function(n.default+"; return ZXing;")()));function Zb(){try{const n=window.AudioContext||window.webkitAudioContext;W.ac=W.ac||new n;const e=W.ac.createOscillator(),t=W.ac.createGain();e.frequency.value=1250,t.gain.value=.12,e.connect(t),t.connect(W.ac.destination),e.start(),e.stop(W.ac.currentTime+.09)}catch{}}function QR(){let n=document.getElementById("scan-ov");return n||(n=document.createElement("div"),n.id="scan-ov",document.body.appendChild(n)),n}function Ah(){const n=ls(k.quotes,W.qid),e=n?(n.install&&n.install.sns||[]).filter(i=>i.ref===W.ref).length:0,t=document.getElementById("sc-count");t&&(t.textContent=`Σκαναρισμένοι σε αυτό το προϊόν: ${e} · σε αυτή τη σάρωση: ${W.added.length}`);const s=document.getElementById("sc-undo");s&&(s.disabled=!W.added.length)}const JR=n=>String(n.code||"").split(/[\s,;]+/).filter(Boolean).map(e=>e.toUpperCase()),YR=n=>{const e=String(n).trim().toUpperCase();return e&&(k.products.find(t=>JR(t).includes(e))||k.products.find(t=>String(t.model||"").trim().toUpperCase()===e))||null};function e_(n){const e=String(n||"").split(/[\r\n]+/)[0].trim();if(!e||e.length>64)return;const t=Date.now();if(e===W.last&&t-W.lastT<1800)return;W.last=e,W.lastT=t;const s=YR(e),i=document.getElementById("sc-last"),r=document.getElementById("sc-flash");if(s){try{navigator.vibrate&&navigator.vibrate(80)}catch{}Zb();const a=W.rerender;Ph(),location.hash.startsWith("#/stock")?(Qb(s.id),a&&a()):(M.openNext=s.id,location.hash="#/stock")}else r&&(r.className="dup",setTimeout(()=>r.className="",350)),i&&(i.innerHTML="❓ Άγνωστος κωδικός <b>"+Bt(e)+"</b>")}function Xm(n,e,t){if(W.mode==="find")return e_(n);const s=ls(k.quotes,W.qid);if(!s)return;const i=Date.now(),r=Yb(n);if(r===W.last&&i-W.lastT<2500)return;const a=Xb(s,W.ref,n,e,!1);if(a==="skip")return;W.last=r,W.lastT=i;const o=document.getElementById("sc-last"),l=document.getElementById("sc-flash"),u=h=>{l&&(l.className=h,setTimeout(()=>l.className="",350))};if(a==="added"){W.lastDup=r;try{navigator.vibrate&&navigator.vibrate(90)}catch{}Zb(),u("ok"),o&&(o.innerHTML="✅ <b>"+Bt(r)+"</b>")}else r!==W.lastDup&&(W.lastDup=r,u("dup"),o&&(o.innerHTML="Υπάρχει ήδη: <b>"+Bt(r)+"</b>"));Ah()}async function Zm(n,e,t,s){const i=n==="",r=ls(k.quotes,n);if(!r&&!i)return;if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return t("Η κάμερα δεν είναι διαθέσιμη εδώ.");Object.assign(W,{mode:i?"find":"sn",qid:n,ref:e,label:i?"Σάρωση προϊόντος":Sh(r,e),added:[],last:"",lastT:0,lastDup:"",rerender:s});const a=QR();a.innerHTML=`<div class="sc-top"><b id="sc-title">${Bt(W.label)}</b><button class="ib dk" data-sc="close">✕</button></div><video id="sc-video" playsinline muted></video><div id="sc-flash"></div>
  <div class="sc-bot"><div id="sc-last">${i?"Σκάναρε το barcode ενός προϊόντος για να δεις το απόθεμά του.":"Στρέψε την κάμερα στο barcode ή στο QR του σειριακού."}</div><div id="sc-count"></div>
  <div class="sc-btns">${i?"":'<button class="btn b2" data-sc="undo" id="sc-undo" disabled>↶ Αναίρεση</button>'}<button class="btn b2" data-sc="torch" id="sc-torch" hidden>🔦</button><button class="btn b1" data-sc="close">Τέλος</button></div></div>`,a.onclick=o=>t_(o.target,s,t),Ah();try{const o=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920},height:{ideal:1080}},audio:!1});if(!document.getElementById("scan-ov")){o.getTracks().forEach(h=>h.stop());return}W.stream=o,W.track=o.getVideoTracks()[0];const l=document.getElementById("sc-video");l.srcObject=o,l.muted=!0,await l.play();try{const h=W.track.getCapabilities&&W.track.getCapabilities();h&&h.torch&&(document.getElementById("sc-torch").hidden=!1)}catch{}let u=!1;if("BarcodeDetector"in window)try{const h=(await Promise.race([BarcodeDetector.getSupportedFormats(),new Promise((p,m)=>setTimeout(()=>m(1),1500))])).filter(p=>p!=="unknown");if(h.length){W.det=new BarcodeDetector({formats:h}),u=!0;const p=()=>{!W.stream||!W.det||W.det.detect(l).then(m=>(m||[]).forEach(w=>Xm(w.rawValue,w.format,t)),()=>{}).then(()=>{W.stream&&(W.t=setTimeout(p,160))})};p()}}catch{}if(!u){const h=await HR();if(!W.stream)return;W.zx=new h.BrowserMultiFormatReader,l.srcObject=null,W.zx.decodeFromStream(W.stream,l,p=>{if(p){let m="";try{m=h.BarcodeFormat[p.getBarcodeFormat()]||""}catch{}Xm(p.getText(),m,t)}})}}catch(o){Ph(),t(o&&o.name==="NotAllowedError"?"Δεν δόθηκε άδεια για την κάμερα. Δώσ' την από τις ρυθμίσεις του κινητού.":"Δεν άνοιξε η κάμερα.")}}function Ph(){if(clearTimeout(W.t),W.det=null,W.zx){try{W.zx.reset()}catch{}W.zx=null}W.stream&&(W.stream.getTracks().forEach(e=>e.stop()),W.stream=null),W.track=null,W.torch=!1;const n=document.getElementById("scan-ov");n&&n.remove()}function t_(n,e,t){const s=n.closest("[data-sn-scan],[data-sn-del],[data-sn-addb],[data-sc],[data-bcscan]");if(!s)return!1;if(s.dataset.bcscan!==void 0)return Zm("","",t,e),!0;const i=s.dataset,r=location.hash.replace(/^#\//,"").split("/");if(i.sc){if(i.sc==="close"){const o=ls(k.quotes,W.qid),l=W.added.length;Ph(),o&&l&&W.mode!=="find"&&(Jl(o,"Σάρωση σειριακών: "+l+" για «"+W.label+"»"),t("Προστέθηκαν "+l+" σειριακοί.")),e()}else if(i.sc==="undo"){const o=ls(k.quotes,W.qid);if(o&&W.added.length){const l=W.added.pop();Ic(o,(o.install&&o.install.sns||[]).filter(u=>u.id!==l)),W.last="",Ah()}}else i.sc==="torch"&&W.track&&(W.torch=!W.torch,W.track.applyConstraints({advanced:[{torch:W.torch}]}).catch(()=>W.torch=!1));return!0}const a=ls(k.quotes,decodeURIComponent(r[1]||""));if(!a)return!0;if(i.snScan)Zm(a.id,i.snScan,t,e);else if(i.snDel){const o=(a.install&&a.install.sns||[]).find(l=>l.id===i.snDel);o&&confirm("Διαγραφή του σειριακού "+o.sn+";")&&(Ic(a,a.install.sns.filter(l=>l.id!==i.snDel)),Jl(a,"Διαγραφή σειριακού "+o.sn),e())}else if(i.snAddb){const o=document.querySelector(`[data-sn-add="${CSS.escape(i.snAddb)}"]`),l=o&&o.value,u=Xb(a,i.snAddb,l,"",!0);u==="dup"?t("Αυτός ο σειριακός υπάρχει ήδη."):u==="skip"?t("Γράψε έναν σειριακό αριθμό."):(Jl(a,"Σειριακός "+String(l).trim()+" ("+Sh(a,i.snAddb)+")"),e())}return!0}function XR(n){if(!n.dataset.snName)return!1;const e=ls(k.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));if(!e||!e.install)return!0;const t=(e.install.sns||[]).map(s=>s.id===n.dataset.snName?{...s,name:n.value.trim()}:s);return Ic(e,t),!0}const Mt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Ve={list:null,loading:!1,area:"",open:"",msg:""},ZR={create:"➕",edit:"✏️",delete:"🗑️",web:"🌐"},e$={create:"Νέα καταχώριση",edit:"Αλλαγή",delete:"Διαγραφή",web:"Ιστοσελίδα"},t$={name:"Όνομα",model:"Μοντέλο",cost:"Κόστος",margin:"Κέρδος %",marginEur:"Κέρδος €",title:"Τίτλος",date:"Ημερομηνία",amount:"Ποσό",note:"Σημείωση",phone:"Τηλέφωνο",email:"Email",status:"Κατάσταση",done:"Ολοκληρώθηκε",qty:"Ποσότητα",price:"Τιμή",subject:"Θέμα",number:"Αριθμός",desc:"Περιγραφή",cat:"Κατηγορία",code:"Barcode",lines:"Γραμμές",customer:"Πελάτης",notes:"Σημειώσεις",links:"Προμηθευτές",vat:"ΦΠΑ",next:"Επόμενος αριθμός",terms:"Όροι",install:"Εγκατάσταση",time:"Ώρα",rems:"Υπενθυμίσεις"},n$=n=>new Date(n).toLocaleString("el-GR",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"});async function zu(n){if(!Ve.loading){Ve.loading=!0,n();try{Ve.list=await _A()}catch{Ve.list=[]}Ve.loading=!1,n()}}const Yl=n=>n.area==="set"?"Ρυθμίσεις":n.area==="web"?"Ιστοσελίδα":vA[n.area]||n.area;function s$(n,e){const t=(Ve.list||[]).filter(i=>!Ve.area||i.area===Ve.area),s=[...new Set((Ve.list||[]).map(i=>i.area))];return e(n("Ιστορικό","Τι άλλαξε και πότε",'<a class="ib" href="#/menu">←</a>'),`<div class="chips wrap" style="padding:0 2px"><button data-h-area="" class="${Ve.area?"":"on"}">Όλα</button>${s.map(i=>`<button data-h-area="${Mt(i)}" class="${Ve.area===i?"on":""}">${Mt(Yl({area:i}))}</button>`).join("")}</div>
    ${Ve.msg?`<div class="upd">${Mt(Ve.msg)}</div>`:""}
    <div class="card">${Ve.loading&&!Ve.list?'<div class="empty">Φόρτωση…</div>':t.map(i=>{const r=Ve.open===i.id,a=i.act==="delete"&&i.before&&!(k[i.area]||[]).some(l=>l.id===i.rid),o=i.act==="edit"&&i.old&&i.rid&&k[i.area];return`<div class="item" data-h-open="${Mt(i.id)}"><div class="t"><b>${ZR[i.act]||"•"} ${Mt(i.name||Yl(i))}</b><span>${Mt(e$[i.act]||i.act)} · ${Mt(Yl(i))} · ${n$(i.ts)}${i.user?" · "+Mt(i.user.split("@")[0]):""}</span></div>
      ${r?`<div class="sm" style="margin-top:6px">${(i.diff||[]).map(l=>`<div class="fld"><label>${Mt(t$[l.k]||l.k)}</label><div class="v">${Mt(l.o)} → <b>${Mt(l.n)}</b></div></div>`).join("")||`<div class="muted small">${i.act==="delete"?"Η εγγραφή διαγράφηκε.":""}</div>`}
        ${a?`<button class="btn b1" data-h-restore="${Mt(i.id)}" style="margin-top:6px">↩ Επαναφορά διαγραμμένου</button>`:""}${o&&i.diff&&i.diff.length?`<button class="btn b2" data-h-undo="${Mt(i.id)}" style="margin-top:6px">↩ Αναίρεση αυτής της αλλαγής</button>`:""}</div>`:""}</div>`}).join("")||'<div class="empty">Δεν υπάρχουν καταγραφές ακόμα.</div>'}</div>
    <div class="muted small" style="padding:0 6px 10px">Καταγράφονται οι αλλαγές που γίνονται από αυτή την εφαρμογή.</div>`,"menu")}function i$(n,e,t){const s=n.closest("[data-h-area],[data-h-open],[data-h-restore],[data-h-undo]");if(!s)return!1;const i=s.dataset,r=a=>(Ve.list||[]).find(o=>o.id===a);if(i.hArea!==void 0)Ve.area=i.hArea;else if(i.hRestore){const a=r(i.hRestore);if(a&&a.before&&!(k[a.area]||[]).some(o=>o.id===a.rid))return We(a.area,a.before),Ve.msg="Η εγγραφή επανήλθε.",t(Ve.msg),zu(e),!0}else if(i.hUndo){const a=r(i.hUndo);if(a&&a.old){const o={};return Object.keys(a.old).forEach(l=>o[l]=a.old[l]===null?void 0:a.old[l]),Ht(a.area,a.rid,o),Ve.msg="Η αλλαγή αναιρέθηκε.",t(Ve.msg),zu(e),!0}}else i.hOpen&&(Ve.open=Ve.open===i.hOpen?"":i.hOpen);return e(),!0}const Ec=(n=10)=>{try{navigator.vibrate&&navigator.vibrate(n)}catch{}};let Xl=!1;const yo=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function r$({title:n,text:e="",ok:t="Ναι",cancel:s="Άκυρο",danger:i=!1}){return new Promise(r=>{const a=document.createElement("div");a.id="ask-ov",a.innerHTML=`<div class="ask-box"><b>${yo(n)}</b>${e?`<p>${yo(e)}</p>`:""}<div class="ask-btns"><button class="btn b2" data-ak="0">${yo(s)}</button><button class="btn ${i?"del":"b1"}" data-ak="1">${yo(t)}</button></div></div>`;const o=l=>{a.remove(),Ec(l?i?[30,40,30]:18:8),r(l)};a.addEventListener("click",l=>{const u=l.target.closest("[data-ak]");u?o(u.dataset.ak==="1"):l.target===a&&o(!1)}),document.body.appendChild(a),Ec(15)})}const a$=[['[data-act="del"]',"Αφαίρεση γραμμής","Να αφαιρεθεί η γραμμή από την προσφορά;","Αφαίρεση",!0],["[data-st-bdel]","Αφαίρεση λογαριασμού","Να αφαιρεθεί ο τραπεζικός λογαριασμός από τη λίστα;","Αφαίρεση",!0],["[data-cat-ldel]","Αφαίρεση προμηθευτή","Να αφαιρεθεί ο προμηθευτής από το προϊόν;","Αφαίρεση",!0],["[data-cat-imgdel]","Αφαίρεση φωτογραφίας","Να αφαιρεθεί η φωτογραφία του προϊόντος;","Αφαίρεση",!0],["[data-web-ldel]","Αφαίρεση λογοτύπου","Να αφαιρεθεί το λογότυπο του συνεργάτη;","Αφαίρεση",!0],["[data-web-del]","Αφαίρεση","Να αφαιρεθεί αυτή η καταχώριση από την ιστοσελίδα (θα φύγει όταν δημοσιεύσεις);","Αφαίρεση",!0],["[data-web-save]","Δημοσίευση","Να δημοσιευτούν οι αλλαγές στην ιστοσελίδα;","Δημοσίευση"],["[data-web-asave]","Αποθήκευση άρθρου","Το άρθρο θα φανεί αμέσως στην ιστοσελίδα. Να αποθηκευτεί;","Αποθήκευση"],["[data-web-atog]","Εμφάνιση/απόκρυψη","Να αλλάξει η εμφάνιση του άρθρου στην ιστοσελίδα;","Ναι"],['[data-act="save"]',"Αποθήκευση προσφοράς","Να αποθηκευτεί η προσφορά;","Αποθήκευση"],['[data-bact="save"]',"Αποθήκευση","Να αποθηκευτεί η καταχώριση στα Λογιστικά;","Αποθήκευση"],['[data-wa="save"]',"Αποθήκευση","Να αποθηκευτεί η καταχώριση μεροκάματου/πληρωμής;","Αποθήκευση"],['[data-sa="save"]',"Αποθήκευση","Να αποθηκευτεί η κίνηση αποθήκης;","Αποθήκευση"],['[data-na="save"]',"Αποθήκευση","Να αποθηκευτεί το εργαλείο στη λίστα;","Αποθήκευση"],['[data-ia="save"]',"Αποθήκευση","Να αποθηκευτούν τα στοιχεία της εγκατάστασης;","Αποθήκευση"],["[data-tsave]","Αποθήκευση εργασίας","Να αποθηκευτεί η εργασία;","Αποθήκευση"],["[data-st-save]","Αποθήκευση ρυθμίσεων","Να αποθηκευτούν οι αλλαγές στις ρυθμίσεις;","Αποθήκευση"],["[data-cat-save]","Αποθήκευση προϊόντος","Να αποθηκευτεί το προϊόν στον κατάλογο;","Αποθήκευση"],['[data-fa="save"]',"Αποθήκευση πελάτη","Να αποθηκευτούν τα στοιχεία του πελάτη;","Αποθήκευση"]];function o$(){document.addEventListener("click",e=>{if(!(Xl||!e.target.closest))for(const[t,s,i,r,a]of a$){const o=e.target.closest(t);if(!(!o||o.disabled)){e.stopImmediatePropagation(),e.preventDefault(),r$({title:s,text:i,ok:r,danger:a}).then(l=>{if(l){Xl=!0;try{o.click()}finally{Xl=!1}}});return}}},!0);const n='button, a[href], [role="button"], .item, .mi, .acc-h, label.btn, .prow, .chips button, [data-pk]';document.addEventListener("pointerdown",e=>{const t=e.target.closest&&e.target.closest(n);!t||t.disabled||t.closest("#ask-ov")||t.closest("#pinlock")||(Ec(10),t.classList.add("tapd"),setTimeout(()=>t.classList.remove("tapd"),180))},{passive:!0,capture:!0})}const ja="tm.app.pin",vo=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Vt=()=>{try{return JSON.parse(localStorage.getItem(ja)||"null")}catch{return null}},bo=n=>{try{return localStorage.setItem(ja,JSON.stringify(n)),!0}catch{return!1}},Vs=()=>{const n=Vt();return!!(n&&n.hash&&window.crypto&&crypto.subtle)},n_=n=>[...new Uint8Array(n)].map(e=>("0"+e.toString(16)).slice(-2)).join("");async function s_(n,e){const t=new TextEncoder,s=await crypto.subtle.importKey("raw",t.encode(n),"PBKDF2",!1,["deriveBits"]);return n_(await crypto.subtle.deriveBits({name:"PBKDF2",salt:t.encode(e),iterations:15e4,hash:"SHA-256"},s,256))}let Xs={logout:()=>{},buzz:()=>{}};const _e={locked:!1,entry:"",fails:0,waitUntil:0,hidAt:0,busy:!1},c$=()=>_e.locked,be={msg:"",ok:"",bioOk:!1,after:null,onStart:null,p1:"",p2:""};function Ei(n,e){const t=Vt(),s=t&&t.len||4,i=_e.entry.length,r=document.getElementById("pinlock");if(!r)return;r.querySelector(".pl-dots").innerHTML=Array.from({length:Math.max(s,i)},(o,l)=>`<i class="${l<i?"on":""}"></i>`).join("");const a=r.querySelector(".pl-msg");a.textContent=n||"",a.className="pl-msg"+(e?" bad":""),r.querySelector(".pl-bio").hidden=!(t&&t.bio)}function l$(){let n=document.getElementById("pinlock");return n||(n=document.createElement("div"),n.id="pinlock",n.innerHTML=`<div class="pl-in"><div class="pl-lg">🔒</div><b>TechMate</b><div class="pl-sub">Γράψε το PIN σου</div><div class="pl-dots"></div><div class="pl-msg"></div>
  <div class="pl-pad">${[1,2,3,4,5,6,7,8,9].map(e=>`<button data-pk="${e}">${e}</button>`).join("")}<button class="pl-bio" data-pk="bio" aria-label="Δακτυλικό">👆</button><button data-pk="0">0</button><button data-pk="del" aria-label="Σβήσιμο">⌫</button></div>
  <button class="pl-forgot" data-pk="forgot">Ξέχασα το PIN</button></div>`,n.addEventListener("click",e=>{const t=e.target.closest("[data-pk]");t&&(Xs.buzz(8),d$(t.dataset.pk))}),document.body.appendChild(n),n)}function Ti(){if(!Vs()||_e.locked)return;_e.locked=!0,_e.entry="",_e.fails=0;const n=l$();n.hidden=!1,document.documentElement.classList.add("pin-locked"),Ei("");try{document.activeElement&&document.activeElement.blur&&document.activeElement.blur()}catch{}const e=Vt();e&&e.bio&&setTimeout(i_,300)}function Tc(){_e.locked=!1,_e.entry="",_e.fails=0;const n=document.getElementById("pinlock");n&&(n.hidden=!0),document.documentElement.classList.remove("pin-locked"),Xs.buzz([15,40,15])}async function i_(){const n=Vt();if(!_e.locked||!n||!n.bio||_e.busy)return;_e.busy=!0;const e=await ue.bioAuth();_e.busy=!1,e&&e.ok&&Tc()}function u$(){if(confirm("Αποσύνδεση και διαγραφή του PIN από αυτή τη συσκευή; Θα ξανασυνδεθείς με email και κωδικό.")){try{localStorage.removeItem(ja)}catch{}Tc(),Xs.logout()}}async function d$(n){if(!_e.locked)return;if(n==="bio")return i_();if(n==="forgot")return u$();if(Date.now()<_e.waitUntil)return Ei("Περίμενε "+Math.ceil((_e.waitUntil-Date.now())/1e3)+"΄΄ και ξαναδοκίμασε.",!0);if(n==="del")return _e.entry=_e.entry.slice(0,-1),Ei("");if(!/^\d$/.test(n)||_e.entry.length>=8)return;_e.entry+=n,Ei("");const e=Vt();if(_e.entry.length!==(e&&e.len||4))return;if(await s_(_e.entry,e.salt)===e.hash)return Tc();if(_e.fails++,_e.entry="",Xs.buzz([60,40,60]),_e.fails>=10){Ei("Πολλές λάθος προσπάθειες. Αποσύνδεση…",!0),setTimeout(()=>{try{localStorage.removeItem(ja)}catch{}Tc(),Xs.logout()},1200);return}_e.fails%5===0&&(_e.waitUntil=Date.now()+3e4),Ei("Λάθος PIN"+(_e.fails>=5?" ("+_e.fails+"/10)":"")+".",!0)}function h$(n){Xs={...Xs,...n},Vs()&&Vt().onStart!==!1&&Ti(),document.addEventListener("visibilitychange",()=>{if(!Vs())return;const t=Number(Vt().after);t<0||(document.hidden?(_e.hidAt=Date.now(),t===0&&Ti()):_e.hidAt&&Date.now()-_e.hidAt>=t*6e4&&Ti())}),ue.on("home",()=>{Vs()&&Number(Vt().after)===0&&Ti()});let e=Date.now();["pointerdown","keydown","touchstart","scroll"].forEach(t=>document.addEventListener(t,()=>e=Date.now(),{capture:!0,passive:!0})),setInterval(()=>{if(!Vs()||_e.locked||document.hidden)return;const t=Number(Vt().after);t<0||Date.now()-e>=(t>0?t:5)*6e4&&Ti()},15e3)}const f$=[["0","Αμέσως μόλις φύγω από την εφαρμογή"],["1","Μετά από 1 λεπτό"],["2","Μετά από 2 λεπτά"],["5","Μετά από 5 λεπτά"],["10","Μετά από 10 λεπτά"],["15","Μετά από 15 λεπτά"],["30","Μετά από 30 λεπτά"],["-1","Μόνο όταν πατήσω «Κλείδωμα τώρα»"]],p$=()=>Vs()?"Ενεργό"+(Vt().bio?" · δακτυλικό":""):"Ανενεργό";async function m$(n){be.bioOk=!!(await ue.bioStatus()||{}).available,n()}function g$(){const n=Vt(),e=Vs(),t=n?String(n.after):"5",s=!n||n.onStart!==!1;return`<div class="muted small" style="margin-bottom:6px">${e?"✅ Ενεργό σε αυτή τη συσκευή.":"Ανενεργό."} Το PIN ζητείται όταν ανοίγεις την εφαρμογή και όταν επιστρέφεις σε αυτήν. Δεν αποθηκεύεται πουθενά· κρατιέται μόνο κρυπτογραφημένο σε αυτό το κινητό.</div>
  <label class="f">${e?"Νέο PIN":"PIN"} (4–8 ψηφία)<input class="in" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password" data-lk="p1" value="${vo(be.p1)}"></label>
  <label class="f">Ξανά το PIN<input class="in" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password" data-lk="p2" value="${vo(be.p2)}"></label>
  <label class="f">Κλείδωμα όταν η εφαρμογή μένει στο παρασκήνιο<select class="in" data-lk="after">${f$.map(([i,r])=>`<option value="${i}"${i===(be.after??t)?" selected":""}>${r}</option>`).join("")}</select></label>
  <label class="chk"><input type="checkbox" data-lk="onStart" ${be.onStart??s?"checked":""}> Ζήτα PIN κάθε φορά που ανοίγει η εφαρμογή</label>
  ${be.msg?`<div class="err box">${vo(be.msg)}</div>`:""}${be.ok?`<div class="upd">${vo(be.ok)}</div>`:""}
  <button class="btn b1 wide" data-lk-set>🔒 ${e?"Αλλαγή PIN / ρυθμίσεων":"Ενεργοποίηση PIN"}</button>
  ${e?be.bioOk?n.bio?'<button class="btn b2 wide" data-lk-bio="off" style="margin-top:6px">👆 Απενεργοποίηση δακτυλικού</button>':'<button class="btn b2 wide" data-lk-bio="on" style="margin-top:6px">👆 Ενεργοποίηση δακτυλικού</button>':'<div class="muted small" style="margin-top:6px">Το δακτυλικό δεν είναι διαθέσιμο (δεν υπάρχει καταχωρημένο δακτυλικό στο κινητό).</div>':""}
  ${e?'<button class="btn b2 wide" data-lk-now style="margin-top:6px">🔐 Κλείδωμα τώρα</button><button class="btn b2 wide del" data-lk-off style="margin-top:6px">Απενεργοποίηση PIN</button>':""}`}function y$(n){const e=n.dataset.lk;return e?(e==="onStart"?be.onStart=n.checked:e==="after"?be.after=n.value:be[e]=n.value,be.msg="",be.ok="",!0):!1}function v$(n,e,t){const s=n.closest("[data-lk-set],[data-lk-bio],[data-lk-now],[data-lk-off]");if(!s)return!1;const i=s.dataset;return(async()=>{if(be.msg="",be.ok="",i.lkSet!==void 0){const r=Vt(),a=be.p1.trim(),o=be.p2.trim(),l=be.after??(r?String(r.after):"5"),u=be.onStart??(!r||r.onStart!==!1);if(!a&&!o&&r)r.after=Number(l),r.onStart=u,bo(r),be.ok="Οι ρυθμίσεις αποθηκεύτηκαν.";else if(!/^\d{4,8}$/.test(a))be.msg="Το PIN πρέπει να είναι 4 έως 8 ψηφία.";else if(a!==o)be.msg="Τα δύο PIN δεν είναι ίδια.";else if(!(window.crypto&&crypto.subtle))be.msg="Δεν υποστηρίζεται κλείδωμα σε αυτή τη συσκευή.";else{const h=n_(crypto.getRandomValues(new Uint8Array(16))),p=await s_(a,h),m={hash:p,salt:h,len:a.length,after:Number(l),onStart:u};r&&r.bio&&(m.bio=!0),bo(m)?(be.p1="",be.p2="",be.ok="Το PIN ενεργοποιήθηκε σε αυτή τη συσκευή.",t("Το PIN ενεργοποιήθηκε.")):be.msg="Δεν αποθηκεύτηκε το PIN."}}else if(i.lkBio==="on"){const r=await ue.bioAuth();if(r&&r.ok){const a=Vt();a.bio=!0,bo(a),be.ok="Το δακτυλικό ενεργοποιήθηκε. Το PIN μένει πάντα εφεδρεία."}else be.msg="Δεν ενεργοποιήθηκε το δακτυλικό"+(r&&r.error?" ("+r.error+")":"")+"."}else if(i.lkBio==="off"){const r=Vt();delete r.bio,bo(r),be.ok="Το δακτυλικό απενεργοποιήθηκε. Μένει το PIN."}else if(i.lkNow!==void 0)Ti();else if(i.lkOff!==void 0){try{localStorage.removeItem(ja)}catch{}be.ok="Το PIN απενεργοποιήθηκε σε αυτή τη συσκευή."}e()})(),!0}const b$="TechMate · Κάμερες, δίκτυα και έξυπνες εγκαταστάσεις",_$="TechMate – Powered by Smart Electric. Εγκατάσταση καμερών ασφαλείας, WiFi και δικτύων, συναγερμών και έξυπνων λύσεων για σπίτια και επιχειρήσεις.",w$="Ασφάλεια · Δίκτυα · Έξυπνες λύσεις",I$="Τεχνολογία που",E$="δουλεύει",T$="εγκατάσταση που κρατάει.",k$="Κάμερες ασφαλείας, WiFi και δίκτυα, συναγερμοί και έξυπνο σπίτι για κατοικίες και επιχειρήσεις. Μελέτη, εγκατάσταση και υποστήριξη από ένα συνεργείο.",S$="Smart Electric",A$=[{ic:"📷",t:"Δωρεάν αυτοψία & προσφορά",s:"Live προσφορά που τη βλέπετε online"},{ic:"🛡️",t:"Εγγύηση εγκατάστασης",s:"24 μήνες σε εξοπλισμό και εργασία"},{ic:"📱",t:"Προβολή από το κινητό",s:"Ρύθμιση εφαρμογών και απομακρυσμένης πρόσβασης"},{ic:"🔧",t:"Υποστήριξη μετά την εγκατάσταση",s:"Συντήρηση και άμεση εξυπηρέτηση"},{ic:"🔌",t:"Προσεκτική διέλευση καλωδίων",s:"Κρυφές ή τακτοποιημένες διαδρομές, σε κανάλια και σωλήνες"},{ic:"🧹",t:"Χωρίς μερεμέτια",s:"Προστατεύουμε τον χώρο σας και τον αφήνουμε καθαρό"},{ic:"🏷️",t:"Επαγγελματικός εξοπλισμός",s:"Αξιόπιστα μοντέλα από κορυφαίους κατασκευαστές"},{ic:"🧰",t:"Επαγγελματικά εργαλεία",s:"Σωστές τερματίσεις, μετρήσεις και δοκιμή σε κάθε σημείο"},{ic:"🎓",t:"Παράδοση με εκπαίδευση",s:"Σας δείχνουμε τη χρήση και σας αφήνουμε τους κωδικούς"}],P$="Ό,τι χρειάζεστε, από ένα συνεργείο",R$="Επιλέγουμε τον σωστό εξοπλισμό για τον χώρο σας και τον εγκαθιστούμε καθαρά και σωστά.",$$=[{ic:"📷",t:"Κάμερες ασφαλείας (CCTV)",d:"IP κάμερες, καταγραφικά, νυχτερινή όραση, προβολή από το κινητό.",m:`## Τι προσέχουμε στην επιλογή μοντέλου

- **Νυχτερινή λήψη:** μοντέλα με υπέρυθρο φωτισμό και, όπου χρειάζεται, έγχρωμη εικόνα και τη νύχτα.
- **Έξυπνη ανίχνευση με AI:** διακρίνει άνθρωπο και όχημα, ώστε να έχετε λιγότερες άσκοπες ειδοποιήσεις από σκιές, ζώα ή βροχή.
- **Καθαρή εικόνα:** ανάλυση ανάλογη με τον χώρο και αυτό που θέλετε να φαίνεται, π.χ. είσοδος, αυλή, πινακίδες.
- **Αντοχή:** στεγανές κάμερες για εξωτερικούς χώρους, που αντέχουν στη βροχή και στη σκόνη.
- **Αρκετή αποθήκευση:** καταγραφικό και δίσκος για τις ημέρες καταγραφής που χρειάζεστε.
- **Στο κινητό:** ζωντανή εικόνα, αναπαραγωγή και ειδοποιήσεις από οπουδήποτε.

## Πώς δουλεύουμε

Επισκεπτόμαστε τον χώρο, προτείνουμε θέσεις και μοντέλα, κάνουμε προσφορά, εγκαθιστούμε με καθαρή καλωδίωση, ρυθμίζουμε και σας δείχνουμε πώς το χρησιμοποιείτε.`},{ic:"📶",t:"WiFi & δίκτυα",d:"Κάλυψη WiFi χωρίς νεκρά σημεία, access points, καλωδιώσεις, rack.",m:`## Τι περιλαμβάνει

- **Μελέτη χώρου:** τοποθετούμε τα access points εκεί που χρειάζεται, ώστε να μην υπάρχουν νεκρά σημεία.
- **Ενσύρματη σύνδεση:** τα access points συνδέονται με καλώδιο δικτύου, για σταθερή ταχύτητα.
- **Ξεχωριστό δίκτυο επισκεπτών**, ώστε οι φιλοξενούμενοι να μην έχουν πρόσβαση στα δικά σας συστήματα.
- **Καλωδίωση και rack:** τακτοποιημένα, με σήμανση και ευκολία στην επέκταση.
- **Ασφάλεια και ρυθμίσεις:** ισχυρούς κωδικούς και σωστές ρυθμίσεις του router.`},{ic:"🚨",t:"Συναγερμοί",d:"Ενσύρματα και ασύρματα συστήματα με ειδοποιήσεις στο κινητό.",m:`## Τι περιλαμβάνει

- **Ανιχνευτές κίνησης και ανοίγματος** στα σημεία που χρειάζονται, με σειρήνα.
- **Ειδοποιήσεις στο κινητό** όταν ενεργοποιείται ο συναγερμός.
- **Ενσύρματο ή ασύρματο σύστημα**, ανάλογα με το κτίριο και τον προϋπολογισμό σας.
- **Μπαταρία υποστήριξης**, ώστε να δουλεύει και σε διακοπή ρεύματος.
- **Σύνδεση με τις κάμερες**, όπου θέλετε να βλέπετε την εικόνα όταν χτυπήσει ο συναγερμός.`},{ic:"🌡️",t:"Αισθητήρες & ανιχνευτές",d:"Θερμοκρασία, υγρασία, φωτιά και καπνός, με ειδοποίηση στο κινητό.",m:`## Τι περιλαμβάνει

- **Αισθητήρες θερμοκρασίας και υγρασίας:** παρακολουθείτε από το κινητό τον χώρο σας, π.χ. αποθήκη, ψυγείο, κάβα, serverroom ή σπίτι που μένει κλειστό.
- **Ειδοποίηση όταν ξεπεραστούν τα όρια** που θα ορίσετε, π.χ. πολύ υψηλή θερμοκρασία ή υγρασία που ευνοεί μούχλα.
- **Ανιχνευτές καπνού και πυρκαγιάς:** ηχούν τοπικά και σας ειδοποιούν στο κινητό, ακόμη κι όταν λείπετε.
- **Σύνδεση με το σύστημα συναγερμού ή τους αυτοματισμούς**, όπου θέλετε να ενεργοποιείται σειρήνα ή σκηνή.
- **Ασύρματοι αισθητήρες με μπαταρία**, χωρίς μεγάλες παρεμβάσεις στον χώρο.
- **Ιστορικό μετρήσεων**, όπου το υποστηρίζει η εφαρμογή.`},{ic:"🚪",t:"Θυροτηλέφωνα & πρόσβαση",d:"Θυροτηλεόραση, κάρτες, κωδικοί και έλεγχος εισόδου.",m:`## Τι περιλαμβάνει

- **Θυροτηλεόραση:** βλέπετε ποιος είναι στην πόρτα, ακόμη και από το κινητό.
- **Πρόσβαση με κάρτα ή κωδικό**, για να μην χρειάζεστε κλειδιά.
- **Ηλεκτρικές κλειδαριές και ανοιχτήρια** για πόρτες και πύλες.
- **Δικαιώματα ανά άτομο:** προσθέτετε ή αφαιρείτε κάρτες όποτε χρειάζεται.`},{ic:"🏠",t:"Έξυπνο σπίτι",d:"Αυτοματισμοί φωτισμού, ρολών και κλιματισμού από το κινητό.",m:`## Τι περιλαμβάνει

- **Φωτισμός, ρολά και κλιματισμός** από το κινητό ή με χρονοπρογραμματισμό.
- **Σκηνές:** ένα πάτημα για «φεύγω» ή «βράδυ».
- **Φωνητικός έλεγχος**, όπου το υποστηρίζουν οι συσκευές.
- **Σταδιακή επέκταση:** ξεκινάτε από ό,τι χρειάζεστε και προσθέτετε αργότερα.`},{ic:"⚡",t:"Ηλεκτρολογικά",d:"Ηλεκτρολογικές εργασίες με τη Smart Electric.",m:`## Τι αναλαμβάνουμε

- **Νέες γραμμές και πίνακες** σε σπίτια και επαγγελματικούς χώρους.
- **Φωτισμός και πρίζες**, επεκτάσεις και αντικαταστάσεις.
- **Αποκατάσταση βλαβών.**
- **Σε συνεργασία με τη Smart Electric.**`}],C$="Συνεργαζόμαστε με κορυφαίους κατασκευαστές",D$="Τοποθετούμε αξιόπιστο εξοπλισμό από εταιρείες που ξέρουμε σε βάθος.",N$=[{t:"TP-Link",s:"Omada · δίκτυα & WiFi"},{t:"Hikvision",s:"Κάμερες & καταγραφικά"},{t:"Dahua",s:"Κάμερες & καταγραφικά"},{t:"Ubiquiti",s:"UniFi · δίκτυα & WiFi"},{t:"Ajax",s:"Συστήματα συναγερμού"}],x$="Δουλειές που έχουμε παραδώσει",V$="Μερικές από τις εγκαταστάσεις μας. Πατήστε σε μια φωτογραφία για να τη δείτε μεγάλη.",O$="Μικρό συνεργείο, μεγάλη φροντίδα",M$="Η TechMate είναι ομάδα τεχνικών με εμπειρία σε συστήματα ασφαλείας, δίκτυα και ηλεκτρολογικά, σε συνεργασία με τη Smart Electric. Αναλαμβάνουμε από ένα διαμέρισμα μέχρι καταστήματα και αποθήκες, με καθαρή δουλειά και σαφή προσφορά από την αρχή.",L$="Μετά την εγκατάσταση δεν εξαφανιζόμαστε: σας δίνουμε τα στοιχεία πρόσβασης, βεβαίωση εγκατάστασης με εγγύηση και είμαστε εδώ για ό,τι χρειαστείτε.",F$=[{v:"150+",l:"εγκαταστάσεις"},{v:"24μ",l:"εγγύηση"},{v:"48ω",l:"απόκριση σε βλάβη"},{v:"1",l:"υπεύθυνος για όλα"}],U$="Ας μιλήσουμε για τον χώρο σας",q$="Πείτε μας τι χρειάζεστε και θα σας στείλουμε προσφορά — συνήθως μέσα στην ίδια μέρα.",j$="",B$="",W$="",z$="",G$="",K$="Δευτέρα–Σάββατο 08:00–20:00",H$="Πρέβεζα, Λευκάδα, Βόνιτσα & Πάλαιρος",Q$="Εξυπηρετούμε και γύρω περιοχές κατόπιν συνεννόησης",J$="",Y$="",X$=[{t:"Αυτοψία",d:"Έρχόμαστε στο χώρο σας (ή βλέπουμε φωτογραφίες) και καταγράφουμε τι ακριβώς χρειάζεστε."},{t:"Προσφορά",d:"Παίρνετε γραπτή προσφορά με τα μοντέλα και τις τιμές, και μπορείτε να τη δείτε online."},{t:"Εγκατάσταση",d:"Τοποθετούμε με προσεκτική διέλευση καλωδίων και δοκιμάζουμε κάθε σημείο."},{t:"Παράδοση & υποστήριξη",d:"Σας δείχνουμε τη χρήση, σας δίνουμε τα στοιχεία πρόσβασης και μένουμε δίπλα σας μετά την εγκατάσταση."}],Z$=[{q:"Πώς γίνεται η προσφορά;",a:"Κάνουμε αυτοψία στο χώρο (ή βλέπουμε φωτογραφίες) και σας στέλνουμε γραπτή προσφορά με τα μοντέλα και τις τιμές. Μπορείτε να τη δείτε και online."},{q:"Πόσο χρόνο παίρνει μια εγκατάσταση;",a:"Εξαρτάται από το μέγεθος του έργου. Σας ενημερώνουμε για τον χρόνο μαζί με την προσφορά."},{q:"Μπορώ να βλέπω τις κάμερες από το κινητό μου;",a:"Ναι. Ρυθμίζουμε την εφαρμογή στο κινητό σας για προβολή και απομακρυσμένη πρόσβαση, και σας δείχνουμε πώς να τη χρησιμοποιείτε."},{q:"Υπάρχει εγγύηση;",a:"Ναι. Οι ακριβείς όροι της εγγύησης αναγράφονται στην προσφορά, και μετά την εγκατάσταση τους βλέπετε και στην Περιοχή πελάτη."},{q:"Τι γίνεται μετά την εγκατάσταση;",a:"Σας παραδίδουμε τα στοιχεία πρόσβασης και μένουμε διαθέσιμοι για υποστήριξη, ρυθμίσεις ή προσθήκες."},{q:"Σε ποιες περιοχές εξυπηρετείτε;",a:"Στην Πρέβεζα, τη Λευκάδα, τη Βόνιτσα και τον Πάλαιρο, και σε γύρω περιοχές κατόπιν συνεννόησης."}],eg={title:b$,desc:_$,eyebrow:w$,h1a:I$,h1b:E$,h1c:T$,lead:k$,powered:S$,cards:A$,svcTitle:P$,svcLead:R$,services:$$,partnersTitle:C$,partnersLead:D$,partners:N$,workTitle:x$,workLead:V$,aboutTitle:O$,about1:M$,about2:L$,stats:F$,contactTitle:U$,contactLead:q$,phone:j$,mobile:B$,reviewUrl:W$,cfToken:z$,email:G$,hours:K$,area:H$,areaNote:Q$,facebook:J$,instagram:Y$,steps:X$,faq:Z$},eC="TechMate · CCTV, networks and smart installations in Greece",tC="TechMate – Powered by Smart Electric. Installation of security cameras, Wi-Fi and networks, alarm systems and smart solutions for homes and businesses in Greece.",nC="Security · Networks · Smart installations",sC="Technology that",iC="works",rC="installation that lasts.",aC="Security cameras, Wi-Fi and networks, alarms and smart homes for residences and businesses. Design, installation and support from one team.",oC="Smart Electric",cC=[{ic:"📷",t:"Free site visit and quote",s:"A live quote you can view online"},{ic:"🛡️",t:"Installation warranty",s:"24 months on equipment and labour"},{ic:"📱",t:"View from your phone",s:"We set up the apps and remote access"},{ic:"🔧",t:"Support after installation",s:"Maintenance and quick service"},{ic:"🔌",t:"Careful cable routing",s:"Hidden or tidy routes, in trunking and conduit"},{ic:"🧹",t:"No mess",s:"We protect your space and leave it clean"},{ic:"🏷️",t:"Professional equipment",s:"Reliable models from leading manufacturers"},{ic:"🧰",t:"Professional tools",s:"Proper terminations, measurements and testing at every point"},{ic:"🎓",t:"Hand-over with training",s:"We show you how to use it and leave you the passwords"}],lC="Everything you need, from one team",uC="We choose the right equipment for your space and install it cleanly and correctly.",dC=[{ic:"📷",t:"CCTV security cameras",d:"IP cameras, recorders, night vision and viewing from your phone.",m:`## What we look for when choosing a model

- **Night vision:** models with infrared lighting and, where needed, colour images at night too.
- **Smart AI detection:** tells people and vehicles apart, so you get fewer false alerts from shadows, animals or rain.
- **Clear picture:** resolution matched to the area and what must be visible, such as an entrance, yard or number plates.
- **Durability:** weatherproof cameras for outdoor use that withstand rain and dust.
- **Enough storage:** a recorder and disk sized for the number of days you need.
- **On your phone:** live view, playback and alerts from anywhere.

## How we work

We visit the site, suggest positions and models, give you a quote, install with tidy cabling, set everything up and show you how to use it.`},{ic:"📶",t:"Wi-Fi and networks",d:"Wi-Fi without dead spots, access points, cabling and racks.",m:`## What is included

- **Site survey:** access points placed where they are needed, so there are no dead spots.
- **Wired backbone:** access points connected by network cable for stable speed.
- **Separate guest network**, so visitors cannot reach your own systems.
- **Cabling and rack:** neat, labelled and easy to extend.
- **Security and settings:** strong passwords and correct router configuration.`},{ic:"🚨",t:"Alarm systems",d:"Wired and wireless systems with phone notifications.",m:`## What is included

- **Motion and door/window sensors** where they are needed, with a siren.
- **Phone notifications** when the alarm is triggered.
- **Wired or wireless system**, depending on the building and your budget.
- **Backup battery**, so it keeps working during a power cut.
- **Link to your cameras**, if you want to see the picture when the alarm goes off.`},{ic:"🌡️",t:"Sensors and detectors",d:"Temperature, humidity, fire and smoke, with a notification to your phone.",m:`## What is included

- **Temperature and humidity sensors:** monitor your space from your phone, such as a storeroom, fridge, wine cellar, server room or a home that stays empty.
- **Alerts when the limits you set are exceeded**, for example very high temperature or humidity that encourages mould.
- **Smoke and fire detectors:** they sound locally and notify your phone, even when you are away.
- **Link to the alarm system or your automations**, where you want a siren or a scene to be triggered.
- **Wireless battery-powered sensors**, with no major work in your space.
- **Measurement history**, where the app supports it.`},{ic:"🚪",t:"Intercoms and access control",d:"Video intercoms, cards, codes and entry control.",m:`## What is included

- **Video intercom:** see who is at the door, even from your phone.
- **Card or code access**, so you do not need keys.
- **Electric locks and door openers** for doors and gates.
- **Rights per person:** add or remove cards whenever needed.`},{ic:"🏠",t:"Smart home",d:"Lighting, shutter and air-conditioning automation from your phone.",m:`## What is included

- **Lights, shutters and air conditioning** from your phone or on a schedule.
- **Scenes:** one tap for “leaving” or “evening”.
- **Voice control**, where the devices support it.
- **Step-by-step growth:** start with what you need and add more later.`},{ic:"⚡",t:"Electrical work",d:"Electrical work together with Smart Electric.",m:`## What we take care of

- **New lines and distribution boards** in homes and business premises.
- **Lighting and sockets**, extensions and replacements.
- **Fault repair.**
- **In cooperation with Smart Electric.**`}],hC="We work with leading manufacturers",fC="We install reliable equipment from companies we know in depth.",pC=[{t:"TP-Link",s:"Omada · networks and Wi-Fi"},{t:"Hikvision",s:"Cameras and recorders"},{t:"Dahua",s:"Cameras and recorders"},{t:"Ubiquiti",s:"UniFi · networks and Wi-Fi"},{t:"Ajax",s:"Alarm systems"}],mC="Jobs we have delivered",gC="A selection of our installations. Tap a photo to see it larger.",yC="A small team that cares",vC="TechMate is a team of technicians experienced in security systems, networks and electrical work, in cooperation with Smart Electric. We take on everything from a flat to shops and warehouses, with tidy work and a clear quote from the start.",bC="We do not disappear after the installation: we give you the access details, an installation certificate with warranty, and we are here for whatever you need.",_C=[{v:"150+",l:"installations"},{v:"24m",l:"warranty"},{v:"48h",l:"fault response"},{v:"1",l:"person responsible for everything"}],wC="Let's talk about your space",IC="Tell us what you need and we will send you a quote, usually the same day.",EC="Monday–Saturday 08:00–20:00",TC="Preveza, Lefkada, Vonitsa & Palairos",kC="We also serve nearby areas by arrangement",SC=[{t:"Site visit",d:"We come to your space (or look at photos) and note exactly what you need."},{t:"Quote",d:"You receive a written quote with the models and prices, and you can view it online."},{t:"Installation",d:"We install with careful cable routing and test every point."},{t:"Hand-over and support",d:"We show you how to use it, give you the access details and stay by your side after the installation."}],AC=[{q:"How does the quote work?",a:"We do a site visit (or look at photos) and send you a written quote with the models and prices. You can also view it online."},{q:"How long does an installation take?",a:"It depends on the size of the job. We tell you the time frame together with the quote."},{q:"Can I watch the cameras on my phone?",a:"Yes. We set up the app on your phone for viewing and remote access, and show you how to use it."},{q:"Is there a warranty?",a:"Yes. The exact warranty terms are written in the quote, and after the installation you can also see them in the Customer area."},{q:"What happens after the installation?",a:"We hand over the access details and remain available for support, settings or additions."},{q:"Which areas do you serve?",a:"Preveza, Lefkada, Vonitsa and Palairos, and nearby areas by arrangement."}],tg={title:eC,desc:tC,eyebrow:nC,h1a:sC,h1b:iC,h1c:rC,lead:aC,powered:oC,cards:cC,svcTitle:lC,svcLead:uC,services:dC,partnersTitle:hC,partnersLead:fC,partners:pC,workTitle:mC,workLead:gC,aboutTitle:yC,about1:vC,about2:bC,stats:_C,contactTitle:wC,contactLead:IC,hours:EC,area:TC,areaNote:kC,steps:SC,faq:AC},ng=[{id:"cctv-plan",on:!0,el:{t:"Πόσες κάμερες χρειάζεται ο χώρος σας και πού μπαίνουν",d:"Πρακτικός οδηγός για τον σχεδιασμό καμερών ασφαλείας σε σπίτι ή επαγγελματικό χώρο: σημεία κάλυψης, ανάλυση, νυχτερινή λήψη, αποθήκευση.",b:`Δεν υπάρχει μαγικός αριθμός καμερών. Ο σωστός σχεδιασμός ξεκινά από το **τι θέλετε να προστατέψετε** και όχι από το πόσες κάμερες χωράνε στο budget.

## 1. Ξεκινήστε από τα σημεία εισόδου

Οι περισσότερες παρεμβάσεις γίνονται από την κύρια είσοδο, τις πίσω πόρτες, τα ισόγεια παράθυρα και τα γκαράζ. Αυτά καλύπτονται πρώτα. Μια καλά τοποθετημένη κάμερα στην είσοδο αξίζει περισσότερο από τρεις που κοιτούν τον κενό χώρο.

## 2. Σκεφτείτε τον στόχο κάθε κάμερας

- **Επισκόπηση:** μια ευρεία εικόνα του χώρου, ώστε να βλέπετε τι συμβαίνει.
- **Αναγνώριση:** πιο κοντινή λήψη σε πόρτες και σημεία διέλευσης, ώστε να φαίνεται ποιος περνά.
- **Αποτροπή:** ορατή κάμερα και σήμανση, που από μόνες τους κάνουν πολλούς να το ξανασκεφτούν.

## 3. Ανάλυση, νυχτερινή λήψη και φως

Περισσότερα pixel βοηθούν στη λεπτομέρεια, αλλά μια κάμερα απέναντι σε δυνατό φως (ήλιος, προβολέας) δίνει κακή εικόνα όσο ακριβή κι αν είναι. Σημασία έχει η θέση, η γωνία και η νυχτερινή λήψη για τις ώρες που πραγματικά χρειάζεστε.

## 4. Αποθήκευση και πρόσβαση

Ο καταγραφέας (ή η αποθήκευση) πρέπει να επιλεγεί σύμφωνα με τον αριθμό των καμερών και τις ημέρες καταγραφής που θέλετε. Σκεφτείτε επίσης ποιος θα έχει απομακρυσμένη πρόσβαση από το κινητό και με ποιον κωδικό.

## 5. Προσοχή στον χώρο των άλλων

Οι κάμερες δεν πρέπει να κοιτούν το σπίτι ή την αυλή του γείτονα ή τον δημόσιο δρόμο περισσότερο από όσο είναι αναγκαίο. Δείτε και το άρθρο μας για τα προσωπικά δεδομένα.

**Τι να κάνετε στη συνέχεια:** κάντε μια βόλτα στον χώρο και σημειώστε τις εισόδους και τα σημεία που σας ανησυχούν. Με αυτή τη λίστα, μια αυτοψία βγάζει γρήγορα σαφή πρόταση.`},en:{t:"How many security cameras you need, and where to put them",d:"A practical guide to planning CCTV for a home or business: coverage points, resolution, night vision and storage.",b:`There is no magic number of cameras. Good planning starts from **what you want to protect**, not from how many cameras fit the budget.

## 1. Start with entry points

Most break-ins happen through the main entrance, back doors, ground-floor windows and garages. Cover those first. One well-placed camera at the door is worth more than three that watch empty space.

## 2. Decide what each camera is for

- **Overview:** a wide picture of the space, so you can see what is going on.
- **Identification:** a closer view of doors and choke points, so you can see who passes.
- **Deterrence:** a visible camera and signage, which on their own make many people think twice.

## 3. Resolution, night vision and light

More pixels help with detail, but a camera facing strong light (sun, floodlight) gives a poor picture however expensive it is. Position, angle and night vision for the hours you actually need matter most.

## 4. Storage and access

The recorder (or storage) should be sized to the number of cameras and the number of days you want to keep. Also think about who gets remote access from a phone, and with which password.

## 5. Respect other people's space

Cameras should not look at a neighbour's home or yard, or at the public street, more than is necessary. See also our article on personal data.

**Next step:** walk around the property and note the entrances and the spots that worry you. With that list, a site visit quickly produces a clear proposal.`}},{id:"wifi",on:!0,el:{t:"Αδύναμο Wi-Fi στο σπίτι ή στο μαγαζί: αιτίες και λύσεις",d:"Γιατί το Wi-Fi χάνεται σε κάποια δωμάτια και τι πραγματικά το διορθώνει: τοποθέτηση, access points, καλωδίωση.",b:`Όταν το Wi-Fi «δεν πιάνει» στο πίσω δωμάτιο, το πρώτο ένστικτο είναι να αγοραστεί ένας δυνατότερος router. Συνήθως δεν είναι εκεί το πρόβλημα.

## Οι πιο συχνές αιτίες

- **Ο router είναι σε κακό σημείο:** σε ντουλάπι, στη γωνία ή πίσω από τηλεόραση.
- **Τοίχοι και πλάκες:** το σκυρόδεμα και οι μεταλλικές επιφάνειες κόβουν το σήμα πολύ.
- **Παρεμβολές:** πολλά δίκτυα στο ίδιο κανάλι, ιδιαίτερα σε πολυκατοικίες.
- **Πολλές συσκευές:** ένας παλιός router δυσκολεύεται όταν συνδέονται δεκάδες.

## Τι λειτουργεί στην πράξη

1. **Μετακίνηση του router** σε κεντρικό, ψηλό και ανοιχτό σημείο, αν γίνεται.
2. **Περισσότερα σημεία πρόσβασης (access points)** που συνδέονται με καλώδιο δικτύου. Είναι η πιο σταθερή λύση για μεγάλους χώρους.
3. **Ενσύρματη σύνδεση** για ό,τι δεν κινείται (τηλεόραση, υπολογιστής, κάμερες): ελαφρύνει το Wi-Fi.
4. **Mesh συστήματα:** βολικά όταν δεν μπορεί να περαστεί καλώδιο, αλλά δουλεύουν καλύτερα όταν τα σημεία τους συνδέονται μεταξύ τους με καλώδιο.

## Πότε χρειάζεται καλωδίωση

Σε μαγαζιά, γραφεία και μεγάλα σπίτια, η σωστή λύση είναι συνήθως λίγα καλώδια δικτύου σε στρατηγικά σημεία και access points στο ταβάνι. Κοστίζει περισσότερο στην αρχή, αλλά λύνει το πρόβλημα μόνιμα.

**Πριν αγοράσετε κάτι:** γράψτε σε ποια δωμάτια χάνεται το σήμα και σε ποιες ώρες. Αυτή η πληροφορία δείχνει συχνά την αιτία πριν από οποιαδήποτε μέτρηση.`},en:{t:"Weak Wi-Fi at home or in the shop: causes and fixes",d:"Why Wi-Fi drops in some rooms and what actually fixes it: placement, access points and cabling.",b:`When Wi-Fi “doesn’t reach” the back room, the first instinct is to buy a stronger router. That is usually not where the problem is.

## The most common causes

- **The router is in a bad spot:** in a cabinet, in a corner or behind a TV.
- **Walls and slabs:** concrete and metal surfaces block signal heavily.
- **Interference:** many networks on the same channel, especially in apartment buildings.
- **Too many devices:** an old router struggles when dozens connect.

## What works in practice

1. **Move the router** to a central, high and open spot if you can.
2. **More access points** connected by network cable. This is the most stable solution for larger spaces.
3. **Wired connections** for anything that does not move (TV, computer, cameras), which takes load off the Wi-Fi.
4. **Mesh systems:** handy when you cannot run cable, but they work better when their nodes are also wired together.

## When cabling is needed

In shops, offices and large homes the right answer is usually a few network cables at strategic points and ceiling access points. It costs more up front but solves the problem for good.

**Before you buy anything:** note which rooms lose signal and at what times. That alone often points to the cause before any measurement.`}},{id:"cctv-law",on:!0,el:{t:"Κάμερες ασφαλείας και προσωπικά δεδομένα: τι πρέπει να ξέρετε",d:"Βασικές αρχές για νόμιμη χρήση καμερών σε σπίτι ή επιχείρηση στην Ελλάδα: σήμανση, χρόνος διατήρησης, πού επιτρέπεται να κοιτούν.",b:`*Γενική ενημέρωση και όχι νομική συμβουλή. Οι κανόνες αλλάζουν, γι’ αυτό ελέγχετε τις τρέχουσες οδηγίες της [Αρχής Προστασίας Δεδομένων](https://www.dpa.gr) ή ζητήστε νομική γνώμη για τη δική σας περίπτωση.*

Μια κάμερα που καταγράφει ανθρώπους επεξεργάζεται προσωπικά δεδομένα. Αυτό σημαίνει ότι υπάρχουν υποχρεώσεις, ιδιαίτερα όταν καταγράφονται άλλοι εκτός από τους ίδιους τους ιδιοκτήτες.

## Σήμανση

Σε επαγγελματικούς χώρους και γενικά όπου καταγράφονται τρίτοι, πρέπει να υπάρχει **ευδιάκριτη πινακίδα** που ενημερώνει ότι ο χώρος παρακολουθείται, με τον υπεύθυνο και τρόπο επικοινωνίας.

## Σκοπός και αναλογικότητα

Οι κάμερες πρέπει να εξυπηρετούν συγκεκριμένο σκοπό, όπως η προστασία προσώπων και περιουσίας, και να καταγράφουν μόνο ό,τι είναι αναγκαίο. Δεν τοποθετούνται σε χώρους όπως αποδυτήρια ή τουαλέτες και δεν στοχεύουν συστηματικά τους εργαζομένους.

## Πού κοιτούν

Αποφεύγετε να καλύπτετε είσοδο ή εσωτερικό γειτονικής κατοικίας και τον δημόσιο δρόμο πέρα από το απολύτως αναγκαίο.

## Πόσο κρατιούνται οι εγγραφές

Οι εγγραφές δεν πρέπει να φυλάσσονται περισσότερο από όσο χρειάζεται. Η Αρχή έχει συνήθως ως γενικό πλαίσιο μερικές δεκάδες ημέρες το πολύ, εκτός αν υπάρχει συγκεκριμένη ανάγκη, για παράδειγμα ένα περιστατικό. Ελέγξτε την τρέχουσα οδηγία.

## Ασφάλεια του ίδιου του συστήματος

Αλλάξτε τους προεπιλεγμένους κωδικούς, περιορίστε ποιοι έχουν πρόσβαση και κρατήστε το σύστημα ενημερωμένο. Μια κάμερα με ανοιχτή πρόσβαση είναι κίνδυνος και για την ιδιωτικότητά σας.

Στις εγκαταστάσεις μας ρυθμίζουμε τους κωδικούς και τον χρόνο καταγραφής μαζί σας και σας υποδεικνύουμε πού χρειάζεται πινακίδα.`},en:{t:"Security cameras and personal data: what you should know",d:"Basic principles for lawful use of cameras at home or in a business in Greece: signage, retention, and where cameras may point.",b:`*General information, not legal advice. Rules change, so check the current guidance of the [Hellenic Data Protection Authority](https://www.dpa.gr) or ask for legal advice on your own case.*

A camera that records people processes personal data. That brings obligations, especially when people other than the owners are recorded.

## Signage

In business premises, and generally wherever third parties are recorded, there should be a **clearly visible sign** saying the area is monitored, with the controller and contact details.

## Purpose and proportionality

Cameras must serve a specific purpose, such as protecting people and property, and record only what is necessary. They are not placed in areas such as changing rooms or toilets and do not systematically target employees.

## Where they point

Avoid covering a neighbour’s entrance or interior, and the public street beyond what is strictly necessary.

## How long recordings are kept

Recordings should not be kept longer than needed. The Authority’s general framework is usually a few dozen days at most, unless there is a specific need such as an incident. Check the current guidance.

## Security of the system itself

Change default passwords, limit who has access and keep the system up to date. A camera with open access is a risk to your own privacy too.

In our installations we set up passwords and recording time with you and point out where signage is needed.`}},{id:"wired-wireless",on:!0,el:{t:"Ενσύρματες ή ασύρματες κάμερες; Πώς να διαλέξετε",d:"Συγκριτικά πλεονεκτήματα και περιορισμοί των καμερών με καλώδιο PoE, Wi-Fi και μπαταρίας.",b:`Η ερώτηση «ασύρματες ή ενσύρματες;» εμφανίζεται σε κάθε αυτοψία. Η απάντηση εξαρτάται από τον χώρο και από το πόσο σταθερό θέλετε το αποτέλεσμα.

## Ενσύρματες (δίκτυο με PoE)

Ένα καλώδιο δικτύου φέρνει και δεδομένα και ρεύμα. **Πλεονεκτήματα:** σταθερή εικόνα, χωρίς εξάρτηση από το Wi-Fi, κεντρική καταγραφή. **Περιορισμοί:** χρειάζεται καλωδίωση, που σε έτοιμα κτίρια θέλει σχεδιασμό.

## Wi-Fi κάμερες (με τροφοδοσία από πρίζα)

Δεν χρειάζονται καλώδιο δεδομένων, αλλά θέλουν ρεύμα και καλό σήμα. **Πλεονεκτήματα:** εύκολη τοποθέτηση. **Περιορισμοί:** η ποιότητα εξαρτάται από το Wi-Fi και ένα αδύναμο δίκτυο δίνει κομμένη εικόνα.

## Κάμερες μπαταρίας

Κατάλληλες για σημεία χωρίς καθόλου καλώδιο. **Περιορισμοί:** χρειάζονται φόρτιση, συνήθως καταγράφουν μόνο σε κίνηση και δεν ταιριάζουν σε συνεχή καταγραφή.

## Πρακτικός κανόνας

- Για **σταθερή, μόνιμη κάλυψη** (είσοδοι, επαγγελματικός χώρος): ενσύρματες.
- Για **πρόσθετο σημείο** όπου δεν περνά καλώδιο: Wi-Fi ή μπαταρίας, αφού ελεγχθεί το σήμα.

Στην αυτοψία ελέγχουμε διαδρομές καλωδίων και σήμα, και προτείνουμε συνδυασμό που ταιριάζει στον χώρο σας.`},en:{t:"Wired or wireless cameras? How to choose",d:"Strengths and limits of PoE wired, Wi-Fi and battery cameras.",b:`The question “wireless or wired?” comes up at every site visit. The answer depends on the space and on how stable you want the result to be.

## Wired (PoE network cameras)

One network cable carries both data and power. **Strengths:** stable picture, no dependence on Wi-Fi, central recording. **Limits:** it needs cabling, which in existing buildings takes planning.

## Wi-Fi cameras (mains powered)

No data cable needed, but they need power and a good signal. **Strengths:** easy to place. **Limits:** quality depends on your Wi-Fi, and a weak network gives a choppy picture.

## Battery cameras

Suitable for spots with no cable at all. **Limits:** they need charging, usually record only on motion and are not suited to continuous recording.

## A practical rule

- For **stable, permanent coverage** (entrances, business premises): wired.
- For an **extra point** where no cable can run: Wi-Fi or battery, once the signal has been checked.

During the site visit we check cable routes and signal, and suggest a mix that suits your space.`}},{id:"maintenance",on:!0,el:{t:"Συντήρηση συστήματος ασφαλείας: τι ελέγχουμε και κάθε πότε",d:"Λίστα ελέγχου για κάμερες, καταγραφέα, δίκτυο και συναγερμό: καθαρισμός, ενημερώσεις, κωδικοί, μπαταρίες.",b:`Ένα σύστημα ασφαλείας που δεν ελέγχεται μπορεί να έχει σταματήσει να καταγράφει χωρίς να το ξέρετε. Ένας περιοδικός έλεγχος, συνήθως μία ή δύο φορές τον χρόνο, αποτρέπει δυσάρεστες εκπλήξεις.

## Τι ελέγχουμε

- **Κάμερες:** καθαρισμός φακών και καλύτερη γωνία. Ιστοί, σκόνη ή βλάστηση μπορούν να χαλάσουν την εικόνα.
- **Καταγραφή:** ότι όντως αποθηκεύονται εγγραφές και για πόσες ημέρες πίσω, καθώς και η κατάσταση του δίσκου.
- **Δίκτυο:** σύνδεση καμερών, καλωδίωση και βύσματα.
- **Ενημερώσεις λογισμικού:** του καταγραφέα και των καμερών, όπου αυτές προσφέρονται.
- **Κωδικοί και πρόσβαση:** ποιος έχει απομακρυσμένη πρόσβαση, αλλαγή κωδικών όταν αλλάζουν τα πρόσωπα.
- **Παροχή ρεύματος:** UPS ή μπαταρίες εφεδρείας, όπου υπάρχουν.
- **Συναγερμός:** μπαταρίες αισθητήρων και δοκιμή ειδοποιήσεων.

## Κάθε πότε

Για τους περισσότερους χώρους αρκεί ένας έλεγχος τον χρόνο. Σε χώρους με μεγάλο φόρτο ή υψηλές απαιτήσεις, κάθε έξι μήνες.

## Τι μπορείτε να κάνετε μόνοι σας

Ανοίξτε μία φορά τον μήνα μια εγγραφή των προηγούμενων ημερών και βεβαιωθείτε ότι υπάρχει και ότι η εικόνα είναι καθαρή. Αν κάτι δεν φαίνεται σωστό, καλέστε μας.

Προσφέρουμε περιοδική συντήρηση κάθε 6 ή 12 μήνες και σας υπενθυμίζουμε εμείς πότε έρχεται η ώρα.`},en:{t:"Maintaining a security system: what we check and how often",d:"A checklist for cameras, recorder, network and alarm: cleaning, updates, passwords, batteries.",b:`A security system that is never checked can stop recording without you knowing. A periodic check, usually once or twice a year, prevents unpleasant surprises.

## What we check

- **Cameras:** cleaning the lenses and adjusting the angle. Webs, dust or vegetation can spoil the picture.
- **Recording:** that footage is really being stored, how many days back, and the state of the disk.
- **Network:** camera connections, cabling and connectors.
- **Software updates:** for the recorder and the cameras, where available.
- **Passwords and access:** who has remote access, and changing passwords when people change.
- **Power:** UPS or backup batteries, where fitted.
- **Alarm:** sensor batteries and a test of notifications.

## How often

For most places one check a year is enough. For busy sites or high requirements, every six months.

## What you can do yourself

Once a month, open a recording from the previous days and make sure it exists and the picture is clear. If something looks wrong, call us.

We offer periodic maintenance every 6 or 12 months and we remind you when it is due.`}},{id:"starlink-order",on:!0,pin:!0,ref:!0,el:{t:"Πώς να παραγγείλετε Starlink μόνοι σας: οδηγός βήμα-βήμα",d:"Βήμα-βήμα οδηγός με φωτογραφίες για να παραγγείλετε το Starlink, ποιο πακέτο και kit να διαλέξετε, παύση της σύνδεσης για καταλύματα Airbnb και δωρεάν μήνας με link από εμάς.",b:`Αρκετοί πελάτες δυσκολεύονται να παραγγείλουν μόνοι τους το Starlink. Εδώ είναι ένας σύντομος οδηγός, βήμα προς βήμα και με φωτογραφίες από την ίδια την παραγγελία. Αν κολλήσετε σε οποιοδήποτε σημείο, γράψτε μας ή καλέστε μας και σας βοηθάμε.

## Πριν ξεκινήσετε

- Έχετε έτοιμη την **ακριβή διεύθυνση εγκατάστασης** (εκεί που θα μπει η κεραία).
- Έχετε μια **κάρτα πληρωμής** (ή Apple Pay).
- Σκεφτείτε πού θα μπει η κεραία: χρειάζεται **ελεύθερη θέα στον ουρανό**, χωρίς δέντρα ή ψηλά εμπόδια.
- Έχετε ένα κινητό για την εφαρμογή Starlink (App Store ή Google Play).

## Βήμα 1: Μπείτε στο starlink.com/gr

Γράψτε στο πεδίο «Διεύθυνση» τη διεύθυνση εγκατάστασης και πατήστε «Ξεκινήστε».

![Η αρχική σελίδα του Starlink. Γράφετε τη διεύθυνση στο πεδίο «Διεύθυνση» και πατάτε «Ξεκινήστε».](img/sl-1-home.jpg)

## Βήμα 2: Διαλέξτε τη σωστή διεύθυνση

Καθώς γράφετε, εμφανίζονται προτάσεις. Πατήστε αυτή που ταιριάζει ακριβώς. Αν η περιοχή δεν είναι διαθέσιμη, η Starlink θα σας το πει εδώ. (Στις εικόνες χρησιμοποιούμε μια δημόσια διεύθυνση ως παράδειγμα.)

![Διαλέξτε τη σωστή διεύθυνση από τη λίστα προτάσεων.](img/sl-2-address.jpg)

## Βήμα 3: Διαλέξτε πακέτο: 200 Mbps και πάνω

Ανοίγει η σελίδα «Παραγγελία κιτ για Οικιακή χρήση». Πάνω-πάνω βλέπετε ότι υπάρχει δοκιμαστική περίοδος 30 ημερών και ότι η αποστολή γίνεται εντός 1-2 εβδομάδων. Υπάρχουν τρεις καρτέλες: **100 Mbps**, **200 Mbps** και **Max**. Προτείνουμε πάντα **200 Mbps ή Max** (δείτε παρακάτω γιατί).

![Οι τρεις καρτέλες πακέτων: 100 Mbps, 200 Mbps και Max.](img/sl-3-plans.jpg)

## Βήμα 4: Δείτε τι κοστίζει και τι περιλαμβάνεται

Κάτω από την καρτέλα βλέπετε τη μηνιαία τιμή της υπηρεσίας και τον εξοπλισμό. Την ημέρα που γράφτηκε ο οδηγός, ο εξοπλισμός είχε **0 € προκαταβολικό κόστος και 0 € τον μήνα**. Δίνεται με ενοικίαση, οπότε **αν ακυρώσετε την υπηρεσία πρέπει να τον επιστρέψετε**. Οι τιμές και οι προσφορές αλλάζουν συχνά, γι' αυτό κοιτάξτε πάντα τις τρέχουσες στη σελίδα.

![Η τιμή του πακέτου 200 Mbps και τα έξοδα εξοπλισμού (οι τιμές αλλάζουν, δείτε πάντα τις τρέχουσες).](img/sl-4-price-200.jpg)

## Βήμα 5: Ελέγξτε ποιο kit παίρνετε

Πατήστε «Λεπτομέρειες προϊόντος» για να δείτε το kit του πακέτου. Με το πακέτο 200 Mbps παίρνετε το **Standard 4** (μεγαλύτερη κεραία, κατανάλωση 75-100 W, αντοχή σε άνεμο 96 km/h+, μαζί με router Starlink Mini Wi-Fi 6).

![Το kit «Standard 4» που περιλαμβάνεται στο πακέτο 200 Mbps.](img/sl-5-kit-200.jpg)

Με το πακέτο 100 Mbps παίρνετε το μικρότερο **Mini X** (κατανάλωση 25-40 W), που ταιριάζει σε μικρά νοικοκυριά.

![Το kit «Mini X» που περιλαμβάνεται στο πακέτο 100 Mbps.](img/sl-6-kit-100.jpg)

## Βήμα 6: Εγκατάσταση

Στην ενότητα «Εγκατάσταση» η Starlink προσφέρει εγκατάσταση από επαγγελματία με επιπλέον χρέωση. Μπορείτε να τη δείτε εκεί ή να μας ζητήσετε να αναλάβουμε εμείς τοποθέτηση, καλωδίωση και ρύθμιση Wi-Fi σε όλο το σπίτι.

## Βήμα 7: Ολοκλήρωση παραγγελίας

Πατήστε «Ολοκλήρωση παραγγελίας», συμπληρώστε τα στοιχεία παράδοσης και πληρωμής και ελέγξτε το «Σύνολο οφειλή σήμερα» πριν πληρώσετε. Η Starlink αναφέρει ότι, αν ακυρώσετε και επιστρέψετε το kit χωρίς ζημιά εντός 30 ημερών από την προθεσμία εξόφλησης, δικαιούστε πλήρη επιστροφή χρημάτων για το kit και τον πρώτο μήνα.

## Βήμα 8: Παραλαβή και εγκατάσταση

Όταν φτάσει το kit, ακολουθήστε την εφαρμογή Starlink. Σας δείχνει αν η θέση της κεραίας είναι καλή.

## Γιατί προτείνουμε 200 Mbps και πάνω

Όπως φαίνεται στη σελίδα παραγγελίας, το πακέτο 200 Mbps έρχεται με το μεγαλύτερο και πιο ισχυρό kit **Standard 4**, ενώ το 100 Mbps με το μικρότερο **Mini X**. Η μεγαλύτερη ταχύτητα βολεύει και σε σπίτια με πολλές συσκευές, τηλεργασία ή καταλύματα με πολλούς επισκέπτες. Πριν πληρώσετε, ελέγξτε πάντα ποιο kit αναγράφεται για το πακέτο που διαλέξατε.

## Airbnb και καταλύματα: παύση τον χειμώνα

Αν η σύνδεση είναι για κατάλυμα που δεν λειτουργεί τον χειμώνα, δεν χρειάζεται να πληρώνετε όλο τον χρόνο πλήρη λογαριασμό. Μπορείτε να **βάλετε τη σύνδεση σε παύση** (λειτουργία αναμονής) για τους μήνες που το κατάλυμα είναι κλειστό και να την ενεργοποιήσετε ξανά την άνοιξη. Η Starlink μπορεί να χρεώνει μικρό μηνιαίο ποσό για την αναμονή και να έχει όρια διάρκειας, γι' αυτό δείτε τους τρέχοντες όρους στον λογαριασμό σας.

## Link παραγγελίας από εμάς: δωρεάν μήνας

Αν ζητήσετε από εμάς **link για να παραγγείλετε το Starlink**, θα πάρετε **έναν μήνα δωρεάν εσείς και έναν μήνα δωρεάν εμείς**, μέσω του προγράμματος παραπομπής της Starlink. Ο μήνας ισχύει όταν η παραγγελία και η ενεργοποίηση γίνουν από το δικό μας link. Δεν πληρώνετε τίποτα παραπάνω.

Πατήστε το κουμπί παρακάτω, αφήστε τα στοιχεία σας και θα σας στείλουμε το link.`},en:{t:"How to order Starlink yourself: a step-by-step guide",d:"A step-by-step guide with photos for ordering Starlink, which plan and kit to pick, pausing the service for Airbnb properties in winter, and a free month with a link from us.",b:`Many customers find it hard to order Starlink on their own. This short guide walks you through it step by step, with photos from the actual order. If you get stuck anywhere, message or call us and we will help.

## Before you start

- Have the **exact installation address** ready (where the dish will go).
- Have a **payment card** ready (or Apple Pay).
- Think about where the dish will go: it needs a **clear view of the sky**, with no trees or tall obstacles.
- Have a phone ready for the Starlink app (App Store or Google Play).

## Step 1: Go to starlink.com/gr

Type your installation address into the "Διεύθυνση" (Address) field and press "Ξεκινήστε" (Get started). The Starlink site is shown in Greek in these photos.

![The Starlink home page. Enter the address in the "Διεύθυνση" field and press "Ξεκινήστε".](img/sl-1-home.jpg)

## Step 2: Pick the right address

Suggestions appear as you type. Tap the one that matches exactly. If your area is not available, Starlink tells you here. (The photos use a public landmark address as an example.)

![Pick the right address from the suggestion list.](img/sl-2-address.jpg)

## Step 3: Choose a plan: 200 Mbps and above

The "Home kit order" page opens. At the top you can see a 30-day trial period and shipping within 1-2 weeks. There are three tabs: **100 Mbps**, **200 Mbps** and **Max**. We always recommend **200 Mbps or Max** (see below why).

![The three plan tabs: 100 Mbps, 200 Mbps and Max.](img/sl-3-plans.jpg)

## Step 4: See the price and what is included

Under the tab you see the monthly service price and the equipment. On the day this guide was written the equipment had **€0 upfront and €0 per month**. It is supplied as a rental, so **if you cancel the service you must return it**. Prices and offers change often, so always check the current ones on the site.

![The 200 Mbps plan price and equipment costs (prices change, always check the current ones).](img/sl-4-price-200.jpg)

## Step 5: Check which kit you get

Tap "Λεπτομέρειες προϊόντος" (Product details) to see the plan's kit. With the 200 Mbps plan you get the **Standard 4** (larger dish, 75-100 W, wind resistance 96 km/h+, plus a Starlink Mini Wi-Fi 6 router).

![The "Standard 4" kit included with the 200 Mbps plan.](img/sl-5-kit-200.jpg)

With the 100 Mbps plan you get the smaller **Mini X** (25-40 W), which suits small households.

![The "Mini X" kit included with the 100 Mbps plan.](img/sl-6-kit-100.jpg)

## Step 6: Installation

In the "Installation" section Starlink offers installation by a professional for an extra fee. You can see it there, or ask us to take care of placement, cabling and Wi-Fi coverage across the whole house.

## Step 7: Complete the order

Press "Ολοκλήρωση παραγγελίας" (Complete order), fill in your delivery and payment details, and check the "Σύνολο οφειλή σήμερα" (Total due today) before you pay. Starlink states that if you cancel and return the undamaged kit within 30 days of the payment due date, you are entitled to a full refund for the kit and the first month.

## Step 8: Delivery and setup

When the kit arrives, follow the Starlink app. It shows whether the dish position is good.

## Why we recommend 200 Mbps and above

As shown on the order page, the 200 Mbps plan comes with the larger, more powerful **Standard 4** kit, while 100 Mbps comes with the smaller **Mini X**. The extra speed also helps in homes with many devices, remote work or busy holiday rentals. Before you pay, always check which kit is listed for the plan you picked.

## Airbnb and holiday lets: pause in winter

If the connection is for a property that is closed in winter, you do not need to pay a full bill all year. You can **pause the connection** (standby mode) for the months the property is closed and switch it back on in spring. Starlink may charge a small monthly fee for standby and may limit how long it lasts, so check the current terms in your account.

## Order link from us: a free month

If you ask us for a **link to order Starlink**, you get **one free month and we get one free month**, through Starlink's referral programme. The free month applies when the order and activation are made through our link. It costs you nothing extra.

Press the button below, leave your details and we will send you the link.`},cat:"tut"}],Ce=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),S={tab:"c",lang:"el",site:null,orig:null,photos:[],pdirty:{},arts:null,seeded:!1,busy:!1,loading:!1,edit:null,draft:null,msg:"",ok:"",del:"",started:!1},Rh=()=>S.started&&(S.dirty()||!!S.edit);S.dirty=()=>!!S.site&&(JSON.stringify(S.site)!==JSON.stringify(S.orig)||Object.keys(S.pdirty).length>0);const PC=()=>{S.started=!1,S.site=null,S.orig=null,S.photos=[],S.pdirty={},S.arts=null,S.edit=null,S.draft=null,S.msg="",S.ok="",S.del="",S.tab="c",S.lang="el"},jo=()=>(se()&&se().pubUrl||"https://tech-mate.gr").replace(/\/?$/,"/"),un=()=>S.lang==="en"?S.site.en:S.site,RC=()=>{const n={};return Object.keys(eg).forEach(e=>n[e]=Se(eg[e])),n};async function $C(n){if(!S.loading){S.loading=!0,S.started=!0,n();try{const[e,t]=await Promise.all([bb("public/site"),IA("public_photos")]),s=e||{},i=RC();Object.keys(s).forEach(o=>i[o]=s[o]),!i.email&&se()&&se().bizEmail&&(i.email=se().bizEmail);const r=s.en&&typeof s.en=="object"?s.en:{};i.en={},Object.keys(tg).forEach(o=>i.en[o]=r[o]!=null?r[o]:Se(tg[o])),delete i.logo,delete i.photos,delete i.vis;const a=s.photos||[];t.sort((o,l)=>{let u=a.indexOf(o.id),h=a.indexOf(l.id);return u<0&&(u=999),h<0&&(h=999),u-h||(l.ts||0)-(o.ts||0)}),S.site=i,S.orig=Se(i),S.photos=t,S.pdirty={},S.msg=""}catch(e){S.msg="Δεν φορτώθηκε η ιστοσελίδα ("+(e&&e.code||e&&e.message||"σφάλμα")+"). Έλεγξε τους κανόνες ασφαλείας.",S.started=!1}S.loading=!1,n()}}const Zl=["cards","services","stats","partners","steps","faq"],_o=n=>(n||[]).filter(e=>e&&(e.t||e.v||e.q));async function CC(){const n=S.photos.map(r=>r.id),e=S.photos.filter(r=>r.show!==!1).map(r=>r.id),t={};Object.keys(S.site).forEach(r=>{if(r==="en")return;const a=Zl.includes(r)?_o(S.site[r]):S.site[r];JSON.stringify(a)!==JSON.stringify(S.orig[r])&&(t[r]=a)});const s={};Object.keys(S.site.en).forEach(r=>{const a=Zl.includes(r)?_o(S.site.en[r]):S.site.en[r];JSON.stringify(a)!==JSON.stringify(S.orig.en[r])&&(s[r]=a)}),Object.keys(s).length&&(t.en=s);const i=Object.keys(t).length>0;Object.assign(t,{photos:n,vis:e,upd:Date.now(),cardsV:2,svcV:1}),await Qi("public/site",t);for(const r of Object.keys(S.pdirty)){const a=S.photos.find(o=>o.id===r);a&&await Qi("public_photos/"+r,{t:a.t||"",p:a.p||"",te:a.te||"",pe:a.pe||"",show:a.show!==!1})}S.pdirty={},S.orig=Se(S.site),S.ok=i||n.length?"Η ιστοσελίδα ενημερώθηκε. Οι αλλαγές φαίνονται ήδη στο "+jo().replace(/^https?:\/\//,"")+" (ανανέωσε τη σελίδα).":"";for(const r of Zl)S.site[r]=_o(S.site[r]),S.site.en[r]=_o(S.site.en[r]);S.orig=Se(S.site)}const Bo=()=>Qi("public/site",{photos:S.photos.map(n=>n.id),vis:S.photos.filter(n=>n.show!==!1).map(n=>n.id)}),DC=n=>{const e={α:"a",β:"v",γ:"g",δ:"d",ε:"e",ζ:"z",η:"i",θ:"th",ι:"i",κ:"k",λ:"l",μ:"m",ν:"n",ξ:"x",ο:"o",π:"p",ρ:"r",σ:"s",ς:"s",τ:"t",υ:"y",φ:"f",χ:"ch",ψ:"ps",ω:"o"},t=String(n||"").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").split("").map(s=>e[s]||s).join("").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,50);return t.length>=2?t:"arthro-"+Date.now().toString(36)};async function sg(n){S.loading=!0,n();try{const e=await bb("public/articles");let t=null;try{e&&(t=JSON.parse(e.json))}catch{}S.seeded=Array.isArray(t),S.arts=S.seeded?t:Se(ng),ng.forEach(s=>{s.pin&&!S.arts.some(i=>i.id===s.id)&&S.arts.push(Se(s))})}catch{S.msg="Δεν φορτώθηκαν τα άρθρα."}S.loading=!1,n()}async function NC(n){const e=JSON.stringify(n);if(e.length>9e5)throw new Error("Τα άρθρα είναι πολύ μεγάλα (όριο ~900KB).");await Qi("public/articles",{json:e,upd:Date.now()}),S.arts=n,S.seeded=!0}const ge=(n,e,t,s)=>{const i=un()[n]==null?"":un()[n];return`<label class="f">${e}${t?`<textarea class="in" data-w="${n}" rows="3" ${s?`placeholder="${Ce(s)}"`:""}>${Ce(i)}</textarea>`:`<input class="in" data-w="${n}" value="${Ce(i)}" ${s?`placeholder="${Ce(s)}"`:""}>`}</label>`};function gi(n,e,t,s){return(un()[n]||[]).map((r,a)=>`<div class="card pad" style="margin:0 0 8px">${e.map(([o,l])=>`<input class="in" style="margin-bottom:6px" data-wl="${n}:${a}:${o}" value="${Ce(r[o]||"")}" placeholder="${Ce(l)}">`).join("")}
    ${s?`<textarea class="in" data-wl="${n}:${a}:m" rows="5" placeholder="${Ce(s)}">${Ce(r.m||"")}</textarea>`:""}
    ${n==="partners"&&S.lang==="el"?`${r.l?`<img class="logo-prev" src="${Ce(r.l)}" style="max-height:48px">`:""}<label class="btn b2">🖼️ ${r.l?"Αλλαγή":"Λογότυπο"}<input type="file" accept="image/*" data-wlogo="${a}" hidden></label>${r.l?`<button class="btn b2" data-web-ldel="${a}">🗑️</button>`:""}`:""}
    <div class="actions"><button class="btn b2" data-web-up="${n}:${a}" ${a?"":"disabled"}>↑</button><button class="btn b2" data-web-del="${n}:${a}">✕ Αφαίρεση</button></div></div>`).join("")+`<button class="btn b2 wide" data-web-add="${n}">＋ ${t}</button>`}function sn(n){return`<div class="grp" style="margin-top:14px">${n}</div>`}function xC(){const n=S.lang==="en";return`<div class="actions"><button class="btn ${n?"b2":"b1"}" data-web-lang="el">🇬🇷 Ελληνικά</button><button class="btn ${n?"b1":"b2"}" data-web-lang="en">🇬🇧 English</button></div>
  ${n?'<div class="muted small">Επεξεργάζεσαι τα αγγλικά κείμενα. Τηλέφωνα, email και λογότυπα είναι κοινά και αλλάζουν από τα ελληνικά.</div>':""}
  <div class="card pad">${sn("🏠 Κεντρικό")}${ge("eyebrow","Μικρή γραμμή πάνω")}${ge("h1a","Τίτλος (αρχή)")}${ge("h1b","Τίτλος (κίτρινη λέξη)")}${ge("h1c","Τίτλος (τέλος)")}${ge("lead","Κείμενο κάτω από τον τίτλο",1)}${ge("powered","Powered by")}
  <div class="lbl">Κάρτες δίπλα στον τίτλο</div>${gi("cards",[["ic","😀 εικονίδιο"],["t","Τίτλος"],["s","Περιγραφή"]],"Κάρτα")}
  ${sn("🧰 Υπηρεσίες")}${ge("svcTitle","Τίτλος ενότητας")}${ge("svcLead","Υπότιτλος",1)}${gi("services",[["ic","😀 εικονίδιο"],["t","Υπηρεσία"],["d","Περιγραφή"]],"Υπηρεσία","Περισσότερες πληροφορίες (ανοίγουν όταν ο πελάτης πατήσει την υπηρεσία). ## Τίτλος · - λίστα · **έντονο**")}
  ${sn("🪜 Πώς δουλεύουμε")}${gi("steps",[["t","Τίτλος"],["d","Περιγραφή"]],"Βήμα")}
  ${sn("❓ Συχνές ερωτήσεις")}${gi("faq",[["q","Ερώτηση"],["a","Απάντηση"]],"Ερώτηση")}
  ${sn("🤝 Συνεργάτες (κατασκευαστές)")}${ge("partnersTitle","Τίτλος ενότητας")}${ge("partnersLead","Υπότιτλος",1)}${gi("partners",[["t",n?"Company (ίδιο όνομα με τα ελληνικά)":"Εταιρεία (π.χ. Hikvision)"],["s",n?"What it does (English)":"Τι κάνει (π.χ. Κάμερες)"]],"Συνεργάτης")}
  ${sn("👥 Ποιοι είμαστε")}${ge("aboutTitle","Τίτλος")}${ge("about1","Παράγραφος 1",1)}${ge("about2","Παράγραφος 2",1)}<div class="lbl">Αριθμοί (π.χ. «150+» · «εγκαταστάσεις»)</div>${gi("stats",[["v","Αριθμός"],["l","Τι μετράει"]],"Αριθμός")}
  ${sn("📞 Επικοινωνία")}${ge("contactTitle","Τίτλος")}${ge("contactLead","Κείμενο",1)}${n?"":ge("phone","Τηλέφωνο",0,"210 0000000")+ge("mobile","Κινητό (Viber / WhatsApp)",0,"69xxxxxxxx")+ge("email","Email")}${ge("hours","Ωράριο")}${ge("area","Περιοχή")}${ge("areaNote","Σημείωση περιοχής")}
  ${n?"":ge("facebook","Facebook (link)")+ge("instagram","Instagram (link)")+ge("cfToken","Cloudflare Web Analytics (token, 32 χαρακτήρες)")+ge("reviewUrl","Google αξιολογήσεις (link «Γράψε κριτική»)")}
  ${n?"":sn("🏢 Στοιχεία επιχείρησης (υποσέλιδο & πολιτική απορρήτου)")+'<div class="muted small">Εμφανίζονται μόνο όσα συμπληρώσεις.</div>'+ge("bizName","Επωνυμία / διακριτικός τίτλος")+ge("afm","ΑΦΜ")+ge("doy","ΔΟΥ")+ge("gemi","ΓΕΜΗ (προαιρετικό)")+ge("bizAddr","Διεύθυνση έδρας")}
  ${sn("🔎 Google")}${ge("title","Τίτλος σελίδας (καρτέλα / Google)")}${ge("desc","Περιγραφή για το Google",1)}</div>`}function VC(){const n=S.lang==="en",e=S.photos,t=e.filter(s=>!(s.t||"").trim()&&s.show!==!1).length;return`<div class="card pad"><div class="actions"><button class="btn b2" data-web-lang="el" ${n?"":'style="font-weight:700"'}>🇬🇷 Ελληνικά</button><button class="btn b2" data-web-lang="en" ${n?'style="font-weight:700"':""}>🇬🇧 English</button></div>
  ${n?'<div class="muted small">Αγγλικός τίτλος και περιοχή για κάθε φωτογραφία. Αν μείνει κενό, φαίνεται χωρίς λεζάντα.</div>':t?`<div class="err box">⚠️ ${t} φωτογραφί${t===1?"α":"ες"} χωρίς τίτλο. Ο τίτλος βοηθά τη Google και τους ανθρώπους με προβλήματα όρασης.</div>`:""}
  ${ge("workTitle","Τίτλος ενότητας «Έργα»")}${ge("workLead","Υπότιτλος",1)}
  ${e.map((s,i)=>`<div class="card pad" style="margin:8px 0;${s.show===!1?"opacity:.6":""}"><img class="logo-prev" src="${Ce(s.thumb||"")}" style="max-height:140px">
    <input class="in" style="margin-top:6px" data-wp="${i}:${n?"te":"t"}" placeholder="${n?"Title (English)":"Τίτλος (π.χ. Εγκατάσταση καμερών σε ξενοδοχείο)"}" value="${Ce(n?s.te||"":s.t||"")}">
    <input class="in" style="margin-top:6px" data-wp="${i}:${n?"pe":"p"}" placeholder="${n?"Area (English)":"Περιοχή"}" value="${Ce(n?s.pe||"":s.p||"")}">
    <div class="actions"><button class="btn b2" data-web-pup="${i}" ${i?"":"disabled"}>↑</button><button class="btn b2" data-web-pshow="${i}">${s.show===!1?"Εμφάνιση":"Απόκρυψη"}</button><button class="btn b2" data-web-pdel="${i}">${S.del==="p"+s.id?"Σίγουρα;":"✕"}</button></div></div>`).join("")||'<div class="muted small">Δεν υπάρχουν φωτογραφίες ακόμα· η ενότητα «Έργα» δεν εμφανίζεται μέχρι να προσθέσεις.</div>'}
  <label class="btn b1 wide" style="margin-top:8px">📷 Προσθήκη φωτογραφιών<input type="file" accept="image/*" multiple data-wph hidden></label>
  <div class="muted small">Οι φωτογραφίες μικραίνουν αυτόματα. Πρόσεξε να μη φαίνονται διευθύνσεις, πρόσωπα ή πινακίδες.</div></div>`}function OC(){if(!S.arts)return'<div class="card pad"><button class="btn b1 wide" data-web-aload>📰 Φόρτωση άρθρων</button></div>';if(S.edit){const n=S.draft,e=(t,s)=>{const i=n[t]||{};return`${sn(s)}<label class="f">Τίτλος<input class="in" maxlength="140" data-wa="${t}:t" value="${Ce(i.t||"")}"></label><label class="f">Σύντομη περιγραφή (για τη λίστα)<textarea class="in" rows="2" data-wa="${t}:d">${Ce(i.d||"")}</textarea></label><label class="f">Κείμενο<textarea class="in" rows="14" data-wa="${t}:b">${Ce(i.b||"")}</textarea></label>`};return`<div class="card pad"><b>${S.edit==="__new"?"Νέο άρθρο":"Επεξεργασία άρθρου"}</b>
    <div class="muted small">Κενή γραμμή = νέα παράγραφος · ## Τίτλος ενότητας · - λίστα (ή 1. αριθμημένη) · **έντονο** · *πλάγιο* · [κείμενο](https://σύνδεσμος)</div>
    <label class="f">Πού εμφανίζεται<select class="in" data-wa="cat"><option value="">📰 Άρθρα</option><option value="tut"${n.cat==="tut"?" selected":""}>🛠️ Βοηθήματα (tutorials)</option></select></label>
    <label class="chk"><input type="checkbox" data-wa="on" ${n.on===!1?"":"checked"}> Εμφανίζεται στο site</label>
    ${e("el","🇬🇷 Ελληνικά")}${e("en","🇬🇧 Αγγλικά (προαιρετικά)")}${S.msg?`<div class="err box">${Ce(S.msg)}</div>`:""}
    <div class="actions"><button class="btn b2" data-web-acancel>Άκυρο</button><button class="btn b1" data-web-asave>💾 Αποθήκευση</button></div></div>`}return`<div class="card pad"><button class="btn b1 wide" data-web-anew>➕ Νέο άρθρο</button><div class="muted small">Οι αλλαγές φαίνονται αμέσως στο site.${S.seeded?"":" Τώρα εμφανίζονται τα προεπιλεγμένα άρθρα· αποθηκεύονται στη βάση μόλις αλλάξεις κάτι."}</div></div>
  <div class="card">${S.arts.map((n,e)=>`<div class="item" style="${n.on===!1?"opacity:.6":""}"><div class="t"><b>${Ce(n.el&&n.el.t||n.en&&n.en.t||"(χωρίς τίτλο)")}</b><span>${n.on===!1?"κρυφό · ":""}${n.cat==="tut"?"🛠️ Βοηθήματα":"📰 Άρθρο"}${n.en&&n.en.t?"":" · χωρίς αγγλικά"}</span></div>
    <div class="actions" style="margin-top:6px"><button class="btn b2" data-web-aedit="${Ce(n.id)}">✏️</button><button class="btn b2" data-web-aup="${Ce(n.id)}" ${e?"":"disabled"}>↑</button><button class="btn b2" data-web-adn="${Ce(n.id)}" ${e<S.arts.length-1?"":"disabled"}>↓</button><button class="btn b2" data-web-atog="${Ce(n.id)}">${n.on===!1?"Εμφάνιση":"Απόκρυψη"}</button><button class="btn b2" data-web-adel="${Ce(n.id)}">${S.del==="a"+n.id?"Σίγουρα;":"✕"}</button></div></div>`).join("")||'<div class="empty">Δεν υπάρχουν άρθρα.</div>'}</div>`}function MC(n,e){if(!S.site)return e(n("Ιστοσελίδα","",'<a class="ib" href="#/menu">←</a>'),`<div class="card pad"><div class="muted small">Η δημόσια σελίδα που βλέπουν οι πελάτες στο ${Ce(jo().replace(/^https?:\/\//,""))}. Αλλάζεις κείμενα, τηλέφωνα, φωτογραφίες έργων και άρθρα από εδώ — χωρίς ανέβασμα.</div>
    ${S.msg?`<div class="err box">${Ce(S.msg)}</div>`:""}<button class="btn b1 wide" data-web-open ${S.loading?"disabled":""}>${S.loading?"Φόρτωση…":"✏️ Επεξεργασία ιστοσελίδας"}</button><a class="btn b2 wide" href="${Ce(jo())}" target="_blank" rel="noopener" style="margin-top:8px">👁️ Άνοιγμα σελίδας</a></div>
    <div class="card"><a class="mi" href="#/msgs"><div class="ic">📨</div><div class="t"><b>Μηνύματα ιστοσελίδας</b><span>Αιτήματα από τη φόρμα επικοινωνίας</span></div></a></div>`,"menu");const t=[["c","Περιεχόμενο"],["p","Φωτογραφίες"],["a","Άρθρα"]],s=S.dirty();return e(n("Ιστοσελίδα",s?"Υπάρχουν αλλαγές που δεν δημοσιεύτηκαν":"",'<a class="ib" data-web-close>←</a>'),`<div class="actions" style="margin:0 0 8px">${t.map(([i,r])=>`<button class="btn ${S.tab===i?"b1":"b2"}" data-web-tab="${i}">${r}</button>`).join("")}</div>
    ${S.ok?`<div class="upd">${Ce(S.ok)}</div>`:""}${S.msg&&S.tab!=="a"?`<div class="err box">${Ce(S.msg)}</div>`:""}
    ${S.tab==="c"?xC():S.tab==="p"?VC():OC()}
    ${S.tab!=="a"?`<div class="card pad"><button class="btn b1 wide" data-web-save ${S.busy?"disabled":""}>🌐 Δημοσίευση αλλαγών</button><a class="btn b2 wide" href="${Ce(jo())}" target="_blank" rel="noopener" style="margin-top:8px">👁️ Άνοιγμα σελίδας</a></div>`:""}`,"menu")}function LC(n){return new Promise((e,t)=>{const s=URL.createObjectURL(n),i=new Image;i.onload=()=>{const r=(l,u)=>{const h=Math.min(1,l/Math.max(i.naturalWidth,i.naturalHeight)),p=document.createElement("canvas");p.width=Math.round(i.naturalWidth*h),p.height=Math.round(i.naturalHeight*h),p.getContext("2d").drawImage(i,0,0,p.width,p.height);let m=p.toDataURL("image/webp",u);return m.indexOf("data:image/webp")!==0&&(m=p.toDataURL("image/jpeg",u)),m},a=r(640,.72);let o=r(1600,.8);o.length>9e5&&(o=r(1280,.7)),URL.revokeObjectURL(s),e({thumb:a,full:o})},i.onerror=()=>{URL.revokeObjectURL(s),t(new Error("Η εικόνα δεν διαβάζεται (π.χ. HEIC). Δοκίμασε JPG/PNG."))},i.src=s})}function FC(n){return new Promise((e,t)=>{const s=URL.createObjectURL(n),i=new Image;i.onload=()=>{const r=Math.min(1,320/i.width,120/i.height),a=Math.max(1,Math.round(i.width*r)),o=Math.max(1,Math.round(i.height*r)),l=document.createElement("canvas");l.width=a,l.height=o,l.getContext("2d").drawImage(i,0,0,a,o),URL.revokeObjectURL(s);let u=l.toDataURL("image/webp",.92);if(u.indexOf("data:image/webp")!==0&&(u=l.toDataURL("image/png")),u.length>9e4&&(u=l.toDataURL("image/webp",.7)),u.length>12e4)return t(new Error("Το λογότυπο είναι πολύ βαρύ· δοκίμασε πιο απλή εικόνα."));e(u)},i.onerror=()=>{URL.revokeObjectURL(s),t(new Error("Δεν διαβάστηκε η εικόνα."))},i.src=s})}const UC="[data-web-open],[data-web-close],[data-web-tab],[data-web-lang],[data-web-add],[data-web-del],[data-web-up],[data-web-ldel],[data-web-save],[data-web-pup],[data-web-pshow],[data-web-pdel],[data-web-aload],[data-web-anew],[data-web-aedit],[data-web-aup],[data-web-adn],[data-web-atog],[data-web-adel],[data-web-asave],[data-web-acancel]";function qC(n,e,t){const s=n.closest(UC);if(!s)return!1;const i=s.dataset;S.ok="",!i.webPdel&&!i.webAdel&&(S.del="");const r=o=>o==="stats"?{v:"",l:""}:o==="partners"?{t:"",s:""}:o==="steps"?{t:"",d:""}:o==="faq"?{q:"",a:""}:o==="cards"?{ic:"✅",t:"",s:""}:{ic:"🔧",t:"",d:""},a=async(o,l,u)=>{try{await NC(o),l&&t(l)}catch(h){S.msg=h.message||"Δεν αποθηκεύτηκε."}u&&u(),e()};if(i.webOpen!==void 0)return $C(e),!0;if(i.webClose!==void 0){if(S.dirty()&&!confirm("Έχεις αλλαγές που δεν δημοσιεύτηκαν. Κλείσιμο χωρίς δημοσίευση;"))return!0;PC()}else if(i.webTab){if(S.tab=i.webTab,S.msg="",S.tab==="a"&&!S.arts&&!S.loading)return sg(e),!0}else if(i.webLang)S.lang=i.webLang;else if(i.webAdd)(un()[i.webAdd]=un()[i.webAdd]||[]).push(r(i.webAdd));else if(i.webDel){const[o,l]=i.webDel.split(":");un()[o].splice(+l,1)}else if(i.webUp){const[o,l]=i.webUp.split(":"),u=un()[o],h=+l;if(h>0){const p=u[h];u[h]=u[h-1],u[h-1]=p}}else if(i.webLdel!==void 0)delete S.site.partners[+i.webLdel].l;else if(i.webSave!==void 0){if(S.busy)return!0;S.busy=!0,S.msg="",CC().then(()=>{S.busy=!1,t("Η ιστοσελίδα ενημερώθηκε."),e()},o=>{S.busy=!1,S.msg="Δεν δημοσιεύτηκε ("+(o&&o.code||"σφάλμα")+"). Έλεγξε τους κανόνες ασφαλείας.",e()})}else if(i.webPup!==void 0){const o=+i.webPup,l=S.photos;if(o>0){const u=l[o];l[o]=l[o-1],l[o-1]=u,Bo().catch(()=>{})}}else if(i.webPshow!==void 0){const o=S.photos[+i.webPshow];o.show=o.show===!1,S.pdirty[o.id]=1,Bo().catch(()=>{})}else if(i.webPdel!==void 0){const o=S.photos[+i.webPdel];S.del!=="p"+o.id?S.del="p"+o.id:(S.del="",S.photos.splice(+i.webPdel,1),delete S.pdirty[o.id],Promise.all([Im("public_photos/"+o.id),Im("public_photos_full/"+o.id)]).then(Bo).then(()=>t("Η φωτογραφία αφαιρέθηκε από τη σελίδα."),()=>t("Δεν διαγράφηκε.")))}else{if(i.webAload!==void 0)return sg(e),!0;if(i.webAnew!==void 0)S.edit="__new",S.draft={id:"",on:!0,el:{t:"",d:"",b:""},en:{t:"",d:"",b:""}},S.msg="",scrollTo(0,0);else if(i.webAedit){const o=S.arts.find(l=>l.id===i.webAedit);o&&(S.edit=o.id,S.draft=Se(o),S.msg="",scrollTo(0,0))}else if(i.webAcancel!==void 0)S.edit=null,S.draft=null,S.msg="";else if(i.webAsave!==void 0){const o=S.draft;if(o.el=o.el||{},o.en=o.en||{},["el","en"].forEach(u=>["t","d","b"].forEach(h=>o[u][h]=String(o[u][h]||"").trim())),!o.el.t||!o.el.b)return S.msg="Γράψε τίτλο και κείμενο στα ελληνικά.",e(),!0;if(o.en.t&&!o.en.b)return S.msg="Στα αγγλικά έχεις τίτλο αλλά όχι κείμενο.",e(),!0;if(o.el.b.length>2e4||o.en.b.length>2e4)return S.msg="Το κείμενο είναι πολύ μεγάλο.",e(),!0;let l=S.arts.slice();if(S.edit==="__new"){const u=DC(o.el.t);let h=u,p=2;for(;l.some(m=>m.id===h);)h=u+"-"+p++;o.id=h,l.push(o)}else l=l.map(u=>u.id===S.edit?o:u);return S.msg="",a(l,"✅ Το άρθρο αποθηκεύτηκε και φαίνεται ήδη στο site.",()=>{S.msg||(S.edit=null,S.draft=null)}),!0}else if(i.webAup||i.webAdn){const o=i.webAup||i.webAdn,l=S.arts.slice(),u=l.findIndex(p=>p.id===o),h=i.webAup?u-1:u+1;if(u>=0&&h>=0&&h<l.length){const p=l[u];return l[u]=l[h],l[h]=p,a(l),!0}}else{if(i.webAtog)return a(S.arts.map(o=>o.id===i.webAtog?{...o,on:o.on===!1}:o)),!0;if(i.webAdel)if(S.del!=="a"+i.webAdel)S.del="a"+i.webAdel;else return S.del="",a(S.arts.filter(o=>o.id!==i.webAdel),"Το άρθρο διαγράφηκε."),!0}}return e(),!0}function $h(n){const e=n.dataset;if(!S.site&&!S.draft)return!1;if(e.w&&S.site)return un()[e.w]=n.value,!0;if(e.wl&&S.site){const[t,s,i]=e.wl.split(":"),r=un()[t]&&un()[t][+s];return r&&(r[i]=n.value),!0}if(e.wp!==void 0&&S.site){const[t,s]=e.wp.split(":"),i=S.photos[+t];return i&&(i[s]=n.value,S.pdirty[i.id]=1),!0}if(e.wa&&S.draft){const[t,s]=e.wa.split(":");return s?(S.draft[t]=S.draft[t]||{},S.draft[t][s]=n.value):t==="on"?S.draft.on=n.checked:t==="cat"&&(n.value==="tut"?S.draft.cat="tut":delete S.draft.cat),!0}return!1}function jC(n,e,t){const s=n.dataset;return s.wa&&S.draft?($h(n),!0):s.wlogo!==void 0||s.wph!==void 0?(BC(n,e,t),!0):!1}async function BC(n,e,t){const s=n.dataset;if(s.wa&&S.draft)return $h(n),!0;if(s.wlogo!==void 0&&n.files&&n.files[0]){try{S.site.partners[+s.wlogo].l=await FC(n.files[0]),S.msg=""}catch(i){S.msg=i.message}return e(),!0}if(s.wph!==void 0&&n.files&&n.files.length){const i=[...n.files];n.value="";let r=0;t("Ανέβασμα φωτογραφιών…");for(const a of i)try{const o=await LC(a),l=Qe(),u={t:a.name.replace(/\.[^.]+$/,"").replace(/[_-]+/g," ").replace(/^(IMG|DSC|PXL|WP)\s*\d.*$/i,""),p:"",thumb:o.thumb,ts:Date.now(),show:!0,od:""};await Qi("public_photos/"+l,u),await Qi("public_photos_full/"+l,{full:o.full,ts:u.ts}),S.photos.push({...u,id:l}),r++,e()}catch(o){S.msg=o&&o.message?o.message:"Μια φωτογραφία δεν ανέβηκε."}if(r){try{await Bo()}catch{}t("Προστέθηκαν "+r+" φωτογραφίες. Γράψε τίτλο σε κάθε μία και πάτα «Δημοσίευση».")}return e(),!0}return!1}const nt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),eu=n=>String(n??"").replace(".",","),ea=n=>{const e=parseFloat(String(n??"").replace(",","."));return isNaN(e)?NaN:e},ka=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),ig=n=>{if(n=String(n||"").trim(),!n)return"";/^https?:\/\//i.test(n)||(n="https://"+n);try{const e=new URL(n);return e.protocol==="http:"||e.protocol==="https:"?e.href:""}catch{return""}},kc=n=>Array.isArray(n.links)&&n.links.length?n.links:n.sup||n.url?[{sup:n.sup||"",url:n.url||""}]:[],te={q:"",cat:"",f:null,msg:"",open:new Set},Ch=()=>!!te.f,WC=()=>{te.f=null,te.msg=""};function zC(){return{id:"",cat:te.cat||"",model:"",desc:"",descEn:"",code:"",cost:"",mtype:"pct",mval:"",links:[{sup:"",url:""}],notes:"",imgPdf:!0,img:void 0,hist:""}}function GC(n){const e=n.marginEur!=null&&n.marginEur!=="",t=(n.costHist||[]).slice(-6).map(s=>(s.ts?new Date(s.ts).toLocaleDateString("el-GR")+": ":"")+ka.format(A(s.cost))).join("  →  ");return{id:n.id,cat:n.cat||"",model:n.model||"",desc:n.desc||"",descEn:n.descEn||"",code:n.code||"",cost:eu(A(n.cost,0)),mtype:e?"eur":"pct",mval:e?eu(A(n.marginEur)):n.margin==null||n.margin===""?"":eu(A(n.margin)),links:kc(n).length?kc(n).map(s=>({sup:s.sup||"",url:s.url||""})):[{sup:"",url:""}],notes:n.notes||"",imgPdf:n.imgPdf!==!1,img:void 0,hist:t}}const r_=()=>[...new Set(k.products.map(n=>n.cat).filter(Boolean))].sort((n,e)=>n.localeCompare(e,"el")),KC=()=>[...new Set(k.products.flatMap(n=>kc(n).map(e=>e.sup)).filter(Boolean))].sort((n,e)=>n.localeCompare(e,"el"));function a_(n){const e=n.mtype==="eur",t=String(n.mval).trim();return{cost:ea(n.cost)||0,margin:!e&&t!==""?ea(t):null,marginEur:e&&t!==""?ea(t):null}}function o_(n){if(!String(n.cost).trim())return"";const e=a_(n),t=Xc(e);return`Τιμή πώλησης <b>${ka.format(t)}</b> · κέρδος <b>${ka.format(q(t-e.cost))}</b>`}function HC(n,e){if(te.f)return QC(n,e);const t=te.q.trim().toLowerCase(),s=k.products.filter(l=>(!te.cat||l.cat===te.cat)&&(!t||[l.model,l.desc,l.cat,l.code,l.sup].join(" ").toLowerCase().includes(t))).sort((l,u)=>String(l.cat||"").localeCompare(String(u.cat||""),"el")||String(l.model).localeCompare(String(u.model),"el")),i=new Map;s.forEach(l=>{const u=l.cat||"Χωρίς κατηγορία";i.has(u)||i.set(u,[]),i.get(u).push(l)});const r=!!t||!!te.cat,a=l=>`<a class="item" data-cat-edit="${nt(l.id)}"><div class="t" style="display:flex;gap:10px;align-items:center">${l.img?`<img class="pth" src="${nt(l.img)}">`:'<span class="pth ph">📦</span>'}<span style="flex:1;min-width:0"><b>${nt(l.model)}</b><span>${nt(l.desc||"")}</span></span><span style="text-align:right"><b>${ka.format(Xc(l))}</b><span>κόστος ${ka.format(A(l.cost))}</span></span></div></a>`,o=[...i].map(([l,u])=>{const h=r||te.open.has(l);return`<button class="cg${h?" open":""}" data-cat-g="${nt(l)}"><span class="cg-a">${h?"▾":"▸"}</span><b>${nt(l)}</b><span class="cg-n">${u.length}</span></button>${h?u.map(a).join(""):""}`}).join("");return e(n("Κατάλογος",s.length+" προϊόντα",'<a class="ib" href="#/menu">←</a>'),`<div class="card pad"><input class="in" data-cat-q placeholder="🔍 Αναζήτηση (μοντέλο, περιγραφή, barcode)" value="${nt(te.q)}">
    <select class="in" data-cat-f style="margin-top:8px"><option value="">Όλες οι κατηγορίες</option>${r_().map(l=>`<option${l===te.cat?" selected":""}>${nt(l)}</option>`).join("")}</select>
    <div class="actions" style="margin-top:8px"><button class="btn b1" data-cat-new>＋ Νέο προϊόν</button><button class="btn b2" data-cat-all>${te.open.size?"Σύμπτυξη όλων":"Άνοιγμα όλων"}</button></div></div>
    <div class="card">${o||'<div class="empty">Κανένα προϊόν.</div>'}</div>
    <div class="muted small" style="padding:0 6px 10px">Η διαγραφή προϊόντων γίνεται μόνο από το PWA.</div>`,"menu")}function QC(n,e){const t=te.f,s=!t.id,i=(a,o,l="",u="")=>`<label class="f">${o}<input class="in" data-cf="${a}" value="${nt(t[a])}" ${l} ${u?`list="${u}"`:""}></label>`,r=t.img===void 0?(k.products.find(a=>a.id===t.id)||{}).img:t.img&&t.img.thumb;return e(n(s?"Νέο προϊόν":"Επεξεργασία προϊόντος","",'<a class="ib" data-cat-cancel>←</a>'),`<div class="card pad">
    <datalist id="cl-cats">${r_().map(a=>`<option value="${nt(a)}">`).join("")}</datalist><datalist id="cl-sups">${KC().map(a=>`<option value="${nt(a)}">`).join("")}</datalist>
    ${i("cat","Κατηγορία","","cl-cats")}${i("model","Μοντέλο")}
    <label class="f">Περιγραφή (ελληνικά)<textarea class="in" data-cf="desc" rows="3">${nt(t.desc)}</textarea></label>
    <label class="f">Περιγραφή στα αγγλικά (για PDF στα αγγλικά)<textarea class="in" data-cf="descEn" rows="3">${nt(t.descEn)}</textarea></label>
    ${i("code","Barcode / κωδικός",'autocapitalize="off"')}${i("cost","Κόστος αγοράς € (χωρίς ΦΠΑ)",'inputmode="decimal"')}
    <label class="f">Κέρδος<select class="in" data-cf="mtype"><option value="pct"${t.mtype==="pct"?" selected":""}>Ποσοστό %</option><option value="eur"${t.mtype==="eur"?" selected":""}>Ποσό € ανά τεμάχιο</option></select></label>
    ${i("mval",t.mtype==="eur"?"Κέρδος € ανά τεμάχιο":"Κέρδος % (κενό = προεπιλογή "+A(se()&&se().margin,25)+"%)",'inputmode="decimal"')}
    <div class="upd" id="cat-prev">${o_(t)}</div>
    ${t.hist?`<div class="muted small">Ιστορικό κόστους: ${nt(t.hist)}</div>`:""}
    <div class="lbl">Προμηθευτές / links</div>
    ${t.links.map((a,o)=>`<div class="card pad" style="margin:0 0 8px"><label class="f">Προμηθευτής<input class="in" data-cl="${o}:sup" list="cl-sups" value="${nt(a.sup)}"></label>
      <label class="f">Link προϊόντος ή προμηθευτή<input class="in" data-cl="${o}:url" inputmode="url" autocapitalize="off" value="${nt(a.url)}"></label>
      ${t.links.length>1?`<button class="btn b2" data-cat-ldel="${o}">🗑️ Αφαίρεση</button>`:""}</div>`).join("")}
    <button class="btn b2 wide" data-cat-ladd>＋ Άλλος προμηθευτής</button>
    <label class="f">Σημειώσεις<textarea class="in" data-cf="notes" rows="2">${nt(t.notes)}</textarea></label>
    <div class="lbl">Φωτογραφία</div>${r?`<img class="logo-prev" src="${nt(r)}">`:'<div class="muted small">Δεν υπάρχει φωτογραφία.</div>'}
    <label class="btn b2 wide">📷 ${r?"Αλλαγή":"Προσθήκη"} φωτογραφίας<input type="file" accept="image/*" data-cimg hidden></label>
    ${r?'<button class="btn b2 wide" data-cat-imgdel style="margin-top:6px">Αφαίρεση φωτογραφίας</button>':""}
    <label class="chk"><input type="checkbox" data-cf="imgPdf" ${t.imgPdf?"checked":""}> Να μπαίνει η φωτογραφία στο PDF της προσφοράς</label>
    ${te.msg?`<div class="err box">${nt(te.msg)}</div>`:""}
    <div class="actions"><button class="btn b2" data-cat-cancel>Άκυρο</button><button class="btn b1" data-cat-save>${s?"➕ Προσθήκη":"💾 Αποθήκευση"}</button></div></div>`,"menu")}function JC(n){return new Promise((e,t)=>{const s=new FileReader;s.onerror=()=>t(new Error("Δεν διαβάστηκε")),s.onload=()=>{const i=new Image;i.onerror=()=>t(new Error("Δεν είναι εικόνα")),i.onload=()=>{const r=l=>{const u=Math.min(1,l/Math.max(i.naturalWidth,i.naturalHeight)),h=document.createElement("canvas");h.width=Math.max(1,Math.round(i.naturalWidth*u)),h.height=Math.max(1,Math.round(i.naturalHeight*u));const p=h.getContext("2d");return p.fillStyle="#fff",p.fillRect(0,0,h.width,h.height),p.drawImage(i,0,0,h.width,h.height),h},a=r(900),o=r(200);e({full:a.toDataURL("image/jpeg",.8),thumb:o.toDataURL("image/jpeg",.78),w:a.width,h:a.height})},i.src=s.result},s.readAsDataURL(n)})}function YC(n){const e=te.f,t=!e.id,s=e.model.trim();if(!s)return te.msg="Βάλε μοντέλο.";const i=ea(e.cost);if(isNaN(i)||i<0)return te.msg="Βάλε έγκυρο κόστος.";const r=String(e.mval).trim();if(r!==""&&isNaN(ea(r)))return te.msg="Το κέρδος δεν είναι αριθμός.";const a=e.links.map(u=>({sup:u.sup.trim(),url:u.url.trim()})).filter(u=>u.sup||u.url);for(const u of a){if(u.url&&!ig(u.url))return te.msg="Το link «"+u.url+"» δεν είναι έγκυρο.";u.url=u.url?ig(u.url):""}const o=a_(e),l={cat:e.cat.trim(),model:s,desc:e.desc.trim(),descEn:e.descEn.trim(),code:e.code.trim(),cost:i,margin:o.margin,marginEur:o.marginEur,links:a,sup:a.length?a[0].sup:"",url:a.length?a[0].url:"",notes:e.notes.trim(),imgPdf:!!e.imgPdf};if(t){const u=Qe(),h={...l,id:u,costHist:[{ts:Date.now(),cost:i}],img:"",imgW:0,imgH:0};e.img&&(wm(u,{d:e.img.full,w:e.img.w,h:e.img.h}),Object.assign(h,{img:e.img.thumb,imgW:e.img.w,imgH:e.img.h,imgFull:!0})),We("products",h)}else{const u=k.products.find(p=>p.id===e.id);if(!u)return te.msg="Το προϊόν δεν βρέθηκε.";const h={};if(Object.keys(l).forEach(p=>{const m=u[p]===void 0?p==="links"?kc(u):p==="imgPdf"?!0:null:u[p];JSON.stringify(m)!==JSON.stringify(l[p])&&!((m==null||m==="")&&(l[p]==null||l[p]===""))&&(h[p]=l[p])}),A(u.cost)!==i){const p=u.costHist&&u.costHist.length?u.costHist.slice():[{ts:0,cost:A(u.cost)}];p.push({ts:Date.now(),cost:i}),h.costHist=p.slice(-20)}e.img?(wm(e.id,{d:e.img.full,w:e.img.w,h:e.img.h}),Object.assign(h,{img:e.img.thumb,imgW:e.img.w,imgH:e.img.h,imgFull:!0})):e.img===!1&&(u.imgFull&&wA(e.id),Object.assign(h,{img:"",imgW:0,imgH:0,imgFull:!1})),Object.keys(h).length&&Ht("products",e.id,h)}te.f=null,te.msg="",n(t?"Το προϊόν προστέθηκε.":"Το προϊόν ενημερώθηκε.")}function XC(n,e,t){const s=n.closest("[data-cat-g],[data-cat-all],[data-cat-edit],[data-cat-new],[data-cat-cancel],[data-cat-save],[data-cat-ladd],[data-cat-ldel],[data-cat-imgdel]");if(!s)return!1;const i=s.dataset;if(i.catG!==void 0)te.open.has(i.catG)?te.open.delete(i.catG):te.open.add(i.catG);else if(i.catAll!==void 0)te.open.size?te.open.clear():k.products.forEach(r=>te.open.add(r.cat||"Χωρίς κατηγορία"));else if(i.catEdit){const r=k.products.find(a=>a.id===i.catEdit);r&&(te.f=GC(r),te.msg="",scrollTo(0,0))}else i.catNew!==void 0?(te.f=zC(),te.msg="",scrollTo(0,0)):i.catCancel!==void 0?(te.f=null,te.msg=""):i.catSave!==void 0?YC(t):i.catLadd!==void 0?te.f.links.push({sup:"",url:""}):i.catLdel!==void 0?te.f.links.splice(+i.catLdel,1):i.catImgdel!==void 0&&(te.f.img=!1);return e(),!0}function ZC(n,e){const t=n.dataset;if(t.catQ!==void 0){te.q=n.value,e();const s=document.querySelector("[data-cat-q]");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(!te.f)return!1;if(t.cf){te.f[t.cf]=n.type==="checkbox"?n.checked:n.value,te.msg="";const s=document.getElementById("cat-prev");return s&&(s.innerHTML=o_(te.f)),!0}if(t.cl){const[s,i]=t.cl.split(":");return te.f.links[+s][i]=n.value,te.msg="",!0}return!1}function eD(n,e){const t=n.dataset;return t.catF!==void 0?(te.cat=n.value,e(),!0):te.f?t.cimg!==void 0&&n.files&&n.files[0]?((async()=>{try{te.f.img=await JC(n.files[0]),te.msg=""}catch(s){te.msg=s.message}e()})(),!0):t.cf&&n.tagName==="SELECT"?(te.f[t.cf]=n.value,e(),!0):!1:!1}const tD=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),nD=new Intl.NumberFormat("en-GB",{style:"currency",currency:"EUR"}),sD=n=>tD.format(Math.round((n||0)*100)/100),iD=n=>nD.format(Math.round((n||0)*100)/100),rD=n=>String(q(n)).replace(".",","),aD=n=>String(q(n)),c_=n=>n.qty*n.price*(1-(n.disc||0)/100),oD=864e5,rg={el:{war:"Εγγύηση ",mUnit:"μήνες",noWar:"Χωρίς εγγύηση",planTitle:"Κάτοψη και θέσεις εξοπλισμού",planCam:"Κάμερα",planAp:"Access Point",planOther:"Σημείο",option:"Εναλλακτική: ",valid:"Ισχύει έως: ",payTitle:"Στοιχεία πληρωμής",payBank:"Τράπεζα",payIban:"IBAN",payHolder:"Δικαιούχος",payAfm:"ΑΦΜ",payRef:"Αιτιολογία",payRefVal:"Προσφορά ",payNote:"Παρακαλούμε ελέγξτε το όνομα δικαιούχου και το ΑΦΜ πριν στείλετε την πληρωμή.",notesTitle:"Σημειώσεις",termsTitle:"Όροι και προϋποθέσεις",page:"Σελίδα",of:"από",lang:"el",benTitle:"Τι κερδίζετε",file:"Prosfora_"},en:{war:"Warranty ",mUnit:"months",noWar:"No warranty",planTitle:"Layout and equipment positions",planCam:"Camera",planAp:"Access Point",planOther:"Point",option:"Option: ",valid:"Valid until: ",payTitle:"Payment details",payBank:"Bank",payIban:"IBAN",payHolder:"Beneficiary",payAfm:"VAT No.",payRef:"Reference",payRefVal:"Quotation ",payNote:"Please verify the beneficiary name and VAT number before sending your payment.",notesTitle:"Notes",termsTitle:"Terms and conditions",page:"Page",of:"of",lang:"en",benTitle:"What you gain",title:"QUOTATION",no:"No.: ",date:"Date: ",to:"To",subject:"Subject: ",desc:"Description",qty:"Qty",unit:"Unit price",disc:"Disc.",total:"Total",net:"Net amount",vat:"VAT ",grand:"TOTAL",grandNoVat:"TOTAL (no VAT)",file:"Quotation_"}},cD=n=>!(n&&n.war&&n.war.on===!1),lD=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(A(e.m,0))):A(se().warrantyMonths,24)},uD=(n,e,t)=>{e=e||{};const s=A(e.val,0);return t=t||0,e.type==="eurnet"?q(Math.min(Math.max(0,s)*(1+t/100),n)):e.type==="pct"?q(n*Math.min(100,Math.max(0,s))/100):e.type==="eur"?q(Math.min(Math.max(0,s),n)):0};function l_(n){let e=0;(n.lines||[]).forEach(u=>e+=c_(u)),e=q(e);const t=n.vatMode==="off",s=A(se().vat,24),i=t?0:q(e*s/100),r=q(e+i),a=n.prepay||{},o=t?0:s,l=uD(r,a,o);return{preNet:a.type==="eurnet"?q(l/(1+o/100)):0,sub:e,vat:i,vp:s,vatOff:t,total:r,pre:l,rest:q(r-l),preType:a.type||"",preVal:A(a.val,0)}}const dD=n=>{if(n.descEn)return n.descEn;const e=n.pid&&k.products.find(t=>t.id===n.pid);if(e&&e.descEn){const t=e.model+(e.desc?" - "+e.desc:"");if(!n.desc||n.desc===t)return e.model+" - "+e.descEn}return n.desc},hD=n=>{const e=String(n||"").trim().match(/^(https:\/\/[a-z0-9.-]+\.[a-z]{2,})(:\d+)?\/?$/i);return e?e[1].toLowerCase()+(e[2]||"")+"/":""},fD=n=>String(n&&n.info||"").replace(/\{email\}/gi,n&&n.bizEmail||""),pD=n=>{const e=n.validDays,t=e!=null&&e!==""?A(e,0):se().validDays==null?15:A(se().validDays,15);return t?new Date((n.ts||Date.now())+t*oD).toLocaleDateString("el-GR"):""};let wo=null;async function mD(){if(wo)return wo;const[{jsPDF:n},e,t,s,i]=await Promise.all([zn(()=>import("./jspdf.es.min-DJ6VHK87.js").then(o=>o.j),[]),zn(()=>import("./jspdf.plugin.autotable-DYHf0IZ0.js"),[]),zn(()=>import("./reg-DWYsL-bi.js"),[]),zn(()=>import("./bold-BPkZ6IBK.js"),[]),zn(()=>import("./qrlib-Bgozeulj.js"),[])]);(e.applyPlugin||e.default&&e.default.applyPlugin)(n);const r=new Function(i.default+"; return qrcode;")(),a=await zn(()=>import("./gen-C78E_0f9.js"),[]);return wo={jsPDF:n,fonts:{reg:t.default.trim(),bold:s.default.trim()},qrcode:r,gen:a},wo}function gD(n,e){try{const t=n(0,"M");t.addData(e),t.make();const s=t.getModuleCount(),i=[];for(let r=0;r<s;r++){let a="";for(let o=0;o<s;o++)a+=t.isDark(r,o)?"1":"0";i.push(a)}return i}catch{return null}}async function yD(n,e){e=e==="en"?"en":"el";const{jsPDF:t,fonts:s,qrcode:i,gen:r}=await mD(),a=se(),o=k.st.logo||{};let l=JSON.parse(JSON.stringify(n));e==="en"&&(l.lines=l.lines.map(N=>({...N,desc:dD(N)}))),l.war={on:cD(l),m:lD(l)};const u=hD(a.pubUrl),p={qr:a.qrOn!==!1&&u?gD(i,u+"portal.html"):null,qrT1:e==="en"?"View your documents online":"Δείτε τα έγγραφά σας online",qrT2:e==="en"?"Scan the code and sign in with your personal access code.":"Σκανάρετε το QR και μπείτε με τον προσωπικό σας κωδικό πρόσβασης.",validTo:pD(l),banks:a.banks||[],name:a.name,info:fD(a),terms:e==="en"&&a.termsEn&&a.termsEn.trim()?a.termsEn:a.terms,logoMM:a.logoMM,color:a.pdfColor,logo:o.data,logoW:o.w,logoH:o.h,plan:null},m={};l.lines.forEach((N,$)=>{const B=N.pid&&k.products.find(J=>J.id===N.pid);N.showImg&&B&&B.img&&B.imgW&&B.imgH&&(m[$]={data:B.img,w:B.imgW,h:B.imgH})});const w=r.makePdf(t,s,p,l,l_(l),e==="en"?iD:sD,e==="en"?aD:rD,c_,m,rg[e]),E=(l.customer.name||"").replace(/[^\p{L}\p{N}]+/gu,"_").replace(/^_|_$/g,"");return{buf:w,fn:rg[e].file+l.number+(E?"_"+E:"")+".pdf"}}const ag=l_,Io=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),vD=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),og=(n,e,t)=>{const s=t==="en"?new Intl.NumberFormat("en-GB",{style:"currency",currency:"EUR"}).format(ag(e).total):vD.format(ag(e).total),i=e.customer&&e.customer.name||"";return String(n??"").split(`
`).filter(r=>!r.includes("{link}")).join(`
`).replace(/\n{3,}/g,`

`).replace(/\{(πελάτης|customer)\}/g,i).replace(/\{(αριθμός|number)\}/g,e.number||"").replace(/\{(θέμα|subject)\}/g,e.subject||"").replace(/\{(σύνολο|total)\}/g,s).replace(/\{(εταιρεία|company)\}/g,se().name||"").replace(/ για «»/g,"").replace(/ for «»/g,"").replace(/ ,/g,",").replace(/Dear ,/g,"Dear Sir/Madam,")},Zn={el:{subj:"Προσφορά {αριθμός} – {εταιρεία}",body:`Καλησπέρα σας {πελάτης},

σας στέλνουμε την προσφορά μας με αριθμό {αριθμός} για «{θέμα}».

Θα βρείτε την προσφορά σε PDF στο συνημμένο.

Είμαστε στη διάθεσή σας για οποιαδήποτε απορία.

Με εκτίμηση,
{εταιρεία}`},en:{subj:"Quotation {number} – {company}",body:`Dear {customer},

please find our quotation no. {number}.

The quotation is attached as a PDF.

Please do not hesitate to contact us if you have any questions.

Kind regards,
{company}`}},bD=n=>{const e=se();return n==="en"?{subj:e.mailSubjEn||Zn.en.subj,body:e.mailBodyEn||Zn.en.body}:{subj:e.mailSubj||Zn.el.subj,body:e.mailBody||Zn.el.body}};let we=null;const Dh=()=>!!we;function _D(){we=null}function wD(n){if(!k.quotes.find(s=>s.id===n))return;let t="el";try{t=localStorage.getItem("tm-pdflang")==="en"?"en":"el"}catch{}we={id:n,lang:t,busy:"",msg:""}}function ID(){if(!we)return"";const n=k.quotes.find(t=>t.id===we.id);if(!n)return we=null,"";const e=n.customer&&n.customer.email||"";return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>PDF προσφοράς #${Io(n.number)}</b><button class="ib dk" data-sd="close">✕</button></div>
  <div class="sheet-list pad"><div class="lbl">Γλώσσα PDF</div>
  <div class="seg"><button data-sdl="el" class="${we.lang==="el"?"on":""}">Ελληνικά</button><button data-sdl="en" class="${we.lang==="en"?"on":""}">English</button></div>
  <div class="sd-btns">
    <button class="btn b1 wide" data-sd="share" ${we.busy?"disabled":""}>📤 Αποστολή (WhatsApp, Viber, Drive…)</button>
    <button class="btn b2 wide" data-sd="mail" ${we.busy?"disabled":""}>✉️ Email${e?" στον "+Io(e):""}</button>
    <button class="btn b2 wide" data-sd="view" ${we.busy?"disabled":""}>👁️ Προβολή / Αποθήκευση</button>
  </div>
  ${we.busy?`<div class="upd">${Io(we.busy)}</div>`:""}${we.msg?`<div class="err box">${Io(we.msg)}</div>`:""}
  <div class="muted small">Δεν αλλάζει τίποτα στην προσφορά· καταγράφεται μόνο στο ιστορικό της.</div></div></div></div>`}const ED=n=>{const e=new Uint8Array(n);let t="";const s=32768;for(let i=0;i<e.length;i+=s)t+=String.fromCharCode.apply(null,e.subarray(i,i+s));return btoa(t)};async function TD(n,e,t){const s=k.quotes.find(i=>i.id===we.id);if(s){we.busy="Φτιάχνω το PDF…",we.msg="",e();try{const{buf:i,fn:r}=await yD(s,we.lang);try{localStorage.setItem("tm-pdflang",we.lang)}catch{}const a=bD(we.lang),o=og(a.subj,s,we.lang),l=og(a.body,s,we.lang);let u={ok:!0};if(On)u=await ue.shareFile({name:r,b64:ED(i),mime:"application/pdf",text:l,subject:o,email:n==="mail"&&s.customer&&s.customer.email||"",view:n==="view"});else{const h=URL.createObjectURL(new Blob([i],{type:"application/pdf"})),p=document.createElement("a");p.href=h,p.download=r,document.body.appendChild(p),p.click(),p.remove(),setTimeout(()=>URL.revokeObjectURL(h),5e3)}if(u&&u.error)return we.busy="",we.msg=u.error,e();We("qlog",{id:Qe(),qid:s.id,number:s.number||"",customer:s.customer&&s.customer.name||"",ts:Date.now(),type:"pdf",text:"Εξαγωγή PDF ("+(we.lang==="en"?"αγγλικά":"ελληνικά")+") από την εφαρμογή Android."}),we=null,t("Το PDF είναι έτοιμο."),e()}catch(i){we.busy="",we.msg="Δεν δημιουργήθηκε το PDF. "+(i&&i.message||""),e()}}}function kD(n,e,t){const s=n.closest("[data-sd],[data-sdl],[data-sdq]");if(!s)return!1;const i=s.dataset;return i.sdq?(wD(i.sdq),e(),!0):we?i.sdl?(we.lang=i.sdl,e(),!0):(i.sd==="close"?(we=null,e()):we.busy||TD(i.sd,e,t),!0):!1}const an=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),tu=n=>String(n??"").replace(".",","),Tn=n=>{const e=parseFloat(String(n??"").replace(",","."));return isNaN(e)?NaN:e},G={open:"company",f:null,msg:"",ok:""},Nh=()=>!!G.f,SD=()=>{G.f=null,G.msg="",G.ok=""},AD=[["company","🏢","Εταιρεία & PDF",()=>se().name||""],["prices","💶","Τιμές & αρίθμηση",()=>"ΦΠΑ "+A(se().vat,24)+"% · κέρδος "+A(se().margin,25)+"%"],["banks","🏦","Τραπεζικοί λογαριασμοί",()=>(se().banks||[]).filter(n=>n.iban).length+" λογαριασμοί"],["mail","✉️","Πρότυπα email",()=>"Ελληνικά & αγγλικά"],["alerts","⏰","Καιρός, υπενθυμίσεις & εγγύηση",()=>se().wxCity||"—"],["books","📒","Λογιστικά & αντίγραφα",()=>"Αρχικό υπόλοιπο · κατηγορίες"],["lock","🔐","Κλείδωμα εφαρμογής",p$],["team","👥","Χρήστες ομάδας",()=>Object.keys((k.st.roles||{}).users||{}).length+" χρήστες"]],cg={company:()=>{const n=se();return{name:n.name||"",info:n.info||"",bizEmail:n.bizEmail||"",pdfColor:n.pdfColor||"#1d4e89",logoMM:String(A(n.logoMM,18)),terms:n.terms||"",termsEn:n.termsEn||"",pubUrl:n.pubUrl||"",qrOn:n.qrOn!==!1}},prices:()=>{const n=se();return{vat:tu(A(n.vat,24)),margin:tu(A(n.margin,25)),next:String(A(n.next,1)),validDays:String(n.validDays==null?15:A(n.validDays,15)),followDays:String(n.followDays==null?7:A(n.followDays,7)),warrantyMonths:String(A(n.warrantyMonths,24)),autoSale:n.autoSale!==!1}},mail:()=>{const n=se();return{mailSubj:n.mailSubj||Zn.el.subj,mailBody:n.mailBody||Zn.el.body,mailSubjEn:n.mailSubjEn||Zn.en.subj,mailBodyEn:n.mailBodyEn||Zn.en.body}},alerts:()=>{const n=se();return{wxCity:n.wxCity||"",wxCity2:n.wxCity2||"",autoRem:n.autoRem!==!1,remDays:String(n.remDays==null?3:A(n.remDays,3)),warrantyTerms:n.warrantyTerms||""}},books:()=>{const n=k.st.books||{},e=k.st.meta||{};return{opening:tu(A(n.opening,0)),costCats:(n.costCats||[]).join(", "),backupDays:String(e.backupDays==null?7:A(e.backupDays,7))}},banks:()=>({banks:(se().banks||[]).map(n=>({id:n.id||Qe(),bank:n.bank||"",iban:n.iban||"",holder:n.holder||"",afm:n.afm||""}))})},dt=(n,e,t="")=>`<label class="f">${e}<input class="in" data-sf="${n}" value="${an(G.f.v[n]??"")}" ${t}></label>`,yi=(n,e,t=3)=>`<label class="f">${e}<textarea class="in" data-sf="${n}" rows="${t}">${an(G.f.v[n]??"")}</textarea></label>`,nu=(n,e)=>`<label class="chk"><input type="checkbox" data-sf="${n}" ${G.f.v[n]?"checked":""}> ${e}</label>`;function PD(n){const e=G.f&&G.f.k===n?G.f:null;if(n==="lock")return g$();if(n==="team")return`<div class="muted small" style="margin-bottom:6px">Οι χρήστες ομάδας (τεχνικοί) προστίθενται και αφαιρούνται από το PWA, γιατί χρειάζονται λογαριασμό στο Firebase. Εδώ φαίνονται μόνο.</div>
    ${Object.entries((k.st.roles||{}).users||{}).map(([i,r])=>`<div class="item"><div class="t"><b>${an(r.name||"—")}</b><span>${r.role==="team"?"Τεχνικός":"Διαχειριστής"}${r.empId?" · υπάλληλος":""}</span></div></div>`).join("")||'<div class="empty">Δεν υπάρχουν χρήστες ομάδας.</div>'}`;if(!e)return`<button class="btn b2 wide" data-st-edit="${n}">✏️ Αλλαγή</button>`+RD(n);let t="";if(n==="company"){const s=e.logo||k.st.logo||{};t=`${dt("name","Επωνυμία")}${yi("info","Στοιχεία (διεύθυνση, τηλ., email, ΑΦΜ)",5)}${dt("bizEmail","Email επιχείρησης",'inputmode="email" autocapitalize="off"')}
    <div class="lbl">Λογότυπο PDF ${s.data?"":"(δεν υπάρχει)"}</div>${s.data?`<img class="logo-prev" src="${an(s.data)}">`:""}
    <label class="btn b2 wide">🖼️ ${s.data?"Αλλαγή":"Επιλογή"} λογοτύπου<input type="file" accept="image/png,image/jpeg" data-sl hidden></label>
    <label class="f">Μέγεθος λογοτύπου<select class="in" data-sf="logoMM">${[["12","Μικρό"],["18","Μεσαίο"],["26","Μεγάλο"]].map(([i,r])=>`<option value="${i}"${String(e.v.logoMM)===i?" selected":""}>${r}</option>`).join("")}</select></label>
    <label class="f">Χρώμα PDF<input class="in" type="color" data-sf="pdfColor" value="${an(e.v.pdfColor)}" style="height:42px;padding:2px;max-width:120px"></label>
    ${yi("terms","Όροι (κάτω στο PDF, ελληνικά)",4)}${yi("termsEn","Όροι στα αγγλικά (κενό = τα ελληνικά)",4)}
    ${dt("pubUrl","Διεύθυνση συνδέσμων προς πελάτες",'inputmode="url" placeholder="https://tech-mate.gr" autocapitalize="off"')}${nu("qrOn","QR στο PDF προς την Περιοχή πελάτη")}`}else n==="prices"?t=`${dt("vat","ΦΠΑ %",'inputmode="decimal"')}${dt("margin","Προεπιλεγμένο κέρδος % (για προϊόντα χωρίς δικό τους)",'inputmode="decimal"')}
    ${dt("next","Επόμενος αριθμός προσφοράς",'inputmode="numeric"')}${dt("validDays","Ισχύς προσφοράς (ημέρες, 0 = χωρίς)",'inputmode="numeric"')}
    ${dt("followDays","Υπενθύμιση για προσφορά χωρίς απάντηση μετά από (ημέρες, 0 = καμία)",'inputmode="numeric"')}${dt("warrantyMonths","Εγγύηση εγκατάστασης (μήνες)",'inputmode="numeric"')}
    ${nu("autoSale","Όταν μια προσφορά γίνεται δεκτή, να φτιάχνεται αυτόματα παραστατικό πώλησης")}
    <div class="upd">Προσοχή στον «Επόμενο αριθμό»: αν τον κατεβάσεις, θα ξαναδοθούν αριθμοί που υπάρχουν ήδη.</div>`:n==="mail"?t=`<div class="muted small">Μεταβλητές: {πελάτης} {αριθμός} {θέμα} {σύνολο} {εταιρεία} (αγγλικά: {customer} {number} {subject} {total} {company}). Το link της live προσφοράς δεν χρησιμοποιείται στην εφαρμογή.</div>
    ${dt("mailSubj","Θέμα email (πρότυπο)")}${yi("mailBody","Κείμενο email (πρότυπο)",9)}${dt("mailSubjEn","Θέμα email στα αγγλικά (πρότυπο)")}${yi("mailBodyEn","Κείμενο email στα αγγλικά (πρότυπο)",9)}`:n==="alerts"?t=`${dt("wxCity","Καιρός: τοποθεσία 1 (πάνω, δίπλα στο λογότυπο)")}${dt("wxCity2","Καιρός: τοποθεσία 2 (προαιρετικά)")}
    ${nu("autoRem","Αυτόματη υπενθύμιση για προσφορά χωρίς απάντηση")}${dt("remDays","…μετά από (ημέρες)",'inputmode="numeric"')}
    ${yi("warrantyTerms","Όροι εγγύησης στη βεβαίωση (κενό = προεπιλεγμένο κείμενο)",5)}`:n==="books"?t=`${dt("opening","Αρχικό υπόλοιπο τράπεζας €",'inputmode="decimal"')}${dt("costCats","Κατηγορίες κόστους (χωρισμένες με κόμμα)")}
    ${dt("backupDays","Υπενθύμιση όταν περάσουν Χ ημέρες χωρίς αντίγραφο (0 = καμία)",'inputmode="numeric"')}
    <div class="muted small">Η δημιουργία/επαναφορά αντιγράφου ασφαλείας γίνεται από το «Ειδοποιήσεις, widget & backup».</div>`:n==="banks"&&(t=e.v.banks.map((s,i)=>`<div class="card pad" style="margin:0 0 8px">
      ${["bank:Τράπεζα","iban:IBAN","holder:Δικαιούχος","afm:ΑΦΜ δικαιούχου"].map(r=>{const[a,o]=r.split(":");return`<label class="f">${o}<input class="in" data-sb="${i}:${a}" value="${an(s[a])}" ${a==="iban"?'autocapitalize="characters"':""}></label>`}).join("")}
      <button class="btn b2" data-st-bdel="${i}">🗑️ Αφαίρεση</button></div>`).join("")+'<button class="btn b2 wide" data-st-badd>＋ Νέος λογαριασμός</button>');return`${t}${G.msg?`<div class="err box">${an(G.msg)}</div>`:""}<div class="actions"><button class="btn b2" data-st-cancel>Άκυρο</button><button class="btn b1" data-st-save="${n}">Αποθήκευση</button></div>
  <div class="muted small">Αλλάζουν μόνο τα πεδία αυτής της ενότητας· όλα τα υπόλοιπα στοιχεία μένουν όπως είναι.</div>`}function RD(n){const e=se(),t=(s,i)=>`<div class="fld"><label>${s}</label><div class="v">${an(i)||"—"}</div></div>`;return n==="company"?`<div class="sm">${t("Επωνυμία",e.name)}${t("Email",e.bizEmail)}${t("Σύνδεσμοι πελατών",e.pubUrl)}</div>`:n==="prices"?`<div class="sm">${t("Επόμενη προσφορά","#"+A(e.next,1))}${t("Ισχύς προσφοράς",(e.validDays==null?15:e.validDays)+" ημέρες")}${t("Εγγύηση",A(e.warrantyMonths,24)+" μήνες")}</div>`:n==="banks"?`<div class="sm">${(e.banks||[]).filter(s=>s.iban).map(s=>t(s.bank||"Τράπεζα",s.iban)).join("")||'<div class="muted small">Κανένας λογαριασμός.</div>'}</div>`:""}function $D(n,e){return e(n("Ρυθμίσεις","Εταιρεία · PDF · Τιμές · Τράπεζες",'<a class="ib" href="#/menu">←</a>'),`<div class="card">${AD.map(([t,s,i,r])=>`<div class="acc${G.open===t?" open":""}"><button class="acc-h" data-st-open="${t}"><span class="ic">${s}</span><span class="t"><b>${i}</b><span>${an(r())}</span></span><span class="chev">${G.open===t?"▾":"▸"}</span></button>
      ${G.open===t?`<div class="acc-b">${PD(t)}</div>`:""}</div>`).join("")}</div>
    ${G.ok?`<div class="upd">${an(G.ok)}</div>`:""}
    <div class="card"><a class="mi" href="#/cset"><div class="ic">🔔</div><div class="t"><b>Ειδοποιήσεις, widget & backup</b><span>Υπενθυμίσεις · Microsoft To Do · Αντίγραφα ημερολογίου</span></div></a></div>
    <div class="muted small" style="padding:0 6px 10px">Push (Firebase), σύνδεση Microsoft για αποστολή email, PIN, ιστοσελίδα και Περιοχή πελάτη ρυθμίζονται μόνο από το PWA.</div>`,"menu")}function CD(n){return new Promise((e,t)=>{const s=new FileReader;s.onerror=()=>t(new Error("Δεν διαβάστηκε")),s.onload=()=>{const i=new Image;i.onerror=()=>t(new Error("Δεν είναι εικόνα")),i.onload=()=>{const r=Math.min(1,700/Math.max(i.naturalWidth,i.naturalHeight)),a=Math.max(1,Math.round(i.naturalWidth*r)),o=Math.max(1,Math.round(i.naturalHeight*r)),l=document.createElement("canvas");l.width=a,l.height=o;const u=l.getContext("2d"),h=n.type==="image/png";h||(u.fillStyle="#fff",u.fillRect(0,0,a,o)),u.drawImage(i,0,0,a,o),e({data:l.toDataURL(h?"image/png":"image/jpeg",.9),w:a,h:o})},i.src=s.result},s.readAsDataURL(n)})}function DD(n,e){const t=G.f.v,s={};if(n==="company"){const a=String(t.name||"").trim();if(!a)return G.msg="Γράψε επωνυμία.";const o=String(t.bizEmail||"").trim();if(o&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(o))return G.msg="Το email δεν φαίνεται σωστό.";const l=String(t.pubUrl||"").trim();if(l&&!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}(:\d+)?\/?$/i.test(l))return G.msg="Η διεύθυνση πρέπει να είναι σαν https://tech-mate.gr";Object.assign(s,{name:a,info:t.info,bizEmail:o,pdfColor:t.pdfColor,logoMM:A(t.logoMM,18),terms:t.terms,termsEn:t.termsEn,pubUrl:l,qrOn:!!t.qrOn})}else if(n==="prices"){const a=Tn(t.vat),o=Tn(t.margin),l=Tn(t.next),u=Tn(t.validDays),h=Tn(t.followDays),p=Tn(t.warrantyMonths);if([a,o,l,u,h,p].some(isNaN)||a<0||a>30||o<0||l<1||u<0||h<0||p<0)return G.msg="Έλεγξε τους αριθμούς (δεν μπορούν να είναι κενοί ή αρνητικοί).";const m=k.quotes.reduce((w,E)=>Math.max(w,A(E.number,0)),0);if(Math.floor(l)<=m&&Math.floor(l)!==A(se().next,1))return G.msg="Υπάρχουν ήδη προσφορές μέχρι το #"+m+". Ο επόμενος αριθμός πρέπει να είναι μεγαλύτερος.";Object.assign(s,{vat:a,margin:o,next:Math.floor(l),validDays:Math.floor(u),followDays:Math.floor(h),warrantyMonths:Math.floor(p),autoSale:!!t.autoSale})}else if(n==="mail")Object.assign(s,{mailSubj:t.mailSubj,mailBody:t.mailBody,mailSubjEn:t.mailSubjEn,mailBodyEn:t.mailBodyEn});else if(n==="alerts"){const a=Tn(t.remDays);if(isNaN(a)||a<1)return G.msg="Οι ημέρες υπενθύμισης πρέπει να είναι τουλάχιστον 1.";Object.assign(s,{wxCity:String(t.wxCity||"").trim(),wxCity2:String(t.wxCity2||"").trim(),autoRem:!!t.autoRem,remDays:Math.floor(a),warrantyTerms:t.warrantyTerms})}else if(n==="books"){const a=Tn(t.opening),o=Tn(t.backupDays);if(isNaN(a)||isNaN(o)||o<0)return G.msg="Έλεγξε τους αριθμούς.";const l={opening:a,costCats:String(t.costCats||"").split(",").map(h=>h.trim()).filter(Boolean)},u={};Object.keys(l).forEach(h=>{const p=G.f.v0,m=G.f.v;(h==="opening"?m.opening===p.opening:m.costCats===p.costCats)||(u[h]=l[h])}),Object.keys(u).length&&mo("books",u),t.backupDays!==G.f.v0.backupDays&&mo("meta",{backupDays:Math.floor(o)}),G.f=null,G.msg="",G.ok="Αποθηκεύτηκε.",e(G.ok);return}else if(n==="banks"&&(s.banks=t.banks.map(a=>({id:a.id,bank:a.bank.trim(),iban:a.iban.replace(/\s+/g,"").toUpperCase(),holder:a.holder.trim(),afm:a.afm.trim()})).filter(a=>a.bank||a.iban||a.holder),s.banks.some(a=>a.iban&&!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(a.iban))))return G.msg="Ένα IBAN δεν φαίνεται σωστό.";const i={};Object.keys(s).forEach(a=>{JSON.stringify(G.f.v[a])!==JSON.stringify(G.f.v0[a])&&(i[a]=s[a])}),n==="company"&&G.f.logo&&mo("logo",G.f.logo),Object.keys(i).length&&mo("main",i);const r=Object.keys(i).length+(G.f.logo?1:0);G.f=null,G.msg="",G.ok=r?"Αποθηκεύτηκε.":"Καμία αλλαγή.",e(G.ok)}function ND(n,e,t){const s=n.closest("[data-st-open],[data-st-edit],[data-st-cancel],[data-st-save],[data-st-badd],[data-st-bdel]");if(!s)return!1;const i=s.dataset;if(i.stOpen){if(G.f)return!0;G.open=G.open===i.stOpen?"":i.stOpen,G.ok="",G.open==="lock"&&m$(e)}else i.stEdit?(G.f={k:i.stEdit,v:cg[i.stEdit](),v0:JSON.parse(JSON.stringify(cg[i.stEdit]())),logo:null},G.msg="",G.ok=""):i.stCancel!==void 0?(G.f=null,G.msg=""):i.stSave?DD(i.stSave,t):i.stBadd!==void 0?G.f.v.banks.push({id:Qe(),bank:"",iban:"",holder:"",afm:""}):i.stBdel!==void 0&&G.f.v.banks.splice(+i.stBdel,1);return e(),!0}function xD(n){const e=n.dataset;if(e.sf&&G.f)return G.f.v[e.sf]=n.type==="checkbox"?n.checked:n.value,G.msg="",!0;if(e.sb&&G.f){const[t,s]=e.sb.split(":");return G.f.v.banks[+t][s]=n.value,G.msg="",!0}return!1}function VD(n,e){const t=n.dataset;return t.sl!==void 0&&G.f&&n.files&&n.files[0]?((async()=>{try{G.f.logo=await CD(n.files[0]),G.msg=""}catch(s){G.msg=s.message}e()})(),!0):t.sf&&G.f&&n.tagName==="SELECT"?(G.f.v[t.sf]=n.value,!0):!1}const en=document.getElementById("app"),de=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Eo=n=>A(n).toLocaleString("el-GR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €",Zi=n=>Math.round(A(n)).toLocaleString("el-GR")+" €",OD=n=>n?new Date(n).toLocaleDateString("el-GR",{day:"numeric",month:"short"}):"",u_=n=>String(n||"?").split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]).join("").toUpperCase(),MD={pending:"p-a",accepted:"p-ok",done:"p-ok",rejected:"p-b"};let dn=null,zt=!1;const st={qf:"all",cq:"",stAsk:null};let Ue=null;const LD=[["home","🏠","Αρχική"],["cal","📅","Ημερολόγιο"],["quotes","📄","Προσφορές"],["custs","👥","Πελάτες"],["menu","☰","Μενού"]],FD=n=>`<nav class="nav">${LD.filter(([e])=>!Te()||e==="cal"||e==="menu").map(([e,t,s])=>`<a href="#/${e}" class="${e===n?"on":""}"><i>${t}</i>${s}</a>`).join("")}</nav>`,$e=(n,e,t="",s="")=>`<header class="top">${t}<h1>${de(n)}${e?`<span class="sm">${de(e)}</span>`:""}</h1>${s}</header>`,er=n=>`<a class="ib" href="#/${n}">←</a>`,xe=(n,e,t,s="")=>`${n}<main class="body">${e}</main>${s}${t?FD(t):""}`;function UD(n=""){return`<div class="login"><img class="lico" src="/icon-192.png" alt=""><div class="logo">TechMate</div><p>Συνδέσου με τον ίδιο λογαριασμό που έχεις στο PWA.</p>
  <form id="lf"><label>Email<input name="e" type="email" autocomplete="username" required></label>
  <label>Κωδικός<input name="p" type="password" autocomplete="current-password" required></label>
  <label class="chk"><input type="checkbox" id="sp"> Εμφάνιση κωδικού</label>
  ${n?`<div class="err">${de(n)}</div>`:""}<button class="btn b1">Σύνδεση</button></form></div>`}function qD(){return k.quotes.filter(n=>!mn(n)&&pt(n)==="pending")}function Gu(){return Ge.state==="downloading"?`<div class="upd">⬇️ Κατεβαίνει η έκδοση ${de(Ge.latest.version)}… ${Ge.pct}%</div>`:Ge.state!=="available"?"":`<div class="upd">⬇️ Νέα έκδοση ${de(Ge.latest.version)}${Ge.latest.notes?": "+de(Ge.latest.notes):""}${Ge.needApk?"<br>Χρειάζεται νέο αρχείο εγκατάστασης (APK).":""}${Ge.err?`<br><span class="bad">${de(Ge.err)}</span>`:""}
    <button class="btn b1 sm" data-up="apply">${Ge.needApk?"Λήψη APK":"Ενημέρωση τώρα"}</button></div>`}function lg(){const n={checking:"Έλεγχος…",none:"Έχεις την τελευταία έκδοση.",error:Ge.err}[Ge.state]||"";return`<div class="card pad ver"><div><b>TechMate ${de(Eb)}</b>${n?`<span>${de(n)}</span>`:""}</div><button class="btn b2 sm" data-up="check">Έλεγχος ενημέρωσης</button></div>`}function ug(){const n=new Date,e=new Date(n.getFullYear(),n.getMonth(),1).getTime(),t=k.quotes.filter(o=>!mn(o)&&["accepted","done"].includes(pt(o))&&(o.ts||0)>=e).reduce((o,l)=>o+A(l.total),0),s=k.ldocs.filter(o=>o.kind==="sale").reduce((o,l)=>o+mb(l),0),i=nR(),r=n.getHours(),a=r<12?"Καλημέρα":r<18?"Καλησπέρα":"Καλό βράδυ";return xe($e("TechMate",`${a} · ${n.toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}`,"",'<a class="ib" href="#/menu">👤</a>'),`${ni?'<div class="upd">🧪 Δοκιμαστικά δεδομένα (preview)</div>':""}${Gu()}
    <div class="qa six"><a href="#/edit/new"><i>📝</i>Προσφορά</a><a data-hnew=""><i>📅</i>Ραντεβού</a><a data-hnew="due"><i>💶</i>Λήξη</a><a href="#/books/newdoc"><i>🧾</i>Έξοδο</a><a href="#/soon/Φωτογραφίες"><i>📷</i>Φωτο</a><a data-bcscan><i>🔍</i>Barcode</a></div>
    <div class="kpis">
      <a class="kpi" href="#/quotes"><b>${qD().length}</b><span>Σε αναμονή απάντησης</span></a>
      <div class="kpi"><b>${Zi(t)}</b><span>Δεκτές αυτόν τον μήνα</span></div>
      <a class="kpi" href="#/custs"><b>${yn().length}</b><span>Πελάτες</span></a>
      <div class="kpi"><b class="${s>0?"bad":""}">${Zi(s)}</b><span>Μου χρωστούν</span></div>
    </div>
    <div class="h">Σήμερα <a class="hl" href="#/cal">Ημερολόγιο ›</a></div>
    <div class="card">${i.today.length?i.today.map(o=>os(o,!1)).join(""):'<div class="empty">Τίποτα για σήμερα 🙂</div>'}</div>
    ${i.late.length?`<div class="h badh">⚠️ Εκκρεμούν από πριν (${i.late.length})</div><div class="card">${i.late.slice(0,5).map(o=>os(o,!0)).join("")}${i.late.length>5?`<a class="empty" href="#/cal">+${i.late.length-5} ακόμα ›</a>`:""}</div>`:""}
    ${i.dues.length?`<div class="h">💶 Λήξεις & πληρωμές (14 μέρες)</div><div class="card">${i.dues.map(o=>os(o,!0)).join("")}</div>`:""}`,"home")}function d_(n){const e=pt(n),t=n.customer&&n.customer.name||"";return`<a class="row" href="#/q/${encodeURIComponent(n.id)}"><div class="av">${de(u_(t))}</div>
  <div class="t"><b>${de(n.subject||"(χωρίς θέμα)")}</b><span>#${de(n.number||"—")} · ${de(t)} · ${OD(n.ts)}</span></div>
  <div class="r"><div class="amt">${Zi(n.total)}</div><span class="pill ${MD[e]||"p-a"}">${Mo[e]||e}</span></div></a>`}function jD(){const n=k.quotes.filter(s=>!mn(s)).sort((s,i)=>(i.ts||0)-(s.ts||0)),e=[["all","Όλες"],["pending","Σε αναμονή"],["accepted","Δεκτές"],["done","Ολοκληρ."],["rejected","Απορρίφθ."]],t=st.qf==="all"?n:n.filter(s=>pt(s)===st.qf);return xe($e("Προσφορές",`${n.length} συνολικά`),`<div class="chips">${e.map(([s,i])=>`<button data-qf="${s}" class="${st.qf===s?"on":""}">${i}</button>`).join("")}</div>
    <div class="card">${t.length?t.map(d_).join(""):`<div class="empty">${zt?"Καμία προσφορά":"Φόρτωση…"}</div>`}</div>`,"quotes",'<a class="fab" href="#/edit/new">＋</a>')}function BD(n){const e=k.quotes.find(a=>a.id===n);if(!e)return xe($e("Προσφορά","",er("quotes")),`<div class="empty">${zt?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"quotes");const t=pt(e),s=e.customer||{},i=e.lines||[],r=i.reduce((a,o)=>a+A(o.qty)*A(o.price)*(1-A(o.disc)/100),0);return xe($e(`#${e.number||"—"}`,Mo[t],er("quotes")),`<div class="card"><div class="fld"><label>Πελάτης</label><a class="v" href="#/c/${encodeURIComponent(qe(s.name)||"_none")}">${de(s.name)} ›</a></div>
    <div class="fld" style="margin:0"><label>Θέμα</label><div class="v">${de(e.subject)}</div></div></div>
    <div class="h">Κατάσταση</div>
    <div class="card pad"><div class="seg four">${Object.keys(Mo).map(a=>`<button data-st="${a}" class="${a===t?"on":""}">${Mo[a]}</button>`).join("")}</div>
    ${st.stAsk&&st.stAsk.id===e.id?`<div class="ask"><b>Αλλαγή σε «${de(Lo[st.stAsk.st])}»;</b>${HA(e,st.stAsk.st).map(a=>`<div>• ${de(a)}</div>`).join("")}
      <div class="actions"><button class="btn b2" data-stno>Άκυρο</button><button class="btn b1" data-stok>Ναι, αλλαγή</button></div></div>`:""}</div>
    <div class="h">Είδη (${i.length})</div>
    <div class="card">${i.map(a=>`<div class="item"><div class="t"><b>${de(a.desc)}</b><span>${A(a.qty)} × ${Eo(a.price)}${A(a.disc)?` · −${A(a.disc)}%`:""}</span></div><div class="amt">${Eo(A(a.qty)*A(a.price)*(1-A(a.disc)/100))}</div></div>`).join("")||'<div class="empty">Χωρίς είδη</div>'}</div>
    <div class="card"><div class="tot"><span>Καθαρό</span><span>${Eo(r)}</span></div>
    <div class="tot big"><span>Σύνολο${e.vatMode==="off"?" (χωρίς ΦΠΑ)":" με ΦΠΑ"}</span><span>${Eo(e.total)}</span></div></div>${ID()}`,null,`<div class="bar"><a class="btn b2" href="#/edit/${encodeURIComponent(e.id)}">✏️ Επεξεργασία</a><button class="btn b2" data-qappt="${de(e.id)}">📅 Ραντεβού</button><button class="btn b1" data-sdq="${de(e.id)}">📤 PDF</button></div>`)}function WD(){const n=qe(st.cq),e=yn().filter(t=>!n||qe(t.name).includes(n)).sort((t,s)=>(s.last||0)-(t.last||0));return xe($e("Πελάτες",`${e.length}`),`<input class="search" id="cq" placeholder="🔍 Αναζήτηση πελάτη" value="${de(st.cq)}">
    <div class="card">${e.map(t=>`<a class="row" href="#/c/${encodeURIComponent(t.k)}"><div class="av">${de(u_(t.name))}</div>
      <div class="t"><b>${de(t.name)}</b><span>${t.quotes.length} προσφορές${t.info.phone?" · "+de(t.info.phone):""}</span></div>
      <div class="r">${t.owed>0?`<div class="amt bad">${Zi(t.owed)}</div><span class="muted">χρωστάει</span>`:""}</div></a>`).join("")||`<div class="empty">${zt?"Κανένας πελάτης":"Φόρτωση…"}</div>`}</div>`,"custs",'<a class="fab" href="#/ce/new">＋</a>')}function zD(n){const e=yn().find(i=>i.k===n);if(!e)return xe($e("Πελάτης","",er("custs")),`<div class="empty">${zt?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"custs");const t=e.info,s=t.phone.replace(/\s/g,"");return xe($e(e.name,[t.address,t.phone].filter(Boolean).join(" · "),er("custs"),s?`<a class="ib" href="tel:${de(s)}">📞</a>`:""),`<div class="kpis"><div class="kpi"><b>${Zi(e.won)}</b><span>Δεκτές προσφορές</span></div><div class="kpi"><b class="${e.owed>0?"bad":""}">${Zi(e.owed)}</b><span>Υπόλοιπο</span></div></div>
    <div class="actions">${s?`<a class="btn b2" href="viber://chat?number=${de(s.startsWith("+")?s:"+30"+s)}">💬 Viber</a>`:""}
    ${t.address?`<a class="btn b2" href="https://maps.google.com/?q=${encodeURIComponent(t.address)}">🗺️ Οδηγίες</a>`:""}
    ${t.email?`<a class="btn b2" href="mailto:${de(t.email)}">✉️ Email</a>`:""}</div>
    <div class="actions"><a class="btn b2" href="#/ce/${encodeURIComponent(e.k)}">✏️ Στοιχεία</a><button class="btn b2" data-newq="${de(e.k)}">＋ Προσφορά</button><button class="btn b2" data-newt="${de(e.k)}">＋ Εργασία</button></div>
    ${e.rec&&e.rec.notes?`<div class="card pad note">${de(e.rec.notes)}</div>`:""}
    <div class="h">Προσφορές (${e.quotes.length})</div>
    <div class="card">${e.quotes.sort((i,r)=>(r.ts||0)-(i.ts||0)).map(d_).join("")||'<div class="empty">Καμία</div>'}</div>
    ${e.mins.length?`<div class="h">Παλιές εγκαταστάσεις (${e.mins.length})</div>`:""}
    <div class="h">Τιμολόγια & φωτογραφίες</div><div class="card">${e.quotes.filter(i=>pt(i)==="done").map(i=>`<a class="row" href="#/files/${encodeURIComponent(i.id)}"><div class="av">📷</div><div class="t"><b>#${de(i.number||"—")} ${de(i.subject||"")}</b><span>${Xi(i).length} τιμολόγια · ${Ta(i).length} φωτογραφίες</span></div></a>`).join("")||'<div class="empty">Θα εμφανιστούν όταν υπάρχει ολοκληρωμένη εγκατάσταση.</div>'}</div>`,"custs")}const xr=(n,e,t="")=>`<label class="f">${e}<input class="in" data-f="${n}" value="${de(Ue.v[n]||"")}" ${t}></label>`,GD=n=>`${Ue.msg?`<div class="err box">${de(Ue.msg)}</div>`:""}`,KD='<div class="bar"><button class="btn b2" data-fa="cancel">Άκυρο</button><button class="btn b1" data-fa="save">💾 Αποθήκευση</button></div>';function HD(n){if(!Ue||Ue.kind!=="cust"||Ue.arg!==n){const e=n!=="new"&&yn().find(t=>t.k===n);if(n!=="new"&&!e)return xe($e("Πελάτης","",er("custs")),`<div class="empty">${zt?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);Ue={kind:"cust",arg:n,v:e?{name:e.name,...e.info,notes:e.rec&&e.rec.notes||""}:{name:""}}}return`${$e(n==="new"?"Νέος πελάτης":"Στοιχεία πελάτη","",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${xr("name","Όνομα",'autocomplete="off"')}${xr("phone","Τηλέφωνο",'inputmode="tel"')}${xr("email","Email",'inputmode="email"')}${xr("afm","ΑΦΜ",'inputmode="numeric"')}${xr("address","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${de(Ue.v.notes||"")}</textarea></label></div>
    ${n!=="new"&&qe(Ue.v.name)!==n?'<div class="upd">Η αλλαγή ονόματος θα περάσει και στις προσφορές, στα παραστατικά και στις εισπράξεις του πελάτη.</div>':""}${GD()}</main>${KD}`}function QD(n){if(n==="cancel"){const t=Ue.arg;return Ue=null,location.replace(t==="new"?"#/custs":"#/c/"+encodeURIComponent(t))}const e=JA(Ue.arg==="new"?"":Ue.arg,Ue.v);if(!e.ok)return Ue.msg=e.msg,oe();Ue=null,location.replace("#/c/"+encodeURIComponent(e.k))}const JD=[["📄","Προσφορές","Νέα · Κατάλογος · Αποθηκευμένες · Κατάσταση · Δεκτές & παραγγελίες · Ιστορικό αλλαγών · Διαγραμμένα","#/quotes"],["📒","Λογιστικά","Σύνοψη · Παραστατικά · Πληρωμές · Υπόλοιπα","#/books/sum"],["🗂️","Κατάλογος προϊόντων","Προσθήκη · Αλλαγή · Τιμές · Φωτογραφίες · Προμηθευτές","#/cat"],["🛡️","Εγκαταστάσεις","Εγγυήσεις · Συντηρήσεις","#/inst"],["👷","Μεροκάματα","Καταχώρηση · Πληρωμή υπαλλήλου · Υπόλοιπα","#/wages"],["📦","Αποθήκη","Απόθεμα · Κινήσεις · Λίστα παραγγελίας · Εργαλεία που λείπουν","#/stock"],["📨","Μηνύματα ιστοσελίδας","Αιτήματα από τη φόρμα επικοινωνίας","#/msgs"],["🌐","Ιστοσελίδα","Περιεχόμενο · Φωτογραφίες έργων · Άρθρα · Βοηθήματα","#/web"],["📅","Ημερολόγιο & ειδοποιήσεις","Υπενθυμίσεις · Widget · Χρώματα · Backup · Microsoft To Do","#/cset"],["🕘","Ιστορικό ενεργειών","Τι άλλαξε και πότε · αναίρεση αλλαγών · επαναφορά διαγραμμένων","#/hist"],["⚙️","Ρυθμίσεις","Εταιρεία & PDF · Τιμές/αρίθμηση · Τράπεζες · Χρήστες ομάδας · Ειδοποιήσεις · Backup","#/set"]];function YD(){return Te()?xe($e("Μενού",dn?dn.email:""),`<div class="card"><a class="mi" href="#/wages"><div class="ic">👷</div><div class="t"><b>Τα μεροκάματά μου</b><span>Καταχώρηση · Υπόλοιπο · Πληρωμές</span></div></a><a class="mi" href="#/stock"><div class="ic">🧰</div><div class="t"><b>Εργαλεία που λείπουν</b><span>Γράψε ό,τι χρειάζεται να παραγγελθεί</span></div></a><a class="mi" href="#/cset"><div class="ic">📅</div><div class="t"><b>Ημερολόγιο & ειδοποιήσεις</b><span>Υπενθυμίσεις · Widget · Χρώματα</span></div></a></div>${Gu()}${lg()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu"):xe($e("Μενού",dn?dn.email:""),`<div class="card">${JD.map(([n,e,t,s])=>`<a class="mi" href="${s||"#/soon/"+e}"><div class="ic">${n}</div><div class="t"><b>${e}${s?"":' <span class="soon">από το PWA</span>'}</b><span>${t}</span></div></a>`).join("")}</div>
    ${Gu()}${lg()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu")}function XD(n){const e=(se()&&se().pubUrl||"").replace(/\/?$/,"/");return xe($e(n,"",'<a class="ib" href="javascript:history.back()">←</a>'),`<div class="card"><div class="empty">🛠️ Το «${de(n)}» γίνεται προς το παρόν από το PWA και φαίνεται αμέσως εδώ όπου χρειάζεται.${se()&&se().pubUrl?`<br><br><a class="btn b1" href="${de(e)}app/" target="_blank" rel="noopener">Άνοιγμα του PWA</a>`:""}</div></div>`,null)}function oe(){if(!dn)return;const[n,e]=location.hash.replace(/^#\//,"").split("/").map(decodeURIComponent),t={home:ug,quotes:jD,q:()=>BD(e),custs:WD,c:()=>zD(e),cal:()=>Lm(zt,$e,xe,e),agenda:()=>Lm(zt,$e,xe),t:()=>zP(e,zt,$e,xe),cset:()=>KP($e,xe),wages:()=>TR($e,xe),wage:()=>Wb(e,$e,xe,!1),stock:()=>RR($e,xe),inst:()=>OR($e,xe),set:()=>$D($e,xe),cat:()=>HC($e,xe),web:()=>MC($e,xe),hist:()=>s$($e,xe),sn:()=>KR(e,$e,xe),msgs:()=>yR($e,xe),files:()=>uR(e,$e,xe),menu:YD,soon:()=>XD(e)};if(n==="edit")return h_(e);_P(),Object.assign(t,{ce:()=>HD(e),books:()=>hP(e,zt)}),n!=="ce"&&(Ue=null),n!=="t"&&OP(),n!==st.lastR&&(ER(),_D(),SD(),WC(),st.lastR=n),M.openNext&&(Qb(M.openNext),M.openNext=""),n!=="q"&&(st.stAsk=null),n==="files"&&!Oe.st&&_h(oe),n==="hist"&&!Ve.list&&!Ve.loading&&zu(oe),n!=="hist"&&(Ve.list=null),n!=="files"&&(Oe.st=null,Oe.msg=""),n==="msgs"&&!kt.list&&!kt.busy&&gR(oe),n!=="msgs"&&(kt.list=null),n!=="books"&&sP();const s=scrollY,i=Te()&&!["cal","t","menu","cset","wages","stock"].includes(n)?t.cal:t[n]||ug;if(en.innerHTML=i(),n==="custs"){const a=document.getElementById("cq");a.oninput=()=>{st.cq=a.value,oe();const o=document.getElementById("cq");o.focus(),o.setSelectionRange(o.value.length,o.value.length)}}const r=document.getElementById("out");r&&(r.onclick=()=>{confirm("Αποσύνδεση; Οι υπενθυμίσεις σε αυτό το κινητό θα σταματήσουν μέχρι να ξανασυνδεθείς.")&&(ue.clearSession(),Sc="",pb())}),scrollTo(0,s)}const ZD=(n,e)=>e?location.replace(n):location.hash=n;en.addEventListener("change",n=>{mR(n.target,oe)||XR(n.target)||VD(n.target,oe)||eD(n.target,oe)||jC(n.target,oe,tt)||eR(n.target,oe,tt)||qR(n.target,oe)||gP(n.target,oe)});en.addEventListener("keydown",n=>tR(n,oe,tt));en.addEventListener("touchstart",n=>jb(n,oe),{passive:!0});en.addEventListener("touchend",n=>jb(n,oe),{passive:!0});en.addEventListener("click",n=>{if(XP(n.target,oe,tt)||pR(n.target,oe,tt)||vR(n.target,oe)||t_(n.target,oe,tt)||v$(n.target,oe,tt)||ND(n.target,oe,tt)||XC(n.target,oe,tt)||qC(n.target,oe,tt)||i$(n.target,oe,tt)||kD(n.target,oe,tt)||FR(n.target,oe,tt)||pP(n.target,ZD,oe,tt))return;const e=n.target.closest("[data-up],[data-qf],[data-st],[data-stok],[data-stno],[data-fa],[data-newq],[data-newt],[data-hnew],[data-qappt]");if(!e)return;const t=e.dataset,s=decodeURIComponent(location.hash.split("/")[2]||"");if(t.up){t.up==="apply"?BA():Lu(!0);return}if(t.hnew!==void 0){Ni({kind:t.hnew,date:ve()}),location.hash="#/t/new";return}if(t.qappt){const i=k.quotes.find(a=>a.id===t.qappt),r=i&&i.customer||{};Ni({quoteId:t.qappt,cust:r.name||"",tel:r.phone||"",addr:r.address||"",title:"Εγκατάσταση – "+(r.name||""),date:ve()}),location.hash="#/t/new";return}if(t.qf)st.qf=t.qf;else if(t.st){const i=k.quotes.find(r=>r.id===s);st.stAsk=i&&pt(i)!==t.st?{id:s,st:t.st}:null}else if("stno"in t)st.stAsk=null;else if("stok"in t){const i=QA(st.stAsk.id,st.stAsk.st);st.stAsk=null,i.msg&&tt(i.msg)}else{if(t.fa)return Ue&&QD(t.fa);if(t.newq){const i=yn().find(r=>r.k===t.newq);i&&wP({name:i.name,...i.info}),location.hash="#/edit/new";return}else if(t.newt){const i=yn().find(r=>r.k===t.newt);i&&Ni({cust:i.name,tel:i.info.phone||"",addr:i.info.address||"",date:ve()}),location.hash="#/t/new";return}}oe()});en.addEventListener("input",n=>{const e=n.target;y$(e)||xD(e)||ZC(e,oe)||$h(e)||ZP(e,oe)||UR(e,oe)||mP(e,oe)||Ue&&e.dataset.f&&(Ue.v[e.dataset.f]=e.type==="checkbox"?e.checked:e.value,Ue.msg&&(Ue.msg=""))});addEventListener("hashchange",()=>{scrollTo(0,0),location.hash.startsWith("#/cset")&&yh(oe),oe()});function h_(n){const e=scrollY,t=kP(n);if(t===null){en.innerHTML=xe($e("Προσφορά","",er("quotes")),`<div class="empty">${zt?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);return}en.innerHTML=t,SP(en,()=>h_(n),s=>location.replace(s?"#/q/"+encodeURIComponent(s):"#/quotes")),scrollTo(0,e)}function tt(n,e){let t=document.getElementById("toast");if(t||(t=document.createElement("div"),t.id="toast",document.body.appendChild(t)),t.textContent=n,e){const s=document.createElement("button");s.textContent=e.label,s.onclick=()=>{t.className="",e.fn()},t.appendChild(s)}t.className="show"+(e?" act":""),clearTimeout(tt.t),tt.t=setTimeout(()=>t.className="",6e3)}gA(n=>tt(n&&n.code==="permission-denied"?"Δεν έχεις δικαίωμα για αυτή την αλλαγή. Δεν αποθηκεύτηκε.":"Η αποθήκευση απέτυχε: "+(n&&(n.code||n.message)||"άγνωστο σφάλμα")));qA(()=>{dn&&!lh()&&!Ue&&!oh()&&!gh()&&!Eh()&&!Dh()&&!Nh()&&!Ch()&&!Rh()&&!kh()&&!bh()&&oe()});jA();ni&&(window.__tm={data:k,hitFind:e_,get goBack(){return m_}});let Sc="";function e1(){const n=hA();if(!On||!n||!Object.keys(k.st).length)return;const e=as()||{},t={uid:n.uid,email:n.email||"",role:Te()?"team":"owner",empId:Zt(),name:e.name||"",rt:n.refreshToken||"",apiKey:Vu.apiKey,project:Vu.projectId},s=JSON.stringify(t);s!==Sc&&(Sc=s,ue.setSession(t))}function f_(n){!n||!dn||(n.task?location.hash="#/t/"+encodeURIComponent(n.task):n.isNew&&(Ni({date:ve()}),location.hash="#/t/new"))}si("open",f_);si("toast",n=>n&&n.text&&tt(n.text));si("files",()=>{location.hash.startsWith("#/files")&&_h(oe)});si("ms",()=>{location.hash.startsWith("#/cset")&&yh(oe)});let dg=!1,Ku=!1;dA(()=>{zt=!0,e1(),sR(),!Ku&&k.tasks.length&&k.quotes.length&&(Ku=!0,setTimeout(()=>HP(zt),4e3)),!(lh()||Ue||oh()||gh()||Eh()||Dh()||Nh()||Ch()||Rh()||kh()||bh())&&oe()});document.addEventListener("visibilitychange",()=>{!document.hidden&&dn&&(Ku=!1,oe())});va().then(()=>{fA(n=>{if(dn=n,!n){Sc="",p_();return}location.hash.startsWith("#/cset")&&yh(oe),oe(),dg||(dg=!0,ue.takeLaunch().then(f_))})});function p_(n="",e=""){en.innerHTML=UD(n);const t=document.getElementById("lf");t.e.value=e,document.getElementById("sp").onchange=s=>{t.p.type=s.target.checked?"text":"password"},document.getElementById("lf").onsubmit=s=>{s.preventDefault();const i=s.target;mA(i.e.value.trim(),i.p.value).catch(r=>{const a=r&&r.code||"",l=["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(a)?"Λάθος email ή κωδικός.":a==="auth/network-request-failed"?"Δεν υπάρχει σύνδεση στο internet.":a==="auth/too-many-requests"?"Πολλές προσπάθειες. Δοκίμασε ξανά σε λίγα λεπτά.":"Η σύνδεση μπλοκαρίστηκε.";p_(l+" ["+(a||r&&r.message||"άγνωστο")+"]",i.e.value)})}}const hg=n=>{const e=document.querySelector(n);return e?(e.click(),!0):!1};function m_(){if(hg('#scan-ov [data-sc="close"]')||hg(".sheet .sheet-h button"))return;if((location.hash.replace(/^#\//,"").split("/")[0]||"home")==="home")return ue.minimize();const e=[...document.querySelectorAll(".top .ib")].find(t=>t.textContent.trim()==="←");if(e)return e.click();location.hash="#/home"}si("back",()=>{c$()||m_()});let g_=0;const t1=()=>g_=Date.now()+18e4;document.addEventListener("click",n=>{n.target.closest&&n.target.closest('input[type=file],label:has(input[type=file]),[data-sd],[data-sn-scan],[data-bcscan],[data-fl="login"]')&&t1()},!0);const y_=()=>{if(Date.now()<g_||lh()||Ue||oh()||gh()||Eh()||Dh()||Nh()||Ch()||Rh()||kh()||bh())return;(location.hash.replace(/^#\//,"").split("/")[0]||"home")!=="home"&&dn&&location.replace("#/home")};document.addEventListener("visibilitychange",()=>{document.hidden&&y_()});si("home",y_);o$();h$({logout:pb,buzz:Ec});export{Rm as A,ih as W,zn as _};
