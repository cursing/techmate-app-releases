(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))s(r);new MutationObserver(r=>{for(const i of r)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function t(r){const i={};return r.integrity&&(i.integrity=r.integrity),r.referrerPolicy&&(i.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?i.credentials="include":r.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function s(r){if(r.ep)return;r.ep=!0;const i=t(r);fetch(r.href,i)}})();var ch={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gf=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let r=n.charCodeAt(s);r<128?e[t++]=r:r<2048?(e[t++]=r>>6|192,e[t++]=r&63|128):(r&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(r=65536+((r&1023)<<10)+(n.charCodeAt(++s)&1023),e[t++]=r>>18|240,e[t++]=r>>12&63|128,e[t++]=r>>6&63|128,e[t++]=r&63|128):(e[t++]=r>>12|224,e[t++]=r>>6&63|128,e[t++]=r&63|128)}return e},V_=function(n){const e=[];let t=0,s=0;for(;t<n.length;){const r=n[t++];if(r<128)e[s++]=String.fromCharCode(r);else if(r>191&&r<224){const i=n[t++];e[s++]=String.fromCharCode((r&31)<<6|i&63)}else if(r>239&&r<365){const i=n[t++],o=n[t++],c=n[t++],l=((r&7)<<18|(i&63)<<12|(o&63)<<6|c&63)-65536;e[s++]=String.fromCharCode(55296+(l>>10)),e[s++]=String.fromCharCode(56320+(l&1023))}else{const i=n[t++],o=n[t++];e[s++]=String.fromCharCode((r&15)<<12|(i&63)<<6|o&63)}}return e.join("")},_f={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let r=0;r<n.length;r+=3){const i=n[r],o=r+1<n.length,c=o?n[r+1]:0,l=r+2<n.length,u=l?n[r+2]:0,f=i>>2,p=(i&3)<<4|c>>4;let y=(c&15)<<2|u>>6,S=u&63;l||(S=64,o||(y=64)),s.push(t[f],t[p],t[y],t[S])}return s.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(gf(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):V_(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let r=0;r<n.length;){const i=t[n.charAt(r++)],c=r<n.length?t[n.charAt(r)]:0;++r;const u=r<n.length?t[n.charAt(r)]:64;++r;const p=r<n.length?t[n.charAt(r)]:64;if(++r,i==null||c==null||u==null||p==null)throw new N_;const y=i<<2|c>>4;if(s.push(y),u!==64){const S=c<<4&240|u>>2;if(s.push(S),p!==64){const k=u<<6&192|p;s.push(k)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class N_ extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const x_=function(n){const e=gf(n);return _f.encodeByteArray(e,!0)},yf=function(n){return x_(n).replace(/\./g,"")},vf=function(n){try{return _f.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function O_(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const L_=()=>O_().__FIREBASE_DEFAULTS__,M_=()=>{if(typeof process>"u"||typeof ch>"u")return;const n=ch.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},$_=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&vf(n[1]);return e&&JSON.parse(e)},zo=()=>{try{return L_()||M_()||$_()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},F_=n=>{var e,t;return(t=(e=zo())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},If=()=>{var n;return(n=zo())===null||n===void 0?void 0:n.config},wf=n=>{var e;return(e=zo())===null||e===void 0?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U_{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ce(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function B_(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Ce())}function q_(){var n;const e=(n=zo())===null||n===void 0?void 0:n.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function j_(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function G_(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function z_(){const n=Ce();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function Ef(){return!q_()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function bf(){try{return typeof indexedDB=="object"}catch{return!1}}function K_(){return new Promise((n,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",r=self.indexedDB.open(s);r.onsuccess=()=>{r.result.close(),t||self.indexedDB.deleteDatabase(s),n(!0)},r.onupgradeneeded=()=>{t=!1},r.onerror=()=>{var i;e(((i=r.error)===null||i===void 0?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const W_="FirebaseError";class jt extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=W_,Object.setPrototypeOf(this,jt.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,hi.prototype.create)}}class hi{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},r=`${this.service}/${e}`,i=this.errors[e],o=i?H_(i,s):"Error",c=`${this.serviceName}: ${o} (${r}).`;return new jt(r,c,s)}}function H_(n,e){return n.replace(Q_,(t,s)=>{const r=e[s];return r!=null?String(r):`<${s}?>`})}const Q_=/\{\$([^}]+)}/g;function J_(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function Gr(n,e){if(n===e)return!0;const t=Object.keys(n),s=Object.keys(e);for(const r of t){if(!s.includes(r))return!1;const i=n[r],o=e[r];if(lh(i)&&lh(o)){if(!Gr(i,o))return!1}else if(i!==o)return!1}for(const r of s)if(!t.includes(r))return!1;return!0}function lh(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function di(n){const e=[];for(const[t,s]of Object.entries(n))Array.isArray(s)?s.forEach(r=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(r))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function Rr(n){const e={};return n.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[r,i]=s.split("=");e[decodeURIComponent(r)]=decodeURIComponent(i)}}),e}function Pr(n){const e=n.indexOf("?");if(!e)return"";const t=n.indexOf("#",e);return n.substring(e,t>0?t:void 0)}function Y_(n,e){const t=new X_(n,e);return t.subscribe.bind(t)}class X_{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let r;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");Z_(e,["next","error","complete"])?r=e:r={next:e,error:t,complete:s},r.next===void 0&&(r.next=Ka),r.error===void 0&&(r.error=Ka),r.complete===void 0&&(r.complete=Ka);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?r.error(this.finalError):r.complete()}catch{}}),this.observers.push(r),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Z_(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function Ka(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xe(n){return n&&n._delegate?n._delegate:n}class Kn{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nn="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ey{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new U_;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const r=this.getOrInitializeService({instanceIdentifier:t});r&&s.resolve(r)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const s=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(i){if(r)return null;throw i}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(ny(e))try{this.getOrInitializeService({instanceIdentifier:Nn})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:r});s.resolve(i)}catch{}}}}clearInstance(e=Nn){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Nn){return this.instances.has(e)}getOptions(e=Nn){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[i,o]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(i);s===c&&o.resolve(r)}return r}onInit(e,t){var s;const r=this.normalizeInstanceIdentifier(t),i=(s=this.onInitCallbacks.get(r))!==null&&s!==void 0?s:new Set;i.add(e),this.onInitCallbacks.set(r,i);const o=this.instances.get(r);return o&&e(o,r),()=>{i.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const r of s)try{r(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:ty(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=Nn){return this.component?this.component.multipleInstances?e:Nn:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function ty(n){return n===Nn?void 0:n}function ny(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sy{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new ey(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ne;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(ne||(ne={}));const ry={debug:ne.DEBUG,verbose:ne.VERBOSE,info:ne.INFO,warn:ne.WARN,error:ne.ERROR,silent:ne.SILENT},iy=ne.INFO,oy={[ne.DEBUG]:"log",[ne.VERBOSE]:"log",[ne.INFO]:"info",[ne.WARN]:"warn",[ne.ERROR]:"error"},ay=(n,e,...t)=>{if(e<n.logLevel)return;const s=new Date().toISOString(),r=oy[e];if(r)console[r](`[${s}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Yc{constructor(e){this.name=e,this._logLevel=iy,this._logHandler=ay,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in ne))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?ry[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,ne.DEBUG,...e),this._logHandler(this,ne.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,ne.VERBOSE,...e),this._logHandler(this,ne.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,ne.INFO,...e),this._logHandler(this,ne.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,ne.WARN,...e),this._logHandler(this,ne.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,ne.ERROR,...e),this._logHandler(this,ne.ERROR,...e)}}const cy=(n,e)=>e.some(t=>n instanceof t);let uh,hh;function ly(){return uh||(uh=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function uy(){return hh||(hh=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Tf=new WeakMap,uc=new WeakMap,Af=new WeakMap,Wa=new WeakMap,Xc=new WeakMap;function hy(n){const e=new Promise((t,s)=>{const r=()=>{n.removeEventListener("success",i),n.removeEventListener("error",o)},i=()=>{t(an(n.result)),r()},o=()=>{s(n.error),r()};n.addEventListener("success",i),n.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&Tf.set(t,n)}).catch(()=>{}),Xc.set(e,n),e}function dy(n){if(uc.has(n))return;const e=new Promise((t,s)=>{const r=()=>{n.removeEventListener("complete",i),n.removeEventListener("error",o),n.removeEventListener("abort",o)},i=()=>{t(),r()},o=()=>{s(n.error||new DOMException("AbortError","AbortError")),r()};n.addEventListener("complete",i),n.addEventListener("error",o),n.addEventListener("abort",o)});uc.set(n,e)}let hc={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return uc.get(n);if(e==="objectStoreNames")return n.objectStoreNames||Af.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return an(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function fy(n){hc=n(hc)}function py(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=n.call(Ha(this),e,...t);return Af.set(s,e.sort?e.sort():[e]),an(s)}:uy().includes(n)?function(...e){return n.apply(Ha(this),e),an(Tf.get(this))}:function(...e){return an(n.apply(Ha(this),e))}}function my(n){return typeof n=="function"?py(n):(n instanceof IDBTransaction&&dy(n),cy(n,ly())?new Proxy(n,hc):n)}function an(n){if(n instanceof IDBRequest)return hy(n);if(Wa.has(n))return Wa.get(n);const e=my(n);return e!==n&&(Wa.set(n,e),Xc.set(e,n)),e}const Ha=n=>Xc.get(n);function gy(n,e,{blocked:t,upgrade:s,blocking:r,terminated:i}={}){const o=indexedDB.open(n,e),c=an(o);return s&&o.addEventListener("upgradeneeded",l=>{s(an(o.result),l.oldVersion,l.newVersion,an(o.transaction),l)}),t&&o.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),c.then(l=>{i&&l.addEventListener("close",()=>i()),r&&l.addEventListener("versionchange",u=>r(u.oldVersion,u.newVersion,u))}).catch(()=>{}),c}const _y=["get","getKey","getAll","getAllKeys","count"],yy=["put","add","delete","clear"],Qa=new Map;function dh(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Qa.get(e))return Qa.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,r=yy.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(r||_y.includes(t)))return;const i=async function(o,...c){const l=this.transaction(o,r?"readwrite":"readonly");let u=l.store;return s&&(u=u.index(c.shift())),(await Promise.all([u[t](...c),r&&l.done]))[0]};return Qa.set(e,i),i}fy(n=>({...n,get:(e,t,s)=>dh(e,t)||n.get(e,t,s),has:(e,t)=>!!dh(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vy{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(Iy(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function Iy(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const dc="@firebase/app",fh="0.10.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wn=new Yc("@firebase/app"),wy="@firebase/app-compat",Ey="@firebase/analytics-compat",by="@firebase/analytics",Ty="@firebase/app-check-compat",Ay="@firebase/app-check",Sy="@firebase/auth",Ry="@firebase/auth-compat",Py="@firebase/database",ky="@firebase/database-compat",Cy="@firebase/functions",Dy="@firebase/functions-compat",Vy="@firebase/installations",Ny="@firebase/installations-compat",xy="@firebase/messaging",Oy="@firebase/messaging-compat",Ly="@firebase/performance",My="@firebase/performance-compat",$y="@firebase/remote-config",Fy="@firebase/remote-config-compat",Uy="@firebase/storage",By="@firebase/storage-compat",qy="@firebase/firestore",jy="@firebase/vertexai-preview",Gy="@firebase/firestore-compat",zy="firebase",Ky="10.12.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fc="[DEFAULT]",Wy={[dc]:"fire-core",[wy]:"fire-core-compat",[by]:"fire-analytics",[Ey]:"fire-analytics-compat",[Ay]:"fire-app-check",[Ty]:"fire-app-check-compat",[Sy]:"fire-auth",[Ry]:"fire-auth-compat",[Py]:"fire-rtdb",[ky]:"fire-rtdb-compat",[Cy]:"fire-fn",[Dy]:"fire-fn-compat",[Vy]:"fire-iid",[Ny]:"fire-iid-compat",[xy]:"fire-fcm",[Oy]:"fire-fcm-compat",[Ly]:"fire-perf",[My]:"fire-perf-compat",[$y]:"fire-rc",[Fy]:"fire-rc-compat",[Uy]:"fire-gcs",[By]:"fire-gcs-compat",[qy]:"fire-fst",[Gy]:"fire-fst-compat",[jy]:"fire-vertex","fire-js":"fire-js",[zy]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yo=new Map,Hy=new Map,pc=new Map;function ph(n,e){try{n.container.addComponent(e)}catch(t){Wn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function ks(n){const e=n.name;if(pc.has(e))return Wn.debug(`There were multiple attempts to register component ${e}.`),!1;pc.set(e,n);for(const t of yo.values())ph(t,n);for(const t of Hy.values())ph(t,n);return!0}function Zc(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function xt(n){return n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qy={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},cn=new hi("app","Firebase",Qy);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jy{constructor(e,t,s){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new Kn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw cn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hs=Ky;function Sf(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const s=Object.assign({name:fc,automaticDataCollectionEnabled:!1},e),r=s.name;if(typeof r!="string"||!r)throw cn.create("bad-app-name",{appName:String(r)});if(t||(t=If()),!t)throw cn.create("no-options");const i=yo.get(r);if(i){if(Gr(t,i.options)&&Gr(s,i.config))return i;throw cn.create("duplicate-app",{appName:r})}const o=new sy(r);for(const l of pc.values())o.addComponent(l);const c=new Jy(t,s,o);return yo.set(r,c),c}function Yy(n=fc){const e=yo.get(n);if(!e&&n===fc&&If())return Sf();if(!e)throw cn.create("no-app",{appName:n});return e}function ln(n,e,t){var s;let r=(s=Wy[n])!==null&&s!==void 0?s:n;t&&(r+=`-${t}`);const i=r.match(/\s|\//),o=e.match(/\s|\//);if(i||o){const c=[`Unable to register library "${r}" with version "${e}":`];i&&c.push(`library name "${r}" contains illegal characters (whitespace or "/")`),i&&o&&c.push("and"),o&&c.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Wn.warn(c.join(" "));return}ks(new Kn(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xy="firebase-heartbeat-database",Zy=1,zr="firebase-heartbeat-store";let Ja=null;function Rf(){return Ja||(Ja=gy(Xy,Zy,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(zr)}catch(t){console.warn(t)}}}}).catch(n=>{throw cn.create("idb-open",{originalErrorMessage:n.message})})),Ja}async function ev(n){try{const t=(await Rf()).transaction(zr),s=await t.objectStore(zr).get(Pf(n));return await t.done,s}catch(e){if(e instanceof jt)Wn.warn(e.message);else{const t=cn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Wn.warn(t.message)}}}async function mh(n,e){try{const s=(await Rf()).transaction(zr,"readwrite");await s.objectStore(zr).put(e,Pf(n)),await s.done}catch(t){if(t instanceof jt)Wn.warn(t.message);else{const s=cn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Wn.warn(s.message)}}}function Pf(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tv=1024,nv=30*24*60*60*1e3;class sv{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new iv(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;const r=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=gh();if(!(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i)))return this._heartbeatsCache.heartbeats.push({date:i,agent:r}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(o=>{const c=new Date(o.date).valueOf();return Date.now()-c<=nv}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var e;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=gh(),{heartbeatsToSend:s,unsentEntries:r}=rv(this._heartbeatsCache.heartbeats),i=yf(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}}function gh(){return new Date().toISOString().substring(0,10)}function rv(n,e=tv){const t=[];let s=n.slice();for(const r of n){const i=t.find(o=>o.agent===r.agent);if(i){if(i.dates.push(r.date),_h(t)>e){i.dates.pop();break}}else if(t.push({agent:r.agent,dates:[r.date]}),_h(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class iv{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return bf()?K_().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await ev(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const r=await this.read();return mh(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const r=await this.read();return mh(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function _h(n){return yf(JSON.stringify({version:2,heartbeats:n})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ov(n){ks(new Kn("platform-logger",e=>new vy(e),"PRIVATE")),ks(new Kn("heartbeat",e=>new sv(e),"PRIVATE")),ln(dc,fh,n),ln(dc,fh,"esm2017"),ln("fire-js","")}ov("");var av="firebase",cv="10.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ln(av,cv,"app");function el(n,e){var t={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&e.indexOf(s)<0&&(t[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var r=0,s=Object.getOwnPropertySymbols(n);r<s.length;r++)e.indexOf(s[r])<0&&Object.prototype.propertyIsEnumerable.call(n,s[r])&&(t[s[r]]=n[s[r]]);return t}function kf(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const lv=kf,Cf=new hi("auth","Firebase",kf());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vo=new Yc("@firebase/auth");function uv(n,...e){vo.logLevel<=ne.WARN&&vo.warn(`Auth (${Hs}): ${n}`,...e)}function eo(n,...e){vo.logLevel<=ne.ERROR&&vo.error(`Auth (${Hs}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wt(n,...e){throw tl(n,...e)}function Rt(n,...e){return tl(n,...e)}function Df(n,e,t){const s=Object.assign(Object.assign({},lv()),{[e]:t});return new hi("auth","Firebase",s).create(e,{appName:n.name})}function un(n){return Df(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function tl(n,...e){if(typeof n!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=n.name),n._errorFactory.create(t,...s)}return Cf.create(n,...e)}function Q(n,e,...t){if(!n)throw tl(e,...t)}function Ot(n){const e="INTERNAL ASSERTION FAILED: "+n;throw eo(e),new Error(e)}function Bt(n,e){n||Ot(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mc(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function hv(){return yh()==="http:"||yh()==="https:"}function yh(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dv(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(hv()||j_()||"connection"in navigator)?navigator.onLine:!0}function fv(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fi{constructor(e,t){this.shortDelay=e,this.longDelay=t,Bt(t>e,"Short delay should be less than long delay!"),this.isMobile=B_()||G_()}get(){return dv()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nl(n,e){Bt(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vf{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Ot("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Ot("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Ot("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pv={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mv=new fi(3e4,6e4);function ss(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function bn(n,e,t,s,r={}){return Nf(n,r,async()=>{let i={},o={};s&&(e==="GET"?o=s:i={body:JSON.stringify(s)});const c=di(Object.assign({key:n.config.apiKey},o)).slice(1),l=await n._getAdditionalHeaders();return l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode),Vf.fetch()(xf(n,n.config.apiHost,t,c),Object.assign({method:e,headers:l,referrerPolicy:"no-referrer"},i))})}async function Nf(n,e,t){n._canInitEmulator=!1;const s=Object.assign(Object.assign({},pv),e);try{const r=new _v(n),i=await Promise.race([t(),r.promise]);r.clearNetworkTimeout();const o=await i.json();if("needConfirmation"in o)throw zi(n,"account-exists-with-different-credential",o);if(i.ok&&!("errorMessage"in o))return o;{const c=i.ok?o.errorMessage:o.error.message,[l,u]=c.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw zi(n,"credential-already-in-use",o);if(l==="EMAIL_EXISTS")throw zi(n,"email-already-in-use",o);if(l==="USER_DISABLED")throw zi(n,"user-disabled",o);const f=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw Df(n,f,u);wt(n,f)}}catch(r){if(r instanceof jt)throw r;wt(n,"network-request-failed",{message:String(r)})}}async function Ko(n,e,t,s,r={}){const i=await bn(n,e,t,s,r);return"mfaPendingCredential"in i&&wt(n,"multi-factor-auth-required",{_serverResponse:i}),i}function xf(n,e,t,s){const r=`${e}${t}?${s}`;return n.config.emulator?nl(n.config,r):`${n.config.apiScheme}://${r}`}function gv(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class _v{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(Rt(this.auth,"network-request-failed")),mv.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function zi(n,e,t){const s={appName:n.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const r=Rt(n,e,s);return r.customData._tokenResponse=t,r}function vh(n){return n!==void 0&&n.enterprise!==void 0}class yv{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return gv(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}}async function vv(n,e){return bn(n,"GET","/v2/recaptchaConfig",ss(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Iv(n,e){return bn(n,"POST","/v1/accounts:delete",e)}async function Of(n,e){return bn(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xr(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function wv(n,e=!1){const t=xe(n),s=await t.getIdToken(e),r=sl(s);Q(r&&r.exp&&r.auth_time&&r.iat,t.auth,"internal-error");const i=typeof r.firebase=="object"?r.firebase:void 0,o=i==null?void 0:i.sign_in_provider;return{claims:r,token:s,authTime:xr(Ya(r.auth_time)),issuedAtTime:xr(Ya(r.iat)),expirationTime:xr(Ya(r.exp)),signInProvider:o||null,signInSecondFactor:(i==null?void 0:i.sign_in_second_factor)||null}}function Ya(n){return Number(n)*1e3}function sl(n){const[e,t,s]=n.split(".");if(e===void 0||t===void 0||s===void 0)return eo("JWT malformed, contained fewer than 3 sections"),null;try{const r=vf(t);return r?JSON.parse(r):(eo("Failed to decode base64 JWT payload"),null)}catch(r){return eo("Caught error parsing JWT payload as JSON",r==null?void 0:r.toString()),null}}function Ih(n){const e=sl(n);return Q(e,"internal-error"),Q(typeof e.exp<"u","internal-error"),Q(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Kr(n,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof jt&&Ev(s)&&n.auth.currentUser===n&&await n.auth.signOut(),s}}function Ev({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bv{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const s=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),s}else{this.errorBackoff=3e4;const r=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gc{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=xr(this.lastLoginAt),this.creationTime=xr(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Io(n){var e;const t=n.auth,s=await n.getIdToken(),r=await Kr(n,Of(t,{idToken:s}));Q(r==null?void 0:r.users.length,t,"internal-error");const i=r.users[0];n._notifyReloadListener(i);const o=!((e=i.providerUserInfo)===null||e===void 0)&&e.length?Lf(i.providerUserInfo):[],c=Av(n.providerData,o),l=n.isAnonymous,u=!(n.email&&i.passwordHash)&&!(c!=null&&c.length),f=l?u:!1,p={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:c,metadata:new gc(i.createdAt,i.lastLoginAt),isAnonymous:f};Object.assign(n,p)}async function Tv(n){const e=xe(n);await Io(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Av(n,e){return[...n.filter(s=>!e.some(r=>r.providerId===s.providerId)),...e]}function Lf(n){return n.map(e=>{var{providerId:t}=e,s=el(e,["providerId"]);return{providerId:t,uid:s.rawId||"",displayName:s.displayName||null,email:s.email||null,phoneNumber:s.phoneNumber||null,photoURL:s.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Sv(n,e){const t=await Nf(n,{},async()=>{const s=di({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:r,apiKey:i}=n.config,o=xf(n,r,"/v1/token",`key=${i}`),c=await n._getAdditionalHeaders();return c["Content-Type"]="application/x-www-form-urlencoded",Vf.fetch()(o,{method:"POST",headers:c,body:s})});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function Rv(n,e){return bn(n,"POST","/v2/accounts:revokeToken",ss(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Es{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){Q(e.idToken,"internal-error"),Q(typeof e.idToken<"u","internal-error"),Q(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Ih(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){Q(e.length!==0,"internal-error");const t=Ih(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(Q(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:r,expiresIn:i}=await Sv(e,t);this.updateTokensAndExpiration(s,r,Number(i))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:r,expirationTime:i}=t,o=new Es;return s&&(Q(typeof s=="string","internal-error",{appName:e}),o.refreshToken=s),r&&(Q(typeof r=="string","internal-error",{appName:e}),o.accessToken=r),i&&(Q(typeof i=="number","internal-error",{appName:e}),o.expirationTime=i),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Es,this.toJSON())}_performRefresh(){return Ot("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jt(n,e){Q(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class Lt{constructor(e){var{uid:t,auth:s,stsTokenManager:r}=e,i=el(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new bv(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=s,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.providerData=i.providerData?[...i.providerData]:[],this.metadata=new gc(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(e){const t=await Kr(this,this.stsTokenManager.getToken(this.auth,e));return Q(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return wv(this,e)}reload(){return Tv(this)}_assign(e){this!==e&&(Q(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Lt(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){Q(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await Io(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(xt(this.auth.app))return Promise.reject(un(this.auth));const e=await this.getIdToken();return await Kr(this,Iv(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var s,r,i,o,c,l,u,f;const p=(s=t.displayName)!==null&&s!==void 0?s:void 0,y=(r=t.email)!==null&&r!==void 0?r:void 0,S=(i=t.phoneNumber)!==null&&i!==void 0?i:void 0,k=(o=t.photoURL)!==null&&o!==void 0?o:void 0,V=(c=t.tenantId)!==null&&c!==void 0?c:void 0,R=(l=t._redirectEventId)!==null&&l!==void 0?l:void 0,B=(u=t.createdAt)!==null&&u!==void 0?u:void 0,z=(f=t.lastLoginAt)!==null&&f!==void 0?f:void 0,{uid:j,emailVerified:Z,isAnonymous:N,providerData:M,stsTokenManager:I}=t;Q(j&&I,e,"internal-error");const g=Es.fromJSON(this.name,I);Q(typeof j=="string",e,"internal-error"),Jt(p,e.name),Jt(y,e.name),Q(typeof Z=="boolean",e,"internal-error"),Q(typeof N=="boolean",e,"internal-error"),Jt(S,e.name),Jt(k,e.name),Jt(V,e.name),Jt(R,e.name),Jt(B,e.name),Jt(z,e.name);const _=new Lt({uid:j,auth:e,email:y,emailVerified:Z,displayName:p,isAnonymous:N,photoURL:k,phoneNumber:S,tenantId:V,stsTokenManager:g,createdAt:B,lastLoginAt:z});return M&&Array.isArray(M)&&(_.providerData=M.map(w=>Object.assign({},w))),R&&(_._redirectEventId=R),_}static async _fromIdTokenResponse(e,t,s=!1){const r=new Es;r.updateFromServerResponse(t);const i=new Lt({uid:t.localId,auth:e,stsTokenManager:r,isAnonymous:s});return await Io(i),i}static async _fromGetAccountInfoResponse(e,t,s){const r=t.users[0];Q(r.localId!==void 0,"internal-error");const i=r.providerUserInfo!==void 0?Lf(r.providerUserInfo):[],o=!(r.email&&r.passwordHash)&&!(i!=null&&i.length),c=new Es;c.updateFromIdToken(s);const l=new Lt({uid:r.localId,auth:e,stsTokenManager:c,isAnonymous:o}),u={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:i,metadata:new gc(r.createdAt,r.lastLoginAt),isAnonymous:!(r.email&&r.passwordHash)&&!(i!=null&&i.length)};return Object.assign(l,u),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wh=new Map;function Mt(n){Bt(n instanceof Function,"Expected a class definition");let e=wh.get(n);return e?(Bt(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,wh.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mf{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}Mf.type="NONE";const Eh=Mf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function to(n,e,t){return`firebase:${n}:${e}:${t}`}class bs{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:r,name:i}=this.auth;this.fullUserKey=to(this.userKey,r.apiKey,i),this.fullPersistenceKey=to("persistence",r.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?Lt._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new bs(Mt(Eh),e,s);const r=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let i=r[0]||Mt(Eh);const o=to(s,e.config.apiKey,e.name);let c=null;for(const u of t)try{const f=await u._get(o);if(f){const p=Lt._fromJSON(e,f);u!==i&&(c=p),i=u;break}}catch{}const l=r.filter(u=>u._shouldAllowMigration);return!i._shouldAllowMigration||!l.length?new bs(i,e,s):(i=l[0],c&&await i._set(o,c.toJSON()),await Promise.all(t.map(async u=>{if(u!==i)try{await u._remove(o)}catch{}})),new bs(i,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bh(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Uf(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if($f(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(qf(e))return"Blackberry";if(jf(e))return"Webos";if(rl(e))return"Safari";if((e.includes("chrome/")||Ff(e))&&!e.includes("edge/"))return"Chrome";if(Bf(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=n.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function $f(n=Ce()){return/firefox\//i.test(n)}function rl(n=Ce()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Ff(n=Ce()){return/crios\//i.test(n)}function Uf(n=Ce()){return/iemobile/i.test(n)}function Bf(n=Ce()){return/android/i.test(n)}function qf(n=Ce()){return/blackberry/i.test(n)}function jf(n=Ce()){return/webos/i.test(n)}function Wo(n=Ce()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function Pv(n=Ce()){var e;return Wo(n)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function kv(){return z_()&&document.documentMode===10}function Gf(n=Ce()){return Wo(n)||Bf(n)||jf(n)||qf(n)||/windows phone/i.test(n)||Uf(n)}function Cv(){try{return!!(window&&window!==window.top)}catch{return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zf(n,e=[]){let t;switch(n){case"Browser":t=bh(Ce());break;case"Worker":t=`${bh(Ce())}-${n}`;break;default:t=n}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Hs}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dv{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=i=>new Promise((o,c)=>{try{const l=e(i);o(l)}catch(l){c(l)}});s.onAbort=t,this.queue.push(s);const r=this.queue.length-1;return()=>{this.queue[r]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const r of t)try{r()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vv(n,e={}){return bn(n,"GET","/v2/passwordPolicy",ss(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nv=6;class xv{constructor(e){var t,s,r,i;const o=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=o.minPasswordLength)!==null&&t!==void 0?t:Nv,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(r=(s=e.allowedNonAlphanumericCharacters)===null||s===void 0?void 0:s.join(""))!==null&&r!==void 0?r:"",this.forceUpgradeOnSignin=(i=e.forceUpgradeOnSignin)!==null&&i!==void 0?i:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,s,r,i,o,c;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,l),this.validatePasswordCharacterOptions(e,l),l.isValid&&(l.isValid=(t=l.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),l.isValid&&(l.isValid=(s=l.meetsMaxPasswordLength)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(r=l.containsLowercaseLetter)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(i=l.containsUppercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(o=l.containsNumericCharacter)!==null&&o!==void 0?o:!0),l.isValid&&(l.isValid=(c=l.containsNonAlphanumericCharacter)!==null&&c!==void 0?c:!0),l}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,r=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),r&&(t.meetsMaxPasswordLength=e.length<=r)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let r=0;r<e.length;r++)s=e.charAt(r),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,r,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=r)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ov{constructor(e,t,s,r){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=r,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Th(this),this.idTokenSubscription=new Th(this),this.beforeStateQueue=new Dv(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Cf,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=r.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Mt(t)),this._initializationPromise=this.queue(async()=>{var s,r;if(!this._deleted&&(this.persistenceManager=await bs.create(this,e),!this._deleted)){if(!((s=this._popupRedirectResolver)===null||s===void 0)&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((r=this.currentUser)===null||r===void 0?void 0:r.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Of(this,{idToken:e}),s=await Lt._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(xt(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(c=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(c,c))}):this.directlySetCurrentUser(null)}const s=await this.assertedPersistence.getCurrentUser();let r=s,i=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,c=r==null?void 0:r._redirectEventId,l=await this.tryRedirectSignIn(e);(!o||o===c)&&(l!=null&&l.user)&&(r=l.user,i=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(i)try{await this.beforeStateQueue.runMiddleware(r)}catch(o){r=s,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return Q(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Io(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=fv()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(xt(this.app))return Promise.reject(un(this));const t=e?xe(e):null;return t&&Q(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&Q(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return xt(this.app)?Promise.reject(un(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return xt(this.app)?Promise.reject(un(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Mt(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await Vv(this),t=new xv(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new hi("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await Rv(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Mt(e)||this._popupRedirectResolver;Q(t,this,"argument-error"),this.redirectPersistenceManager=await bs.create(this,[Mt(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)===null||s===void 0?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const s=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==s&&(this.lastNotifiedUid=s,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,r){if(this._deleted)return()=>{};const i=typeof t=="function"?t:t.next.bind(t);let o=!1;const c=this._isInitialized?Promise.resolve():this._initializationPromise;if(Q(c,this,"internal-error"),c.then(()=>{o||i(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,s,r);return()=>{o=!0,l()}}else{const l=e.addObserver(t);return()=>{o=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return Q(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=zf(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const s=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());s&&(t["X-Firebase-Client"]=s);const r=await this._getAppCheckToken();return r&&(t["X-Firebase-AppCheck"]=r),t}async _getAppCheckToken(){var e;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&uv(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function Qs(n){return xe(n)}class Th{constructor(e){this.auth=e,this.observer=null,this.addObserver=Y_(t=>this.observer=t)}get next(){return Q(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ho={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function Lv(n){Ho=n}function Kf(n){return Ho.loadJS(n)}function Mv(){return Ho.recaptchaEnterpriseScript}function $v(){return Ho.gapiScript}function Fv(n){return`__${n}${Math.floor(Math.random()*1e6)}`}const Uv="recaptcha-enterprise",Bv="NO_RECAPTCHA";class qv{constructor(e){this.type=Uv,this.auth=Qs(e)}async verify(e="verify",t=!1){async function s(i){if(!t){if(i.tenantId==null&&i._agentRecaptchaConfig!=null)return i._agentRecaptchaConfig.siteKey;if(i.tenantId!=null&&i._tenantRecaptchaConfigs[i.tenantId]!==void 0)return i._tenantRecaptchaConfigs[i.tenantId].siteKey}return new Promise(async(o,c)=>{vv(i,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)c(new Error("recaptcha Enterprise site key undefined"));else{const u=new yv(l);return i.tenantId==null?i._agentRecaptchaConfig=u:i._tenantRecaptchaConfigs[i.tenantId]=u,o(u.siteKey)}}).catch(l=>{c(l)})})}function r(i,o,c){const l=window.grecaptcha;vh(l)?l.enterprise.ready(()=>{l.enterprise.execute(i,{action:e}).then(u=>{o(u)}).catch(()=>{o(Bv)})}):c(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((i,o)=>{s(this.auth).then(c=>{if(!t&&vh(window.grecaptcha))r(c,i,o);else{if(typeof window>"u"){o(new Error("RecaptchaVerifier is only supported in browser"));return}let l=Mv();l.length!==0&&(l+=c),Kf(l).then(()=>{r(c,i,o)}).catch(u=>{o(u)})}}).catch(c=>{o(c)})})}}async function Ah(n,e,t,s=!1){const r=new qv(n);let i;try{i=await r.verify(t)}catch{i=await r.verify(t,!0)}const o=Object.assign({},e);return s?Object.assign(o,{captchaResp:i}):Object.assign(o,{captchaResponse:i}),Object.assign(o,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(o,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),o}async function Sh(n,e,t,s){var r;if(!((r=n._getRecaptchaConfig())===null||r===void 0)&&r.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const i=await Ah(n,e,t,t==="getOobCode");return s(n,i)}else return s(n,e).catch(async i=>{if(i.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const o=await Ah(n,e,t,t==="getOobCode");return s(n,o)}else return Promise.reject(i)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jv(n,e){const t=Zc(n,"auth");if(t.isInitialized()){const r=t.getImmediate(),i=t.getOptions();if(Gr(i,e??{}))return r;wt(r,"already-initialized")}return t.initialize({options:e})}function Gv(n,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(Mt);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function zv(n,e,t){const s=Qs(n);Q(s._canInitEmulator,s,"emulator-config-failed"),Q(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const r=!1,i=Wf(e),{host:o,port:c}=Kv(e),l=c===null?"":`:${c}`;s.config.emulator={url:`${i}//${o}${l}/`},s.settings.appVerificationDisabledForTesting=!0,s.emulatorConfig=Object.freeze({host:o,port:c,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:r})}),Wv()}function Wf(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function Kv(n){const e=Wf(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",r=/^(\[[^\]]+\])(:|$)/.exec(s);if(r){const i=r[1];return{host:i,port:Rh(s.substr(i.length+1))}}else{const[i,o]=s.split(":");return{host:i,port:Rh(o)}}}function Rh(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function Wv(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class il{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return Ot("not implemented")}_getIdTokenResponse(e){return Ot("not implemented")}_linkToIdToken(e,t){return Ot("not implemented")}_getReauthenticationResolver(e){return Ot("not implemented")}}async function Hv(n,e){return bn(n,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Qv(n,e){return Ko(n,"POST","/v1/accounts:signInWithPassword",ss(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Jv(n,e){return Ko(n,"POST","/v1/accounts:signInWithEmailLink",ss(n,e))}async function Yv(n,e){return Ko(n,"POST","/v1/accounts:signInWithEmailLink",ss(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wr extends il{constructor(e,t,s,r=null){super("password",s),this._email=e,this._password=t,this._tenantId=r}static _fromEmailAndPassword(e,t){return new Wr(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new Wr(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Sh(e,t,"signInWithPassword",Qv);case"emailLink":return Jv(e,{email:this._email,oobCode:this._password});default:wt(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Sh(e,s,"signUpPassword",Hv);case"emailLink":return Yv(e,{idToken:t,email:this._email,oobCode:this._password});default:wt(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ts(n,e){return Ko(n,"POST","/v1/accounts:signInWithIdp",ss(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xv="http://localhost";class Hn extends il{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Hn(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):wt("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:r}=t,i=el(t,["providerId","signInMethod"]);if(!s||!r)return null;const o=new Hn(s,r);return o.idToken=i.idToken||void 0,o.accessToken=i.accessToken||void 0,o.secret=i.secret,o.nonce=i.nonce,o.pendingToken=i.pendingToken||null,o}_getIdTokenResponse(e){const t=this.buildRequest();return Ts(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,Ts(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,Ts(e,t)}buildRequest(){const e={requestUri:Xv,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=di(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zv(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function eI(n){const e=Rr(Pr(n)).link,t=e?Rr(Pr(e)).deep_link_id:null,s=Rr(Pr(n)).deep_link_id;return(s?Rr(Pr(s)).link:null)||s||t||e||n}class ol{constructor(e){var t,s,r,i,o,c;const l=Rr(Pr(e)),u=(t=l.apiKey)!==null&&t!==void 0?t:null,f=(s=l.oobCode)!==null&&s!==void 0?s:null,p=Zv((r=l.mode)!==null&&r!==void 0?r:null);Q(u&&f&&p,"argument-error"),this.apiKey=u,this.operation=p,this.code=f,this.continueUrl=(i=l.continueUrl)!==null&&i!==void 0?i:null,this.languageCode=(o=l.languageCode)!==null&&o!==void 0?o:null,this.tenantId=(c=l.tenantId)!==null&&c!==void 0?c:null}static parseLink(e){const t=eI(e);try{return new ol(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Js{constructor(){this.providerId=Js.PROVIDER_ID}static credential(e,t){return Wr._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=ol.parseLink(t);return Q(s,"argument-error"),Wr._fromEmailAndCode(e,s.code,s.tenantId)}}Js.PROVIDER_ID="password";Js.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Js.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hf{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pi extends Hf{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class en extends pi{constructor(){super("facebook.com")}static credential(e){return Hn._fromParams({providerId:en.PROVIDER_ID,signInMethod:en.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return en.credentialFromTaggedObject(e)}static credentialFromError(e){return en.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return en.credential(e.oauthAccessToken)}catch{return null}}}en.FACEBOOK_SIGN_IN_METHOD="facebook.com";en.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tn extends pi{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Hn._fromParams({providerId:tn.PROVIDER_ID,signInMethod:tn.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return tn.credentialFromTaggedObject(e)}static credentialFromError(e){return tn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return tn.credential(t,s)}catch{return null}}}tn.GOOGLE_SIGN_IN_METHOD="google.com";tn.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nn extends pi{constructor(){super("github.com")}static credential(e){return Hn._fromParams({providerId:nn.PROVIDER_ID,signInMethod:nn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return nn.credentialFromTaggedObject(e)}static credentialFromError(e){return nn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return nn.credential(e.oauthAccessToken)}catch{return null}}}nn.GITHUB_SIGN_IN_METHOD="github.com";nn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sn extends pi{constructor(){super("twitter.com")}static credential(e,t){return Hn._fromParams({providerId:sn.PROVIDER_ID,signInMethod:sn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return sn.credentialFromTaggedObject(e)}static credentialFromError(e){return sn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return sn.credential(t,s)}catch{return null}}}sn.TWITTER_SIGN_IN_METHOD="twitter.com";sn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cs{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,r=!1){const i=await Lt._fromIdTokenResponse(e,s,r),o=Ph(s);return new Cs({user:i,providerId:o,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const r=Ph(s);return new Cs({user:e,providerId:r,_tokenResponse:s,operationType:t})}}function Ph(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wo extends jt{constructor(e,t,s,r){var i;super(t.code,t.message),this.operationType=s,this.user=r,Object.setPrototypeOf(this,wo.prototype),this.customData={appName:e.name,tenantId:(i=e.tenantId)!==null&&i!==void 0?i:void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,r){return new wo(e,t,s,r)}}function Qf(n,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?wo._fromErrorAndOperation(n,i,e,s):i})}async function tI(n,e,t=!1){const s=await Kr(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return Cs._forOperation(n,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function nI(n,e,t=!1){const{auth:s}=n;if(xt(s.app))return Promise.reject(un(s));const r="reauthenticate";try{const i=await Kr(n,Qf(s,r,e,n),t);Q(i.idToken,s,"internal-error");const o=sl(i.idToken);Q(o,s,"internal-error");const{sub:c}=o;return Q(n.uid===c,s,"user-mismatch"),Cs._forOperation(n,r,i)}catch(i){throw(i==null?void 0:i.code)==="auth/user-not-found"&&wt(s,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Jf(n,e,t=!1){if(xt(n.app))return Promise.reject(un(n));const s="signIn",r=await Qf(n,s,e),i=await Cs._fromIdTokenResponse(n,s,r);return t||await n._updateCurrentUser(i.user),i}async function sI(n,e){return Jf(Qs(n),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function rI(n){const e=Qs(n);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}function iI(n,e,t){return xt(n.app)?Promise.reject(un(n)):sI(xe(n),Js.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&rI(n),s})}function oI(n,e,t,s){return xe(n).onIdTokenChanged(e,t,s)}function aI(n,e,t){return xe(n).beforeAuthStateChanged(e,t)}function cI(n,e,t,s){return xe(n).onAuthStateChanged(e,t,s)}function lI(n){return xe(n).signOut()}const Eo="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yf{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Eo,"1"),this.storage.removeItem(Eo),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uI(){const n=Ce();return rl(n)||Wo(n)}const hI=1e3,dI=10;class Xf extends Yf{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=uI()&&Cv(),this.fallbackToPolling=Gf(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),r=this.localCache[t];s!==r&&e(t,r,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((o,c,l)=>{this.notifyListeners(o,l)});return}const s=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const o=this.storage.getItem(s);if(e.newValue!==o)e.newValue!==null?this.storage.setItem(s,e.newValue):this.storage.removeItem(s);else if(this.localCache[s]===e.newValue&&!t)return}const r=()=>{const o=this.storage.getItem(s);!t&&this.localCache[s]===o||this.notifyListeners(s,o)},i=this.storage.getItem(s);kv()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(r,dI):r()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const r of Array.from(s))r(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},hI)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Xf.type="LOCAL";const fI=Xf;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zf extends Yf{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Zf.type="SESSION";const ep=Zf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pI(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qo{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(r=>r.isListeningto(e));if(t)return t;const s=new Qo(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:r,data:i}=t.data,o=this.handlersMap[r];if(!(o!=null&&o.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:r});const c=Array.from(o).map(async u=>u(t.origin,i)),l=await pI(c);t.ports[0].postMessage({status:"done",eventId:s,eventType:r,response:l})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Qo.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function al(n="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mI{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const r=typeof MessageChannel<"u"?new MessageChannel:null;if(!r)throw new Error("connection_unavailable");let i,o;return new Promise((c,l)=>{const u=al("",20);r.port1.start();const f=setTimeout(()=>{l(new Error("unsupported_event"))},s);o={messageChannel:r,onMessage(p){const y=p;if(y.data.eventId===u)switch(y.data.status){case"ack":clearTimeout(f),i=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),c(y.data.response);break;default:clearTimeout(f),clearTimeout(i),l(new Error("invalid_response"));break}}},this.handlers.add(o),r.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[r.port2])}).finally(()=>{o&&this.removeMessageHandler(o)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pt(){return window}function gI(n){Pt().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tp(){return typeof Pt().WorkerGlobalScope<"u"&&typeof Pt().importScripts=="function"}async function _I(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function yI(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function vI(){return tp()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const np="firebaseLocalStorageDb",II=1,bo="firebaseLocalStorage",sp="fbase_key";class mi{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function Jo(n,e){return n.transaction([bo],e?"readwrite":"readonly").objectStore(bo)}function wI(){const n=indexedDB.deleteDatabase(np);return new mi(n).toPromise()}function _c(){const n=indexedDB.open(np,II);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const s=n.result;try{s.createObjectStore(bo,{keyPath:sp})}catch(r){t(r)}}),n.addEventListener("success",async()=>{const s=n.result;s.objectStoreNames.contains(bo)?e(s):(s.close(),await wI(),e(await _c()))})})}async function kh(n,e,t){const s=Jo(n,!0).put({[sp]:e,value:t});return new mi(s).toPromise()}async function EI(n,e){const t=Jo(n,!1).get(e),s=await new mi(t).toPromise();return s===void 0?null:s.value}function Ch(n,e){const t=Jo(n,!0).delete(e);return new mi(t).toPromise()}const bI=800,TI=3;class rp{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await _c(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>TI)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return tp()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Qo._getInstance(vI()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await _I(),!this.activeServiceWorker)return;this.sender=new mI(this.activeServiceWorker);const s=await this.sender._send("ping",{},800);s&&!((e=s[0])===null||e===void 0)&&e.fulfilled&&!((t=s[0])===null||t===void 0)&&t.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||yI()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await _c();return await kh(e,Eo,"1"),await Ch(e,Eo),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>kh(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>EI(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Ch(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(r=>{const i=Jo(r,!1).getAll();return new mi(i).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:r,value:i}of e)s.add(r),JSON.stringify(this.localCache[r])!==JSON.stringify(i)&&(this.notifyListeners(r,i),t.push(r));for(const r of Object.keys(this.localCache))this.localCache[r]&&!s.has(r)&&(this.notifyListeners(r,null),t.push(r));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const r of Array.from(s))r(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),bI)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}rp.type="LOCAL";const AI=rp;new fi(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function SI(n,e){return e?Mt(e):(Q(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cl extends il{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Ts(e,this._buildIdpRequest())}_linkToIdToken(e,t){return Ts(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return Ts(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function RI(n){return Jf(n.auth,new cl(n),n.bypassAuthState)}function PI(n){const{auth:e,user:t}=n;return Q(t,e,"internal-error"),nI(t,new cl(n),n.bypassAuthState)}async function kI(n){const{auth:e,user:t}=n;return Q(t,e,"internal-error"),tI(t,new cl(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ip{constructor(e,t,s,r,i=!1){this.auth=e,this.resolver=s,this.user=r,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:r,tenantId:i,error:o,type:c}=e;if(o){this.reject(o);return}const l={auth:this.auth,requestUri:t,sessionId:s,tenantId:i||void 0,postBody:r||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(c)(l))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return RI;case"linkViaPopup":case"linkViaRedirect":return kI;case"reauthViaPopup":case"reauthViaRedirect":return PI;default:wt(this.auth,"internal-error")}}resolve(e){Bt(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Bt(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const CI=new fi(2e3,1e4);class ws extends ip{constructor(e,t,s,r,i){super(e,t,r,i),this.provider=s,this.authWindow=null,this.pollId=null,ws.currentPopupAction&&ws.currentPopupAction.cancel(),ws.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return Q(e,this.auth,"internal-error"),e}async onExecution(){Bt(this.filter.length===1,"Popup operations only handle one event");const e=al();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Rt(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(Rt(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,ws.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if(!((s=(t=this.authWindow)===null||t===void 0?void 0:t.window)===null||s===void 0)&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Rt(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,CI.get())};e()}}ws.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const DI="pendingRedirect",no=new Map;class VI extends ip{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=no.get(this.auth._key());if(!e){try{const s=await NI(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}no.set(this.auth._key(),e)}return this.bypassAuthState||no.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function NI(n,e){const t=LI(e),s=OI(n);if(!await s._isAvailable())return!1;const r=await s._get(t)==="true";return await s._remove(t),r}function xI(n,e){no.set(n._key(),e)}function OI(n){return Mt(n._redirectPersistence)}function LI(n){return to(DI,n.config.apiKey,n.name)}async function MI(n,e,t=!1){if(xt(n.app))return Promise.reject(un(n));const s=Qs(n),r=SI(s,e),o=await new VI(s,r,t).execute();return o&&!t&&(delete o.user._redirectEventId,await s._persistUserIfCurrent(o.user),await s._setRedirectUser(null,e)),o}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $I=10*60*1e3;class FI{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!UI(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!op(e)){const r=((s=e.error.code)===null||s===void 0?void 0:s.split("auth/")[1])||"internal-error";t.onError(Rt(this.auth,r))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=$I&&this.cachedEventUids.clear(),this.cachedEventUids.has(Dh(e))}saveEventToCache(e){this.cachedEventUids.add(Dh(e)),this.lastProcessedEventTime=Date.now()}}function Dh(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function op({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function UI(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return op(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function BI(n,e={}){return bn(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qI=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,jI=/^https?/;async function GI(n){if(n.config.emulator)return;const{authorizedDomains:e}=await BI(n);for(const t of e)try{if(zI(t))return}catch{}wt(n,"unauthorized-domain")}function zI(n){const e=mc(),{protocol:t,hostname:s}=new URL(e);if(n.startsWith("chrome-extension://")){const o=new URL(n);return o.hostname===""&&s===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&o.hostname===s}if(!jI.test(t))return!1;if(qI.test(n))return s===n;const r=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+r+"|"+r+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const KI=new fi(3e4,6e4);function Vh(){const n=Pt().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function WI(n){return new Promise((e,t)=>{var s,r,i;function o(){Vh(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{Vh(),t(Rt(n,"network-request-failed"))},timeout:KI.get()})}if(!((r=(s=Pt().gapi)===null||s===void 0?void 0:s.iframes)===null||r===void 0)&&r.Iframe)e(gapi.iframes.getContext());else if(!((i=Pt().gapi)===null||i===void 0)&&i.load)o();else{const c=Fv("iframefcb");return Pt()[c]=()=>{gapi.load?o():t(Rt(n,"network-request-failed"))},Kf(`${$v()}?onload=${c}`).catch(l=>t(l))}}).catch(e=>{throw so=null,e})}let so=null;function HI(n){return so=so||WI(n),so}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const QI=new fi(5e3,15e3),JI="__/auth/iframe",YI="emulator/auth/iframe",XI={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},ZI=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function ew(n){const e=n.config;Q(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?nl(e,YI):`https://${n.config.authDomain}/${JI}`,s={apiKey:e.apiKey,appName:n.name,v:Hs},r=ZI.get(n.config.apiHost);r&&(s.eid=r);const i=n._getFrameworks();return i.length&&(s.fw=i.join(",")),`${t}?${di(s).slice(1)}`}async function tw(n){const e=await HI(n),t=Pt().gapi;return Q(t,n,"internal-error"),e.open({where:document.body,url:ew(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:XI,dontclear:!0},s=>new Promise(async(r,i)=>{await s.restyle({setHideOnLeave:!1});const o=Rt(n,"network-request-failed"),c=Pt().setTimeout(()=>{i(o)},QI.get());function l(){Pt().clearTimeout(c),r(s)}s.ping(l).then(l,()=>{i(o)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nw={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},sw=500,rw=600,iw="_blank",ow="http://localhost";class Nh{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function aw(n,e,t,s=sw,r=rw){const i=Math.max((window.screen.availHeight-r)/2,0).toString(),o=Math.max((window.screen.availWidth-s)/2,0).toString();let c="";const l=Object.assign(Object.assign({},nw),{width:s.toString(),height:r.toString(),top:i,left:o}),u=Ce().toLowerCase();t&&(c=Ff(u)?iw:t),$f(u)&&(e=e||ow,l.scrollbars="yes");const f=Object.entries(l).reduce((y,[S,k])=>`${y}${S}=${k},`,"");if(Pv(u)&&c!=="_self")return cw(e||"",c),new Nh(null);const p=window.open(e||"",c,f);Q(p,n,"popup-blocked");try{p.focus()}catch{}return new Nh(p)}function cw(n,e){const t=document.createElement("a");t.href=n,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lw="__/auth/handler",uw="emulator/auth/handler",hw=encodeURIComponent("fac");async function xh(n,e,t,s,r,i){Q(n.config.authDomain,n,"auth-domain-config-required"),Q(n.config.apiKey,n,"invalid-api-key");const o={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:s,v:Hs,eventId:r};if(e instanceof Hf){e.setDefaultLanguage(n.languageCode),o.providerId=e.providerId||"",J_(e.getCustomParameters())||(o.customParameters=JSON.stringify(e.getCustomParameters()));for(const[f,p]of Object.entries({}))o[f]=p}if(e instanceof pi){const f=e.getScopes().filter(p=>p!=="");f.length>0&&(o.scopes=f.join(","))}n.tenantId&&(o.tid=n.tenantId);const c=o;for(const f of Object.keys(c))c[f]===void 0&&delete c[f];const l=await n._getAppCheckToken(),u=l?`#${hw}=${encodeURIComponent(l)}`:"";return`${dw(n)}?${di(c).slice(1)}${u}`}function dw({config:n}){return n.emulator?nl(n,uw):`https://${n.authDomain}/${lw}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xa="webStorageSupport";class fw{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=ep,this._completeRedirectFn=MI,this._overrideRedirectResult=xI}async _openPopup(e,t,s,r){var i;Bt((i=this.eventManagers[e._key()])===null||i===void 0?void 0:i.manager,"_initialize() not called before _openPopup()");const o=await xh(e,t,s,mc(),r);return aw(e,o,al())}async _openRedirect(e,t,s,r){await this._originValidation(e);const i=await xh(e,t,s,mc(),r);return gI(i),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:r,promise:i}=this.eventManagers[t];return r?Promise.resolve(r):(Bt(i,"If manager is not set, promise should be"),i)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await tw(e),s=new FI(e);return t.register("authEvent",r=>(Q(r==null?void 0:r.authEvent,e,"invalid-auth-event"),{status:s.onEvent(r.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(Xa,{type:Xa},r=>{var i;const o=(i=r==null?void 0:r[0])===null||i===void 0?void 0:i[Xa];o!==void 0&&t(!!o),wt(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=GI(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Gf()||rl()||Wo()}}const pw=fw;var Oh="@firebase/auth",Lh="1.7.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mw{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){Q(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gw(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function _w(n){ks(new Kn("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),r=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:o,authDomain:c}=s.options;Q(o&&!o.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:o,authDomain:c,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:zf(n)},u=new Ov(s,r,i,l);return Gv(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),ks(new Kn("auth-internal",e=>{const t=Qs(e.getProvider("auth").getImmediate());return(s=>new mw(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),ln(Oh,Lh,gw(n)),ln(Oh,Lh,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yw=5*60,vw=wf("authIdTokenMaxAge")||yw;let Mh=null;const Iw=n=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>vw)return;const r=t==null?void 0:t.token;Mh!==r&&(Mh=r,await fetch(n,{method:r?"POST":"DELETE",headers:r?{Authorization:`Bearer ${r}`}:{}}))};function ww(n=Yy()){const e=Zc(n,"auth");if(e.isInitialized())return e.getImmediate();const t=jv(n,{popupRedirectResolver:pw,persistence:[AI,fI,ep]}),s=wf("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(s,location.origin);if(location.origin===i.origin){const o=Iw(i.toString());aI(t,o,()=>o(t.currentUser)),oI(t,c=>o(c))}}const r=F_("auth");return r&&zv(t,`http://${r}`),t}function Ew(){var n,e;return(e=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&e!==void 0?e:document}Lv({loadJS(n){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",n),s.onload=e,s.onerror=r=>{const i=Rt("internal-error");i.customData=r,t(i)},s.type="text/javascript",s.charset="UTF-8",Ew().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});_w("Browser");var $h=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Bn,ap;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(I,g){function _(){}_.prototype=g.prototype,I.D=g.prototype,I.prototype=new _,I.prototype.constructor=I,I.C=function(w,E,b){for(var v=Array(arguments.length-2),tt=2;tt<arguments.length;tt++)v[tt-2]=arguments[tt];return g.prototype[E].apply(w,v)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(s,t),s.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function r(I,g,_){_||(_=0);var w=Array(16);if(typeof g=="string")for(var E=0;16>E;++E)w[E]=g.charCodeAt(_++)|g.charCodeAt(_++)<<8|g.charCodeAt(_++)<<16|g.charCodeAt(_++)<<24;else for(E=0;16>E;++E)w[E]=g[_++]|g[_++]<<8|g[_++]<<16|g[_++]<<24;g=I.g[0],_=I.g[1],E=I.g[2];var b=I.g[3],v=g+(b^_&(E^b))+w[0]+3614090360&4294967295;g=_+(v<<7&4294967295|v>>>25),v=b+(E^g&(_^E))+w[1]+3905402710&4294967295,b=g+(v<<12&4294967295|v>>>20),v=E+(_^b&(g^_))+w[2]+606105819&4294967295,E=b+(v<<17&4294967295|v>>>15),v=_+(g^E&(b^g))+w[3]+3250441966&4294967295,_=E+(v<<22&4294967295|v>>>10),v=g+(b^_&(E^b))+w[4]+4118548399&4294967295,g=_+(v<<7&4294967295|v>>>25),v=b+(E^g&(_^E))+w[5]+1200080426&4294967295,b=g+(v<<12&4294967295|v>>>20),v=E+(_^b&(g^_))+w[6]+2821735955&4294967295,E=b+(v<<17&4294967295|v>>>15),v=_+(g^E&(b^g))+w[7]+4249261313&4294967295,_=E+(v<<22&4294967295|v>>>10),v=g+(b^_&(E^b))+w[8]+1770035416&4294967295,g=_+(v<<7&4294967295|v>>>25),v=b+(E^g&(_^E))+w[9]+2336552879&4294967295,b=g+(v<<12&4294967295|v>>>20),v=E+(_^b&(g^_))+w[10]+4294925233&4294967295,E=b+(v<<17&4294967295|v>>>15),v=_+(g^E&(b^g))+w[11]+2304563134&4294967295,_=E+(v<<22&4294967295|v>>>10),v=g+(b^_&(E^b))+w[12]+1804603682&4294967295,g=_+(v<<7&4294967295|v>>>25),v=b+(E^g&(_^E))+w[13]+4254626195&4294967295,b=g+(v<<12&4294967295|v>>>20),v=E+(_^b&(g^_))+w[14]+2792965006&4294967295,E=b+(v<<17&4294967295|v>>>15),v=_+(g^E&(b^g))+w[15]+1236535329&4294967295,_=E+(v<<22&4294967295|v>>>10),v=g+(E^b&(_^E))+w[1]+4129170786&4294967295,g=_+(v<<5&4294967295|v>>>27),v=b+(_^E&(g^_))+w[6]+3225465664&4294967295,b=g+(v<<9&4294967295|v>>>23),v=E+(g^_&(b^g))+w[11]+643717713&4294967295,E=b+(v<<14&4294967295|v>>>18),v=_+(b^g&(E^b))+w[0]+3921069994&4294967295,_=E+(v<<20&4294967295|v>>>12),v=g+(E^b&(_^E))+w[5]+3593408605&4294967295,g=_+(v<<5&4294967295|v>>>27),v=b+(_^E&(g^_))+w[10]+38016083&4294967295,b=g+(v<<9&4294967295|v>>>23),v=E+(g^_&(b^g))+w[15]+3634488961&4294967295,E=b+(v<<14&4294967295|v>>>18),v=_+(b^g&(E^b))+w[4]+3889429448&4294967295,_=E+(v<<20&4294967295|v>>>12),v=g+(E^b&(_^E))+w[9]+568446438&4294967295,g=_+(v<<5&4294967295|v>>>27),v=b+(_^E&(g^_))+w[14]+3275163606&4294967295,b=g+(v<<9&4294967295|v>>>23),v=E+(g^_&(b^g))+w[3]+4107603335&4294967295,E=b+(v<<14&4294967295|v>>>18),v=_+(b^g&(E^b))+w[8]+1163531501&4294967295,_=E+(v<<20&4294967295|v>>>12),v=g+(E^b&(_^E))+w[13]+2850285829&4294967295,g=_+(v<<5&4294967295|v>>>27),v=b+(_^E&(g^_))+w[2]+4243563512&4294967295,b=g+(v<<9&4294967295|v>>>23),v=E+(g^_&(b^g))+w[7]+1735328473&4294967295,E=b+(v<<14&4294967295|v>>>18),v=_+(b^g&(E^b))+w[12]+2368359562&4294967295,_=E+(v<<20&4294967295|v>>>12),v=g+(_^E^b)+w[5]+4294588738&4294967295,g=_+(v<<4&4294967295|v>>>28),v=b+(g^_^E)+w[8]+2272392833&4294967295,b=g+(v<<11&4294967295|v>>>21),v=E+(b^g^_)+w[11]+1839030562&4294967295,E=b+(v<<16&4294967295|v>>>16),v=_+(E^b^g)+w[14]+4259657740&4294967295,_=E+(v<<23&4294967295|v>>>9),v=g+(_^E^b)+w[1]+2763975236&4294967295,g=_+(v<<4&4294967295|v>>>28),v=b+(g^_^E)+w[4]+1272893353&4294967295,b=g+(v<<11&4294967295|v>>>21),v=E+(b^g^_)+w[7]+4139469664&4294967295,E=b+(v<<16&4294967295|v>>>16),v=_+(E^b^g)+w[10]+3200236656&4294967295,_=E+(v<<23&4294967295|v>>>9),v=g+(_^E^b)+w[13]+681279174&4294967295,g=_+(v<<4&4294967295|v>>>28),v=b+(g^_^E)+w[0]+3936430074&4294967295,b=g+(v<<11&4294967295|v>>>21),v=E+(b^g^_)+w[3]+3572445317&4294967295,E=b+(v<<16&4294967295|v>>>16),v=_+(E^b^g)+w[6]+76029189&4294967295,_=E+(v<<23&4294967295|v>>>9),v=g+(_^E^b)+w[9]+3654602809&4294967295,g=_+(v<<4&4294967295|v>>>28),v=b+(g^_^E)+w[12]+3873151461&4294967295,b=g+(v<<11&4294967295|v>>>21),v=E+(b^g^_)+w[15]+530742520&4294967295,E=b+(v<<16&4294967295|v>>>16),v=_+(E^b^g)+w[2]+3299628645&4294967295,_=E+(v<<23&4294967295|v>>>9),v=g+(E^(_|~b))+w[0]+4096336452&4294967295,g=_+(v<<6&4294967295|v>>>26),v=b+(_^(g|~E))+w[7]+1126891415&4294967295,b=g+(v<<10&4294967295|v>>>22),v=E+(g^(b|~_))+w[14]+2878612391&4294967295,E=b+(v<<15&4294967295|v>>>17),v=_+(b^(E|~g))+w[5]+4237533241&4294967295,_=E+(v<<21&4294967295|v>>>11),v=g+(E^(_|~b))+w[12]+1700485571&4294967295,g=_+(v<<6&4294967295|v>>>26),v=b+(_^(g|~E))+w[3]+2399980690&4294967295,b=g+(v<<10&4294967295|v>>>22),v=E+(g^(b|~_))+w[10]+4293915773&4294967295,E=b+(v<<15&4294967295|v>>>17),v=_+(b^(E|~g))+w[1]+2240044497&4294967295,_=E+(v<<21&4294967295|v>>>11),v=g+(E^(_|~b))+w[8]+1873313359&4294967295,g=_+(v<<6&4294967295|v>>>26),v=b+(_^(g|~E))+w[15]+4264355552&4294967295,b=g+(v<<10&4294967295|v>>>22),v=E+(g^(b|~_))+w[6]+2734768916&4294967295,E=b+(v<<15&4294967295|v>>>17),v=_+(b^(E|~g))+w[13]+1309151649&4294967295,_=E+(v<<21&4294967295|v>>>11),v=g+(E^(_|~b))+w[4]+4149444226&4294967295,g=_+(v<<6&4294967295|v>>>26),v=b+(_^(g|~E))+w[11]+3174756917&4294967295,b=g+(v<<10&4294967295|v>>>22),v=E+(g^(b|~_))+w[2]+718787259&4294967295,E=b+(v<<15&4294967295|v>>>17),v=_+(b^(E|~g))+w[9]+3951481745&4294967295,I.g[0]=I.g[0]+g&4294967295,I.g[1]=I.g[1]+(E+(v<<21&4294967295|v>>>11))&4294967295,I.g[2]=I.g[2]+E&4294967295,I.g[3]=I.g[3]+b&4294967295}s.prototype.u=function(I,g){g===void 0&&(g=I.length);for(var _=g-this.blockSize,w=this.B,E=this.h,b=0;b<g;){if(E==0)for(;b<=_;)r(this,I,b),b+=this.blockSize;if(typeof I=="string"){for(;b<g;)if(w[E++]=I.charCodeAt(b++),E==this.blockSize){r(this,w),E=0;break}}else for(;b<g;)if(w[E++]=I[b++],E==this.blockSize){r(this,w),E=0;break}}this.h=E,this.o+=g},s.prototype.v=function(){var I=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);I[0]=128;for(var g=1;g<I.length-8;++g)I[g]=0;var _=8*this.o;for(g=I.length-8;g<I.length;++g)I[g]=_&255,_/=256;for(this.u(I),I=Array(16),g=_=0;4>g;++g)for(var w=0;32>w;w+=8)I[_++]=this.g[g]>>>w&255;return I};function i(I,g){var _=c;return Object.prototype.hasOwnProperty.call(_,I)?_[I]:_[I]=g(I)}function o(I,g){this.h=g;for(var _=[],w=!0,E=I.length-1;0<=E;E--){var b=I[E]|0;w&&b==g||(_[E]=b,w=!1)}this.g=_}var c={};function l(I){return-128<=I&&128>I?i(I,function(g){return new o([g|0],0>g?-1:0)}):new o([I|0],0>I?-1:0)}function u(I){if(isNaN(I)||!isFinite(I))return p;if(0>I)return R(u(-I));for(var g=[],_=1,w=0;I>=_;w++)g[w]=I/_|0,_*=4294967296;return new o(g,0)}function f(I,g){if(I.length==0)throw Error("number format error: empty string");if(g=g||10,2>g||36<g)throw Error("radix out of range: "+g);if(I.charAt(0)=="-")return R(f(I.substring(1),g));if(0<=I.indexOf("-"))throw Error('number format error: interior "-" character');for(var _=u(Math.pow(g,8)),w=p,E=0;E<I.length;E+=8){var b=Math.min(8,I.length-E),v=parseInt(I.substring(E,E+b),g);8>b?(b=u(Math.pow(g,b)),w=w.j(b).add(u(v))):(w=w.j(_),w=w.add(u(v)))}return w}var p=l(0),y=l(1),S=l(16777216);n=o.prototype,n.m=function(){if(V(this))return-R(this).m();for(var I=0,g=1,_=0;_<this.g.length;_++){var w=this.i(_);I+=(0<=w?w:4294967296+w)*g,g*=4294967296}return I},n.toString=function(I){if(I=I||10,2>I||36<I)throw Error("radix out of range: "+I);if(k(this))return"0";if(V(this))return"-"+R(this).toString(I);for(var g=u(Math.pow(I,6)),_=this,w="";;){var E=Z(_,g).g;_=B(_,E.j(g));var b=((0<_.g.length?_.g[0]:_.h)>>>0).toString(I);if(_=E,k(_))return b+w;for(;6>b.length;)b="0"+b;w=b+w}},n.i=function(I){return 0>I?0:I<this.g.length?this.g[I]:this.h};function k(I){if(I.h!=0)return!1;for(var g=0;g<I.g.length;g++)if(I.g[g]!=0)return!1;return!0}function V(I){return I.h==-1}n.l=function(I){return I=B(this,I),V(I)?-1:k(I)?0:1};function R(I){for(var g=I.g.length,_=[],w=0;w<g;w++)_[w]=~I.g[w];return new o(_,~I.h).add(y)}n.abs=function(){return V(this)?R(this):this},n.add=function(I){for(var g=Math.max(this.g.length,I.g.length),_=[],w=0,E=0;E<=g;E++){var b=w+(this.i(E)&65535)+(I.i(E)&65535),v=(b>>>16)+(this.i(E)>>>16)+(I.i(E)>>>16);w=v>>>16,b&=65535,v&=65535,_[E]=v<<16|b}return new o(_,_[_.length-1]&-2147483648?-1:0)};function B(I,g){return I.add(R(g))}n.j=function(I){if(k(this)||k(I))return p;if(V(this))return V(I)?R(this).j(R(I)):R(R(this).j(I));if(V(I))return R(this.j(R(I)));if(0>this.l(S)&&0>I.l(S))return u(this.m()*I.m());for(var g=this.g.length+I.g.length,_=[],w=0;w<2*g;w++)_[w]=0;for(w=0;w<this.g.length;w++)for(var E=0;E<I.g.length;E++){var b=this.i(w)>>>16,v=this.i(w)&65535,tt=I.i(E)>>>16,Et=I.i(E)&65535;_[2*w+2*E]+=v*Et,z(_,2*w+2*E),_[2*w+2*E+1]+=b*Et,z(_,2*w+2*E+1),_[2*w+2*E+1]+=v*tt,z(_,2*w+2*E+1),_[2*w+2*E+2]+=b*tt,z(_,2*w+2*E+2)}for(w=0;w<g;w++)_[w]=_[2*w+1]<<16|_[2*w];for(w=g;w<2*g;w++)_[w]=0;return new o(_,0)};function z(I,g){for(;(I[g]&65535)!=I[g];)I[g+1]+=I[g]>>>16,I[g]&=65535,g++}function j(I,g){this.g=I,this.h=g}function Z(I,g){if(k(g))throw Error("division by zero");if(k(I))return new j(p,p);if(V(I))return g=Z(R(I),g),new j(R(g.g),R(g.h));if(V(g))return g=Z(I,R(g)),new j(R(g.g),g.h);if(30<I.g.length){if(V(I)||V(g))throw Error("slowDivide_ only works with positive integers.");for(var _=y,w=g;0>=w.l(I);)_=N(_),w=N(w);var E=M(_,1),b=M(w,1);for(w=M(w,2),_=M(_,2);!k(w);){var v=b.add(w);0>=v.l(I)&&(E=E.add(_),b=v),w=M(w,1),_=M(_,1)}return g=B(I,E.j(g)),new j(E,g)}for(E=p;0<=I.l(g);){for(_=Math.max(1,Math.floor(I.m()/g.m())),w=Math.ceil(Math.log(_)/Math.LN2),w=48>=w?1:Math.pow(2,w-48),b=u(_),v=b.j(g);V(v)||0<v.l(I);)_-=w,b=u(_),v=b.j(g);k(b)&&(b=y),E=E.add(b),I=B(I,v)}return new j(E,I)}n.A=function(I){return Z(this,I).h},n.and=function(I){for(var g=Math.max(this.g.length,I.g.length),_=[],w=0;w<g;w++)_[w]=this.i(w)&I.i(w);return new o(_,this.h&I.h)},n.or=function(I){for(var g=Math.max(this.g.length,I.g.length),_=[],w=0;w<g;w++)_[w]=this.i(w)|I.i(w);return new o(_,this.h|I.h)},n.xor=function(I){for(var g=Math.max(this.g.length,I.g.length),_=[],w=0;w<g;w++)_[w]=this.i(w)^I.i(w);return new o(_,this.h^I.h)};function N(I){for(var g=I.g.length+1,_=[],w=0;w<g;w++)_[w]=I.i(w)<<1|I.i(w-1)>>>31;return new o(_,I.h)}function M(I,g){var _=g>>5;g%=32;for(var w=I.g.length-_,E=[],b=0;b<w;b++)E[b]=0<g?I.i(b+_)>>>g|I.i(b+_+1)<<32-g:I.i(b+_);return new o(E,I.h)}s.prototype.digest=s.prototype.v,s.prototype.reset=s.prototype.s,s.prototype.update=s.prototype.u,ap=s,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.A,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=u,o.fromString=f,Bn=o}).apply(typeof $h<"u"?$h:typeof self<"u"?self:typeof window<"u"?window:{});var Ki=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var cp,lp,kr,up,ro,yc,hp,dp,fp;(function(){var n,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(a,h,d){return a==Array.prototype||a==Object.prototype||(a[h]=d.value),a};function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof Ki=="object"&&Ki];for(var h=0;h<a.length;++h){var d=a[h];if(d&&d.Math==Math)return d}throw Error("Cannot find global object")}var s=t(this);function r(a,h){if(h)e:{var d=s;a=a.split(".");for(var m=0;m<a.length-1;m++){var T=a[m];if(!(T in d))break e;d=d[T]}a=a[a.length-1],m=d[a],h=h(m),h!=m&&h!=null&&e(d,a,{configurable:!0,writable:!0,value:h})}}function i(a,h){a instanceof String&&(a+="");var d=0,m=!1,T={next:function(){if(!m&&d<a.length){var P=d++;return{value:h(P,a[P]),done:!1}}return m=!0,{done:!0,value:void 0}}};return T[Symbol.iterator]=function(){return T},T}r("Array.prototype.values",function(a){return a||function(){return i(this,function(h,d){return d})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},c=this||self;function l(a){var h=typeof a;return h=h!="object"?h:a?Array.isArray(a)?"array":h:"null",h=="array"||h=="object"&&typeof a.length=="number"}function u(a){var h=typeof a;return h=="object"&&a!=null||h=="function"}function f(a,h,d){return a.call.apply(a.bind,arguments)}function p(a,h,d){if(!a)throw Error();if(2<arguments.length){var m=Array.prototype.slice.call(arguments,2);return function(){var T=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(T,m),a.apply(h,T)}}return function(){return a.apply(h,arguments)}}function y(a,h,d){return y=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?f:p,y.apply(null,arguments)}function S(a,h){var d=Array.prototype.slice.call(arguments,1);return function(){var m=d.slice();return m.push.apply(m,arguments),a.apply(this,m)}}function k(a,h){function d(){}d.prototype=h.prototype,a.aa=h.prototype,a.prototype=new d,a.prototype.constructor=a,a.Qb=function(m,T,P){for(var L=Array(arguments.length-2),de=2;de<arguments.length;de++)L[de-2]=arguments[de];return h.prototype[T].apply(m,L)}}function V(a){const h=a.length;if(0<h){const d=Array(h);for(let m=0;m<h;m++)d[m]=a[m];return d}return[]}function R(a,h){for(let d=1;d<arguments.length;d++){const m=arguments[d];if(l(m)){const T=a.length||0,P=m.length||0;a.length=T+P;for(let L=0;L<P;L++)a[T+L]=m[L]}else a.push(m)}}class B{constructor(h,d){this.i=h,this.j=d,this.h=0,this.g=null}get(){let h;return 0<this.h?(this.h--,h=this.g,this.g=h.next,h.next=null):h=this.i(),h}}function z(a){return/^[\s\xa0]*$/.test(a)}function j(){var a=c.navigator;return a&&(a=a.userAgent)?a:""}function Z(a){return Z[" "](a),a}Z[" "]=function(){};var N=j().indexOf("Gecko")!=-1&&!(j().toLowerCase().indexOf("webkit")!=-1&&j().indexOf("Edge")==-1)&&!(j().indexOf("Trident")!=-1||j().indexOf("MSIE")!=-1)&&j().indexOf("Edge")==-1;function M(a,h,d){for(const m in a)h.call(d,a[m],m,a)}function I(a,h){for(const d in a)h.call(void 0,a[d],d,a)}function g(a){const h={};for(const d in a)h[d]=a[d];return h}const _="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function w(a,h){let d,m;for(let T=1;T<arguments.length;T++){m=arguments[T];for(d in m)a[d]=m[d];for(let P=0;P<_.length;P++)d=_[P],Object.prototype.hasOwnProperty.call(m,d)&&(a[d]=m[d])}}function E(a){var h=1;a=a.split(":");const d=[];for(;0<h&&a.length;)d.push(a.shift()),h--;return a.length&&d.push(a.join(":")),d}function b(a){c.setTimeout(()=>{throw a},0)}function v(){var a=Ea;let h=null;return a.g&&(h=a.g,a.g=a.g.next,a.g||(a.h=null),h.next=null),h}class tt{constructor(){this.h=this.g=null}add(h,d){const m=Et.get();m.set(h,d),this.h?this.h.next=m:this.g=m,this.h=m}}var Et=new B(()=>new Yg,a=>a.reset());class Yg{constructor(){this.next=this.g=this.h=null}set(h,d){this.h=h,this.g=d,this.next=null}reset(){this.next=this.g=this.h=null}}let sr,rr=!1,Ea=new tt,cu=()=>{const a=c.Promise.resolve(void 0);sr=()=>{a.then(Xg)}};var Xg=()=>{for(var a;a=v();){try{a.h.call(a.g)}catch(d){b(d)}var h=Et;h.j(a),100>h.h&&(h.h++,a.next=h.g,h.g=a)}rr=!1};function Kt(){this.s=this.s,this.C=this.C}Kt.prototype.s=!1,Kt.prototype.ma=function(){this.s||(this.s=!0,this.N())},Kt.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function Be(a,h){this.type=a,this.g=this.target=h,this.defaultPrevented=!1}Be.prototype.h=function(){this.defaultPrevented=!0};var Zg=function(){if(!c.addEventListener||!Object.defineProperty)return!1;var a=!1,h=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const d=()=>{};c.addEventListener("test",d,h),c.removeEventListener("test",d,h)}catch{}return a}();function ir(a,h){if(Be.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a){var d=this.type=a.type,m=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;if(this.target=a.target||a.srcElement,this.g=h,h=a.relatedTarget){if(N){e:{try{Z(h.nodeName);var T=!0;break e}catch{}T=!1}T||(h=null)}}else d=="mouseover"?h=a.fromElement:d=="mouseout"&&(h=a.toElement);this.relatedTarget=h,m?(this.clientX=m.clientX!==void 0?m.clientX:m.pageX,this.clientY=m.clientY!==void 0?m.clientY:m.pageY,this.screenX=m.screenX||0,this.screenY=m.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=typeof a.pointerType=="string"?a.pointerType:e_[a.pointerType]||"",this.state=a.state,this.i=a,a.defaultPrevented&&ir.aa.h.call(this)}}k(ir,Be);var e_={2:"touch",3:"pen",4:"mouse"};ir.prototype.h=function(){ir.aa.h.call(this);var a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var Ri="closure_listenable_"+(1e6*Math.random()|0),t_=0;function n_(a,h,d,m,T){this.listener=a,this.proxy=null,this.src=h,this.type=d,this.capture=!!m,this.ha=T,this.key=++t_,this.da=this.fa=!1}function Pi(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function ki(a){this.src=a,this.g={},this.h=0}ki.prototype.add=function(a,h,d,m,T){var P=a.toString();a=this.g[P],a||(a=this.g[P]=[],this.h++);var L=Ta(a,h,m,T);return-1<L?(h=a[L],d||(h.fa=!1)):(h=new n_(h,this.src,P,!!m,T),h.fa=d,a.push(h)),h};function ba(a,h){var d=h.type;if(d in a.g){var m=a.g[d],T=Array.prototype.indexOf.call(m,h,void 0),P;(P=0<=T)&&Array.prototype.splice.call(m,T,1),P&&(Pi(h),a.g[d].length==0&&(delete a.g[d],a.h--))}}function Ta(a,h,d,m){for(var T=0;T<a.length;++T){var P=a[T];if(!P.da&&P.listener==h&&P.capture==!!d&&P.ha==m)return T}return-1}var Aa="closure_lm_"+(1e6*Math.random()|0),Sa={};function lu(a,h,d,m,T){if(Array.isArray(h)){for(var P=0;P<h.length;P++)lu(a,h[P],d,m,T);return null}return d=du(d),a&&a[Ri]?a.K(h,d,u(m)?!!m.capture:!1,T):s_(a,h,d,!1,m,T)}function s_(a,h,d,m,T,P){if(!h)throw Error("Invalid event type");var L=u(T)?!!T.capture:!!T,de=Pa(a);if(de||(a[Aa]=de=new ki(a)),d=de.add(h,d,m,L,P),d.proxy)return d;if(m=r_(),d.proxy=m,m.src=a,m.listener=d,a.addEventListener)Zg||(T=L),T===void 0&&(T=!1),a.addEventListener(h.toString(),m,T);else if(a.attachEvent)a.attachEvent(hu(h.toString()),m);else if(a.addListener&&a.removeListener)a.addListener(m);else throw Error("addEventListener and attachEvent are unavailable.");return d}function r_(){function a(d){return h.call(a.src,a.listener,d)}const h=i_;return a}function uu(a,h,d,m,T){if(Array.isArray(h))for(var P=0;P<h.length;P++)uu(a,h[P],d,m,T);else m=u(m)?!!m.capture:!!m,d=du(d),a&&a[Ri]?(a=a.i,h=String(h).toString(),h in a.g&&(P=a.g[h],d=Ta(P,d,m,T),-1<d&&(Pi(P[d]),Array.prototype.splice.call(P,d,1),P.length==0&&(delete a.g[h],a.h--)))):a&&(a=Pa(a))&&(h=a.g[h.toString()],a=-1,h&&(a=Ta(h,d,m,T)),(d=-1<a?h[a]:null)&&Ra(d))}function Ra(a){if(typeof a!="number"&&a&&!a.da){var h=a.src;if(h&&h[Ri])ba(h.i,a);else{var d=a.type,m=a.proxy;h.removeEventListener?h.removeEventListener(d,m,a.capture):h.detachEvent?h.detachEvent(hu(d),m):h.addListener&&h.removeListener&&h.removeListener(m),(d=Pa(h))?(ba(d,a),d.h==0&&(d.src=null,h[Aa]=null)):Pi(a)}}}function hu(a){return a in Sa?Sa[a]:Sa[a]="on"+a}function i_(a,h){if(a.da)a=!0;else{h=new ir(h,this);var d=a.listener,m=a.ha||a.src;a.fa&&Ra(a),a=d.call(m,h)}return a}function Pa(a){return a=a[Aa],a instanceof ki?a:null}var ka="__closure_events_fn_"+(1e9*Math.random()>>>0);function du(a){return typeof a=="function"?a:(a[ka]||(a[ka]=function(h){return a.handleEvent(h)}),a[ka])}function qe(){Kt.call(this),this.i=new ki(this),this.M=this,this.F=null}k(qe,Kt),qe.prototype[Ri]=!0,qe.prototype.removeEventListener=function(a,h,d,m){uu(this,a,h,d,m)};function Qe(a,h){var d,m=a.F;if(m)for(d=[];m;m=m.F)d.push(m);if(a=a.M,m=h.type||h,typeof h=="string")h=new Be(h,a);else if(h instanceof Be)h.target=h.target||a;else{var T=h;h=new Be(m,a),w(h,T)}if(T=!0,d)for(var P=d.length-1;0<=P;P--){var L=h.g=d[P];T=Ci(L,m,!0,h)&&T}if(L=h.g=a,T=Ci(L,m,!0,h)&&T,T=Ci(L,m,!1,h)&&T,d)for(P=0;P<d.length;P++)L=h.g=d[P],T=Ci(L,m,!1,h)&&T}qe.prototype.N=function(){if(qe.aa.N.call(this),this.i){var a=this.i,h;for(h in a.g){for(var d=a.g[h],m=0;m<d.length;m++)Pi(d[m]);delete a.g[h],a.h--}}this.F=null},qe.prototype.K=function(a,h,d,m){return this.i.add(String(a),h,!1,d,m)},qe.prototype.L=function(a,h,d,m){return this.i.add(String(a),h,!0,d,m)};function Ci(a,h,d,m){if(h=a.i.g[String(h)],!h)return!0;h=h.concat();for(var T=!0,P=0;P<h.length;++P){var L=h[P];if(L&&!L.da&&L.capture==d){var de=L.listener,Me=L.ha||L.src;L.fa&&ba(a.i,L),T=de.call(Me,m)!==!1&&T}}return T&&!m.defaultPrevented}function fu(a,h,d){if(typeof a=="function")d&&(a=y(a,d));else if(a&&typeof a.handleEvent=="function")a=y(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<Number(h)?-1:c.setTimeout(a,h||0)}function pu(a){a.g=fu(()=>{a.g=null,a.i&&(a.i=!1,pu(a))},a.l);const h=a.h;a.h=null,a.m.apply(null,h)}class o_ extends Kt{constructor(h,d){super(),this.m=h,this.l=d,this.h=null,this.i=!1,this.g=null}j(h){this.h=arguments,this.g?this.i=!0:pu(this)}N(){super.N(),this.g&&(c.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function or(a){Kt.call(this),this.h=a,this.g={}}k(or,Kt);var mu=[];function gu(a){M(a.g,function(h,d){this.g.hasOwnProperty(d)&&Ra(h)},a),a.g={}}or.prototype.N=function(){or.aa.N.call(this),gu(this)},or.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ca=c.JSON.stringify,a_=c.JSON.parse,c_=class{stringify(a){return c.JSON.stringify(a,void 0)}parse(a){return c.JSON.parse(a,void 0)}};function Da(){}Da.prototype.h=null;function _u(a){return a.h||(a.h=a.i())}function yu(){}var ar={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function Va(){Be.call(this,"d")}k(Va,Be);function Na(){Be.call(this,"c")}k(Na,Be);var Pn={},vu=null;function Di(){return vu=vu||new qe}Pn.La="serverreachability";function Iu(a){Be.call(this,Pn.La,a)}k(Iu,Be);function cr(a){const h=Di();Qe(h,new Iu(h))}Pn.STAT_EVENT="statevent";function wu(a,h){Be.call(this,Pn.STAT_EVENT,a),this.stat=h}k(wu,Be);function Je(a){const h=Di();Qe(h,new wu(h,a))}Pn.Ma="timingevent";function Eu(a,h){Be.call(this,Pn.Ma,a),this.size=h}k(Eu,Be);function lr(a,h){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return c.setTimeout(function(){a()},h)}function ur(){this.g=!0}ur.prototype.xa=function(){this.g=!1};function l_(a,h,d,m,T,P){a.info(function(){if(a.g)if(P)for(var L="",de=P.split("&"),Me=0;Me<de.length;Me++){var ce=de[Me].split("=");if(1<ce.length){var je=ce[0];ce=ce[1];var Ge=je.split("_");L=2<=Ge.length&&Ge[1]=="type"?L+(je+"="+ce+"&"):L+(je+"=redacted&")}}else L=null;else L=P;return"XMLHTTP REQ ("+m+") [attempt "+T+"]: "+h+`
`+d+`
`+L})}function u_(a,h,d,m,T,P,L){a.info(function(){return"XMLHTTP RESP ("+m+") [ attempt "+T+"]: "+h+`
`+d+`
`+P+" "+L})}function as(a,h,d,m){a.info(function(){return"XMLHTTP TEXT ("+h+"): "+d_(a,d)+(m?" "+m:"")})}function h_(a,h){a.info(function(){return"TIMEOUT: "+h})}ur.prototype.info=function(){};function d_(a,h){if(!a.g)return h;if(!h)return null;try{var d=JSON.parse(h);if(d){for(a=0;a<d.length;a++)if(Array.isArray(d[a])){var m=d[a];if(!(2>m.length)){var T=m[1];if(Array.isArray(T)&&!(1>T.length)){var P=T[0];if(P!="noop"&&P!="stop"&&P!="close")for(var L=1;L<T.length;L++)T[L]=""}}}}return Ca(d)}catch{return h}}var Vi={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},bu={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},xa;function Ni(){}k(Ni,Da),Ni.prototype.g=function(){return new XMLHttpRequest},Ni.prototype.i=function(){return{}},xa=new Ni;function Wt(a,h,d,m){this.j=a,this.i=h,this.l=d,this.R=m||1,this.U=new or(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new Tu}function Tu(){this.i=null,this.g="",this.h=!1}var Au={},Oa={};function La(a,h,d){a.L=1,a.v=Mi(Dt(h)),a.m=d,a.P=!0,Su(a,null)}function Su(a,h){a.F=Date.now(),xi(a),a.A=Dt(a.v);var d=a.A,m=a.R;Array.isArray(m)||(m=[String(m)]),Uu(d.i,"t",m),a.C=0,d=a.j.J,a.h=new Tu,a.g=rh(a.j,d?h:null,!a.m),0<a.O&&(a.M=new o_(y(a.Y,a,a.g),a.O)),h=a.U,d=a.g,m=a.ca;var T="readystatechange";Array.isArray(T)||(T&&(mu[0]=T.toString()),T=mu);for(var P=0;P<T.length;P++){var L=lu(d,T[P],m||h.handleEvent,!1,h.h||h);if(!L)break;h.g[L.key]=L}h=a.H?g(a.H):{},a.m?(a.u||(a.u="POST"),h["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.A,a.u,a.m,h)):(a.u="GET",a.g.ea(a.A,a.u,null,h)),cr(),l_(a.i,a.u,a.A,a.l,a.R,a.m)}Wt.prototype.ca=function(a){a=a.target;const h=this.M;h&&Vt(a)==3?h.j():this.Y(a)},Wt.prototype.Y=function(a){try{if(a==this.g)e:{const Ge=Vt(this.g);var h=this.g.Ba();const us=this.g.Z();if(!(3>Ge)&&(Ge!=3||this.g&&(this.h.h||this.g.oa()||Wu(this.g)))){this.J||Ge!=4||h==7||(h==8||0>=us?cr(3):cr(2)),Ma(this);var d=this.g.Z();this.X=d;t:if(Ru(this)){var m=Wu(this.g);a="";var T=m.length,P=Vt(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){kn(this),hr(this);var L="";break t}this.h.i=new c.TextDecoder}for(h=0;h<T;h++)this.h.h=!0,a+=this.h.i.decode(m[h],{stream:!(P&&h==T-1)});m.length=0,this.h.g+=a,this.C=0,L=this.h.g}else L=this.g.oa();if(this.o=d==200,u_(this.i,this.u,this.A,this.l,this.R,Ge,d),this.o){if(this.T&&!this.K){t:{if(this.g){var de,Me=this.g;if((de=Me.g?Me.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!z(de)){var ce=de;break t}}ce=null}if(d=ce)as(this.i,this.l,d,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,$a(this,d);else{this.o=!1,this.s=3,Je(12),kn(this),hr(this);break e}}if(this.P){d=!0;let mt;for(;!this.J&&this.C<L.length;)if(mt=f_(this,L),mt==Oa){Ge==4&&(this.s=4,Je(14),d=!1),as(this.i,this.l,null,"[Incomplete Response]");break}else if(mt==Au){this.s=4,Je(15),as(this.i,this.l,L,"[Invalid Chunk]"),d=!1;break}else as(this.i,this.l,mt,null),$a(this,mt);if(Ru(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),Ge!=4||L.length!=0||this.h.h||(this.s=1,Je(16),d=!1),this.o=this.o&&d,!d)as(this.i,this.l,L,"[Invalid Chunked Response]"),kn(this),hr(this);else if(0<L.length&&!this.W){this.W=!0;var je=this.j;je.g==this&&je.ba&&!je.M&&(je.j.info("Great, no buffering proxy detected. Bytes received: "+L.length),Ga(je),je.M=!0,Je(11))}}else as(this.i,this.l,L,null),$a(this,L);Ge==4&&kn(this),this.o&&!this.J&&(Ge==4?eh(this.j,this):(this.o=!1,xi(this)))}else C_(this.g),d==400&&0<L.indexOf("Unknown SID")?(this.s=3,Je(12)):(this.s=0,Je(13)),kn(this),hr(this)}}}catch{}finally{}};function Ru(a){return a.g?a.u=="GET"&&a.L!=2&&a.j.Ca:!1}function f_(a,h){var d=a.C,m=h.indexOf(`
`,d);return m==-1?Oa:(d=Number(h.substring(d,m)),isNaN(d)?Au:(m+=1,m+d>h.length?Oa:(h=h.slice(m,m+d),a.C=m+d,h)))}Wt.prototype.cancel=function(){this.J=!0,kn(this)};function xi(a){a.S=Date.now()+a.I,Pu(a,a.I)}function Pu(a,h){if(a.B!=null)throw Error("WatchDog timer not null");a.B=lr(y(a.ba,a),h)}function Ma(a){a.B&&(c.clearTimeout(a.B),a.B=null)}Wt.prototype.ba=function(){this.B=null;const a=Date.now();0<=a-this.S?(h_(this.i,this.A),this.L!=2&&(cr(),Je(17)),kn(this),this.s=2,hr(this)):Pu(this,this.S-a)};function hr(a){a.j.G==0||a.J||eh(a.j,a)}function kn(a){Ma(a);var h=a.M;h&&typeof h.ma=="function"&&h.ma(),a.M=null,gu(a.U),a.g&&(h=a.g,a.g=null,h.abort(),h.ma())}function $a(a,h){try{var d=a.j;if(d.G!=0&&(d.g==a||Fa(d.h,a))){if(!a.K&&Fa(d.h,a)&&d.G==3){try{var m=d.Da.g.parse(h)}catch{m=null}if(Array.isArray(m)&&m.length==3){var T=m;if(T[0]==0){e:if(!d.u){if(d.g)if(d.g.F+3e3<a.F)qi(d),Ui(d);else break e;ja(d),Je(18)}}else d.za=T[1],0<d.za-d.T&&37500>T[2]&&d.F&&d.v==0&&!d.C&&(d.C=lr(y(d.Za,d),6e3));if(1>=Du(d.h)&&d.ca){try{d.ca()}catch{}d.ca=void 0}}else Dn(d,11)}else if((a.K||d.g==a)&&qi(d),!z(h))for(T=d.Da.g.parse(h),h=0;h<T.length;h++){let ce=T[h];if(d.T=ce[0],ce=ce[1],d.G==2)if(ce[0]=="c"){d.K=ce[1],d.ia=ce[2];const je=ce[3];je!=null&&(d.la=je,d.j.info("VER="+d.la));const Ge=ce[4];Ge!=null&&(d.Aa=Ge,d.j.info("SVER="+d.Aa));const us=ce[5];us!=null&&typeof us=="number"&&0<us&&(m=1.5*us,d.L=m,d.j.info("backChannelRequestTimeoutMs_="+m)),m=d;const mt=a.g;if(mt){const Gi=mt.g?mt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Gi){var P=m.h;P.g||Gi.indexOf("spdy")==-1&&Gi.indexOf("quic")==-1&&Gi.indexOf("h2")==-1||(P.j=P.l,P.g=new Set,P.h&&(Ua(P,P.h),P.h=null))}if(m.D){const za=mt.g?mt.g.getResponseHeader("X-HTTP-Session-Id"):null;za&&(m.ya=za,me(m.I,m.D,za))}}d.G=3,d.l&&d.l.ua(),d.ba&&(d.R=Date.now()-a.F,d.j.info("Handshake RTT: "+d.R+"ms")),m=d;var L=a;if(m.qa=sh(m,m.J?m.ia:null,m.W),L.K){Vu(m.h,L);var de=L,Me=m.L;Me&&(de.I=Me),de.B&&(Ma(de),xi(de)),m.g=L}else Xu(m);0<d.i.length&&Bi(d)}else ce[0]!="stop"&&ce[0]!="close"||Dn(d,7);else d.G==3&&(ce[0]=="stop"||ce[0]=="close"?ce[0]=="stop"?Dn(d,7):qa(d):ce[0]!="noop"&&d.l&&d.l.ta(ce),d.v=0)}}cr(4)}catch{}}var p_=class{constructor(a,h){this.g=a,this.map=h}};function ku(a){this.l=a||10,c.PerformanceNavigationTiming?(a=c.performance.getEntriesByType("navigation"),a=0<a.length&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(c.chrome&&c.chrome.loadTimes&&c.chrome.loadTimes()&&c.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function Cu(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Du(a){return a.h?1:a.g?a.g.size:0}function Fa(a,h){return a.h?a.h==h:a.g?a.g.has(h):!1}function Ua(a,h){a.g?a.g.add(h):a.h=h}function Vu(a,h){a.h&&a.h==h?a.h=null:a.g&&a.g.has(h)&&a.g.delete(h)}ku.prototype.cancel=function(){if(this.i=Nu(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function Nu(a){if(a.h!=null)return a.i.concat(a.h.D);if(a.g!=null&&a.g.size!==0){let h=a.i;for(const d of a.g.values())h=h.concat(d.D);return h}return V(a.i)}function m_(a){if(a.V&&typeof a.V=="function")return a.V();if(typeof Map<"u"&&a instanceof Map||typeof Set<"u"&&a instanceof Set)return Array.from(a.values());if(typeof a=="string")return a.split("");if(l(a)){for(var h=[],d=a.length,m=0;m<d;m++)h.push(a[m]);return h}h=[],d=0;for(m in a)h[d++]=a[m];return h}function g_(a){if(a.na&&typeof a.na=="function")return a.na();if(!a.V||typeof a.V!="function"){if(typeof Map<"u"&&a instanceof Map)return Array.from(a.keys());if(!(typeof Set<"u"&&a instanceof Set)){if(l(a)||typeof a=="string"){var h=[];a=a.length;for(var d=0;d<a;d++)h.push(d);return h}h=[],d=0;for(const m in a)h[d++]=m;return h}}}function xu(a,h){if(a.forEach&&typeof a.forEach=="function")a.forEach(h,void 0);else if(l(a)||typeof a=="string")Array.prototype.forEach.call(a,h,void 0);else for(var d=g_(a),m=m_(a),T=m.length,P=0;P<T;P++)h.call(void 0,m[P],d&&d[P],a)}var Ou=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function __(a,h){if(a){a=a.split("&");for(var d=0;d<a.length;d++){var m=a[d].indexOf("="),T=null;if(0<=m){var P=a[d].substring(0,m);T=a[d].substring(m+1)}else P=a[d];h(P,T?decodeURIComponent(T.replace(/\+/g," ")):"")}}}function Cn(a){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,a instanceof Cn){this.h=a.h,Oi(this,a.j),this.o=a.o,this.g=a.g,Li(this,a.s),this.l=a.l;var h=a.i,d=new pr;d.i=h.i,h.g&&(d.g=new Map(h.g),d.h=h.h),Lu(this,d),this.m=a.m}else a&&(h=String(a).match(Ou))?(this.h=!1,Oi(this,h[1]||"",!0),this.o=dr(h[2]||""),this.g=dr(h[3]||"",!0),Li(this,h[4]),this.l=dr(h[5]||"",!0),Lu(this,h[6]||"",!0),this.m=dr(h[7]||"")):(this.h=!1,this.i=new pr(null,this.h))}Cn.prototype.toString=function(){var a=[],h=this.j;h&&a.push(fr(h,Mu,!0),":");var d=this.g;return(d||h=="file")&&(a.push("//"),(h=this.o)&&a.push(fr(h,Mu,!0),"@"),a.push(encodeURIComponent(String(d)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),d=this.s,d!=null&&a.push(":",String(d))),(d=this.l)&&(this.g&&d.charAt(0)!="/"&&a.push("/"),a.push(fr(d,d.charAt(0)=="/"?I_:v_,!0))),(d=this.i.toString())&&a.push("?",d),(d=this.m)&&a.push("#",fr(d,E_)),a.join("")};function Dt(a){return new Cn(a)}function Oi(a,h,d){a.j=d?dr(h,!0):h,a.j&&(a.j=a.j.replace(/:$/,""))}function Li(a,h){if(h){if(h=Number(h),isNaN(h)||0>h)throw Error("Bad port number "+h);a.s=h}else a.s=null}function Lu(a,h,d){h instanceof pr?(a.i=h,b_(a.i,a.h)):(d||(h=fr(h,w_)),a.i=new pr(h,a.h))}function me(a,h,d){a.i.set(h,d)}function Mi(a){return me(a,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),a}function dr(a,h){return a?h?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function fr(a,h,d){return typeof a=="string"?(a=encodeURI(a).replace(h,y_),d&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function y_(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var Mu=/[#\/\?@]/g,v_=/[#\?:]/g,I_=/[#\?]/g,w_=/[#\?@]/g,E_=/#/g;function pr(a,h){this.h=this.g=null,this.i=a||null,this.j=!!h}function Ht(a){a.g||(a.g=new Map,a.h=0,a.i&&__(a.i,function(h,d){a.add(decodeURIComponent(h.replace(/\+/g," ")),d)}))}n=pr.prototype,n.add=function(a,h){Ht(this),this.i=null,a=cs(this,a);var d=this.g.get(a);return d||this.g.set(a,d=[]),d.push(h),this.h+=1,this};function $u(a,h){Ht(a),h=cs(a,h),a.g.has(h)&&(a.i=null,a.h-=a.g.get(h).length,a.g.delete(h))}function Fu(a,h){return Ht(a),h=cs(a,h),a.g.has(h)}n.forEach=function(a,h){Ht(this),this.g.forEach(function(d,m){d.forEach(function(T){a.call(h,T,m,this)},this)},this)},n.na=function(){Ht(this);const a=Array.from(this.g.values()),h=Array.from(this.g.keys()),d=[];for(let m=0;m<h.length;m++){const T=a[m];for(let P=0;P<T.length;P++)d.push(h[m])}return d},n.V=function(a){Ht(this);let h=[];if(typeof a=="string")Fu(this,a)&&(h=h.concat(this.g.get(cs(this,a))));else{a=Array.from(this.g.values());for(let d=0;d<a.length;d++)h=h.concat(a[d])}return h},n.set=function(a,h){return Ht(this),this.i=null,a=cs(this,a),Fu(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[h]),this.h+=1,this},n.get=function(a,h){return a?(a=this.V(a),0<a.length?String(a[0]):h):h};function Uu(a,h,d){$u(a,h),0<d.length&&(a.i=null,a.g.set(cs(a,h),V(d)),a.h+=d.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],h=Array.from(this.g.keys());for(var d=0;d<h.length;d++){var m=h[d];const P=encodeURIComponent(String(m)),L=this.V(m);for(m=0;m<L.length;m++){var T=P;L[m]!==""&&(T+="="+encodeURIComponent(String(L[m]))),a.push(T)}}return this.i=a.join("&")};function cs(a,h){return h=String(h),a.j&&(h=h.toLowerCase()),h}function b_(a,h){h&&!a.j&&(Ht(a),a.i=null,a.g.forEach(function(d,m){var T=m.toLowerCase();m!=T&&($u(this,m),Uu(this,T,d))},a)),a.j=h}function T_(a,h){const d=new ur;if(c.Image){const m=new Image;m.onload=S(Qt,d,"TestLoadImage: loaded",!0,h,m),m.onerror=S(Qt,d,"TestLoadImage: error",!1,h,m),m.onabort=S(Qt,d,"TestLoadImage: abort",!1,h,m),m.ontimeout=S(Qt,d,"TestLoadImage: timeout",!1,h,m),c.setTimeout(function(){m.ontimeout&&m.ontimeout()},1e4),m.src=a}else h(!1)}function A_(a,h){const d=new ur,m=new AbortController,T=setTimeout(()=>{m.abort(),Qt(d,"TestPingServer: timeout",!1,h)},1e4);fetch(a,{signal:m.signal}).then(P=>{clearTimeout(T),P.ok?Qt(d,"TestPingServer: ok",!0,h):Qt(d,"TestPingServer: server error",!1,h)}).catch(()=>{clearTimeout(T),Qt(d,"TestPingServer: error",!1,h)})}function Qt(a,h,d,m,T){try{T&&(T.onload=null,T.onerror=null,T.onabort=null,T.ontimeout=null),m(d)}catch{}}function S_(){this.g=new c_}function R_(a,h,d){const m=d||"";try{xu(a,function(T,P){let L=T;u(T)&&(L=Ca(T)),h.push(m+P+"="+encodeURIComponent(L))})}catch(T){throw h.push(m+"type="+encodeURIComponent("_badmap")),T}}function mr(a){this.l=a.Ub||null,this.j=a.eb||!1}k(mr,Da),mr.prototype.g=function(){return new $i(this.l,this.j)},mr.prototype.i=function(a){return function(){return a}}({});function $i(a,h){qe.call(this),this.D=a,this.o=h,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}k($i,qe),n=$i.prototype,n.open=function(a,h){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=a,this.A=h,this.readyState=1,_r(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const h={headers:this.u,method:this.B,credentials:this.m,cache:void 0};a&&(h.body=a),(this.D||c).fetch(new Request(this.A,h)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,gr(this)),this.readyState=0},n.Sa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,_r(this)),this.g&&(this.readyState=3,_r(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof c.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;Bu(this)}else a.text().then(this.Ra.bind(this),this.ga.bind(this))};function Bu(a){a.j.read().then(a.Pa.bind(a)).catch(a.ga.bind(a))}n.Pa=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var h=a.value?a.value:new Uint8Array(0);(h=this.v.decode(h,{stream:!a.done}))&&(this.response=this.responseText+=h)}a.done?gr(this):_r(this),this.readyState==3&&Bu(this)}},n.Ra=function(a){this.g&&(this.response=this.responseText=a,gr(this))},n.Qa=function(a){this.g&&(this.response=a,gr(this))},n.ga=function(){this.g&&gr(this)};function gr(a){a.readyState=4,a.l=null,a.j=null,a.v=null,_r(a)}n.setRequestHeader=function(a,h){this.u.append(a,h)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],h=this.h.entries();for(var d=h.next();!d.done;)d=d.value,a.push(d[0]+": "+d[1]),d=h.next();return a.join(`\r
`)};function _r(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty($i.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function qu(a){let h="";return M(a,function(d,m){h+=m,h+=":",h+=d,h+=`\r
`}),h}function Ba(a,h,d){e:{for(m in d){var m=!1;break e}m=!0}m||(d=qu(d),typeof a=="string"?d!=null&&encodeURIComponent(String(d)):me(a,h,d))}function Ie(a){qe.call(this),this.headers=new Map,this.o=a||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}k(Ie,qe);var P_=/^https?$/i,k_=["POST","PUT"];n=Ie.prototype,n.Ha=function(a){this.J=a},n.ea=function(a,h,d,m){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);h=h?h.toUpperCase():"GET",this.D=a,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():xa.g(),this.v=this.o?_u(this.o):_u(xa),this.g.onreadystatechange=y(this.Ea,this);try{this.B=!0,this.g.open(h,String(a),!0),this.B=!1}catch(P){ju(this,P);return}if(a=d||"",d=new Map(this.headers),m)if(Object.getPrototypeOf(m)===Object.prototype)for(var T in m)d.set(T,m[T]);else if(typeof m.keys=="function"&&typeof m.get=="function")for(const P of m.keys())d.set(P,m.get(P));else throw Error("Unknown input type for opt_headers: "+String(m));m=Array.from(d.keys()).find(P=>P.toLowerCase()=="content-type"),T=c.FormData&&a instanceof c.FormData,!(0<=Array.prototype.indexOf.call(k_,h,void 0))||m||T||d.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[P,L]of d)this.g.setRequestHeader(P,L);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{Ku(this),this.u=!0,this.g.send(a),this.u=!1}catch(P){ju(this,P)}};function ju(a,h){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=h,a.m=5,Gu(a),Fi(a)}function Gu(a){a.A||(a.A=!0,Qe(a,"complete"),Qe(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=a||7,Qe(this,"complete"),Qe(this,"abort"),Fi(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Fi(this,!0)),Ie.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?zu(this):this.bb())},n.bb=function(){zu(this)};function zu(a){if(a.h&&typeof o<"u"&&(!a.v[1]||Vt(a)!=4||a.Z()!=2)){if(a.u&&Vt(a)==4)fu(a.Ea,0,a);else if(Qe(a,"readystatechange"),Vt(a)==4){a.h=!1;try{const L=a.Z();e:switch(L){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var h=!0;break e;default:h=!1}var d;if(!(d=h)){var m;if(m=L===0){var T=String(a.D).match(Ou)[1]||null;!T&&c.self&&c.self.location&&(T=c.self.location.protocol.slice(0,-1)),m=!P_.test(T?T.toLowerCase():"")}d=m}if(d)Qe(a,"complete"),Qe(a,"success");else{a.m=6;try{var P=2<Vt(a)?a.g.statusText:""}catch{P=""}a.l=P+" ["+a.Z()+"]",Gu(a)}}finally{Fi(a)}}}}function Fi(a,h){if(a.g){Ku(a);const d=a.g,m=a.v[0]?()=>{}:null;a.g=null,a.v=null,h||Qe(a,"ready");try{d.onreadystatechange=m}catch{}}}function Ku(a){a.I&&(c.clearTimeout(a.I),a.I=null)}n.isActive=function(){return!!this.g};function Vt(a){return a.g?a.g.readyState:0}n.Z=function(){try{return 2<Vt(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(a){if(this.g){var h=this.g.responseText;return a&&h.indexOf(a)==0&&(h=h.substring(a.length)),a_(h)}};function Wu(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.H){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function C_(a){const h={};a=(a.g&&2<=Vt(a)&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let m=0;m<a.length;m++){if(z(a[m]))continue;var d=E(a[m]);const T=d[0];if(d=d[1],typeof d!="string")continue;d=d.trim();const P=h[T]||[];h[T]=P,P.push(d)}I(h,function(m){return m.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function yr(a,h,d){return d&&d.internalChannelParams&&d.internalChannelParams[a]||h}function Hu(a){this.Aa=0,this.i=[],this.j=new ur,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=yr("failFast",!1,a),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=yr("baseRetryDelayMs",5e3,a),this.cb=yr("retryDelaySeedMs",1e4,a),this.Wa=yr("forwardChannelMaxRetries",2,a),this.wa=yr("forwardChannelRequestTimeoutMs",2e4,a),this.pa=a&&a.xmlHttpFactory||void 0,this.Xa=a&&a.Tb||void 0,this.Ca=a&&a.useFetchStreams||!1,this.L=void 0,this.J=a&&a.supportsCrossDomainXhr||!1,this.K="",this.h=new ku(a&&a.concurrentRequestLimit),this.Da=new S_,this.P=a&&a.fastHandshake||!1,this.O=a&&a.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=a&&a.Rb||!1,a&&a.xa&&this.j.xa(),a&&a.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&a&&a.detectBufferingProxy||!1,this.ja=void 0,a&&a.longPollingTimeout&&0<a.longPollingTimeout&&(this.ja=a.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=Hu.prototype,n.la=8,n.G=1,n.connect=function(a,h,d,m){Je(0),this.W=a,this.H=h||{},d&&m!==void 0&&(this.H.OSID=d,this.H.OAID=m),this.F=this.X,this.I=sh(this,null,this.W),Bi(this)};function qa(a){if(Qu(a),a.G==3){var h=a.U++,d=Dt(a.I);if(me(d,"SID",a.K),me(d,"RID",h),me(d,"TYPE","terminate"),vr(a,d),h=new Wt(a,a.j,h),h.L=2,h.v=Mi(Dt(d)),d=!1,c.navigator&&c.navigator.sendBeacon)try{d=c.navigator.sendBeacon(h.v.toString(),"")}catch{}!d&&c.Image&&(new Image().src=h.v,d=!0),d||(h.g=rh(h.j,null),h.g.ea(h.v)),h.F=Date.now(),xi(h)}nh(a)}function Ui(a){a.g&&(Ga(a),a.g.cancel(),a.g=null)}function Qu(a){Ui(a),a.u&&(c.clearTimeout(a.u),a.u=null),qi(a),a.h.cancel(),a.s&&(typeof a.s=="number"&&c.clearTimeout(a.s),a.s=null)}function Bi(a){if(!Cu(a.h)&&!a.s){a.s=!0;var h=a.Ga;sr||cu(),rr||(sr(),rr=!0),Ea.add(h,a),a.B=0}}function D_(a,h){return Du(a.h)>=a.h.j-(a.s?1:0)?!1:a.s?(a.i=h.D.concat(a.i),!0):a.G==1||a.G==2||a.B>=(a.Va?0:a.Wa)?!1:(a.s=lr(y(a.Ga,a,h),th(a,a.B)),a.B++,!0)}n.Ga=function(a){if(this.s)if(this.s=null,this.G==1){if(!a){this.U=Math.floor(1e5*Math.random()),a=this.U++;const T=new Wt(this,this.j,a);let P=this.o;if(this.S&&(P?(P=g(P),w(P,this.S)):P=this.S),this.m!==null||this.O||(T.H=P,P=null),this.P)e:{for(var h=0,d=0;d<this.i.length;d++){t:{var m=this.i[d];if("__data__"in m.map&&(m=m.map.__data__,typeof m=="string")){m=m.length;break t}m=void 0}if(m===void 0)break;if(h+=m,4096<h){h=d;break e}if(h===4096||d===this.i.length-1){h=d+1;break e}}h=1e3}else h=1e3;h=Yu(this,T,h),d=Dt(this.I),me(d,"RID",a),me(d,"CVER",22),this.D&&me(d,"X-HTTP-Session-Id",this.D),vr(this,d),P&&(this.O?h="headers="+encodeURIComponent(String(qu(P)))+"&"+h:this.m&&Ba(d,this.m,P)),Ua(this.h,T),this.Ua&&me(d,"TYPE","init"),this.P?(me(d,"$req",h),me(d,"SID","null"),T.T=!0,La(T,d,null)):La(T,d,h),this.G=2}}else this.G==3&&(a?Ju(this,a):this.i.length==0||Cu(this.h)||Ju(this))};function Ju(a,h){var d;h?d=h.l:d=a.U++;const m=Dt(a.I);me(m,"SID",a.K),me(m,"RID",d),me(m,"AID",a.T),vr(a,m),a.m&&a.o&&Ba(m,a.m,a.o),d=new Wt(a,a.j,d,a.B+1),a.m===null&&(d.H=a.o),h&&(a.i=h.D.concat(a.i)),h=Yu(a,d,1e3),d.I=Math.round(.5*a.wa)+Math.round(.5*a.wa*Math.random()),Ua(a.h,d),La(d,m,h)}function vr(a,h){a.H&&M(a.H,function(d,m){me(h,m,d)}),a.l&&xu({},function(d,m){me(h,m,d)})}function Yu(a,h,d){d=Math.min(a.i.length,d);var m=a.l?y(a.l.Na,a.l,a):null;e:{var T=a.i;let P=-1;for(;;){const L=["count="+d];P==-1?0<d?(P=T[0].g,L.push("ofs="+P)):P=0:L.push("ofs="+P);let de=!0;for(let Me=0;Me<d;Me++){let ce=T[Me].g;const je=T[Me].map;if(ce-=P,0>ce)P=Math.max(0,T[Me].g-100),de=!1;else try{R_(je,L,"req"+ce+"_")}catch{m&&m(je)}}if(de){m=L.join("&");break e}}}return a=a.i.splice(0,d),h.D=a,m}function Xu(a){if(!a.g&&!a.u){a.Y=1;var h=a.Fa;sr||cu(),rr||(sr(),rr=!0),Ea.add(h,a),a.v=0}}function ja(a){return a.g||a.u||3<=a.v?!1:(a.Y++,a.u=lr(y(a.Fa,a),th(a,a.v)),a.v++,!0)}n.Fa=function(){if(this.u=null,Zu(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var a=2*this.R;this.j.info("BP detection timer enabled: "+a),this.A=lr(y(this.ab,this),a)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,Je(10),Ui(this),Zu(this))};function Ga(a){a.A!=null&&(c.clearTimeout(a.A),a.A=null)}function Zu(a){a.g=new Wt(a,a.j,"rpc",a.Y),a.m===null&&(a.g.H=a.o),a.g.O=0;var h=Dt(a.qa);me(h,"RID","rpc"),me(h,"SID",a.K),me(h,"AID",a.T),me(h,"CI",a.F?"0":"1"),!a.F&&a.ja&&me(h,"TO",a.ja),me(h,"TYPE","xmlhttp"),vr(a,h),a.m&&a.o&&Ba(h,a.m,a.o),a.L&&(a.g.I=a.L);var d=a.g;a=a.ia,d.L=1,d.v=Mi(Dt(h)),d.m=null,d.P=!0,Su(d,a)}n.Za=function(){this.C!=null&&(this.C=null,Ui(this),ja(this),Je(19))};function qi(a){a.C!=null&&(c.clearTimeout(a.C),a.C=null)}function eh(a,h){var d=null;if(a.g==h){qi(a),Ga(a),a.g=null;var m=2}else if(Fa(a.h,h))d=h.D,Vu(a.h,h),m=1;else return;if(a.G!=0){if(h.o)if(m==1){d=h.m?h.m.length:0,h=Date.now()-h.F;var T=a.B;m=Di(),Qe(m,new Eu(m,d)),Bi(a)}else Xu(a);else if(T=h.s,T==3||T==0&&0<h.X||!(m==1&&D_(a,h)||m==2&&ja(a)))switch(d&&0<d.length&&(h=a.h,h.i=h.i.concat(d)),T){case 1:Dn(a,5);break;case 4:Dn(a,10);break;case 3:Dn(a,6);break;default:Dn(a,2)}}}function th(a,h){let d=a.Ta+Math.floor(Math.random()*a.cb);return a.isActive()||(d*=2),d*h}function Dn(a,h){if(a.j.info("Error code "+h),h==2){var d=y(a.fb,a),m=a.Xa;const T=!m;m=new Cn(m||"//www.google.com/images/cleardot.gif"),c.location&&c.location.protocol=="http"||Oi(m,"https"),Mi(m),T?T_(m.toString(),d):A_(m.toString(),d)}else Je(2);a.G=0,a.l&&a.l.sa(h),nh(a),Qu(a)}n.fb=function(a){a?(this.j.info("Successfully pinged google.com"),Je(2)):(this.j.info("Failed to ping google.com"),Je(1))};function nh(a){if(a.G=0,a.ka=[],a.l){const h=Nu(a.h);(h.length!=0||a.i.length!=0)&&(R(a.ka,h),R(a.ka,a.i),a.h.i.length=0,V(a.i),a.i.length=0),a.l.ra()}}function sh(a,h,d){var m=d instanceof Cn?Dt(d):new Cn(d);if(m.g!="")h&&(m.g=h+"."+m.g),Li(m,m.s);else{var T=c.location;m=T.protocol,h=h?h+"."+T.hostname:T.hostname,T=+T.port;var P=new Cn(null);m&&Oi(P,m),h&&(P.g=h),T&&Li(P,T),d&&(P.l=d),m=P}return d=a.D,h=a.ya,d&&h&&me(m,d,h),me(m,"VER",a.la),vr(a,m),m}function rh(a,h,d){if(h&&!a.J)throw Error("Can't create secondary domain capable XhrIo object.");return h=a.Ca&&!a.pa?new Ie(new mr({eb:d})):new Ie(a.pa),h.Ha(a.J),h}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function ih(){}n=ih.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function ji(){}ji.prototype.g=function(a,h){return new ot(a,h)};function ot(a,h){qe.call(this),this.g=new Hu(h),this.l=a,this.h=h&&h.messageUrlParams||null,a=h&&h.messageHeaders||null,h&&h.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=h&&h.initMessageHeaders||null,h&&h.messageContentType&&(a?a["X-WebChannel-Content-Type"]=h.messageContentType:a={"X-WebChannel-Content-Type":h.messageContentType}),h&&h.va&&(a?a["X-WebChannel-Client-Profile"]=h.va:a={"X-WebChannel-Client-Profile":h.va}),this.g.S=a,(a=h&&h.Sb)&&!z(a)&&(this.g.m=a),this.v=h&&h.supportsCrossDomainXhr||!1,this.u=h&&h.sendRawJson||!1,(h=h&&h.httpSessionIdParam)&&!z(h)&&(this.g.D=h,a=this.h,a!==null&&h in a&&(a=this.h,h in a&&delete a[h])),this.j=new ls(this)}k(ot,qe),ot.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},ot.prototype.close=function(){qa(this.g)},ot.prototype.o=function(a){var h=this.g;if(typeof a=="string"){var d={};d.__data__=a,a=d}else this.u&&(d={},d.__data__=Ca(a),a=d);h.i.push(new p_(h.Ya++,a)),h.G==3&&Bi(h)},ot.prototype.N=function(){this.g.l=null,delete this.j,qa(this.g),delete this.g,ot.aa.N.call(this)};function oh(a){Va.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var h=a.__sm__;if(h){e:{for(const d in h){a=d;break e}a=void 0}(this.i=a)&&(a=this.i,h=h!==null&&a in h?h[a]:void 0),this.data=h}else this.data=a}k(oh,Va);function ah(){Na.call(this),this.status=1}k(ah,Na);function ls(a){this.g=a}k(ls,ih),ls.prototype.ua=function(){Qe(this.g,"a")},ls.prototype.ta=function(a){Qe(this.g,new oh(a))},ls.prototype.sa=function(a){Qe(this.g,new ah)},ls.prototype.ra=function(){Qe(this.g,"b")},ji.prototype.createWebChannel=ji.prototype.g,ot.prototype.send=ot.prototype.o,ot.prototype.open=ot.prototype.m,ot.prototype.close=ot.prototype.close,fp=function(){return new ji},dp=function(){return Di()},hp=Pn,yc={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Vi.NO_ERROR=0,Vi.TIMEOUT=8,Vi.HTTP_ERROR=6,ro=Vi,bu.COMPLETE="complete",up=bu,yu.EventType=ar,ar.OPEN="a",ar.CLOSE="b",ar.ERROR="c",ar.MESSAGE="d",qe.prototype.listen=qe.prototype.K,kr=yu,lp=mr,Ie.prototype.listenOnce=Ie.prototype.L,Ie.prototype.getLastError=Ie.prototype.Ka,Ie.prototype.getLastErrorCode=Ie.prototype.Ba,Ie.prototype.getStatus=Ie.prototype.Z,Ie.prototype.getResponseJson=Ie.prototype.Oa,Ie.prototype.getResponseText=Ie.prototype.oa,Ie.prototype.send=Ie.prototype.ea,Ie.prototype.setWithCredentials=Ie.prototype.Ha,cp=Ie}).apply(typeof Ki<"u"?Ki:typeof self<"u"?self:typeof window<"u"?window:{});const Fh="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ke{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Ke.UNAUTHENTICATED=new Ke(null),Ke.GOOGLE_CREDENTIALS=new Ke("google-credentials-uid"),Ke.FIRST_PARTY=new Ke("first-party-uid"),Ke.MOCK_USER=new Ke("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ys="10.12.1";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qn=new Yc("@firebase/firestore");function gs(){return Qn.logLevel}function D(n,...e){if(Qn.logLevel<=ne.DEBUG){const t=e.map(ll);Qn.debug(`Firestore (${Ys}): ${n}`,...t)}}function Te(n,...e){if(Qn.logLevel<=ne.ERROR){const t=e.map(ll);Qn.error(`Firestore (${Ys}): ${n}`,...t)}}function Hr(n,...e){if(Qn.logLevel<=ne.WARN){const t=e.map(ll);Qn.warn(`Firestore (${Ys}): ${n}`,...t)}}function ll(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function q(n="Unexpected state"){const e=`FIRESTORE (${Ys}) INTERNAL ASSERTION FAILED: `+n;throw Te(e),new Error(e)}function W(n,e){n||q()}function G(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const C={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class F extends jt{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hn{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bw{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Tw{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(Ke.UNAUTHENTICATED))}shutdown(){}}class Aw{constructor(e){this.t=e,this.currentUser=Ke.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let s=this.i;const r=l=>this.i!==s?(s=this.i,t(l)):Promise.resolve();let i=new hn;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new hn,e.enqueueRetryable(()=>r(this.currentUser))};const o=()=>{const l=i;e.enqueueRetryable(async()=>{await l.promise,await r(this.currentUser)})},c=l=>{D("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),o()};this.t.onInit(l=>c(l)),setTimeout(()=>{if(!this.auth){const l=this.t.getImmediate({optional:!0});l?c(l):(D("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new hn)}},0),o()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(s=>this.i!==e?(D("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(W(typeof s.accessToken=="string"),new bw(s.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const e=this.auth&&this.auth.getUid();return W(e===null||typeof e=="string"),new Ke(e)}}class Sw{constructor(e,t,s){this.l=e,this.h=t,this.P=s,this.type="FirstParty",this.user=Ke.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class Rw{constructor(e,t,s){this.l=e,this.h=t,this.P=s}getToken(){return Promise.resolve(new Sw(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(Ke.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Pw{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class kw{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,t){const s=i=>{i.error!=null&&D("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.R;return this.R=i.token,D("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(i.token):Promise.resolve()};this.o=i=>{e.enqueueRetryable(()=>s(i))};const r=i=>{D("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.appCheck.addTokenListener(this.o)};this.A.onInit(i=>r(i)),setTimeout(()=>{if(!this.appCheck){const i=this.A.getImmediate({optional:!0});i?r(i):D("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(W(typeof t.token=="string"),this.R=t.token,new Pw(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cw(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<n;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pp{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length;let s="";for(;s.length<20;){const r=Cw(40);for(let i=0;i<r.length;++i)s.length<20&&r[i]<t&&(s+=e.charAt(r[i]%e.length))}return s}}function X(n,e){return n<e?-1:n>e?1:0}function Ds(n,e,t){return n.length===e.length&&n.every((s,r)=>t(s,e[r]))}function mp(n){return n+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ve{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new F(C.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new F(C.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800)throw new F(C.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new F(C.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return ve.fromMillis(Date.now())}static fromDate(e){return ve.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor(1e6*(e-1e3*t));return new ve(t,s)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?X(this.nanoseconds,e.nanoseconds):X(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class H{constructor(e){this.timestamp=e}static fromTimestamp(e){return new H(e)}static min(){return new H(new ve(0,0))}static max(){return new H(new ve(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qr{constructor(e,t,s){t===void 0?t=0:t>e.length&&q(),s===void 0?s=e.length-t:s>e.length-t&&q(),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return Qr.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Qr?e.forEach(s=>{t.push(s)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let r=0;r<s;r++){const i=e.get(r),o=t.get(r);if(i<o)return-1;if(i>o)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class le extends Qr{construct(e,t,s){return new le(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new F(C.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter(r=>r.length>0))}return new le(t)}static emptyPath(){return new le([])}}const Dw=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class ye extends Qr{construct(e,t,s){return new ye(e,t,s)}static isValidIdentifier(e){return Dw.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),ye.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new ye(["__name__"])}static fromServerFormat(e){const t=[];let s="",r=0;const i=()=>{if(s.length===0)throw new F(C.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let o=!1;for(;r<e.length;){const c=e[r];if(c==="\\"){if(r+1===e.length)throw new F(C.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const l=e[r+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new F(C.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=l,r+=2}else c==="`"?(o=!o,r++):c!=="."||o?(s+=c,r++):(i(),r++)}if(i(),o)throw new F(C.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new ye(t)}static emptyPath(){return new ye([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ${constructor(e){this.path=e}static fromPath(e){return new $(le.fromString(e))}static fromName(e){return new $(le.fromString(e).popFirst(5))}static empty(){return new $(le.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&le.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return le.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new $(new le(e.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class To{constructor(e,t,s,r){this.indexId=e,this.collectionGroup=t,this.fields=s,this.indexState=r}}function vc(n){return n.fields.find(e=>e.kind===2)}function xn(n){return n.fields.filter(e=>e.kind!==2)}To.UNKNOWN_ID=-1;class io{constructor(e,t){this.fieldPath=e,this.kind=t}}class Jr{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new Jr(0,ht.min())}}function gp(n,e){const t=n.toTimestamp().seconds,s=n.toTimestamp().nanoseconds+1,r=H.fromTimestamp(s===1e9?new ve(t+1,0):new ve(t,s));return new ht(r,$.empty(),e)}function _p(n){return new ht(n.readTime,n.key,-1)}class ht{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new ht(H.min(),$.empty(),-1)}static max(){return new ht(H.max(),$.empty(),-1)}}function ul(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=$.comparator(n.documentKey,e.documentKey),t!==0?t:X(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yp="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class vp{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Tn(n){if(n.code!==C.FAILED_PRECONDITION||n.message!==yp)throw n;D("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&q(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new A((s,r)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(s,r)},this.catchCallback=i=>{this.wrapFailure(t,i).next(s,r)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof A?t:A.resolve(t)}catch(t){return A.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):A.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):A.reject(t)}static resolve(e){return new A((t,s)=>{t(e)})}static reject(e){return new A((t,s)=>{s(e)})}static waitFor(e){return new A((t,s)=>{let r=0,i=0,o=!1;e.forEach(c=>{++r,c.next(()=>{++i,o&&i===r&&t()},l=>s(l))}),o=!0,i===r&&t()})}static or(e){let t=A.resolve(!1);for(const s of e)t=t.next(r=>r?A.resolve(r):s());return t}static forEach(e,t){const s=[];return e.forEach((r,i)=>{s.push(t.call(this,r,i))}),this.waitFor(s)}static mapArray(e,t){return new A((s,r)=>{const i=e.length,o=new Array(i);let c=0;for(let l=0;l<i;l++){const u=l;t(e[u]).next(f=>{o[u]=f,++c,c===i&&s(o)},f=>r(f))}})}static doWhile(e,t){return new A((s,r)=>{const i=()=>{e()===!0?t().next(()=>{i()},r):s()};i()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yo{constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.V=new hn,this.transaction.oncomplete=()=>{this.V.resolve()},this.transaction.onabort=()=>{t.error?this.V.reject(new Or(e,t.error)):this.V.resolve()},this.transaction.onerror=s=>{const r=hl(s.target.error);this.V.reject(new Or(e,r))}}static open(e,t,s,r){try{return new Yo(t,e.transaction(r,s))}catch(i){throw new Or(t,i)}}get m(){return this.V.promise}abort(e){e&&this.V.reject(e),this.aborted||(D("SimpleDb","Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}g(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new Nw(t)}}class dn{constructor(e,t,s){this.name=e,this.version=t,this.p=s,dn.S(Ce())===12.2&&Te("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(e){return D("SimpleDb","Removing database:",e),On(window.indexedDB.deleteDatabase(e)).toPromise()}static D(){if(!bf())return!1;if(dn.C())return!0;const e=Ce(),t=dn.S(e),s=0<t&&t<10,r=Ip(e),i=0<r&&r<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||s||i)}static C(){var e;return typeof process<"u"&&((e=process.__PRIVATE_env)===null||e===void 0?void 0:e.v)==="YES"}static F(e,t){return e.store(t)}static S(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),s=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(s)}async M(e){return this.db||(D("SimpleDb","Opening database:",this.name),this.db=await new Promise((t,s)=>{const r=indexedDB.open(this.name,this.version);r.onsuccess=i=>{const o=i.target.result;t(o)},r.onblocked=()=>{s(new Or(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},r.onerror=i=>{const o=i.target.error;o.name==="VersionError"?s(new F(C.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):o.name==="InvalidStateError"?s(new F(C.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+o)):s(new Or(e,o))},r.onupgradeneeded=i=>{D("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',i.oldVersion);const o=i.target.result;this.p.O(o,r.transaction,i.oldVersion,this.version).next(()=>{D("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.N&&(this.db.onversionchange=t=>this.N(t)),this.db}L(e){this.N=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,s,r){const i=t==="readonly";let o=0;for(;;){++o;try{this.db=await this.M(e);const c=Yo.open(this.db,e,i?"readonly":"readwrite",s),l=r(c).next(u=>(c.g(),u)).catch(u=>(c.abort(u),A.reject(u))).toPromise();return l.catch(()=>{}),await c.m,l}catch(c){const l=c,u=l.name!=="FirebaseError"&&o<3;if(D("SimpleDb","Transaction failed with error:",l.message,"Retrying:",u),this.close(),!u)return Promise.reject(l)}}}close(){this.db&&this.db.close(),this.db=void 0}}function Ip(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class Vw{constructor(e){this.B=e,this.k=!1,this.q=null}get isDone(){return this.k}get K(){return this.q}set cursor(e){this.B=e}done(){this.k=!0}$(e){this.q=e}delete(){return On(this.B.delete())}}class Or extends F{constructor(e,t){super(C.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function An(n){return n.name==="IndexedDbTransactionError"}class Nw{constructor(e){this.store=e}put(e,t){let s;return t!==void 0?(D("SimpleDb","PUT",this.store.name,e,t),s=this.store.put(t,e)):(D("SimpleDb","PUT",this.store.name,"<auto-key>",e),s=this.store.put(e)),On(s)}add(e){return D("SimpleDb","ADD",this.store.name,e,e),On(this.store.add(e))}get(e){return On(this.store.get(e)).next(t=>(t===void 0&&(t=null),D("SimpleDb","GET",this.store.name,e,t),t))}delete(e){return D("SimpleDb","DELETE",this.store.name,e),On(this.store.delete(e))}count(){return D("SimpleDb","COUNT",this.store.name),On(this.store.count())}U(e,t){const s=this.options(e,t),r=s.index?this.store.index(s.index):this.store;if(typeof r.getAll=="function"){const i=r.getAll(s.range);return new A((o,c)=>{i.onerror=l=>{c(l.target.error)},i.onsuccess=l=>{o(l.target.result)}})}{const i=this.cursor(s),o=[];return this.W(i,(c,l)=>{o.push(l)}).next(()=>o)}}G(e,t){const s=this.store.getAll(e,t===null?void 0:t);return new A((r,i)=>{s.onerror=o=>{i(o.target.error)},s.onsuccess=o=>{r(o.target.result)}})}j(e,t){D("SimpleDb","DELETE ALL",this.store.name);const s=this.options(e,t);s.H=!1;const r=this.cursor(s);return this.W(r,(i,o,c)=>c.delete())}J(e,t){let s;t?s=e:(s={},t=e);const r=this.cursor(s);return this.W(r,t)}Y(e){const t=this.cursor({});return new A((s,r)=>{t.onerror=i=>{const o=hl(i.target.error);r(o)},t.onsuccess=i=>{const o=i.target.result;o?e(o.primaryKey,o.value).next(c=>{c?o.continue():s()}):s()}})}W(e,t){const s=[];return new A((r,i)=>{e.onerror=o=>{i(o.target.error)},e.onsuccess=o=>{const c=o.target.result;if(!c)return void r();const l=new Vw(c),u=t(c.primaryKey,c.value,l);if(u instanceof A){const f=u.catch(p=>(l.done(),A.reject(p)));s.push(f)}l.isDone?r():l.K===null?c.continue():c.continue(l.K)}}).next(()=>A.waitFor(s))}options(e,t){let s;return e!==void 0&&(typeof e=="string"?s=e:t=e),{index:s,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const s=this.store.index(e.index);return e.H?s.openKeyCursor(e.range,t):s.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function On(n){return new A((e,t)=>{n.onsuccess=s=>{const r=s.target.result;e(r)},n.onerror=s=>{const r=hl(s.target.error);t(r)}})}let Uh=!1;function hl(n){const e=dn.S(Ce());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(n.message.indexOf(t)>=0){const s=new F("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Uh||(Uh=!0,setTimeout(()=>{throw s},0)),s}}return n}class xw{constructor(e,t){this.asyncQueue=e,this.Z=t,this.task=null}start(){this.X(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}X(e){D("IndexBackfiller",`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,async()=>{this.task=null;try{D("IndexBackfiller",`Documents written: ${await this.Z.ee()}`)}catch(t){An(t)?D("IndexBackfiller","Ignoring IndexedDB error during index backfill: ",t):await Tn(t)}await this.X(6e4)})}}class Ow{constructor(e,t){this.localStore=e,this.persistence=t}async ee(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",t=>this.te(t,e))}te(e,t){const s=new Set;let r=t,i=!0;return A.doWhile(()=>i===!0&&r>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next(o=>{if(o!==null&&!s.has(o))return D("IndexBackfiller",`Processing collection: ${o}`),this.ne(e,o,r).next(c=>{r-=c,s.add(o)});i=!1})).next(()=>t-r)}ne(e,t,s){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next(r=>this.localStore.localDocuments.getNextDocuments(e,t,r,s).next(i=>{const o=i.changes;return this.localStore.indexManager.updateIndexEntries(e,o).next(()=>this.re(r,i)).next(c=>(D("IndexBackfiller",`Updating offset: ${c}`),this.localStore.indexManager.updateCollectionGroup(e,t,c))).next(()=>o.size)}))}re(e,t){let s=e;return t.changes.forEach((r,i)=>{const o=_p(i);ul(o,s)>0&&(s=o)}),new ht(s.readTime,s.documentKey,Math.max(t.batchId,e.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class st{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.ie(s),this.se=s=>t.writeSequenceNumber(s))}ie(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.se&&this.se(e),e}}st.oe=-1;function Xo(n){return n==null}function Yr(n){return n===0&&1/n==-1/0}function wp(n){return typeof n=="number"&&Number.isInteger(n)&&!Yr(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xe(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=Bh(e)),e=Lw(n.get(t),e);return Bh(e)}function Lw(n,e){let t=e;const s=n.length;for(let r=0;r<s;r++){const i=n.charAt(r);switch(i){case"\0":t+="";break;case"":t+="";break;default:t+=i}}return t}function Bh(n){return n+""}function Tt(n){const e=n.length;if(W(e>=2),e===2)return W(n.charAt(0)===""&&n.charAt(1)===""),le.emptyPath();const t=e-2,s=[];let r="";for(let i=0;i<e;){const o=n.indexOf("",i);switch((o<0||o>t)&&q(),n.charAt(o+1)){case"":const c=n.substring(i,o);let l;r.length===0?l=c:(r+=c,l=r,r=""),s.push(l);break;case"":r+=n.substring(i,o),r+="\0";break;case"":r+=n.substring(i,o+1);break;default:q()}i=o+2}return new le(s)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qh=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oo(n,e){return[n,Xe(e)]}function Ep(n,e,t){return[n,Xe(e),t]}const Mw={},$w=["prefixPath","collectionGroup","readTime","documentId"],Fw=["prefixPath","collectionGroup","documentId"],Uw=["collectionGroup","readTime","prefixPath","documentId"],Bw=["canonicalId","targetId"],qw=["targetId","path"],jw=["path","targetId"],Gw=["collectionId","parent"],zw=["indexId","uid"],Kw=["uid","sequenceNumber"],Ww=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],Hw=["indexId","uid","orderedDocumentKey"],Qw=["userId","collectionPath","documentId"],Jw=["userId","collectionPath","largestBatchId"],Yw=["userId","collectionGroup","largestBatchId"],bp=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],Xw=[...bp,"documentOverlays"],Tp=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],Ap=Tp,Sp=[...Ap,"indexConfiguration","indexState","indexEntries"],Zw=Sp;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ic extends vp{constructor(e,t){super(),this._e=e,this.currentSequenceNumber=t}}function Le(n,e){const t=G(n);return dn.F(t._e,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jh(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function rs(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function Rp(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pe{constructor(e,t){this.comparator=e,this.root=t||$e.EMPTY}insert(e,t){return new pe(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,$e.BLACK,null,null))}remove(e){return new pe(this.comparator,this.root.remove(e,this.comparator).copy(null,null,$e.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const r=this.comparator(e,s.key);if(r===0)return t+s.left.size;r<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,s)=>(e(t,s),!1))}toString(){const e=[];return this.inorderTraversal((t,s)=>(e.push(`${t}:${s}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Wi(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Wi(this.root,e,this.comparator,!1)}getReverseIterator(){return new Wi(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Wi(this.root,e,this.comparator,!0)}}class Wi{constructor(e,t,s,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?s(e.key,t):1,t&&r&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class $e{constructor(e,t,s,r,i){this.key=e,this.value=t,this.color=s??$e.RED,this.left=r??$e.EMPTY,this.right=i??$e.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,r,i){return new $e(e??this.key,t??this.value,s??this.color,r??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let r=this;const i=s(e,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(e,t,s),null):i===0?r.copy(null,t,null,null,null):r.copy(null,null,null,null,r.right.insert(e,t,s)),r.fixUp()}removeMin(){if(this.left.isEmpty())return $e.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,r=this;if(t(e,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(e,t),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),t(e,r.key)===0){if(r.right.isEmpty())return $e.EMPTY;s=r.right.min(),r=r.copy(s.key,s.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(e,t))}return r.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,$e.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,$e.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw q();const e=this.left.check();if(e!==this.right.check())throw q();return e+(this.isRed()?0:1)}}$e.EMPTY=null,$e.RED=!0,$e.BLACK=!1;$e.EMPTY=new class{constructor(){this.size=0}get key(){throw q()}get value(){throw q()}get color(){throw q()}get left(){throw q()}get right(){throw q()}copy(e,t,s,r,i){return this}insert(e,t,s){return new $e(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class he{constructor(e){this.comparator=e,this.data=new pe(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,s)=>(e(t),!1))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const r=s.getNext();if(this.comparator(r.key,e[1])>=0)return;t(r.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Gh(this.data.getIterator())}getIteratorFrom(e){return new Gh(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(s=>{t=t.add(s)}),t}isEqual(e){if(!(e instanceof he)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=s.getNext().key;if(this.comparator(r,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new he(this.comparator);return t.data=e,t}}class Gh{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function hs(n){return n.hasNext()?n.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rt{constructor(e){this.fields=e,e.sort(ye.comparator)}static empty(){return new rt([])}unionWith(e){let t=new he(ye.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new rt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return Ds(this.fields,e.fields,(t,s)=>t.isEqual(s))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pp extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oe{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(r){try{return atob(r)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new Pp("Invalid base64 string: "+i):i}}(e);return new Oe(t)}static fromUint8Array(e){const t=function(r){let i="";for(let o=0;o<r.length;++o)i+=String.fromCharCode(r[o]);return i}(e);return new Oe(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const s=new Uint8Array(t.length);for(let r=0;r<t.length;r++)s[r]=t.charCodeAt(r);return s}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return X(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}Oe.EMPTY_BYTE_STRING=new Oe("");const eE=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function qt(n){if(W(!!n),typeof n=="string"){let e=0;const t=eE.exec(n);if(W(!!t),t[1]){let r=t[1];r=(r+"000000000").substr(0,9),e=Number(r)}const s=new Date(n);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:Ee(n.seconds),nanos:Ee(n.nanos)}}function Ee(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function _n(n){return typeof n=="string"?Oe.fromBase64String(n):Oe.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dl(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{}).__type__)===null||t===void 0?void 0:t.stringValue)==="server_timestamp"}function fl(n){const e=n.mapValue.fields.__previous_value__;return dl(e)?fl(e):e}function Xr(n){const e=qt(n.mapValue.fields.__local_write_time__.timestampValue);return new ve(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tE{constructor(e,t,s,r,i,o,c,l,u){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=r,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=c,this.longPollingOptions=l,this.useFetchStreams=u}}class Jn{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new Jn("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof Jn&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const on={mapValue:{fields:{__type__:{stringValue:"__max__"}}}},ao={nullValue:"NULL_VALUE"};function Yn(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?dl(n)?4:kp(n)?9007199254740991:10:q()}function kt(n,e){if(n===e)return!0;const t=Yn(n);if(t!==Yn(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return Xr(n).isEqual(Xr(e));case 3:return function(r,i){if(typeof r.timestampValue=="string"&&typeof i.timestampValue=="string"&&r.timestampValue.length===i.timestampValue.length)return r.timestampValue===i.timestampValue;const o=qt(r.timestampValue),c=qt(i.timestampValue);return o.seconds===c.seconds&&o.nanos===c.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(r,i){return _n(r.bytesValue).isEqual(_n(i.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(r,i){return Ee(r.geoPointValue.latitude)===Ee(i.geoPointValue.latitude)&&Ee(r.geoPointValue.longitude)===Ee(i.geoPointValue.longitude)}(n,e);case 2:return function(r,i){if("integerValue"in r&&"integerValue"in i)return Ee(r.integerValue)===Ee(i.integerValue);if("doubleValue"in r&&"doubleValue"in i){const o=Ee(r.doubleValue),c=Ee(i.doubleValue);return o===c?Yr(o)===Yr(c):isNaN(o)&&isNaN(c)}return!1}(n,e);case 9:return Ds(n.arrayValue.values||[],e.arrayValue.values||[],kt);case 10:return function(r,i){const o=r.mapValue.fields||{},c=i.mapValue.fields||{};if(jh(o)!==jh(c))return!1;for(const l in o)if(o.hasOwnProperty(l)&&(c[l]===void 0||!kt(o[l],c[l])))return!1;return!0}(n,e);default:return q()}}function Zr(n,e){return(n.values||[]).find(t=>kt(t,e))!==void 0}function yn(n,e){if(n===e)return 0;const t=Yn(n),s=Yn(e);if(t!==s)return X(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return X(n.booleanValue,e.booleanValue);case 2:return function(i,o){const c=Ee(i.integerValue||i.doubleValue),l=Ee(o.integerValue||o.doubleValue);return c<l?-1:c>l?1:c===l?0:isNaN(c)?isNaN(l)?0:-1:1}(n,e);case 3:return zh(n.timestampValue,e.timestampValue);case 4:return zh(Xr(n),Xr(e));case 5:return X(n.stringValue,e.stringValue);case 6:return function(i,o){const c=_n(i),l=_n(o);return c.compareTo(l)}(n.bytesValue,e.bytesValue);case 7:return function(i,o){const c=i.split("/"),l=o.split("/");for(let u=0;u<c.length&&u<l.length;u++){const f=X(c[u],l[u]);if(f!==0)return f}return X(c.length,l.length)}(n.referenceValue,e.referenceValue);case 8:return function(i,o){const c=X(Ee(i.latitude),Ee(o.latitude));return c!==0?c:X(Ee(i.longitude),Ee(o.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return function(i,o){const c=i.values||[],l=o.values||[];for(let u=0;u<c.length&&u<l.length;++u){const f=yn(c[u],l[u]);if(f)return f}return X(c.length,l.length)}(n.arrayValue,e.arrayValue);case 10:return function(i,o){if(i===on.mapValue&&o===on.mapValue)return 0;if(i===on.mapValue)return 1;if(o===on.mapValue)return-1;const c=i.fields||{},l=Object.keys(c),u=o.fields||{},f=Object.keys(u);l.sort(),f.sort();for(let p=0;p<l.length&&p<f.length;++p){const y=X(l[p],f[p]);if(y!==0)return y;const S=yn(c[l[p]],u[f[p]]);if(S!==0)return S}return X(l.length,f.length)}(n.mapValue,e.mapValue);default:throw q()}}function zh(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return X(n,e);const t=qt(n),s=qt(e),r=X(t.seconds,s.seconds);return r!==0?r:X(t.nanos,s.nanos)}function Vs(n){return wc(n)}function wc(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const s=qt(t);return`time(${s.seconds},${s.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return _n(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return $.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let s="[",r=!0;for(const i of t.values||[])r?r=!1:s+=",",s+=wc(i);return s+"]"}(n.arrayValue):"mapValue"in n?function(t){const s=Object.keys(t.fields||{}).sort();let r="{",i=!0;for(const o of s)i?i=!1:r+=",",r+=`${o}:${wc(t.fields[o])}`;return r+"}"}(n.mapValue):q()}function pl(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function Ec(n){return!!n&&"integerValue"in n}function ei(n){return!!n&&"arrayValue"in n}function Kh(n){return!!n&&"nullValue"in n}function Wh(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function co(n){return!!n&&"mapValue"in n}function Lr(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const e={mapValue:{fields:{}}};return rs(n.mapValue.fields,(t,s)=>e.mapValue.fields[t]=Lr(s)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=Lr(n.arrayValue.values[t]);return e}return Object.assign({},n)}function kp(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}function nE(n){return"nullValue"in n?ao:"booleanValue"in n?{booleanValue:!1}:"integerValue"in n||"doubleValue"in n?{doubleValue:NaN}:"timestampValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in n?{stringValue:""}:"bytesValue"in n?{bytesValue:""}:"referenceValue"in n?pl(Jn.empty(),$.empty()):"geoPointValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in n?{arrayValue:{}}:"mapValue"in n?{mapValue:{}}:q()}function sE(n){return"nullValue"in n?{booleanValue:!1}:"booleanValue"in n?{doubleValue:NaN}:"integerValue"in n||"doubleValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in n?{stringValue:""}:"stringValue"in n?{bytesValue:""}:"bytesValue"in n?pl(Jn.empty(),$.empty()):"referenceValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in n?{arrayValue:{}}:"arrayValue"in n?{mapValue:{}}:"mapValue"in n?on:q()}function Hh(n,e){const t=yn(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?-1:!n.inclusive&&e.inclusive?1:0}function Qh(n,e){const t=yn(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?1:!n.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class We{constructor(e){this.value=e}static empty(){return new We({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!co(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Lr(t)}setAll(e){let t=ye.emptyPath(),s={},r=[];e.forEach((o,c)=>{if(!t.isImmediateParentOf(c)){const l=this.getFieldsMap(t);this.applyChanges(l,s,r),s={},r=[],t=c.popLast()}o?s[c.lastSegment()]=Lr(o):r.push(c.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,s,r)}delete(e){const t=this.field(e.popLast());co(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return kt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let r=t.mapValue.fields[e.get(s)];co(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=r),t=r}return t.mapValue.fields}applyChanges(e,t,s){rs(t,(r,i)=>e[r]=i);for(const r of s)delete e[r]}clone(){return new We(Lr(this.value))}}function Cp(n){const e=[];return rs(n.fields,(t,s)=>{const r=new ye([t]);if(co(s)){const i=Cp(s.mapValue).fields;if(i.length===0)e.push(r);else for(const o of i)e.push(r.child(o))}else e.push(r)}),new rt(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class be{constructor(e,t,s,r,i,o,c){this.key=e,this.documentType=t,this.version=s,this.readTime=r,this.createTime=i,this.data=o,this.documentState=c}static newInvalidDocument(e){return new be(e,0,H.min(),H.min(),H.min(),We.empty(),0)}static newFoundDocument(e,t,s,r){return new be(e,1,t,H.min(),s,r,0)}static newNoDocument(e,t){return new be(e,2,t,H.min(),H.min(),We.empty(),0)}static newUnknownDocument(e,t){return new be(e,3,t,H.min(),H.min(),We.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(H.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=We.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=We.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=H.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof be&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new be(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ns{constructor(e,t){this.position=e,this.inclusive=t}}function Jh(n,e,t){let s=0;for(let r=0;r<n.position.length;r++){const i=e[r],o=n.position[r];if(i.field.isKeyField()?s=$.comparator($.fromName(o.referenceValue),t.key):s=yn(o,t.data.field(i.field)),i.dir==="desc"&&(s*=-1),s!==0)break}return s}function Yh(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!kt(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ao{constructor(e,t="asc"){this.field=e,this.dir=t}}function rE(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dp{}class re extends Dp{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new iE(e,t,s):t==="array-contains"?new cE(e,s):t==="in"?new Mp(e,s):t==="not-in"?new lE(e,s):t==="array-contains-any"?new uE(e,s):new re(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new oE(e,s):new aE(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&this.matchesComparison(yn(t,this.value)):t!==null&&Yn(this.value)===Yn(t)&&this.matchesComparison(yn(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return q()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class ue extends Dp{constructor(e,t){super(),this.filters=e,this.op=t,this.ae=null}static create(e,t){return new ue(e,t)}matches(e){return xs(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.ae!==null||(this.ae=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ae}getFilters(){return Object.assign([],this.filters)}}function xs(n){return n.op==="and"}function bc(n){return n.op==="or"}function ml(n){return Vp(n)&&xs(n)}function Vp(n){for(const e of n.filters)if(e instanceof ue)return!1;return!0}function Tc(n){if(n instanceof re)return n.field.canonicalString()+n.op.toString()+Vs(n.value);if(ml(n))return n.filters.map(e=>Tc(e)).join(",");{const e=n.filters.map(t=>Tc(t)).join(",");return`${n.op}(${e})`}}function Np(n,e){return n instanceof re?function(s,r){return r instanceof re&&s.op===r.op&&s.field.isEqual(r.field)&&kt(s.value,r.value)}(n,e):n instanceof ue?function(s,r){return r instanceof ue&&s.op===r.op&&s.filters.length===r.filters.length?s.filters.reduce((i,o,c)=>i&&Np(o,r.filters[c]),!0):!1}(n,e):void q()}function xp(n,e){const t=n.filters.concat(e);return ue.create(t,n.op)}function Op(n){return n instanceof re?function(t){return`${t.field.canonicalString()} ${t.op} ${Vs(t.value)}`}(n):n instanceof ue?function(t){return t.op.toString()+" {"+t.getFilters().map(Op).join(" ,")+"}"}(n):"Filter"}class iE extends re{constructor(e,t,s){super(e,t,s),this.key=$.fromName(s.referenceValue)}matches(e){const t=$.comparator(e.key,this.key);return this.matchesComparison(t)}}class oE extends re{constructor(e,t){super(e,"in",t),this.keys=Lp("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class aE extends re{constructor(e,t){super(e,"not-in",t),this.keys=Lp("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function Lp(n,e){var t;return(((t=e.arrayValue)===null||t===void 0?void 0:t.values)||[]).map(s=>$.fromName(s.referenceValue))}class cE extends re{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return ei(t)&&Zr(t.arrayValue,this.value)}}class Mp extends re{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Zr(this.value.arrayValue,t)}}class lE extends re{constructor(e,t){super(e,"not-in",t)}matches(e){if(Zr(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&!Zr(this.value.arrayValue,t)}}class uE extends re{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!ei(t)||!t.arrayValue.values)&&t.arrayValue.values.some(s=>Zr(this.value.arrayValue,s))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hE{constructor(e,t=null,s=[],r=[],i=null,o=null,c=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=r,this.limit=i,this.startAt=o,this.endAt=c,this.ue=null}}function Ac(n,e=null,t=[],s=[],r=null,i=null,o=null){return new hE(n,e,t,s,r,i,o)}function Xn(n){const e=G(n);if(e.ue===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(s=>Tc(s)).join(","),t+="|ob:",t+=e.orderBy.map(s=>function(i){return i.field.canonicalString()+i.dir}(s)).join(","),Xo(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(s=>Vs(s)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(s=>Vs(s)).join(",")),e.ue=t}return e.ue}function gi(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!rE(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!Np(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Yh(n.startAt,e.startAt)&&Yh(n.endAt,e.endAt)}function So(n){return $.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function Ro(n,e){return n.filters.filter(t=>t instanceof re&&t.field.isEqual(e))}function Xh(n,e,t){let s=ao,r=!0;for(const i of Ro(n,e)){let o=ao,c=!0;switch(i.op){case"<":case"<=":o=nE(i.value);break;case"==":case"in":case">=":o=i.value;break;case">":o=i.value,c=!1;break;case"!=":case"not-in":o=ao}Hh({value:s,inclusive:r},{value:o,inclusive:c})<0&&(s=o,r=c)}if(t!==null){for(let i=0;i<n.orderBy.length;++i)if(n.orderBy[i].field.isEqual(e)){const o=t.position[i];Hh({value:s,inclusive:r},{value:o,inclusive:t.inclusive})<0&&(s=o,r=t.inclusive);break}}return{value:s,inclusive:r}}function Zh(n,e,t){let s=on,r=!0;for(const i of Ro(n,e)){let o=on,c=!0;switch(i.op){case">=":case">":o=sE(i.value),c=!1;break;case"==":case"in":case"<=":o=i.value;break;case"<":o=i.value,c=!1;break;case"!=":case"not-in":o=on}Qh({value:s,inclusive:r},{value:o,inclusive:c})>0&&(s=o,r=c)}if(t!==null){for(let i=0;i<n.orderBy.length;++i)if(n.orderBy[i].field.isEqual(e)){const o=t.position[i];Qh({value:s,inclusive:r},{value:o,inclusive:t.inclusive})>0&&(s=o,r=t.inclusive);break}}return{value:s,inclusive:r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zo{constructor(e,t=null,s=[],r=[],i=null,o="F",c=null,l=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=r,this.limit=i,this.limitType=o,this.startAt=c,this.endAt=l,this.ce=null,this.le=null,this.he=null,this.startAt,this.endAt}}function $p(n,e,t,s,r,i,o,c){return new Zo(n,e,t,s,r,i,o,c)}function ea(n){return new Zo(n)}function ed(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function dE(n){return n.collectionGroup!==null}function Mr(n){const e=G(n);if(e.ce===null){e.ce=[];const t=new Set;for(const i of e.explicitOrderBy)e.ce.push(i),t.add(i.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let c=new he(ye.comparator);return o.filters.forEach(l=>{l.getFlattenedFilters().forEach(u=>{u.isInequality()&&(c=c.add(u.field))})}),c})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.ce.push(new Ao(i,s))}),t.has(ye.keyField().canonicalString())||e.ce.push(new Ao(ye.keyField(),s))}return e.ce}function ct(n){const e=G(n);return e.le||(e.le=fE(e,Mr(n))),e.le}function fE(n,e){if(n.limitType==="F")return Ac(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(r=>{const i=r.dir==="desc"?"asc":"desc";return new Ao(r.field,i)});const t=n.endAt?new Ns(n.endAt.position,n.endAt.inclusive):null,s=n.startAt?new Ns(n.startAt.position,n.startAt.inclusive):null;return Ac(n.path,n.collectionGroup,e,n.filters,n.limit,t,s)}}function Sc(n,e,t){return new Zo(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function ta(n,e){return gi(ct(n),ct(e))&&n.limitType===e.limitType}function Fp(n){return`${Xn(ct(n))}|lt:${n.limitType}`}function _s(n){return`Query(target=${function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map(r=>Op(r)).join(", ")}]`),Xo(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map(r=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(r)).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map(r=>Vs(r)).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map(r=>Vs(r)).join(",")),`Target(${s})`}(ct(n))}; limitType=${n.limitType})`}function _i(n,e){return e.isFoundDocument()&&function(s,r){const i=r.key.path;return s.collectionGroup!==null?r.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(i):$.isDocumentKey(s.path)?s.path.isEqual(i):s.path.isImmediateParentOf(i)}(n,e)&&function(s,r){for(const i of Mr(s))if(!i.field.isKeyField()&&r.data.field(i.field)===null)return!1;return!0}(n,e)&&function(s,r){for(const i of s.filters)if(!i.matches(r))return!1;return!0}(n,e)&&function(s,r){return!(s.startAt&&!function(o,c,l){const u=Jh(o,c,l);return o.inclusive?u<=0:u<0}(s.startAt,Mr(s),r)||s.endAt&&!function(o,c,l){const u=Jh(o,c,l);return o.inclusive?u>=0:u>0}(s.endAt,Mr(s),r))}(n,e)}function Up(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Bp(n){return(e,t)=>{let s=!1;for(const r of Mr(n)){const i=pE(r,e,t);if(i!==0)return i;s=s||r.field.isKeyField()}return 0}}function pE(n,e,t){const s=n.field.isKeyField()?$.comparator(e.key,t.key):function(i,o,c){const l=o.data.field(i),u=c.data.field(i);return l!==null&&u!==null?yn(l,u):q()}(n.field,e,t);switch(n.dir){case"asc":return s;case"desc":return-1*s;default:return q()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sn{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[r,i]of s)if(this.equalsFn(r,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),r=this.inner[s];if(r===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return void(r[i]=[e,t]);r.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let r=0;r<s.length;r++)if(this.equalsFn(s[r][0],e))return s.length===1?delete this.inner[t]:s.splice(r,1),this.innerSize--,!0;return!1}forEach(e){rs(this.inner,(t,s)=>{for(const[r,i]of s)e(r,i)})}isEmpty(){return Rp(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mE=new pe($.comparator);function at(){return mE}const qp=new pe($.comparator);function Cr(...n){let e=qp;for(const t of n)e=e.insert(t.key,t);return e}function jp(n){let e=qp;return n.forEach((t,s)=>e=e.insert(t,s.overlayedDocument)),e}function At(){return $r()}function Gp(){return $r()}function $r(){return new Sn(n=>n.toString(),(n,e)=>n.isEqual(e))}const gE=new pe($.comparator),_E=new he($.comparator);function te(...n){let e=_E;for(const t of n)e=e.add(t);return e}const yE=new he(X);function gl(){return yE}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zp(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Yr(e)?"-0":e}}function Kp(n){return{integerValue:""+n}}function vE(n,e){return wp(e)?Kp(e):zp(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class na{constructor(){this._=void 0}}function IE(n,e,t){return n instanceof ti?function(r,i){const o={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:r.seconds,nanos:r.nanoseconds}}}};return i&&dl(i)&&(i=fl(i)),i&&(o.fields.__previous_value__=i),{mapValue:o}}(t,e):n instanceof Os?Hp(n,e):n instanceof Ls?Qp(n,e):function(r,i){const o=Wp(r,i),c=td(o)+td(r.Pe);return Ec(o)&&Ec(r.Pe)?Kp(c):zp(r.serializer,c)}(n,e)}function wE(n,e,t){return n instanceof Os?Hp(n,e):n instanceof Ls?Qp(n,e):t}function Wp(n,e){return n instanceof ni?function(s){return Ec(s)||function(i){return!!i&&"doubleValue"in i}(s)}(e)?e:{integerValue:0}:null}class ti extends na{}class Os extends na{constructor(e){super(),this.elements=e}}function Hp(n,e){const t=Jp(e);for(const s of n.elements)t.some(r=>kt(r,s))||t.push(s);return{arrayValue:{values:t}}}class Ls extends na{constructor(e){super(),this.elements=e}}function Qp(n,e){let t=Jp(e);for(const s of n.elements)t=t.filter(r=>!kt(r,s));return{arrayValue:{values:t}}}class ni extends na{constructor(e,t){super(),this.serializer=e,this.Pe=t}}function td(n){return Ee(n.integerValue||n.doubleValue)}function Jp(n){return ei(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class EE{constructor(e,t){this.field=e,this.transform=t}}function bE(n,e){return n.field.isEqual(e.field)&&function(s,r){return s instanceof Os&&r instanceof Os||s instanceof Ls&&r instanceof Ls?Ds(s.elements,r.elements,kt):s instanceof ni&&r instanceof ni?kt(s.Pe,r.Pe):s instanceof ti&&r instanceof ti}(n.transform,e.transform)}class TE{constructor(e,t){this.version=e,this.transformResults=t}}class Ye{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Ye}static exists(e){return new Ye(void 0,e)}static updateTime(e){return new Ye(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function lo(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class sa{}function Yp(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new ra(n.key,Ye.none()):new Xs(n.key,n.data,Ye.none());{const t=n.data,s=We.empty();let r=new he(ye.comparator);for(let i of e.fields)if(!r.has(i)){let o=t.field(i);o===null&&i.length>1&&(i=i.popLast(),o=t.field(i)),o===null?s.delete(i):s.set(i,o),r=r.add(i)}return new Gt(n.key,s,new rt(r.toArray()),Ye.none())}}function AE(n,e,t){n instanceof Xs?function(r,i,o){const c=r.value.clone(),l=sd(r.fieldTransforms,i,o.transformResults);c.setAll(l),i.convertToFoundDocument(o.version,c).setHasCommittedMutations()}(n,e,t):n instanceof Gt?function(r,i,o){if(!lo(r.precondition,i))return void i.convertToUnknownDocument(o.version);const c=sd(r.fieldTransforms,i,o.transformResults),l=i.data;l.setAll(Xp(r)),l.setAll(c),i.convertToFoundDocument(o.version,l).setHasCommittedMutations()}(n,e,t):function(r,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,t)}function Fr(n,e,t,s){return n instanceof Xs?function(i,o,c,l){if(!lo(i.precondition,o))return c;const u=i.value.clone(),f=rd(i.fieldTransforms,l,o);return u.setAll(f),o.convertToFoundDocument(o.version,u).setHasLocalMutations(),null}(n,e,t,s):n instanceof Gt?function(i,o,c,l){if(!lo(i.precondition,o))return c;const u=rd(i.fieldTransforms,l,o),f=o.data;return f.setAll(Xp(i)),f.setAll(u),o.convertToFoundDocument(o.version,f).setHasLocalMutations(),c===null?null:c.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(p=>p.field))}(n,e,t,s):function(i,o,c){return lo(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):c}(n,e,t)}function SE(n,e){let t=null;for(const s of n.fieldTransforms){const r=e.data.field(s.field),i=Wp(s.transform,r||null);i!=null&&(t===null&&(t=We.empty()),t.set(s.field,i))}return t||null}function nd(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(s,r){return s===void 0&&r===void 0||!(!s||!r)&&Ds(s,r,(i,o)=>bE(i,o))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Xs extends sa{constructor(e,t,s,r=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=r,this.type=0}getFieldMask(){return null}}class Gt extends sa{constructor(e,t,s,r,i=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=r,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function Xp(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const s=n.data.field(t);e.set(t,s)}}),e}function sd(n,e,t){const s=new Map;W(n.length===t.length);for(let r=0;r<t.length;r++){const i=n[r],o=i.transform,c=e.data.field(i.field);s.set(i.field,wE(o,c,t[r]))}return s}function rd(n,e,t){const s=new Map;for(const r of n){const i=r.transform,o=t.data.field(r.field);s.set(r.field,IE(i,o,e))}return s}class ra extends sa{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Zp extends sa{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _l{constructor(e,t,s,r){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=r}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let r=0;r<this.mutations.length;r++){const i=this.mutations[r];i.key.isEqual(e.key)&&AE(i,e,s[r])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=Fr(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=Fr(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=Gp();return this.mutations.forEach(r=>{const i=e.get(r.key),o=i.overlayedDocument;let c=this.applyToLocalView(o,i.mutatedFields);c=t.has(r.key)?null:c;const l=Yp(o,c);l!==null&&s.set(r.key,l),o.isValidDocument()||o.convertToNoDocument(H.min())}),s}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),te())}isEqual(e){return this.batchId===e.batchId&&Ds(this.mutations,e.mutations,(t,s)=>nd(t,s))&&Ds(this.baseMutations,e.baseMutations,(t,s)=>nd(t,s))}}class yl{constructor(e,t,s,r){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=r}static from(e,t,s){W(e.mutations.length===s.length);let r=function(){return gE}();const i=e.mutations;for(let o=0;o<i.length;o++)r=r.insert(i[o].key,s[o].version);return new yl(e,t,s,r)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vl{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RE{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Se,ie;function PE(n){switch(n){default:return q();case C.CANCELLED:case C.UNKNOWN:case C.DEADLINE_EXCEEDED:case C.RESOURCE_EXHAUSTED:case C.INTERNAL:case C.UNAVAILABLE:case C.UNAUTHENTICATED:return!1;case C.INVALID_ARGUMENT:case C.NOT_FOUND:case C.ALREADY_EXISTS:case C.PERMISSION_DENIED:case C.FAILED_PRECONDITION:case C.ABORTED:case C.OUT_OF_RANGE:case C.UNIMPLEMENTED:case C.DATA_LOSS:return!0}}function em(n){if(n===void 0)return Te("GRPC error has no .code"),C.UNKNOWN;switch(n){case Se.OK:return C.OK;case Se.CANCELLED:return C.CANCELLED;case Se.UNKNOWN:return C.UNKNOWN;case Se.DEADLINE_EXCEEDED:return C.DEADLINE_EXCEEDED;case Se.RESOURCE_EXHAUSTED:return C.RESOURCE_EXHAUSTED;case Se.INTERNAL:return C.INTERNAL;case Se.UNAVAILABLE:return C.UNAVAILABLE;case Se.UNAUTHENTICATED:return C.UNAUTHENTICATED;case Se.INVALID_ARGUMENT:return C.INVALID_ARGUMENT;case Se.NOT_FOUND:return C.NOT_FOUND;case Se.ALREADY_EXISTS:return C.ALREADY_EXISTS;case Se.PERMISSION_DENIED:return C.PERMISSION_DENIED;case Se.FAILED_PRECONDITION:return C.FAILED_PRECONDITION;case Se.ABORTED:return C.ABORTED;case Se.OUT_OF_RANGE:return C.OUT_OF_RANGE;case Se.UNIMPLEMENTED:return C.UNIMPLEMENTED;case Se.DATA_LOSS:return C.DATA_LOSS;default:return q()}}(ie=Se||(Se={}))[ie.OK=0]="OK",ie[ie.CANCELLED=1]="CANCELLED",ie[ie.UNKNOWN=2]="UNKNOWN",ie[ie.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",ie[ie.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",ie[ie.NOT_FOUND=5]="NOT_FOUND",ie[ie.ALREADY_EXISTS=6]="ALREADY_EXISTS",ie[ie.PERMISSION_DENIED=7]="PERMISSION_DENIED",ie[ie.UNAUTHENTICATED=16]="UNAUTHENTICATED",ie[ie.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",ie[ie.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",ie[ie.ABORTED=10]="ABORTED",ie[ie.OUT_OF_RANGE=11]="OUT_OF_RANGE",ie[ie.UNIMPLEMENTED=12]="UNIMPLEMENTED",ie[ie.INTERNAL=13]="INTERNAL",ie[ie.UNAVAILABLE=14]="UNAVAILABLE",ie[ie.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kE(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const CE=new Bn([4294967295,4294967295],0);function id(n){const e=kE().encode(n),t=new ap;return t.update(e),new Uint8Array(t.digest())}function od(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),r=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new Bn([t,s],0),new Bn([r,i],0)]}class Il{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new Dr(`Invalid padding: ${t}`);if(s<0)throw new Dr(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new Dr(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new Dr(`Invalid padding when bitmap length is 0: ${t}`);this.Ie=8*e.length-t,this.Te=Bn.fromNumber(this.Ie)}Ee(e,t,s){let r=e.add(t.multiply(Bn.fromNumber(s)));return r.compare(CE)===1&&(r=new Bn([r.getBits(0),r.getBits(1)],0)),r.modulo(this.Te).toNumber()}de(e){return(this.bitmap[Math.floor(e/8)]&1<<e%8)!=0}mightContain(e){if(this.Ie===0)return!1;const t=id(e),[s,r]=od(t);for(let i=0;i<this.hashCount;i++){const o=this.Ee(s,r,i);if(!this.de(o))return!1}return!0}static create(e,t,s){const r=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new Il(i,r,t);return s.forEach(c=>o.insert(c)),o}insert(e){if(this.Ie===0)return;const t=id(e),[s,r]=od(t);for(let i=0;i<this.hashCount;i++){const o=this.Ee(s,r,i);this.Ae(o)}}Ae(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class Dr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yi{constructor(e,t,s,r,i){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=r,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const r=new Map;return r.set(e,vi.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new yi(H.min(),r,new pe(X),at(),te())}}class vi{constructor(e,t,s,r,i){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new vi(s,t,te(),te(),te())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(e,t,s,r){this.Re=e,this.removedTargetIds=t,this.key=s,this.Ve=r}}class tm{constructor(e,t){this.targetId=e,this.me=t}}class nm{constructor(e,t,s=Oe.EMPTY_BYTE_STRING,r=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=r}}class ad{constructor(){this.fe=0,this.ge=ld(),this.pe=Oe.EMPTY_BYTE_STRING,this.ye=!1,this.we=!0}get current(){return this.ye}get resumeToken(){return this.pe}get Se(){return this.fe!==0}get be(){return this.we}De(e){e.approximateByteSize()>0&&(this.we=!0,this.pe=e)}Ce(){let e=te(),t=te(),s=te();return this.ge.forEach((r,i)=>{switch(i){case 0:e=e.add(r);break;case 2:t=t.add(r);break;case 1:s=s.add(r);break;default:q()}}),new vi(this.pe,this.ye,e,t,s)}ve(){this.we=!1,this.ge=ld()}Fe(e,t){this.we=!0,this.ge=this.ge.insert(e,t)}Me(e){this.we=!0,this.ge=this.ge.remove(e)}xe(){this.fe+=1}Oe(){this.fe-=1,W(this.fe>=0)}Ne(){this.we=!0,this.ye=!0}}class DE{constructor(e){this.Le=e,this.Be=new Map,this.ke=at(),this.qe=cd(),this.Qe=new pe(X)}Ke(e){for(const t of e.Re)e.Ve&&e.Ve.isFoundDocument()?this.$e(t,e.Ve):this.Ue(t,e.key,e.Ve);for(const t of e.removedTargetIds)this.Ue(t,e.key,e.Ve)}We(e){this.forEachTarget(e,t=>{const s=this.Ge(t);switch(e.state){case 0:this.ze(t)&&s.De(e.resumeToken);break;case 1:s.Oe(),s.Se||s.ve(),s.De(e.resumeToken);break;case 2:s.Oe(),s.Se||this.removeTarget(t);break;case 3:this.ze(t)&&(s.Ne(),s.De(e.resumeToken));break;case 4:this.ze(t)&&(this.je(t),s.De(e.resumeToken));break;default:q()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.Be.forEach((s,r)=>{this.ze(r)&&t(r)})}He(e){const t=e.targetId,s=e.me.count,r=this.Je(t);if(r){const i=r.target;if(So(i))if(s===0){const o=new $(i.path);this.Ue(t,o,be.newNoDocument(o,H.min()))}else W(s===1);else{const o=this.Ye(t);if(o!==s){const c=this.Ze(e),l=c?this.Xe(c,e,o):1;if(l!==0){this.je(t);const u=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Qe=this.Qe.insert(t,u)}}}}}Ze(e){const t=e.me.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:r=0},hashCount:i=0}=t;let o,c;try{o=_n(s).toUint8Array()}catch(l){if(l instanceof Pp)return Hr("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{c=new Il(o,r,i)}catch(l){return Hr(l instanceof Dr?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return c.Ie===0?null:c}Xe(e,t,s){return t.me.count===s-this.nt(e,t.targetId)?0:2}nt(e,t){const s=this.Le.getRemoteKeysForTarget(t);let r=0;return s.forEach(i=>{const o=this.Le.tt(),c=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(c)||(this.Ue(t,i,null),r++)}),r}rt(e){const t=new Map;this.Be.forEach((i,o)=>{const c=this.Je(o);if(c){if(i.current&&So(c.target)){const l=new $(c.target.path);this.ke.get(l)!==null||this.it(o,l)||this.Ue(o,l,be.newNoDocument(l,e))}i.be&&(t.set(o,i.Ce()),i.ve())}});let s=te();this.qe.forEach((i,o)=>{let c=!0;o.forEachWhile(l=>{const u=this.Je(l);return!u||u.purpose==="TargetPurposeLimboResolution"||(c=!1,!1)}),c&&(s=s.add(i))}),this.ke.forEach((i,o)=>o.setReadTime(e));const r=new yi(e,t,this.Qe,this.ke,s);return this.ke=at(),this.qe=cd(),this.Qe=new pe(X),r}$e(e,t){if(!this.ze(e))return;const s=this.it(e,t.key)?2:0;this.Ge(e).Fe(t.key,s),this.ke=this.ke.insert(t.key,t),this.qe=this.qe.insert(t.key,this.st(t.key).add(e))}Ue(e,t,s){if(!this.ze(e))return;const r=this.Ge(e);this.it(e,t)?r.Fe(t,1):r.Me(t),this.qe=this.qe.insert(t,this.st(t).delete(e)),s&&(this.ke=this.ke.insert(t,s))}removeTarget(e){this.Be.delete(e)}Ye(e){const t=this.Ge(e).Ce();return this.Le.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}xe(e){this.Ge(e).xe()}Ge(e){let t=this.Be.get(e);return t||(t=new ad,this.Be.set(e,t)),t}st(e){let t=this.qe.get(e);return t||(t=new he(X),this.qe=this.qe.insert(e,t)),t}ze(e){const t=this.Je(e)!==null;return t||D("WatchChangeAggregator","Detected inactive target",e),t}Je(e){const t=this.Be.get(e);return t&&t.Se?null:this.Le.ot(e)}je(e){this.Be.set(e,new ad),this.Le.getRemoteKeysForTarget(e).forEach(t=>{this.Ue(e,t,null)})}it(e,t){return this.Le.getRemoteKeysForTarget(e).has(t)}}function cd(){return new pe($.comparator)}function ld(){return new pe($.comparator)}const VE={asc:"ASCENDING",desc:"DESCENDING"},NE={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},xE={and:"AND",or:"OR"};class OE{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Rc(n,e){return n.useProto3Json||Xo(e)?e:{value:e}}function Ms(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function sm(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function LE(n,e){return Ms(n,e.toTimestamp())}function Ze(n){return W(!!n),H.fromTimestamp(function(t){const s=qt(t);return new ve(s.seconds,s.nanos)}(n))}function wl(n,e){return Pc(n,e).canonicalString()}function Pc(n,e){const t=function(r){return new le(["projects",r.projectId,"databases",r.database])}(n).child("documents");return e===void 0?t:t.child(e)}function rm(n){const e=le.fromString(n);return W(fm(e)),e}function Po(n,e){return wl(n.databaseId,e.path)}function qn(n,e){const t=rm(e);if(t.get(1)!==n.databaseId.projectId)throw new F(C.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new F(C.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new $(am(t))}function im(n,e){return wl(n.databaseId,e)}function om(n){const e=rm(n);return e.length===4?le.emptyPath():am(e)}function kc(n){return new le(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function am(n){return W(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function ud(n,e,t){return{name:Po(n,e),fields:t.value.mapValue.fields}}function ME(n,e,t){const s=qn(n,e.name),r=Ze(e.updateTime),i=e.createTime?Ze(e.createTime):H.min(),o=new We({mapValue:{fields:e.fields}}),c=be.newFoundDocument(s,r,i,o);return t&&c.setHasCommittedMutations(),t?c.setHasCommittedMutations():c}function $E(n,e){let t;if("targetChange"in e){e.targetChange;const s=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:q()}(e.targetChange.targetChangeType||"NO_CHANGE"),r=e.targetChange.targetIds||[],i=function(u,f){return u.useProto3Json?(W(f===void 0||typeof f=="string"),Oe.fromBase64String(f||"")):(W(f===void 0||f instanceof Buffer||f instanceof Uint8Array),Oe.fromUint8Array(f||new Uint8Array))}(n,e.targetChange.resumeToken),o=e.targetChange.cause,c=o&&function(u){const f=u.code===void 0?C.UNKNOWN:em(u.code);return new F(f,u.message||"")}(o);t=new nm(s,r,i,c||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const r=qn(n,s.document.name),i=Ze(s.document.updateTime),o=s.document.createTime?Ze(s.document.createTime):H.min(),c=new We({mapValue:{fields:s.document.fields}}),l=be.newFoundDocument(r,i,o,c),u=s.targetIds||[],f=s.removedTargetIds||[];t=new uo(u,f,l.key,l)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const r=qn(n,s.document),i=s.readTime?Ze(s.readTime):H.min(),o=be.newNoDocument(r,i),c=s.removedTargetIds||[];t=new uo([],c,o.key,o)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const r=qn(n,s.document),i=s.removedTargetIds||[];t=new uo([],i,r,null)}else{if(!("filter"in e))return q();{e.filter;const s=e.filter;s.targetId;const{count:r=0,unchangedNames:i}=s,o=new RE(r,i),c=s.targetId;t=new tm(c,o)}}return t}function ko(n,e){let t;if(e instanceof Xs)t={update:ud(n,e.key,e.value)};else if(e instanceof ra)t={delete:Po(n,e.key)};else if(e instanceof Gt)t={update:ud(n,e.key,e.data),updateMask:GE(e.fieldMask)};else{if(!(e instanceof Zp))return q();t={verify:Po(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(s=>function(i,o){const c=o.transform;if(c instanceof ti)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(c instanceof Os)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:c.elements}};if(c instanceof Ls)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:c.elements}};if(c instanceof ni)return{fieldPath:o.field.canonicalString(),increment:c.Pe};throw q()}(0,s))),e.precondition.isNone||(t.currentDocument=function(r,i){return i.updateTime!==void 0?{updateTime:LE(r,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:q()}(n,e.precondition)),t}function Cc(n,e){const t=e.currentDocument?function(i){return i.updateTime!==void 0?Ye.updateTime(Ze(i.updateTime)):i.exists!==void 0?Ye.exists(i.exists):Ye.none()}(e.currentDocument):Ye.none(),s=e.updateTransforms?e.updateTransforms.map(r=>function(o,c){let l=null;if("setToServerValue"in c)W(c.setToServerValue==="REQUEST_TIME"),l=new ti;else if("appendMissingElements"in c){const f=c.appendMissingElements.values||[];l=new Os(f)}else if("removeAllFromArray"in c){const f=c.removeAllFromArray.values||[];l=new Ls(f)}else"increment"in c?l=new ni(o,c.increment):q();const u=ye.fromServerFormat(c.fieldPath);return new EE(u,l)}(n,r)):[];if(e.update){e.update.name;const r=qn(n,e.update.name),i=new We({mapValue:{fields:e.update.fields}});if(e.updateMask){const o=function(l){const u=l.fieldPaths||[];return new rt(u.map(f=>ye.fromServerFormat(f)))}(e.updateMask);return new Gt(r,i,o,t,s)}return new Xs(r,i,t,s)}if(e.delete){const r=qn(n,e.delete);return new ra(r,t)}if(e.verify){const r=qn(n,e.verify);return new Zp(r,t)}return q()}function FE(n,e){return n&&n.length>0?(W(e!==void 0),n.map(t=>function(r,i){let o=r.updateTime?Ze(r.updateTime):Ze(i);return o.isEqual(H.min())&&(o=Ze(i)),new TE(o,r.transformResults||[])}(t,e))):[]}function cm(n,e){return{documents:[im(n,e.path)]}}function lm(n,e){const t={structuredQuery:{}},s=e.path;let r;e.collectionGroup!==null?(r=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(r=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=im(n,r);const i=function(u){if(u.length!==0)return dm(ue.create(u,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const o=function(u){if(u.length!==0)return u.map(f=>function(y){return{field:ys(y.field),direction:BE(y.dir)}}(f))}(e.orderBy);o&&(t.structuredQuery.orderBy=o);const c=Rc(n,e.limit);return c!==null&&(t.structuredQuery.limit=c),e.startAt&&(t.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(e.endAt)),{_t:t,parent:r}}function um(n){let e=om(n.parent);const t=n.structuredQuery,s=t.from?t.from.length:0;let r=null;if(s>0){W(s===1);const f=t.from[0];f.allDescendants?r=f.collectionId:e=e.child(f.collectionId)}let i=[];t.where&&(i=function(p){const y=hm(p);return y instanceof ue&&ml(y)?y.getFilters():[y]}(t.where));let o=[];t.orderBy&&(o=function(p){return p.map(y=>function(k){return new Ao(vs(k.field),function(R){switch(R){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(k.direction))}(y))}(t.orderBy));let c=null;t.limit&&(c=function(p){let y;return y=typeof p=="object"?p.value:p,Xo(y)?null:y}(t.limit));let l=null;t.startAt&&(l=function(p){const y=!!p.before,S=p.values||[];return new Ns(S,y)}(t.startAt));let u=null;return t.endAt&&(u=function(p){const y=!p.before,S=p.values||[];return new Ns(S,y)}(t.endAt)),$p(e,r,o,i,c,"F",l,u)}function UE(n,e){const t=function(r){switch(r){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return q()}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function hm(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=vs(t.unaryFilter.field);return re.create(s,"==",{doubleValue:NaN});case"IS_NULL":const r=vs(t.unaryFilter.field);return re.create(r,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=vs(t.unaryFilter.field);return re.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=vs(t.unaryFilter.field);return re.create(o,"!=",{nullValue:"NULL_VALUE"});default:return q()}}(n):n.fieldFilter!==void 0?function(t){return re.create(vs(t.fieldFilter.field),function(r){switch(r){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return q()}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return ue.create(t.compositeFilter.filters.map(s=>hm(s)),function(r){switch(r){case"AND":return"and";case"OR":return"or";default:return q()}}(t.compositeFilter.op))}(n):q()}function BE(n){return VE[n]}function qE(n){return NE[n]}function jE(n){return xE[n]}function ys(n){return{fieldPath:n.canonicalString()}}function vs(n){return ye.fromServerFormat(n.fieldPath)}function dm(n){return n instanceof re?function(t){if(t.op==="=="){if(Wh(t.value))return{unaryFilter:{field:ys(t.field),op:"IS_NAN"}};if(Kh(t.value))return{unaryFilter:{field:ys(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Wh(t.value))return{unaryFilter:{field:ys(t.field),op:"IS_NOT_NAN"}};if(Kh(t.value))return{unaryFilter:{field:ys(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:ys(t.field),op:qE(t.op),value:t.value}}}(n):n instanceof ue?function(t){const s=t.getFilters().map(r=>dm(r));return s.length===1?s[0]:{compositeFilter:{op:jE(t.op),filters:s}}}(n):q()}function GE(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function fm(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $t{constructor(e,t,s,r,i=H.min(),o=H.min(),c=Oe.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=c,this.expectedCount=l}withSequenceNumber(e){return new $t(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new $t(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new $t(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new $t(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pm{constructor(e){this.ct=e}}function zE(n,e){let t;if(e.document)t=ME(n.ct,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const s=$.fromSegments(e.noDocument.path),r=es(e.noDocument.readTime);t=be.newNoDocument(s,r),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return q();{const s=$.fromSegments(e.unknownDocument.path),r=es(e.unknownDocument.version);t=be.newUnknownDocument(s,r)}}return e.readTime&&t.setReadTime(function(r){const i=new ve(r[0],r[1]);return H.fromTimestamp(i)}(e.readTime)),t}function hd(n,e){const t=e.key,s={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:Co(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())s.document=function(i,o){return{name:Po(i,o.key),fields:o.data.value.mapValue.fields,updateTime:Ms(i,o.version.toTimestamp()),createTime:Ms(i,o.createTime.toTimestamp())}}(n.ct,e);else if(e.isNoDocument())s.noDocument={path:t.path.toArray(),readTime:Zn(e.version)};else{if(!e.isUnknownDocument())return q();s.unknownDocument={path:t.path.toArray(),version:Zn(e.version)}}return s}function Co(n){const e=n.toTimestamp();return[e.seconds,e.nanoseconds]}function Zn(n){const e=n.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function es(n){const e=new ve(n.seconds,n.nanoseconds);return H.fromTimestamp(e)}function Ln(n,e){const t=(e.baseMutations||[]).map(i=>Cc(n.ct,i));for(let i=0;i<e.mutations.length-1;++i){const o=e.mutations[i];if(i+1<e.mutations.length&&e.mutations[i+1].transform!==void 0){const c=e.mutations[i+1];o.updateTransforms=c.transform.fieldTransforms,e.mutations.splice(i+1,1),++i}}const s=e.mutations.map(i=>Cc(n.ct,i)),r=ve.fromMillis(e.localWriteTimeMs);return new _l(e.batchId,r,t,s)}function Vr(n){const e=es(n.readTime),t=n.lastLimboFreeSnapshotVersion!==void 0?es(n.lastLimboFreeSnapshotVersion):H.min();let s;return s=function(i){return i.documents!==void 0}(n.query)?function(i){return W(i.documents.length===1),ct(ea(om(i.documents[0])))}(n.query):function(i){return ct(um(i))}(n.query),new $t(s,n.targetId,"TargetPurposeListen",n.lastListenSequenceNumber,e,t,Oe.fromBase64String(n.resumeToken))}function mm(n,e){const t=Zn(e.snapshotVersion),s=Zn(e.lastLimboFreeSnapshotVersion);let r;r=So(e.target)?cm(n.ct,e.target):lm(n.ct,e.target)._t;const i=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:Xn(e.target),readTime:t,resumeToken:i,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:s,query:r}}function gm(n){const e=um({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Sc(e,e.limit,"L"):e}function Za(n,e){return new vl(e.largestBatchId,Cc(n.ct,e.overlayMutation))}function dd(n,e){const t=e.path.lastSegment();return[n,Xe(e.path.popLast()),t]}function fd(n,e,t,s){return{indexId:n,uid:e,sequenceNumber:t,readTime:Zn(s.readTime),documentKey:Xe(s.documentKey.path),largestBatchId:s.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KE{getBundleMetadata(e,t){return pd(e).get(t).next(s=>{if(s)return function(i){return{id:i.bundleId,createTime:es(i.createTime),version:i.version}}(s)})}saveBundleMetadata(e,t){return pd(e).put(function(r){return{bundleId:r.id,createTime:Zn(Ze(r.createTime)),version:r.version}}(t))}getNamedQuery(e,t){return md(e).get(t).next(s=>{if(s)return function(i){return{name:i.name,query:gm(i.bundledQuery),readTime:es(i.readTime)}}(s)})}saveNamedQuery(e,t){return md(e).put(function(r){return{name:r.name,readTime:Zn(Ze(r.readTime)),bundledQuery:r.bundledQuery}}(t))}}function pd(n){return Le(n,"bundles")}function md(n){return Le(n,"namedQueries")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ia{constructor(e,t){this.serializer=e,this.userId=t}static lt(e,t){const s=t.uid||"";return new ia(e,s)}getOverlay(e,t){return Ir(e).get(dd(this.userId,t)).next(s=>s?Za(this.serializer,s):null)}getOverlays(e,t){const s=At();return A.forEach(t,r=>this.getOverlay(e,r).next(i=>{i!==null&&s.set(r,i)})).next(()=>s)}saveOverlays(e,t,s){const r=[];return s.forEach((i,o)=>{const c=new vl(t,o);r.push(this.ht(e,c))}),A.waitFor(r)}removeOverlaysForBatchId(e,t,s){const r=new Set;t.forEach(o=>r.add(Xe(o.getCollectionPath())));const i=[];return r.forEach(o=>{const c=IDBKeyRange.bound([this.userId,o,s],[this.userId,o,s+1],!1,!0);i.push(Ir(e).j("collectionPathOverlayIndex",c))}),A.waitFor(i)}getOverlaysForCollection(e,t,s){const r=At(),i=Xe(t),o=IDBKeyRange.bound([this.userId,i,s],[this.userId,i,Number.POSITIVE_INFINITY],!0);return Ir(e).U("collectionPathOverlayIndex",o).next(c=>{for(const l of c){const u=Za(this.serializer,l);r.set(u.getKey(),u)}return r})}getOverlaysForCollectionGroup(e,t,s,r){const i=At();let o;const c=IDBKeyRange.bound([this.userId,t,s],[this.userId,t,Number.POSITIVE_INFINITY],!0);return Ir(e).J({index:"collectionGroupOverlayIndex",range:c},(l,u,f)=>{const p=Za(this.serializer,u);i.size()<r||p.largestBatchId===o?(i.set(p.getKey(),p),o=p.largestBatchId):f.done()}).next(()=>i)}ht(e,t){return Ir(e).put(function(r,i,o){const[c,l,u]=dd(i,o.mutation.key);return{userId:i,collectionPath:l,documentId:u,collectionGroup:o.mutation.key.getCollectionGroup(),largestBatchId:o.largestBatchId,overlayMutation:ko(r.ct,o.mutation)}}(this.serializer,this.userId,t))}}function Ir(n){return Le(n,"documentOverlays")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mn{constructor(){}Pt(e,t){this.It(e,t),t.Tt()}It(e,t){if("nullValue"in e)this.Et(t,5);else if("booleanValue"in e)this.Et(t,10),t.dt(e.booleanValue?1:0);else if("integerValue"in e)this.Et(t,15),t.dt(Ee(e.integerValue));else if("doubleValue"in e){const s=Ee(e.doubleValue);isNaN(s)?this.Et(t,13):(this.Et(t,15),Yr(s)?t.dt(0):t.dt(s))}else if("timestampValue"in e){let s=e.timestampValue;this.Et(t,20),typeof s=="string"&&(s=qt(s)),t.At(`${s.seconds||""}`),t.dt(s.nanos||0)}else if("stringValue"in e)this.Rt(e.stringValue,t),this.Vt(t);else if("bytesValue"in e)this.Et(t,30),t.ft(_n(e.bytesValue)),this.Vt(t);else if("referenceValue"in e)this.gt(e.referenceValue,t);else if("geoPointValue"in e){const s=e.geoPointValue;this.Et(t,45),t.dt(s.latitude||0),t.dt(s.longitude||0)}else"mapValue"in e?kp(e)?this.Et(t,Number.MAX_SAFE_INTEGER):(this.yt(e.mapValue,t),this.Vt(t)):"arrayValue"in e?(this.wt(e.arrayValue,t),this.Vt(t)):q()}Rt(e,t){this.Et(t,25),this.St(e,t)}St(e,t){t.At(e)}yt(e,t){const s=e.fields||{};this.Et(t,55);for(const r of Object.keys(s))this.Rt(r,t),this.It(s[r],t)}wt(e,t){const s=e.values||[];this.Et(t,50);for(const r of s)this.It(r,t)}gt(e,t){this.Et(t,37),$.fromName(e).path.forEach(s=>{this.Et(t,60),this.St(s,t)})}Et(e,t){e.dt(t)}Vt(e){e.dt(2)}}Mn.bt=new Mn;function WE(n){if(n===0)return 8;let e=0;return!(n>>4)&&(e+=4,n<<=4),!(n>>6)&&(e+=2,n<<=2),!(n>>7)&&(e+=1),e}function gd(n){const e=64-function(s){let r=0;for(let i=0;i<8;++i){const o=WE(255&s[i]);if(r+=o,o!==8)break}return r}(n);return Math.ceil(e/8)}class HE{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Dt(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Ct(s.value),s=t.next();this.vt()}Ft(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Mt(s.value),s=t.next();this.xt()}Ot(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Ct(s);else if(s<2048)this.Ct(960|s>>>6),this.Ct(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Ct(480|s>>>12),this.Ct(128|63&s>>>6),this.Ct(128|63&s);else{const r=t.codePointAt(0);this.Ct(240|r>>>18),this.Ct(128|63&r>>>12),this.Ct(128|63&r>>>6),this.Ct(128|63&r)}}this.vt()}Nt(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Mt(s);else if(s<2048)this.Mt(960|s>>>6),this.Mt(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Mt(480|s>>>12),this.Mt(128|63&s>>>6),this.Mt(128|63&s);else{const r=t.codePointAt(0);this.Mt(240|r>>>18),this.Mt(128|63&r>>>12),this.Mt(128|63&r>>>6),this.Mt(128|63&r)}}this.xt()}Lt(e){const t=this.Bt(e),s=gd(t);this.kt(1+s),this.buffer[this.position++]=255&s;for(let r=t.length-s;r<t.length;++r)this.buffer[this.position++]=255&t[r]}qt(e){const t=this.Bt(e),s=gd(t);this.kt(1+s),this.buffer[this.position++]=~(255&s);for(let r=t.length-s;r<t.length;++r)this.buffer[this.position++]=~(255&t[r])}Qt(){this.Kt(255),this.Kt(255)}$t(){this.Ut(255),this.Ut(255)}reset(){this.position=0}seed(e){this.kt(e.length),this.buffer.set(e,this.position),this.position+=e.length}Wt(){return this.buffer.slice(0,this.position)}Bt(e){const t=function(i){const o=new DataView(new ArrayBuffer(8));return o.setFloat64(0,i,!1),new Uint8Array(o.buffer)}(e),s=(128&t[0])!=0;t[0]^=s?255:128;for(let r=1;r<t.length;++r)t[r]^=s?255:0;return t}Ct(e){const t=255&e;t===0?(this.Kt(0),this.Kt(255)):t===255?(this.Kt(255),this.Kt(0)):this.Kt(t)}Mt(e){const t=255&e;t===0?(this.Ut(0),this.Ut(255)):t===255?(this.Ut(255),this.Ut(0)):this.Ut(e)}vt(){this.Kt(0),this.Kt(1)}xt(){this.Ut(0),this.Ut(1)}Kt(e){this.kt(1),this.buffer[this.position++]=e}Ut(e){this.kt(1),this.buffer[this.position++]=~e}kt(e){const t=e+this.position;if(t<=this.buffer.length)return;let s=2*this.buffer.length;s<t&&(s=t);const r=new Uint8Array(s);r.set(this.buffer),this.buffer=r}}class QE{constructor(e){this.Gt=e}ft(e){this.Gt.Dt(e)}At(e){this.Gt.Ot(e)}dt(e){this.Gt.Lt(e)}Tt(){this.Gt.Qt()}}class JE{constructor(e){this.Gt=e}ft(e){this.Gt.Ft(e)}At(e){this.Gt.Nt(e)}dt(e){this.Gt.qt(e)}Tt(){this.Gt.$t()}}class wr{constructor(){this.Gt=new HE,this.zt=new QE(this.Gt),this.jt=new JE(this.Gt)}seed(e){this.Gt.seed(e)}Ht(e){return e===0?this.zt:this.jt}Wt(){return this.Gt.Wt()}reset(){this.Gt.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $n{constructor(e,t,s,r){this.indexId=e,this.documentKey=t,this.arrayValue=s,this.directionalValue=r}Jt(){const e=this.directionalValue.length,t=e===0||this.directionalValue[e-1]===255?e+1:e,s=new Uint8Array(t);return s.set(this.directionalValue,0),t!==e?s.set([0],this.directionalValue.length):++s[s.length-1],new $n(this.indexId,this.documentKey,this.arrayValue,s)}}function Yt(n,e){let t=n.indexId-e.indexId;return t!==0?t:(t=_d(n.arrayValue,e.arrayValue),t!==0?t:(t=_d(n.directionalValue,e.directionalValue),t!==0?t:$.comparator(n.documentKey,e.documentKey)))}function _d(n,e){for(let t=0;t<n.length&&t<e.length;++t){const s=n[t]-e[t];if(s!==0)return s}return n.length-e.length}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yd{constructor(e){this.Yt=new he((t,s)=>ye.comparator(t.field,s.field)),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.Zt=e.orderBy,this.Xt=[];for(const t of e.filters){const s=t;s.isInequality()?this.Yt=this.Yt.add(s):this.Xt.push(s)}}get en(){return this.Yt.size>1}tn(e){if(W(e.collectionGroup===this.collectionId),this.en)return!1;const t=vc(e);if(t!==void 0&&!this.nn(t))return!1;const s=xn(e);let r=new Set,i=0,o=0;for(;i<s.length&&this.nn(s[i]);++i)r=r.add(s[i].fieldPath.canonicalString());if(i===s.length)return!0;if(this.Yt.size>0){const c=this.Yt.getIterator().getNext();if(!r.has(c.field.canonicalString())){const l=s[i];if(!this.rn(c,l)||!this.sn(this.Zt[o++],l))return!1}++i}for(;i<s.length;++i){const c=s[i];if(o>=this.Zt.length||!this.sn(this.Zt[o++],c))return!1}return!0}on(){if(this.en)return null;let e=new he(ye.comparator);const t=[];for(const s of this.Xt)if(!s.field.isKeyField())if(s.op==="array-contains"||s.op==="array-contains-any")t.push(new io(s.field,2));else{if(e.has(s.field))continue;e=e.add(s.field),t.push(new io(s.field,0))}for(const s of this.Zt)s.field.isKeyField()||e.has(s.field)||(e=e.add(s.field),t.push(new io(s.field,s.dir==="asc"?0:1)));return new To(To.UNKNOWN_ID,this.collectionId,t,Jr.empty())}nn(e){for(const t of this.Xt)if(this.rn(t,e))return!0;return!1}rn(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const s=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===s}sn(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _m(n){var e,t;if(W(n instanceof re||n instanceof ue),n instanceof re){if(n instanceof Mp){const r=((t=(e=n.value.arrayValue)===null||e===void 0?void 0:e.values)===null||t===void 0?void 0:t.map(i=>re.create(n.field,"==",i)))||[];return ue.create(r,"or")}return n}const s=n.filters.map(r=>_m(r));return ue.create(s,n.op)}function YE(n){if(n.getFilters().length===0)return[];const e=Nc(_m(n));return W(ym(e)),Dc(e)||Vc(e)?[e]:e.getFilters()}function Dc(n){return n instanceof re}function Vc(n){return n instanceof ue&&ml(n)}function ym(n){return Dc(n)||Vc(n)||function(t){if(t instanceof ue&&bc(t)){for(const s of t.getFilters())if(!Dc(s)&&!Vc(s))return!1;return!0}return!1}(n)}function Nc(n){if(W(n instanceof re||n instanceof ue),n instanceof re)return n;if(n.filters.length===1)return Nc(n.filters[0]);const e=n.filters.map(s=>Nc(s));let t=ue.create(e,n.op);return t=Do(t),ym(t)?t:(W(t instanceof ue),W(xs(t)),W(t.filters.length>1),t.filters.reduce((s,r)=>El(s,r)))}function El(n,e){let t;return W(n instanceof re||n instanceof ue),W(e instanceof re||e instanceof ue),t=n instanceof re?e instanceof re?function(r,i){return ue.create([r,i],"and")}(n,e):vd(n,e):e instanceof re?vd(e,n):function(r,i){if(W(r.filters.length>0&&i.filters.length>0),xs(r)&&xs(i))return xp(r,i.getFilters());const o=bc(r)?r:i,c=bc(r)?i:r,l=o.filters.map(u=>El(u,c));return ue.create(l,"or")}(n,e),Do(t)}function vd(n,e){if(xs(e))return xp(e,n.getFilters());{const t=e.filters.map(s=>El(n,s));return ue.create(t,"or")}}function Do(n){if(W(n instanceof re||n instanceof ue),n instanceof re)return n;const e=n.getFilters();if(e.length===1)return Do(e[0]);if(Vp(n))return n;const t=e.map(r=>Do(r)),s=[];return t.forEach(r=>{r instanceof re?s.push(r):r instanceof ue&&(r.op===n.op?s.push(...r.filters):s.push(r))}),s.length===1?s[0]:ue.create(s,n.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XE{constructor(){this._n=new bl}addToCollectionParentIndex(e,t){return this._n.add(t),A.resolve()}getCollectionParents(e,t){return A.resolve(this._n.getEntries(t))}addFieldIndex(e,t){return A.resolve()}deleteFieldIndex(e,t){return A.resolve()}deleteAllFieldIndexes(e){return A.resolve()}createTargetIndexes(e,t){return A.resolve()}getDocumentsMatchingTarget(e,t){return A.resolve(null)}getIndexType(e,t){return A.resolve(0)}getFieldIndexes(e,t){return A.resolve([])}getNextCollectionGroupToUpdate(e){return A.resolve(null)}getMinOffset(e,t){return A.resolve(ht.min())}getMinOffsetFromCollectionGroup(e,t){return A.resolve(ht.min())}updateCollectionGroup(e,t,s){return A.resolve()}updateIndexEntries(e,t){return A.resolve()}}class bl{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),r=this.index[t]||new he(le.comparator),i=!r.has(s);return this.index[t]=r.add(s),i}has(e){const t=e.lastSegment(),s=e.popLast(),r=this.index[t];return r&&r.has(s)}getEntries(e){return(this.index[e]||new he(le.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hi=new Uint8Array(0);class ZE{constructor(e,t){this.databaseId=t,this.an=new bl,this.un=new Sn(s=>Xn(s),(s,r)=>gi(s,r)),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.an.has(t)){const s=t.lastSegment(),r=t.popLast();e.addOnCommittedListener(()=>{this.an.add(t)});const i={collectionId:s,parent:Xe(r)};return Id(e).put(i)}return A.resolve()}getCollectionParents(e,t){const s=[],r=IDBKeyRange.bound([t,""],[mp(t),""],!1,!0);return Id(e).U(r).next(i=>{for(const o of i){if(o.collectionId!==t)break;s.push(Tt(o.parent))}return s})}addFieldIndex(e,t){const s=Er(e),r=function(c){return{indexId:c.indexId,collectionGroup:c.collectionGroup,fields:c.fields.map(l=>[l.fieldPath.canonicalString(),l.kind])}}(t);delete r.indexId;const i=s.add(r);if(t.indexState){const o=fs(e);return i.next(c=>{o.put(fd(c,this.uid,t.indexState.sequenceNumber,t.indexState.offset))})}return i.next()}deleteFieldIndex(e,t){const s=Er(e),r=fs(e),i=ds(e);return s.delete(t.indexId).next(()=>r.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))).next(()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))}deleteAllFieldIndexes(e){const t=Er(e),s=ds(e),r=fs(e);return t.j().next(()=>s.j()).next(()=>r.j())}createTargetIndexes(e,t){return A.forEach(this.cn(t),s=>this.getIndexType(e,s).next(r=>{if(r===0||r===1){const i=new yd(s).on();if(i!=null)return this.addFieldIndex(e,i)}}))}getDocumentsMatchingTarget(e,t){const s=ds(e);let r=!0;const i=new Map;return A.forEach(this.cn(t),o=>this.ln(e,o).next(c=>{r&&(r=!!c),i.set(o,c)})).next(()=>{if(r){let o=te();const c=[];return A.forEach(i,(l,u)=>{D("IndexedDbIndexManager",`Using index ${function(j){return`id=${j.indexId}|cg=${j.collectionGroup}|f=${j.fields.map(Z=>`${Z.fieldPath}:${Z.kind}`).join(",")}`}(l)} to execute ${Xn(t)}`);const f=function(j,Z){const N=vc(Z);if(N===void 0)return null;for(const M of Ro(j,N.fieldPath))switch(M.op){case"array-contains-any":return M.value.arrayValue.values||[];case"array-contains":return[M.value]}return null}(u,l),p=function(j,Z){const N=new Map;for(const M of xn(Z))for(const I of Ro(j,M.fieldPath))switch(I.op){case"==":case"in":N.set(M.fieldPath.canonicalString(),I.value);break;case"not-in":case"!=":return N.set(M.fieldPath.canonicalString(),I.value),Array.from(N.values())}return null}(u,l),y=function(j,Z){const N=[];let M=!0;for(const I of xn(Z)){const g=I.kind===0?Xh(j,I.fieldPath,j.startAt):Zh(j,I.fieldPath,j.startAt);N.push(g.value),M&&(M=g.inclusive)}return new Ns(N,M)}(u,l),S=function(j,Z){const N=[];let M=!0;for(const I of xn(Z)){const g=I.kind===0?Zh(j,I.fieldPath,j.endAt):Xh(j,I.fieldPath,j.endAt);N.push(g.value),M&&(M=g.inclusive)}return new Ns(N,M)}(u,l),k=this.hn(l,u,y),V=this.hn(l,u,S),R=this.Pn(l,u,p),B=this.In(l.indexId,f,k,y.inclusive,V,S.inclusive,R);return A.forEach(B,z=>s.G(z,t.limit).next(j=>{j.forEach(Z=>{const N=$.fromSegments(Z.documentKey);o.has(N)||(o=o.add(N),c.push(N))})}))}).next(()=>c)}return A.resolve(null)})}cn(e){let t=this.un.get(e);return t||(e.filters.length===0?t=[e]:t=YE(ue.create(e.filters,"and")).map(s=>Ac(e.path,e.collectionGroup,e.orderBy,s.getFilters(),e.limit,e.startAt,e.endAt)),this.un.set(e,t),t)}In(e,t,s,r,i,o,c){const l=(t!=null?t.length:1)*Math.max(s.length,i.length),u=l/(t!=null?t.length:1),f=[];for(let p=0;p<l;++p){const y=t?this.Tn(t[p/u]):Hi,S=this.En(e,y,s[p%u],r),k=this.dn(e,y,i[p%u],o),V=c.map(R=>this.En(e,y,R,!0));f.push(...this.createRange(S,k,V))}return f}En(e,t,s,r){const i=new $n(e,$.empty(),t,s);return r?i:i.Jt()}dn(e,t,s,r){const i=new $n(e,$.empty(),t,s);return r?i.Jt():i}ln(e,t){const s=new yd(t),r=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,r).next(i=>{let o=null;for(const c of i)s.tn(c)&&(!o||c.fields.length>o.fields.length)&&(o=c);return o})}getIndexType(e,t){let s=2;const r=this.cn(t);return A.forEach(r,i=>this.ln(e,i).next(o=>{o?s!==0&&o.fields.length<function(l){let u=new he(ye.comparator),f=!1;for(const p of l.filters)for(const y of p.getFlattenedFilters())y.field.isKeyField()||(y.op==="array-contains"||y.op==="array-contains-any"?f=!0:u=u.add(y.field));for(const p of l.orderBy)p.field.isKeyField()||(u=u.add(p.field));return u.size+(f?1:0)}(i)&&(s=1):s=0})).next(()=>function(o){return o.limit!==null}(t)&&r.length>1&&s===2?1:s)}An(e,t){const s=new wr;for(const r of xn(e)){const i=t.data.field(r.fieldPath);if(i==null)return null;const o=s.Ht(r.kind);Mn.bt.Pt(i,o)}return s.Wt()}Tn(e){const t=new wr;return Mn.bt.Pt(e,t.Ht(0)),t.Wt()}Rn(e,t){const s=new wr;return Mn.bt.Pt(pl(this.databaseId,t),s.Ht(function(i){const o=xn(i);return o.length===0?0:o[o.length-1].kind}(e))),s.Wt()}Pn(e,t,s){if(s===null)return[];let r=[];r.push(new wr);let i=0;for(const o of xn(e)){const c=s[i++];for(const l of r)if(this.Vn(t,o.fieldPath)&&ei(c))r=this.mn(r,o,c);else{const u=l.Ht(o.kind);Mn.bt.Pt(c,u)}}return this.fn(r)}hn(e,t,s){return this.Pn(e,t,s.position)}fn(e){const t=[];for(let s=0;s<e.length;++s)t[s]=e[s].Wt();return t}mn(e,t,s){const r=[...e],i=[];for(const o of s.arrayValue.values||[])for(const c of r){const l=new wr;l.seed(c.Wt()),Mn.bt.Pt(o,l.Ht(t.kind)),i.push(l)}return i}Vn(e,t){return!!e.filters.find(s=>s instanceof re&&s.field.isEqual(t)&&(s.op==="in"||s.op==="not-in"))}getFieldIndexes(e,t){const s=Er(e),r=fs(e);return(t?s.U("collectionGroupIndex",IDBKeyRange.bound(t,t)):s.U()).next(i=>{const o=[];return A.forEach(i,c=>r.get([c.indexId,this.uid]).next(l=>{o.push(function(f,p){const y=p?new Jr(p.sequenceNumber,new ht(es(p.readTime),new $(Tt(p.documentKey)),p.largestBatchId)):Jr.empty(),S=f.fields.map(([k,V])=>new io(ye.fromServerFormat(k),V));return new To(f.indexId,f.collectionGroup,S,y)}(c,l))})).next(()=>o)})}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next(t=>t.length===0?null:(t.sort((s,r)=>{const i=s.indexState.sequenceNumber-r.indexState.sequenceNumber;return i!==0?i:X(s.collectionGroup,r.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(e,t,s){const r=Er(e),i=fs(e);return this.gn(e).next(o=>r.U("collectionGroupIndex",IDBKeyRange.bound(t,t)).next(c=>A.forEach(c,l=>i.put(fd(l.indexId,this.uid,o,s)))))}updateIndexEntries(e,t){const s=new Map;return A.forEach(t,(r,i)=>{const o=s.get(r.collectionGroup);return(o?A.resolve(o):this.getFieldIndexes(e,r.collectionGroup)).next(c=>(s.set(r.collectionGroup,c),A.forEach(c,l=>this.pn(e,r,l).next(u=>{const f=this.yn(i,l);return u.isEqual(f)?A.resolve():this.wn(e,i,l,u,f)}))))})}Sn(e,t,s,r){return ds(e).put({indexId:r.indexId,uid:this.uid,arrayValue:r.arrayValue,directionalValue:r.directionalValue,orderedDocumentKey:this.Rn(s,t.key),documentKey:t.key.path.toArray()})}bn(e,t,s,r){return ds(e).delete([r.indexId,this.uid,r.arrayValue,r.directionalValue,this.Rn(s,t.key),t.key.path.toArray()])}pn(e,t,s){const r=ds(e);let i=new he(Yt);return r.J({index:"documentKeyIndex",range:IDBKeyRange.only([s.indexId,this.uid,this.Rn(s,t)])},(o,c)=>{i=i.add(new $n(s.indexId,t,c.arrayValue,c.directionalValue))}).next(()=>i)}yn(e,t){let s=new he(Yt);const r=this.An(t,e);if(r==null)return s;const i=vc(t);if(i!=null){const o=e.data.field(i.fieldPath);if(ei(o))for(const c of o.arrayValue.values||[])s=s.add(new $n(t.indexId,e.key,this.Tn(c),r))}else s=s.add(new $n(t.indexId,e.key,Hi,r));return s}wn(e,t,s,r,i){D("IndexedDbIndexManager","Updating index entries for document '%s'",t.key);const o=[];return function(l,u,f,p,y){const S=l.getIterator(),k=u.getIterator();let V=hs(S),R=hs(k);for(;V||R;){let B=!1,z=!1;if(V&&R){const j=f(V,R);j<0?z=!0:j>0&&(B=!0)}else V!=null?z=!0:B=!0;B?(p(R),R=hs(k)):z?(y(V),V=hs(S)):(V=hs(S),R=hs(k))}}(r,i,Yt,c=>{o.push(this.Sn(e,t,s,c))},c=>{o.push(this.bn(e,t,s,c))}),A.waitFor(o)}gn(e){let t=1;return fs(e).J({index:"sequenceNumberIndex",reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(s,r,i)=>{i.done(),t=r.sequenceNumber+1}).next(()=>t)}createRange(e,t,s){s=s.sort((o,c)=>Yt(o,c)).filter((o,c,l)=>!c||Yt(o,l[c-1])!==0);const r=[];r.push(e);for(const o of s){const c=Yt(o,e),l=Yt(o,t);if(c===0)r[0]=e.Jt();else if(c>0&&l<0)r.push(o),r.push(o.Jt());else if(l>0)break}r.push(t);const i=[];for(let o=0;o<r.length;o+=2){if(this.Dn(r[o],r[o+1]))return[];const c=[r[o].indexId,this.uid,r[o].arrayValue,r[o].directionalValue,Hi,[]],l=[r[o+1].indexId,this.uid,r[o+1].arrayValue,r[o+1].directionalValue,Hi,[]];i.push(IDBKeyRange.bound(c,l))}return i}Dn(e,t){return Yt(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(wd)}getMinOffset(e,t){return A.mapArray(this.cn(t),s=>this.ln(e,s).next(r=>r||q())).next(wd)}}function Id(n){return Le(n,"collectionParents")}function ds(n){return Le(n,"indexEntries")}function Er(n){return Le(n,"indexConfiguration")}function fs(n){return Le(n,"indexState")}function wd(n){W(n.length!==0);let e=n[0].indexState.offset,t=e.largestBatchId;for(let s=1;s<n.length;s++){const r=n[s].indexState.offset;ul(r,e)<0&&(e=r),t<r.largestBatchId&&(t=r.largestBatchId)}return new ht(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ed={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class nt{constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}static withCacheSize(e){return new nt(e,nt.DEFAULT_COLLECTION_PERCENTILE,nt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vm(n,e,t){const s=n.store("mutations"),r=n.store("documentMutations"),i=[],o=IDBKeyRange.only(t.batchId);let c=0;const l=s.J({range:o},(f,p,y)=>(c++,y.delete()));i.push(l.next(()=>{W(c===1)}));const u=[];for(const f of t.mutations){const p=Ep(e,f.key.path,t.batchId);i.push(r.delete(p)),u.push(f.key)}return A.waitFor(i).next(()=>u)}function Vo(n){if(!n)return 0;let e;if(n.document)e=n.document;else if(n.unknownDocument)e=n.unknownDocument;else{if(!n.noDocument)throw q();e=n.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */nt.DEFAULT_COLLECTION_PERCENTILE=10,nt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,nt.DEFAULT=new nt(41943040,nt.DEFAULT_COLLECTION_PERCENTILE,nt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),nt.DISABLED=new nt(-1,0,0);class oa{constructor(e,t,s,r){this.userId=e,this.serializer=t,this.indexManager=s,this.referenceDelegate=r,this.Cn={}}static lt(e,t,s,r){W(e.uid!=="");const i=e.isAuthenticated()?e.uid:"";return new oa(i,t,s,r)}checkEmpty(e){let t=!0;const s=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Xt(e).J({index:"userMutationsIndex",range:s},(r,i,o)=>{t=!1,o.done()}).next(()=>t)}addMutationBatch(e,t,s,r){const i=Is(e),o=Xt(e);return o.add({}).next(c=>{W(typeof c=="number");const l=new _l(c,t,s,r),u=function(S,k,V){const R=V.baseMutations.map(z=>ko(S.ct,z)),B=V.mutations.map(z=>ko(S.ct,z));return{userId:k,batchId:V.batchId,localWriteTimeMs:V.localWriteTime.toMillis(),baseMutations:R,mutations:B}}(this.serializer,this.userId,l),f=[];let p=new he((y,S)=>X(y.canonicalString(),S.canonicalString()));for(const y of r){const S=Ep(this.userId,y.key.path,c);p=p.add(y.key.path.popLast()),f.push(o.put(u)),f.push(i.put(S,Mw))}return p.forEach(y=>{f.push(this.indexManager.addToCollectionParentIndex(e,y))}),e.addOnCommittedListener(()=>{this.Cn[c]=l.keys()}),A.waitFor(f).next(()=>l)})}lookupMutationBatch(e,t){return Xt(e).get(t).next(s=>s?(W(s.userId===this.userId),Ln(this.serializer,s)):null)}vn(e,t){return this.Cn[t]?A.resolve(this.Cn[t]):this.lookupMutationBatch(e,t).next(s=>{if(s){const r=s.keys();return this.Cn[t]=r,r}return null})}getNextMutationBatchAfterBatchId(e,t){const s=t+1,r=IDBKeyRange.lowerBound([this.userId,s]);let i=null;return Xt(e).J({index:"userMutationsIndex",range:r},(o,c,l)=>{c.userId===this.userId&&(W(c.batchId>=s),i=Ln(this.serializer,c)),l.done()}).next(()=>i)}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let s=-1;return Xt(e).J({index:"userMutationsIndex",range:t,reverse:!0},(r,i,o)=>{s=i.batchId,o.done()}).next(()=>s)}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return Xt(e).U("userMutationsIndex",t).next(s=>s.map(r=>Ln(this.serializer,r)))}getAllMutationBatchesAffectingDocumentKey(e,t){const s=oo(this.userId,t.path),r=IDBKeyRange.lowerBound(s),i=[];return Is(e).J({range:r},(o,c,l)=>{const[u,f,p]=o,y=Tt(f);if(u===this.userId&&t.path.isEqual(y))return Xt(e).get(p).next(S=>{if(!S)throw q();W(S.userId===this.userId),i.push(Ln(this.serializer,S))});l.done()}).next(()=>i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new he(X);const r=[];return t.forEach(i=>{const o=oo(this.userId,i.path),c=IDBKeyRange.lowerBound(o),l=Is(e).J({range:c},(u,f,p)=>{const[y,S,k]=u,V=Tt(S);y===this.userId&&i.path.isEqual(V)?s=s.add(k):p.done()});r.push(l)}),A.waitFor(r).next(()=>this.Fn(e,s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,r=s.length+1,i=oo(this.userId,s),o=IDBKeyRange.lowerBound(i);let c=new he(X);return Is(e).J({range:o},(l,u,f)=>{const[p,y,S]=l,k=Tt(y);p===this.userId&&s.isPrefixOf(k)?k.length===r&&(c=c.add(S)):f.done()}).next(()=>this.Fn(e,c))}Fn(e,t){const s=[],r=[];return t.forEach(i=>{r.push(Xt(e).get(i).next(o=>{if(o===null)throw q();W(o.userId===this.userId),s.push(Ln(this.serializer,o))}))}),A.waitFor(r).next(()=>s)}removeMutationBatch(e,t){return vm(e._e,this.userId,t).next(s=>(e.addOnCommittedListener(()=>{this.Mn(t.batchId)}),A.forEach(s,r=>this.referenceDelegate.markPotentiallyOrphaned(e,r))))}Mn(e){delete this.Cn[e]}performConsistencyCheck(e){return this.checkEmpty(e).next(t=>{if(!t)return A.resolve();const s=IDBKeyRange.lowerBound(function(o){return[o]}(this.userId)),r=[];return Is(e).J({range:s},(i,o,c)=>{if(i[0]===this.userId){const l=Tt(i[1]);r.push(l)}else c.done()}).next(()=>{W(r.length===0)})})}containsKey(e,t){return Im(e,this.userId,t)}xn(e){return wm(e).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:-1,lastStreamToken:""})}}function Im(n,e,t){const s=oo(e,t.path),r=s[1],i=IDBKeyRange.lowerBound(s);let o=!1;return Is(n).J({range:i,H:!0},(c,l,u)=>{const[f,p,y]=c;f===e&&p===r&&(o=!0),u.done()}).next(()=>o)}function Xt(n){return Le(n,"mutations")}function Is(n){return Le(n,"documentMutations")}function wm(n){return Le(n,"mutationQueues")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ts{constructor(e){this.On=e}next(){return this.On+=2,this.On}static Nn(){return new ts(0)}static Ln(){return new ts(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eb{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.Bn(e).next(t=>{const s=new ts(t.highestTargetId);return t.highestTargetId=s.next(),this.kn(e,t).next(()=>t.highestTargetId)})}getLastRemoteSnapshotVersion(e){return this.Bn(e).next(t=>H.fromTimestamp(new ve(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(e){return this.Bn(e).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(e,t,s){return this.Bn(e).next(r=>(r.highestListenSequenceNumber=t,s&&(r.lastRemoteSnapshotVersion=s.toTimestamp()),t>r.highestListenSequenceNumber&&(r.highestListenSequenceNumber=t),this.kn(e,r)))}addTargetData(e,t){return this.qn(e,t).next(()=>this.Bn(e).next(s=>(s.targetCount+=1,this.Qn(t,s),this.kn(e,s))))}updateTargetData(e,t){return this.qn(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next(()=>ps(e).delete(t.targetId)).next(()=>this.Bn(e)).next(s=>(W(s.targetCount>0),s.targetCount-=1,this.kn(e,s)))}removeTargets(e,t,s){let r=0;const i=[];return ps(e).J((o,c)=>{const l=Vr(c);l.sequenceNumber<=t&&s.get(l.targetId)===null&&(r++,i.push(this.removeTargetData(e,l)))}).next(()=>A.waitFor(i)).next(()=>r)}forEachTarget(e,t){return ps(e).J((s,r)=>{const i=Vr(r);t(i)})}Bn(e){return bd(e).get("targetGlobalKey").next(t=>(W(t!==null),t))}kn(e,t){return bd(e).put("targetGlobalKey",t)}qn(e,t){return ps(e).put(mm(this.serializer,t))}Qn(e,t){let s=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,s=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,s=!0),s}getTargetCount(e){return this.Bn(e).next(t=>t.targetCount)}getTargetData(e,t){const s=Xn(t),r=IDBKeyRange.bound([s,Number.NEGATIVE_INFINITY],[s,Number.POSITIVE_INFINITY]);let i=null;return ps(e).J({range:r,index:"queryTargetsIndex"},(o,c,l)=>{const u=Vr(c);gi(t,u.target)&&(i=u,l.done())}).next(()=>i)}addMatchingKeys(e,t,s){const r=[],i=rn(e);return t.forEach(o=>{const c=Xe(o.path);r.push(i.put({targetId:s,path:c})),r.push(this.referenceDelegate.addReference(e,s,o))}),A.waitFor(r)}removeMatchingKeys(e,t,s){const r=rn(e);return A.forEach(t,i=>{const o=Xe(i.path);return A.waitFor([r.delete([s,o]),this.referenceDelegate.removeReference(e,s,i)])})}removeMatchingKeysForTargetId(e,t){const s=rn(e),r=IDBKeyRange.bound([t],[t+1],!1,!0);return s.delete(r)}getMatchingKeysForTargetId(e,t){const s=IDBKeyRange.bound([t],[t+1],!1,!0),r=rn(e);let i=te();return r.J({range:s,H:!0},(o,c,l)=>{const u=Tt(o[1]),f=new $(u);i=i.add(f)}).next(()=>i)}containsKey(e,t){const s=Xe(t.path),r=IDBKeyRange.bound([s],[mp(s)],!1,!0);let i=0;return rn(e).J({index:"documentTargetsIndex",H:!0,range:r},([o,c],l,u)=>{o!==0&&(i++,u.done())}).next(()=>i>0)}ot(e,t){return ps(e).get(t).next(s=>s?Vr(s):null)}}function ps(n){return Le(n,"targets")}function bd(n){return Le(n,"targetGlobal")}function rn(n){return Le(n,"targetDocuments")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Td([n,e],[t,s]){const r=X(n,t);return r===0?X(e,s):r}class tb{constructor(e){this.Kn=e,this.buffer=new he(Td),this.$n=0}Un(){return++this.$n}Wn(e){const t=[e,this.Un()];if(this.buffer.size<this.Kn)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();Td(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class nb{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.Gn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.zn(6e4)}stop(){this.Gn&&(this.Gn.cancel(),this.Gn=null)}get started(){return this.Gn!==null}zn(e){D("LruGarbageCollector",`Garbage collection scheduled in ${e}ms`),this.Gn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Gn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){An(t)?D("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",t):await Tn(t)}await this.zn(3e5)})}}class sb{constructor(e,t){this.jn=e,this.params=t}calculateTargetCount(e,t){return this.jn.Hn(e).next(s=>Math.floor(t/100*s))}nthSequenceNumber(e,t){if(t===0)return A.resolve(st.oe);const s=new tb(t);return this.jn.forEachTarget(e,r=>s.Wn(r.sequenceNumber)).next(()=>this.jn.Jn(e,r=>s.Wn(r))).next(()=>s.maxValue)}removeTargets(e,t,s){return this.jn.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.jn.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(D("LruGarbageCollector","Garbage collection skipped; disabled"),A.resolve(Ed)):this.getCacheSize(e).next(s=>s<this.params.cacheSizeCollectionThreshold?(D("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Ed):this.Yn(e,t))}getCacheSize(e){return this.jn.getCacheSize(e)}Yn(e,t){let s,r,i,o,c,l,u;const f=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(p=>(p>this.params.maximumSequenceNumbersToCollect?(D("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${p}`),r=this.params.maximumSequenceNumbersToCollect):r=p,o=Date.now(),this.nthSequenceNumber(e,r))).next(p=>(s=p,c=Date.now(),this.removeTargets(e,s,t))).next(p=>(i=p,l=Date.now(),this.removeOrphanedDocuments(e,s))).next(p=>(u=Date.now(),gs()<=ne.DEBUG&&D("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-f}ms
	Determined least recently used ${r} in `+(c-o)+`ms
	Removed ${i} targets in `+(l-c)+`ms
	Removed ${p} documents in `+(u-l)+`ms
Total Duration: ${u-f}ms`),A.resolve({didRun:!0,sequenceNumbersCollected:r,targetsRemoved:i,documentsRemoved:p})))}}function rb(n,e){return new sb(n,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ib{constructor(e,t){this.db=e,this.garbageCollector=rb(this,t)}Hn(e){const t=this.Zn(e);return this.db.getTargetCache().getTargetCount(e).next(s=>t.next(r=>s+r))}Zn(e){let t=0;return this.Jn(e,s=>{t++}).next(()=>t)}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}Jn(e,t){return this.Xn(e,(s,r)=>t(r))}addReference(e,t,s){return Qi(e,s)}removeReference(e,t,s){return Qi(e,s)}removeTargets(e,t,s){return this.db.getTargetCache().removeTargets(e,t,s)}markPotentiallyOrphaned(e,t){return Qi(e,t)}er(e,t){return function(r,i){let o=!1;return wm(r).Y(c=>Im(r,c,i).next(l=>(l&&(o=!0),A.resolve(!l)))).next(()=>o)}(e,t)}removeOrphanedDocuments(e,t){const s=this.db.getRemoteDocumentCache().newChangeBuffer(),r=[];let i=0;return this.Xn(e,(o,c)=>{if(c<=t){const l=this.er(e,o).next(u=>{if(!u)return i++,s.getEntry(e,o).next(()=>(s.removeEntry(o,H.min()),rn(e).delete(function(p){return[0,Xe(p.path)]}(o))))});r.push(l)}}).next(()=>A.waitFor(r)).next(()=>s.apply(e)).next(()=>i)}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,s)}updateLimboDocument(e,t){return Qi(e,t)}Xn(e,t){const s=rn(e);let r,i=st.oe;return s.J({index:"documentTargetsIndex"},([o,c],{path:l,sequenceNumber:u})=>{o===0?(i!==st.oe&&t(new $(Tt(r)),i),i=u,r=l):i=st.oe}).next(()=>{i!==st.oe&&t(new $(Tt(r)),i)})}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function Qi(n,e){return rn(n).put(function(s,r){return{targetId:0,path:Xe(s.path),sequenceNumber:r}}(e,n.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Em{constructor(){this.changes=new Sn(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,be.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?A.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ob{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,s){return Vn(e).put(s)}removeEntry(e,t,s){return Vn(e).delete(function(i,o){const c=i.path.toArray();return[c.slice(0,c.length-2),c[c.length-2],Co(o),c[c.length-1]]}(t,s))}updateMetadata(e,t){return this.getMetadata(e).next(s=>(s.byteSize+=t,this.tr(e,s)))}getEntry(e,t){let s=be.newInvalidDocument(t);return Vn(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(br(t))},(r,i)=>{s=this.nr(t,i)}).next(()=>s)}rr(e,t){let s={size:0,document:be.newInvalidDocument(t)};return Vn(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(br(t))},(r,i)=>{s={document:this.nr(t,i),size:Vo(i)}}).next(()=>s)}getEntries(e,t){let s=at();return this.ir(e,t,(r,i)=>{const o=this.nr(r,i);s=s.insert(r,o)}).next(()=>s)}sr(e,t){let s=at(),r=new pe($.comparator);return this.ir(e,t,(i,o)=>{const c=this.nr(i,o);s=s.insert(i,c),r=r.insert(i,Vo(o))}).next(()=>({documents:s,_r:r}))}ir(e,t,s){if(t.isEmpty())return A.resolve();let r=new he(Rd);t.forEach(l=>r=r.add(l));const i=IDBKeyRange.bound(br(r.first()),br(r.last())),o=r.getIterator();let c=o.getNext();return Vn(e).J({index:"documentKeyIndex",range:i},(l,u,f)=>{const p=$.fromSegments([...u.prefixPath,u.collectionGroup,u.documentId]);for(;c&&Rd(c,p)<0;)s(c,null),c=o.getNext();c&&c.isEqual(p)&&(s(c,u),c=o.hasNext()?o.getNext():null),c?f.$(br(c)):f.done()}).next(()=>{for(;c;)s(c,null),c=o.hasNext()?o.getNext():null})}getDocumentsMatchingQuery(e,t,s,r,i){const o=t.path,c=[o.popLast().toArray(),o.lastSegment(),Co(s.readTime),s.documentKey.path.isEmpty()?"":s.documentKey.path.lastSegment()],l=[o.popLast().toArray(),o.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return Vn(e).U(IDBKeyRange.bound(c,l,!0)).next(u=>{i==null||i.incrementDocumentReadCount(u.length);let f=at();for(const p of u){const y=this.nr($.fromSegments(p.prefixPath.concat(p.collectionGroup,p.documentId)),p);y.isFoundDocument()&&(_i(t,y)||r.has(y.key))&&(f=f.insert(y.key,y))}return f})}getAllFromCollectionGroup(e,t,s,r){let i=at();const o=Sd(t,s),c=Sd(t,ht.max());return Vn(e).J({index:"collectionGroupIndex",range:IDBKeyRange.bound(o,c,!0)},(l,u,f)=>{const p=this.nr($.fromSegments(u.prefixPath.concat(u.collectionGroup,u.documentId)),u);i=i.insert(p.key,p),i.size===r&&f.done()}).next(()=>i)}newChangeBuffer(e){return new ab(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next(t=>t.byteSize)}getMetadata(e){return Ad(e).get("remoteDocumentGlobalKey").next(t=>(W(!!t),t))}tr(e,t){return Ad(e).put("remoteDocumentGlobalKey",t)}nr(e,t){if(t){const s=zE(this.serializer,t);if(!(s.isNoDocument()&&s.version.isEqual(H.min())))return s}return be.newInvalidDocument(e)}}function bm(n){return new ob(n)}class ab extends Em{constructor(e,t){super(),this.ar=e,this.trackRemovals=t,this.ur=new Sn(s=>s.toString(),(s,r)=>s.isEqual(r))}applyChanges(e){const t=[];let s=0,r=new he((i,o)=>X(i.canonicalString(),o.canonicalString()));return this.changes.forEach((i,o)=>{const c=this.ur.get(i);if(t.push(this.ar.removeEntry(e,i,c.readTime)),o.isValidDocument()){const l=hd(this.ar.serializer,o);r=r.add(i.path.popLast());const u=Vo(l);s+=u-c.size,t.push(this.ar.addEntry(e,i,l))}else if(s-=c.size,this.trackRemovals){const l=hd(this.ar.serializer,o.convertToNoDocument(H.min()));t.push(this.ar.addEntry(e,i,l))}}),r.forEach(i=>{t.push(this.ar.indexManager.addToCollectionParentIndex(e,i))}),t.push(this.ar.updateMetadata(e,s)),A.waitFor(t)}getFromCache(e,t){return this.ar.rr(e,t).next(s=>(this.ur.set(t,{size:s.size,readTime:s.document.readTime}),s.document))}getAllFromCache(e,t){return this.ar.sr(e,t).next(({documents:s,_r:r})=>(r.forEach((i,o)=>{this.ur.set(i,{size:o,readTime:s.get(i).readTime})}),s))}}function Ad(n){return Le(n,"remoteDocumentGlobal")}function Vn(n){return Le(n,"remoteDocumentsV14")}function br(n){const e=n.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function Sd(n,e){const t=e.documentKey.path.toArray();return[n,Co(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function Rd(n,e){const t=n.path.toArray(),s=e.path.toArray();let r=0;for(let i=0;i<t.length-2&&i<s.length-2;++i)if(r=X(t[i],s[i]),r)return r;return r=X(t.length,s.length),r||(r=X(t[t.length-2],s[s.length-2]),r||X(t[t.length-1],s[s.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cb{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tm{constructor(e,t,s,r){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=r}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next(r=>(s=r,this.remoteDocumentCache.getEntry(e,t))).next(r=>(s!==null&&Fr(s.mutation,r,rt.empty(),ve.now()),r))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.getLocalViewOfDocuments(e,s,te()).next(()=>s))}getLocalViewOfDocuments(e,t,s=te()){const r=At();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,s).next(i=>{let o=Cr();return i.forEach((c,l)=>{o=o.insert(c,l.overlayedDocument)}),o}))}getOverlayedDocuments(e,t){const s=At();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,te()))}populateOverlays(e,t,s){const r=[];return s.forEach(i=>{t.has(i)||r.push(i)}),this.documentOverlayCache.getOverlays(e,r).next(i=>{i.forEach((o,c)=>{t.set(o,c)})})}computeViews(e,t,s,r){let i=at();const o=$r(),c=function(){return $r()}();return t.forEach((l,u)=>{const f=s.get(u.key);r.has(u.key)&&(f===void 0||f.mutation instanceof Gt)?i=i.insert(u.key,u):f!==void 0?(o.set(u.key,f.mutation.getFieldMask()),Fr(f.mutation,u,f.mutation.getFieldMask(),ve.now())):o.set(u.key,rt.empty())}),this.recalculateAndSaveOverlays(e,i).next(l=>(l.forEach((u,f)=>o.set(u,f)),t.forEach((u,f)=>{var p;return c.set(u,new cb(f,(p=o.get(u))!==null&&p!==void 0?p:null))}),c))}recalculateAndSaveOverlays(e,t){const s=$r();let r=new pe((o,c)=>o-c),i=te();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(o=>{for(const c of o)c.keys().forEach(l=>{const u=t.get(l);if(u===null)return;let f=s.get(l)||rt.empty();f=c.applyToLocalView(u,f),s.set(l,f);const p=(r.get(c.batchId)||te()).add(l);r=r.insert(c.batchId,p)})}).next(()=>{const o=[],c=r.getReverseIterator();for(;c.hasNext();){const l=c.getNext(),u=l.key,f=l.value,p=Gp();f.forEach(y=>{if(!i.has(y)){const S=Yp(t.get(y),s.get(y));S!==null&&p.set(y,S),i=i.add(y)}}),o.push(this.documentOverlayCache.saveOverlays(e,u,p))}return A.waitFor(o)}).next(()=>s)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.recalculateAndSaveOverlays(e,s))}getDocumentsMatchingQuery(e,t,s,r){return function(o){return $.isDocumentKey(o.path)&&o.collectionGroup===null&&o.filters.length===0}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):dE(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,r):this.getDocumentsMatchingCollectionQuery(e,t,s,r)}getNextDocuments(e,t,s,r){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,r).next(i=>{const o=r-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,r-i.size):A.resolve(At());let c=-1,l=i;return o.next(u=>A.forEach(u,(f,p)=>(c<p.largestBatchId&&(c=p.largestBatchId),i.get(f)?A.resolve():this.remoteDocumentCache.getEntry(e,f).next(y=>{l=l.insert(f,y)}))).next(()=>this.populateOverlays(e,u,i)).next(()=>this.computeViews(e,l,u,te())).next(f=>({batchId:c,changes:jp(f)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new $(t)).next(s=>{let r=Cr();return s.isFoundDocument()&&(r=r.insert(s.key,s)),r})}getDocumentsMatchingCollectionGroupQuery(e,t,s,r){const i=t.collectionGroup;let o=Cr();return this.indexManager.getCollectionParents(e,i).next(c=>A.forEach(c,l=>{const u=function(p,y){return new Zo(y,null,p.explicitOrderBy.slice(),p.filters.slice(),p.limit,p.limitType,p.startAt,p.endAt)}(t,l.child(i));return this.getDocumentsMatchingCollectionQuery(e,u,s,r).next(f=>{f.forEach((p,y)=>{o=o.insert(p,y)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,t,s,r){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next(o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,i,r))).next(o=>{i.forEach((l,u)=>{const f=u.getKey();o.get(f)===null&&(o=o.insert(f,be.newInvalidDocument(f)))});let c=Cr();return o.forEach((l,u)=>{const f=i.get(l);f!==void 0&&Fr(f.mutation,u,rt.empty(),ve.now()),_i(t,u)&&(c=c.insert(l,u))}),c})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lb{constructor(e){this.serializer=e,this.cr=new Map,this.lr=new Map}getBundleMetadata(e,t){return A.resolve(this.cr.get(t))}saveBundleMetadata(e,t){return this.cr.set(t.id,function(r){return{id:r.id,version:r.version,createTime:Ze(r.createTime)}}(t)),A.resolve()}getNamedQuery(e,t){return A.resolve(this.lr.get(t))}saveNamedQuery(e,t){return this.lr.set(t.name,function(r){return{name:r.name,query:gm(r.bundledQuery),readTime:Ze(r.readTime)}}(t)),A.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ub{constructor(){this.overlays=new pe($.comparator),this.hr=new Map}getOverlay(e,t){return A.resolve(this.overlays.get(t))}getOverlays(e,t){const s=At();return A.forEach(t,r=>this.getOverlay(e,r).next(i=>{i!==null&&s.set(r,i)})).next(()=>s)}saveOverlays(e,t,s){return s.forEach((r,i)=>{this.ht(e,t,i)}),A.resolve()}removeOverlaysForBatchId(e,t,s){const r=this.hr.get(s);return r!==void 0&&(r.forEach(i=>this.overlays=this.overlays.remove(i)),this.hr.delete(s)),A.resolve()}getOverlaysForCollection(e,t,s){const r=At(),i=t.length+1,o=new $(t.child("")),c=this.overlays.getIteratorFrom(o);for(;c.hasNext();){const l=c.getNext().value,u=l.getKey();if(!t.isPrefixOf(u.path))break;u.path.length===i&&l.largestBatchId>s&&r.set(l.getKey(),l)}return A.resolve(r)}getOverlaysForCollectionGroup(e,t,s,r){let i=new pe((u,f)=>u-f);const o=this.overlays.getIterator();for(;o.hasNext();){const u=o.getNext().value;if(u.getKey().getCollectionGroup()===t&&u.largestBatchId>s){let f=i.get(u.largestBatchId);f===null&&(f=At(),i=i.insert(u.largestBatchId,f)),f.set(u.getKey(),u)}}const c=At(),l=i.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((u,f)=>c.set(u,f)),!(c.size()>=r)););return A.resolve(c)}ht(e,t,s){const r=this.overlays.get(s.key);if(r!==null){const o=this.hr.get(r.largestBatchId).delete(s.key);this.hr.set(r.largestBatchId,o)}this.overlays=this.overlays.insert(s.key,new vl(t,s));let i=this.hr.get(t);i===void 0&&(i=te(),this.hr.set(t,i)),this.hr.set(t,i.add(s.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tl{constructor(){this.Pr=new he(Ne.Ir),this.Tr=new he(Ne.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(e,t){const s=new Ne(e,t);this.Pr=this.Pr.add(s),this.Tr=this.Tr.add(s)}dr(e,t){e.forEach(s=>this.addReference(s,t))}removeReference(e,t){this.Ar(new Ne(e,t))}Rr(e,t){e.forEach(s=>this.removeReference(s,t))}Vr(e){const t=new $(new le([])),s=new Ne(t,e),r=new Ne(t,e+1),i=[];return this.Tr.forEachInRange([s,r],o=>{this.Ar(o),i.push(o.key)}),i}mr(){this.Pr.forEach(e=>this.Ar(e))}Ar(e){this.Pr=this.Pr.delete(e),this.Tr=this.Tr.delete(e)}gr(e){const t=new $(new le([])),s=new Ne(t,e),r=new Ne(t,e+1);let i=te();return this.Tr.forEachInRange([s,r],o=>{i=i.add(o.key)}),i}containsKey(e){const t=new Ne(e,0),s=this.Pr.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class Ne{constructor(e,t){this.key=e,this.pr=t}static Ir(e,t){return $.comparator(e.key,t.key)||X(e.pr,t.pr)}static Er(e,t){return X(e.pr,t.pr)||$.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hb{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.yr=1,this.wr=new he(Ne.Ir)}checkEmpty(e){return A.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,r){const i=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new _l(i,t,s,r);this.mutationQueue.push(o);for(const c of r)this.wr=this.wr.add(new Ne(c.key,i)),this.indexManager.addToCollectionParentIndex(e,c.key.path.popLast());return A.resolve(o)}lookupMutationBatch(e,t){return A.resolve(this.Sr(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,r=this.br(s),i=r<0?0:r;return A.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return A.resolve(this.mutationQueue.length===0?-1:this.yr-1)}getAllMutationBatches(e){return A.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new Ne(t,0),r=new Ne(t,Number.POSITIVE_INFINITY),i=[];return this.wr.forEachInRange([s,r],o=>{const c=this.Sr(o.pr);i.push(c)}),A.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new he(X);return t.forEach(r=>{const i=new Ne(r,0),o=new Ne(r,Number.POSITIVE_INFINITY);this.wr.forEachInRange([i,o],c=>{s=s.add(c.pr)})}),A.resolve(this.Dr(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,r=s.length+1;let i=s;$.isDocumentKey(i)||(i=i.child(""));const o=new Ne(new $(i),0);let c=new he(X);return this.wr.forEachWhile(l=>{const u=l.key.path;return!!s.isPrefixOf(u)&&(u.length===r&&(c=c.add(l.pr)),!0)},o),A.resolve(this.Dr(c))}Dr(e){const t=[];return e.forEach(s=>{const r=this.Sr(s);r!==null&&t.push(r)}),t}removeMutationBatch(e,t){W(this.Cr(t.batchId,"removed")===0),this.mutationQueue.shift();let s=this.wr;return A.forEach(t.mutations,r=>{const i=new Ne(r.key,t.batchId);return s=s.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,r.key)}).next(()=>{this.wr=s})}Mn(e){}containsKey(e,t){const s=new Ne(t,0),r=this.wr.firstAfterOrEqual(s);return A.resolve(t.isEqual(r&&r.key))}performConsistencyCheck(e){return this.mutationQueue.length,A.resolve()}Cr(e,t){return this.br(e)}br(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Sr(e){const t=this.br(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class db{constructor(e){this.vr=e,this.docs=function(){return new pe($.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,r=this.docs.get(s),i=r?r.size:0,o=this.vr(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return A.resolve(s?s.document.mutableCopy():be.newInvalidDocument(t))}getEntries(e,t){let s=at();return t.forEach(r=>{const i=this.docs.get(r);s=s.insert(r,i?i.document.mutableCopy():be.newInvalidDocument(r))}),A.resolve(s)}getDocumentsMatchingQuery(e,t,s,r){let i=at();const o=t.path,c=new $(o.child("")),l=this.docs.getIteratorFrom(c);for(;l.hasNext();){const{key:u,value:{document:f}}=l.getNext();if(!o.isPrefixOf(u.path))break;u.path.length>o.length+1||ul(_p(f),s)<=0||(r.has(f.key)||_i(t,f))&&(i=i.insert(f.key,f.mutableCopy()))}return A.resolve(i)}getAllFromCollectionGroup(e,t,s,r){q()}Fr(e,t){return A.forEach(this.docs,s=>t(s))}newChangeBuffer(e){return new fb(this)}getSize(e){return A.resolve(this.size)}}class fb extends Em{constructor(e){super(),this.ar=e}applyChanges(e){const t=[];return this.changes.forEach((s,r)=>{r.isValidDocument()?t.push(this.ar.addEntry(e,r)):this.ar.removeEntry(s)}),A.waitFor(t)}getFromCache(e,t){return this.ar.getEntry(e,t)}getAllFromCache(e,t){return this.ar.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pb{constructor(e){this.persistence=e,this.Mr=new Sn(t=>Xn(t),gi),this.lastRemoteSnapshotVersion=H.min(),this.highestTargetId=0,this.Or=0,this.Nr=new Tl,this.targetCount=0,this.Lr=ts.Nn()}forEachTarget(e,t){return this.Mr.forEach((s,r)=>t(r)),A.resolve()}getLastRemoteSnapshotVersion(e){return A.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return A.resolve(this.Or)}allocateTargetId(e){return this.highestTargetId=this.Lr.next(),A.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.Or&&(this.Or=t),A.resolve()}qn(e){this.Mr.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Lr=new ts(t),this.highestTargetId=t),e.sequenceNumber>this.Or&&(this.Or=e.sequenceNumber)}addTargetData(e,t){return this.qn(t),this.targetCount+=1,A.resolve()}updateTargetData(e,t){return this.qn(t),A.resolve()}removeTargetData(e,t){return this.Mr.delete(t.target),this.Nr.Vr(t.targetId),this.targetCount-=1,A.resolve()}removeTargets(e,t,s){let r=0;const i=[];return this.Mr.forEach((o,c)=>{c.sequenceNumber<=t&&s.get(c.targetId)===null&&(this.Mr.delete(o),i.push(this.removeMatchingKeysForTargetId(e,c.targetId)),r++)}),A.waitFor(i).next(()=>r)}getTargetCount(e){return A.resolve(this.targetCount)}getTargetData(e,t){const s=this.Mr.get(t)||null;return A.resolve(s)}addMatchingKeys(e,t,s){return this.Nr.dr(t,s),A.resolve()}removeMatchingKeys(e,t,s){this.Nr.Rr(t,s);const r=this.persistence.referenceDelegate,i=[];return r&&t.forEach(o=>{i.push(r.markPotentiallyOrphaned(e,o))}),A.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.Nr.Vr(t),A.resolve()}getMatchingKeysForTargetId(e,t){const s=this.Nr.gr(t);return A.resolve(s)}containsKey(e,t){return A.resolve(this.Nr.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Am{constructor(e,t){this.Br={},this.overlays={},this.kr=new st(0),this.qr=!1,this.qr=!0,this.referenceDelegate=e(this),this.Qr=new pb(this),this.indexManager=new XE,this.remoteDocumentCache=function(r){return new db(r)}(s=>this.referenceDelegate.Kr(s)),this.serializer=new pm(t),this.$r=new lb(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new ub,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this.Br[e.toKey()];return s||(s=new hb(t,this.referenceDelegate),this.Br[e.toKey()]=s),s}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(e,t,s){D("MemoryPersistence","Starting transaction:",e);const r=new mb(this.kr.next());return this.referenceDelegate.Ur(),s(r).next(i=>this.referenceDelegate.Wr(r).next(()=>i)).toPromise().then(i=>(r.raiseOnCommittedEvent(),i))}Gr(e,t){return A.or(Object.values(this.Br).map(s=>()=>s.containsKey(e,t)))}}class mb extends vp{constructor(e){super(),this.currentSequenceNumber=e}}class aa{constructor(e){this.persistence=e,this.zr=new Tl,this.jr=null}static Hr(e){return new aa(e)}get Jr(){if(this.jr)return this.jr;throw q()}addReference(e,t,s){return this.zr.addReference(s,t),this.Jr.delete(s.toString()),A.resolve()}removeReference(e,t,s){return this.zr.removeReference(s,t),this.Jr.add(s.toString()),A.resolve()}markPotentiallyOrphaned(e,t){return this.Jr.add(t.toString()),A.resolve()}removeTarget(e,t){this.zr.Vr(t.targetId).forEach(r=>this.Jr.add(r.toString()));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next(r=>{r.forEach(i=>this.Jr.add(i.toString()))}).next(()=>s.removeTargetData(e,t))}Ur(){this.jr=new Set}Wr(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return A.forEach(this.Jr,s=>{const r=$.fromPath(s);return this.Yr(e,r).next(i=>{i||t.removeEntry(r,H.min())})}).next(()=>(this.jr=null,t.apply(e)))}updateLimboDocument(e,t){return this.Yr(e,t).next(s=>{s?this.Jr.delete(t.toString()):this.Jr.add(t.toString())})}Kr(e){return 0}Yr(e,t){return A.or([()=>A.resolve(this.zr.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gr(e,t)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gb{constructor(e){this.serializer=e}O(e,t,s,r){const i=new Yo("createOrUpgrade",t);s<1&&r>=1&&(function(l){l.createObjectStore("owner")}(e),function(l){l.createObjectStore("mutationQueues",{keyPath:"userId"}),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",qh,{unique:!0}),l.createObjectStore("documentMutations")}(e),Pd(e),function(l){l.createObjectStore("remoteDocuments")}(e));let o=A.resolve();return s<3&&r>=3&&(s!==0&&(function(l){l.deleteObjectStore("targetDocuments"),l.deleteObjectStore("targets"),l.deleteObjectStore("targetGlobal")}(e),Pd(e)),o=o.next(()=>function(l){const u=l.store("targetGlobal"),f={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:H.min().toTimestamp(),targetCount:0};return u.put("targetGlobalKey",f)}(i))),s<4&&r>=4&&(s!==0&&(o=o.next(()=>function(l,u){return u.store("mutations").U().next(f=>{l.deleteObjectStore("mutations"),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",qh,{unique:!0});const p=u.store("mutations"),y=f.map(S=>p.put(S));return A.waitFor(y)})}(e,i))),o=o.next(()=>{(function(l){l.createObjectStore("clientMetadata",{keyPath:"clientId"})})(e)})),s<5&&r>=5&&(o=o.next(()=>this.Xr(i))),s<6&&r>=6&&(o=o.next(()=>(function(l){l.createObjectStore("remoteDocumentGlobal")}(e),this.ei(i)))),s<7&&r>=7&&(o=o.next(()=>this.ti(i))),s<8&&r>=8&&(o=o.next(()=>this.ni(e,i))),s<9&&r>=9&&(o=o.next(()=>{(function(l){l.objectStoreNames.contains("remoteDocumentChanges")&&l.deleteObjectStore("remoteDocumentChanges")})(e)})),s<10&&r>=10&&(o=o.next(()=>this.ri(i))),s<11&&r>=11&&(o=o.next(()=>{(function(l){l.createObjectStore("bundles",{keyPath:"bundleId"})})(e),function(l){l.createObjectStore("namedQueries",{keyPath:"name"})}(e)})),s<12&&r>=12&&(o=o.next(()=>{(function(l){const u=l.createObjectStore("documentOverlays",{keyPath:Qw});u.createIndex("collectionPathOverlayIndex",Jw,{unique:!1}),u.createIndex("collectionGroupOverlayIndex",Yw,{unique:!1})})(e)})),s<13&&r>=13&&(o=o.next(()=>function(l){const u=l.createObjectStore("remoteDocumentsV14",{keyPath:$w});u.createIndex("documentKeyIndex",Fw),u.createIndex("collectionGroupIndex",Uw)}(e)).next(()=>this.ii(e,i)).next(()=>e.deleteObjectStore("remoteDocuments"))),s<14&&r>=14&&(o=o.next(()=>this.si(e,i))),s<15&&r>=15&&(o=o.next(()=>function(l){l.createObjectStore("indexConfiguration",{keyPath:"indexId",autoIncrement:!0}).createIndex("collectionGroupIndex","collectionGroup",{unique:!1}),l.createObjectStore("indexState",{keyPath:zw}).createIndex("sequenceNumberIndex",Kw,{unique:!1}),l.createObjectStore("indexEntries",{keyPath:Ww}).createIndex("documentKeyIndex",Hw,{unique:!1})}(e))),s<16&&r>=16&&(o=o.next(()=>{t.objectStore("indexState").clear()}).next(()=>{t.objectStore("indexEntries").clear()})),o}ei(e){let t=0;return e.store("remoteDocuments").J((s,r)=>{t+=Vo(r)}).next(()=>{const s={byteSize:t};return e.store("remoteDocumentGlobal").put("remoteDocumentGlobalKey",s)})}Xr(e){const t=e.store("mutationQueues"),s=e.store("mutations");return t.U().next(r=>A.forEach(r,i=>{const o=IDBKeyRange.bound([i.userId,-1],[i.userId,i.lastAcknowledgedBatchId]);return s.U("userMutationsIndex",o).next(c=>A.forEach(c,l=>{W(l.userId===i.userId);const u=Ln(this.serializer,l);return vm(e,i.userId,u).next(()=>{})}))}))}ti(e){const t=e.store("targetDocuments"),s=e.store("remoteDocuments");return e.store("targetGlobal").get("targetGlobalKey").next(r=>{const i=[];return s.J((o,c)=>{const l=new le(o),u=function(p){return[0,Xe(p)]}(l);i.push(t.get(u).next(f=>f?A.resolve():(p=>t.put({targetId:0,path:Xe(p),sequenceNumber:r.highestListenSequenceNumber}))(l)))}).next(()=>A.waitFor(i))})}ni(e,t){e.createObjectStore("collectionParents",{keyPath:Gw});const s=t.store("collectionParents"),r=new bl,i=o=>{if(r.add(o)){const c=o.lastSegment(),l=o.popLast();return s.put({collectionId:c,parent:Xe(l)})}};return t.store("remoteDocuments").J({H:!0},(o,c)=>{const l=new le(o);return i(l.popLast())}).next(()=>t.store("documentMutations").J({H:!0},([o,c,l],u)=>{const f=Tt(c);return i(f.popLast())}))}ri(e){const t=e.store("targets");return t.J((s,r)=>{const i=Vr(r),o=mm(this.serializer,i);return t.put(o)})}ii(e,t){const s=t.store("remoteDocuments"),r=[];return s.J((i,o)=>{const c=t.store("remoteDocumentsV14"),l=function(p){return p.document?new $(le.fromString(p.document.name).popFirst(5)):p.noDocument?$.fromSegments(p.noDocument.path):p.unknownDocument?$.fromSegments(p.unknownDocument.path):q()}(o).path.toArray(),u={prefixPath:l.slice(0,l.length-2),collectionGroup:l[l.length-2],documentId:l[l.length-1],readTime:o.readTime||[0,0],unknownDocument:o.unknownDocument,noDocument:o.noDocument,document:o.document,hasCommittedMutations:!!o.hasCommittedMutations};r.push(c.put(u))}).next(()=>A.waitFor(r))}si(e,t){const s=t.store("mutations"),r=bm(this.serializer),i=new Am(aa.Hr,this.serializer.ct);return s.U().next(o=>{const c=new Map;return o.forEach(l=>{var u;let f=(u=c.get(l.userId))!==null&&u!==void 0?u:te();Ln(this.serializer,l).keys().forEach(p=>f=f.add(p)),c.set(l.userId,f)}),A.forEach(c,(l,u)=>{const f=new Ke(u),p=ia.lt(this.serializer,f),y=i.getIndexManager(f),S=oa.lt(f,this.serializer,y,i.referenceDelegate);return new Tm(r,S,p,y).recalculateAndSaveOverlaysForDocumentKeys(new Ic(t,st.oe),l).next()})})}}function Pd(n){n.createObjectStore("targetDocuments",{keyPath:qw}).createIndex("documentTargetsIndex",jw,{unique:!0}),n.createObjectStore("targets",{keyPath:"targetId"}).createIndex("queryTargetsIndex",Bw,{unique:!0}),n.createObjectStore("targetGlobal")}const ec="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class Al{constructor(e,t,s,r,i,o,c,l,u,f,p=16){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=s,this.oi=i,this.window=o,this.document=c,this._i=u,this.ai=f,this.ui=p,this.kr=null,this.qr=!1,this.isPrimary=!1,this.networkEnabled=!0,this.ci=null,this.inForeground=!1,this.li=null,this.hi=null,this.Pi=Number.NEGATIVE_INFINITY,this.Ii=y=>Promise.resolve(),!Al.D())throw new F(C.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new ib(this,r),this.Ti=t+"main",this.serializer=new pm(l),this.Ei=new dn(this.Ti,this.ui,new gb(this.serializer)),this.Qr=new eb(this.referenceDelegate,this.serializer),this.remoteDocumentCache=bm(this.serializer),this.$r=new KE,this.window&&this.window.localStorage?this.di=this.window.localStorage:(this.di=null,f===!1&&Te("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ai().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new F(C.FAILED_PRECONDITION,ec);return this.Ri(),this.Vi(),this.mi(),this.runTransaction("getHighestListenSequenceNumber","readonly",e=>this.Qr.getHighestSequenceNumber(e))}).then(e=>{this.kr=new st(e,this._i)}).then(()=>{this.qr=!0}).catch(e=>(this.Ei&&this.Ei.close(),Promise.reject(e)))}fi(e){return this.Ii=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.Ei.L(async t=>{t.newVersion===null&&await e()})}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.oi.enqueueAndForget(async()=>{this.started&&await this.Ai()}))}Ai(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",e=>Ji(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.gi(e).next(t=>{t||(this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)))})}).next(()=>this.pi(e)).next(t=>this.isPrimary&&!t?this.yi(e).next(()=>!1):!!t&&this.wi(e).next(()=>!0))).catch(e=>{if(An(e))return D("IndexedDbPersistence","Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return D("IndexedDbPersistence","Releasing owner lease after error during lease refresh",e),!1}).then(e=>{this.isPrimary!==e&&this.oi.enqueueRetryable(()=>this.Ii(e)),this.isPrimary=e})}gi(e){return Tr(e).get("owner").next(t=>A.resolve(this.Si(t)))}bi(e){return Ji(e).delete(this.clientId)}async Di(){if(this.isPrimary&&!this.Ci(this.Pi,18e5)){this.Pi=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const s=Le(t,"clientMetadata");return s.U().next(r=>{const i=this.vi(r,18e5),o=r.filter(c=>i.indexOf(c)===-1);return A.forEach(o,c=>s.delete(c.clientId)).next(()=>o)})}).catch(()=>[]);if(this.di)for(const t of e)this.di.removeItem(this.Fi(t.clientId))}}mi(){this.hi=this.oi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Ai().then(()=>this.Di()).then(()=>this.mi()))}Si(e){return!!e&&e.ownerId===this.clientId}pi(e){return this.ai?A.resolve(!0):Tr(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)){if(this.Si(t)&&this.networkEnabled)return!0;if(!this.Si(t)){if(!t.allowTabSynchronization)throw new F(C.FAILED_PRECONDITION,ec);return!1}}return!(!this.networkEnabled||!this.inForeground)||Ji(e).U().next(s=>this.vi(s,5e3).find(r=>{if(this.clientId!==r.clientId){const i=!this.networkEnabled&&r.networkEnabled,o=!this.inForeground&&r.inForeground,c=this.networkEnabled===r.networkEnabled;if(i||o&&c)return!0}return!1})===void 0)}).next(t=>(this.isPrimary!==t&&D("IndexedDbPersistence",`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.qr=!1,this.xi(),this.hi&&(this.hi.cancel(),this.hi=null),this.Oi(),this.Ni(),await this.Ei.runTransaction("shutdown","readwrite",["owner","clientMetadata"],e=>{const t=new Ic(e,st.oe);return this.yi(t).next(()=>this.bi(t))}),this.Ei.close(),this.Li()}vi(e,t){return e.filter(s=>this.Ci(s.updateTimeMs,t)&&!this.Mi(s.clientId))}Bi(){return this.runTransaction("getActiveClients","readonly",e=>Ji(e).U().next(t=>this.vi(t,18e5).map(s=>s.clientId)))}get started(){return this.qr}getMutationQueue(e,t){return oa.lt(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new ZE(e,this.serializer.ct.databaseId)}getDocumentOverlayCache(e){return ia.lt(this.serializer,e)}getBundleCache(){return this.$r}runTransaction(e,t,s){D("IndexedDbPersistence","Starting transaction:",e);const r=t==="readonly"?"readonly":"readwrite",i=function(l){return l===16?Zw:l===15?Sp:l===14?Ap:l===13?Tp:l===12?Xw:l===11?bp:void q()}(this.ui);let o;return this.Ei.runTransaction(e,r,i,c=>(o=new Ic(c,this.kr?this.kr.next():st.oe),t==="readwrite-primary"?this.gi(o).next(l=>!!l||this.pi(o)).next(l=>{if(!l)throw Te(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)),new F(C.FAILED_PRECONDITION,yp);return s(o)}).next(l=>this.wi(o).next(()=>l)):this.ki(o).next(()=>s(o)))).then(c=>(o.raiseOnCommittedEvent(),c))}ki(e){return Tr(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)&&!this.Si(t)&&!(this.ai||this.allowTabSynchronization&&t.allowTabSynchronization))throw new F(C.FAILED_PRECONDITION,ec)})}wi(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return Tr(e).put("owner",t)}static D(){return dn.D()}yi(e){const t=Tr(e);return t.get("owner").next(s=>this.Si(s)?(D("IndexedDbPersistence","Releasing primary lease."),t.delete("owner")):A.resolve())}Ci(e,t){const s=Date.now();return!(e<s-t)&&(!(e>s)||(Te(`Detected an update time that is in the future: ${e} > ${s}`),!1))}Ri(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.li=()=>{this.oi.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.Ai()))},this.document.addEventListener("visibilitychange",this.li),this.inForeground=this.document.visibilityState==="visible")}Oi(){this.li&&(this.document.removeEventListener("visibilitychange",this.li),this.li=null)}Vi(){var e;typeof((e=this.window)===null||e===void 0?void 0:e.addEventListener)=="function"&&(this.ci=()=>{this.xi();const t=/(?:Version|Mobile)\/1[456]/;Ef()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.oi.enterRestrictedMode(!0),this.oi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.ci))}Ni(){this.ci&&(this.window.removeEventListener("pagehide",this.ci),this.ci=null)}Mi(e){var t;try{const s=((t=this.di)===null||t===void 0?void 0:t.getItem(this.Fi(e)))!==null;return D("IndexedDbPersistence",`Client '${e}' ${s?"is":"is not"} zombied in LocalStorage`),s}catch(s){return Te("IndexedDbPersistence","Failed to get zombied client id.",s),!1}}xi(){if(this.di)try{this.di.setItem(this.Fi(this.clientId),String(Date.now()))}catch(e){Te("Failed to set zombie client id.",e)}}Li(){if(this.di)try{this.di.removeItem(this.Fi(this.clientId))}catch{}}Fi(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function Tr(n){return Le(n,"owner")}function Ji(n){return Le(n,"clientMetadata")}function Sm(n,e){let t=n.projectId;return n.isDefaultDatabase||(t+="."+n.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sl{constructor(e,t,s,r){this.targetId=e,this.fromCache=t,this.qi=s,this.Qi=r}static Ki(e,t){let s=te(),r=te();for(const i of t.docChanges)switch(i.type){case 0:s=s.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new Sl(e,t.fromCache,s,r)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _b{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rm{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=function(){return Ef()?8:Ip(Ce())>0?6:4}()}initialize(e,t){this.zi=e,this.indexManager=t,this.$i=!0}getDocumentsMatchingQuery(e,t,s,r){const i={result:null};return this.ji(e,t).next(o=>{i.result=o}).next(()=>{if(!i.result)return this.Hi(e,t,r,s).next(o=>{i.result=o})}).next(()=>{if(i.result)return;const o=new _b;return this.Ji(e,t,o).next(c=>{if(i.result=c,this.Ui)return this.Yi(e,t,o,c.size)})}).next(()=>i.result)}Yi(e,t,s,r){return s.documentReadCount<this.Wi?(gs()<=ne.DEBUG&&D("QueryEngine","SDK will not create cache indexes for query:",_s(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),A.resolve()):(gs()<=ne.DEBUG&&D("QueryEngine","Query:",_s(t),"scans",s.documentReadCount,"local documents and returns",r,"documents as results."),s.documentReadCount>this.Gi*r?(gs()<=ne.DEBUG&&D("QueryEngine","The SDK decides to create cache indexes for query:",_s(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,ct(t))):A.resolve())}ji(e,t){if(ed(t))return A.resolve(null);let s=ct(t);return this.indexManager.getIndexType(e,s).next(r=>r===0?null:(t.limit!==null&&r===1&&(t=Sc(t,null,"F"),s=ct(t)),this.indexManager.getDocumentsMatchingTarget(e,s).next(i=>{const o=te(...i);return this.zi.getDocuments(e,o).next(c=>this.indexManager.getMinOffset(e,s).next(l=>{const u=this.Zi(t,c);return this.Xi(t,u,o,l.readTime)?this.ji(e,Sc(t,null,"F")):this.es(e,u,t,l)}))})))}Hi(e,t,s,r){return ed(t)||r.isEqual(H.min())?A.resolve(null):this.zi.getDocuments(e,s).next(i=>{const o=this.Zi(t,i);return this.Xi(t,o,s,r)?A.resolve(null):(gs()<=ne.DEBUG&&D("QueryEngine","Re-using previous result from %s to execute query: %s",r.toString(),_s(t)),this.es(e,o,t,gp(r,-1)).next(c=>c))})}Zi(e,t){let s=new he(Bp(e));return t.forEach((r,i)=>{_i(e,i)&&(s=s.add(i))}),s}Xi(e,t,s,r){if(e.limit===null)return!1;if(s.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}Ji(e,t,s){return gs()<=ne.DEBUG&&D("QueryEngine","Using full collection scan to execute query:",_s(t)),this.zi.getDocumentsMatchingQuery(e,t,ht.min(),s)}es(e,t,s,r){return this.zi.getDocumentsMatchingQuery(e,s,r).next(i=>(t.forEach(o=>{i=i.insert(o.key,o)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yb{constructor(e,t,s,r){this.persistence=e,this.ts=t,this.serializer=r,this.ns=new pe(X),this.rs=new Sn(i=>Xn(i),gi),this.ss=new Map,this.os=e.getRemoteDocumentCache(),this.Qr=e.getTargetCache(),this.$r=e.getBundleCache(),this._s(s)}_s(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new Tm(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.ns))}}function Pm(n,e,t,s){return new yb(n,e,t,s)}async function km(n,e){const t=G(n);return await t.persistence.runTransaction("Handle user change","readonly",s=>{let r;return t.mutationQueue.getAllMutationBatches(s).next(i=>(r=i,t._s(e),t.mutationQueue.getAllMutationBatches(s))).next(i=>{const o=[],c=[];let l=te();for(const u of r){o.push(u.batchId);for(const f of u.mutations)l=l.add(f.key)}for(const u of i){c.push(u.batchId);for(const f of u.mutations)l=l.add(f.key)}return t.localDocuments.getDocuments(s,l).next(u=>({us:u,removedBatchIds:o,addedBatchIds:c}))})})}function vb(n,e){const t=G(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",s=>{const r=e.batch.keys(),i=t.os.newChangeBuffer({trackRemovals:!0});return function(c,l,u,f){const p=u.batch,y=p.keys();let S=A.resolve();return y.forEach(k=>{S=S.next(()=>f.getEntry(l,k)).next(V=>{const R=u.docVersions.get(k);W(R!==null),V.version.compareTo(R)<0&&(p.applyToRemoteDocument(V,u),V.isValidDocument()&&(V.setReadTime(u.commitVersion),f.addEntry(V)))})}),S.next(()=>c.mutationQueue.removeMutationBatch(l,p))}(t,s,e,i).next(()=>i.apply(s)).next(()=>t.mutationQueue.performConsistencyCheck(s)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(s,r,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,function(c){let l=te();for(let u=0;u<c.mutationResults.length;++u)c.mutationResults[u].transformResults.length>0&&(l=l.add(c.batch.mutations[u].key));return l}(e))).next(()=>t.localDocuments.getDocuments(s,r))})}function Cm(n){const e=G(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Qr.getLastRemoteSnapshotVersion(t))}function Ib(n,e){const t=G(n),s=e.snapshotVersion;let r=t.ns;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const o=t.os.newChangeBuffer({trackRemovals:!0});r=t.ns;const c=[];e.targetChanges.forEach((f,p)=>{const y=r.get(p);if(!y)return;c.push(t.Qr.removeMatchingKeys(i,f.removedDocuments,p).next(()=>t.Qr.addMatchingKeys(i,f.addedDocuments,p)));let S=y.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(p)!==null?S=S.withResumeToken(Oe.EMPTY_BYTE_STRING,H.min()).withLastLimboFreeSnapshotVersion(H.min()):f.resumeToken.approximateByteSize()>0&&(S=S.withResumeToken(f.resumeToken,s)),r=r.insert(p,S),function(V,R,B){return V.resumeToken.approximateByteSize()===0||R.snapshotVersion.toMicroseconds()-V.snapshotVersion.toMicroseconds()>=3e8?!0:B.addedDocuments.size+B.modifiedDocuments.size+B.removedDocuments.size>0}(y,S,f)&&c.push(t.Qr.updateTargetData(i,S))});let l=at(),u=te();if(e.documentUpdates.forEach(f=>{e.resolvedLimboDocuments.has(f)&&c.push(t.persistence.referenceDelegate.updateLimboDocument(i,f))}),c.push(wb(i,o,e.documentUpdates).next(f=>{l=f.cs,u=f.ls})),!s.isEqual(H.min())){const f=t.Qr.getLastRemoteSnapshotVersion(i).next(p=>t.Qr.setTargetsMetadata(i,i.currentSequenceNumber,s));c.push(f)}return A.waitFor(c).next(()=>o.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,l,u)).next(()=>l)}).then(i=>(t.ns=r,i))}function wb(n,e,t){let s=te(),r=te();return t.forEach(i=>s=s.add(i)),e.getEntries(n,s).next(i=>{let o=at();return t.forEach((c,l)=>{const u=i.get(c);l.isFoundDocument()!==u.isFoundDocument()&&(r=r.add(c)),l.isNoDocument()&&l.version.isEqual(H.min())?(e.removeEntry(c,l.readTime),o=o.insert(c,l)):!u.isValidDocument()||l.version.compareTo(u.version)>0||l.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(l),o=o.insert(c,l)):D("LocalStore","Ignoring outdated watch update for ",c,". Current version:",u.version," Watch version:",l.version)}),{cs:o,ls:r}})}function Eb(n,e){const t=G(n);return t.persistence.runTransaction("Get next mutation batch","readonly",s=>(e===void 0&&(e=-1),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e)))}function No(n,e){const t=G(n);return t.persistence.runTransaction("Allocate target","readwrite",s=>{let r;return t.Qr.getTargetData(s,e).next(i=>i?(r=i,A.resolve(r)):t.Qr.allocateTargetId(s).next(o=>(r=new $t(e,o,"TargetPurposeListen",s.currentSequenceNumber),t.Qr.addTargetData(s,r).next(()=>r))))}).then(s=>{const r=t.ns.get(s.targetId);return(r===null||s.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(t.ns=t.ns.insert(s.targetId,s),t.rs.set(e,s.targetId)),s})}async function $s(n,e,t){const s=G(n),r=s.ns.get(e),i=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",i,o=>s.persistence.referenceDelegate.removeTarget(o,r))}catch(o){if(!An(o))throw o;D("LocalStore",`Failed to update sequence numbers for target ${e}: ${o}`)}s.ns=s.ns.remove(e),s.rs.delete(r.target)}function xc(n,e,t){const s=G(n);let r=H.min(),i=te();return s.persistence.runTransaction("Execute query","readwrite",o=>function(l,u,f){const p=G(l),y=p.rs.get(f);return y!==void 0?A.resolve(p.ns.get(y)):p.Qr.getTargetData(u,f)}(s,o,ct(e)).next(c=>{if(c)return r=c.lastLimboFreeSnapshotVersion,s.Qr.getMatchingKeysForTargetId(o,c.targetId).next(l=>{i=l})}).next(()=>s.ts.getDocumentsMatchingQuery(o,e,t?r:H.min(),t?i:te())).next(c=>(Nm(s,Up(e),c),{documents:c,hs:i})))}function Dm(n,e){const t=G(n),s=G(t.Qr),r=t.ns.get(e);return r?Promise.resolve(r.target):t.persistence.runTransaction("Get target data","readonly",i=>s.ot(i,e).next(o=>o?o.target:null))}function Vm(n,e){const t=G(n),s=t.ss.get(e)||H.min();return t.persistence.runTransaction("Get new document changes","readonly",r=>t.os.getAllFromCollectionGroup(r,e,gp(s,-1),Number.MAX_SAFE_INTEGER)).then(r=>(Nm(t,e,r),r))}function Nm(n,e,t){let s=n.ss.get(e)||H.min();t.forEach((r,i)=>{i.readTime.compareTo(s)>0&&(s=i.readTime)}),n.ss.set(e,s)}function kd(n,e){return`firestore_clients_${n}_${e}`}function Cd(n,e,t){let s=`firestore_mutations_${n}_${t}`;return e.isAuthenticated()&&(s+=`_${e.uid}`),s}function tc(n,e){return`firestore_targets_${n}_${e}`}class xo{constructor(e,t,s,r){this.user=e,this.batchId=t,this.state=s,this.error=r}static Es(e,t,s){const r=JSON.parse(s);let i,o=typeof r=="object"&&["pending","acknowledged","rejected"].indexOf(r.state)!==-1&&(r.error===void 0||typeof r.error=="object");return o&&r.error&&(o=typeof r.error.message=="string"&&typeof r.error.code=="string",o&&(i=new F(r.error.code,r.error.message))),o?new xo(e,t,r.state,i):(Te("SharedClientState",`Failed to parse mutation state for ID '${t}': ${s}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Ur{constructor(e,t,s){this.targetId=e,this.state=t,this.error=s}static Es(e,t){const s=JSON.parse(t);let r,i=typeof s=="object"&&["not-current","current","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return i&&s.error&&(i=typeof s.error.message=="string"&&typeof s.error.code=="string",i&&(r=new F(s.error.code,s.error.message))),i?new Ur(e,s.state,r):(Te("SharedClientState",`Failed to parse target state for ID '${e}': ${t}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Oo{constructor(e,t){this.clientId=e,this.activeTargetIds=t}static Es(e,t){const s=JSON.parse(t);let r=typeof s=="object"&&s.activeTargetIds instanceof Array,i=gl();for(let o=0;r&&o<s.activeTargetIds.length;++o)r=wp(s.activeTargetIds[o]),i=i.add(s.activeTargetIds[o]);return r?new Oo(e,i):(Te("SharedClientState",`Failed to parse client data for instance '${e}': ${t}`),null)}}class Rl{constructor(e,t){this.clientId=e,this.onlineState=t}static Es(e){const t=JSON.parse(e);return typeof t=="object"&&["Unknown","Online","Offline"].indexOf(t.onlineState)!==-1&&typeof t.clientId=="string"?new Rl(t.clientId,t.onlineState):(Te("SharedClientState",`Failed to parse online state: ${e}`),null)}}class Oc{constructor(){this.activeTargetIds=gl()}As(e){this.activeTargetIds=this.activeTargetIds.add(e)}Rs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ds(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class nc{constructor(e,t,s,r,i){this.window=e,this.oi=t,this.persistenceKey=s,this.Vs=r,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.fs=this.gs.bind(this),this.ps=new pe(X),this.started=!1,this.ys=[];const o=s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=i,this.ws=kd(this.persistenceKey,this.Vs),this.Ss=function(l){return`firestore_sequence_number_${l}`}(this.persistenceKey),this.ps=this.ps.insert(this.Vs,new Oc),this.bs=new RegExp(`^firestore_clients_${o}_([^_]*)$`),this.Ds=new RegExp(`^firestore_mutations_${o}_(\\d+)(?:_(.*))?$`),this.Cs=new RegExp(`^firestore_targets_${o}_(\\d+)$`),this.vs=function(l){return`firestore_online_state_${l}`}(this.persistenceKey),this.Fs=function(l){return`firestore_bundle_loaded_v2_${l}`}(this.persistenceKey),this.window.addEventListener("storage",this.fs)}static D(e){return!(!e||!e.localStorage)}async start(){const e=await this.syncEngine.Bi();for(const s of e){if(s===this.Vs)continue;const r=this.getItem(kd(this.persistenceKey,s));if(r){const i=Oo.Es(s,r);i&&(this.ps=this.ps.insert(i.clientId,i))}}this.Ms();const t=this.storage.getItem(this.vs);if(t){const s=this.xs(t);s&&this.Os(s)}for(const s of this.ys)this.gs(s);this.ys=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(e){this.setItem(this.Ss,JSON.stringify(e))}getAllActiveQueryTargets(){return this.Ns(this.ps)}isActiveQueryTarget(e){let t=!1;return this.ps.forEach((s,r)=>{r.activeTargetIds.has(e)&&(t=!0)}),t}addPendingMutation(e){this.Ls(e,"pending")}updateMutationState(e,t,s){this.Ls(e,t,s),this.Bs(e)}addLocalQueryTarget(e){let t="not-current";if(this.isActiveQueryTarget(e)){const s=this.storage.getItem(tc(this.persistenceKey,e));if(s){const r=Ur.Es(e,s);r&&(t=r.state)}}return this.ks.As(e),this.Ms(),t}removeLocalQueryTarget(e){this.ks.Rs(e),this.Ms()}isLocalQueryTarget(e){return this.ks.activeTargetIds.has(e)}clearQueryState(e){this.removeItem(tc(this.persistenceKey,e))}updateQueryState(e,t,s){this.qs(e,t,s)}handleUserChange(e,t,s){t.forEach(r=>{this.Bs(r)}),this.currentUser=e,s.forEach(r=>{this.addPendingMutation(r)})}setOnlineState(e){this.Qs(e)}notifyBundleLoaded(e){this.Ks(e)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.fs),this.removeItem(this.ws),this.started=!1)}getItem(e){const t=this.storage.getItem(e);return D("SharedClientState","READ",e,t),t}setItem(e,t){D("SharedClientState","SET",e,t),this.storage.setItem(e,t)}removeItem(e){D("SharedClientState","REMOVE",e),this.storage.removeItem(e)}gs(e){const t=e;if(t.storageArea===this.storage){if(D("SharedClientState","EVENT",t.key,t.newValue),t.key===this.ws)return void Te("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.oi.enqueueRetryable(async()=>{if(this.started){if(t.key!==null){if(this.bs.test(t.key)){if(t.newValue==null){const s=this.$s(t.key);return this.Us(s,null)}{const s=this.Ws(t.key,t.newValue);if(s)return this.Us(s.clientId,s)}}else if(this.Ds.test(t.key)){if(t.newValue!==null){const s=this.Gs(t.key,t.newValue);if(s)return this.zs(s)}}else if(this.Cs.test(t.key)){if(t.newValue!==null){const s=this.js(t.key,t.newValue);if(s)return this.Hs(s)}}else if(t.key===this.vs){if(t.newValue!==null){const s=this.xs(t.newValue);if(s)return this.Os(s)}}else if(t.key===this.Ss){const s=function(i){let o=st.oe;if(i!=null)try{const c=JSON.parse(i);W(typeof c=="number"),o=c}catch(c){Te("SharedClientState","Failed to read sequence number from WebStorage",c)}return o}(t.newValue);s!==st.oe&&this.sequenceNumberHandler(s)}else if(t.key===this.Fs){const s=this.Js(t.newValue);await Promise.all(s.map(r=>this.syncEngine.Ys(r)))}}}else this.ys.push(t)})}}get ks(){return this.ps.get(this.Vs)}Ms(){this.setItem(this.ws,this.ks.ds())}Ls(e,t,s){const r=new xo(this.currentUser,e,t,s),i=Cd(this.persistenceKey,this.currentUser,e);this.setItem(i,r.ds())}Bs(e){const t=Cd(this.persistenceKey,this.currentUser,e);this.removeItem(t)}Qs(e){const t={clientId:this.Vs,onlineState:e};this.storage.setItem(this.vs,JSON.stringify(t))}qs(e,t,s){const r=tc(this.persistenceKey,e),i=new Ur(e,t,s);this.setItem(r,i.ds())}Ks(e){const t=JSON.stringify(Array.from(e));this.setItem(this.Fs,t)}$s(e){const t=this.bs.exec(e);return t?t[1]:null}Ws(e,t){const s=this.$s(e);return Oo.Es(s,t)}Gs(e,t){const s=this.Ds.exec(e),r=Number(s[1]),i=s[2]!==void 0?s[2]:null;return xo.Es(new Ke(i),r,t)}js(e,t){const s=this.Cs.exec(e),r=Number(s[1]);return Ur.Es(r,t)}xs(e){return Rl.Es(e)}Js(e){return JSON.parse(e)}async zs(e){if(e.user.uid===this.currentUser.uid)return this.syncEngine.Zs(e.batchId,e.state,e.error);D("SharedClientState",`Ignoring mutation for non-active user ${e.user.uid}`)}Hs(e){return this.syncEngine.Xs(e.targetId,e.state,e.error)}Us(e,t){const s=t?this.ps.insert(e,t):this.ps.remove(e),r=this.Ns(this.ps),i=this.Ns(s),o=[],c=[];return i.forEach(l=>{r.has(l)||o.push(l)}),r.forEach(l=>{i.has(l)||c.push(l)}),this.syncEngine.eo(o,c).then(()=>{this.ps=s})}Os(e){this.ps.get(e.clientId)&&this.onlineStateHandler(e.onlineState)}Ns(e){let t=gl();return e.forEach((s,r)=>{t=t.unionWith(r.activeTargetIds)}),t}}class xm{constructor(){this.no=new Oc,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e){return this.no.As(e),this.ro[e]||"not-current"}updateQueryState(e,t,s){this.ro[e]=t}removeLocalQueryTarget(e){this.no.Rs(e)}isLocalQueryTarget(e){return this.no.activeTargetIds.has(e)}clearQueryState(e){delete this.ro[e]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(e){return this.no.activeTargetIds.has(e)}start(){return this.no=new Oc,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bb{io(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dd{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(e){this.uo.push(e)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){D("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const e of this.uo)e(0)}ao(){D("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const e of this.uo)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Yi=null;function sc(){return Yi===null?Yi=function(){return 268435456+Math.round(2147483648*Math.random())}():Yi++,"0x"+Yi.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tb={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ab{constructor(e){this.lo=e.lo,this.ho=e.ho}Po(e){this.Io=e}To(e){this.Eo=e}Ao(e){this.Ro=e}onMessage(e){this.Vo=e}close(){this.ho()}send(e){this.lo(e)}mo(){this.Io()}fo(){this.Eo()}po(e){this.Ro(e)}yo(e){this.Vo(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ze="WebChannelConnection";class Sb extends class{constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const s=t.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),i=encodeURIComponent(this.databaseId.database);this.wo=s+"://"+t.host,this.So=`projects/${r}/databases/${i}`,this.bo=this.databaseId.database==="(default)"?`project_id=${r}`:`project_id=${r}&database_id=${i}`}get Do(){return!1}Co(t,s,r,i,o){const c=sc(),l=this.vo(t,s.toUriEncodedString());D("RestConnection",`Sending RPC '${t}' ${c}:`,l,r);const u={"google-cloud-resource-prefix":this.So,"x-goog-request-params":this.bo};return this.Fo(u,i,o),this.Mo(t,l,u,r).then(f=>(D("RestConnection",`Received RPC '${t}' ${c}: `,f),f),f=>{throw Hr("RestConnection",`RPC '${t}' ${c} failed with error: `,f,"url: ",l,"request:",r),f})}xo(t,s,r,i,o,c){return this.Co(t,s,r,i,o)}Fo(t,s,r){t["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Ys}(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),s&&s.headers.forEach((i,o)=>t[o]=i),r&&r.headers.forEach((i,o)=>t[o]=i)}vo(t,s){const r=Tb[t];return`${this.wo}/v1/${s}:${r}`}terminate(){}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Mo(e,t,s,r){const i=sc();return new Promise((o,c)=>{const l=new cp;l.setWithCredentials(!0),l.listenOnce(up.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case ro.NO_ERROR:const f=l.getResponseJson();D(ze,`XHR for RPC '${e}' ${i} received:`,JSON.stringify(f)),o(f);break;case ro.TIMEOUT:D(ze,`RPC '${e}' ${i} timed out`),c(new F(C.DEADLINE_EXCEEDED,"Request time out"));break;case ro.HTTP_ERROR:const p=l.getStatus();if(D(ze,`RPC '${e}' ${i} failed with status:`,p,"response text:",l.getResponseText()),p>0){let y=l.getResponseJson();Array.isArray(y)&&(y=y[0]);const S=y==null?void 0:y.error;if(S&&S.status&&S.message){const k=function(R){const B=R.toLowerCase().replace(/_/g,"-");return Object.values(C).indexOf(B)>=0?B:C.UNKNOWN}(S.status);c(new F(k,S.message))}else c(new F(C.UNKNOWN,"Server responded with status "+l.getStatus()))}else c(new F(C.UNAVAILABLE,"Connection failed."));break;default:q()}}finally{D(ze,`RPC '${e}' ${i} completed.`)}});const u=JSON.stringify(r);D(ze,`RPC '${e}' ${i} sending request:`,r),l.send(t,"POST",u,s,15)})}Oo(e,t,s){const r=sc(),i=[this.wo,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=fp(),c=dp(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.xmlHttpFactory=new lp({})),this.Fo(l.initMessageHeaders,t,s),l.encodeInitMessageHeaders=!0;const f=i.join("");D(ze,`Creating RPC '${e}' stream ${r}: ${f}`,l);const p=o.createWebChannel(f,l);let y=!1,S=!1;const k=new Ab({lo:R=>{S?D(ze,`Not sending because RPC '${e}' stream ${r} is closed:`,R):(y||(D(ze,`Opening RPC '${e}' stream ${r} transport.`),p.open(),y=!0),D(ze,`RPC '${e}' stream ${r} sending:`,R),p.send(R))},ho:()=>p.close()}),V=(R,B,z)=>{R.listen(B,j=>{try{z(j)}catch(Z){setTimeout(()=>{throw Z},0)}})};return V(p,kr.EventType.OPEN,()=>{S||(D(ze,`RPC '${e}' stream ${r} transport opened.`),k.mo())}),V(p,kr.EventType.CLOSE,()=>{S||(S=!0,D(ze,`RPC '${e}' stream ${r} transport closed`),k.po())}),V(p,kr.EventType.ERROR,R=>{S||(S=!0,Hr(ze,`RPC '${e}' stream ${r} transport errored:`,R),k.po(new F(C.UNAVAILABLE,"The operation could not be completed")))}),V(p,kr.EventType.MESSAGE,R=>{var B;if(!S){const z=R.data[0];W(!!z);const j=z,Z=j.error||((B=j[0])===null||B===void 0?void 0:B.error);if(Z){D(ze,`RPC '${e}' stream ${r} received error:`,Z);const N=Z.status;let M=function(_){const w=Se[_];if(w!==void 0)return em(w)}(N),I=Z.message;M===void 0&&(M=C.INTERNAL,I="Unknown error status: "+N+" with message "+Z.message),S=!0,k.po(new F(M,I)),p.close()}else D(ze,`RPC '${e}' stream ${r} received:`,z),k.yo(z)}}),V(c,hp.STAT_EVENT,R=>{R.stat===yc.PROXY?D(ze,`RPC '${e}' stream ${r} detected buffering proxy`):R.stat===yc.NOPROXY&&D(ze,`RPC '${e}' stream ${r} detected no buffering proxy`)}),setTimeout(()=>{k.fo()},0),k}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Om(){return typeof window<"u"?window:null}function ho(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ca(n){return new OE(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lm{constructor(e,t,s=1e3,r=1.5,i=6e4){this.oi=e,this.timerId=t,this.No=s,this.Lo=r,this.Bo=i,this.ko=0,this.qo=null,this.Qo=Date.now(),this.reset()}reset(){this.ko=0}Ko(){this.ko=this.Bo}$o(e){this.cancel();const t=Math.floor(this.ko+this.Uo()),s=Math.max(0,Date.now()-this.Qo),r=Math.max(0,t-s);r>0&&D("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.ko} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.qo=this.oi.enqueueAfterDelay(this.timerId,r,()=>(this.Qo=Date.now(),e())),this.ko*=this.Lo,this.ko<this.No&&(this.ko=this.No),this.ko>this.Bo&&(this.ko=this.Bo)}Wo(){this.qo!==null&&(this.qo.skipDelay(),this.qo=null)}cancel(){this.qo!==null&&(this.qo.cancel(),this.qo=null)}Uo(){return(Math.random()-.5)*this.ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mm{constructor(e,t,s,r,i,o,c,l){this.oi=e,this.Go=s,this.zo=r,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=c,this.listener=l,this.state=0,this.jo=0,this.Ho=null,this.Jo=null,this.stream=null,this.Yo=new Lm(e,t)}Zo(){return this.state===1||this.state===5||this.Xo()}Xo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.e_()}async stop(){this.Zo()&&await this.close(0)}t_(){this.state=0,this.Yo.reset()}n_(){this.Xo()&&this.Ho===null&&(this.Ho=this.oi.enqueueAfterDelay(this.Go,6e4,()=>this.r_()))}i_(e){this.s_(),this.stream.send(e)}async r_(){if(this.Xo())return this.close(0)}s_(){this.Ho&&(this.Ho.cancel(),this.Ho=null)}o_(){this.Jo&&(this.Jo.cancel(),this.Jo=null)}async close(e,t){this.s_(),this.o_(),this.Yo.cancel(),this.jo++,e!==4?this.Yo.reset():t&&t.code===C.RESOURCE_EXHAUSTED?(Te(t.toString()),Te("Using maximum backoff delay to prevent overloading the backend."),this.Yo.Ko()):t&&t.code===C.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.__(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Ao(t)}__(){}auth(){this.state=1;const e=this.a_(this.jo),t=this.jo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([s,r])=>{this.jo===t&&this.u_(s,r)},s=>{e(()=>{const r=new F(C.UNKNOWN,"Fetching auth token failed: "+s.message);return this.c_(r)})})}u_(e,t){const s=this.a_(this.jo);this.stream=this.l_(e,t),this.stream.Po(()=>{s(()=>this.listener.Po())}),this.stream.To(()=>{s(()=>(this.state=2,this.Jo=this.oi.enqueueAfterDelay(this.zo,1e4,()=>(this.Xo()&&(this.state=3),Promise.resolve())),this.listener.To()))}),this.stream.Ao(r=>{s(()=>this.c_(r))}),this.stream.onMessage(r=>{s(()=>this.onMessage(r))})}e_(){this.state=5,this.Yo.$o(async()=>{this.state=0,this.start()})}c_(e){return D("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}a_(e){return t=>{this.oi.enqueueAndForget(()=>this.jo===e?t():(D("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class Rb extends Mm{constructor(e,t,s,r,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,r,o),this.serializer=i}l_(e,t){return this.connection.Oo("Listen",e,t)}onMessage(e){this.Yo.reset();const t=$E(this.serializer,e),s=function(i){if(!("targetChange"in i))return H.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?H.min():o.readTime?Ze(o.readTime):H.min()}(e);return this.listener.h_(t,s)}P_(e){const t={};t.database=kc(this.serializer),t.addTarget=function(i,o){let c;const l=o.target;if(c=So(l)?{documents:cm(i,l)}:{query:lm(i,l)._t},c.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){c.resumeToken=sm(i,o.resumeToken);const u=Rc(i,o.expectedCount);u!==null&&(c.expectedCount=u)}else if(o.snapshotVersion.compareTo(H.min())>0){c.readTime=Ms(i,o.snapshotVersion.toTimestamp());const u=Rc(i,o.expectedCount);u!==null&&(c.expectedCount=u)}return c}(this.serializer,e);const s=UE(this.serializer,e);s&&(t.labels=s),this.i_(t)}I_(e){const t={};t.database=kc(this.serializer),t.removeTarget=e,this.i_(t)}}class Pb extends Mm{constructor(e,t,s,r,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,r,o),this.serializer=i,this.T_=!1}get E_(){return this.T_}start(){this.T_=!1,this.lastStreamToken=void 0,super.start()}__(){this.T_&&this.d_([])}l_(e,t){return this.connection.Oo("Write",e,t)}onMessage(e){if(W(!!e.streamToken),this.lastStreamToken=e.streamToken,this.T_){this.Yo.reset();const t=FE(e.writeResults,e.commitTime),s=Ze(e.commitTime);return this.listener.A_(s,t)}return W(!e.writeResults||e.writeResults.length===0),this.T_=!0,this.listener.R_()}V_(){const e={};e.database=kc(this.serializer),this.i_(e)}d_(e){const t={streamToken:this.lastStreamToken,writes:e.map(s=>ko(this.serializer,s))};this.i_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kb extends class{}{constructor(e,t,s,r){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=r,this.m_=!1}f_(){if(this.m_)throw new F(C.FAILED_PRECONDITION,"The client has already been terminated.")}Co(e,t,s,r){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.Co(e,Pc(t,s),r,i,o)).catch(i=>{throw i.name==="FirebaseError"?(i.code===C.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new F(C.UNKNOWN,i.toString())})}xo(e,t,s,r,i){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,c])=>this.connection.xo(e,Pc(t,s),r,o,c,i)).catch(o=>{throw o.name==="FirebaseError"?(o.code===C.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new F(C.UNKNOWN,o.toString())})}terminate(){this.m_=!0,this.connection.terminate()}}class Cb{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.g_=0,this.p_=null,this.y_=!0}w_(){this.g_===0&&(this.S_("Unknown"),this.p_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.p_=null,this.b_("Backend didn't respond within 10 seconds."),this.S_("Offline"),Promise.resolve())))}D_(e){this.state==="Online"?this.S_("Unknown"):(this.g_++,this.g_>=1&&(this.C_(),this.b_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.S_("Offline")))}set(e){this.C_(),this.g_=0,e==="Online"&&(this.y_=!1),this.S_(e)}S_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}b_(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.y_?(Te(t),this.y_=!1):D("OnlineStateTracker",t)}C_(){this.p_!==null&&(this.p_.cancel(),this.p_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Db{constructor(e,t,s,r,i){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.v_=[],this.F_=new Map,this.M_=new Set,this.x_=[],this.O_=i,this.O_.io(o=>{s.enqueueAndForget(async()=>{is(this)&&(D("RemoteStore","Restarting streams for network reachability change."),await async function(l){const u=G(l);u.M_.add(4),await Ii(u),u.N_.set("Unknown"),u.M_.delete(4),await la(u)}(this))})}),this.N_=new Cb(s,r)}}async function la(n){if(is(n))for(const e of n.x_)await e(!0)}async function Ii(n){for(const e of n.x_)await e(!1)}function ua(n,e){const t=G(n);t.F_.has(e.targetId)||(t.F_.set(e.targetId,e),Cl(t)?kl(t):er(t).Xo()&&Pl(t,e))}function Fs(n,e){const t=G(n),s=er(t);t.F_.delete(e),s.Xo()&&$m(t,e),t.F_.size===0&&(s.Xo()?s.n_():is(t)&&t.N_.set("Unknown"))}function Pl(n,e){if(n.L_.xe(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(H.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}er(n).P_(e)}function $m(n,e){n.L_.xe(e),er(n).I_(e)}function kl(n){n.L_=new DE({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),ot:e=>n.F_.get(e)||null,tt:()=>n.datastore.serializer.databaseId}),er(n).start(),n.N_.w_()}function Cl(n){return is(n)&&!er(n).Zo()&&n.F_.size>0}function is(n){return G(n).M_.size===0}function Fm(n){n.L_=void 0}async function Vb(n){n.N_.set("Online")}async function Nb(n){n.F_.forEach((e,t)=>{Pl(n,e)})}async function xb(n,e){Fm(n),Cl(n)?(n.N_.D_(e),kl(n)):n.N_.set("Unknown")}async function Ob(n,e,t){if(n.N_.set("Online"),e instanceof nm&&e.state===2&&e.cause)try{await async function(r,i){const o=i.cause;for(const c of i.targetIds)r.F_.has(c)&&(await r.remoteSyncer.rejectListen(c,o),r.F_.delete(c),r.L_.removeTarget(c))}(n,e)}catch(s){D("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),s),await Lo(n,s)}else if(e instanceof uo?n.L_.Ke(e):e instanceof tm?n.L_.He(e):n.L_.We(e),!t.isEqual(H.min()))try{const s=await Cm(n.localStore);t.compareTo(s)>=0&&await function(i,o){const c=i.L_.rt(o);return c.targetChanges.forEach((l,u)=>{if(l.resumeToken.approximateByteSize()>0){const f=i.F_.get(u);f&&i.F_.set(u,f.withResumeToken(l.resumeToken,o))}}),c.targetMismatches.forEach((l,u)=>{const f=i.F_.get(l);if(!f)return;i.F_.set(l,f.withResumeToken(Oe.EMPTY_BYTE_STRING,f.snapshotVersion)),$m(i,l);const p=new $t(f.target,l,u,f.sequenceNumber);Pl(i,p)}),i.remoteSyncer.applyRemoteEvent(c)}(n,t)}catch(s){D("RemoteStore","Failed to raise snapshot:",s),await Lo(n,s)}}async function Lo(n,e,t){if(!An(e))throw e;n.M_.add(1),await Ii(n),n.N_.set("Offline"),t||(t=()=>Cm(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{D("RemoteStore","Retrying IndexedDB access"),await t(),n.M_.delete(1),await la(n)})}function Um(n,e){return e().catch(t=>Lo(n,t,e))}async function Zs(n){const e=G(n),t=vn(e);let s=e.v_.length>0?e.v_[e.v_.length-1].batchId:-1;for(;Lb(e);)try{const r=await Eb(e.localStore,s);if(r===null){e.v_.length===0&&t.n_();break}s=r.batchId,Mb(e,r)}catch(r){await Lo(e,r)}Bm(e)&&qm(e)}function Lb(n){return is(n)&&n.v_.length<10}function Mb(n,e){n.v_.push(e);const t=vn(n);t.Xo()&&t.E_&&t.d_(e.mutations)}function Bm(n){return is(n)&&!vn(n).Zo()&&n.v_.length>0}function qm(n){vn(n).start()}async function $b(n){vn(n).V_()}async function Fb(n){const e=vn(n);for(const t of n.v_)e.d_(t.mutations)}async function Ub(n,e,t){const s=n.v_.shift(),r=yl.from(s,e,t);await Um(n,()=>n.remoteSyncer.applySuccessfulWrite(r)),await Zs(n)}async function Bb(n,e){e&&vn(n).E_&&await async function(s,r){if(function(o){return PE(o)&&o!==C.ABORTED}(r.code)){const i=s.v_.shift();vn(s).t_(),await Um(s,()=>s.remoteSyncer.rejectFailedWrite(i.batchId,r)),await Zs(s)}}(n,e),Bm(n)&&qm(n)}async function Vd(n,e){const t=G(n);t.asyncQueue.verifyOperationInProgress(),D("RemoteStore","RemoteStore received new credentials");const s=is(t);t.M_.add(3),await Ii(t),s&&t.N_.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.M_.delete(3),await la(t)}async function Lc(n,e){const t=G(n);e?(t.M_.delete(2),await la(t)):e||(t.M_.add(2),await Ii(t),t.N_.set("Unknown"))}function er(n){return n.B_||(n.B_=function(t,s,r){const i=G(t);return i.f_(),new Rb(s,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(n.datastore,n.asyncQueue,{Po:Vb.bind(null,n),To:Nb.bind(null,n),Ao:xb.bind(null,n),h_:Ob.bind(null,n)}),n.x_.push(async e=>{e?(n.B_.t_(),Cl(n)?kl(n):n.N_.set("Unknown")):(await n.B_.stop(),Fm(n))})),n.B_}function vn(n){return n.k_||(n.k_=function(t,s,r){const i=G(t);return i.f_(),new Pb(s,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(n.datastore,n.asyncQueue,{Po:()=>Promise.resolve(),To:$b.bind(null,n),Ao:Bb.bind(null,n),R_:Fb.bind(null,n),A_:Ub.bind(null,n)}),n.x_.push(async e=>{e?(n.k_.t_(),await Zs(n)):(await n.k_.stop(),n.v_.length>0&&(D("RemoteStore",`Stopping write stream with ${n.v_.length} pending writes`),n.v_=[]))})),n.k_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dl{constructor(e,t,s,r,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=r,this.removalCallback=i,this.deferred=new hn,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,r,i){const o=Date.now()+s,c=new Dl(e,t,o,r,i);return c.start(s),c}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new F(C.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Vl(n,e){if(Te("AsyncQueue",`${e}: ${n}`),An(n))return new F(C.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(e){this.comparator=e?(t,s)=>e(t,s)||$.comparator(t.key,s.key):(t,s)=>$.comparator(t.key,s.key),this.keyedMap=Cr(),this.sortedSet=new pe(this.comparator)}static emptySet(e){return new As(e.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,s)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof As)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=s.getNext().key;if(!r.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new As;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nd{constructor(){this.q_=new pe($.comparator)}track(e){const t=e.doc.key,s=this.q_.get(t);s?e.type!==0&&s.type===3?this.q_=this.q_.insert(t,e):e.type===3&&s.type!==1?this.q_=this.q_.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.q_=this.q_.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.q_=this.q_.remove(t):e.type===1&&s.type===2?this.q_=this.q_.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):q():this.q_=this.q_.insert(t,e)}Q_(){const e=[];return this.q_.inorderTraversal((t,s)=>{e.push(s)}),e}}class Us{constructor(e,t,s,r,i,o,c,l,u){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=r,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=c,this.excludesMetadataChanges=l,this.hasCachedResults=u}static fromInitialDocuments(e,t,s,r,i){const o=[];return t.forEach(c=>{o.push({type:0,doc:c})}),new Us(e,t,As.emptySet(t),o,s,r,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&ta(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let r=0;r<t.length;r++)if(t[r].type!==s[r].type||!t[r].doc.isEqual(s[r].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qb{constructor(){this.K_=void 0,this.U_=[]}W_(){return this.U_.some(e=>e.G_())}}class jb{constructor(){this.queries=new Sn(e=>Fp(e),ta),this.onlineState="Unknown",this.z_=new Set}}async function Gb(n,e){const t=G(n);let s=3;const r=e.query;let i=t.queries.get(r);i?!i.W_()&&e.G_()&&(s=2):(i=new qb,s=e.G_()?0:1);try{switch(s){case 0:i.K_=await t.onListen(r,!0);break;case 1:i.K_=await t.onListen(r,!1);break;case 2:await t.onFirstRemoteStoreListen(r)}}catch(o){const c=Vl(o,`Initialization of query '${_s(e.query)}' failed`);return void e.onError(c)}t.queries.set(r,i),i.U_.push(e),e.j_(t.onlineState),i.K_&&e.H_(i.K_)&&Nl(t)}async function zb(n,e){const t=G(n),s=e.query;let r=3;const i=t.queries.get(s);if(i){const o=i.U_.indexOf(e);o>=0&&(i.U_.splice(o,1),i.U_.length===0?r=e.G_()?0:1:!i.W_()&&e.G_()&&(r=2))}switch(r){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function Kb(n,e){const t=G(n);let s=!1;for(const r of e){const i=r.query,o=t.queries.get(i);if(o){for(const c of o.U_)c.H_(r)&&(s=!0);o.K_=r}}s&&Nl(t)}function Wb(n,e,t){const s=G(n),r=s.queries.get(e);if(r)for(const i of r.U_)i.onError(t);s.queries.delete(e)}function Nl(n){n.z_.forEach(e=>{e.next()})}var Mc,xd;(xd=Mc||(Mc={})).J_="default",xd.Cache="cache";class Hb{constructor(e,t,s){this.query=e,this.Y_=t,this.Z_=!1,this.X_=null,this.onlineState="Unknown",this.options=s||{}}H_(e){if(!this.options.includeMetadataChanges){const s=[];for(const r of e.docChanges)r.type!==3&&s.push(r);e=new Us(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Z_?this.ea(e)&&(this.Y_.next(e),t=!0):this.ta(e,this.onlineState)&&(this.na(e),t=!0),this.X_=e,t}onError(e){this.Y_.error(e)}j_(e){this.onlineState=e;let t=!1;return this.X_&&!this.Z_&&this.ta(this.X_,e)&&(this.na(this.X_),t=!0),t}ta(e,t){if(!e.fromCache||!this.G_())return!0;const s=t!=="Offline";return(!this.options.ra||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}ea(e){if(e.docChanges.length>0)return!0;const t=this.X_&&this.X_.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}na(e){e=Us.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Z_=!0,this.Y_.next(e)}G_(){return this.options.source!==Mc.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jm{constructor(e){this.key=e}}class Gm{constructor(e){this.key=e}}class Qb{constructor(e,t){this.query=e,this.la=t,this.ha=null,this.hasCachedResults=!1,this.current=!1,this.Pa=te(),this.mutatedKeys=te(),this.Ia=Bp(e),this.Ta=new As(this.Ia)}get Ea(){return this.la}da(e,t){const s=t?t.Aa:new Nd,r=t?t.Ta:this.Ta;let i=t?t.mutatedKeys:this.mutatedKeys,o=r,c=!1;const l=this.query.limitType==="F"&&r.size===this.query.limit?r.last():null,u=this.query.limitType==="L"&&r.size===this.query.limit?r.first():null;if(e.inorderTraversal((f,p)=>{const y=r.get(f),S=_i(this.query,p)?p:null,k=!!y&&this.mutatedKeys.has(y.key),V=!!S&&(S.hasLocalMutations||this.mutatedKeys.has(S.key)&&S.hasCommittedMutations);let R=!1;y&&S?y.data.isEqual(S.data)?k!==V&&(s.track({type:3,doc:S}),R=!0):this.Ra(y,S)||(s.track({type:2,doc:S}),R=!0,(l&&this.Ia(S,l)>0||u&&this.Ia(S,u)<0)&&(c=!0)):!y&&S?(s.track({type:0,doc:S}),R=!0):y&&!S&&(s.track({type:1,doc:y}),R=!0,(l||u)&&(c=!0)),R&&(S?(o=o.add(S),i=V?i.add(f):i.delete(f)):(o=o.delete(f),i=i.delete(f)))}),this.query.limit!==null)for(;o.size>this.query.limit;){const f=this.query.limitType==="F"?o.last():o.first();o=o.delete(f.key),i=i.delete(f.key),s.track({type:1,doc:f})}return{Ta:o,Aa:s,Xi:c,mutatedKeys:i}}Ra(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,r){const i=this.Ta;this.Ta=e.Ta,this.mutatedKeys=e.mutatedKeys;const o=e.Aa.Q_();o.sort((f,p)=>function(S,k){const V=R=>{switch(R){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return q()}};return V(S)-V(k)}(f.type,p.type)||this.Ia(f.doc,p.doc)),this.Va(s),r=r!=null&&r;const c=t&&!r?this.ma():[],l=this.Pa.size===0&&this.current&&!r?1:0,u=l!==this.ha;return this.ha=l,o.length!==0||u?{snapshot:new Us(this.query,e.Ta,i,o,e.mutatedKeys,l===0,u,!1,!!s&&s.resumeToken.approximateByteSize()>0),fa:c}:{fa:c}}j_(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Ta:this.Ta,Aa:new Nd,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{fa:[]}}ga(e){return!this.la.has(e)&&!!this.Ta.has(e)&&!this.Ta.get(e).hasLocalMutations}Va(e){e&&(e.addedDocuments.forEach(t=>this.la=this.la.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.la=this.la.delete(t)),this.current=e.current)}ma(){if(!this.current)return[];const e=this.Pa;this.Pa=te(),this.Ta.forEach(s=>{this.ga(s.key)&&(this.Pa=this.Pa.add(s.key))});const t=[];return e.forEach(s=>{this.Pa.has(s)||t.push(new Gm(s))}),this.Pa.forEach(s=>{e.has(s)||t.push(new jm(s))}),t}pa(e){this.la=e.hs,this.Pa=te();const t=this.da(e.documents);return this.applyChanges(t,!0)}ya(){return Us.fromInitialDocuments(this.query,this.Ta,this.mutatedKeys,this.ha===0,this.hasCachedResults)}}class Jb{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class Yb{constructor(e){this.key=e,this.wa=!1}}class Xb{constructor(e,t,s,r,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.Sa={},this.ba=new Sn(c=>Fp(c),ta),this.Da=new Map,this.Ca=new Set,this.va=new pe($.comparator),this.Fa=new Map,this.Ma=new Tl,this.xa={},this.Oa=new Map,this.Na=ts.Ln(),this.onlineState="Unknown",this.La=void 0}get isPrimaryClient(){return this.La===!0}}async function Zb(n,e,t=!0){const s=ha(n);let r;const i=s.ba.get(e);return i?(s.sharedClientState.addLocalQueryTarget(i.targetId),r=i.view.ya()):r=await zm(s,e,t,!0),r}async function eT(n,e){const t=ha(n);await zm(t,e,!0,!1)}async function zm(n,e,t,s){const r=await No(n.localStore,ct(e)),i=r.targetId,o=t?n.sharedClientState.addLocalQueryTarget(i):"not-current";let c;return s&&(c=await xl(n,e,i,o==="current",r.resumeToken)),n.isPrimaryClient&&t&&ua(n.remoteStore,r),c}async function xl(n,e,t,s,r){n.Ba=(p,y,S)=>async function(V,R,B,z){let j=R.view.da(B);j.Xi&&(j=await xc(V.localStore,R.query,!1).then(({documents:I})=>R.view.da(I,j)));const Z=z&&z.targetChanges.get(R.targetId),N=z&&z.targetMismatches.get(R.targetId)!=null,M=R.view.applyChanges(j,V.isPrimaryClient,Z,N);return $c(V,R.targetId,M.fa),M.snapshot}(n,p,y,S);const i=await xc(n.localStore,e,!0),o=new Qb(e,i.hs),c=o.da(i.documents),l=vi.createSynthesizedTargetChangeForCurrentChange(t,s&&n.onlineState!=="Offline",r),u=o.applyChanges(c,n.isPrimaryClient,l);$c(n,t,u.fa);const f=new Jb(e,t,o);return n.ba.set(e,f),n.Da.has(t)?n.Da.get(t).push(e):n.Da.set(t,[e]),u.snapshot}async function tT(n,e,t){const s=G(n),r=s.ba.get(e),i=s.Da.get(r.targetId);if(i.length>1)return s.Da.set(r.targetId,i.filter(o=>!ta(o,e))),void s.ba.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(r.targetId),s.sharedClientState.isActiveQueryTarget(r.targetId)||await $s(s.localStore,r.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(r.targetId),t&&Fs(s.remoteStore,r.targetId),Bs(s,r.targetId)}).catch(Tn)):(Bs(s,r.targetId),await $s(s.localStore,r.targetId,!0))}async function nT(n,e){const t=G(n),s=t.ba.get(e),r=t.Da.get(s.targetId);t.isPrimaryClient&&r.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),Fs(t.remoteStore,s.targetId))}async function sT(n,e,t){const s=$l(n);try{const r=await function(o,c){const l=G(o),u=ve.now(),f=c.reduce((S,k)=>S.add(k.key),te());let p,y;return l.persistence.runTransaction("Locally write mutations","readwrite",S=>{let k=at(),V=te();return l.os.getEntries(S,f).next(R=>{k=R,k.forEach((B,z)=>{z.isValidDocument()||(V=V.add(B))})}).next(()=>l.localDocuments.getOverlayedDocuments(S,k)).next(R=>{p=R;const B=[];for(const z of c){const j=SE(z,p.get(z.key).overlayedDocument);j!=null&&B.push(new Gt(z.key,j,Cp(j.value.mapValue),Ye.exists(!0)))}return l.mutationQueue.addMutationBatch(S,u,B,c)}).next(R=>{y=R;const B=R.applyToLocalDocumentSet(p,V);return l.documentOverlayCache.saveOverlays(S,R.batchId,B)})}).then(()=>({batchId:y.batchId,changes:jp(p)}))}(s.localStore,e);s.sharedClientState.addPendingMutation(r.batchId),function(o,c,l){let u=o.xa[o.currentUser.toKey()];u||(u=new pe(X)),u=u.insert(c,l),o.xa[o.currentUser.toKey()]=u}(s,r.batchId,t),await Rn(s,r.changes),await Zs(s.remoteStore)}catch(r){const i=Vl(r,"Failed to persist write");t.reject(i)}}async function Km(n,e){const t=G(n);try{const s=await Ib(t.localStore,e);e.targetChanges.forEach((r,i)=>{const o=t.Fa.get(i);o&&(W(r.addedDocuments.size+r.modifiedDocuments.size+r.removedDocuments.size<=1),r.addedDocuments.size>0?o.wa=!0:r.modifiedDocuments.size>0?W(o.wa):r.removedDocuments.size>0&&(W(o.wa),o.wa=!1))}),await Rn(t,s,e)}catch(s){await Tn(s)}}function Od(n,e,t){const s=G(n);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const r=[];s.ba.forEach((i,o)=>{const c=o.view.j_(e);c.snapshot&&r.push(c.snapshot)}),function(o,c){const l=G(o);l.onlineState=c;let u=!1;l.queries.forEach((f,p)=>{for(const y of p.U_)y.j_(c)&&(u=!0)}),u&&Nl(l)}(s.eventManager,e),r.length&&s.Sa.h_(r),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function rT(n,e,t){const s=G(n);s.sharedClientState.updateQueryState(e,"rejected",t);const r=s.Fa.get(e),i=r&&r.key;if(i){let o=new pe($.comparator);o=o.insert(i,be.newNoDocument(i,H.min()));const c=te().add(i),l=new yi(H.min(),new Map,new pe(X),o,c);await Km(s,l),s.va=s.va.remove(i),s.Fa.delete(e),Ml(s)}else await $s(s.localStore,e,!1).then(()=>Bs(s,e,t)).catch(Tn)}async function iT(n,e){const t=G(n),s=e.batch.batchId;try{const r=await vb(t.localStore,e);Ll(t,s,null),Ol(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await Rn(t,r)}catch(r){await Tn(r)}}async function oT(n,e,t){const s=G(n);try{const r=await function(o,c){const l=G(o);return l.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let f;return l.mutationQueue.lookupMutationBatch(u,c).next(p=>(W(p!==null),f=p.keys(),l.mutationQueue.removeMutationBatch(u,p))).next(()=>l.mutationQueue.performConsistencyCheck(u)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(u,f,c)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,f)).next(()=>l.localDocuments.getDocuments(u,f))})}(s.localStore,e);Ll(s,e,t),Ol(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await Rn(s,r)}catch(r){await Tn(r)}}function Ol(n,e){(n.Oa.get(e)||[]).forEach(t=>{t.resolve()}),n.Oa.delete(e)}function Ll(n,e,t){const s=G(n);let r=s.xa[s.currentUser.toKey()];if(r){const i=r.get(e);i&&(t?i.reject(t):i.resolve(),r=r.remove(e)),s.xa[s.currentUser.toKey()]=r}}function Bs(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const s of n.Da.get(e))n.ba.delete(s),t&&n.Sa.ka(s,t);n.Da.delete(e),n.isPrimaryClient&&n.Ma.Vr(e).forEach(s=>{n.Ma.containsKey(s)||Wm(n,s)})}function Wm(n,e){n.Ca.delete(e.path.canonicalString());const t=n.va.get(e);t!==null&&(Fs(n.remoteStore,t),n.va=n.va.remove(e),n.Fa.delete(t),Ml(n))}function $c(n,e,t){for(const s of t)s instanceof jm?(n.Ma.addReference(s.key,e),aT(n,s)):s instanceof Gm?(D("SyncEngine","Document no longer in limbo: "+s.key),n.Ma.removeReference(s.key,e),n.Ma.containsKey(s.key)||Wm(n,s.key)):q()}function aT(n,e){const t=e.key,s=t.path.canonicalString();n.va.get(t)||n.Ca.has(s)||(D("SyncEngine","New document in limbo: "+t),n.Ca.add(s),Ml(n))}function Ml(n){for(;n.Ca.size>0&&n.va.size<n.maxConcurrentLimboResolutions;){const e=n.Ca.values().next().value;n.Ca.delete(e);const t=new $(le.fromString(e)),s=n.Na.next();n.Fa.set(s,new Yb(t)),n.va=n.va.insert(t,s),ua(n.remoteStore,new $t(ct(ea(t.path)),s,"TargetPurposeLimboResolution",st.oe))}}async function Rn(n,e,t){const s=G(n),r=[],i=[],o=[];s.ba.isEmpty()||(s.ba.forEach((c,l)=>{o.push(s.Ba(l,e,t).then(u=>{if((u||t)&&s.isPrimaryClient){const f=u&&!u.fromCache;s.sharedClientState.updateQueryState(l.targetId,f?"current":"not-current")}if(u){r.push(u);const f=Sl.Ki(l.targetId,u);i.push(f)}}))}),await Promise.all(o),s.Sa.h_(r),await async function(l,u){const f=G(l);try{await f.persistence.runTransaction("notifyLocalViewChanges","readwrite",p=>A.forEach(u,y=>A.forEach(y.qi,S=>f.persistence.referenceDelegate.addReference(p,y.targetId,S)).next(()=>A.forEach(y.Qi,S=>f.persistence.referenceDelegate.removeReference(p,y.targetId,S)))))}catch(p){if(!An(p))throw p;D("LocalStore","Failed to update sequence numbers: "+p)}for(const p of u){const y=p.targetId;if(!p.fromCache){const S=f.ns.get(y),k=S.snapshotVersion,V=S.withLastLimboFreeSnapshotVersion(k);f.ns=f.ns.insert(y,V)}}}(s.localStore,i))}async function cT(n,e){const t=G(n);if(!t.currentUser.isEqual(e)){D("SyncEngine","User change. New user:",e.toKey());const s=await km(t.localStore,e);t.currentUser=e,function(i,o){i.Oa.forEach(c=>{c.forEach(l=>{l.reject(new F(C.CANCELLED,o))})}),i.Oa.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await Rn(t,s.us)}}function lT(n,e){const t=G(n),s=t.Fa.get(e);if(s&&s.wa)return te().add(s.key);{let r=te();const i=t.Da.get(e);if(!i)return r;for(const o of i){const c=t.ba.get(o);r=r.unionWith(c.view.Ea)}return r}}async function uT(n,e){const t=G(n),s=await xc(t.localStore,e.query,!0),r=e.view.pa(s);return t.isPrimaryClient&&$c(t,e.targetId,r.fa),r}async function hT(n,e){const t=G(n);return Vm(t.localStore,e).then(s=>Rn(t,s))}async function dT(n,e,t,s){const r=G(n),i=await function(c,l){const u=G(c),f=G(u.mutationQueue);return u.persistence.runTransaction("Lookup mutation documents","readonly",p=>f.vn(p,l).next(y=>y?u.localDocuments.getDocuments(p,y):A.resolve(null)))}(r.localStore,e);i!==null?(t==="pending"?await Zs(r.remoteStore):t==="acknowledged"||t==="rejected"?(Ll(r,e,s||null),Ol(r,e),function(c,l){G(G(c).mutationQueue).Mn(l)}(r.localStore,e)):q(),await Rn(r,i)):D("SyncEngine","Cannot apply mutation batch with id: "+e)}async function fT(n,e){const t=G(n);if(ha(t),$l(t),e===!0&&t.La!==!0){const s=t.sharedClientState.getAllActiveQueryTargets(),r=await Ld(t,s.toArray());t.La=!0,await Lc(t.remoteStore,!0);for(const i of r)ua(t.remoteStore,i)}else if(e===!1&&t.La!==!1){const s=[];let r=Promise.resolve();t.Da.forEach((i,o)=>{t.sharedClientState.isLocalQueryTarget(o)?s.push(o):r=r.then(()=>(Bs(t,o),$s(t.localStore,o,!0))),Fs(t.remoteStore,o)}),await r,await Ld(t,s),function(o){const c=G(o);c.Fa.forEach((l,u)=>{Fs(c.remoteStore,u)}),c.Ma.mr(),c.Fa=new Map,c.va=new pe($.comparator)}(t),t.La=!1,await Lc(t.remoteStore,!1)}}async function Ld(n,e,t){const s=G(n),r=[],i=[];for(const o of e){let c;const l=s.Da.get(o);if(l&&l.length!==0){c=await No(s.localStore,ct(l[0]));for(const u of l){const f=s.ba.get(u),p=await uT(s,f);p.snapshot&&i.push(p.snapshot)}}else{const u=await Dm(s.localStore,o);c=await No(s.localStore,u),await xl(s,Hm(u),o,!1,c.resumeToken)}r.push(c)}return s.Sa.h_(i),r}function Hm(n){return $p(n.path,n.collectionGroup,n.orderBy,n.filters,n.limit,"F",n.startAt,n.endAt)}function pT(n){return function(t){return G(G(t).persistence).Bi()}(G(n).localStore)}async function mT(n,e,t,s){const r=G(n);if(r.La)return void D("SyncEngine","Ignoring unexpected query state notification.");const i=r.Da.get(e);if(i&&i.length>0)switch(t){case"current":case"not-current":{const o=await Vm(r.localStore,Up(i[0])),c=yi.createSynthesizedRemoteEventForCurrentChange(e,t==="current",Oe.EMPTY_BYTE_STRING);await Rn(r,o,c);break}case"rejected":await $s(r.localStore,e,!0),Bs(r,e,s);break;default:q()}}async function gT(n,e,t){const s=ha(n);if(s.La){for(const r of e){if(s.Da.has(r)&&s.sharedClientState.isActiveQueryTarget(r)){D("SyncEngine","Adding an already active target "+r);continue}const i=await Dm(s.localStore,r),o=await No(s.localStore,i);await xl(s,Hm(i),o.targetId,!1,o.resumeToken),ua(s.remoteStore,o)}for(const r of t)s.Da.has(r)&&await $s(s.localStore,r,!1).then(()=>{Fs(s.remoteStore,r),Bs(s,r)}).catch(Tn)}}function ha(n){const e=G(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Km.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=lT.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=rT.bind(null,e),e.Sa.h_=Kb.bind(null,e.eventManager),e.Sa.ka=Wb.bind(null,e.eventManager),e}function $l(n){const e=G(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=iT.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=oT.bind(null,e),e}class Fc{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=ca(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){return Pm(this.persistence,new Rm,e.initialUser,this.serializer)}createPersistence(e){return new Am(aa.Hr,this.serializer)}createSharedClientState(e){return new xm}async terminate(){var e,t;(e=this.gcScheduler)===null||e===void 0||e.stop(),(t=this.indexBackfillerScheduler)===null||t===void 0||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class Qm extends Fc{constructor(e,t,s){super(),this.Qa=e,this.cacheSizeBytes=t,this.forceOwnership=s,this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Qa.initialize(this,e),await $l(this.Qa.syncEngine),await Zs(this.Qa.remoteStore),await this.persistence.fi(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}createLocalStore(e){return Pm(this.persistence,new Rm,e.initialUser,this.serializer)}createGarbageCollectionScheduler(e,t){const s=this.persistence.referenceDelegate.garbageCollector;return new nb(s,e.asyncQueue,t)}createIndexBackfillerScheduler(e,t){const s=new Ow(t,this.persistence);return new xw(e.asyncQueue,s)}createPersistence(e){const t=Sm(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),s=this.cacheSizeBytes!==void 0?nt.withCacheSize(this.cacheSizeBytes):nt.DEFAULT;return new Al(this.synchronizeTabs,t,e.clientId,s,e.asyncQueue,Om(),ho(),this.serializer,this.sharedClientState,!!this.forceOwnership)}createSharedClientState(e){return new xm}}class _T extends Qm{constructor(e,t){super(e,t,!1),this.Qa=e,this.cacheSizeBytes=t,this.synchronizeTabs=!0}async initialize(e){await super.initialize(e);const t=this.Qa.syncEngine;this.sharedClientState instanceof nc&&(this.sharedClientState.syncEngine={Zs:dT.bind(null,t),Xs:mT.bind(null,t),eo:gT.bind(null,t),Bi:pT.bind(null,t),Ys:hT.bind(null,t)},await this.sharedClientState.start()),await this.persistence.fi(async s=>{await fT(this.Qa.syncEngine,s),this.gcScheduler&&(s&&!this.gcScheduler.started?this.gcScheduler.start():s||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(s&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():s||this.indexBackfillerScheduler.stop())})}createSharedClientState(e){const t=Om();if(!nc.D(t))throw new F(C.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const s=Sm(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey);return new nc(t,e.asyncQueue,s,e.clientId,e.initialUser)}}class Fl{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>Od(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=cT.bind(null,this.syncEngine),await Lc(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new jb}()}createDatastore(e){const t=ca(e.databaseInfo.databaseId),s=function(i){return new Sb(i)}(e.databaseInfo);return function(i,o,c,l){return new kb(i,o,c,l)}(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return function(s,r,i,o,c){return new Db(s,r,i,o,c)}(this.localStore,this.datastore,e.asyncQueue,t=>Od(this.syncEngine,t,0),function(){return Dd.D()?new Dd:new bb}())}createSyncEngine(e,t){return function(r,i,o,c,l,u,f){const p=new Xb(r,i,o,c,l,u);return f&&(p.La=!0),p}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e;await async function(s){const r=G(s);D("RemoteStore","RemoteStore shutting down."),r.M_.add(5),await Ii(r),r.O_.shutdown(),r.N_.set("Unknown")}(this.remoteStore),(e=this.datastore)===null||e===void 0||e.terminate()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yT{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Ka(this.observer.next,e)}error(e){this.observer.error?this.Ka(this.observer.error,e):Te("Uncaught Error in snapshot listener:",e.toString())}$a(){this.muted=!0}Ka(e,t){this.muted||setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vT{constructor(e,t,s,r){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this.databaseInfo=r,this.user=Ke.UNAUTHENTICATED,this.clientId=pp.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(s,async i=>{D("FirestoreClient","Received user=",i.uid),await this.authCredentialListener(i),this.user=i}),this.appCheckCredentials.start(s,i=>(D("FirestoreClient","Received new app check token=",i),this.appCheckCredentialListener(i,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new F(C.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const e=new hn;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=Vl(t,"Failed to shutdown persistence");e.reject(s)}}),e.promise}}async function rc(n,e){n.asyncQueue.verifyOperationInProgress(),D("FirestoreClient","Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let s=t.initialUser;n.setCredentialChangeListener(async r=>{s.isEqual(r)||(await km(e.localStore,r),s=r)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function Md(n,e){n.asyncQueue.verifyOperationInProgress();const t=await wT(n);D("FirestoreClient","Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(s=>Vd(e.remoteStore,s)),n.setAppCheckTokenChangeListener((s,r)=>Vd(e.remoteStore,r)),n._onlineComponents=e}function IT(n){return n.name==="FirebaseError"?n.code===C.FAILED_PRECONDITION||n.code===C.UNIMPLEMENTED:!(typeof DOMException<"u"&&n instanceof DOMException)||n.code===22||n.code===20||n.code===11}async function wT(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){D("FirestoreClient","Using user provided OfflineComponentProvider");try{await rc(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!IT(t))throw t;Hr("Error using user provided cache. Falling back to memory cache: "+t),await rc(n,new Fc)}}else D("FirestoreClient","Using default OfflineComponentProvider"),await rc(n,new Fc);return n._offlineComponents}async function Jm(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(D("FirestoreClient","Using user provided OnlineComponentProvider"),await Md(n,n._uninitializedComponentsProvider._online)):(D("FirestoreClient","Using default OnlineComponentProvider"),await Md(n,new Fl))),n._onlineComponents}function ET(n){return Jm(n).then(e=>e.syncEngine)}async function $d(n){const e=await Jm(n),t=e.eventManager;return t.onListen=Zb.bind(null,e.syncEngine),t.onUnlisten=tT.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=eT.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=nT.bind(null,e.syncEngine),t}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ym(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fd=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xm(n,e,t){if(!t)throw new F(C.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function bT(n,e,t,s){if(e===!0&&s===!0)throw new F(C.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Ud(n){if(!$.isDocumentKey(n))throw new F(C.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Bd(n){if($.isDocumentKey(n))throw new F(C.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Ul(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(s){return s.constructor?s.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":q()}function fn(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new F(C.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=Ul(n);throw new F(C.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qd{constructor(e){var t,s;if(e.host===void 0){if(e.ssl!==void 0)throw new F(C.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(t=e.ssl)===null||t===void 0||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new F(C.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}bT("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Ym((s=e.experimentalLongPollingOptions)!==null&&s!==void 0?s:{}),function(i){if(i.timeoutSeconds!==void 0){if(isNaN(i.timeoutSeconds))throw new F(C.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (must not be NaN)`);if(i.timeoutSeconds<5)throw new F(C.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (minimum allowed value is 5)`);if(i.timeoutSeconds>30)throw new F(C.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(s,r){return s.timeoutSeconds===r.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Bl{constructor(e,t,s,r){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new qd({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new F(C.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(e){if(this._settingsFrozen)throw new F(C.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new qd(e),e.credentials!==void 0&&(this._authCredentials=function(s){if(!s)return new Tw;switch(s.type){case"firstParty":return new Rw(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new F(C.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const s=Fd.get(t);s&&(D("ComponentProvider","Removing Datastore"),Fd.delete(t),s.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class da{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new da(this.firestore,e,this._query)}}class it{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new pn(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new it(this.firestore,e,this._key)}}class pn extends da{constructor(e,t,s){super(e,t,ea(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new it(this.firestore,null,new $(e))}withConverter(e){return new pn(this.firestore,e,this._path)}}function jd(n,e,...t){if(n=xe(n),Xm("collection","path",e),n instanceof Bl){const s=le.fromString(e,...t);return Bd(s),new pn(n,null,s)}{if(!(n instanceof it||n instanceof pn))throw new F(C.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(le.fromString(e,...t));return Bd(s),new pn(n.firestore,null,s)}}function wi(n,e,...t){if(n=xe(n),arguments.length===1&&(e=pp.newId()),Xm("doc","path",e),n instanceof Bl){const s=le.fromString(e,...t);return Ud(s),new it(n,null,new $(s))}{if(!(n instanceof it||n instanceof pn))throw new F(C.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(le.fromString(e,...t));return Ud(s),new it(n.firestore,n instanceof pn?n.converter:null,new $(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TT{constructor(){this.iu=Promise.resolve(),this.su=[],this.ou=!1,this._u=[],this.au=null,this.uu=!1,this.cu=!1,this.lu=[],this.Yo=new Lm(this,"async_queue_retry"),this.hu=()=>{const t=ho();t&&D("AsyncQueue","Visibility state changed to "+t.visibilityState),this.Yo.Wo()};const e=ho();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.hu)}get isShuttingDown(){return this.ou}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Pu(),this.Iu(e)}enterRestrictedMode(e){if(!this.ou){this.ou=!0,this.cu=e||!1;const t=ho();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.hu)}}enqueue(e){if(this.Pu(),this.ou)return new Promise(()=>{});const t=new hn;return this.Iu(()=>this.ou&&this.cu?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.su.push(e),this.Tu()))}async Tu(){if(this.su.length!==0){try{await this.su[0](),this.su.shift(),this.Yo.reset()}catch(e){if(!An(e))throw e;D("AsyncQueue","Operation failed with retryable error: "+e)}this.su.length>0&&this.Yo.$o(()=>this.Tu())}}Iu(e){const t=this.iu.then(()=>(this.uu=!0,e().catch(s=>{this.au=s,this.uu=!1;const r=function(o){let c=o.message||"";return o.stack&&(c=o.stack.includes(o.message)?o.stack:o.message+`
`+o.stack),c}(s);throw Te("INTERNAL UNHANDLED ERROR: ",r),s}).then(s=>(this.uu=!1,s))));return this.iu=t,t}enqueueAfterDelay(e,t,s){this.Pu(),this.lu.indexOf(e)>-1&&(t=0);const r=Dl.createAndSchedule(this,e,t,s,i=>this.Eu(i));return this._u.push(r),r}Pu(){this.au&&q()}verifyOperationInProgress(){}async du(){let e;do e=this.iu,await e;while(e!==this.iu)}Au(e){for(const t of this._u)if(t.timerId===e)return!0;return!1}Ru(e){return this.du().then(()=>{this._u.sort((t,s)=>t.targetTimeMs-s.targetTimeMs);for(const t of this._u)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.du()})}Vu(e){this.lu.push(e)}Eu(e){const t=this._u.indexOf(e);this._u.splice(t,1)}}function Gd(n){return function(t,s){if(typeof t!="object"||t===null)return!1;const r=t;for(const i of s)if(i in r&&typeof r[i]=="function")return!0;return!1}(n,["next","error","complete"])}class qs extends Bl{constructor(e,t,s,r){super(e,t,s,r),this.type="firestore",this._queue=function(){return new TT}(),this._persistenceKey=(r==null?void 0:r.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||eg(this),this._firestoreClient.terminate()}}function AT(n,e,t){t||(t="(default)");const s=Zc(n,"firestore");if(s.isInitialized(t)){const r=s.getImmediate({identifier:t}),i=s.getOptions(t);if(Gr(i,e))return r;throw new F(C.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new F(C.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new F(C.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return s.initialize({options:e,instanceIdentifier:t})}function Zm(n){return n._firestoreClient||eg(n),n._firestoreClient.verifyNotTerminated(),n._firestoreClient}function eg(n){var e,t,s;const r=n._freezeSettings(),i=function(c,l,u,f){return new tE(c,l,u,f.host,f.ssl,f.experimentalForceLongPolling,f.experimentalAutoDetectLongPolling,Ym(f.experimentalLongPollingOptions),f.useFetchStreams)}(n._databaseId,((e=n._app)===null||e===void 0?void 0:e.options.appId)||"",n._persistenceKey,r);n._firestoreClient=new vT(n._authCredentials,n._appCheckCredentials,n._queue,i),!((t=r.localCache)===null||t===void 0)&&t._offlineComponentProvider&&(!((s=r.localCache)===null||s===void 0)&&s._onlineComponentProvider)&&(n._firestoreClient._uninitializedComponentsProvider={_offlineKind:r.localCache.kind,_offline:r.localCache._offlineComponentProvider,_online:r.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class js{constructor(e){this._byteString=e}static fromBase64String(e){try{return new js(Oe.fromBase64String(e))}catch(t){throw new F(C.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new js(Oe.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fa{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new F(C.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new ye(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ql{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jl{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new F(C.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new F(C.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return X(this._lat,e._lat)||X(this._long,e._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ST=/^__.*__$/;class RT{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new Gt(e,this.data,this.fieldMask,t,this.fieldTransforms):new Xs(e,this.data,t,this.fieldTransforms)}}class tg{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new Gt(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function ng(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw q()}}class Gl{constructor(e,t,s,r,i,o){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=r,i===void 0&&this.mu(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get fu(){return this.settings.fu}gu(e){return new Gl(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}pu(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),r=this.gu({path:s,yu:!1});return r.wu(e),r}Su(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),r=this.gu({path:s,yu:!1});return r.mu(),r}bu(e){return this.gu({path:void 0,yu:!0})}Du(e){return Mo(e,this.settings.methodName,this.settings.Cu||!1,this.path,this.settings.vu)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}mu(){if(this.path)for(let e=0;e<this.path.length;e++)this.wu(this.path.get(e))}wu(e){if(e.length===0)throw this.Du("Document fields must not be empty");if(ng(this.fu)&&ST.test(e))throw this.Du('Document fields cannot begin and end with "__"')}}class PT{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||ca(e)}Fu(e,t,s,r=!1){return new Gl({fu:e,methodName:t,vu:s,path:ye.emptyPath(),yu:!1,Cu:r},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function sg(n){const e=n._freezeSettings(),t=ca(n._databaseId);return new PT(n._databaseId,!!e.ignoreUndefinedProperties,t)}function kT(n,e,t,s,r,i={}){const o=n.Fu(i.merge||i.mergeFields?2:0,e,t,r);zl("Data must be an object, but it was:",o,s);const c=rg(s,o);let l,u;if(i.merge)l=new rt(o.fieldMask),u=o.fieldTransforms;else if(i.mergeFields){const f=[];for(const p of i.mergeFields){const y=Uc(e,p,t);if(!o.contains(y))throw new F(C.INVALID_ARGUMENT,`Field '${y}' is specified in your field mask but missing from your input data.`);og(f,y)||f.push(y)}l=new rt(f),u=o.fieldTransforms.filter(p=>l.covers(p.field))}else l=null,u=o.fieldTransforms;return new RT(new We(c),l,u)}class Ei extends ql{_toFieldTransform(e){if(e.fu!==2)throw e.fu===1?e.Du(`${this._methodName}() can only appear at the top level of your update data`):e.Du(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Ei}}function CT(n,e,t,s){const r=n.Fu(1,e,t);zl("Data must be an object, but it was:",r,s);const i=[],o=We.empty();rs(s,(l,u)=>{const f=Kl(e,l,t);u=xe(u);const p=r.Su(f);if(u instanceof Ei)i.push(f);else{const y=pa(u,p);y!=null&&(i.push(f),o.set(f,y))}});const c=new rt(i);return new tg(o,c,r.fieldTransforms)}function DT(n,e,t,s,r,i){const o=n.Fu(1,e,t),c=[Uc(e,s,t)],l=[r];if(i.length%2!=0)throw new F(C.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let y=0;y<i.length;y+=2)c.push(Uc(e,i[y])),l.push(i[y+1]);const u=[],f=We.empty();for(let y=c.length-1;y>=0;--y)if(!og(u,c[y])){const S=c[y];let k=l[y];k=xe(k);const V=o.Su(S);if(k instanceof Ei)u.push(S);else{const R=pa(k,V);R!=null&&(u.push(S),f.set(S,R))}}const p=new rt(u);return new tg(f,p,o.fieldTransforms)}function pa(n,e){if(ig(n=xe(n)))return zl("Unsupported field value:",e,n),rg(n,e);if(n instanceof ql)return function(s,r){if(!ng(r.fu))throw r.Du(`${s._methodName}() can only be used with update() and set()`);if(!r.path)throw r.Du(`${s._methodName}() is not currently supported inside arrays`);const i=s._toFieldTransform(r);i&&r.fieldTransforms.push(i)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.yu&&e.fu!==4)throw e.Du("Nested arrays are not supported");return function(s,r){const i=[];let o=0;for(const c of s){let l=pa(c,r.bu(o));l==null&&(l={nullValue:"NULL_VALUE"}),i.push(l),o++}return{arrayValue:{values:i}}}(n,e)}return function(s,r){if((s=xe(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return vE(r.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const i=ve.fromDate(s);return{timestampValue:Ms(r.serializer,i)}}if(s instanceof ve){const i=new ve(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:Ms(r.serializer,i)}}if(s instanceof jl)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof js)return{bytesValue:sm(r.serializer,s._byteString)};if(s instanceof it){const i=r.databaseId,o=s.firestore._databaseId;if(!o.isEqual(i))throw r.Du(`Document reference is for database ${o.projectId}/${o.database} but should be for database ${i.projectId}/${i.database}`);return{referenceValue:wl(s.firestore._databaseId||r.databaseId,s._key.path)}}throw r.Du(`Unsupported field value: ${Ul(s)}`)}(n,e)}function rg(n,e){const t={};return Rp(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):rs(n,(s,r)=>{const i=pa(r,e.pu(s));i!=null&&(t[s]=i)}),{mapValue:{fields:t}}}function ig(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof ve||n instanceof jl||n instanceof js||n instanceof it||n instanceof ql)}function zl(n,e,t){if(!ig(t)||!function(r){return typeof r=="object"&&r!==null&&(Object.getPrototypeOf(r)===Object.prototype||Object.getPrototypeOf(r)===null)}(t)){const s=Ul(t);throw s==="an object"?e.Du(n+" a custom object"):e.Du(n+" "+s)}}function Uc(n,e,t){if((e=xe(e))instanceof fa)return e._internalPath;if(typeof e=="string")return Kl(n,e);throw Mo("Field path arguments must be of type string or ",n,!1,void 0,t)}const VT=new RegExp("[~\\*/\\[\\]]");function Kl(n,e,t){if(e.search(VT)>=0)throw Mo(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new fa(...e.split("."))._internalPath}catch{throw Mo(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Mo(n,e,t,s,r){const i=s&&!s.isEmpty(),o=r!==void 0;let c=`Function ${e}() called with invalid data`;t&&(c+=" (via `toFirestore()`)"),c+=". ";let l="";return(i||o)&&(l+=" (found",i&&(l+=` in field ${s}`),o&&(l+=` in document ${r}`),l+=")"),new F(C.INVALID_ARGUMENT,c+n+l)}function og(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ag{constructor(e,t,s,r,i){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new it(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new NT(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field(cg("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class NT extends ag{data(){return super.data()}}function cg(n,e){return typeof e=="string"?Kl(n,e):e instanceof fa?e._internalPath:e._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xT(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new F(C.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class OT{convertValue(e,t="none"){switch(Yn(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Ee(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(_n(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw q()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return rs(e,(r,i)=>{s[r]=this.convertValue(i,t)}),s}convertGeoPoint(e){return new jl(Ee(e.latitude),Ee(e.longitude))}convertArray(e,t){return(e.values||[]).map(s=>this.convertValue(s,t))}convertServerTimestamp(e,t){switch(t){case"previous":const s=fl(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(Xr(e));default:return null}}convertTimestamp(e){const t=qt(e);return new ve(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=le.fromString(e);W(fm(s));const r=new Jn(s.get(1),s.get(3)),i=new $(s.popFirst(5));return r.isEqual(t)||Te(`Document ${i} contains a document reference within a different database (${r.projectId}/${r.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function LT(n,e,t){let s;return s=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nr{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class lg extends ag{constructor(e,t,s,r,i,o){super(e,t,s,r,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new fo(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field(cg("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}}class fo extends lg{data(e={}){return super.data(e)}}class MT{constructor(e,t,s,r){this._firestore=e,this._userDataWriter=t,this._snapshot=r,this.metadata=new Nr(r.hasPendingWrites,r.fromCache),this.query=s}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(s=>{e.call(t,new fo(this._firestore,this._userDataWriter,s.key,s,new Nr(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new F(C.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(r,i){if(r._snapshot.oldDocs.isEmpty()){let o=0;return r._snapshot.docChanges.map(c=>{const l=new fo(r._firestore,r._userDataWriter,c.doc.key,c.doc,new Nr(r._snapshot.mutatedKeys.has(c.doc.key),r._snapshot.fromCache),r.query.converter);return c.doc,{type:"added",doc:l,oldIndex:-1,newIndex:o++}})}{let o=r._snapshot.oldDocs;return r._snapshot.docChanges.filter(c=>i||c.type!==3).map(c=>{const l=new fo(r._firestore,r._userDataWriter,c.doc.key,c.doc,new Nr(r._snapshot.mutatedKeys.has(c.doc.key),r._snapshot.fromCache),r.query.converter);let u=-1,f=-1;return c.type!==0&&(u=o.indexOf(c.doc.key),o=o.delete(c.doc.key)),c.type!==1&&(o=o.add(c.doc),f=o.indexOf(c.doc.key)),{type:$T(c.type),doc:l,oldIndex:u,newIndex:f}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function $T(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return q()}}class ug extends OT{constructor(e){super(),this.firestore=e}convertBytes(e){return new js(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new it(this.firestore,null,t)}}function Wl(n,e,t){n=fn(n,it);const s=fn(n.firestore,qs),r=LT(n.converter,e,t);return Hl(s,[kT(sg(s),"setDoc",n._key,r,n.converter!==null,t).toMutation(n._key,Ye.none())])}function FT(n,e,t,...s){n=fn(n,it);const r=fn(n.firestore,qs),i=sg(r);let o;return o=typeof(e=xe(e))=="string"||e instanceof fa?DT(i,"updateDoc",n._key,e,t,s):CT(i,"updateDoc",n._key,e),Hl(r,[o.toMutation(n._key,Ye.exists(!0))])}function UT(n){return Hl(fn(n.firestore,qs),[new ra(n._key,Ye.none())])}function zd(n,...e){var t,s,r;n=xe(n);let i={includeMetadataChanges:!1,source:"default"},o=0;typeof e[o]!="object"||Gd(e[o])||(i=e[o],o++);const c={includeMetadataChanges:i.includeMetadataChanges,source:i.source};if(Gd(e[o])){const p=e[o];e[o]=(t=p.next)===null||t===void 0?void 0:t.bind(p),e[o+1]=(s=p.error)===null||s===void 0?void 0:s.bind(p),e[o+2]=(r=p.complete)===null||r===void 0?void 0:r.bind(p)}let l,u,f;if(n instanceof it)u=fn(n.firestore,qs),f=ea(n._key.path),l={next:p=>{e[o]&&e[o](BT(u,n,p))},error:e[o+1],complete:e[o+2]};else{const p=fn(n,da);u=fn(p.firestore,qs),f=p._query;const y=new ug(u);l={next:S=>{e[o]&&e[o](new MT(u,y,p,S))},error:e[o+1],complete:e[o+2]},xT(n._query)}return function(y,S,k,V){const R=new yT(V),B=new Hb(S,R,k);return y.asyncQueue.enqueueAndForget(async()=>Gb(await $d(y),B)),()=>{R.$a(),y.asyncQueue.enqueueAndForget(async()=>zb(await $d(y),B))}}(Zm(u),f,c,l)}function Hl(n,e){return function(s,r){const i=new hn;return s.asyncQueue.enqueueAndForget(async()=>sT(await ET(s),r,i)),i.promise}(Zm(n),e)}function BT(n,e,t){const s=t.docs.get(e._key),r=new ug(n);return new lg(n,r,e._key,s,new Nr(t.hasPendingWrites,t.fromCache),e.converter)}class qT{constructor(e){let t;this.kind="persistent",e!=null&&e.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=KT(),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function jT(n){return new qT(n)}class GT{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Fl,this._offlineComponentProvider=new Qm(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes,this.forceOwnership)}}class zT{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Fl,this._offlineComponentProvider=new _T(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes)}}function KT(n){return new GT(void 0)}function WT(){return new zT}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hg(){return new Ei("deleteField")}(function(e,t=!0){(function(r){Ys=r})(Hs),ks(new Kn("firestore",(s,{instanceIdentifier:r,options:i})=>{const o=s.getProvider("app").getImmediate(),c=new qs(new Aw(s.getProvider("auth-internal")),new kw(s.getProvider("app-check-internal")),function(u,f){if(!Object.prototype.hasOwnProperty.apply(u.options,["projectId"]))throw new F(C.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Jn(u.options.projectId,f)}(o,r),o);return i=Object.assign({useFetchStreams:t},i),c._setSettings(i),c},"PUBLIC").setMultipleInstances(!0)),ln(Fh,"4.6.3",e),ln(Fh,"4.6.3","esm2017")})();const Bc={apiKey:"AIzaSyC9Um4cxmF3LT_f9Ade5gYSj4ZjMbPHZU4",authDomain:"cursing-offers.firebaseapp.com",projectId:"cursing-offers",storageBucket:"cursing-offers.firebasestorage.app",messagingSenderId:"782347533500",appId:"1:782347533500:web:5da31b9357632fc055a4b9"};function HT(){const n=Date.now(),e=864e5,t=new Date().toISOString().slice(0,10),s=(i,o,c)=>({desc:i,qty:o,price:c,disc:0}),r=(i,o,c,l,u,f,p,y,S,k)=>({id:i,number:o,ts:n-S*e,date:new Date(n-S*e).toISOString().slice(0,10),customer:{name:c,phone:l,email:"",afm:"",address:u},subject:f,status:p,total:y,vatMode:"on",lines:k});return{quotes:[r("q1","2311","Γιώργος Παπαδόπουλος","6900000001","Πρέβεζα","Εγκατάσταση CCTV και WiFi","accepted",1437.16,3,[s("Hikvision IP 4MP Bullet",4,89),s("NVR 8 καναλιών + 2TB",1,245),s("UniFi U6 Lite",2,119),s("Εργασία εγκατάστασης",1,320)]),r("q2","2310","Hotel Aktaion","6900000002","Βόνιτσα","WiFi ξενοδοχείου 40 δωμάτια","pending",6920,5,[s("UniFi U6+",20,159),s("Switch PoE 24 θυρών",1,420),s("Εργασία",1,1700)]),r("q3","2309","Μαρία Νικολάου","6900000003","Λευκάδα","Συναγερμός Paradox","done",780,40,[s("Paradox MG5050 set",1,480),s("Εργασία",1,149)]),r("q4","2307","Κώστας Δήμου","6900000004","Πρέβεζα","Κάμερες καταστήματος","rejected",1150,12,[s("Dahua 4MP Dome",6,95),s("Εργασία",1,357)]),r("q5","2306","Σταύρος Σταύρου","6900000005","Πάλαιρος","Θυροτηλέφωνο + κάμερα","pending",540,1,[s("Θυροτηλέφωνο IP",1,290),s("Εργασία",1,145)])],products:[{id:"p1",cat:"Κάμερες",model:"Hikvision IP 4MP Bullet",desc:"DS-2CD2043",cost:71.2},{id:"p2",cat:"Κάμερες",model:"Dahua 4MP Dome",desc:"",cost:76},{id:"p3",cat:"Καταγραφικά",model:"NVR 8 καναλιών",desc:"με δίσκο 2TB",cost:196},{id:"p4",cat:"WiFi",model:"UniFi U6 Lite",desc:"Access Point",cost:95.2},{id:"p5",cat:"WiFi",model:"UniFi U6+",desc:"",cost:127.2},{id:"p6",cat:"Συναγερμοί",model:"Paradox MG5050",desc:"set",cost:384}],smoves:[{id:"m1",pid:"p1",qty:6}],custs:[{id:"c1",name:"Γιώργος Παπαδόπουλος",phone:"6900000001",address:"Πρέβεζα",ts:n-30*e}],tasks:[{id:"t1",title:"Εγκατάσταση CCTV",date:t,time:"09:00",cust:"Γιώργος Παπαδόπουλος",tel:"6900000001",addr:"Πρέβεζα",emps:["e1"],rems:[60,0],done:!1,chk:[{tx:"4 κάμερες",dn:!0},{tx:"NVR + δίσκος",dn:!1},{tx:"Ρύθμιση εφαρμογής",dn:!1}],quoteId:"q1"},{id:"t2",title:"Αυτοψία WiFi ξενοδοχείου",date:t,time:"13:30",cust:"Hotel Aktaion",addr:"Βόνιτσα",done:!1,clr:9},{id:"t3",title:"Service συναγερμού",date:t,time:"17:00",cust:"Μαρία Νικολάου",addr:"Λευκάδα",done:!0},{id:"t4",title:"Ασφάλεια βαν",kind:"due",rep:"y",date:new Date(n+5*e).toISOString().slice(0,10),done:!1,rems:[1440,0]},{id:"t5",title:"Παραγγελία Xpatit",date:new Date(n-2*e).toISOString().slice(0,10),done:!1},{id:"t6",title:"Τηλέφωνο σε Σταύρο για θυροτηλέφωνο",date:"",done:!1},{id:"t7",title:"Συνδρομή Starlink",kind:"due",rep:"m",date:new Date(n+9*e).toISOString().slice(0,10),done:!1},{id:"t8",title:"Εγκατάσταση WiFi",date:new Date(n+e).toISOString().slice(0,10),time:"10:00",cust:"Hotel Aktaion",addr:"Βόνιτσα",emps:["e1"],done:!1}],ldocs:[{id:"d3",kind:"purchase",party:"Xpatit",number:"ΤΔΑ 1182",cat:"Εμπορεύματα",net:820,vat:196.8,rate:24,gross:1016.8,date:t,ts:n-e,items:[]},{id:"d4",kind:"purchase",party:"Cosmote",number:"",cat:"Τηλεπικοινωνίες",net:45,vat:10.8,rate:24,gross:55.8,date:t,ts:n-3*e,items:[]},{id:"d1",kind:"sale",qid:"q1",number:"2311",party:"Γιώργος Παπαδόπουλος",net:1159,vat:278.16,rate:24,gross:1437.16,date:t,ts:n-2*e},{id:"d2",kind:"sale",party:"Μαρία Νικολάου",gross:780,date:t,ts:n-30*e}],wdays:[{id:"w1",empId:"e1",date:t,days:1,amount:60},{id:"w2",empId:"e1",date:t,days:1,amount:60}],wpays:[{id:"wp1",empId:"e1",date:t,amount:50,method:"cash"}],lpays:[{id:"p3",dir:"out",date:t,party:"Xpatit",docId:"d3",amount:400,method:"bank",note:""},{id:"p1",docId:"d1",amount:500,dir:"in",date:t,party:"Γιώργος Παπαδόπουλος",method:"bank",note:"Προκαταβολή"},{id:"p2",docId:"d2",amount:780,dir:"in",date:t,party:"Μαρία Νικολάου",method:"cash",note:""}],emps:[{id:"e1",name:"Νίκος Τεχνικός",rate:60}],st:{main:{vat:24,margin:25,next:2312},books:{opening:1500,costCats:["Εμπορεύματα","Υλικά","Καύσιμα","Τηλεπικοινωνίες","Λοιπά έξοδα"]}}}}const dg={quotes:"quotes",custs:"customers",tasks:"tasks",ldocs:"ledger_docs",lpays:"ledger_pays",emps:"employees",products:"products",smoves:"stock_moves",wdays:"workdays",wpays:"wagepays"},ma={...dg,qlog:"quote_log"},x={quotes:[],custs:[],tasks:[],ldocs:[],lpays:[],emps:[],products:[],smoves:[],wdays:[],wpays:[],st:{}},fg=new Set;function QT(n){fg.add(n)}function mn(){fg.forEach(n=>n())}const zt=new URLSearchParams(location.search).has("demo"),pg=zt;let In=null,wn=null,$o=[];const mg={},JT=()=>In&&In.currentUser||null;function YT(n){if(zt){Object.assign(x,HT()),n({email:"demo@techmate"}),setTimeout(mn,0);return}const e=Sf(Bc);In=ww(e),wn=AT(e,{localCache:jT({tabManager:WT()})}),cI(In,t=>{$o.forEach(s=>s()),$o=[],t&&XT(),n(t)})}function XT(){$o.push(zd(jd(wn,"settings"),n=>{const e={};n.docs.forEach(t=>e[t.id]=t.data()),x.st=e,mn()},()=>{})),Object.entries(dg).forEach(([n,e])=>{$o.push(zd(jd(wn,e),t=>{x[n]=t.docs.map(s=>({...s.data(),id:s.id})),mg[n]=!0,mn()},()=>{x[n]=[],mn()}))})}function ZT(n,e){return iI(In,n,e)}function eA(){return zt?location.assign(location.pathname):lI(In)}const Pe=n=>String(n||"").trim().toLowerCase(),O=(n,e=0)=>{const t=parseFloat(n);return isNaN(t)?e:t},Y=n=>Math.round(n*100)/100,lt=n=>n.status||"pending",bi=n=>!!(n&&n.kind==="install"),po={pending:"Σε αναμονή",accepted:"Δεκτή",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"};function ga(n){let e=0;return x.lpays.forEach(t=>{t.docId===n&&(e+=O(t.amount))}),Y(e)}function gg(n){return Math.max(0,Y(O(n.gross)-ga(n.id)))}function Ct(){const n={},e=t=>{const s=Pe(t)||"_none";return n[s]||(n[s]={k:s,name:t||"(χωρίς όνομα)",quotes:[],mins:[],last:0})};return x.custs.forEach(t=>{const s=e(t.name);s.name=t.name,s.rec=t,s.last=Math.max(s.last,t.upd||t.ts||0)}),x.quotes.forEach(t=>{const s=e(t.customer&&t.customer.name);(bi(t)?s.mins:s.quotes).push(t),s.last=Math.max(s.last,t.ts||0)}),x.ldocs.forEach(t=>{t.kind==="sale"&&e(t.party)}),Object.values(n).map(t=>{t.won=0,t.owed=0,t.docs=x.ldocs.filter(i=>i.kind==="sale"&&Pe(i.party)===t.k),t.quotes.forEach(i=>{const o=lt(i);(o==="accepted"||o==="done")&&(t.won+=O(i.total))}),t.docs.forEach(i=>{t.owed+=gg(i),t.last=Math.max(t.last,i.ts||0)}),t.owed=Y(t.owed),t.won=Y(t.won);const s=t.quotes.slice().sort((i,o)=>(o.ts||0)-(i.ts||0))[0],r=s&&s.customer||{};return t.info={},["phone","email","afm","address"].forEach(i=>t.info[i]=t.rec&&t.rec[i]||r[i]||""),t})}const En=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),yt=n=>JSON.parse(JSON.stringify(n)),dt=()=>x.st.main;let _g=()=>{};function tA(n){_g=n}const Ti=n=>{n.catch(e=>_g(e))};function pt(n,e){const t=yt(e);delete t.id;const s=x[n];if(s){const r=s.findIndex(i=>i.id===e.id);r>=0?s[r]=yt(e):s.push(yt(e))}zt||Ti(Wl(wi(wn,ma[n],e.id),t)),mn()}function yg(n,e){x[n]&&(x[n]=x[n].filter(t=>t.id!==e)),zt||Ti(UT(wi(wn,ma[n],e))),mn()}const Fo=()=>zt?{uid:"demo",email:"demo@techmate"}:In&&In.currentUser;function ns(n,e,t){const s=(x[n]||[]).find(i=>i.id===e);s&&Object.keys(t).forEach(i=>{t[i]===void 0?delete s[i]:s[i]=t[i]});const r={};Object.keys(t).forEach(i=>r[i]=t[i]===void 0?hg():t[i]),zt||Ti(FT(wi(wn,ma[n],e),r)),mn()}function nA(n,e,t){const s=x[n];let r=s&&s.find(o=>o.id===e);s&&!r&&(r={id:e},s.push(r)),r&&Object.keys(t).forEach(o=>{t[o]===void 0?delete r[o]:r[o]=yt(t[o])});const i={};Object.keys(t).forEach(o=>{o!=="id"&&(i[o]=t[o]===void 0?hg():yt(t[o]))}),zt||Ti(Wl(wi(wn,ma[n],e),i,{merge:!0})),mn()}function sA(n){x.st.main&&(x.st.main.next=n),zt||Ti(Wl(wi(wn,"settings","main"),{next:n},{merge:!0}))}const Ql=n=>O(n.qty)*O(n.price)*(1-O(n.disc)/100),Jl=n=>Y((n.lines||[]).reduce((e,t)=>e+Ql(t),0));function vg(n){const e=Jl(n),t=n.vatMode==="off",s=O(dt()&&dt().vat,24),r=t?0:Y(e*s/100);return{sub:e,vat:r,vp:s,off:t,total:Y(e+r)}}function Ig(n){const e=O(n.cost,0);if(n.marginEur!=null&&n.marginEur!=="")return Y(e+O(n.marginEur));const t=n.margin==null||n.margin===""?O(dt()&&dt().margin,25):O(n.margin);return Y(e*(1+t/100))}function wg(n,e){let t=0,s=0,r=0;return x.ldocs.forEach(i=>{i.kind==="purchase"&&i.items&&i.items.forEach(o=>{o.pid===n&&(t+=O(o.qty))})}),x.smoves.forEach(i=>{i.pid===n&&(t+=O(i.qty))}),x.quotes.forEach(i=>{if(i.id===e)return;const o=lt(i);(i.lines||[]).forEach(c=>{if(c.pid!==n||c.src!=="stock")return;const l=O(c.qty);o==="done"?i.noStock||(s+=l):o==="accepted"&&(r+=l)})}),Y(t-s-r)}/*! Capacitor: https://capacitorjs.com/ - MIT License */var Gs;(function(n){n.Unimplemented="UNIMPLEMENTED",n.Unavailable="UNAVAILABLE"})(Gs||(Gs={}));class ic extends Error{constructor(e,t,s){super(e),this.message=e,this.code=t,this.data=s}}const rA=n=>{var e,t;return n!=null&&n.androidBridge?"android":!((t=(e=n==null?void 0:n.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||t===void 0)&&t.bridge?"ios":"web"},iA=n=>{const e=n.CapacitorCustomPlatform||null,t=n.Capacitor||{},s=t.Plugins=t.Plugins||{},r=()=>e!==null?e.name:rA(n),i=()=>r()!=="web",o=p=>{const y=u.get(p);return!!(y!=null&&y.platforms.has(r())||c(p))},c=p=>{var y;return(y=t.PluginHeaders)===null||y===void 0?void 0:y.find(S=>S.name===p)},l=p=>n.console.error(p),u=new Map,f=(p,y={})=>{const S=u.get(p);if(S)return console.warn(`Capacitor plugin "${p}" already registered. Cannot register plugins twice.`),S.proxy;const k=r(),V=c(p);let R;const B=async()=>(!R&&k in y?R=typeof y[k]=="function"?R=await y[k]():R=y[k]:e!==null&&!R&&"web"in y&&(R=typeof y.web=="function"?R=await y.web():R=y.web),R),z=(g,_)=>{var w,E;if(V){const b=V==null?void 0:V.methods.find(v=>_===v.name);if(b)return b.rtype==="promise"?v=>t.nativePromise(p,_.toString(),v):(v,tt)=>t.nativeCallback(p,_.toString(),v,tt);if(g)return(w=g[_])===null||w===void 0?void 0:w.bind(g)}else{if(g)return(E=g[_])===null||E===void 0?void 0:E.bind(g);throw new ic(`"${p}" plugin is not implemented on ${k}`,Gs.Unimplemented)}},j=g=>{let _;const w=(...E)=>{const b=B().then(v=>{const tt=z(v,g);if(tt){const Et=tt(...E);return _=Et==null?void 0:Et.remove,Et}else throw new ic(`"${p}.${g}()" is not implemented on ${k}`,Gs.Unimplemented)});return g==="addListener"&&(b.remove=async()=>_()),b};return w.toString=()=>`${g.toString()}() { [capacitor code] }`,Object.defineProperty(w,"name",{value:g,writable:!1,configurable:!1}),w},Z=j("addListener"),N=j("removeListener"),M=(g,_)=>{const w=Z({eventName:g},_).then(v=>v),E=async()=>{const v=await w;await N({eventName:g,callbackId:v})},b=new Promise(v=>w.then(()=>v({remove:E})));return b.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await E()},b},I=new Proxy({},{get(g,_){switch(_){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return V?M:Z;case"removeListener":return N;default:return j(_)}}});return s[p]=I,u.set(p,{name:p,proxy:I,platforms:new Set([...Object.keys(y),...V?[k]:[]])}),I};return t.convertFileSrc||(t.convertFileSrc=p=>p),t.getPlatform=r,t.handleError=l,t.isNativePlatform=i,t.isPluginAvailable=o,t.registerPlugin=f,t.Exception=ic,t.DEBUG=!!t.DEBUG,t.isLoggingEnabled=!!t.isLoggingEnabled,t},oA=n=>n.Capacitor=iA(n),si=oA(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),Ai=si.registerPlugin;class Yl{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let s=!1;this.listeners[e]||(this.listeners[e]=[],s=!0),this.listeners[e].push(t);const i=this.windowListeners[e];i&&!i.registered&&this.addWindowListener(i),s&&this.sendRetainedArgumentsForEvent(e);const o=async()=>this.removeListener(e,t);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,s){const r=this.listeners[e];if(!r){if(s){let i=this.retainedEventArguments[e];i||(i=[]),i.push(t),this.retainedEventArguments[e]=i}return}r.forEach(i=>i(t))}hasListeners(e){var t;return!!(!((t=this.listeners[e])===null||t===void 0)&&t.length)}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:s=>{this.notifyListeners(t,s)}}}unimplemented(e="not implemented"){return new si.Exception(e,Gs.Unimplemented)}unavailable(e="not available"){return new si.Exception(e,Gs.Unavailable)}async removeListener(e,t){const s=this.listeners[e];if(!s)return;const r=s.indexOf(t);r!==-1&&this.listeners[e].splice(r,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(s=>{this.notifyListeners(e,s)}))}}const Kd=n=>encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Wd=n=>n.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class aA extends Yl{async getCookies(){const e=document.cookie,t={};return e.split(";").forEach(s=>{if(s.length<=0)return;let[r,i]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");r=Wd(r).trim(),i=Wd(i).trim(),t[r]=i}),t}async setCookie(e){try{const t=Kd(e.key),s=Kd(e.value),r=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",i=(e.path||"/").replace("path=",""),o=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${t}=${s||""}${r}; path=${i}; ${o};`}catch(t){return Promise.reject(t)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(t){return Promise.reject(t)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const t of e)document.cookie=t.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}Ai("CapacitorCookies",{web:()=>new aA});const cA=async n=>new Promise((e,t)=>{const s=new FileReader;s.onload=()=>{const r=s.result;e(r.indexOf(",")>=0?r.split(",")[1]:r)},s.onerror=r=>t(r),s.readAsDataURL(n)}),lA=(n={})=>{const e=Object.keys(n);return Object.keys(n).map(r=>r.toLocaleLowerCase()).reduce((r,i,o)=>(r[i]=n[e[o]],r),{})},uA=(n,e=!0)=>n?Object.entries(n).reduce((s,r)=>{const[i,o]=r;let c,l;return Array.isArray(o)?(l="",o.forEach(u=>{c=e?encodeURIComponent(u):u,l+=`${i}=${c}&`}),l.slice(0,-1)):(c=e?encodeURIComponent(o):o,l=`${i}=${c}`),`${s}&${l}`},"").substr(1):null,hA=(n,e={})=>{const t=Object.assign({method:n.method||"GET",headers:n.headers},e),r=lA(n.headers)["content-type"]||"";if(typeof n.data=="string")t.body=n.data;else if(r.includes("application/x-www-form-urlencoded")){const i=new URLSearchParams;for(const[o,c]of Object.entries(n.data||{}))i.set(o,c);t.body=i.toString()}else if(r.includes("multipart/form-data")||n.data instanceof FormData){const i=new FormData;if(n.data instanceof FormData)n.data.forEach((c,l)=>{i.append(l,c)});else for(const c of Object.keys(n.data))i.append(c,n.data[c]);t.body=i;const o=new Headers(t.headers);o.delete("content-type"),t.headers=o}else(r.includes("application/json")||typeof n.data=="object")&&(t.body=JSON.stringify(n.data));return t};class dA extends Yl{async request(e){const t=hA(e,e.webFetchExtra),s=uA(e.params,e.shouldEncodeUrlParams),r=s?`${e.url}?${s}`:e.url,i=await fetch(r,t),o=i.headers.get("content-type")||"";let{responseType:c="text"}=i.ok?e:{};o.includes("application/json")&&(c="json");let l,u;switch(c){case"arraybuffer":case"blob":u=await i.blob(),l=await cA(u);break;case"json":l=await i.json();break;case"document":case"text":default:l=await i.text()}const f={};return i.headers.forEach((p,y)=>{f[y]=p}),{data:l,headers:f,status:i.status,url:i.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}Ai("CapacitorHttp",{web:()=>new dA});var Hd;(function(n){n.Dark="DARK",n.Light="LIGHT",n.Default="DEFAULT"})(Hd||(Hd={}));var Qd;(function(n){n.StatusBar="StatusBar",n.NavigationBar="NavigationBar"})(Qd||(Qd={}));class fA extends Yl{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}Ai("SystemBars",{web:()=>new fA});const pA="modulepreload",mA=function(n){return"/"+n},Jd={},gA=function(e,t,s){let r=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const o=document.querySelector("meta[property=csp-nonce]"),c=(o==null?void 0:o.nonce)||(o==null?void 0:o.getAttribute("nonce"));r=Promise.allSettled(t.map(l=>{if(l=mA(l),l in Jd)return;Jd[l]=!0;const u=l.endsWith(".css"),f=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${f}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":pA,u||(p.as="script"),p.crossOrigin="",p.href=l,c&&p.setAttribute("nonce",c),document.head.appendChild(p),u)return new Promise((y,S)=>{p.addEventListener("load",y),p.addEventListener("error",()=>S(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(o){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=o,window.dispatchEvent(c),!c.defaultPrevented)throw o}return r.then(o=>{for(const c of o||[])c.status==="rejected"&&i(c.reason);return e().catch(i)})},_A="__capgo_keep_url_path_after_reload",oc="__capgo_history_stack__",Yd=100,yA=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(yA){const n=window;if(!n.__capgoHistoryPatched){n.__capgoHistoryPatched=!0;const e=()=>{try{if(n.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(_A)==="1"}catch{return!1}},t=()=>{try{const N=window.sessionStorage.getItem(oc);if(!N)return{stack:[],index:-1};const M=JSON.parse(N);return!M||!Array.isArray(M.stack)||typeof M.index!="number"?{stack:[],index:-1}:M}catch{return{stack:[],index:-1}}},s=(N,M)=>{try{window.sessionStorage.setItem(oc,JSON.stringify({stack:N,index:M}))}catch{}},r=()=>{try{window.sessionStorage.removeItem(oc)}catch{}},i=N=>{try{const M=N??window.location.href,I=new URL(M instanceof URL?M.toString():M,window.location.href);return`${I.pathname}${I.search}${I.hash}`}catch{return null}},o=(N,M)=>{if(N.length<=Yd)return{stack:N,index:M};const I=N.length-Yd,g=N.slice(I),_=Math.max(0,M-I);return{stack:g,index:_}},c=N=>{document.readyState==="complete"||document.readyState==="interactive"?N():window.addEventListener("DOMContentLoaded",N,{once:!0})};let l=!1,u=!1,f=!1;const p=()=>{if(!l)return;const N=t(),M=i();if(M){if(N.stack.length===0){N.stack.push(M),N.index=0,s(N.stack,N.index);return}(N.index<0||N.index>=N.stack.length)&&(N.index=N.stack.length-1),N.stack[N.index]!==M&&(N.stack[N.index]=M,s(N.stack,N.index))}},y=(N,M)=>{if(!l||u)return;const I=i(N);if(!I)return;let{stack:g,index:_}=t();g.length===0?(g.push(I),_=g.length-1):M?((_<0||_>=g.length)&&(_=g.length-1),g[_]=I):_>=g.length-1?(g.push(I),_=g.length-1):(g=g.slice(0,_+1),g.push(I),_=g.length-1),{stack:g,index:_}=o(g,_),s(g,_)},S=()=>{if(!l||u)return;const N=t();if(N.stack.length===0){p();return}const M=N.index>=0&&N.index<N.stack.length?N.index:N.stack.length-1,I=i();if(N.stack.length===1&&I===N.stack[0])return;const g=N.stack[0];if(!g)return;u=!0;try{history.replaceState(history.state,document.title,g);for(let E=1;E<N.stack.length;E+=1)history.pushState(history.state,document.title,N.stack[E])}catch{u=!1;return}u=!1;const _=N.stack.length-1,w=M-_;w!==0?history.go(w):(history.replaceState(history.state,document.title,N.stack[M]),window.dispatchEvent(new PopStateEvent("popstate")))},k=()=>{!l||f||(f=!0,c(()=>{f=!1,S()}))};let V=null,R=null;const B=()=>{if(!l||u)return;const N=i();if(!N)return;const M=t(),I=M.stack.lastIndexOf(N);I>=0?M.index=I:(M.stack.push(N),M.index=M.stack.length-1);const g=o(M.stack,M.index);s(g.stack,g.index)},z=()=>{V&&R||(V=history.pushState,R=history.replaceState,history.pushState=function(M,I,g){const _=V==null?void 0:V.call(history,M,I,g);return y(g,!1),_},history.replaceState=function(M,I,g){const _=R==null?void 0:R.call(history,M,I,g);return y(g,!0),_},window.addEventListener("popstate",B))},j=()=>{V&&(history.pushState=V,V=null),R&&(history.replaceState=R,R=null),window.removeEventListener("popstate",B)},Z=N=>{if(l===N){l&&(p(),k());return}l=N,l?(z(),p(),k()):(j(),r())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",N=>{var M;const I=N,g=(M=I==null?void 0:I.detail)===null||M===void 0?void 0:M.enabled;typeof g=="boolean"?(n.__capgoKeepUrlPathAfterReload=g,Z(g)):(n.__capgoKeepUrlPathAfterReload=!0,Z(!0))}),Z(e())}}var Xd;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",n[n.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",n[n.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(Xd||(Xd={}));var Zd;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.PENDING=1]="PENDING",n[n.DOWNLOADING=2]="DOWNLOADING",n[n.INSTALLING=3]="INSTALLING",n[n.INSTALLED=4]="INSTALLED",n[n.FAILED=5]="FAILED",n[n.CANCELED=6]="CANCELED",n[n.DOWNLOADED=11]="DOWNLOADED"})(Zd||(Zd={}));var ef;(function(n){n[n.OK=0]="OK",n[n.CANCELED=1]="CANCELED",n[n.FAILED=2]="FAILED",n[n.NOT_AVAILABLE=3]="NOT_AVAILABLE",n[n.NOT_ALLOWED=4]="NOT_ALLOWED",n[n.INFO_MISSING=5]="INFO_MISSING"})(ef||(ef={}));const ri=Ai("CapacitorUpdater",{web:()=>gA(()=>import("./web-BbPr-GAQ.js"),[]).then(n=>new n.CapacitorUpdaterWeb)}),tr=si.isNativePlatform(),vt=tr?Ai("TechMate"):null,qc={accent:0,view:"lists",sun:!1,showDone:!0,compact:!1,defRems:"60,0",dueRems:"1440,0",rep:!0,repMin:5,repMax:6,snooze:10,alarmSound:!1,clockMode:!1,syncMin:60,notifyNew:!0,wAlpha:95,wMode:"todo",wList:"",wDays:2,autoUpd:!0,empClr:"{}",bUri:"",bAuto:!0,bLast:0};let jn={...qc};const Eg="tm-settings",Ve=()=>jn;async function ii(){if(vt)try{const n=await vt.getSettings();jn={...qc,...n||{}}}catch{}else try{jn={...qc,...JSON.parse(localStorage.getItem(Eg)||"{}")}}catch{}return jn}async function Br(n,e){if(jn={...jn,[n]:e},vt)try{await vt.setSetting({k:n,v:e})}catch{}else try{localStorage.setItem(Eg,JSON.stringify(jn))}catch{}}const Ae=async(n,e={},t=null)=>{if(!vt)return t;try{return await vt[n](e)}catch(s){return{error:s&&s.message||"σφάλμα"}}},ge={setSession:n=>Ae("setSession",n),clearSession:()=>Ae("clearSession"),setTasks:(n,e,t)=>Ae("setTasks",{json:n,emps:e,lists:t}),testNotif:()=>Ae("testNotif"),openBattery:()=>Ae("openBattery"),openNotifSettings:()=>Ae("openNotifSettings"),exactAlarms:()=>Ae("exactAlarms",{},{ok:!0}),msStatus:()=>Ae("msStatus",{},{connected:!1}),msLogin:()=>Ae("msLogin"),msSync:()=>Ae("msSync",{},{ok:!1}),msDisconnect:()=>Ae("msDisconnect"),pull:()=>Ae("pull",{},{ok:!1}),backupPick:()=>Ae("backupPick",{},{error:"Μόνο στο κινητό"}),backupWrite:n=>Ae("backupWrite",{json:n},{error:"Μόνο στο κινητό"}),takeLaunch:()=>Ae("takeLaunch",{},{}),installApk:(n,e)=>Ae("installApk",{url:n,size:e}),copy:async n=>{if(vt)return Ae("copy",{text:n});try{await navigator.clipboard.writeText(n)}catch{}},paste:async()=>{if(vt){const n=await Ae("paste");return n&&n.text||""}try{return await navigator.clipboard.readText()}catch{return""}},share:n=>vt?Ae("share",{text:n}):ge.copy(n),refreshWidgets:()=>Ae("refreshWidgets")};function _a(n,e){vt&&vt.addListener(n,e)}const bg="1.0.0",vA="https://raw.githubusercontent.com/cursing/techmate-app-releases/main/latest.json",Tg=si.isNativePlatform(),tf=(n,e)=>{const t=String(n).split(".").map(Number),s=String(e).split(".").map(Number);for(let r=0;r<3;r++){const i=(t[r]||0)-(s[r]||0);if(i)return i}return 0},we={state:"idle",latest:null,pct:0,err:"",needApk:!1,checkedAt:0};let Ag=()=>{};function IA(n){Ag=n}const gt=n=>{Object.assign(we,n),Ag()};function wA(){Tg&&(ri.notifyAppReady().catch(()=>{}),ri.addListener("download",n=>{we.state==="downloading"&&gt({pct:Math.round(n.percent||0)})}),_a("apk",n=>{we.state==="downloading"&&gt({pct:n&&n.pct||0})}),jc(),document.addEventListener("visibilitychange",()=>{!document.hidden&&Date.now()-we.checkedAt>30*6e4&&jc()}))}async function jc(n){if(!Tg){n&&gt({state:"none"});return}if(we.state!=="downloading"){n&&gt({state:"checking",err:""});try{const e=await fetch(vA+"?t="+Date.now(),{cache:"no-store"});if(!e.ok)throw new Error("HTTP "+e.status);const t=await e.json();if(we.checkedAt=Date.now(),!t.version||tf(t.version,bg)<=0)return gt({state:n?"none":"idle",latest:null});let s="0";try{s=(await ri.getBuiltinVersion()).version||"0"}catch{}gt({state:"available",latest:t,needApk:!!t.minNative&&tf(s,t.minNative)<0,err:""})}catch{gt({state:n?"error":"idle",err:n?"Δεν μπόρεσα να ελέγξω για ενημέρωση. Έλεγξε τη σύνδεση.":""})}}}async function EA(){const n=we.latest;if(!(!n||we.state==="downloading")){if(we.needApk){gt({state:"downloading",pct:0,err:""});const e=await ge.installApk(n.apk,n.apkSize||0);gt({state:"available",err:e&&e.error?e.error:""});return}gt({state:"downloading",pct:0,err:""});try{const e=await ri.download({url:n.zip,version:n.version,checksum:n.sha256||""});await ri.set(e)}catch(e){gt({state:"available",err:"Η λήψη απέτυχε: "+(e&&(e.message||e.code)||"άγνωστο σφάλμα")})}}}const bA=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Gc=n=>bA.format(Math.round((n||0)*100)/100),nf=n=>n<10?"0"+n:""+n,fe=()=>{const n=new Date;return n.getFullYear()+"-"+nf(n.getMonth()+1)+"-"+nf(n.getDate())},TA=n=>(n=O(n,24),[24,13,6,0].includes(n)?n:24),Xl=()=>{const n=Fo();return n&&(x.st.roles&&x.st.roles.users||{})[n.uid]||null},et=()=>{const n=Xl();return!!(n&&n.role==="team")},Gn=()=>{const n=Xl();return n&&n.empId||""},zn=()=>{const n=Fo();if(!n)return null;const e=Xl();return{uid:n.uid,name:e?e.name||"Υπάλληλος":"Διαχειριστής"}},Zl=n=>!et()||!!(n&&n.by&&Fo()&&n.by.uid===Fo().uid),mo={pending:"Σε αναμονή απάντησης",accepted:"Έγινε δεκτή, προς εγκατάσταση",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"},ac=(n,e,t)=>pt("qlog",{id:En(),qid:n.id||"",number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:e,text:t}),Sg=n=>x.ldocs.find(e=>e.kind==="sale"&&(e.qid===n.id||!e.qid&&n.number&&e.number===n.number&&Pe(e.party)===Pe(n.customer&&n.customer.name)))||null,sf=n=>!(n&&n.war&&n.war.on===!1),AA=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(O(e.m,0))):O(dt().warrantyMonths,24)};function SA(n,e){let t=0,s=0,r=0;return x.ldocs.forEach(i=>{i.kind==="purchase"&&i.items&&i.items.forEach(o=>{o.pid===n&&(t+=O(o.qty))})}),x.smoves.forEach(i=>{i.pid===n&&(t+=O(i.qty))}),x.quotes.forEach(i=>{if(i.id===e)return;const o=lt(i);(i.lines||[]).forEach(c=>{if(c.pid!==n||c.src!=="stock")return;const l=O(c.qty);o==="done"?i.noStock||(s+=l):o==="accepted"&&(r+=l)})}),Y(t-s-r)}function RA(n,e){const t=[],s=Sg(n);if(e==="pending"||e==="rejected"?s&&s.qid===n.id&&s.note==="Από προσφορά "+(n.number||"")&&ga(s.id)===0&&t.push("Θα αφαιρεθεί το παραστατικό πώλησης που είχε δημιουργηθεί αυτόματα."):!s&&dt()&&dt().autoSale!==!1&&t.push("Θα δημιουργηθεί παραστατικό πώλησης "+Gc(Rg(n).gross)+" στα Λογιστικά."),e==="done"&&!n.install&&t.push("Θα καταχωρηθεί ως εγκατάσταση με σημερινή ημερομηνία."),(e==="accepted"||e==="done")&&n.gid){const r=x.quotes.filter(i=>i.gid===n.gid&&i.id!==n.id&&lt(i)==="pending").length;r&&t.push("Οι "+r+" άλλες εναλλακτικές θα μπουν ως «Απορρίφθηκε».")}return t}function Rg(n){const e=n.vatMode==="off"?0:TA(dt().vat),t=Jl(n),s=Y(t*e/100);return{rate:e,net:t,vat:s,gross:Y(t+s)}}function PA(n,e){const t=x.quotes.find(c=>c.id===n);if(!t||lt(t)===e)return{ok:!1};if(!dt())return{ok:!1,msg:"Δεν έχουν φορτώσει οι ρυθμίσεις. Περίμενε λίγο ή έλεγξε τη σύνδεση."};const s=yt(t);ac(s,"status",mo[lt(s)]+" → "+mo[e]),e==="done"&&!s.install&&(s.install={date:fe(),months:sf(s)?AA(s):0,serials:"",nw:!sf(s)}),s.status=e,s.statusDate=fe();const r=[];e==="accepted"&&(s.lines||[]).forEach(c=>{if(c.pid&&c.src==="stock"&&O(c.qty)>SA(c.pid,s.id)){const l=x.products.find(u=>u.id===c.pid);r.push(l?l.model:c.desc)}});const i=[],o=Sg(s);if(e==="pending"||e==="rejected")o&&o.qid===s.id&&o.note==="Από προσφορά "+(s.number||"")&&ga(o.id)===0&&(yg("ldocs",o.id),i.push("Αφαιρέθηκε το αυτόματο παραστατικό πώλησης."));else if(!o&&dt().autoSale!==!1){const c=Rg(s),l={id:En(),ts:Date.now(),kind:"sale",date:fe(),party:s.customer&&s.customer.name||"Πελάτης",number:s.number||"",cat:"",net:c.net,vat:c.vat,gross:c.gross,rate:c.rate,note:"Από προσφορά "+(s.number||""),items:[],qid:s.id};pt("ldocs",l),x.lpays.forEach(u=>{u.qid===s.id&&!u.docId&&ns("lpays",u.id,{docId:l.id,party:l.party||u.party})}),ac(s,"edit","Δημιουργήθηκε αυτόματα παραστατικό πώλησης ("+Gc(c.gross)+")."),i.push("Δημιουργήθηκε παραστατικό πώλησης "+Gc(c.gross)+" στα Λογιστικά.")}return s.gid&&(e==="accepted"||e==="done")&&x.quotes.filter(c=>c.gid===s.gid&&c.id!==s.id&&lt(c)==="pending").forEach(c=>{const l=yt(c);l.status="rejected",l.statusDate=fe(),ac(l,"status","Σε αναμονή → Απορρίφθηκε (έγινε δεκτή η εναλλακτική "+(s.number||"")+")"),pt("quotes",l)}),pt("quotes",s),r.length&&i.push("Δεν επαρκεί το απόθεμα για: "+r.join(", ")+"."),{ok:!0,msg:["Η κατάσταση άλλαξε: "+mo[e]+"."].concat(i).join(" ")}}function kA(n,e){const t=String(e.name||"").trim();if(!t)return{msg:"Γράψε όνομα πελάτη."};const s=Pe(t),r=Ct(),i=n&&r.find(u=>u.k===n);if((!n||n!==s)&&r.some(u=>u.k===s))return{msg:"Υπάρχει ήδη πελάτης «"+t+"». Άνοιξε τον φάκελό του."};const o=n&&x.custs.find(u=>Pe(u.name)===n),c=o?yt(o):{id:En(),ts:Date.now()},l=u=>String(e[u]||"").trim();return Object.assign(c,{name:t,phone:l("phone"),email:l("email"),afm:l("afm"),address:l("address"),notes:l("notes"),upd:Date.now()}),pt("custs",c),n&&n!==s&&i&&(i.quotes.concat(i.mins).forEach(u=>{const f=yt(u);f.customer=Object.assign({},f.customer||{},{name:t}),pt("quotes",f)}),x.ldocs.forEach(u=>{u.kind==="sale"&&Pe(u.party)===n&&ns("ldocs",u.id,{party:t})}),x.lpays.forEach(u=>{u.dir==="in"&&Pe(u.party)===n&&ns("lpays",u.id,{party:t})})),{ok:!0,k:s}}const De=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),CA=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),se=n=>CA.format(Math.round((n||0)*100)/100),Pg=n=>String(Y(n)).replace(".",","),Ss=n=>O(String(n).replace(",","."),NaN),oi=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},rf=n=>n<10?"0"+n:""+n,ms=n=>n.getFullYear()+"-"+rf(n.getMonth()+1)+"-"+rf(n.getDate()),kg=()=>x.st.books||{},DA=n=>(n=O(n,24),[24,13,6,0].includes(n)?n:24);let ai="month";try{ai=localStorage.getItem("tm_period")||"month"}catch{}const VA=[["month","Μήνας"],["prevmonth","Προηγ. μήνας"],["quarter","Τρίμηνο"],["year","Έτος"],["all","Όλα"]];function Cg(){const n=new Date,e=n.getFullYear(),t=n.getMonth();switch(ai){case"month":return[ms(new Date(e,t,1)),ms(new Date(e,t+1,0))];case"prevmonth":return[ms(new Date(e,t-1,1)),ms(new Date(e,t,0))];case"quarter":{const s=Math.floor(t/3)*3;return[ms(new Date(e,s,1)),ms(new Date(e,s+3,0))]}case"year":return[e+"-01-01",e+"-12-31"];default:return["",""]}}const Fn=n=>{const e=Cg();return(!e[0]||n>=e[0])&&(!e[1]||n<=e[1])},NA=()=>{const n=Cg();return!n[0]&&!n[1]?"Όλες οι κινήσεις":oi(n[0])+" έως "+oi(n[1])};function Dg(n){let e=0,t=0;return x.wdays.forEach(s=>{s.empId===n&&(e+=O(s.amount))}),x.wpays.forEach(s=>{s.empId===n&&(t+=O(s.amount))}),{earned:Y(e),paid:Y(t),bal:Y(e-t)}}function ya(){const n={},e={},t=(r,i)=>{const o=Pe(i)||"—";return r[o]||(r[o]={name:(i||"").trim()||"Χωρίς όνομα",inv:0,paid:0})};x.ldocs.forEach(r=>{t(r.kind==="sale"?e:n,r.party).inv+=O(r.gross)}),x.lpays.forEach(r=>{t(r.dir==="in"?e:n,r.party).paid+=O(r.amount)});const s=r=>Object.values(r).map(i=>(i.inv=Y(i.inv),i.paid=Y(i.paid),i.bal=Y(i.inv-i.paid),i)).sort((i,o)=>o.bal-i.bal);return{sup:s(n),cus:s(e)}}function xA(){const n={sNet:0,sVat:0,pNet:0,pVat:0,inBank:0,inCash:0,outBank:0,outCash:0,wages:0,cats:{}};x.ldocs.forEach(r=>{if(!(r.opening||!Fn(r.date)))if(r.kind==="sale")n.sNet+=O(r.net),n.sVat+=O(r.vat);else{n.pNet+=O(r.net),n.pVat+=O(r.vat);const i=r.cat||"Χωρίς κατηγορία";n.cats[i]=(n.cats[i]||0)+O(r.net)}}),x.lpays.forEach(r=>{Fn(r.date)&&(r.dir==="in"?r.method==="bank"?n.inBank+=O(r.amount):n.inCash+=O(r.amount):r.method==="bank"?n.outBank+=O(r.amount):n.outCash+=O(r.amount))}),x.wdays.forEach(r=>{Fn(r.date)&&(n.wages+=O(r.amount))}),x.wpays.forEach(r=>{Fn(r.date)&&(r.method==="bank"?n.outBank+=O(r.amount):n.outCash+=O(r.amount))}),Object.keys(n).forEach(r=>{typeof n[r]=="number"&&(n[r]=Y(n[r]))}),n.vatDue=Y(n.sVat-n.pVat),n.profit=Y(n.sNet-n.pNet-n.wages);let e=O(kg().opening,0),t=0;x.lpays.forEach(r=>{const i=r.dir==="in"?O(r.amount):-O(r.amount);r.method==="bank"?e+=i:t+=i}),x.wpays.forEach(r=>{r.method==="bank"?e-=O(r.amount):t-=O(r.amount)}),n.bank=Y(e),n.cash=Y(t),n.rcvAll=Y(n.inBank+n.inCash),n.nRcv=x.lpays.filter(r=>r.dir==="in"&&Fn(r.date)).length;const s=ya();return n.owe=0,n.due=0,n.nOwe=0,n.nDue=0,n.wOwe=0,n.nW=0,s.sup.forEach(r=>{r.bal>.004&&(n.owe+=r.bal,n.nOwe++)}),s.cus.forEach(r=>{r.bal>.004&&(n.due+=r.bal,n.nDue++)}),x.emps.forEach(r=>{const i=Dg(r.id).bal;i>.004&&(n.wOwe+=i,n.nW++)}),n.owe=Y(n.owe),n.due=Y(n.due),n.wOwe=Y(n.wOwe),n}function Si(n){const e=ga(n.id),t=Y(O(n.gross)-e);return O(n.gross)!==0&&t<=.004?{k:"paid",t:n.kind==="sale"?"Εισπράχθηκε":"Πληρώθηκε",rem:0}:e>0?{k:"part",t:"Μερικώς",rem:t}:{k:"open",t:n.kind==="sale"?"Δεν εισπράχθηκε":"Ανεξόφλητο",rem:t}}const OA=(n,e)=>{const t=e==="in"?"sale":"purchase",s=Pe(n);return x.ldocs.filter(r=>r.kind===t&&(!s||Pe(r.party)===s)&&Si(r).k!=="paid").sort((r,i)=>r.date<i.date?1:-1)},Vg=[["sum","Σύνοψη"],["docs","Παραστατικά"],["pays","Πληρωμές"],["bal","Υπόλοιπα"]];let go="all",oe=null;const Ng=()=>!!oe;function LA(){oe=null}const Xi=(n,e,t="")=>`<div class="kpi"><b class="${t}">${n}</b><span>${e}</span></div>`,MA={paid:"p-ok",part:"p-w",open:"p-b"},$A=(n,e)=>`<div class="chips">${Vg.map(([t,s])=>`<a href="#/books/${t}" class="chip${t===n?" on":""}">${s}</a>`).join("")}</div>
  ${n==="bal"?"":`<div class="chips">${VA.map(([t,s])=>`<button data-bper="${t}" class="${t===ai?"on":""}">${s}</button>`).join("")}</div><div class="plabel">${NA()}</div>`}${e?"":'<div class="upd">Φόρτωση…</div>'}`;function FA(){const n=xA(),e=Object.entries(n.cats).sort((t,s)=>s[1]-t[1]);return`<div class="kpis">${Xi(se(n.sNet),"Έσοδα (καθαρά)","ok")}${Xi(se(n.pNet),"Αγορές και έξοδα (καθαρά)","bad")}${Xi(se(n.wages),"Μεροκάματα")}${Xi(se(n.profit),"Κέρδος περιόδου",n.profit<0?"bad":"")}</div>
  ${n.sVat||n.pVat?`<div class="h">ΦΠΑ</div><div class="card"><div class="tot"><span>ΦΠΑ πωλήσεων</span><span>${se(n.sVat)}</span></div><div class="tot"><span>ΦΠΑ αγορών</span><span>${se(n.pVat)}</span></div>
    <div class="tot big"><span>${n.vatDue>=0?"ΦΠΑ προς απόδοση":"ΦΠΑ πιστωτικό"}</span><span>${se(Math.abs(n.vatDue))}</span></div></div>`:""}
  <div class="h">Χρήματα</div><div class="card"><div class="tot"><span>Εισπράξεις περιόδου${n.nRcv?" ("+n.nRcv+")":""}</span><span>${se(n.rcvAll)}</span></div>
    <div class="tot"><span>· τράπεζα ${se(n.inBank)} · μετρητά ${se(n.inCash)}</span><span></span></div>
    <div class="tot"><span>Πληρωμές περιόδου</span><span>${se(Y(n.outBank+n.outCash))}</span></div>
    <div class="tot big"><span>Τράπεζα σήμερα</span><span>${se(n.bank)}</span></div><div class="tot big"><span>Μετρητά στο ταμείο</span><span>${se(n.cash)}</span></div></div>
  <div class="h">Υπόλοιπα</div><div class="card">
    <a class="row" href="#/books/bal"><div class="av">👥</div><div class="t"><b>Πελάτες μου χρωστούν</b><span>${n.nDue} πελάτες</span></div><span class="amt">${se(n.due)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">🏭</div><div class="t"><b>Χρωστάω σε προμηθευτές</b><span>${n.nOwe} προμηθευτές</span></div><span class="amt">${se(n.owe)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">👷</div><div class="t"><b>Μεροκάματα που χρωστάω</b><span>${n.nW} υπάλληλοι</span></div><span class="amt">${se(n.wOwe)}</span></a></div>
  ${e.length?`<div class="h">Έξοδα ανά κατηγορία</div><div class="card">${e.map(([t,s])=>`<div class="tot"><span>${De(t)}</span><span>${se(s)}</span></div>`).join("")}</div>`:""}`}function UA(){const n=x.ldocs.filter(e=>Fn(e.date)&&(go==="all"||e.kind===go)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0));return`<div class="chips">${[["all","Όλα"],["sale","Πωλήσεις"],["purchase","Αγορές"]].map(([e,t])=>`<button data-bdk="${e}" class="${go===e?"on":""}">${t}</button>`).join("")}</div>
  <div class="card">${n.map(e=>{const t=Si(e);return`<div class="row"><div class="av">${e.kind==="sale"?"📤":"📥"}</div>
    <div class="t"><b>${De(e.party)}</b><span>${oi(e.date)}${e.number?" · "+De(e.number):""}${e.cat?" · "+De(e.cat):""}${e.opening?" · παλιό υπόλοιπο":""}</span>${e.note?`<span>${De(e.note)}</span>`:""}
    ${t.k!=="paid"?`<button class="lnk" data-bpay="${De(e.id)}">${e.kind==="sale"?"💶 Είσπραξη":"💶 Πληρωμή"} ${se(t.rem)}</button>`:""}</div>
    <div class="r"><div class="amt">${se(e.gross)}</div><span class="pill ${MA[t.k]}">${t.t}</span></div></div>`}).join("")||'<div class="empty">Κανένα παραστατικό στην περίοδο</div>'}</div>`}function BA(){return`<div class="card">${x.lpays.filter(e=>Fn(e.date)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0)).map(e=>`<div class="row"><div class="av">${e.dir==="in"?"⬇️":"⬆️"}</div>
    <div class="t"><b>${De(e.party)}</b><span>${oi(e.date)} · ${e.method==="bank"?"τράπεζα":"μετρητά"}${e.note?" · "+De(e.note):""}</span></div>
    <div class="r"><div class="amt ${e.dir==="in"?"ok":"bad"}">${e.dir==="in"?"+":"−"}${se(e.amount)}</div></div></div>`).join("")||'<div class="empty">Καμία κίνηση στην περίοδο</div>'}</div>`}function qA(){const n=ya(),e=(s,r,i)=>s.map(o=>`<div class="row"><div class="t"><b>${De(o.name)}</b><span>τιμολογημένα ${se(o.inv)} · πληρωμένα ${se(o.paid)}</span>
    ${o.bal>.004?`<button class="lnk" data-bnew="${r}" data-party="${De(o.name)}">${r==="in"?"💶 Νέα είσπραξη":"💶 Νέα πληρωμή"}</button>`:""}</div>
    <div class="r"><span class="pill ${o.bal>.004?"p-b":o.bal<-.004?"p-w":"p-ok"}">${o.bal>.004?se(o.bal):o.bal<-.004?"πιστωτικό "+se(-o.bal):"εξοφλημένο"}</span></div></div>`).join("")||`<div class="empty">${i}</div>`,t=x.emps.slice().sort((s,r)=>String(s.name).localeCompare(r.name,"el"));return`<div class="h">Πελάτες</div><div class="card">${e(n.cus,"in","Δεν υπάρχουν πελάτες με παραστατικά")}</div>
  <div class="h">Προμηθευτές</div><div class="card">${e(n.sup,"out","Δεν υπάρχουν προμηθευτές")}</div>
  ${t.length?`<div class="h">Υπάλληλοι</div><div class="card">${t.map(s=>{const r=Dg(s.id);return`<div class="row"><div class="t"><b>${De(s.name)}</b><span>δεδουλευμένα ${se(r.earned)} · πληρωμένα ${se(r.paid)}</span></div>
    <div class="r"><span class="pill ${r.bal>.004?"p-b":r.bal<-.004?"p-w":"p-ok"}">${r.bal>.004?se(r.bal):r.bal<-.004?"προπληρωμή "+se(-r.bal):"τακτοποιημένο"}</span></div></div>`}).join("")}</div>`:""}`}const bt=(n,e,t="")=>`<label class="f">${e}<input class="in" data-bf="${n}" value="${De(oe.v[n]??"")}" ${t}></label>`,qr=(n,e)=>`<div class="seg">${e.map(([t,s])=>`<button data-bseg="${n}" data-v="${t}" class="${oe.v[n]===t?"on":""}">${s}</button>`).join("")}</div>`;function jA(){const n=oe.v,e=OA(n.party,n.dir),t=ya();return n.docId&&!e.some(s=>s.id===n.docId)&&(n.docId=""),`<div class="card pad">${qr("dir",[["in","Είσπραξη από πελάτη"],["out","Πληρωμή σε προμηθευτή"]])}
    ${bt("date","Ημερομηνία",'type="date"')}${bt("party",n.dir==="in"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.dir==="in"?t.cus:t.sup).map(s=>`<option value="${De(s.name)}">`).join("")}</datalist>
    <label class="f">Παραστατικό<select class="in" data-bf="docId"><option value="">Χωρίς σύνδεση με παραστατικό</option>${e.map(s=>`<option value="${De(s.id)}" ${s.id===n.docId?"selected":""}>${oi(s.date)} · ${De(s.party)}${s.number?" · "+De(s.number):""} · υπόλοιπο ${se(Si(s).rem)}</option>`).join("")}</select></label>
    ${bt("amount","Ποσό €",'inputmode="decimal"')}${qr("method",[["bank","Τράπεζα"],["cash","Μετρητά"]])}${bt("note","Σημείωση")}</div>`}function eu(n){const e=Ss(n.amount),t=O(n.rate,24);let s,r,i;return n.mode==="net"?(s=Y(e),r=Y(s*t/100),i=Y(s+r)):(i=Y(e),s=Y(i/(1+t/100)),r=Y(i-s)),{net:s,vat:r,gross:i,rate:t}}function GA(){const n=oe.v,e=ya(),t=isNaN(Ss(n.amount))?null:eu(n);return`<div class="card pad">${qr("kind",[["purchase","Αγορά / έξοδο"],["sale","Πώληση"]])}
    ${bt("date","Ημερομηνία",'type="date"')}${bt("party",n.kind==="sale"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.kind==="sale"?e.cus:e.sup).map(s=>`<option value="${De(s.name)}">`).join("")}</datalist>
    ${bt("number","Αριθμός παραστατικού")}
    ${n.kind==="purchase"?`${bt("cat","Κατηγορία εξόδου",'list="bcl" autocomplete="off"')}<datalist id="bcl">${(kg().costCats||[]).map(s=>`<option value="${De(s)}">`).join("")}</datalist>`:""}
    ${bt("amount","Ποσό €",'inputmode="decimal"')}${qr("mode",[["gross","Το ποσό είναι με ΦΠΑ"],["net","Το ποσό είναι χωρίς ΦΠΑ"]])}
    <div class="f">Συντελεστής ΦΠΑ</div>${qr("rate",[["24","24%"],["13","13%"],["6","6%"],["0","0%"]])}
    <div id="bprev" class="plabel">${t?`Καθαρό ${se(t.net)} · ΦΠΑ ${se(t.vat)} · Σύνολο ${se(t.gross)}`:""}</div>${bt("note","Σημείωση")}</div>`}function zA(n,e){if(n==="newpay"||n==="newdoc"){const s=n==="newpay"?"pay":"doc";return(!oe||oe.kind!==s)&&(oe={kind:s,v:s==="pay"?{dir:"in",date:fe(),party:"",docId:"",amount:"",method:"bank",note:"",...Uo||{}}:{kind:"purchase",date:fe(),party:"",number:"",cat:"",amount:"",mode:"gross",rate:String(DA(dt()&&dt().vat)),note:""}}),Uo=null,`<header class="top"><a class="ib" data-bact="cancel">←</a><h1>${s==="pay"?"Νέα κίνηση":"Νέο παραστατικό"}</h1></header><main class="body ed">${s==="pay"?jA():GA()}
      ${oe.msg?`<div class="err box">${De(oe.msg)}</div>`:""}</main><div class="bar"><button class="btn b2" data-bact="cancel">Άκυρο</button><button class="btn b1" data-bact="save">💾 Αποθήκευση</button></div>`}oe=null;const t=Vg.some(([s])=>s===n)?n:"sum";return`<header class="top"><a class="ib" href="#/menu">←</a><h1>Λογιστικά</h1></header><main class="body">${$A(t,e)}${{sum:FA,docs:UA,pays:BA,bal:qA}[t]()}</main>
    <div class="fab2"><a class="btn b2" href="#/books/newdoc">＋ Παραστατικό</a><a class="btn b1" href="#/books/newpay">＋ Είσπραξη / πληρωμή</a></div>`}let Uo=null;function KA(){const n=oe.v;if(!n.date)return"Βάλε ημερομηνία.";if(oe.kind==="pay"){let s=String(n.party||"").trim();const r=n.docId&&x.ldocs.find(i=>i.id===n.docId);return r&&(s=r.party),s?!String(n.amount).trim()||isNaN(Ss(n.amount))?"Βάλε ποσό.":(pt("lpays",{dir:n.dir,date:n.date,party:s,docId:n.docId||"",amount:Y(Ss(n.amount)),method:n.method,note:String(n.note||"").trim(),id:En(),ts:Date.now()}),""):"Βάλε "+(n.dir==="in"?"πελάτη":"προμηθευτή")+"."}const e=String(n.party||"").trim();if(!e)return"Βάλε "+(n.kind==="sale"?"πελάτη":"προμηθευτή")+".";if(!String(n.amount).trim()||isNaN(Ss(n.amount)))return"Βάλε ποσό.";const t=eu(n);return pt("ldocs",{kind:n.kind,date:n.date,party:e,number:String(n.number||"").trim(),cat:n.kind==="purchase"?String(n.cat||"").trim():"",net:t.net,vat:t.vat,gross:t.gross,rate:t.rate,note:String(n.note||"").trim(),items:[],id:En(),ts:Date.now()}),""}function WA(n,e,t,s){const r=n.closest("[data-bper],[data-bdk],[data-bpay],[data-bnew],[data-bseg],[data-bact]");if(!r)return!1;const i=r.dataset;if(i.bper){ai=i.bper;try{localStorage.setItem("tm_period",ai)}catch{}}else if(i.bdk)go=i.bdk;else if(i.bpay){const o=x.ldocs.find(c=>c.id===i.bpay);return o&&(Uo={dir:o.kind==="sale"?"in":"out",party:o.party,docId:o.id,amount:Pg(Si(o).rem)}),oe=null,e("#/books/newpay"),!0}else{if(i.bnew)return Uo={dir:i.bnew,party:i.party},oe=null,e("#/books/newpay"),!0;if(i.bseg)oe.v[i.bseg]=i.v,i.bseg==="dir"&&(oe.v.docId="");else if(i.bact==="cancel"){const o=oe&&oe.kind;return oe=null,e(o==="doc"?"#/books/docs":"#/books/pays",!0),!0}else if(i.bact==="save"){const o=KA();if(o)oe.msg=o;else{const c=oe.kind;return oe=null,s(c==="pay"?"Η κίνηση αποθηκεύτηκε.":"Το παραστατικό αποθηκεύτηκε."),e(c==="doc"?"#/books/docs":"#/books/pays",!0),!0}}}return t(),!0}function HA(n,e){if(!oe||!n.dataset.bf)return!1;const t=n.dataset.bf;if(oe.v[t]=n.value,oe.msg="",t==="docId"){const s=x.ldocs.find(r=>r.id===n.value);s&&(oe.v.party=s.party,oe.v.amount=Pg(Si(s).rem)),e()}else if(!(t==="party"&&oe.kind==="pay")){if(t==="amount"&&oe.kind==="doc"){const s=document.getElementById("bprev");if(s){const r=isNaN(Ss(n.value))?null:eu(oe.v);s.textContent=r?`Καθαρό ${se(r.net)} · ΦΠΑ ${se(r.vat)} · Σύνολο ${se(r.gross)}`:""}}}return!0}function QA(n,e){oe&&oe.kind==="pay"&&n.dataset.bf==="party"&&e()}const Re=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),JA=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),_t=n=>JA.format(Math.round((n||0)*100)/100),St=n=>String(Y(n)).replace(".",","),YA=n=>O(String(n).replace(",","."),0),XA=()=>({war:{on:!0,m:null},id:null,number:null,date:null,ts:0,customer:{name:"",phone:"",email:"",afm:"",address:""},subject:"",notes:"",status:"pending",vatMode:"on",benefits:[],benShow:!0,planMarks:[],planOn:!0,gid:null,optName:"",validDays:null,payShow:!1,payIds:null,prepay:{type:"",val:0},lines:[]}),Bo=n=>n===null||typeof n!="object"?JSON.stringify(n===void 0?null:n):Array.isArray(n)?"["+n.map(Bo).join(",")+"]":"{"+Object.keys(n).sort().map(e=>JSON.stringify(e)+":"+Bo(n[e])).join(",")+"}";let J=null;const xg=()=>!!J;function ZA(){J=null}let _o=null;function e0(n){_o=n}function t0(n){if(n==="new"){const s=XA();return _o&&(Object.assign(s.customer,_o),_o=null),J={arg:n,q:s,base:null,pick:!1,pq:"",pcat:""}}const e=x.quotes.find(s=>s.id===n);if(!e)return null;const t=yt(e);return t.customer=Object.assign({name:"",phone:"",email:"",afm:"",address:""},t.customer),t.lines=t.lines||[],J={arg:n,q:t,base:Bo(e),pick:!1,pq:"",pcat:""}}function n0(n,e){return`<div class="ln-ed" data-i="${e}">
    <div class="ln-top"><input class="in" data-l="desc" value="${Re(n.desc)}" placeholder="Περιγραφή"><button class="x" data-act="del" aria-label="Διαγραφή γραμμής">✕</button></div>
    <div class="ln-bot">
      <div class="step"><button data-act="dec">−</button><input class="in" data-l="qty" inputmode="decimal" value="${Re(St(O(n.qty)))}"><button data-act="inc">＋</button></div>
      <label>Τιμή €<input class="in" data-l="price" inputmode="decimal" value="${Re(St(O(n.price)))}"></label>
      <label>Έκπτ. %<input class="in" data-l="disc" inputmode="decimal" value="${Re(St(O(n.disc)))}"></label>
      <div class="ln-sum" data-sum>${_t(Ql(n))}</div>
    </div></div>`}function Og(){const n=vg(J.q);return`<div class="tot"><span>Καθαρό</span><span>${_t(n.sub)}</span></div>
  ${n.off?"":`<div class="tot"><span>ΦΠΑ ${St(n.vp)}%</span><span>${_t(n.vat)}</span></div>`}
  <div class="tot big"><span>Σύνολο${n.off?" (χωρίς ΦΠΑ)":""}</span><span>${_t(n.total)}</span></div>`}function s0(){const n=[...new Set(x.products.map(s=>s.cat).filter(Boolean))].sort((s,r)=>s.localeCompare(r,"el")),e=Pe(J.pq),t=x.products.filter(s=>(!J.pcat||s.cat===J.pcat)&&(!e||Pe((s.model||"")+" "+(s.desc||"")+" "+(s.cat||"")).includes(e))).sort((s,r)=>((s.cat||"")+(s.model||"")).localeCompare((r.cat||"")+(r.model||""),"el")).slice(0,80);return`<div class="sheet"><div class="sheet-in">
    <div class="sheet-h"><b>Κατάλογος</b><button class="btn b1 sm" data-act="pick-close">Τέλος</button></div>
    <input class="search" id="pq" placeholder="🔍 Αναζήτηση προϊόντος" value="${Re(J.pq)}">
    <div class="chips"><button data-pcat="" class="${J.pcat?"":"on"}">Όλα</button>${n.map(s=>`<button data-pcat="${Re(s)}" class="${J.pcat===s?"on":""}">${Re(s)}</button>`).join("")}</div>
    <div class="sheet-list">${t.map(s=>{const r=J.q.lines.find(o=>o.pid===s.id),i=wg(s.id,J.q.id);return`<button class="prow${r?" has":""}" data-pid="${Re(s.id)}"><div class="t"><b>${Re(s.model)}</b><span>${Re([s.cat,s.desc].filter(Boolean).join(" · "))}${i>=1?` · 📦 ${St(i)} στο ράφι`:""}</span></div>
      <div class="r"><div class="amt">${_t(Ig(s))}</div>${r?`<span class="pill p-ok">×${St(O(r.qty))}</span>`:'<span class="muted">＋ προσθήκη</span>'}</div></button>`}).join("")||`<div class="empty">${x.products.length?"Δεν βρέθηκε προϊόν":"Ο κατάλογος είναι άδειος"}</div>`}</div>
  </div></div>`}function r0(n){if((!J||J.arg!==n)&&(J=null,!t0(n)))return null;const e=J.q,t=e.customer,s=Ct().map(r=>r.name).filter(r=>r&&r!=="(χωρίς όνομα)");return`<header class="top"><a class="ib" data-act="cancel">←</a><h1>${e.id?"Προσφορά #"+Re(e.number||"—"):"Νέα προσφορά"}<span class="sm">${e.id?"Επεξεργασία":"Δεν έχει αποθηκευτεί ακόμα"}</span></h1></header>
  <main class="body ed">
    <div class="card pad">
      <label class="f">Πελάτης<input class="in" data-c="name" list="cl" value="${Re(t.name)}" placeholder="Όνομα πελάτη" autocomplete="off"></label>
      <datalist id="cl">${s.map(r=>`<option value="${Re(r)}">`).join("")}</datalist>
      <details><summary>Τηλέφωνο, email, ΑΦΜ, διεύθυνση</summary>
        <label class="f">Τηλέφωνο<input class="in" data-c="phone" inputmode="tel" value="${Re(t.phone)}"></label>
        <label class="f">Email<input class="in" data-c="email" inputmode="email" value="${Re(t.email)}"></label>
        <label class="f">ΑΦΜ<input class="in" data-c="afm" inputmode="numeric" value="${Re(t.afm)}"></label>
        <label class="f">Διεύθυνση<input class="in" data-c="address" value="${Re(t.address)}"></label>
      </details>
      <label class="f">Θέμα<input class="in" data-q="subject" value="${Re(e.subject)}" placeholder="π.χ. Εγκατάσταση CCTV"></label>
    </div>
    <div class="h">Είδη (${e.lines.length})</div>
    <div class="card pad" id="lines">${e.lines.map(n0).join("")||'<div class="empty">Πρόσθεσε είδη από τον κατάλογο ή γράψε δική σου γραμμή.</div>'}</div>
    <div class="actions"><button class="btn b1" data-act="pick">📦 Κατάλογος</button><button class="btn b2" data-act="free">＋ Γραμμή</button><button class="btn b2" data-act="work">🛠️ Εργασία</button></div>
    <div class="card pad">
      <div class="seg"><button data-vat="on" class="${e.vatMode==="off"?"":"on"}">Με ΦΠΑ</button><button data-vat="off" class="${e.vatMode==="off"?"on":""}">Χωρίς ΦΠΑ</button></div>
      <div id="tots">${Og()}</div>
    </div>
    <div class="card pad"><label class="f">Σημειώσεις<textarea class="in" data-q="notes" rows="3">${Re(e.notes)}</textarea></label></div>
    ${J.msg?`<div class="err box">${Re(J.msg)}</div>`:""}
  </main>
  <div class="bar"><button class="btn b2" data-act="cancel">Άκυρο</button><button class="btn b1" data-act="save">💾 ${J.force?"Αποθήκευση (αντικατάσταση)":"Αποθήκευση"}</button></div>
  ${J.pick?s0():""}`}function i0(n,e,t){const s=()=>{const r=n.querySelector("#tots");r&&(r.innerHTML=Og())};n.oninput=r=>{const i=r.target,o=J&&J.q;if(o){if(i.dataset.c){if(o.customer[i.dataset.c]=i.value,i.dataset.c==="name"){const c=Ct().find(l=>l.k===Pe(i.value));if(c){let l=!1;if(["phone","email","afm","address"].forEach(u=>{!o.customer[u]&&c.info[u]&&(o.customer[u]=c.info[u],l=!0)}),l){e();const u=n.querySelector('[data-c="name"]');u.focus(),u.setSelectionRange(u.value.length,u.value.length)}}}}else if(i.dataset.q)o[i.dataset.q]=i.value;else if(i.dataset.l){const c=i.closest(".ln-ed"),l=o.lines[+c.dataset.i];if(!l)return;l[i.dataset.l]=i.dataset.l==="desc"?i.value:YA(i.value),c.querySelector("[data-sum]").textContent=_t(Ql(l)),s()}else if(i.id==="pq"){J.pq=i.value,e();const c=n.querySelector("#pq");c.focus(),c.setSelectionRange(c.value.length,c.value.length)}}},n.onclick=r=>{const i=J&&J.q;if(!i)return;const o=r.target.closest("[data-act],[data-vat],[data-pcat],[data-pid]");if(!o)return;const c=o.closest(".ln-ed"),l=c&&i.lines[+c.dataset.i],u=o.dataset.act;if(o.dataset.vat)i.vatMode=o.dataset.vat;else if(o.dataset.pcat!==void 0)J.pcat=o.dataset.pcat;else if(o.dataset.pid)o0(o.dataset.pid);else if(u==="inc")l.qty=Y(O(l.qty)+1);else if(u==="dec")l.qty=Math.max(0,Y(O(l.qty)-1));else if(u==="del")i.lines.splice(+c.dataset.i,1);else if(u==="free")i.lines.push({desc:"",qty:1,price:0,disc:0,showImg:!0});else if(u==="work")i.lines.push({desc:"Εργασία / εγκατάσταση",qty:1,price:0,disc:0,showImg:!0});else if(u==="pick")J.pick=!0;else if(u==="pick-close")J.pick=!1;else if(u==="cancel"){const f=i.id;return J=null,t(f)}else if(u==="save"){const f=l0();if(f)return J=null,t(f)}if(J.msg&&u!=="save"&&(J.msg="",J.force=!1),e(),u==="free"){const f=n.querySelectorAll('[data-l="desc"]');f[f.length-1].focus()}}}function o0(n){const e=x.products.find(s=>s.id===n);if(!e)return;const t=J.q.lines.find(s=>s.pid===n);t?t.qty=Y(O(t.qty)+1):J.q.lines.push({pid:n,desc:e.model+(e.desc?" - "+e.desc:""),qty:1,price:Ig(e),disc:0,src:wg(n,J.q.id)>=1?"stock":"supplier",showImg:!!(e.img&&e.imgPdf!==!1)})}function a0(n,e){const t=[],s=(c,l,u)=>{String(l||"")!==String(u||"")&&t.push(c+": «"+(l||"—")+"» → «"+(u||"—")+"»")};s("Πελάτης",n.customer&&n.customer.name,e.customer&&e.customer.name),s("Θέμα",n.subject,e.subject),s("ΦΠΑ",n.vatMode==="off"?"χωρίς":"με",e.vatMode==="off"?"χωρίς":"με"),(n.notes||"")!==(e.notes||"")&&t.push("Άλλαξαν οι σημειώσεις");const r={},i={};if((n.lines||[]).forEach(c=>r[c.pid||c.desc]=c),(e.lines||[]).forEach(c=>i[c.pid||c.desc]=c),Object.keys(i).forEach(c=>{if(!r[c])t.push("Προστέθηκε: "+i[c].desc+" ×"+St(O(i[c].qty)));else{const l=r[c],u=i[c];O(l.qty)!==O(u.qty)&&t.push(u.desc+": ποσότητα "+St(O(l.qty))+" → "+St(O(u.qty))),O(l.price)!==O(u.price)&&t.push(u.desc+": τιμή "+_t(O(l.price))+" → "+_t(O(u.price))),O(l.disc)!==O(u.disc)&&t.push(u.desc+": έκπτωση "+St(O(u.disc))+"%")}}),Object.keys(r).forEach(c=>{i[c]||t.push("Αφαιρέθηκε: "+r[c].desc)}),!t.length)return"";const o=Y(O(e.total)-O(n.total));return t.join("; ")+(o?" (σύνολο "+_t(O(n.total))+" → "+_t(O(e.total))+")":"")}const c0=n=>(n=O(n,24),[24,13,6,0].includes(n)?n:24);function l0(){const n=J.q,e=dt();if(n.lines=n.lines.filter(c=>String(c.desc||"").trim()).map(c=>({...c,desc:String(c.desc).trim(),qty:O(c.qty),price:O(c.price),disc:O(c.disc)})),!n.lines.length)return J.msg="Η προσφορά δεν έχει γραμμές.",null;if(!e)return J.msg="Δεν έχουν φορτώσει οι ρυθμίσεις (αρίθμηση, ΦΠΑ). Περίμενε λίγο ή έλεγξε τη σύνδεση.",null;const t=n.id?x.quotes.find(c=>c.id===n.id):null;if(n.id&&!t)return J.msg="Η προσφορά δεν υπάρχει πια (ίσως διαγράφηκε από άλλη συσκευή).",null;if(t&&Bo(t)!==J.base&&!J.force)return J.force=!0,J.msg="Η προσφορά άλλαξε από άλλη συσκευή αφού την άνοιξες. Αν αποθηκεύσεις, οι αλλαγές εκείνες θα αντικατασταθούν. Πάτα ξανά «Αποθήκευση» για να συνεχίσεις, ή «Άκυρο».",null;let s=0;if(!n.number){const c=Math.max(1,Math.floor(O(e.next,1)));n.number=new Date().getFullYear()+"-"+String(c).padStart(3,"0"),s=c+1}n.date||(n.date=new Date().toLocaleDateString("el-GR")),n.id||(n.id=En(),n.ts=Date.now()),n.customer.name=String(n.customer.name||"").trim(),n.total=vg(n).total;const r=yt(n);pt("quotes",r),s&&sA(s);const i=(c,l)=>pt("qlog",{id:En(),qid:r.id,number:r.number||"",customer:r.customer.name||"",ts:Date.now(),type:c,text:l});if(!t)i("create","Νέα προσφορά, σύνολο "+_t(r.total)+", "+r.lines.length+" γραμμές.");else{const c=a0(t,r);c&&i("edit",c)}const o=x.ldocs.find(c=>c.kind==="sale"&&(c.qid===r.id||!c.qid&&r.number&&c.number===r.number&&Pe(c.party)===Pe(r.customer.name)));if(o){const c=r.vatMode==="off"?0:c0(e.vat),l=Jl(r),u=Y(l*c/100),f=Y(l+u),p=r.customer.name||o.party;o.qid===r.id&&o.net===l&&o.vat===u&&o.gross===f&&o.rate===c&&o.party===p&&o.number===(r.number||"")||ns("ldocs",o.id,{qid:r.id,net:l,vat:u,gross:f,rate:c,party:p,number:r.number||""})}return r.id}const ee=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),of=n=>n<10?"0"+n:""+n,tu=n=>n.getFullYear()+"-"+of(n.getMonth()+1)+"-"+of(n.getDate()),os=n=>new Date(n+"T12:00:00"),ut=(n,e)=>{const t=os(n);return t.setDate(t.getDate()+e),tu(t)},ci=(n,e)=>{const t=os(n),s=t.getDate();t.setDate(1),t.setMonth(t.getMonth()+e);const r=new Date(t.getFullYear(),t.getMonth()+1,0).getDate();return t.setDate(Math.min(s,r)),tu(t)},nr="el-GR",Lg=n=>n.charAt(0).toUpperCase()+n.slice(1),va=n=>Lg(os(n).toLocaleDateString(nr,{weekday:"long",day:"numeric",month:"long",year:"numeric"})),qo=n=>os(n).toLocaleDateString(nr,{weekday:"short",day:"numeric",month:"numeric"}),u0=n=>Lg(os(n).toLocaleDateString(nr,{month:"long",year:"numeric"})),Mg=n=>{const e=fe();return n===e?"Σήμερα":n===ut(e,1)?"Αύριο":n===ut(e,-1)?"Χθες":qo(n)},Rs=[["Μπλε TechMate","#1F4E79"],["Γαλάζιο","#0288D1"],["Τιρκουάζ","#00897B"],["Πράσινο","#2E7D32"],["Λαχανί","#7CB342"],["Κίτρινο","#F2A900"],["Πορτοκαλί","#EF6C00"],["Κόκκινο","#D32F2F"],["Ροζ","#C2185B"],["Μωβ","#7B1FA2"],["Λουλακί","#3949AB"],["Γκρι","#546E7A"]],Un=n=>(Rs[n]||Rs[0])[1],$g=()=>{try{return JSON.parse(Ve().empClr||"{}")}catch{return{}}},Ia=n=>{const e=$g()[n];return typeof e=="number"?e:-1};function Fg(n){if(typeof n.clr=="number"&&n.clr>=0)return Un(n.clr);for(const e of n.emps||[]){const t=Ia(e);if(t>=0)return Un(t)}return n.kind==="due"?Un(6):Un(O(Ve().accent,0))}const nu=-1,Ug=[0,15,30,60,120,1440,2880,10080,nu],jo=n=>String(n||"").split(",").map(e=>parseInt(e,10)).filter(e=>!isNaN(e));function su(n){return Array.isArray(n.rems)?n.rems.map(Number).filter(e=>!isNaN(e)):{none:[],eve:[nu],15:[15],30:[30],60:[60],120:[120]}[n.remOff||"at"]||[0]}function zc(n){return n===0?"Στην ώρα":n===nu?"Το προηγ. βράδυ":n<60?n+"΄ πριν":n===60?"1 ώρα πριν":n<1440?n/60+" ώρες πριν":n===1440?"1 μέρα πριν":n===10080?"1 εβδομάδα πριν":n/1440+" μέρες πριν"}const h0=n=>n.length?n.includes(0)?"at":{[-1]:"eve",15:"15",30:"30",60:"60",120:"120"}[n[0]]||"at":"none",Kc={"":"Καμία",w:"Κάθε εβδομάδα",m:"Κάθε μήνα",y:"Κάθε χρόνο"},d0=n=>!et()||!!Gn()&&(n.emps||[]).includes(Gn()),Wc=()=>x.tasks.filter(n=>!n.del&&d0(n)),ru=n=>!et()||(n.emps||[]).includes(Gn()),iu=n=>{const e=x.emps.find(t=>t.id===n);return e?e.name:""},li=()=>x.emps.filter(n=>n.name&&String(n.name).trim()).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),nr));function wa(){const n=x.st.main||{},e=n.msDefList||"",t=n.msToolList||"",s=n.msListNames||{},r=[...new Set((Array.isArray(n.msLists)?n.msLists:[]).filter(i=>i!==t).concat(e?[e]:[]))];return{def:e,lists:r.map(i=>({id:i,name:s[i]||"Λίστα"})).sort((i,o)=>(i.id===e?0:1)-(o.id===e?0:1))}}function ou(n,e){const t=String(e.title||"").trim();if(!t)return{msg:"Γράψε τίτλο πρώτα."};const s=n&&x.tasks.find(y=>y.id===n),r=!s;if(n&&!s)return{msg:"Η εργασία δεν υπάρχει πια (ίσως σβήστηκε)."};if(!r&&!Zl(s))return{msg:"Μπορείς να αλλάξεις μόνο εργασίες που έγραψες εσύ."};if(et()&&!Gn())return{msg:"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει."};const i=e.date||"",o=i&&e.time||"",c=Date.now(),l=!!(s&&s.done),u=(e.rems||[]).map(Number).filter((y,S,k)=>k.indexOf(y)===S).sort((y,S)=>S-y),f=r?{id:En(),ts:c,msId:"",msList:e.msList||"",rem:""}:{id:s.id};if(r){const y=zn();y&&(f.by=y)}!r&&(s.date!==i||(s.time||"")!==o||JSON.stringify(su(s).slice().sort((y,S)=>S-y))!==JSON.stringify(u))&&(f.rem="");let p=(e.emps||[]).slice();if(et()&&(p=(r?e.emps||[]:s.emps||[]).slice(),p.includes(Gn())||p.push(Gn())),Object.assign(f,{title:t,date:i,time:o,emps:p,cust:String(e.cust||"").trim(),tel:String(e.tel||"").trim(),addr:String(e.addr||"").trim(),notes:String(e.notes||"").trim(),done:!!e.done,remOff:h0(u),rems:u,quoteId:e.quoteId||"",chk:(e.chk||[]).map(y=>({tx:String(y.tx||"").trim(),dn:!!y.dn})).filter(y=>y.tx),kind:e.kind||"",rep:e.rep||"",clr:typeof e.clr=="number"?e.clr:-1,upd:c,dirty:!0,del:!1}),f.done&&!l){f.doneAt=c;const y=zn();y&&(f.doneBy=y.name)}else f.done||(f.doneAt=void 0,f.doneBy=void 0);if(r){if(delete f.doneAt,delete f.doneBy,f.done){f.doneAt=c;const y=zn();y&&(f.doneBy=y.name)}pt("tasks",f)}else nA("tasks",f.id,f);return f.done&&!l&&Bg(x.tasks.find(y=>y.id===f.id)||f),{ok:!0,id:f.id}}function cc(n,e){if(!n||!ru(n))return;const t=Date.now(),s=zn(),r=!!n.done;ns("tasks",n.id,e?{done:!0,upd:t,dirty:!0,doneAt:t,doneBy:s&&s.name||""}:{done:!1,upd:t,dirty:!0,doneAt:void 0,doneBy:void 0}),e&&!r&&Bg(n)}function f0(n,e){ns("tasks",n.id,{chk:e.map(t=>({tx:t.tx,dn:!!t.dn})),upd:Date.now(),dirty:!0})}function Bg(n){if(!n.date||!n.rep)return;const e=n.rep==="w"?ut(n.date,7):n.rep==="m"?ci(n.date,1):n.rep==="y"?ci(n.date,12):"";e&&ou(null,{...n,rems:su(n),date:e,done:!1,chk:(n.chk||[]).map(t=>({tx:t.tx,dn:!1})),msList:n.msList||""})}function p0(n){return Zl(n)?(n.msId?ns("tasks",n.id,{del:!0,dirty:!0,upd:Date.now()}):yg("tasks",n.id),{ok:!0}):{msg:"Μπορείς να σβήσεις μόνο εργασίες που έγραψες εσύ."}}const K={view:"",sel:"",emp:"",q:"",srch:!1,list:"myday",showDone:!1,quick:"",preset:null,ms:null,emSel:""},zs=()=>K.sel||(K.sel=fe());let U=null;const qg=()=>!!U,m0=()=>{U=null};function Ps(n){K.preset=n}const ui=(n,e)=>n.done-e.done||(n.time||"99:99").localeCompare(e.time||"99:99")||String(n.title||"").localeCompare(String(e.title||""),nr),g0=(n,e)=>(n.date?0:1)-(e.date?0:1)||(n.date||"").localeCompare(e.date||"")||(n.time||"99").localeCompare(e.time||"99")||(e.upd||0)-(n.upd||0),_0=(n,e)=>!e||[n.title,n.cust,n.addr,n.notes,n.tel].some(t=>String(t||"").toLowerCase().includes(e))||(n.chk||[]).some(t=>String(t.tx||"").toLowerCase().includes(e));function af(n){const e=K.q.trim().toLowerCase();return Wc().filter(t=>(n||Ve().showDone||!t.done)&&(!K.emp||(t.emps||[]).includes(K.emp))&&_0(t,e))}function gn(n,e){const t=!n.done&&n.date&&n.date<fe(),s=t?"var(--bad)":Fg(n),r=[e&&n.date?t?"Καθυστέρηση · "+qo(n.date):Mg(n.date):"",n.cust,n.addr].filter(Boolean).join(" · "),i=(n.emps||[]).map(iu).filter(Boolean),o=(n.chk||[]).length?`<em>☑ ${(n.chk||[]).filter(u=>u.dn).length}/${n.chk.length}</em>`:"",c=[n.kind==="due"?"<em>💶 Λήξη</em>":"",n.rep?`<em>🔁 ${ee(Kc[n.rep]||"")}</em>`:"",o,!et()&&i.length?`<em>👷 ${ee(i.join(", "))}</em>`:""].join(""),l=ru(n);return`<div class="tc${n.done?" dn":""}${Ve().compact?" cp":""}" style="--c:${s}">
    <button class="tick${n.done?" on":""}" ${l?`data-tk="${ee(n.id)}"`:"disabled"} aria-label="Ολοκληρώθηκε">${n.done?"✓":""}</button>
    <a class="tcb" href="#/t/${encodeURIComponent(n.id)}"><div class="t"><b>${n.kind==="due"?"💶 ":""}${ee(n.title||"(χωρίς τίτλο)")}</b>${r?`<span>${ee(r)}</span>`:""}${c&&!Ve().compact?`<div class="tags">${c}</div>`:""}</div>
    <div class="tcr" style="color:${s}">${ee(n.time||"")}</div></a></div>`}const lc=(n,e,t,s="")=>e.length?`<div class="h ${s}">${n}</div><div class="card">${e.map(r=>gn(r,t)).join("")}</div>`:"";function y0(n){const e=zs(),t=os(e.slice(0,8)+"01"),s=!!Ve().sun,r=(t.getDay()+(s?0:6))%7,i=tu(new Date(t.getFullYear(),t.getMonth(),1-r)),o=s?["Κυρ","Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ"]:["Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ","Κυρ"],c=fe(),l=e.slice(0,7);let u="";for(let p=0;p<6;p++){const y=ut(i,p*7);if(p===5&&y.slice(0,7)!==l)break;for(let S=0;S<7;S++){const k=ut(y,S),V=(n[k]||[]).slice().sort(ui);u+=`<button class="mc${k===e?" sel":""}${k===c?" now":""}${k.slice(0,7)!==l?" out":""}" data-csel="${k}"><b>${+k.slice(8)}</b><i>${V.slice(0,4).map(R=>`<u style="background:${Fg(R)};opacity:${R.done?.35:1}"></u>`).join("")}</i>${V.length>4?`<small>+${V.length-4}</small>`:""}</button>`}}const f=(n[e]||[]).slice().sort(ui);return`<div class="mnav"><button data-cmon="-1">‹</button><b>${u0(e)}</b><button data-cmon="1">›</button></div>
    <div class="card mgrid" id="mgrid"><div class="mh">${o.map(p=>`<span>${p}</span>`).join("")}</div><div class="mg">${u}</div></div>
    <div class="h">${ee(va(e))}</div>
    <div class="card">${f.length?f.map(p=>gn(p,!1)).join(""):'<div class="empty">Ελεύθερη μέρα. Πάτα «＋» για να προσθέσεις.</div>'}</div>`}function v0(n){const e=zs(),t=!!Ve().sun,s=ut(e,-((os(e).getDay()+(t?0:6))%7)),r=fe();let i=`<div class="mnav"><button data-cwk="-1">‹</button><b>${qo(s)} – ${qo(ut(s,6))}</b><button data-cwk="1">›</button></div>`;for(let o=0;o<7;o++){const c=ut(s,o),l=(n[c]||[]).slice().sort(ui);i+=`<div class="h wkh${c===r?" now":""}" data-csel="${c}">${c===r?"● ":""}${ee(va(c))}${l.length?` · ${l.length}`:""}</div>`,i+=l.length?`<div class="card">${l.map(u=>gn(u,!1)).join("")}</div>`:'<div class="wke">—</div>'}return i}function I0(n){const e=fe(),t=(c,l)=>(c.date||"").localeCompare(l.date||"")||ui(c,l),s=n.filter(c=>!c.done&&c.date&&c.date<e).sort(t),r={};n.filter(c=>c.date&&c.date>=e).sort(t).forEach(c=>(r[c.date]=r[c.date]||[]).push(c));const i=n.filter(c=>!c.date&&!c.done).sort((c,l)=>(l.upd||l.ts||0)-(c.upd||c.ts||0));return lc(`⚠️ Εκκρεμότητες από πριν (${s.length})`,s,!0,"badh")+Object.keys(r).map(c=>lc((c===e||c===ut(e,1)?Mg(c)+" · ":"")+va(c),r[c],!1)).join("")+lc("Χωρίς ημερομηνία",i,!1)||'<div class="card"><div class="empty">Δεν υπάρχει τίποτα προγραμματισμένο.</div></div>'}function w0(n){const{def:e,lists:t}=wa(),s=fe(),r=K.list,i=n.filter(u=>r==="myday"?u.date&&u.date<=s&&(!u.done||u.date===s):r==="planned"?!!u.date:r==="all"?!0:u.msList===r||!u.msList&&r===e),o=i.filter(u=>!u.done).sort(g0),c=i.filter(u=>u.done).sort((u,f)=>(f.upd||0)-(u.upd||0));return`<div class="chips">${[["myday","☀️ Η μέρα μου"],["planned","📅 Προγραμματισμένες"],["all","📥 Όλες"]].concat(t.map(u=>[u.id,"≡ "+u.name])).map(([u,f])=>`<button data-clist="${ee(u)}" class="${r===u?"on":""}">${ee(f)}</button>`).join("")}</div>
    <div class="qadd"><input class="search" data-cqv placeholder="＋ Προσθήκη εργασίας" value="${ee(K.quick)}" enterkeyhint="done"><button class="btn b1 sm" data-cqa>Προσθήκη</button></div>
    ${o.length?`<div class="card">${o.map(u=>gn(u,!0)).join("")}</div>`:c.length?"":`<div class="card"><div class="empty">${r==="myday"?"Τίποτα για σήμερα 🙂":"Η λίστα είναι άδεια."}</div></div>`}
    ${c.length?`<div class="h lnk2" data-cdone>${K.showDone?"▾":"▸"} Ολοκληρωμένες (${c.length})</div>${K.showDone?`<div class="card">${c.map(u=>gn(u,!0)).join("")}</div>`:""}`:""}`}function cf(n,e,t,s){s&&s!==K.argV&&["lists","month","week","agenda"].includes(s)&&(K.view=s,K.argV=s),K.view||(K.view=Ve().view||"lists");const r=K.view,i=af(!1),o={};i.forEach(p=>{p.date&&(o[p.date]=o[p.date]||[]).push(p)});const c=[["lists","☑ Λίστες"],["month","🗓 Μήνας"],["week","Εβδ."],["agenda","Ατζέντα"]],l=et()?[]:li(),u=e("Ημερολόγιο",et()?(zn()||{}).name||"":"Πρόγραμμα · εργασίες · λήξεις","",`<button class="ib" data-csrch aria-label="Αναζήτηση">${K.srch?"✕":"🔍"}</button><button class="ib" data-ctoday aria-label="Σήμερα">◎</button><a class="ib" href="#/cset" aria-label="Ρυθμίσεις">⚙️</a>`),f=`${K.srch?`<input class="search" id="csq" data-csq placeholder="🔍 Αναζήτηση σε τίτλο, πελάτη, σημειώσεις…" value="${ee(K.q)}">`:""}
    <div class="seg">${c.map(([p,y])=>`<button data-cv="${p}" class="${r===p?"on":""}">${y}</button>`).join("")}</div>
    ${l.length?`<div class="chips"><button data-cemp="" class="${K.emp?"":"on"}">Όλοι</button>${l.map(p=>{const y=Ia(p.id);return`<button data-cemp="${ee(p.id)}" class="${K.emp===p.id?"on":""}">${y>=0?`<u class="dot" style="background:${Un(y)}"></u>`:""}${ee(p.name)}</button>`}).join("")}</div>`:""}
    ${n?r==="month"?y0(o):r==="week"?v0(o):r==="agenda"?I0(i):w0(af(!0)):'<div class="card"><div class="empty">Φόρτωση…</div></div>'}`;return t(u,f,"cal",'<button class="fab" data-cnew aria-label="Νέα εργασία">＋</button>')}function E0(n){const e=n!=="new"&&x.tasks.find(r=>r.id===n);if(n!=="new"&&!e)return!1;const t=K.preset||{};K.preset=null;const s=jo(t.kind==="due"?Ve().dueRems:Ve().defRems);return U={arg:n,t0:e||null,isNew:!e,canEdit:!e||Zl(e),canTick:!e||ru(e),msg:"",ask:!1,pick:null,err:!1,v:e?{kind:e.kind||"",title:e.title||"",date:e.date||"",time:e.time||"",rems:su(e),rep:e.rep||"",cust:e.cust||"",tel:e.tel||"",addr:e.addr||"",quoteId:e.quoteId||"",emps:(e.emps||[]).slice(),clr:typeof e.clr=="number"?e.clr:-1,notes:e.notes||"",chk:(e.chk||[]).map(r=>({tx:r.tx||"",dn:!!r.dn})),done:!!e.done,msList:e.msList||""}:{kind:t.kind||"",title:t.title||"",date:t.date!==void 0?t.date:fe(),time:"",rems:t.rems||s,rep:"",cust:t.cust||"",tel:t.tel||"",addr:t.addr||"",quoteId:t.quoteId||"",emps:[],clr:-1,notes:"",chk:[],done:!1,msList:t.msList||""}},!0}const jr=(n,e,t)=>`<div class="chips wrap">${n.map(([s,r])=>`<button ${t}="${ee(s)}" class="${e(s)?"on":""}">${r}</button>`).join("")}</div>`,b0=n=>{const e=x.quotes.find(t=>t.id===n);return e?`#${e.number||"—"} · ${e.customer&&e.customer.name||""}${e.subject?" · "+e.subject:""}`:"Συνδεδεμένη προσφορά"},lf=n=>[n.kind==="due"?"💶 "+n.title:n.title,n.date?va(n.date)+(n.time?" "+n.time:""):"",n.cust?"Πελάτης: "+n.cust:"",n.tel?"Τηλ: "+n.tel:"",n.addr?"Διεύθυνση: "+n.addr:"",(n.emps||[]).length?"Τεχνικοί: "+n.emps.map(iu).filter(Boolean).join(", "):"",n.notes?`
`+n.notes:"",(n.chk||[]).length?`
`+n.chk.map(e=>(e.dn?"✔ ":"▫ ")+e.tx).join(`
`):""].filter(Boolean).join(`
`);function T0(n,e,t,s){if((!U||U.arg!==n)&&!E0(n))return s(t("Εργασία","",'<a class="ib" href="#/cal">←</a>'),`<div class="card"><div class="empty">${e?"Η εργασία δεν βρέθηκε (ίσως σβήστηκε).":"Φόρτωση…"}</div></div>`,null);const r=U.v,i=U.canEdit,o=i?"":"disabled",c=!et(),l=(R,B,z="",j="")=>`<label class="f">${B}<span class="fw"><input class="in${R==="title"&&U.err?" ine":""}" data-tf="${R}" value="${ee(r[R]||"")}" ${o} ${z}>${j}</span></label>`,{def:u,lists:f}=wa(),p=U.isNew?r.kind==="due"?"Νέα λήξη / πληρωμή":"Νέα εργασία":i?"Επεξεργασία":"Εργασία",y=r.tel.replace(/\s/g,""),S=r.chk.filter(R=>R.dn).length,k=`${i?"":`<div class="upd">🔒 Την έγραψε ${ee(U.t0.by&&U.t0.by.name||"άλλος")}. Μπορείς να τη σημειώσεις ολοκληρωμένη και να τσεκάρεις το checklist.</div>`}
  <div class="card pad"><div class="ch">📅 Τι και πότε</div>
    ${i?`<div class="seg">${[["","🛠 Εργασία"],["due","💶 Λήξη / πληρωμή"]].map(([R,B])=>`<button data-tfk="${R}" class="${r.kind===R?"on":""}">${B}</button>`).join("")}</div>`:""}
    ${c&&U.isNew&&f.length>1?`<div class="f">Λίστα To Do</div>${jr(f.map(R=>[R.id,ee(R.name)]),R=>R===r.msList||!r.msList&&R===u,"data-tlist")}`:!U.isNew&&r.msList&&f.find(R=>R.id===r.msList)?`<div class="f">≡ Λίστα: ${ee(f.find(R=>R.id===r.msList).name)}</div>`:""}
    ${l("title",r.kind==="due"?"Τι λήγει / τι πληρώνεται":"Τίτλος",'placeholder="π.χ. Εγκατάσταση καμερών" autocomplete="off"')}
    <div class="two">${l("date","Ημερομηνία",'type="date"')}${l("time","Ώρα",`type="time" ${r.date?"":"disabled"}`)}</div>
    ${i?`<div class="chips wrap">${[["Σήμερα",fe()],["Αύριο",ut(fe(),1)],["+1 εβδομάδα",ut(fe(),7)],["+1 μήνας",ci(fe(),1)]].map(([R,B])=>`<button data-tdq="${B}" class="${r.date===B?"on":""}">${R}</button>`).join("")}${r.date?'<button data-tdq="">✕ Χωρίς ημερομηνία</button>':""}</div>`:""}
  </div>
  <div class="card pad"><div class="ch">🔔 Υπενθυμίσεις</div>
    ${i?jr(Ug.map(R=>[R,zc(R)]),R=>r.rems.includes(+R),"data-trem")+(r.date&&!r.time?'<div class="hint">Χωρίς ώρα, οι υπενθυμίσεις υπολογίζονται από τις 08:00.</div>':"")+(r.date?"":'<div class="hint">Οι υπενθυμίσεις χρειάζονται ημερομηνία.</div>'):`<div class="hint">${r.rems.map(zc).join(", ")||"Καμία"}</div>`}
    <div class="f" style="margin-top:8px">🔁 Επανάληψη</div>
    ${i?jr(Object.entries(Kc),R=>R===r.rep,"data-trep")+(r.rep?'<div class="hint">Όταν την ολοκληρώσεις, δημιουργείται αυτόματα η επόμενη.</div>':""):`<div class="hint">${Kc[r.rep]||"Καμία"}</div>`}
  </div>
  <div class="card pad"><div class="ch">👤 Πελάτης</div>
    ${c&&i?`<div class="actions"><button class="btn b2" data-tpick="cust">📇 Από πελάτες</button><button class="btn b2" data-tpick="quote">📄 ${r.quoteId?"Άλλη προσφορά":"Προσφορά"}</button></div>`:""}
    ${r.quoteId?`<div class="qlink"><a href="#/q/${encodeURIComponent(r.quoteId)}">🔗 ${ee(b0(r.quoteId))}</a>${c&&i?'<button class="x" data-tunq aria-label="Αποσύνδεση">✕</button>':""}</div>`:""}
    ${l("cust","Όνομα πελάτη",'autocomplete="off"')}
    ${l("tel","Τηλέφωνο",'inputmode="tel"',y?`<a class="fa" href="tel:${ee(y)}">📞</a>`:"")}
    ${l("addr","Διεύθυνση","",r.addr?`<a class="fa" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(r.addr)}">🗺️</a>`:"")}
  </div>
  ${c&&x.emps.length||i?`<div class="card pad"><div class="ch">👷 Ποιος και χρώμα</div>
    ${c&&li().length?`<div class="chips wrap">${li().map(R=>{const B=Ia(R.id),z=r.emps.includes(R.id);return`<button data-temp="${ee(R.id)}" class="${z?"on":""}" ${o}>${z?"✓ ":B>=0?`<u class="dot" style="background:${Un(B)}"></u>`:""}${ee(R.name)}</button>`}).join("")}</div>`:r.emps.length?`<div class="hint">${ee(r.emps.map(iu).filter(Boolean).join(", "))}</div>`:""}
    ${i?`<div class="f" style="margin-top:6px">Χρώμα</div><div class="clrs"><button data-tclr="-1" class="${r.clr<0?"on":""}">Αυτόματο</button>${Rs.map(([R,B],z)=>`<button data-tclr="${z}" class="sw${r.clr===z?" on":""}" style="background:${B}" aria-label="${R}"></button>`).join("")}</div>`:""}
  </div>`:""}
  <div class="card pad"><div class="ch">📝 Σημειώσεις</div>
    <textarea class="in" data-tf="notes" rows="4" placeholder="Ό,τι χρειάζεται να θυμάσαι…" ${o}>${ee(r.notes)}</textarea>
    <div class="actions"><button class="btn b2" data-tncopy>⧉ Αντιγραφή</button>${i?'<button class="btn b2" data-tnpaste>📋 Επικόλληση</button>':""}</div>
  </div>
  <div class="card pad"><div class="ch">☑ Checklist${r.chk.length?` <span class="muted">${S}/${r.chk.length}</span>`:""}</div>
    ${r.chk.length?`<div class="prog"><i style="width:${Math.round(S/r.chk.length*100)}%"></i></div>`:""}
    ${r.chk.map((R,B)=>`<div class="ci"><button class="tick${R.dn?" on":""}" data-tchktg="${B}" ${U.canTick?"":"disabled"}>${R.dn?"✓":""}</button>${i?`<input class="in" data-tchk="${B}" value="${ee(R.tx)}"><button class="x" data-tchkdel="${B}">✕</button>`:`<span class="${R.dn?"strike":""}">${ee(R.tx)}</span>`}</div>`).join("")}
    <div class="actions">${i?'<button class="btn b2" data-tchkadd>＋ Στοιχείο</button>':""}<button class="btn b2" data-tccopy ${r.chk.length?"":"disabled"}>⧉ Αντιγραφή</button>${i?'<button class="btn b2" data-tcpaste>📋 Επικόλληση</button>':""}</div>
    ${i?'<div class="hint">Επικόλληση: κάθε γραμμή του προχείρου γίνεται ξεχωριστό στοιχείο.</div>':""}
  </div>
  <div class="card pad"><div class="ch">✅ Κατάσταση</div>
    <label class="chk2"><input type="checkbox" data-tf="done" ${r.done?"checked":""} ${U.canTick?"":"disabled"}> ${r.done?"Ολοκληρώθηκε":"Ανοιχτή"}</label>
    ${U.t0&&U.t0.by&&U.t0.by.name?`<div class="hint">Την έγραψε: ${ee(U.t0.by.uid===(zn()||{}).uid?"εσύ":U.t0.by.name)}${U.t0.done&&U.t0.doneBy?" · ολοκλήρωσε: "+ee(U.t0.doneBy):""}</div>`:""}
  </div>
  ${U.msg?`<div class="err box">${ee(U.msg)}</div>`:""}
  ${!U.isNew&&i?`<button class="btn wide del" data-tdel>${U.ask?"Σίγουρα; Πάτα ξανά για διαγραφή":"🗑️ Διαγραφή"}</button>`:""}
  ${U.pick?A0():""}`;return`${t(p,"",'<a class="ib" data-tcancel>←</a>','<button class="ib" data-tcopy aria-label="Αντιγραφή">⧉</button><button class="ib" data-tshare aria-label="Αποστολή">📤</button>')}<main class="body ed">${k}</main><div class="bar"><button class="btn b2" data-tcancel>Άκυρο</button><button class="btn b1" data-tsave>💾 Αποθήκευση</button></div>`}function jg(){return U.pick.kind==="cust"?Ct().filter(n=>n.name&&n.name!=="(χωρίς όνομα)").sort((n,e)=>(e.last||0)-(n.last||0)).map(n=>({t:n.name,s:[n.info.phone,n.info.address].filter(Boolean).join(" · "),v:{cust:n.name,tel:n.info.phone||"",addr:n.info.address||""}})):x.quotes.filter(n=>!bi(n)).sort((n,e)=>(e.ts||0)-(n.ts||0)).map(n=>{const e=n.customer||{};return{t:`#${n.number||"—"} · ${e.name||""}`,s:[n.subject,e.address].filter(Boolean).join(" · "),v:{quoteId:n.id,cust:e.name||"",tel:e.phone||"",addr:e.address||"",q:!0}}})}function A0(){const n=U.pick.q.trim().toLowerCase(),e=jg().map((t,s)=>({...t,i:s})).filter(t=>!n||(t.t+" "+t.s).toLowerCase().includes(n)).slice(0,150);return`<div class="sheet" data-pkx><div class="sheet-in"><div class="sheet-h"><b>${U.pick.kind==="cust"?"Πελάτες":"Προσφορές"}</b><button class="ib dk" data-pkx>✕</button></div>
    <input class="search" id="pq" data-pq placeholder="🔍 Αναζήτηση…" value="${ee(U.pick.q)}">
    <div class="sheet-list">${e.map(t=>`<button class="prow" data-pk="${t.i}"><div class="t"><b>${ee(t.t)}</b><span>${ee(t.s)}</span></div></button>`).join("")||'<div class="empty">Τίποτα</div>'}</div></div></div>`}const Nt=(n,e)=>`<label class="tg"><span>${e}</span><input type="checkbox" data-stg="${n}" ${Ve()[n]?"checked":""}></label>`,Zt=(n,e,t)=>`<div class="f">${e}</div>${jr(t,s=>String(Ve()[n])===String(s),`data-s="${n}" data-v`)}`,uf=(n,e)=>`<div class="f">${e}</div>${jr(Ug.map(t=>[t,zc(t)]),t=>jo(Ve()[n]).includes(+t),`data-sr="${n}" data-v`)}`;async function au(n){await ii(),K.ms=await ge.msStatus(),n()}function S0(n,e){const t=Ve(),s=K.ms||{},{lists:r}=wa(),i=!et(),o=l=>l?new Date(l).toLocaleString(nr,{dateStyle:"short",timeStyle:"short"}):"",c=`${tr?"":'<div class="upd">🧪 Preview στον browser: ειδοποιήσεις, widgets, backup και To Do λειτουργούν μόνο στο κινητό.</div>'}
  <div class="h">🎨 Εμφάνιση ημερολογίου</div><div class="card pad">
    ${Zt("view","Οθόνη έναρξης",[["lists","Λίστες"],["month","Μήνας"],["week","Εβδομάδα"],["agenda","Ατζέντα"]])}
    <div class="f">Χρώμα εργασιών (προεπιλογή)</div><div class="clrs">${Rs.map(([l,u],f)=>`<button data-s="accent" data-v="${f}" class="sw${O(t.accent)===f?" on":""}" style="background:${u}" aria-label="${l}"></button>`).join("")}</div>
    ${Nt("sun","Η εβδομάδα ξεκινά Κυριακή")}${Nt("showDone","Εμφάνιση ολοκληρωμένων")}${Nt("compact","Συμπαγής λίστα (περισσότερα στην οθόνη)")}
  </div>
  ${i&&li().length?`<div class="h">👷 Χρώμα ανά τεχνικό</div><div class="card pad"><div class="hint">Οι εργασίες χωρίς δικό τους χρώμα παίρνουν το χρώμα του τεχνικού.</div>
    ${li().map(l=>{const u=Ia(l.id);return`<div class="erow" data-sec="${ee(l.id)}"><u class="dot lg" style="background:${u>=0?Un(u):"var(--line)"}"></u><b>${ee(l.name)}</b><span class="muted">${u>=0?Rs[u][0]:"Αυτόματο"}</span></div>
      ${K.emSel===l.id?`<div class="clrs"><button data-secv="${ee(l.id)}|-1" class="${u<0?"on":""}">Αυτόματο</button>${Rs.map(([f,p],y)=>`<button data-secv="${ee(l.id)}|${y}" class="sw${u===y?" on":""}" style="background:${p}" aria-label="${f}"></button>`).join("")}</div>`:""}`}).join("")}</div>`:""}
  <div class="h">🔔 Υπενθυμίσεις</div><div class="card pad">
    ${uf("defRems","Προεπιλογή για νέες εργασίες")}${uf("dueRems","Προεπιλογή για λήξεις / πληρωμές")}
    ${Nt("rep","Να ξαναχτυπά μέχρι να πατήσω «ΟΚ»")}
    ${t.rep?Zt("repMin","Κάθε",[2,5,10,15,30].map(l=>[l,l+"΄"]))+Zt("repMax","Μέχρι",[3,6,12,24].map(l=>[l,l+" φορές"])):""}
    ${Zt("snooze","Αναβολή",[5,10,15,30,60].map(l=>[l,l+"΄"]))}
    ${Nt("alarmSound","Δυνατός ήχος ξυπνητηριού")}${Nt("clockMode","Μέγιστη ακρίβεια (σαν ξυπνητήρι)")}
    <div class="actions"><button class="btn b2" data-sact="test">🔔 Δοκιμή</button><button class="btn b2" data-sact="notif">🔊 Ήχοι</button></div>
    <div class="hint">Αν το κινητό (Xiaomi, Huawei, Samsung) «κοιμίζει» τις εφαρμογές, βάλε το TechMate «Χωρίς περιορισμό» μπαταρίας:</div>
    <div class="actions"><button class="btn b2" data-sact="battery">🔋 Ρυθμίσεις μπαταρίας</button></div>
  </div>
  <div class="h">🔄 Συγχρονισμός και μπαταρία</div><div class="card pad">
    <div class="hint">Όσο η εφαρμογή είναι ανοιχτή, όλα ενημερώνονται αμέσως. Κλειστή, ελέγχει για νέες εργασίες μόνο όσο συχνά ορίσεις. Οι υπενθυμίσεις δεν εξαρτώνται από αυτό.</div>
    ${Zt("syncMin","Έλεγχος για νέες εργασίες",[[0,"Ποτέ"],[15,"15΄"],[30,"30΄"],[60,"1 ώρα"],[180,"3 ώρες"],[360,"6 ώρες"]])}
    ${Nt("notifyNew","Ειδοποίηση για νέα / αλλαγμένη εργασία")}
  </div>
  <div class="h">🧩 Widget</div><div class="card pad">
    <label class="f">Διαφάνεια φόντου: <b id="wav">${t.wAlpha}%</b><input type="range" min="20" max="100" step="10" value="${t.wAlpha}" data-sw class="rng"></label>
    ${Zt("wMode","Τι δείχνει το widget-λίστα",[["todo","Εργασίες (όπως το To Do)"],["cal","Μόνο ραντεβού με ημερομηνία"]])}
    ${t.wMode==="todo"&&r.length>1?Zt("wList","Λίστα To Do στο widget",[["","Όλες"]].concat(r.map(l=>[l.id,ee(l.name)]))):""}
    ${Zt("wDays",t.wMode==="todo"?"Μαζί με ραντεβού για":"Η λίστα του widget δείχνει",[[1,"Σήμερα"],[2,"Σήμερα & αύριο"],[3,"3 μέρες"],[7,"Εβδομάδα"]])}
    <div class="hint">Για να το προσθέσεις: πάτα παρατεταμένα την αρχική οθόνη → Widgets → TechMate.</div>
  </div>
  ${i?`<div class="h">💾 Backup στη συσκευή / Google Drive</div><div class="card pad">
    <div class="hint">Σώζει ΟΛΟ το TechMate (προσφορές, πελάτες, λογιστικά, εργασίες…) σε αρχείο που διαλέγεις. Για Google Drive, πάτα ☰ στον επιλογέα και διάλεξε «Drive». Μόνο διαβάζει τη βάση, δεν αλλάζει τίποτα.</div>
    <div class="actions"><button class="btn b2" data-sact="bpick">📁 ${t.bUri?"Άλλο αρχείο":"Επιλογή αρχείου"}</button>${t.bUri?'<button class="btn b2" data-sact="bnow">☁️ Backup τώρα</button>':""}</div>
    ${t.bUri?Nt("bAuto","Αυτόματο backup μία φορά τη μέρα (όταν ανοίγεις την εφαρμογή)")+`<div class="hint">${t.bLast?"Τελευταίο: "+o(t.bLast):"Δεν έχει γίνει ακόμα"}</div>`:""}
    <label class="btn b2 wide filebtn">♻️ Επαναφορά εργασιών που λείπουν, από backup…<input type="file" accept="application/json,.json" data-restore hidden></label>
    <div class="hint">Η επαναφορά προσθέτει ΜΟΝΟ εργασίες που δεν υπάρχουν πια. Όσες υπάρχουν δεν αλλάζουν.</div>
  </div>
  <div class="h">✅ Microsoft To Do</div><div class="card pad">
    ${s.connected?`<div class="hint">👤 ${ee(s.account||"Συνδεδεμένο")}</div><div class="hint">${s.status==="sync"?"⏳ Συγχρονισμός…":s.status==="login"?"⚠️ Χρειάζεται ξανά σύνδεση":s.status&&s.status!=="ok"?"⚠️ "+ee(s.status):s.last?"✓ Τελευταίος συγχρονισμός: "+o(s.last):"✓ Συνδεδεμένο"}</div>
        <div class="actions">${s.status==="login"?'<button class="btn b1" data-sact="mslogin">Σύνδεση</button>':'<button class="btn b2" data-sact="mssync">🔄 Συγχρονισμός τώρα</button>'}<button class="btn b2" data-sact="msout">Αποσύνδεση</button></div>
        <div class="hint">Συγχρονίζονται οι λίστες που έχεις διαλέξει στο TechMate. Οι νέες εργασίες πάνε στην κύρια λίστα.</div>`:'<div class="hint">Σύνδεσε τον λογαριασμό Microsoft: οι εργασίες πηγαίνουν και έρχονται από το To Do απευθείας από το κινητό, με την ίδια λογική με το PWA (χωρίς διπλές).</div><button class="btn b1 wide" data-sact="mslogin">Σύνδεση με Microsoft</button>'}
  </div>`:'<div class="card pad"><div class="hint">Τον συγχρονισμό με το To Do και τα backup τα κάνει ο διαχειριστής.</div></div>'}
  <div class="card pad">${Nt("autoUpd","Αυτόματος έλεγχος για νέα έκδοση εφαρμογής")}</div>`;return e(n("Ρυθμίσεις ημερολογίου","Ειδοποιήσεις · widget · backup · To Do",'<a class="ib" href="#/cal">←</a>'),c,null)}function Hc(){const n=t=>Object.fromEntries((t||[]).map(s=>{const r={...s};return delete r.id,[s.id,r]})),e={};return["quotes","custs","tasks","ldocs","lpays","emps","products","smoves","wdays","wpays"].forEach(t=>e[t]=n(x[t])),JSON.stringify({app:"TechMate",ver:2,at:new Date().toISOString(),tasks:e.tasks,data:e,settings:x.st},null,1)}async function R0(n){const e=Ve();if(!tr||!n||et()||!e.bUri||!e.bAuto||!x.tasks.length||!x.quotes.length||Date.now()-O(e.bLast)<20*36e5)return;const t=await ge.backupWrite(Hc());t&&t.ok&&await ii()}async function P0(n,e,t){try{const s=JSON.parse(await n.text()),r=s.tasks||s.data&&s.data.tasks||{},i=new Set(x.tasks.map(c=>c.id));let o=0;Object.keys(r).forEach(c=>{i.has(c)||!r[c]||typeof r[c]!="object"||(pt("tasks",{...r[c],id:c}),o++)}),e(o?`Επαναφέρθηκαν ${o} εργασίες που έλειπαν.`:"Δεν έλειπε καμία εργασία. Δεν άλλαξε τίποτα.")}catch{e("Το αρχείο δεν είναι σωστό backup.")}t()}function Gg(n){const e=K.quick.trim();if(!e)return;const t=K.list,s=ou(null,{title:e,date:t==="myday"?fe():"",rems:[],msList:["myday","planned","all"].includes(t)?"":t});if(s.msg)return n(s.msg);K.quick="",n("Προστέθηκε: "+e)}function k0(){if(K.view==="lists"){const e=K.list;Ps({date:e==="myday"||e==="planned"?fe():"",msList:["myday","planned","all"].includes(e)?"":e})}else Ps({date:zs()});location.hash="#/t/new"}async function C0(n,e,t){const s={test:async()=>{const r=await ge.testNotif();t(r&&r.error?r.error:tr?"Στάλθηκε δοκιμαστική ειδοποίηση":"Μόνο στο κινητό")},notif:()=>ge.openNotifSettings(),battery:()=>ge.openBattery(),mslogin:()=>ge.msLogin(),mssync:async()=>{K.ms={...K.ms||{},status:"sync"},e();const r=await ge.msSync();t(r&&r.ok?"Συγχρονίστηκε με το To Do":"Ο συγχρονισμός απέτυχε")},msout:async()=>{await ge.msDisconnect(),t("Αποσυνδέθηκε το Microsoft To Do")},bpick:async()=>{const r=await ge.backupPick();if(r&&r.error)return t(r.error);if(r&&r.ok){await ii();const i=await ge.backupWrite(Hc());t(i&&i.ok?"Έγινε το πρώτο backup":"Backup: "+(i&&i.error||"σφάλμα"))}},bnow:async()=>{const r=await ge.backupWrite(Hc());t(r&&r.ok?"Έγινε backup":"Backup: "+(r&&r.error||"σφάλμα"))}}[n];s&&await s(),await ii(),K.ms=await ge.msStatus(),e()}function D0(n,e,t){const s=n.closest("[data-tk],[data-cv],[data-csel],[data-cmon],[data-cwk],[data-cemp],[data-clist],[data-csrch],[data-ctoday],[data-cdone],[data-cnew],[data-cqa],[data-tfk],[data-trem],[data-trep],[data-temp],[data-tclr],[data-tdq],[data-tlist],[data-tunq],[data-tpick],[data-pk],[data-pkx],[data-tchkadd],[data-tchkdel],[data-tchktg],[data-tncopy],[data-tnpaste],[data-tccopy],[data-tcpaste],[data-tcopy],[data-tshare],[data-tsave],[data-tcancel],[data-tdel],[data-s],[data-sr],[data-sec],[data-secv],[data-sact]");if(!s)return!1;const r=s.dataset;if(r.tk){const o=x.tasks.find(l=>l.id===r.tk);if(!o)return!0;const c=!o.done;return cc(o,c),t((c?"✓ Ολοκληρώθηκε: ":"Άνοιξε ξανά: ")+(o.title||""),{label:"Αναίρεση",fn:()=>{const l=x.tasks.find(u=>u.id===o.id);l&&cc(l,!c)}}),!0}if(r.cv)return K.view=r.cv,e(),!0;if(r.csel)return K.sel=r.csel,K.view==="week"&&(K.view="month"),e(),!0;if(r.cmon)return K.sel=ci(zs().slice(0,8)+"01",+r.cmon),e(),!0;if(r.cwk)return K.sel=ut(zs(),7*r.cwk),e(),!0;if("cemp"in r)return K.emp=K.emp===r.cemp?"":r.cemp,e(),!0;if(r.clist)return K.list=r.clist,e(),!0;if("csrch"in r){K.srch=!K.srch,K.srch||(K.q=""),e();const o=document.getElementById("csq");return o&&o.focus(),!0}if("ctoday"in r)return K.sel=fe(),e(),!0;if("cdone"in r)return K.showDone=!K.showDone,e(),!0;if("cnew"in r)return k0(),!0;if("cqa"in r)return Gg(t),e(),!0;if(r.s!==void 0&&r.v!==void 0){const o=Ve()[r.s],c=typeof o=="number"?+r.v:typeof o=="boolean"?r.v==="true":r.v;return Br(r.s,c).then(e),!0}if(r.sr){const o=jo(Ve()[r.sr]),c=+r.v,l=o.includes(c)?o.filter(u=>u!==c):o.concat(c);return Br(r.sr,l.join(",")).then(e),!0}if(r.secv){const[o,c]=r.secv.split("|"),l=$g();return+c<0?delete l[o]:l[o]=+c,K.emSel="",Br("empClr",JSON.stringify(l)).then(e),!0}if(r.sec)return K.emSel=K.emSel===r.sec?"":r.sec,e(),!0;if(r.sact)return C0(r.sact,e,t),!0;if(!U)return!1;const i=U.v;if("pkx"in r)return s.classList.contains("sheet")&&n!==s?!0:(U.pick=null,e(),!0);if(r.pk){const o=jg()[+r.pk];if(o){const c=o.v;c.q?(i.quoteId=c.quoteId,i.cust||(i.cust=c.cust),i.tel||(i.tel=c.tel),i.addr||(i.addr=c.addr),i.title||(i.title="Εγκατάσταση – "+c.cust)):(i.cust=c.cust,c.tel&&(i.tel=c.tel),c.addr&&(i.addr=c.addr))}return U.pick=null,e(),!0}if(r.tfk!==void 0)i.kind!==r.tfk&&U.isNew&&(i.rems=jo(r.tfk==="due"?Ve().dueRems:Ve().defRems)),i.kind=r.tfk;else if(r.trem!==void 0){const o=+r.trem;i.rems=i.rems.includes(o)?i.rems.filter(c=>c!==o):i.rems.concat(o)}else if(r.trep!==void 0)i.rep=r.trep;else if(r.temp){const o=i.emps.indexOf(r.temp);o>=0?i.emps.splice(o,1):i.emps.push(r.temp)}else if(r.tclr!==void 0)i.clr=+r.tclr;else if(r.tdq!==void 0)i.date=r.tdq,i.date||(i.time="");else if(r.tlist)i.msList=r.tlist;else if("tunq"in r)i.quoteId="";else if(r.tpick)U.pick={kind:r.tpick,q:""};else if("tchkadd"in r)i.chk.push({tx:"",dn:!1});else if(r.tchkdel)i.chk.splice(+r.tchkdel,1);else if(r.tchktg){const o=i.chk[+r.tchktg];o&&U.canTick&&(o.dn=!o.dn)}else{if("tncopy"in r)return ge.copy(i.notes),t("Αντιγράφηκαν οι σημειώσεις"),!0;if("tnpaste"in r)return ge.paste().then(o=>{if(!o)return t("Το πρόχειρο είναι άδειο");i.notes=i.notes.trim()?i.notes.trimEnd()+`
`+o:o,t("Επικολλήθηκε"),e()}),!0;if("tccopy"in r)return ge.copy(i.chk.map(o=>(o.dn?"✔ ":"▫ ")+o.tx).join(`
`)),t("Αντιγράφηκε το checklist"),!0;if("tcpaste"in r)return ge.paste().then(o=>{const c=String(o||"").split(/\r?\n/).map(l=>l.trim()).filter(Boolean).map(l=>({tx:l.replace(/^([-*•▫☐☑✔✓]|\[[ xX]?\]|\d+[.)])\s*/,""),dn:/^(☑|✔|✓|\[[xX]\])/.test(l)})).filter(l=>l.tx);if(!c.length)return t("Το πρόχειρο είναι άδειο");i.chk.push(...c),t(`Προστέθηκαν ${c.length} στοιχεία`),e()}),!0;if("tcopy"in r)return ge.copy(lf(i)),t("Αντιγράφηκε η εργασία"),!0;if("tshare"in r)return ge.share(lf(i)),!0;if("tcancel"in r)return U=null,history.length>1?history.back():location.replace("#/cal"),!0;if("tdel"in r)if(!U.ask)U.ask=!0;else{const o=p0(U.t0);if(o.msg)U.msg=o.msg,U.ask=!1;else{const c=U.t0.title;return U=null,t("Διαγράφηκε: "+c),location.replace("#/cal"),!0}}else if("tsave"in r){if(U.canEdit){const l=ou(U.isNew?null:U.arg,i);if(l.msg)return U.msg=l.msg,U.err=!i.title.trim(),e(),!0}else{const l=x.tasks.find(f=>f.id===U.arg)||U.t0,u=i.chk.filter(f=>f.tx.trim());JSON.stringify(u)!==JSON.stringify((l.chk||[]).map(f=>({tx:f.tx,dn:!!f.dn})))&&f0(l,u),!!i.done!=!!l.done&&cc(l,i.done)}const o=i.title.trim(),c=U.isNew;return U=null,t(c?"Προστέθηκε: "+o:"Αποθηκεύτηκε"),history.length>1?history.back():location.replace("#/cal"),!0}}return e(),!0}function V0(n,e){const t=n.dataset;if("csq"in t){K.q=n.value,e();const s=document.getElementById("csq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if("cqv"in t)return K.quick=n.value,!0;if("sw"in t){const s=document.getElementById("wav");return s&&(s.textContent=n.value+"%"),!0}if(!U)return!1;if("pq"in t){U.pick.q=n.value,e();const s=document.getElementById("pq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(t.tchk!==void 0){const s=U.v.chk[+t.tchk];return s&&(s.tx=n.value),!0}return t.tf?(U.v[t.tf]=n.type==="checkbox"?n.checked:n.value,U.msg&&(U.msg=""),t.tf==="title"&&(U.err=!1),!0):!1}function N0(n,e,t){const s=n.dataset;return s.stg?(Br(s.stg,n.checked).then(e),!0):"sw"in s?(Br("wAlpha",+n.value).then(e),!0):"restore"in s?(n.files&&n.files[0]&&P0(n.files[0],t,e),!0):U&&(s.tf==="date"||s.tf==="done")?(U.v[s.tf]=n.type==="checkbox"?n.checked:n.value,s.tf==="date"&&!n.value&&(U.v.time=""),e(),!0):!1}function x0(n,e,t){if(n.key==="Enter"&&n.target.dataset&&"cqv"in n.target.dataset){n.preventDefault(),K.quick=n.target.value,Gg(t),e();const s=document.querySelector("[data-cqv]");return s&&s.focus(),!0}return!1}let Ar=null;function zg(n,e){if(!n.target.closest||!n.target.closest("#mgrid")){Ar=null;return}if(n.type==="touchstart")Ar=n.touches[0].clientX;else if(n.type==="touchend"&&Ar!==null){const t=n.changedTouches[0].clientX-Ar;Ar=null,Math.abs(t)>70&&(K.sel=ci(zs().slice(0,8)+"01",t<0?1:-1),e())}}function O0(){const n=fe(),e=Wc().filter(t=>!t.done);return{today:Wc().filter(t=>t.date===n).sort(ui),late:e.filter(t=>t.date&&t.date<n).sort((t,s)=>t.date.localeCompare(s.date)),dues:e.filter(t=>t.kind==="due"&&t.date&&t.date>n&&t.date<=ut(n,14)).sort((t,s)=>t.date.localeCompare(s.date))}}let hf=null,df="";function L0(){!tr||!mg.tasks||(clearTimeout(hf),hf=setTimeout(()=>{const n={};x.tasks.forEach(i=>{const o={...i};delete o.id,n[i.id]=o});const e=JSON.stringify(n),t=x.emps.map(i=>({id:i.id,name:i.name||""})),s=wa(),r=e.length+":"+e+JSON.stringify(t)+JSON.stringify(s);r!==df&&(df=r,ge.setTasks(e,t,s))},400))}const It=document.getElementById("app"),ae=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Zi=n=>O(n).toLocaleString("el-GR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €",Ks=n=>Math.round(O(n)).toLocaleString("el-GR")+" €",M0=n=>n?new Date(n).toLocaleDateString("el-GR",{day:"numeric",month:"short"}):"",Kg=n=>String(n||"?").split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]).join("").toUpperCase(),$0={pending:"p-a",accepted:"p-ok",done:"p-ok",rejected:"p-b"};let Ft=null,ft=!1;const Fe={qf:"all",cq:"",stAsk:null};let _e=null;const F0=[["home","🏠","Αρχική"],["cal","📅","Ημερολόγιο"],["quotes","📄","Προσφορές"],["custs","👥","Πελάτες"],["menu","☰","Μενού"]],U0=n=>`<nav class="nav">${F0.filter(([e])=>!et()||e==="cal"||e==="menu").map(([e,t,s])=>`<a href="#/${e}" class="${e===n?"on":""}"><i>${t}</i>${s}</a>`).join("")}</nav>`,Ue=(n,e,t="",s="")=>`<header class="top">${t}<h1>${ae(n)}${e?`<span class="sm">${ae(e)}</span>`:""}</h1>${s}</header>`,Ws=n=>`<a class="ib" href="#/${n}">←</a>`,He=(n,e,t,s="")=>`${n}<main class="body">${e}</main>${s}${t?U0(t):""}`;function B0(n=""){return`<div class="login"><img class="lico" src="/icon-192.png" alt=""><div class="logo">TechMate</div><p>Συνδέσου με τον ίδιο λογαριασμό που έχεις στο PWA.</p>
  <form id="lf"><label>Email<input name="e" type="email" autocomplete="username" required></label>
  <label>Κωδικός<input name="p" type="password" autocomplete="current-password" required></label>
  <label class="chk"><input type="checkbox" id="sp"> Εμφάνιση κωδικού</label>
  ${n?`<div class="err">${ae(n)}</div>`:""}<button class="btn b1">Σύνδεση</button></form></div>`}function q0(){return x.quotes.filter(n=>!bi(n)&&lt(n)==="pending")}function Qc(){return we.state==="downloading"?`<div class="upd">⬇️ Κατεβαίνει η έκδοση ${ae(we.latest.version)}… ${we.pct}%</div>`:we.state!=="available"?"":`<div class="upd">⬇️ Νέα έκδοση ${ae(we.latest.version)}${we.latest.notes?": "+ae(we.latest.notes):""}${we.needApk?"<br>Χρειάζεται νέο αρχείο εγκατάστασης (APK).":""}${we.err?`<br><span class="bad">${ae(we.err)}</span>`:""}
    <button class="btn b1 sm" data-up="apply">${we.needApk?"Λήψη APK":"Ενημέρωση τώρα"}</button></div>`}function ff(){const n={checking:"Έλεγχος…",none:"Έχεις την τελευταία έκδοση.",error:we.err}[we.state]||"";return`<div class="card pad ver"><div><b>TechMate ${ae(bg)}</b>${n?`<span>${ae(n)}</span>`:""}</div><button class="btn b2 sm" data-up="check">Έλεγχος ενημέρωσης</button></div>`}function pf(){const n=new Date,e=new Date(n.getFullYear(),n.getMonth(),1).getTime(),t=x.quotes.filter(c=>!bi(c)&&["accepted","done"].includes(lt(c))&&(c.ts||0)>=e).reduce((c,l)=>c+O(l.total),0),s=x.ldocs.filter(c=>c.kind==="sale").reduce((c,l)=>c+gg(l),0),r=O0(),i=n.getHours(),o=i<12?"Καλημέρα":i<18?"Καλησπέρα":"Καλό βράδυ";return He(Ue("TechMate",`${o} · ${n.toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}`,"",'<a class="ib" href="#/menu">👤</a>'),`${pg?'<div class="upd">🧪 Δοκιμαστικά δεδομένα (preview)</div>':""}${Qc()}
    <div class="qa six"><a href="#/edit/new"><i>📝</i>Προσφορά</a><a data-hnew=""><i>📅</i>Ραντεβού</a><a data-hnew="due"><i>💶</i>Λήξη</a><a href="#/books/newdoc"><i>🧾</i>Έξοδο</a><a href="#/soon/Φωτογραφίες"><i>📷</i>Φωτο</a><a href="#/soon/Barcode"><i>🔍</i>Barcode</a></div>
    <div class="kpis">
      <a class="kpi" href="#/quotes"><b>${q0().length}</b><span>Σε αναμονή απάντησης</span></a>
      <div class="kpi"><b>${Ks(t)}</b><span>Δεκτές αυτόν τον μήνα</span></div>
      <a class="kpi" href="#/custs"><b>${Ct().length}</b><span>Πελάτες</span></a>
      <div class="kpi"><b class="${s>0?"bad":""}">${Ks(s)}</b><span>Μου χρωστούν</span></div>
    </div>
    <div class="h">Σήμερα <a class="hl" href="#/cal">Ημερολόγιο ›</a></div>
    <div class="card">${r.today.length?r.today.map(c=>gn(c,!1)).join(""):'<div class="empty">Τίποτα για σήμερα 🙂</div>'}</div>
    ${r.late.length?`<div class="h badh">⚠️ Εκκρεμούν από πριν (${r.late.length})</div><div class="card">${r.late.slice(0,5).map(c=>gn(c,!0)).join("")}${r.late.length>5?`<a class="empty" href="#/cal">+${r.late.length-5} ακόμα ›</a>`:""}</div>`:""}
    ${r.dues.length?`<div class="h">💶 Λήξεις & πληρωμές (14 μέρες)</div><div class="card">${r.dues.map(c=>gn(c,!0)).join("")}</div>`:""}`,"home")}function Wg(n){const e=lt(n),t=n.customer&&n.customer.name||"";return`<a class="row" href="#/q/${encodeURIComponent(n.id)}"><div class="av">${ae(Kg(t))}</div>
  <div class="t"><b>${ae(n.subject||"(χωρίς θέμα)")}</b><span>#${ae(n.number||"—")} · ${ae(t)} · ${M0(n.ts)}</span></div>
  <div class="r"><div class="amt">${Ks(n.total)}</div><span class="pill ${$0[e]||"p-a"}">${po[e]||e}</span></div></a>`}function j0(){const n=x.quotes.filter(s=>!bi(s)).sort((s,r)=>(r.ts||0)-(s.ts||0)),e=[["all","Όλες"],["pending","Σε αναμονή"],["accepted","Δεκτές"],["done","Ολοκληρ."],["rejected","Απορρίφθ."]],t=Fe.qf==="all"?n:n.filter(s=>lt(s)===Fe.qf);return He(Ue("Προσφορές",`${n.length} συνολικά`),`<div class="chips">${e.map(([s,r])=>`<button data-qf="${s}" class="${Fe.qf===s?"on":""}">${r}</button>`).join("")}</div>
    <div class="card">${t.length?t.map(Wg).join(""):`<div class="empty">${ft?"Καμία προσφορά":"Φόρτωση…"}</div>`}</div>`,"quotes",'<a class="fab" href="#/edit/new">＋</a>')}function G0(n){const e=x.quotes.find(o=>o.id===n);if(!e)return He(Ue("Προσφορά","",Ws("quotes")),`<div class="empty">${ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"quotes");const t=lt(e),s=e.customer||{},r=e.lines||[],i=r.reduce((o,c)=>o+O(c.qty)*O(c.price)*(1-O(c.disc)/100),0);return He(Ue(`#${e.number||"—"}`,po[t],Ws("quotes")),`<div class="card"><div class="fld"><label>Πελάτης</label><a class="v" href="#/c/${encodeURIComponent(Pe(s.name)||"_none")}">${ae(s.name)} ›</a></div>
    <div class="fld" style="margin:0"><label>Θέμα</label><div class="v">${ae(e.subject)}</div></div></div>
    <div class="h">Κατάσταση</div>
    <div class="card pad"><div class="seg four">${Object.keys(po).map(o=>`<button data-st="${o}" class="${o===t?"on":""}">${po[o]}</button>`).join("")}</div>
    ${Fe.stAsk&&Fe.stAsk.id===e.id?`<div class="ask"><b>Αλλαγή σε «${ae(mo[Fe.stAsk.st])}»;</b>${RA(e,Fe.stAsk.st).map(o=>`<div>• ${ae(o)}</div>`).join("")}
      <div class="actions"><button class="btn b2" data-stno>Άκυρο</button><button class="btn b1" data-stok>Ναι, αλλαγή</button></div></div>`:""}</div>
    <div class="h">Είδη (${r.length})</div>
    <div class="card">${r.map(o=>`<div class="item"><div class="t"><b>${ae(o.desc)}</b><span>${O(o.qty)} × ${Zi(o.price)}${O(o.disc)?` · −${O(o.disc)}%`:""}</span></div><div class="amt">${Zi(O(o.qty)*O(o.price)*(1-O(o.disc)/100))}</div></div>`).join("")||'<div class="empty">Χωρίς είδη</div>'}</div>
    <div class="card"><div class="tot"><span>Καθαρό</span><span>${Zi(i)}</span></div>
    <div class="tot big"><span>Σύνολο${e.vatMode==="off"?" (χωρίς ΦΠΑ)":" με ΦΠΑ"}</span><span>${Zi(e.total)}</span></div></div>`,null,`<div class="bar"><a class="btn b2" href="#/edit/${encodeURIComponent(e.id)}">✏️ Επεξεργασία</a><button class="btn b2" data-qappt="${ae(e.id)}">📅 Ραντεβού</button><a class="btn b1" href="#/soon/Αποστολή PDF">📤 PDF</a></div>`)}function z0(){const n=Pe(Fe.cq),e=Ct().filter(t=>!n||Pe(t.name).includes(n)).sort((t,s)=>(s.last||0)-(t.last||0));return He(Ue("Πελάτες",`${e.length}`),`<input class="search" id="cq" placeholder="🔍 Αναζήτηση πελάτη" value="${ae(Fe.cq)}">
    <div class="card">${e.map(t=>`<a class="row" href="#/c/${encodeURIComponent(t.k)}"><div class="av">${ae(Kg(t.name))}</div>
      <div class="t"><b>${ae(t.name)}</b><span>${t.quotes.length} προσφορές${t.info.phone?" · "+ae(t.info.phone):""}</span></div>
      <div class="r">${t.owed>0?`<div class="amt bad">${Ks(t.owed)}</div><span class="muted">χρωστάει</span>`:""}</div></a>`).join("")||`<div class="empty">${ft?"Κανένας πελάτης":"Φόρτωση…"}</div>`}</div>`,"custs",'<a class="fab" href="#/ce/new">＋</a>')}function K0(n){const e=Ct().find(r=>r.k===n);if(!e)return He(Ue("Πελάτης","",Ws("custs")),`<div class="empty">${ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"custs");const t=e.info,s=t.phone.replace(/\s/g,"");return He(Ue(e.name,[t.address,t.phone].filter(Boolean).join(" · "),Ws("custs"),s?`<a class="ib" href="tel:${ae(s)}">📞</a>`:""),`<div class="kpis"><div class="kpi"><b>${Ks(e.won)}</b><span>Δεκτές προσφορές</span></div><div class="kpi"><b class="${e.owed>0?"bad":""}">${Ks(e.owed)}</b><span>Υπόλοιπο</span></div></div>
    <div class="actions">${s?`<a class="btn b2" href="viber://chat?number=${ae(s.startsWith("+")?s:"+30"+s)}">💬 Viber</a>`:""}
    ${t.address?`<a class="btn b2" href="https://maps.google.com/?q=${encodeURIComponent(t.address)}">🗺️ Οδηγίες</a>`:""}
    ${t.email?`<a class="btn b2" href="mailto:${ae(t.email)}">✉️ Email</a>`:""}</div>
    <div class="actions"><a class="btn b2" href="#/ce/${encodeURIComponent(e.k)}">✏️ Στοιχεία</a><button class="btn b2" data-newq="${ae(e.k)}">＋ Προσφορά</button><button class="btn b2" data-newt="${ae(e.k)}">＋ Εργασία</button></div>
    ${e.rec&&e.rec.notes?`<div class="card pad note">${ae(e.rec.notes)}</div>`:""}
    <div class="h">Προσφορές (${e.quotes.length})</div>
    <div class="card">${e.quotes.sort((r,i)=>(i.ts||0)-(r.ts||0)).map(Wg).join("")||'<div class="empty">Καμία</div>'}</div>
    ${e.mins.length?`<div class="h">Παλιές εγκαταστάσεις (${e.mins.length})</div>`:""}
    <div class="h">Φωτογραφίες δουλειάς</div><div class="card"><a class="empty" href="#/soon/Φωτογραφίες">📷 Έρχεται στο επόμενο βήμα</a></div>`,"custs")}const Sr=(n,e,t="")=>`<label class="f">${e}<input class="in" data-f="${n}" value="${ae(_e.v[n]||"")}" ${t}></label>`,W0=n=>`${_e.msg?`<div class="err box">${ae(_e.msg)}</div>`:""}`,H0='<div class="bar"><button class="btn b2" data-fa="cancel">Άκυρο</button><button class="btn b1" data-fa="save">💾 Αποθήκευση</button></div>';function Q0(n){if(!_e||_e.kind!=="cust"||_e.arg!==n){const e=n!=="new"&&Ct().find(t=>t.k===n);if(n!=="new"&&!e)return He(Ue("Πελάτης","",Ws("custs")),`<div class="empty">${ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);_e={kind:"cust",arg:n,v:e?{name:e.name,...e.info,notes:e.rec&&e.rec.notes||""}:{name:""}}}return`${Ue(n==="new"?"Νέος πελάτης":"Στοιχεία πελάτη","",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${Sr("name","Όνομα",'autocomplete="off"')}${Sr("phone","Τηλέφωνο",'inputmode="tel"')}${Sr("email","Email",'inputmode="email"')}${Sr("afm","ΑΦΜ",'inputmode="numeric"')}${Sr("address","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${ae(_e.v.notes||"")}</textarea></label></div>
    ${n!=="new"&&Pe(_e.v.name)!==n?'<div class="upd">Η αλλαγή ονόματος θα περάσει και στις προσφορές, στα παραστατικά και στις εισπράξεις του πελάτη.</div>':""}${W0()}</main>${H0}`}function J0(n){if(n==="cancel"){const t=_e.arg;return _e=null,location.replace(t==="new"?"#/custs":"#/c/"+encodeURIComponent(t))}const e=kA(_e.arg==="new"?"":_e.arg,_e.v);if(!e.ok)return _e.msg=e.msg,ke();_e=null,location.replace("#/c/"+encodeURIComponent(e.k))}const Y0=[["📄","Προσφορές","Νέα · Κατάλογος · Αποθηκευμένες · Κατάσταση · Δεκτές & παραγγελίες · Ιστορικό αλλαγών · Διαγραμμένα","#/quotes"],["📒","Λογιστικά","Σύνοψη · Παραστατικά · Πληρωμές · Υπόλοιπα","#/books/sum"],["🛡️","Εγκαταστάσεις","Εγκαταστάσεις · Οδηγίες"],["👷","Μεροκάματα","Καταχώρηση · Πληρωμή υπαλλήλου · Υπόλοιπα"],["📦","Αποθήκη","Απόθεμα · Κινήσεις · Λίστα παραγγελίας · Εργαλεία που λείπουν"],["🌐","Ιστοσελίδα","Περιεχόμενο · Άρθρα · Μηνύματα"],["📅","Ημερολόγιο & ειδοποιήσεις","Υπενθυμίσεις · Widget · Χρώματα · Backup · Microsoft To Do","#/cset"],["⚙️","Ρυθμίσεις","Εταιρεία & PDF · Τιμές/αρίθμηση · Τράπεζες · Χρήστες ομάδας · PIN · Ειδοποιήσεις · Backup"]];function X0(){return et()?He(Ue("Μενού",Ft?Ft.email:""),`<div class="card"><a class="mi" href="#/cset"><div class="ic">📅</div><div class="t"><b>Ημερολόγιο & ειδοποιήσεις</b><span>Υπενθυμίσεις · Widget · Χρώματα</span></div></a></div><div class="card"><div class="empty">Ο λογαριασμός σου βλέπει το Ημερολόγιο. Τα μεροκάματα και τα εργαλεία που λείπουν έρχονται σύντομα.</div></div>${Qc()}${ff()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu"):He(Ue("Μενού",Ft?Ft.email:""),`<div class="card">${Y0.map(([n,e,t,s])=>`<a class="mi" href="${s||"#/soon/"+e}"><div class="ic">${n}</div><div class="t"><b>${e}${s?"":' <span class="soon">σύντομα</span>'}</b><span>${t}</span></div></a>`).join("")}</div>
    ${Qc()}${ff()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu")}function Z0(n){return He(Ue(n,"",'<a class="ib" href="javascript:history.back()">←</a>'),`<div class="card"><div class="empty">🛠️ Το «${ae(n)}» φτιάχνεται στα επόμενα βήματα.<br>Μέχρι τότε γίνεται από το PWA, και φαίνεται αμέσως εδώ.</div></div>`,null)}function ke(){if(!Ft)return;const[n,e]=location.hash.replace(/^#\//,"").split("/").map(decodeURIComponent),t={home:pf,quotes:j0,q:()=>G0(e),custs:z0,c:()=>K0(e),cal:()=>cf(ft,Ue,He,e),agenda:()=>cf(ft,Ue,He),t:()=>T0(e,ft,Ue,He),cset:()=>S0(Ue,He),menu:X0,soon:()=>Z0(e)};if(n==="edit")return Hg(e);ZA(),Object.assign(t,{ce:()=>Q0(e),books:()=>zA(e,ft)}),n!=="ce"&&(_e=null),n!=="t"&&m0(),n!=="q"&&(Fe.stAsk=null),n!=="books"&&LA();const s=scrollY,r=et()&&!["cal","t","menu","cset"].includes(n)?t.cal:t[n]||pf;if(It.innerHTML=r(),n==="custs"){const o=document.getElementById("cq");o.oninput=()=>{Fe.cq=o.value,ke();const c=document.getElementById("cq");c.focus(),c.setSelectionRange(c.value.length,c.value.length)}}const i=document.getElementById("out");i&&(i.onclick=()=>{confirm("Αποσύνδεση; Οι υπενθυμίσεις σε αυτό το κινητό θα σταματήσουν μέχρι να ξανασυνδεθείς.")&&(ge.clearSession(),Go="",eA())}),scrollTo(0,s)}const eS=(n,e)=>e?location.replace(n):location.hash=n;It.addEventListener("change",n=>{N0(n.target,ke,Ut)||QA(n.target,ke)});It.addEventListener("keydown",n=>x0(n,ke,Ut));It.addEventListener("touchstart",n=>zg(n,ke),{passive:!0});It.addEventListener("touchend",n=>zg(n,ke),{passive:!0});It.addEventListener("click",n=>{if(D0(n.target,ke,Ut)||WA(n.target,eS,ke,Ut))return;const e=n.target.closest("[data-up],[data-qf],[data-st],[data-stok],[data-stno],[data-fa],[data-newq],[data-newt],[data-hnew],[data-qappt]");if(!e)return;const t=e.dataset,s=decodeURIComponent(location.hash.split("/")[2]||"");if(t.up){t.up==="apply"?EA():jc(!0);return}if(t.hnew!==void 0){Ps({kind:t.hnew,date:fe()}),location.hash="#/t/new";return}if(t.qappt){const r=x.quotes.find(o=>o.id===t.qappt),i=r&&r.customer||{};Ps({quoteId:t.qappt,cust:i.name||"",tel:i.phone||"",addr:i.address||"",title:"Εγκατάσταση – "+(i.name||""),date:fe()}),location.hash="#/t/new";return}if(t.qf)Fe.qf=t.qf;else if(t.st){const r=x.quotes.find(i=>i.id===s);Fe.stAsk=r&&lt(r)!==t.st?{id:s,st:t.st}:null}else if("stno"in t)Fe.stAsk=null;else if("stok"in t){const r=PA(Fe.stAsk.id,Fe.stAsk.st);Fe.stAsk=null,r.msg&&Ut(r.msg)}else{if(t.fa)return _e&&J0(t.fa);if(t.newq){const r=Ct().find(i=>i.k===t.newq);r&&e0({name:r.name,...r.info}),location.hash="#/edit/new";return}else if(t.newt){const r=Ct().find(i=>i.k===t.newt);r&&Ps({cust:r.name,tel:r.info.phone||"",addr:r.info.address||"",date:fe()}),location.hash="#/t/new";return}}ke()});It.addEventListener("input",n=>{const e=n.target;V0(e,ke)||HA(e,ke)||_e&&e.dataset.f&&(_e.v[e.dataset.f]=e.type==="checkbox"?e.checked:e.value,_e.msg&&(_e.msg=""))});addEventListener("hashchange",()=>{scrollTo(0,0),location.hash.startsWith("#/cset")&&au(ke),ke()});function Hg(n){const e=scrollY,t=r0(n);if(t===null){It.innerHTML=He(Ue("Προσφορά","",Ws("quotes")),`<div class="empty">${ft?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);return}It.innerHTML=t,i0(It,()=>Hg(n),s=>location.replace(s?"#/q/"+encodeURIComponent(s):"#/quotes")),scrollTo(0,e)}function Ut(n,e){let t=document.getElementById("toast");if(t||(t=document.createElement("div"),t.id="toast",document.body.appendChild(t)),t.textContent=n,e){const s=document.createElement("button");s.textContent=e.label,s.onclick=()=>{t.className="",e.fn()},t.appendChild(s)}t.className="show"+(e?" act":""),clearTimeout(Ut.t),Ut.t=setTimeout(()=>t.className="",6e3)}tA(n=>Ut(n&&n.code==="permission-denied"?"Δεν έχεις δικαίωμα για αυτή την αλλαγή. Δεν αποθηκεύτηκε.":"Η αποθήκευση απέτυχε: "+(n&&(n.code||n.message)||"άγνωστο σφάλμα")));IA(()=>{Ft&&!xg()&&!_e&&!Ng()&&!qg()&&ke()});wA();pg&&(window.__tm={data:x});let Go="";function tS(){const n=JT();if(!tr||!n||!Object.keys(x.st).length)return;const e=zn()||{},t={uid:n.uid,email:n.email||"",role:et()?"team":"owner",empId:Gn(),name:e.name||"",rt:n.refreshToken||"",apiKey:Bc.apiKey,project:Bc.projectId},s=JSON.stringify(t);s!==Go&&(Go=s,ge.setSession(t))}function Qg(n){!n||!Ft||(n.task?location.hash="#/t/"+encodeURIComponent(n.task):n.isNew&&(Ps({date:fe()}),location.hash="#/t/new"))}_a("open",Qg);_a("toast",n=>n&&n.text&&Ut(n.text));_a("ms",()=>{location.hash.startsWith("#/cset")&&au(ke)});let mf=!1,Jc=!1;QT(()=>{ft=!0,tS(),L0(),!Jc&&x.tasks.length&&x.quotes.length&&(Jc=!0,setTimeout(()=>R0(ft),4e3)),!(xg()||_e||Ng()||qg())&&ke()});document.addEventListener("visibilitychange",()=>{!document.hidden&&Ft&&(Jc=!1,ke())});ii().then(()=>{YT(n=>{if(Ft=n,!n){Go="",Jg();return}location.hash.startsWith("#/cset")&&au(ke),ke(),mf||(mf=!0,ge.takeLaunch().then(Qg))})});function Jg(n="",e=""){It.innerHTML=B0(n);const t=document.getElementById("lf");t.e.value=e,document.getElementById("sp").onchange=s=>{t.p.type=s.target.checked?"text":"password"},document.getElementById("lf").onsubmit=s=>{s.preventDefault();const r=s.target;ZT(r.e.value.trim(),r.p.value).catch(i=>{const o=i&&i.code||"",l=["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(o)?"Λάθος email ή κωδικός.":o==="auth/network-request-failed"?"Δεν υπάρχει σύνδεση στο internet.":o==="auth/too-many-requests"?"Πολλές προσπάθειες. Δοκίμασε ξανά σε λίγα λεπτά.":"Η σύνδεση μπλοκαρίστηκε.";Jg(l+" ["+(o||i&&i.message||"άγνωστο")+"]",r.e.value)})}}export{Xd as A,Yl as W};
