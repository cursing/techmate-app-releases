(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function t(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(i){if(i.ep)return;i.ep=!0;const r=t(i);fetch(i.href,r)}})();var Rh={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const em=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let i=n.charCodeAt(s);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++s)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},L_=function(n){const e=[];let t=0,s=0;for(;t<n.length;){const i=n[t++];if(i<128)e[s++]=String.fromCharCode(i);else if(i>191&&i<224){const r=n[t++];e[s++]=String.fromCharCode((i&31)<<6|r&63)}else if(i>239&&i<365){const r=n[t++],o=n[t++],a=n[t++],l=((i&7)<<18|(r&63)<<12|(o&63)<<6|a&63)-65536;e[s++]=String.fromCharCode(55296+(l>>10)),e[s++]=String.fromCharCode(56320+(l&1023))}else{const r=n[t++],o=n[t++];e[s++]=String.fromCharCode((i&15)<<12|(r&63)<<6|o&63)}}return e.join("")},tm={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let i=0;i<n.length;i+=3){const r=n[i],o=i+1<n.length,a=o?n[i+1]:0,l=i+2<n.length,u=l?n[i+2]:0,h=r>>2,p=(r&3)<<4|a>>4;let m=(a&15)<<2|u>>6,w=u&63;l||(w=64,o||(m=64)),s.push(t[h],t[p],t[m],t[w])}return s.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(em(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):L_(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let i=0;i<n.length;){const r=t[n.charAt(i++)],a=i<n.length?t[n.charAt(i)]:0;++i;const u=i<n.length?t[n.charAt(i)]:64;++i;const p=i<n.length?t[n.charAt(i)]:64;if(++i,r==null||a==null||u==null||p==null)throw new F_;const m=r<<2|a>>4;if(s.push(m),u!==64){const w=a<<4&240|u>>2;if(s.push(w),p!==64){const E=u<<6&192|p;s.push(E)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class F_ extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const U_=function(n){const e=em(n);return tm.encodeByteArray(e,!0)},nm=function(n){return U_(n).replace(/\./g,"")},sm=function(n){try{return tm.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function q_(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B_=()=>q_().__FIREBASE_DEFAULTS__,j_=()=>{if(typeof process>"u"||typeof Rh>"u")return;const n=Rh.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},z_=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&sm(n[1]);return e&&JSON.parse(e)},Ba=()=>{try{return B_()||j_()||z_()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},G_=n=>{var e,t;return(t=(e=Ba())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},im=()=>{var n;return(n=Ba())===null||n===void 0?void 0:n.config},rm=n=>{var e;return(e=Ba())===null||e===void 0?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class K_{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ze(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function W_(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(ze())}function H_(){var n;const e=(n=Ba())===null||n===void 0?void 0:n.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Q_(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function J_(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function Y_(){const n=ze();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function om(){return!H_()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function am(){try{return typeof indexedDB=="object"}catch{return!1}}function X_(){return new Promise((n,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(s);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(s),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var r;e(((r=i.error)===null||r===void 0?void 0:r.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Z_="FirebaseError";class yn extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=Z_,Object.setPrototypeOf(this,yn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Zr.prototype.create)}}class Zr{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},i=`${this.service}/${e}`,r=this.errors[e],o=r?eb(r,s):"Error",a=`${this.serviceName}: ${o} (${i}).`;return new yn(i,a,s)}}function eb(n,e){return n.replace(tb,(t,s)=>{const i=e[s];return i!=null?String(i):`<${s}?>`})}const tb=/\{\$([^}]+)}/g;function nb(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function Pr(n,e){if(n===e)return!0;const t=Object.keys(n),s=Object.keys(e);for(const i of t){if(!s.includes(i))return!1;const r=n[i],o=e[i];if(Ph(r)&&Ph(o)){if(!Pr(r,o))return!1}else if(r!==o)return!1}for(const i of s)if(!t.includes(i))return!1;return!0}function Ph(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eo(n){const e=[];for(const[t,s]of Object.entries(n))Array.isArray(s)?s.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function dr(n){const e={};return n.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[i,r]=s.split("=");e[decodeURIComponent(i)]=decodeURIComponent(r)}}),e}function hr(n){const e=n.indexOf("?");if(!e)return"";const t=n.indexOf("#",e);return n.substring(e,t>0?t:void 0)}function sb(n,e){const t=new ib(n,e);return t.subscribe.bind(t)}class ib{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let i;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");rb(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:s},i.next===void 0&&(i.next=jc),i.error===void 0&&(i.error=jc),i.complete===void 0&&(i.complete=jc);const r=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),r}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function rb(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function jc(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function He(n){return n&&n._delegate?n._delegate:n}class Is{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ls="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ob{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new K_;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&s.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const s=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),i=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(r){if(i)return null;throw r}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(cb(e))try{this.getOrInitializeService({instanceIdentifier:ls})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const r=this.getOrInitializeService({instanceIdentifier:i});s.resolve(r)}catch{}}}}clearInstance(e=ls){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=ls){return this.instances.has(e)}getOptions(e=ls){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[r,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(r);s===a&&o.resolve(i)}return i}onInit(e,t){var s;const i=this.normalizeInstanceIdentifier(t),r=(s=this.onInitCallbacks.get(i))!==null&&s!==void 0?s:new Set;r.add(e),this.onInitCallbacks.set(i,r);const o=this.instances.get(i);return o&&e(o,i),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const i of s)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:ab(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=ls){return this.component?this.component.multipleInstances?e:ls:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function ab(n){return n===ls?void 0:n}function cb(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lb{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new ob(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ce;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(ce||(ce={}));const ub={debug:ce.DEBUG,verbose:ce.VERBOSE,info:ce.INFO,warn:ce.WARN,error:ce.ERROR,silent:ce.SILENT},db=ce.INFO,hb={[ce.DEBUG]:"log",[ce.VERBOSE]:"log",[ce.INFO]:"info",[ce.WARN]:"warn",[ce.ERROR]:"error"},fb=(n,e,...t)=>{if(e<n.logLevel)return;const s=new Date().toISOString(),i=hb[e];if(i)console[i](`[${s}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class iu{constructor(e){this.name=e,this._logLevel=db,this._logHandler=fb,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in ce))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?ub[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,ce.DEBUG,...e),this._logHandler(this,ce.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,ce.VERBOSE,...e),this._logHandler(this,ce.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,ce.INFO,...e),this._logHandler(this,ce.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,ce.WARN,...e),this._logHandler(this,ce.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,ce.ERROR,...e),this._logHandler(this,ce.ERROR,...e)}}const pb=(n,e)=>e.some(t=>n instanceof t);let Ch,Dh;function mb(){return Ch||(Ch=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function gb(){return Dh||(Dh=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const cm=new WeakMap,hl=new WeakMap,lm=new WeakMap,zc=new WeakMap,ru=new WeakMap;function yb(n){const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("success",r),n.removeEventListener("error",o)},r=()=>{t(Ln(n.result)),i()},o=()=>{s(n.error),i()};n.addEventListener("success",r),n.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&cm.set(t,n)}).catch(()=>{}),ru.set(e,n),e}function vb(n){if(hl.has(n))return;const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("complete",r),n.removeEventListener("error",o),n.removeEventListener("abort",o)},r=()=>{t(),i()},o=()=>{s(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",r),n.addEventListener("error",o),n.addEventListener("abort",o)});hl.set(n,e)}let fl={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return hl.get(n);if(e==="objectStoreNames")return n.objectStoreNames||lm.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Ln(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function _b(n){fl=n(fl)}function bb(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=n.call(Gc(this),e,...t);return lm.set(s,e.sort?e.sort():[e]),Ln(s)}:gb().includes(n)?function(...e){return n.apply(Gc(this),e),Ln(cm.get(this))}:function(...e){return Ln(n.apply(Gc(this),e))}}function wb(n){return typeof n=="function"?bb(n):(n instanceof IDBTransaction&&vb(n),pb(n,mb())?new Proxy(n,fl):n)}function Ln(n){if(n instanceof IDBRequest)return yb(n);if(zc.has(n))return zc.get(n);const e=wb(n);return e!==n&&(zc.set(n,e),ru.set(e,n)),e}const Gc=n=>ru.get(n);function Ib(n,e,{blocked:t,upgrade:s,blocking:i,terminated:r}={}){const o=indexedDB.open(n,e),a=Ln(o);return s&&o.addEventListener("upgradeneeded",l=>{s(Ln(o.result),l.oldVersion,l.newVersion,Ln(o.transaction),l)}),t&&o.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),a.then(l=>{r&&l.addEventListener("close",()=>r()),i&&l.addEventListener("versionchange",u=>i(u.oldVersion,u.newVersion,u))}).catch(()=>{}),a}const Eb=["get","getKey","getAll","getAllKeys","count"],Tb=["put","add","delete","clear"],Kc=new Map;function $h(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Kc.get(e))return Kc.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,i=Tb.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(i||Eb.includes(t)))return;const r=async function(o,...a){const l=this.transaction(o,i?"readwrite":"readonly");let u=l.store;return s&&(u=u.index(a.shift())),(await Promise.all([u[t](...a),i&&l.done]))[0]};return Kc.set(e,r),r}_b(n=>({...n,get:(e,t,s)=>$h(e,t)||n.get(e,t,s),has:(e,t)=>!!$h(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ab{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(Sb(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function Sb(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const pl="@firebase/app",Vh="0.10.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Es=new iu("@firebase/app"),kb="@firebase/app-compat",Rb="@firebase/analytics-compat",Pb="@firebase/analytics",Cb="@firebase/app-check-compat",Db="@firebase/app-check",$b="@firebase/auth",Vb="@firebase/auth-compat",Nb="@firebase/database",xb="@firebase/database-compat",Ob="@firebase/functions",Mb="@firebase/functions-compat",Lb="@firebase/installations",Fb="@firebase/installations-compat",Ub="@firebase/messaging",qb="@firebase/messaging-compat",Bb="@firebase/performance",jb="@firebase/performance-compat",zb="@firebase/remote-config",Gb="@firebase/remote-config-compat",Kb="@firebase/storage",Wb="@firebase/storage-compat",Hb="@firebase/firestore",Qb="@firebase/vertexai-preview",Jb="@firebase/firestore-compat",Yb="firebase",Xb="10.12.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ml="[DEFAULT]",Zb={[pl]:"fire-core",[kb]:"fire-core-compat",[Pb]:"fire-analytics",[Rb]:"fire-analytics-compat",[Db]:"fire-app-check",[Cb]:"fire-app-check-compat",[$b]:"fire-auth",[Vb]:"fire-auth-compat",[Nb]:"fire-rtdb",[xb]:"fire-rtdb-compat",[Ob]:"fire-fn",[Mb]:"fire-fn-compat",[Lb]:"fire-iid",[Fb]:"fire-iid-compat",[Ub]:"fire-fcm",[qb]:"fire-fcm-compat",[Bb]:"fire-perf",[jb]:"fire-perf-compat",[zb]:"fire-rc",[Gb]:"fire-rc-compat",[Kb]:"fire-gcs",[Wb]:"fire-gcs-compat",[Hb]:"fire-fst",[Jb]:"fire-fst-compat",[Qb]:"fire-vertex","fire-js":"fire-js",[Yb]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ua=new Map,ew=new Map,gl=new Map;function Nh(n,e){try{n.container.addComponent(e)}catch(t){Es.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function di(n){const e=n.name;if(gl.has(e))return Es.debug(`There were multiple attempts to register component ${e}.`),!1;gl.set(e,n);for(const t of ua.values())Nh(t,n);for(const t of ew.values())Nh(t,n);return!0}function ou(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function an(n){return n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tw={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Fn=new Zr("app","Firebase",tw);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nw{constructor(e,t,s){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new Is("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Fn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Di=Xb;function um(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const s=Object.assign({name:ml,automaticDataCollectionEnabled:!1},e),i=s.name;if(typeof i!="string"||!i)throw Fn.create("bad-app-name",{appName:String(i)});if(t||(t=im()),!t)throw Fn.create("no-options");const r=ua.get(i);if(r){if(Pr(t,r.options)&&Pr(s,r.config))return r;throw Fn.create("duplicate-app",{appName:i})}const o=new lb(i);for(const l of gl.values())o.addComponent(l);const a=new nw(t,s,o);return ua.set(i,a),a}function sw(n=ml){const e=ua.get(n);if(!e&&n===ml&&im())return um();if(!e)throw Fn.create("no-app",{appName:n});return e}function Un(n,e,t){var s;let i=(s=Zb[n])!==null&&s!==void 0?s:n;t&&(i+=`-${t}`);const r=i.match(/\s|\//),o=e.match(/\s|\//);if(r||o){const a=[`Unable to register library "${i}" with version "${e}":`];r&&a.push(`library name "${i}" contains illegal characters (whitespace or "/")`),r&&o&&a.push("and"),o&&a.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Es.warn(a.join(" "));return}di(new Is(`${i}-version`,()=>({library:i,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iw="firebase-heartbeat-database",rw=1,Cr="firebase-heartbeat-store";let Wc=null;function dm(){return Wc||(Wc=Ib(iw,rw,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(Cr)}catch(t){console.warn(t)}}}}).catch(n=>{throw Fn.create("idb-open",{originalErrorMessage:n.message})})),Wc}async function ow(n){try{const t=(await dm()).transaction(Cr),s=await t.objectStore(Cr).get(hm(n));return await t.done,s}catch(e){if(e instanceof yn)Es.warn(e.message);else{const t=Fn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Es.warn(t.message)}}}async function xh(n,e){try{const s=(await dm()).transaction(Cr,"readwrite");await s.objectStore(Cr).put(e,hm(n)),await s.done}catch(t){if(t instanceof yn)Es.warn(t.message);else{const s=Fn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Es.warn(s.message)}}}function hm(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const aw=1024,cw=30*24*60*60*1e3;class lw{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new dw(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=Oh();if(!(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(o=>o.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:i}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(o=>{const a=new Date(o.date).valueOf();return Date.now()-a<=cw}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var e;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=Oh(),{heartbeatsToSend:s,unsentEntries:i}=uw(this._heartbeatsCache.heartbeats),r=nm(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),r}}function Oh(){return new Date().toISOString().substring(0,10)}function uw(n,e=aw){const t=[];let s=n.slice();for(const i of n){const r=t.find(o=>o.agent===i.agent);if(r){if(r.dates.push(i.date),Mh(t)>e){r.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),Mh(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class dw{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return am()?X_().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await ow(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return xh(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return xh(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}else return}}function Mh(n){return nm(JSON.stringify({version:2,heartbeats:n})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hw(n){di(new Is("platform-logger",e=>new Ab(e),"PRIVATE")),di(new Is("heartbeat",e=>new lw(e),"PRIVATE")),Un(pl,Vh,n),Un(pl,Vh,"esm2017"),Un("fire-js","")}hw("");var fw="firebase",pw="10.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Un(fw,pw,"app");function au(n,e){var t={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&e.indexOf(s)<0&&(t[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var i=0,s=Object.getOwnPropertySymbols(n);i<s.length;i++)e.indexOf(s[i])<0&&Object.prototype.propertyIsEnumerable.call(n,s[i])&&(t[s[i]]=n[s[i]]);return t}function fm(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const mw=fm,pm=new Zr("auth","Firebase",fm());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const da=new iu("@firebase/auth");function gw(n,...e){da.logLevel<=ce.WARN&&da.warn(`Auth (${Di}): ${n}`,...e)}function Ko(n,...e){da.logLevel<=ce.ERROR&&da.error(`Auth (${Di}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ut(n,...e){throw cu(n,...e)}function Wt(n,...e){return cu(n,...e)}function mm(n,e,t){const s=Object.assign(Object.assign({},mw()),{[e]:t});return new Zr("auth","Firebase",s).create(e,{appName:n.name})}function qn(n){return mm(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function cu(n,...e){if(typeof n!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=n.name),n._errorFactory.create(t,...s)}return pm.create(n,...e)}function ee(n,e,...t){if(!n)throw cu(e,...t)}function cn(n){const e="INTERNAL ASSERTION FAILED: "+n;throw Ko(e),new Error(e)}function pn(n,e){n||cn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yl(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function yw(){return Lh()==="http:"||Lh()==="https:"}function Lh(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vw(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(yw()||Q_()||"connection"in navigator)?navigator.onLine:!0}function _w(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class to{constructor(e,t){this.shortDelay=e,this.longDelay=t,pn(t>e,"Short delay should be less than long delay!"),this.isMobile=W_()||J_()}get(){return vw()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lu(n,e){pn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gm{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;cn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;cn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;cn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bw={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ww=new to(3e4,6e4);function Ns(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function Xn(n,e,t,s,i={}){return ym(n,i,async()=>{let r={},o={};s&&(e==="GET"?o=s:r={body:JSON.stringify(s)});const a=eo(Object.assign({key:n.config.apiKey},o)).slice(1),l=await n._getAdditionalHeaders();return l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode),gm.fetch()(vm(n,n.config.apiHost,t,a),Object.assign({method:e,headers:l,referrerPolicy:"no-referrer"},r))})}async function ym(n,e,t){n._canInitEmulator=!1;const s=Object.assign(Object.assign({},bw),e);try{const i=new Ew(n),r=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const o=await r.json();if("needConfirmation"in o)throw xo(n,"account-exists-with-different-credential",o);if(r.ok&&!("errorMessage"in o))return o;{const a=r.ok?o.errorMessage:o.error.message,[l,u]=a.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw xo(n,"credential-already-in-use",o);if(l==="EMAIL_EXISTS")throw xo(n,"email-already-in-use",o);if(l==="USER_DISABLED")throw xo(n,"user-disabled",o);const h=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw mm(n,h,u);Ut(n,h)}}catch(i){if(i instanceof yn)throw i;Ut(n,"network-request-failed",{message:String(i)})}}async function ja(n,e,t,s,i={}){const r=await Xn(n,e,t,s,i);return"mfaPendingCredential"in r&&Ut(n,"multi-factor-auth-required",{_serverResponse:r}),r}function vm(n,e,t,s){const i=`${e}${t}?${s}`;return n.config.emulator?lu(n.config,i):`${n.config.apiScheme}://${i}`}function Iw(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class Ew{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(Wt(this.auth,"network-request-failed")),ww.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function xo(n,e,t){const s={appName:n.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const i=Wt(n,e,s);return i.customData._tokenResponse=t,i}function Fh(n){return n!==void 0&&n.enterprise!==void 0}class Tw{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return Iw(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}}async function Aw(n,e){return Xn(n,"GET","/v2/recaptchaConfig",Ns(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Sw(n,e){return Xn(n,"POST","/v1/accounts:delete",e)}async function _m(n,e){return Xn(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vr(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function kw(n,e=!1){const t=He(n),s=await t.getIdToken(e),i=uu(s);ee(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const r=typeof i.firebase=="object"?i.firebase:void 0,o=r==null?void 0:r.sign_in_provider;return{claims:i,token:s,authTime:vr(Hc(i.auth_time)),issuedAtTime:vr(Hc(i.iat)),expirationTime:vr(Hc(i.exp)),signInProvider:o||null,signInSecondFactor:(r==null?void 0:r.sign_in_second_factor)||null}}function Hc(n){return Number(n)*1e3}function uu(n){const[e,t,s]=n.split(".");if(e===void 0||t===void 0||s===void 0)return Ko("JWT malformed, contained fewer than 3 sections"),null;try{const i=sm(t);return i?JSON.parse(i):(Ko("Failed to decode base64 JWT payload"),null)}catch(i){return Ko("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function Uh(n){const e=uu(n);return ee(e,"internal-error"),ee(typeof e.exp<"u","internal-error"),ee(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Dr(n,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof yn&&Rw(s)&&n.auth.currentUser===n&&await n.auth.signOut(),s}}function Rw({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pw{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const s=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),s}else{this.errorBackoff=3e4;const i=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vl{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=vr(this.lastLoginAt),this.creationTime=vr(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ha(n){var e;const t=n.auth,s=await n.getIdToken(),i=await Dr(n,_m(t,{idToken:s}));ee(i==null?void 0:i.users.length,t,"internal-error");const r=i.users[0];n._notifyReloadListener(r);const o=!((e=r.providerUserInfo)===null||e===void 0)&&e.length?bm(r.providerUserInfo):[],a=Dw(n.providerData,o),l=n.isAnonymous,u=!(n.email&&r.passwordHash)&&!(a!=null&&a.length),h=l?u:!1,p={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:a,metadata:new vl(r.createdAt,r.lastLoginAt),isAnonymous:h};Object.assign(n,p)}async function Cw(n){const e=He(n);await ha(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Dw(n,e){return[...n.filter(s=>!e.some(i=>i.providerId===s.providerId)),...e]}function bm(n){return n.map(e=>{var{providerId:t}=e,s=au(e,["providerId"]);return{providerId:t,uid:s.rawId||"",displayName:s.displayName||null,email:s.email||null,phoneNumber:s.phoneNumber||null,photoURL:s.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $w(n,e){const t=await ym(n,{},async()=>{const s=eo({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:r}=n.config,o=vm(n,i,"/v1/token",`key=${r}`),a=await n._getAdditionalHeaders();return a["Content-Type"]="application/x-www-form-urlencoded",gm.fetch()(o,{method:"POST",headers:a,body:s})});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function Vw(n,e){return Xn(n,"POST","/v2/accounts:revokeToken",Ns(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ii{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){ee(e.idToken,"internal-error"),ee(typeof e.idToken<"u","internal-error"),ee(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Uh(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){ee(e.length!==0,"internal-error");const t=Uh(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(ee(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:i,expiresIn:r}=await $w(e,t);this.updateTokensAndExpiration(s,i,Number(r))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:i,expirationTime:r}=t,o=new ii;return s&&(ee(typeof s=="string","internal-error",{appName:e}),o.refreshToken=s),i&&(ee(typeof i=="string","internal-error",{appName:e}),o.accessToken=i),r&&(ee(typeof r=="number","internal-error",{appName:e}),o.expirationTime=r),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new ii,this.toJSON())}_performRefresh(){return cn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sn(n,e){ee(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class ln{constructor(e){var{uid:t,auth:s,stsTokenManager:i}=e,r=au(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new Pw(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=s,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new vl(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(e){const t=await Dr(this,this.stsTokenManager.getToken(this.auth,e));return ee(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return kw(this,e)}reload(){return Cw(this)}_assign(e){this!==e&&(ee(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new ln(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){ee(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await ha(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(an(this.auth.app))return Promise.reject(qn(this.auth));const e=await this.getIdToken();return await Dr(this,Sw(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var s,i,r,o,a,l,u,h;const p=(s=t.displayName)!==null&&s!==void 0?s:void 0,m=(i=t.email)!==null&&i!==void 0?i:void 0,w=(r=t.phoneNumber)!==null&&r!==void 0?r:void 0,E=(o=t.photoURL)!==null&&o!==void 0?o:void 0,$=(a=t.tenantId)!==null&&a!==void 0?a:void 0,R=(l=t._redirectEventId)!==null&&l!==void 0?l:void 0,B=(u=t.createdAt)!==null&&u!==void 0?u:void 0,H=(h=t.lastLoginAt)!==null&&h!==void 0?h:void 0,{uid:K,emailVerified:se,isAnonymous:x,providerData:L,stsTokenManager:b}=t;ee(K&&b,e,"internal-error");const y=ii.fromJSON(this.name,b);ee(typeof K=="string",e,"internal-error"),Sn(p,e.name),Sn(m,e.name),ee(typeof se=="boolean",e,"internal-error"),ee(typeof x=="boolean",e,"internal-error"),Sn(w,e.name),Sn(E,e.name),Sn($,e.name),Sn(R,e.name),Sn(B,e.name),Sn(H,e.name);const v=new ln({uid:K,auth:e,email:m,emailVerified:se,displayName:p,isAnonymous:x,photoURL:E,phoneNumber:w,tenantId:$,stsTokenManager:y,createdAt:B,lastLoginAt:H});return L&&Array.isArray(L)&&(v.providerData=L.map(I=>Object.assign({},I))),R&&(v._redirectEventId=R),v}static async _fromIdTokenResponse(e,t,s=!1){const i=new ii;i.updateFromServerResponse(t);const r=new ln({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:s});return await ha(r),r}static async _fromGetAccountInfoResponse(e,t,s){const i=t.users[0];ee(i.localId!==void 0,"internal-error");const r=i.providerUserInfo!==void 0?bm(i.providerUserInfo):[],o=!(i.email&&i.passwordHash)&&!(r!=null&&r.length),a=new ii;a.updateFromIdToken(s);const l=new ln({uid:i.localId,auth:e,stsTokenManager:a,isAnonymous:o}),u={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:r,metadata:new vl(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(r!=null&&r.length)};return Object.assign(l,u),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qh=new Map;function un(n){pn(n instanceof Function,"Expected a class definition");let e=qh.get(n);return e?(pn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,qh.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wm{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}wm.type="NONE";const Bh=wm;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wo(n,e,t){return`firebase:${n}:${e}:${t}`}class ri{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:i,name:r}=this.auth;this.fullUserKey=Wo(this.userKey,i.apiKey,r),this.fullPersistenceKey=Wo("persistence",i.apiKey,r),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?ln._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new ri(un(Bh),e,s);const i=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let r=i[0]||un(Bh);const o=Wo(s,e.config.apiKey,e.name);let a=null;for(const u of t)try{const h=await u._get(o);if(h){const p=ln._fromJSON(e,h);u!==r&&(a=p),r=u;break}}catch{}const l=i.filter(u=>u._shouldAllowMigration);return!r._shouldAllowMigration||!l.length?new ri(r,e,s):(r=l[0],a&&await r._set(o,a.toJSON()),await Promise.all(t.map(async u=>{if(u!==r)try{await u._remove(o)}catch{}})),new ri(r,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jh(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Tm(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Im(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Sm(e))return"Blackberry";if(km(e))return"Webos";if(du(e))return"Safari";if((e.includes("chrome/")||Em(e))&&!e.includes("edge/"))return"Chrome";if(Am(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=n.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function Im(n=ze()){return/firefox\//i.test(n)}function du(n=ze()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Em(n=ze()){return/crios\//i.test(n)}function Tm(n=ze()){return/iemobile/i.test(n)}function Am(n=ze()){return/android/i.test(n)}function Sm(n=ze()){return/blackberry/i.test(n)}function km(n=ze()){return/webos/i.test(n)}function za(n=ze()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function Nw(n=ze()){var e;return za(n)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function xw(){return Y_()&&document.documentMode===10}function Rm(n=ze()){return za(n)||Am(n)||km(n)||Sm(n)||/windows phone/i.test(n)||Tm(n)}function Ow(){try{return!!(window&&window!==window.top)}catch{return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pm(n,e=[]){let t;switch(n){case"Browser":t=jh(ze());break;case"Worker":t=`${jh(ze())}-${n}`;break;default:t=n}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Di}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mw{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=r=>new Promise((o,a)=>{try{const l=e(r);o(l)}catch(l){a(l)}});s.onAbort=t,this.queue.push(s);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Lw(n,e={}){return Xn(n,"GET","/v2/passwordPolicy",Ns(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fw=6;class Uw{constructor(e){var t,s,i,r;const o=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=o.minPasswordLength)!==null&&t!==void 0?t:Fw,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(s=e.allowedNonAlphanumericCharacters)===null||s===void 0?void 0:s.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(r=e.forceUpgradeOnSignin)!==null&&r!==void 0?r:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,s,i,r,o,a;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,l),this.validatePasswordCharacterOptions(e,l),l.isValid&&(l.isValid=(t=l.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),l.isValid&&(l.isValid=(s=l.meetsMaxPasswordLength)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(i=l.containsLowercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(r=l.containsUppercaseLetter)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(o=l.containsNumericCharacter)!==null&&o!==void 0?o:!0),l.isValid&&(l.isValid=(a=l.containsNonAlphanumericCharacter)!==null&&a!==void 0?a:!0),l}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let i=0;i<e.length;i++)s=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,i,r){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qw{constructor(e,t,s,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new zh(this),this.idTokenSubscription=new zh(this),this.beforeStateQueue=new Mw(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=pm,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=un(t)),this._initializationPromise=this.queue(async()=>{var s,i;if(!this._deleted&&(this.persistenceManager=await ri.create(this,e),!this._deleted)){if(!((s=this._popupRedirectResolver)===null||s===void 0)&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((i=this.currentUser)===null||i===void 0?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await _m(this,{idToken:e}),s=await ln._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(an(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(a,a))}):this.directlySetCurrentUser(null)}const s=await this.assertedPersistence.getCurrentUser();let i=s,r=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,a=i==null?void 0:i._redirectEventId,l=await this.tryRedirectSignIn(e);(!o||o===a)&&(l!=null&&l.user)&&(i=l.user,r=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(i)}catch(o){i=s,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return ee(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await ha(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=_w()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(an(this.app))return Promise.reject(qn(this));const t=e?He(e):null;return t&&ee(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&ee(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return an(this.app)?Promise.reject(qn(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return an(this.app)?Promise.reject(qn(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(un(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await Lw(this),t=new Uw(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new Zr("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await Vw(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&un(e)||this._popupRedirectResolver;ee(t,this,"argument-error"),this.redirectPersistenceManager=await ri.create(this,[un(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)===null||s===void 0?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const s=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==s&&(this.lastNotifiedUid=s,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,i){if(this._deleted)return()=>{};const r=typeof t=="function"?t:t.next.bind(t);let o=!1;const a=this._isInitialized?Promise.resolve():this._initializationPromise;if(ee(a,this,"internal-error"),a.then(()=>{o||r(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,s,i);return()=>{o=!0,l()}}else{const l=e.addObserver(t);return()=>{o=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return ee(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Pm(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const s=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());s&&(t["X-Firebase-Client"]=s);const i=await this._getAppCheckToken();return i&&(t["X-Firebase-AppCheck"]=i),t}async _getAppCheckToken(){var e;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&gw(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function $i(n){return He(n)}class zh{constructor(e){this.auth=e,this.observer=null,this.addObserver=sb(t=>this.observer=t)}get next(){return ee(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ga={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function Bw(n){Ga=n}function Cm(n){return Ga.loadJS(n)}function jw(){return Ga.recaptchaEnterpriseScript}function zw(){return Ga.gapiScript}function Gw(n){return`__${n}${Math.floor(Math.random()*1e6)}`}const Kw="recaptcha-enterprise",Ww="NO_RECAPTCHA";class Hw{constructor(e){this.type=Kw,this.auth=$i(e)}async verify(e="verify",t=!1){async function s(r){if(!t){if(r.tenantId==null&&r._agentRecaptchaConfig!=null)return r._agentRecaptchaConfig.siteKey;if(r.tenantId!=null&&r._tenantRecaptchaConfigs[r.tenantId]!==void 0)return r._tenantRecaptchaConfigs[r.tenantId].siteKey}return new Promise(async(o,a)=>{Aw(r,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)a(new Error("recaptcha Enterprise site key undefined"));else{const u=new Tw(l);return r.tenantId==null?r._agentRecaptchaConfig=u:r._tenantRecaptchaConfigs[r.tenantId]=u,o(u.siteKey)}}).catch(l=>{a(l)})})}function i(r,o,a){const l=window.grecaptcha;Fh(l)?l.enterprise.ready(()=>{l.enterprise.execute(r,{action:e}).then(u=>{o(u)}).catch(()=>{o(Ww)})}):a(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((r,o)=>{s(this.auth).then(a=>{if(!t&&Fh(window.grecaptcha))i(a,r,o);else{if(typeof window>"u"){o(new Error("RecaptchaVerifier is only supported in browser"));return}let l=jw();l.length!==0&&(l+=a),Cm(l).then(()=>{i(a,r,o)}).catch(u=>{o(u)})}}).catch(a=>{o(a)})})}}async function Gh(n,e,t,s=!1){const i=new Hw(n);let r;try{r=await i.verify(t)}catch{r=await i.verify(t,!0)}const o=Object.assign({},e);return s?Object.assign(o,{captchaResp:r}):Object.assign(o,{captchaResponse:r}),Object.assign(o,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(o,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),o}async function Kh(n,e,t,s){var i;if(!((i=n._getRecaptchaConfig())===null||i===void 0)&&i.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const r=await Gh(n,e,t,t==="getOobCode");return s(n,r)}else return s(n,e).catch(async r=>{if(r.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const o=await Gh(n,e,t,t==="getOobCode");return s(n,o)}else return Promise.reject(r)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qw(n,e){const t=ou(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),r=t.getOptions();if(Pr(r,e??{}))return i;Ut(i,"already-initialized")}return t.initialize({options:e})}function Jw(n,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(un);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function Yw(n,e,t){const s=$i(n);ee(s._canInitEmulator,s,"emulator-config-failed"),ee(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const i=!1,r=Dm(e),{host:o,port:a}=Xw(e),l=a===null?"":`:${a}`;s.config.emulator={url:`${r}//${o}${l}/`},s.settings.appVerificationDisabledForTesting=!0,s.emulatorConfig=Object.freeze({host:o,port:a,protocol:r.replace(":",""),options:Object.freeze({disableWarnings:i})}),Zw()}function Dm(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function Xw(n){const e=Dm(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(s);if(i){const r=i[1];return{host:r,port:Wh(s.substr(r.length+1))}}else{const[r,o]=s.split(":");return{host:r,port:Wh(o)}}}function Wh(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function Zw(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hu{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return cn("not implemented")}_getIdTokenResponse(e){return cn("not implemented")}_linkToIdToken(e,t){return cn("not implemented")}_getReauthenticationResolver(e){return cn("not implemented")}}async function eI(n,e){return Xn(n,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function tI(n,e){return ja(n,"POST","/v1/accounts:signInWithPassword",Ns(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function nI(n,e){return ja(n,"POST","/v1/accounts:signInWithEmailLink",Ns(n,e))}async function sI(n,e){return ja(n,"POST","/v1/accounts:signInWithEmailLink",Ns(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $r extends hu{constructor(e,t,s,i=null){super("password",s),this._email=e,this._password=t,this._tenantId=i}static _fromEmailAndPassword(e,t){return new $r(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new $r(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Kh(e,t,"signInWithPassword",tI);case"emailLink":return nI(e,{email:this._email,oobCode:this._password});default:Ut(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Kh(e,s,"signUpPassword",eI);case"emailLink":return sI(e,{idToken:t,email:this._email,oobCode:this._password});default:Ut(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function oi(n,e){return ja(n,"POST","/v1/accounts:signInWithIdp",Ns(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iI="http://localhost";class Ts extends hu{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Ts(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Ut("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:i}=t,r=au(t,["providerId","signInMethod"]);if(!s||!i)return null;const o=new Ts(s,i);return o.idToken=r.idToken||void 0,o.accessToken=r.accessToken||void 0,o.secret=r.secret,o.nonce=r.nonce,o.pendingToken=r.pendingToken||null,o}_getIdTokenResponse(e){const t=this.buildRequest();return oi(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,oi(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,oi(e,t)}buildRequest(){const e={requestUri:iI,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=eo(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rI(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function oI(n){const e=dr(hr(n)).link,t=e?dr(hr(e)).deep_link_id:null,s=dr(hr(n)).deep_link_id;return(s?dr(hr(s)).link:null)||s||t||e||n}class fu{constructor(e){var t,s,i,r,o,a;const l=dr(hr(e)),u=(t=l.apiKey)!==null&&t!==void 0?t:null,h=(s=l.oobCode)!==null&&s!==void 0?s:null,p=rI((i=l.mode)!==null&&i!==void 0?i:null);ee(u&&h&&p,"argument-error"),this.apiKey=u,this.operation=p,this.code=h,this.continueUrl=(r=l.continueUrl)!==null&&r!==void 0?r:null,this.languageCode=(o=l.languageCode)!==null&&o!==void 0?o:null,this.tenantId=(a=l.tenantId)!==null&&a!==void 0?a:null}static parseLink(e){const t=oI(e);try{return new fu(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vi{constructor(){this.providerId=Vi.PROVIDER_ID}static credential(e,t){return $r._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=fu.parseLink(t);return ee(s,"argument-error"),$r._fromEmailAndCode(e,s.code,s.tenantId)}}Vi.PROVIDER_ID="password";Vi.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Vi.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $m{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class no extends $m{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $n extends no{constructor(){super("facebook.com")}static credential(e){return Ts._fromParams({providerId:$n.PROVIDER_ID,signInMethod:$n.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return $n.credentialFromTaggedObject(e)}static credentialFromError(e){return $n.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return $n.credential(e.oauthAccessToken)}catch{return null}}}$n.FACEBOOK_SIGN_IN_METHOD="facebook.com";$n.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vn extends no{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Ts._fromParams({providerId:Vn.PROVIDER_ID,signInMethod:Vn.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return Vn.credentialFromTaggedObject(e)}static credentialFromError(e){return Vn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return Vn.credential(t,s)}catch{return null}}}Vn.GOOGLE_SIGN_IN_METHOD="google.com";Vn.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nn extends no{constructor(){super("github.com")}static credential(e){return Ts._fromParams({providerId:Nn.PROVIDER_ID,signInMethod:Nn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Nn.credentialFromTaggedObject(e)}static credentialFromError(e){return Nn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Nn.credential(e.oauthAccessToken)}catch{return null}}}Nn.GITHUB_SIGN_IN_METHOD="github.com";Nn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xn extends no{constructor(){super("twitter.com")}static credential(e,t){return Ts._fromParams({providerId:xn.PROVIDER_ID,signInMethod:xn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return xn.credentialFromTaggedObject(e)}static credentialFromError(e){return xn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return xn.credential(t,s)}catch{return null}}}xn.TWITTER_SIGN_IN_METHOD="twitter.com";xn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hi{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,i=!1){const r=await ln._fromIdTokenResponse(e,s,i),o=Hh(s);return new hi({user:r,providerId:o,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const i=Hh(s);return new hi({user:e,providerId:i,_tokenResponse:s,operationType:t})}}function Hh(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fa extends yn{constructor(e,t,s,i){var r;super(t.code,t.message),this.operationType=s,this.user=i,Object.setPrototypeOf(this,fa.prototype),this.customData={appName:e.name,tenantId:(r=e.tenantId)!==null&&r!==void 0?r:void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,i){return new fa(e,t,s,i)}}function Vm(n,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(r=>{throw r.code==="auth/multi-factor-auth-required"?fa._fromErrorAndOperation(n,r,e,s):r})}async function aI(n,e,t=!1){const s=await Dr(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return hi._forOperation(n,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function cI(n,e,t=!1){const{auth:s}=n;if(an(s.app))return Promise.reject(qn(s));const i="reauthenticate";try{const r=await Dr(n,Vm(s,i,e,n),t);ee(r.idToken,s,"internal-error");const o=uu(r.idToken);ee(o,s,"internal-error");const{sub:a}=o;return ee(n.uid===a,s,"user-mismatch"),hi._forOperation(n,i,r)}catch(r){throw(r==null?void 0:r.code)==="auth/user-not-found"&&Ut(s,"user-mismatch"),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Nm(n,e,t=!1){if(an(n.app))return Promise.reject(qn(n));const s="signIn",i=await Vm(n,s,e),r=await hi._fromIdTokenResponse(n,s,i);return t||await n._updateCurrentUser(r.user),r}async function lI(n,e){return Nm($i(n),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function uI(n){const e=$i(n);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}function dI(n,e,t){return an(n.app)?Promise.reject(qn(n)):lI(He(n),Vi.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&uI(n),s})}function hI(n,e,t,s){return He(n).onIdTokenChanged(e,t,s)}function fI(n,e,t){return He(n).beforeAuthStateChanged(e,t)}function pI(n,e,t,s){return He(n).onAuthStateChanged(e,t,s)}function mI(n){return He(n).signOut()}const pa="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xm{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(pa,"1"),this.storage.removeItem(pa),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gI(){const n=ze();return du(n)||za(n)}const yI=1e3,vI=10;class Om extends xm{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=gI()&&Ow(),this.fallbackToPolling=Rm(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),i=this.localCache[t];s!==i&&e(t,i,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((o,a,l)=>{this.notifyListeners(o,l)});return}const s=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const o=this.storage.getItem(s);if(e.newValue!==o)e.newValue!==null?this.storage.setItem(s,e.newValue):this.storage.removeItem(s);else if(this.localCache[s]===e.newValue&&!t)return}const i=()=>{const o=this.storage.getItem(s);!t&&this.localCache[s]===o||this.notifyListeners(s,o)},r=this.storage.getItem(s);xw()&&r!==e.newValue&&e.newValue!==e.oldValue?setTimeout(i,vI):i()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const i of Array.from(s))i(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},yI)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Om.type="LOCAL";const _I=Om;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mm extends xm{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Mm.type="SESSION";const Lm=Mm;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bI(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ka{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(i=>i.isListeningto(e));if(t)return t;const s=new Ka(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:i,data:r}=t.data,o=this.handlersMap[i];if(!(o!=null&&o.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:i});const a=Array.from(o).map(async u=>u(t.origin,r)),l=await bI(a);t.ports[0].postMessage({status:"done",eventId:s,eventType:i,response:l})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Ka.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pu(n="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wI{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let r,o;return new Promise((a,l)=>{const u=pu("",20);i.port1.start();const h=setTimeout(()=>{l(new Error("unsupported_event"))},s);o={messageChannel:i,onMessage(p){const m=p;if(m.data.eventId===u)switch(m.data.status){case"ack":clearTimeout(h),r=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(r),a(m.data.response);break;default:clearTimeout(h),clearTimeout(r),l(new Error("invalid_response"));break}}},this.handlers.add(o),i.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[i.port2])}).finally(()=>{o&&this.removeMessageHandler(o)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ht(){return window}function II(n){Ht().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fm(){return typeof Ht().WorkerGlobalScope<"u"&&typeof Ht().importScripts=="function"}async function EI(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function TI(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function AI(){return Fm()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Um="firebaseLocalStorageDb",SI=1,ma="firebaseLocalStorage",qm="fbase_key";class so{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function Wa(n,e){return n.transaction([ma],e?"readwrite":"readonly").objectStore(ma)}function kI(){const n=indexedDB.deleteDatabase(Um);return new so(n).toPromise()}function _l(){const n=indexedDB.open(Um,SI);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const s=n.result;try{s.createObjectStore(ma,{keyPath:qm})}catch(i){t(i)}}),n.addEventListener("success",async()=>{const s=n.result;s.objectStoreNames.contains(ma)?e(s):(s.close(),await kI(),e(await _l()))})})}async function Qh(n,e,t){const s=Wa(n,!0).put({[qm]:e,value:t});return new so(s).toPromise()}async function RI(n,e){const t=Wa(n,!1).get(e),s=await new so(t).toPromise();return s===void 0?null:s.value}function Jh(n,e){const t=Wa(n,!0).delete(e);return new so(t).toPromise()}const PI=800,CI=3;class Bm{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await _l(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>CI)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Fm()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Ka._getInstance(AI()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await EI(),!this.activeServiceWorker)return;this.sender=new wI(this.activeServiceWorker);const s=await this.sender._send("ping",{},800);s&&!((e=s[0])===null||e===void 0)&&e.fulfilled&&!((t=s[0])===null||t===void 0)&&t.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||TI()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await _l();return await Qh(e,pa,"1"),await Jh(e,pa),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>Qh(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>RI(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Jh(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const r=Wa(i,!1).getAll();return new so(r).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:i,value:r}of e)s.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(r)&&(this.notifyListeners(i,r),t.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!s.has(i)&&(this.notifyListeners(i,null),t.push(i));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const i of Array.from(s))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),PI)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Bm.type="LOCAL";const DI=Bm;new to(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $I(n,e){return e?un(e):(ee(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mu extends hu{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return oi(e,this._buildIdpRequest())}_linkToIdToken(e,t){return oi(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return oi(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function VI(n){return Nm(n.auth,new mu(n),n.bypassAuthState)}function NI(n){const{auth:e,user:t}=n;return ee(t,e,"internal-error"),cI(t,new mu(n),n.bypassAuthState)}async function xI(n){const{auth:e,user:t}=n;return ee(t,e,"internal-error"),aI(t,new mu(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jm{constructor(e,t,s,i,r=!1){this.auth=e,this.resolver=s,this.user=i,this.bypassAuthState=r,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:i,tenantId:r,error:o,type:a}=e;if(o){this.reject(o);return}const l={auth:this.auth,requestUri:t,sessionId:s,tenantId:r||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(a)(l))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return VI;case"linkViaPopup":case"linkViaRedirect":return xI;case"reauthViaPopup":case"reauthViaRedirect":return NI;default:Ut(this.auth,"internal-error")}}resolve(e){pn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){pn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const OI=new to(2e3,1e4);class ni extends jm{constructor(e,t,s,i,r){super(e,t,i,r),this.provider=s,this.authWindow=null,this.pollId=null,ni.currentPopupAction&&ni.currentPopupAction.cancel(),ni.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return ee(e,this.auth,"internal-error"),e}async onExecution(){pn(this.filter.length===1,"Popup operations only handle one event");const e=pu();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Wt(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(Wt(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,ni.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if(!((s=(t=this.authWindow)===null||t===void 0?void 0:t.window)===null||s===void 0)&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Wt(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,OI.get())};e()}}ni.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const MI="pendingRedirect",Ho=new Map;class LI extends jm{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=Ho.get(this.auth._key());if(!e){try{const s=await FI(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}Ho.set(this.auth._key(),e)}return this.bypassAuthState||Ho.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function FI(n,e){const t=BI(e),s=qI(n);if(!await s._isAvailable())return!1;const i=await s._get(t)==="true";return await s._remove(t),i}function UI(n,e){Ho.set(n._key(),e)}function qI(n){return un(n._redirectPersistence)}function BI(n){return Wo(MI,n.config.apiKey,n.name)}async function jI(n,e,t=!1){if(an(n.app))return Promise.reject(qn(n));const s=$i(n),i=$I(s,e),o=await new LI(s,i,t).execute();return o&&!t&&(delete o.user._redirectEventId,await s._persistUserIfCurrent(o.user),await s._setRedirectUser(null,e)),o}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zI=10*60*1e3;class GI{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!KI(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!zm(e)){const i=((s=e.error.code)===null||s===void 0?void 0:s.split("auth/")[1])||"internal-error";t.onError(Wt(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=zI&&this.cachedEventUids.clear(),this.cachedEventUids.has(Yh(e))}saveEventToCache(e){this.cachedEventUids.add(Yh(e)),this.lastProcessedEventTime=Date.now()}}function Yh(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function zm({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function KI(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return zm(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function WI(n,e={}){return Xn(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const HI=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,QI=/^https?/;async function JI(n){if(n.config.emulator)return;const{authorizedDomains:e}=await WI(n);for(const t of e)try{if(YI(t))return}catch{}Ut(n,"unauthorized-domain")}function YI(n){const e=yl(),{protocol:t,hostname:s}=new URL(e);if(n.startsWith("chrome-extension://")){const o=new URL(n);return o.hostname===""&&s===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&o.hostname===s}if(!QI.test(t))return!1;if(HI.test(n))return s===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const XI=new to(3e4,6e4);function Xh(){const n=Ht().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function ZI(n){return new Promise((e,t)=>{var s,i,r;function o(){Xh(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{Xh(),t(Wt(n,"network-request-failed"))},timeout:XI.get()})}if(!((i=(s=Ht().gapi)===null||s===void 0?void 0:s.iframes)===null||i===void 0)&&i.Iframe)e(gapi.iframes.getContext());else if(!((r=Ht().gapi)===null||r===void 0)&&r.load)o();else{const a=Gw("iframefcb");return Ht()[a]=()=>{gapi.load?o():t(Wt(n,"network-request-failed"))},Cm(`${zw()}?onload=${a}`).catch(l=>t(l))}}).catch(e=>{throw Qo=null,e})}let Qo=null;function eE(n){return Qo=Qo||ZI(n),Qo}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tE=new to(5e3,15e3),nE="__/auth/iframe",sE="emulator/auth/iframe",iE={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},rE=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function oE(n){const e=n.config;ee(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?lu(e,sE):`https://${n.config.authDomain}/${nE}`,s={apiKey:e.apiKey,appName:n.name,v:Di},i=rE.get(n.config.apiHost);i&&(s.eid=i);const r=n._getFrameworks();return r.length&&(s.fw=r.join(",")),`${t}?${eo(s).slice(1)}`}async function aE(n){const e=await eE(n),t=Ht().gapi;return ee(t,n,"internal-error"),e.open({where:document.body,url:oE(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:iE,dontclear:!0},s=>new Promise(async(i,r)=>{await s.restyle({setHideOnLeave:!1});const o=Wt(n,"network-request-failed"),a=Ht().setTimeout(()=>{r(o)},tE.get());function l(){Ht().clearTimeout(a),i(s)}s.ping(l).then(l,()=>{r(o)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cE={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},lE=500,uE=600,dE="_blank",hE="http://localhost";class Zh{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function fE(n,e,t,s=lE,i=uE){const r=Math.max((window.screen.availHeight-i)/2,0).toString(),o=Math.max((window.screen.availWidth-s)/2,0).toString();let a="";const l=Object.assign(Object.assign({},cE),{width:s.toString(),height:i.toString(),top:r,left:o}),u=ze().toLowerCase();t&&(a=Em(u)?dE:t),Im(u)&&(e=e||hE,l.scrollbars="yes");const h=Object.entries(l).reduce((m,[w,E])=>`${m}${w}=${E},`,"");if(Nw(u)&&a!=="_self")return pE(e||"",a),new Zh(null);const p=window.open(e||"",a,h);ee(p,n,"popup-blocked");try{p.focus()}catch{}return new Zh(p)}function pE(n,e){const t=document.createElement("a");t.href=n,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mE="__/auth/handler",gE="emulator/auth/handler",yE=encodeURIComponent("fac");async function ef(n,e,t,s,i,r){ee(n.config.authDomain,n,"auth-domain-config-required"),ee(n.config.apiKey,n,"invalid-api-key");const o={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:s,v:Di,eventId:i};if(e instanceof $m){e.setDefaultLanguage(n.languageCode),o.providerId=e.providerId||"",nb(e.getCustomParameters())||(o.customParameters=JSON.stringify(e.getCustomParameters()));for(const[h,p]of Object.entries({}))o[h]=p}if(e instanceof no){const h=e.getScopes().filter(p=>p!=="");h.length>0&&(o.scopes=h.join(","))}n.tenantId&&(o.tid=n.tenantId);const a=o;for(const h of Object.keys(a))a[h]===void 0&&delete a[h];const l=await n._getAppCheckToken(),u=l?`#${yE}=${encodeURIComponent(l)}`:"";return`${vE(n)}?${eo(a).slice(1)}${u}`}function vE({config:n}){return n.emulator?lu(n,gE):`https://${n.authDomain}/${mE}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qc="webStorageSupport";class _E{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Lm,this._completeRedirectFn=jI,this._overrideRedirectResult=UI}async _openPopup(e,t,s,i){var r;pn((r=this.eventManagers[e._key()])===null||r===void 0?void 0:r.manager,"_initialize() not called before _openPopup()");const o=await ef(e,t,s,yl(),i);return fE(e,o,pu())}async _openRedirect(e,t,s,i){await this._originValidation(e);const r=await ef(e,t,s,yl(),i);return II(r),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:i,promise:r}=this.eventManagers[t];return i?Promise.resolve(i):(pn(r,"If manager is not set, promise should be"),r)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await aE(e),s=new GI(e);return t.register("authEvent",i=>(ee(i==null?void 0:i.authEvent,e,"invalid-auth-event"),{status:s.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(Qc,{type:Qc},i=>{var r;const o=(r=i==null?void 0:i[0])===null||r===void 0?void 0:r[Qc];o!==void 0&&t(!!o),Ut(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=JI(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Rm()||du()||za()}}const bE=_E;var tf="@firebase/auth",nf="1.7.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wE{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){ee(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function IE(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function EE(n){di(new Is("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),r=e.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=s.options;ee(o&&!o.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:o,authDomain:a,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Pm(n)},u=new qw(s,i,r,l);return Jw(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),di(new Is("auth-internal",e=>{const t=$i(e.getProvider("auth").getImmediate());return(s=>new wE(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Un(tf,nf,IE(n)),Un(tf,nf,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const TE=5*60,AE=rm("authIdTokenMaxAge")||TE;let sf=null;const SE=n=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>AE)return;const i=t==null?void 0:t.token;sf!==i&&(sf=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function kE(n=sw()){const e=ou(n,"auth");if(e.isInitialized())return e.getImmediate();const t=Qw(n,{popupRedirectResolver:bE,persistence:[DI,_I,Lm]}),s=rm("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const r=new URL(s,location.origin);if(location.origin===r.origin){const o=SE(r.toString());fI(t,o,()=>o(t.currentUser)),hI(t,a=>o(a))}}const i=G_("auth");return i&&Yw(t,`http://${i}`),t}function RE(){var n,e;return(e=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&e!==void 0?e:document}Bw({loadJS(n){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",n),s.onload=e,s.onerror=i=>{const r=Wt("internal-error");r.customData=i,t(r)},s.type="text/javascript",s.charset="UTF-8",RE().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});EE("Browser");var rf=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var vs,Gm;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(b,y){function v(){}v.prototype=y.prototype,b.D=y.prototype,b.prototype=new v,b.prototype.constructor=b,b.C=function(I,T,S){for(var _=Array(arguments.length-2),vt=2;vt<arguments.length;vt++)_[vt-2]=arguments[vt];return y.prototype[T].apply(I,_)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(s,t),s.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(b,y,v){v||(v=0);var I=Array(16);if(typeof y=="string")for(var T=0;16>T;++T)I[T]=y.charCodeAt(v++)|y.charCodeAt(v++)<<8|y.charCodeAt(v++)<<16|y.charCodeAt(v++)<<24;else for(T=0;16>T;++T)I[T]=y[v++]|y[v++]<<8|y[v++]<<16|y[v++]<<24;y=b.g[0],v=b.g[1],T=b.g[2];var S=b.g[3],_=y+(S^v&(T^S))+I[0]+3614090360&4294967295;y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+I[1]+3905402710&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+I[2]+606105819&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+I[3]+3250441966&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(S^v&(T^S))+I[4]+4118548399&4294967295,y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+I[5]+1200080426&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+I[6]+2821735955&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+I[7]+4249261313&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(S^v&(T^S))+I[8]+1770035416&4294967295,y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+I[9]+2336552879&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+I[10]+4294925233&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+I[11]+2304563134&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(S^v&(T^S))+I[12]+1804603682&4294967295,y=v+(_<<7&4294967295|_>>>25),_=S+(T^y&(v^T))+I[13]+4254626195&4294967295,S=y+(_<<12&4294967295|_>>>20),_=T+(v^S&(y^v))+I[14]+2792965006&4294967295,T=S+(_<<17&4294967295|_>>>15),_=v+(y^T&(S^y))+I[15]+1236535329&4294967295,v=T+(_<<22&4294967295|_>>>10),_=y+(T^S&(v^T))+I[1]+4129170786&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+I[6]+3225465664&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+I[11]+643717713&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+I[0]+3921069994&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(T^S&(v^T))+I[5]+3593408605&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+I[10]+38016083&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+I[15]+3634488961&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+I[4]+3889429448&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(T^S&(v^T))+I[9]+568446438&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+I[14]+3275163606&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+I[3]+4107603335&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+I[8]+1163531501&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(T^S&(v^T))+I[13]+2850285829&4294967295,y=v+(_<<5&4294967295|_>>>27),_=S+(v^T&(y^v))+I[2]+4243563512&4294967295,S=y+(_<<9&4294967295|_>>>23),_=T+(y^v&(S^y))+I[7]+1735328473&4294967295,T=S+(_<<14&4294967295|_>>>18),_=v+(S^y&(T^S))+I[12]+2368359562&4294967295,v=T+(_<<20&4294967295|_>>>12),_=y+(v^T^S)+I[5]+4294588738&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+I[8]+2272392833&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+I[11]+1839030562&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+I[14]+4259657740&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(v^T^S)+I[1]+2763975236&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+I[4]+1272893353&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+I[7]+4139469664&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+I[10]+3200236656&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(v^T^S)+I[13]+681279174&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+I[0]+3936430074&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+I[3]+3572445317&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+I[6]+76029189&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(v^T^S)+I[9]+3654602809&4294967295,y=v+(_<<4&4294967295|_>>>28),_=S+(y^v^T)+I[12]+3873151461&4294967295,S=y+(_<<11&4294967295|_>>>21),_=T+(S^y^v)+I[15]+530742520&4294967295,T=S+(_<<16&4294967295|_>>>16),_=v+(T^S^y)+I[2]+3299628645&4294967295,v=T+(_<<23&4294967295|_>>>9),_=y+(T^(v|~S))+I[0]+4096336452&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+I[7]+1126891415&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+I[14]+2878612391&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+I[5]+4237533241&4294967295,v=T+(_<<21&4294967295|_>>>11),_=y+(T^(v|~S))+I[12]+1700485571&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+I[3]+2399980690&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+I[10]+4293915773&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+I[1]+2240044497&4294967295,v=T+(_<<21&4294967295|_>>>11),_=y+(T^(v|~S))+I[8]+1873313359&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+I[15]+4264355552&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+I[6]+2734768916&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+I[13]+1309151649&4294967295,v=T+(_<<21&4294967295|_>>>11),_=y+(T^(v|~S))+I[4]+4149444226&4294967295,y=v+(_<<6&4294967295|_>>>26),_=S+(v^(y|~T))+I[11]+3174756917&4294967295,S=y+(_<<10&4294967295|_>>>22),_=T+(y^(S|~v))+I[2]+718787259&4294967295,T=S+(_<<15&4294967295|_>>>17),_=v+(S^(T|~y))+I[9]+3951481745&4294967295,b.g[0]=b.g[0]+y&4294967295,b.g[1]=b.g[1]+(T+(_<<21&4294967295|_>>>11))&4294967295,b.g[2]=b.g[2]+T&4294967295,b.g[3]=b.g[3]+S&4294967295}s.prototype.u=function(b,y){y===void 0&&(y=b.length);for(var v=y-this.blockSize,I=this.B,T=this.h,S=0;S<y;){if(T==0)for(;S<=v;)i(this,b,S),S+=this.blockSize;if(typeof b=="string"){for(;S<y;)if(I[T++]=b.charCodeAt(S++),T==this.blockSize){i(this,I),T=0;break}}else for(;S<y;)if(I[T++]=b[S++],T==this.blockSize){i(this,I),T=0;break}}this.h=T,this.o+=y},s.prototype.v=function(){var b=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);b[0]=128;for(var y=1;y<b.length-8;++y)b[y]=0;var v=8*this.o;for(y=b.length-8;y<b.length;++y)b[y]=v&255,v/=256;for(this.u(b),b=Array(16),y=v=0;4>y;++y)for(var I=0;32>I;I+=8)b[v++]=this.g[y]>>>I&255;return b};function r(b,y){var v=a;return Object.prototype.hasOwnProperty.call(v,b)?v[b]:v[b]=y(b)}function o(b,y){this.h=y;for(var v=[],I=!0,T=b.length-1;0<=T;T--){var S=b[T]|0;I&&S==y||(v[T]=S,I=!1)}this.g=v}var a={};function l(b){return-128<=b&&128>b?r(b,function(y){return new o([y|0],0>y?-1:0)}):new o([b|0],0>b?-1:0)}function u(b){if(isNaN(b)||!isFinite(b))return p;if(0>b)return R(u(-b));for(var y=[],v=1,I=0;b>=v;I++)y[I]=b/v|0,v*=4294967296;return new o(y,0)}function h(b,y){if(b.length==0)throw Error("number format error: empty string");if(y=y||10,2>y||36<y)throw Error("radix out of range: "+y);if(b.charAt(0)=="-")return R(h(b.substring(1),y));if(0<=b.indexOf("-"))throw Error('number format error: interior "-" character');for(var v=u(Math.pow(y,8)),I=p,T=0;T<b.length;T+=8){var S=Math.min(8,b.length-T),_=parseInt(b.substring(T,T+S),y);8>S?(S=u(Math.pow(y,S)),I=I.j(S).add(u(_))):(I=I.j(v),I=I.add(u(_)))}return I}var p=l(0),m=l(1),w=l(16777216);n=o.prototype,n.m=function(){if($(this))return-R(this).m();for(var b=0,y=1,v=0;v<this.g.length;v++){var I=this.i(v);b+=(0<=I?I:4294967296+I)*y,y*=4294967296}return b},n.toString=function(b){if(b=b||10,2>b||36<b)throw Error("radix out of range: "+b);if(E(this))return"0";if($(this))return"-"+R(this).toString(b);for(var y=u(Math.pow(b,6)),v=this,I="";;){var T=se(v,y).g;v=B(v,T.j(y));var S=((0<v.g.length?v.g[0]:v.h)>>>0).toString(b);if(v=T,E(v))return S+I;for(;6>S.length;)S="0"+S;I=S+I}},n.i=function(b){return 0>b?0:b<this.g.length?this.g[b]:this.h};function E(b){if(b.h!=0)return!1;for(var y=0;y<b.g.length;y++)if(b.g[y]!=0)return!1;return!0}function $(b){return b.h==-1}n.l=function(b){return b=B(this,b),$(b)?-1:E(b)?0:1};function R(b){for(var y=b.g.length,v=[],I=0;I<y;I++)v[I]=~b.g[I];return new o(v,~b.h).add(m)}n.abs=function(){return $(this)?R(this):this},n.add=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],I=0,T=0;T<=y;T++){var S=I+(this.i(T)&65535)+(b.i(T)&65535),_=(S>>>16)+(this.i(T)>>>16)+(b.i(T)>>>16);I=_>>>16,S&=65535,_&=65535,v[T]=_<<16|S}return new o(v,v[v.length-1]&-2147483648?-1:0)};function B(b,y){return b.add(R(y))}n.j=function(b){if(E(this)||E(b))return p;if($(this))return $(b)?R(this).j(R(b)):R(R(this).j(b));if($(b))return R(this.j(R(b)));if(0>this.l(w)&&0>b.l(w))return u(this.m()*b.m());for(var y=this.g.length+b.g.length,v=[],I=0;I<2*y;I++)v[I]=0;for(I=0;I<this.g.length;I++)for(var T=0;T<b.g.length;T++){var S=this.i(I)>>>16,_=this.i(I)&65535,vt=b.i(T)>>>16,qt=b.i(T)&65535;v[2*I+2*T]+=_*qt,H(v,2*I+2*T),v[2*I+2*T+1]+=S*qt,H(v,2*I+2*T+1),v[2*I+2*T+1]+=_*vt,H(v,2*I+2*T+1),v[2*I+2*T+2]+=S*vt,H(v,2*I+2*T+2)}for(I=0;I<y;I++)v[I]=v[2*I+1]<<16|v[2*I];for(I=y;I<2*y;I++)v[I]=0;return new o(v,0)};function H(b,y){for(;(b[y]&65535)!=b[y];)b[y+1]+=b[y]>>>16,b[y]&=65535,y++}function K(b,y){this.g=b,this.h=y}function se(b,y){if(E(y))throw Error("division by zero");if(E(b))return new K(p,p);if($(b))return y=se(R(b),y),new K(R(y.g),R(y.h));if($(y))return y=se(b,R(y)),new K(R(y.g),y.h);if(30<b.g.length){if($(b)||$(y))throw Error("slowDivide_ only works with positive integers.");for(var v=m,I=y;0>=I.l(b);)v=x(v),I=x(I);var T=L(v,1),S=L(I,1);for(I=L(I,2),v=L(v,2);!E(I);){var _=S.add(I);0>=_.l(b)&&(T=T.add(v),S=_),I=L(I,1),v=L(v,1)}return y=B(b,T.j(y)),new K(T,y)}for(T=p;0<=b.l(y);){for(v=Math.max(1,Math.floor(b.m()/y.m())),I=Math.ceil(Math.log(v)/Math.LN2),I=48>=I?1:Math.pow(2,I-48),S=u(v),_=S.j(y);$(_)||0<_.l(b);)v-=I,S=u(v),_=S.j(y);E(S)&&(S=m),T=T.add(S),b=B(b,_)}return new K(T,b)}n.A=function(b){return se(this,b).h},n.and=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)&b.i(I);return new o(v,this.h&b.h)},n.or=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)|b.i(I);return new o(v,this.h|b.h)},n.xor=function(b){for(var y=Math.max(this.g.length,b.g.length),v=[],I=0;I<y;I++)v[I]=this.i(I)^b.i(I);return new o(v,this.h^b.h)};function x(b){for(var y=b.g.length+1,v=[],I=0;I<y;I++)v[I]=b.i(I)<<1|b.i(I-1)>>>31;return new o(v,b.h)}function L(b,y){var v=y>>5;y%=32;for(var I=b.g.length-v,T=[],S=0;S<I;S++)T[S]=0<y?b.i(S+v)>>>y|b.i(S+v+1)<<32-y:b.i(S+v);return new o(T,b.h)}s.prototype.digest=s.prototype.v,s.prototype.reset=s.prototype.s,s.prototype.update=s.prototype.u,Gm=s,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.A,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=u,o.fromString=h,vs=o}).apply(typeof rf<"u"?rf:typeof self<"u"?self:typeof window<"u"?window:{});var Oo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Km,Wm,fr,Hm,Jo,bl,Qm,Jm,Ym;(function(){var n,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(c,d,f){return c==Array.prototype||c==Object.prototype||(c[d]=f.value),c};function t(c){c=[typeof globalThis=="object"&&globalThis,c,typeof window=="object"&&window,typeof self=="object"&&self,typeof Oo=="object"&&Oo];for(var d=0;d<c.length;++d){var f=c[d];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var s=t(this);function i(c,d){if(d)e:{var f=s;c=c.split(".");for(var g=0;g<c.length-1;g++){var k=c[g];if(!(k in f))break e;f=f[k]}c=c[c.length-1],g=f[c],d=d(g),d!=g&&d!=null&&e(f,c,{configurable:!0,writable:!0,value:d})}}function r(c,d){c instanceof String&&(c+="");var f=0,g=!1,k={next:function(){if(!g&&f<c.length){var D=f++;return{value:d(D,c[D]),done:!1}}return g=!0,{done:!0,value:void 0}}};return k[Symbol.iterator]=function(){return k},k}i("Array.prototype.values",function(c){return c||function(){return r(this,function(d,f){return f})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},a=this||self;function l(c){var d=typeof c;return d=d!="object"?d:c?Array.isArray(c)?"array":d:"null",d=="array"||d=="object"&&typeof c.length=="number"}function u(c){var d=typeof c;return d=="object"&&c!=null||d=="function"}function h(c,d,f){return c.call.apply(c.bind,arguments)}function p(c,d,f){if(!c)throw Error();if(2<arguments.length){var g=Array.prototype.slice.call(arguments,2);return function(){var k=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(k,g),c.apply(d,k)}}return function(){return c.apply(d,arguments)}}function m(c,d,f){return m=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?h:p,m.apply(null,arguments)}function w(c,d){var f=Array.prototype.slice.call(arguments,1);return function(){var g=f.slice();return g.push.apply(g,arguments),c.apply(this,g)}}function E(c,d){function f(){}f.prototype=d.prototype,c.aa=d.prototype,c.prototype=new f,c.prototype.constructor=c,c.Qb=function(g,k,D){for(var M=Array(arguments.length-2),Te=2;Te<arguments.length;Te++)M[Te-2]=arguments[Te];return d.prototype[k].apply(g,M)}}function $(c){const d=c.length;if(0<d){const f=Array(d);for(let g=0;g<d;g++)f[g]=c[g];return f}return[]}function R(c,d){for(let f=1;f<arguments.length;f++){const g=arguments[f];if(l(g)){const k=c.length||0,D=g.length||0;c.length=k+D;for(let M=0;M<D;M++)c[k+M]=g[M]}else c.push(g)}}class B{constructor(d,f){this.i=d,this.j=f,this.h=0,this.g=null}get(){let d;return 0<this.h?(this.h--,d=this.g,this.g=d.next,d.next=null):d=this.i(),d}}function H(c){return/^[\s\xa0]*$/.test(c)}function K(){var c=a.navigator;return c&&(c=c.userAgent)?c:""}function se(c){return se[" "](c),c}se[" "]=function(){};var x=K().indexOf("Gecko")!=-1&&!(K().toLowerCase().indexOf("webkit")!=-1&&K().indexOf("Edge")==-1)&&!(K().indexOf("Trident")!=-1||K().indexOf("MSIE")!=-1)&&K().indexOf("Edge")==-1;function L(c,d,f){for(const g in c)d.call(f,c[g],g,c)}function b(c,d){for(const f in c)d.call(void 0,c[f],f,c)}function y(c){const d={};for(const f in c)d[f]=c[f];return d}const v="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function I(c,d){let f,g;for(let k=1;k<arguments.length;k++){g=arguments[k];for(f in g)c[f]=g[f];for(let D=0;D<v.length;D++)f=v[D],Object.prototype.hasOwnProperty.call(g,f)&&(c[f]=g[f])}}function T(c){var d=1;c=c.split(":");const f=[];for(;0<d&&c.length;)f.push(c.shift()),d--;return c.length&&f.push(c.join(":")),f}function S(c){a.setTimeout(()=>{throw c},0)}function _(){var c=_c;let d=null;return c.g&&(d=c.g,c.g=c.g.next,c.g||(c.h=null),d.next=null),d}class vt{constructor(){this.h=this.g=null}add(d,f){const g=qt.get();g.set(d,f),this.h?this.h.next=g:this.g=g,this.h=g}}var qt=new B(()=>new s_,c=>c.reset());class s_{constructor(){this.next=this.g=this.h=null}set(d,f){this.h=d,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let Ui,qi=!1,_c=new vt,Rd=()=>{const c=a.Promise.resolve(void 0);Ui=()=>{c.then(i_)}};var i_=()=>{for(var c;c=_();){try{c.h.call(c.g)}catch(f){S(f)}var d=qt;d.j(c),100>d.h&&(d.h++,c.next=d.g,d.g=c)}qi=!1};function In(){this.s=this.s,this.C=this.C}In.prototype.s=!1,In.prototype.ma=function(){this.s||(this.s=!0,this.N())},In.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function st(c,d){this.type=c,this.g=this.target=d,this.defaultPrevented=!1}st.prototype.h=function(){this.defaultPrevented=!0};var r_=function(){if(!a.addEventListener||!Object.defineProperty)return!1;var c=!1,d=Object.defineProperty({},"passive",{get:function(){c=!0}});try{const f=()=>{};a.addEventListener("test",f,d),a.removeEventListener("test",f,d)}catch{}return c}();function Bi(c,d){if(st.call(this,c?c.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,c){var f=this.type=c.type,g=c.changedTouches&&c.changedTouches.length?c.changedTouches[0]:null;if(this.target=c.target||c.srcElement,this.g=d,d=c.relatedTarget){if(x){e:{try{se(d.nodeName);var k=!0;break e}catch{}k=!1}k||(d=null)}}else f=="mouseover"?d=c.fromElement:f=="mouseout"&&(d=c.toElement);this.relatedTarget=d,g?(this.clientX=g.clientX!==void 0?g.clientX:g.pageX,this.clientY=g.clientY!==void 0?g.clientY:g.pageY,this.screenX=g.screenX||0,this.screenY=g.screenY||0):(this.clientX=c.clientX!==void 0?c.clientX:c.pageX,this.clientY=c.clientY!==void 0?c.clientY:c.pageY,this.screenX=c.screenX||0,this.screenY=c.screenY||0),this.button=c.button,this.key=c.key||"",this.ctrlKey=c.ctrlKey,this.altKey=c.altKey,this.shiftKey=c.shiftKey,this.metaKey=c.metaKey,this.pointerId=c.pointerId||0,this.pointerType=typeof c.pointerType=="string"?c.pointerType:o_[c.pointerType]||"",this.state=c.state,this.i=c,c.defaultPrevented&&Bi.aa.h.call(this)}}E(Bi,st);var o_={2:"touch",3:"pen",4:"mouse"};Bi.prototype.h=function(){Bi.aa.h.call(this);var c=this.i;c.preventDefault?c.preventDefault():c.returnValue=!1};var yo="closure_listenable_"+(1e6*Math.random()|0),a_=0;function c_(c,d,f,g,k){this.listener=c,this.proxy=null,this.src=d,this.type=f,this.capture=!!g,this.ha=k,this.key=++a_,this.da=this.fa=!1}function vo(c){c.da=!0,c.listener=null,c.proxy=null,c.src=null,c.ha=null}function _o(c){this.src=c,this.g={},this.h=0}_o.prototype.add=function(c,d,f,g,k){var D=c.toString();c=this.g[D],c||(c=this.g[D]=[],this.h++);var M=wc(c,d,g,k);return-1<M?(d=c[M],f||(d.fa=!1)):(d=new c_(d,this.src,D,!!g,k),d.fa=f,c.push(d)),d};function bc(c,d){var f=d.type;if(f in c.g){var g=c.g[f],k=Array.prototype.indexOf.call(g,d,void 0),D;(D=0<=k)&&Array.prototype.splice.call(g,k,1),D&&(vo(d),c.g[f].length==0&&(delete c.g[f],c.h--))}}function wc(c,d,f,g){for(var k=0;k<c.length;++k){var D=c[k];if(!D.da&&D.listener==d&&D.capture==!!f&&D.ha==g)return k}return-1}var Ic="closure_lm_"+(1e6*Math.random()|0),Ec={};function Pd(c,d,f,g,k){if(Array.isArray(d)){for(var D=0;D<d.length;D++)Pd(c,d[D],f,g,k);return null}return f=$d(f),c&&c[yo]?c.K(d,f,u(g)?!!g.capture:!1,k):l_(c,d,f,!1,g,k)}function l_(c,d,f,g,k,D){if(!d)throw Error("Invalid event type");var M=u(k)?!!k.capture:!!k,Te=Ac(c);if(Te||(c[Ic]=Te=new _o(c)),f=Te.add(d,f,g,M,D),f.proxy)return f;if(g=u_(),f.proxy=g,g.src=c,g.listener=f,c.addEventListener)r_||(k=M),k===void 0&&(k=!1),c.addEventListener(d.toString(),g,k);else if(c.attachEvent)c.attachEvent(Dd(d.toString()),g);else if(c.addListener&&c.removeListener)c.addListener(g);else throw Error("addEventListener and attachEvent are unavailable.");return f}function u_(){function c(f){return d.call(c.src,c.listener,f)}const d=d_;return c}function Cd(c,d,f,g,k){if(Array.isArray(d))for(var D=0;D<d.length;D++)Cd(c,d[D],f,g,k);else g=u(g)?!!g.capture:!!g,f=$d(f),c&&c[yo]?(c=c.i,d=String(d).toString(),d in c.g&&(D=c.g[d],f=wc(D,f,g,k),-1<f&&(vo(D[f]),Array.prototype.splice.call(D,f,1),D.length==0&&(delete c.g[d],c.h--)))):c&&(c=Ac(c))&&(d=c.g[d.toString()],c=-1,d&&(c=wc(d,f,g,k)),(f=-1<c?d[c]:null)&&Tc(f))}function Tc(c){if(typeof c!="number"&&c&&!c.da){var d=c.src;if(d&&d[yo])bc(d.i,c);else{var f=c.type,g=c.proxy;d.removeEventListener?d.removeEventListener(f,g,c.capture):d.detachEvent?d.detachEvent(Dd(f),g):d.addListener&&d.removeListener&&d.removeListener(g),(f=Ac(d))?(bc(f,c),f.h==0&&(f.src=null,d[Ic]=null)):vo(c)}}}function Dd(c){return c in Ec?Ec[c]:Ec[c]="on"+c}function d_(c,d){if(c.da)c=!0;else{d=new Bi(d,this);var f=c.listener,g=c.ha||c.src;c.fa&&Tc(c),c=f.call(g,d)}return c}function Ac(c){return c=c[Ic],c instanceof _o?c:null}var Sc="__closure_events_fn_"+(1e9*Math.random()>>>0);function $d(c){return typeof c=="function"?c:(c[Sc]||(c[Sc]=function(d){return c.handleEvent(d)}),c[Sc])}function it(){In.call(this),this.i=new _o(this),this.M=this,this.F=null}E(it,In),it.prototype[yo]=!0,it.prototype.removeEventListener=function(c,d,f,g){Cd(this,c,d,f,g)};function dt(c,d){var f,g=c.F;if(g)for(f=[];g;g=g.F)f.push(g);if(c=c.M,g=d.type||d,typeof d=="string")d=new st(d,c);else if(d instanceof st)d.target=d.target||c;else{var k=d;d=new st(g,c),I(d,k)}if(k=!0,f)for(var D=f.length-1;0<=D;D--){var M=d.g=f[D];k=bo(M,g,!0,d)&&k}if(M=d.g=c,k=bo(M,g,!0,d)&&k,k=bo(M,g,!1,d)&&k,f)for(D=0;D<f.length;D++)M=d.g=f[D],k=bo(M,g,!1,d)&&k}it.prototype.N=function(){if(it.aa.N.call(this),this.i){var c=this.i,d;for(d in c.g){for(var f=c.g[d],g=0;g<f.length;g++)vo(f[g]);delete c.g[d],c.h--}}this.F=null},it.prototype.K=function(c,d,f,g){return this.i.add(String(c),d,!1,f,g)},it.prototype.L=function(c,d,f,g){return this.i.add(String(c),d,!0,f,g)};function bo(c,d,f,g){if(d=c.i.g[String(d)],!d)return!0;d=d.concat();for(var k=!0,D=0;D<d.length;++D){var M=d[D];if(M&&!M.da&&M.capture==f){var Te=M.listener,Xe=M.ha||M.src;M.fa&&bc(c.i,M),k=Te.call(Xe,g)!==!1&&k}}return k&&!g.defaultPrevented}function Vd(c,d,f){if(typeof c=="function")f&&(c=m(c,f));else if(c&&typeof c.handleEvent=="function")c=m(c.handleEvent,c);else throw Error("Invalid listener argument");return 2147483647<Number(d)?-1:a.setTimeout(c,d||0)}function Nd(c){c.g=Vd(()=>{c.g=null,c.i&&(c.i=!1,Nd(c))},c.l);const d=c.h;c.h=null,c.m.apply(null,d)}class h_ extends In{constructor(d,f){super(),this.m=d,this.l=f,this.h=null,this.i=!1,this.g=null}j(d){this.h=arguments,this.g?this.i=!0:Nd(this)}N(){super.N(),this.g&&(a.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function ji(c){In.call(this),this.h=c,this.g={}}E(ji,In);var xd=[];function Od(c){L(c.g,function(d,f){this.g.hasOwnProperty(f)&&Tc(d)},c),c.g={}}ji.prototype.N=function(){ji.aa.N.call(this),Od(this)},ji.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var kc=a.JSON.stringify,f_=a.JSON.parse,p_=class{stringify(c){return a.JSON.stringify(c,void 0)}parse(c){return a.JSON.parse(c,void 0)}};function Rc(){}Rc.prototype.h=null;function Md(c){return c.h||(c.h=c.i())}function Ld(){}var zi={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function Pc(){st.call(this,"d")}E(Pc,st);function Cc(){st.call(this,"c")}E(Cc,st);var is={},Fd=null;function wo(){return Fd=Fd||new it}is.La="serverreachability";function Ud(c){st.call(this,is.La,c)}E(Ud,st);function Gi(c){const d=wo();dt(d,new Ud(d))}is.STAT_EVENT="statevent";function qd(c,d){st.call(this,is.STAT_EVENT,c),this.stat=d}E(qd,st);function ht(c){const d=wo();dt(d,new qd(d,c))}is.Ma="timingevent";function Bd(c,d){st.call(this,is.Ma,c),this.size=d}E(Bd,st);function Ki(c,d){if(typeof c!="function")throw Error("Fn must not be null and must be a function");return a.setTimeout(function(){c()},d)}function Wi(){this.g=!0}Wi.prototype.xa=function(){this.g=!1};function m_(c,d,f,g,k,D){c.info(function(){if(c.g)if(D)for(var M="",Te=D.split("&"),Xe=0;Xe<Te.length;Xe++){var ge=Te[Xe].split("=");if(1<ge.length){var rt=ge[0];ge=ge[1];var ot=rt.split("_");M=2<=ot.length&&ot[1]=="type"?M+(rt+"="+ge+"&"):M+(rt+"=redacted&")}}else M=null;else M=D;return"XMLHTTP REQ ("+g+") [attempt "+k+"]: "+d+`
`+f+`
`+M})}function g_(c,d,f,g,k,D,M){c.info(function(){return"XMLHTTP RESP ("+g+") [ attempt "+k+"]: "+d+`
`+f+`
`+D+" "+M})}function Fs(c,d,f,g){c.info(function(){return"XMLHTTP TEXT ("+d+"): "+v_(c,f)+(g?" "+g:"")})}function y_(c,d){c.info(function(){return"TIMEOUT: "+d})}Wi.prototype.info=function(){};function v_(c,d){if(!c.g)return d;if(!d)return null;try{var f=JSON.parse(d);if(f){for(c=0;c<f.length;c++)if(Array.isArray(f[c])){var g=f[c];if(!(2>g.length)){var k=g[1];if(Array.isArray(k)&&!(1>k.length)){var D=k[0];if(D!="noop"&&D!="stop"&&D!="close")for(var M=1;M<k.length;M++)k[M]=""}}}}return kc(f)}catch{return d}}var Io={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},jd={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},Dc;function Eo(){}E(Eo,Rc),Eo.prototype.g=function(){return new XMLHttpRequest},Eo.prototype.i=function(){return{}},Dc=new Eo;function En(c,d,f,g){this.j=c,this.i=d,this.l=f,this.R=g||1,this.U=new ji(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new zd}function zd(){this.i=null,this.g="",this.h=!1}var Gd={},$c={};function Vc(c,d,f){c.L=1,c.v=ko(en(d)),c.m=f,c.P=!0,Kd(c,null)}function Kd(c,d){c.F=Date.now(),To(c),c.A=en(c.v);var f=c.A,g=c.R;Array.isArray(g)||(g=[String(g)]),oh(f.i,"t",g),c.C=0,f=c.j.J,c.h=new zd,c.g=Th(c.j,f?d:null,!c.m),0<c.O&&(c.M=new h_(m(c.Y,c,c.g),c.O)),d=c.U,f=c.g,g=c.ca;var k="readystatechange";Array.isArray(k)||(k&&(xd[0]=k.toString()),k=xd);for(var D=0;D<k.length;D++){var M=Pd(f,k[D],g||d.handleEvent,!1,d.h||d);if(!M)break;d.g[M.key]=M}d=c.H?y(c.H):{},c.m?(c.u||(c.u="POST"),d["Content-Type"]="application/x-www-form-urlencoded",c.g.ea(c.A,c.u,c.m,d)):(c.u="GET",c.g.ea(c.A,c.u,null,d)),Gi(),m_(c.i,c.u,c.A,c.l,c.R,c.m)}En.prototype.ca=function(c){c=c.target;const d=this.M;d&&tn(c)==3?d.j():this.Y(c)},En.prototype.Y=function(c){try{if(c==this.g)e:{const ot=tn(this.g);var d=this.g.Ba();const Bs=this.g.Z();if(!(3>ot)&&(ot!=3||this.g&&(this.h.h||this.g.oa()||fh(this.g)))){this.J||ot!=4||d==7||(d==8||0>=Bs?Gi(3):Gi(2)),Nc(this);var f=this.g.Z();this.X=f;t:if(Wd(this)){var g=fh(this.g);c="";var k=g.length,D=tn(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){rs(this),Hi(this);var M="";break t}this.h.i=new a.TextDecoder}for(d=0;d<k;d++)this.h.h=!0,c+=this.h.i.decode(g[d],{stream:!(D&&d==k-1)});g.length=0,this.h.g+=c,this.C=0,M=this.h.g}else M=this.g.oa();if(this.o=f==200,g_(this.i,this.u,this.A,this.l,this.R,ot,f),this.o){if(this.T&&!this.K){t:{if(this.g){var Te,Xe=this.g;if((Te=Xe.g?Xe.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!H(Te)){var ge=Te;break t}}ge=null}if(f=ge)Fs(this.i,this.l,f,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,xc(this,f);else{this.o=!1,this.s=3,ht(12),rs(this),Hi(this);break e}}if(this.P){f=!0;let Vt;for(;!this.J&&this.C<M.length;)if(Vt=__(this,M),Vt==$c){ot==4&&(this.s=4,ht(14),f=!1),Fs(this.i,this.l,null,"[Incomplete Response]");break}else if(Vt==Gd){this.s=4,ht(15),Fs(this.i,this.l,M,"[Invalid Chunk]"),f=!1;break}else Fs(this.i,this.l,Vt,null),xc(this,Vt);if(Wd(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),ot!=4||M.length!=0||this.h.h||(this.s=1,ht(16),f=!1),this.o=this.o&&f,!f)Fs(this.i,this.l,M,"[Invalid Chunked Response]"),rs(this),Hi(this);else if(0<M.length&&!this.W){this.W=!0;var rt=this.j;rt.g==this&&rt.ba&&!rt.M&&(rt.j.info("Great, no buffering proxy detected. Bytes received: "+M.length),qc(rt),rt.M=!0,ht(11))}}else Fs(this.i,this.l,M,null),xc(this,M);ot==4&&rs(this),this.o&&!this.J&&(ot==4?bh(this.j,this):(this.o=!1,To(this)))}else O_(this.g),f==400&&0<M.indexOf("Unknown SID")?(this.s=3,ht(12)):(this.s=0,ht(13)),rs(this),Hi(this)}}}catch{}finally{}};function Wd(c){return c.g?c.u=="GET"&&c.L!=2&&c.j.Ca:!1}function __(c,d){var f=c.C,g=d.indexOf(`
`,f);return g==-1?$c:(f=Number(d.substring(f,g)),isNaN(f)?Gd:(g+=1,g+f>d.length?$c:(d=d.slice(g,g+f),c.C=g+f,d)))}En.prototype.cancel=function(){this.J=!0,rs(this)};function To(c){c.S=Date.now()+c.I,Hd(c,c.I)}function Hd(c,d){if(c.B!=null)throw Error("WatchDog timer not null");c.B=Ki(m(c.ba,c),d)}function Nc(c){c.B&&(a.clearTimeout(c.B),c.B=null)}En.prototype.ba=function(){this.B=null;const c=Date.now();0<=c-this.S?(y_(this.i,this.A),this.L!=2&&(Gi(),ht(17)),rs(this),this.s=2,Hi(this)):Hd(this,this.S-c)};function Hi(c){c.j.G==0||c.J||bh(c.j,c)}function rs(c){Nc(c);var d=c.M;d&&typeof d.ma=="function"&&d.ma(),c.M=null,Od(c.U),c.g&&(d=c.g,c.g=null,d.abort(),d.ma())}function xc(c,d){try{var f=c.j;if(f.G!=0&&(f.g==c||Oc(f.h,c))){if(!c.K&&Oc(f.h,c)&&f.G==3){try{var g=f.Da.g.parse(d)}catch{g=null}if(Array.isArray(g)&&g.length==3){var k=g;if(k[0]==0){e:if(!f.u){if(f.g)if(f.g.F+3e3<c.F)$o(f),Co(f);else break e;Uc(f),ht(18)}}else f.za=k[1],0<f.za-f.T&&37500>k[2]&&f.F&&f.v==0&&!f.C&&(f.C=Ki(m(f.Za,f),6e3));if(1>=Yd(f.h)&&f.ca){try{f.ca()}catch{}f.ca=void 0}}else as(f,11)}else if((c.K||f.g==c)&&$o(f),!H(d))for(k=f.Da.g.parse(d),d=0;d<k.length;d++){let ge=k[d];if(f.T=ge[0],ge=ge[1],f.G==2)if(ge[0]=="c"){f.K=ge[1],f.ia=ge[2];const rt=ge[3];rt!=null&&(f.la=rt,f.j.info("VER="+f.la));const ot=ge[4];ot!=null&&(f.Aa=ot,f.j.info("SVER="+f.Aa));const Bs=ge[5];Bs!=null&&typeof Bs=="number"&&0<Bs&&(g=1.5*Bs,f.L=g,f.j.info("backChannelRequestTimeoutMs_="+g)),g=f;const Vt=c.g;if(Vt){const No=Vt.g?Vt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(No){var D=g.h;D.g||No.indexOf("spdy")==-1&&No.indexOf("quic")==-1&&No.indexOf("h2")==-1||(D.j=D.l,D.g=new Set,D.h&&(Mc(D,D.h),D.h=null))}if(g.D){const Bc=Vt.g?Vt.g.getResponseHeader("X-HTTP-Session-Id"):null;Bc&&(g.ya=Bc,ke(g.I,g.D,Bc))}}f.G=3,f.l&&f.l.ua(),f.ba&&(f.R=Date.now()-c.F,f.j.info("Handshake RTT: "+f.R+"ms")),g=f;var M=c;if(g.qa=Eh(g,g.J?g.ia:null,g.W),M.K){Xd(g.h,M);var Te=M,Xe=g.L;Xe&&(Te.I=Xe),Te.B&&(Nc(Te),To(Te)),g.g=M}else vh(g);0<f.i.length&&Do(f)}else ge[0]!="stop"&&ge[0]!="close"||as(f,7);else f.G==3&&(ge[0]=="stop"||ge[0]=="close"?ge[0]=="stop"?as(f,7):Fc(f):ge[0]!="noop"&&f.l&&f.l.ta(ge),f.v=0)}}Gi(4)}catch{}}var b_=class{constructor(c,d){this.g=c,this.map=d}};function Qd(c){this.l=c||10,a.PerformanceNavigationTiming?(c=a.performance.getEntriesByType("navigation"),c=0<c.length&&(c[0].nextHopProtocol=="hq"||c[0].nextHopProtocol=="h2")):c=!!(a.chrome&&a.chrome.loadTimes&&a.chrome.loadTimes()&&a.chrome.loadTimes().wasFetchedViaSpdy),this.j=c?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function Jd(c){return c.h?!0:c.g?c.g.size>=c.j:!1}function Yd(c){return c.h?1:c.g?c.g.size:0}function Oc(c,d){return c.h?c.h==d:c.g?c.g.has(d):!1}function Mc(c,d){c.g?c.g.add(d):c.h=d}function Xd(c,d){c.h&&c.h==d?c.h=null:c.g&&c.g.has(d)&&c.g.delete(d)}Qd.prototype.cancel=function(){if(this.i=Zd(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const c of this.g.values())c.cancel();this.g.clear()}};function Zd(c){if(c.h!=null)return c.i.concat(c.h.D);if(c.g!=null&&c.g.size!==0){let d=c.i;for(const f of c.g.values())d=d.concat(f.D);return d}return $(c.i)}function w_(c){if(c.V&&typeof c.V=="function")return c.V();if(typeof Map<"u"&&c instanceof Map||typeof Set<"u"&&c instanceof Set)return Array.from(c.values());if(typeof c=="string")return c.split("");if(l(c)){for(var d=[],f=c.length,g=0;g<f;g++)d.push(c[g]);return d}d=[],f=0;for(g in c)d[f++]=c[g];return d}function I_(c){if(c.na&&typeof c.na=="function")return c.na();if(!c.V||typeof c.V!="function"){if(typeof Map<"u"&&c instanceof Map)return Array.from(c.keys());if(!(typeof Set<"u"&&c instanceof Set)){if(l(c)||typeof c=="string"){var d=[];c=c.length;for(var f=0;f<c;f++)d.push(f);return d}d=[],f=0;for(const g in c)d[f++]=g;return d}}}function eh(c,d){if(c.forEach&&typeof c.forEach=="function")c.forEach(d,void 0);else if(l(c)||typeof c=="string")Array.prototype.forEach.call(c,d,void 0);else for(var f=I_(c),g=w_(c),k=g.length,D=0;D<k;D++)d.call(void 0,g[D],f&&f[D],c)}var th=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function E_(c,d){if(c){c=c.split("&");for(var f=0;f<c.length;f++){var g=c[f].indexOf("="),k=null;if(0<=g){var D=c[f].substring(0,g);k=c[f].substring(g+1)}else D=c[f];d(D,k?decodeURIComponent(k.replace(/\+/g," ")):"")}}}function os(c){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,c instanceof os){this.h=c.h,Ao(this,c.j),this.o=c.o,this.g=c.g,So(this,c.s),this.l=c.l;var d=c.i,f=new Yi;f.i=d.i,d.g&&(f.g=new Map(d.g),f.h=d.h),nh(this,f),this.m=c.m}else c&&(d=String(c).match(th))?(this.h=!1,Ao(this,d[1]||"",!0),this.o=Qi(d[2]||""),this.g=Qi(d[3]||"",!0),So(this,d[4]),this.l=Qi(d[5]||"",!0),nh(this,d[6]||"",!0),this.m=Qi(d[7]||"")):(this.h=!1,this.i=new Yi(null,this.h))}os.prototype.toString=function(){var c=[],d=this.j;d&&c.push(Ji(d,sh,!0),":");var f=this.g;return(f||d=="file")&&(c.push("//"),(d=this.o)&&c.push(Ji(d,sh,!0),"@"),c.push(encodeURIComponent(String(f)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.s,f!=null&&c.push(":",String(f))),(f=this.l)&&(this.g&&f.charAt(0)!="/"&&c.push("/"),c.push(Ji(f,f.charAt(0)=="/"?S_:A_,!0))),(f=this.i.toString())&&c.push("?",f),(f=this.m)&&c.push("#",Ji(f,R_)),c.join("")};function en(c){return new os(c)}function Ao(c,d,f){c.j=f?Qi(d,!0):d,c.j&&(c.j=c.j.replace(/:$/,""))}function So(c,d){if(d){if(d=Number(d),isNaN(d)||0>d)throw Error("Bad port number "+d);c.s=d}else c.s=null}function nh(c,d,f){d instanceof Yi?(c.i=d,P_(c.i,c.h)):(f||(d=Ji(d,k_)),c.i=new Yi(d,c.h))}function ke(c,d,f){c.i.set(d,f)}function ko(c){return ke(c,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),c}function Qi(c,d){return c?d?decodeURI(c.replace(/%25/g,"%2525")):decodeURIComponent(c):""}function Ji(c,d,f){return typeof c=="string"?(c=encodeURI(c).replace(d,T_),f&&(c=c.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c):null}function T_(c){return c=c.charCodeAt(0),"%"+(c>>4&15).toString(16)+(c&15).toString(16)}var sh=/[#\/\?@]/g,A_=/[#\?:]/g,S_=/[#\?]/g,k_=/[#\?@]/g,R_=/#/g;function Yi(c,d){this.h=this.g=null,this.i=c||null,this.j=!!d}function Tn(c){c.g||(c.g=new Map,c.h=0,c.i&&E_(c.i,function(d,f){c.add(decodeURIComponent(d.replace(/\+/g," ")),f)}))}n=Yi.prototype,n.add=function(c,d){Tn(this),this.i=null,c=Us(this,c);var f=this.g.get(c);return f||this.g.set(c,f=[]),f.push(d),this.h+=1,this};function ih(c,d){Tn(c),d=Us(c,d),c.g.has(d)&&(c.i=null,c.h-=c.g.get(d).length,c.g.delete(d))}function rh(c,d){return Tn(c),d=Us(c,d),c.g.has(d)}n.forEach=function(c,d){Tn(this),this.g.forEach(function(f,g){f.forEach(function(k){c.call(d,k,g,this)},this)},this)},n.na=function(){Tn(this);const c=Array.from(this.g.values()),d=Array.from(this.g.keys()),f=[];for(let g=0;g<d.length;g++){const k=c[g];for(let D=0;D<k.length;D++)f.push(d[g])}return f},n.V=function(c){Tn(this);let d=[];if(typeof c=="string")rh(this,c)&&(d=d.concat(this.g.get(Us(this,c))));else{c=Array.from(this.g.values());for(let f=0;f<c.length;f++)d=d.concat(c[f])}return d},n.set=function(c,d){return Tn(this),this.i=null,c=Us(this,c),rh(this,c)&&(this.h-=this.g.get(c).length),this.g.set(c,[d]),this.h+=1,this},n.get=function(c,d){return c?(c=this.V(c),0<c.length?String(c[0]):d):d};function oh(c,d,f){ih(c,d),0<f.length&&(c.i=null,c.g.set(Us(c,d),$(f)),c.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const c=[],d=Array.from(this.g.keys());for(var f=0;f<d.length;f++){var g=d[f];const D=encodeURIComponent(String(g)),M=this.V(g);for(g=0;g<M.length;g++){var k=D;M[g]!==""&&(k+="="+encodeURIComponent(String(M[g]))),c.push(k)}}return this.i=c.join("&")};function Us(c,d){return d=String(d),c.j&&(d=d.toLowerCase()),d}function P_(c,d){d&&!c.j&&(Tn(c),c.i=null,c.g.forEach(function(f,g){var k=g.toLowerCase();g!=k&&(ih(this,g),oh(this,k,f))},c)),c.j=d}function C_(c,d){const f=new Wi;if(a.Image){const g=new Image;g.onload=w(An,f,"TestLoadImage: loaded",!0,d,g),g.onerror=w(An,f,"TestLoadImage: error",!1,d,g),g.onabort=w(An,f,"TestLoadImage: abort",!1,d,g),g.ontimeout=w(An,f,"TestLoadImage: timeout",!1,d,g),a.setTimeout(function(){g.ontimeout&&g.ontimeout()},1e4),g.src=c}else d(!1)}function D_(c,d){const f=new Wi,g=new AbortController,k=setTimeout(()=>{g.abort(),An(f,"TestPingServer: timeout",!1,d)},1e4);fetch(c,{signal:g.signal}).then(D=>{clearTimeout(k),D.ok?An(f,"TestPingServer: ok",!0,d):An(f,"TestPingServer: server error",!1,d)}).catch(()=>{clearTimeout(k),An(f,"TestPingServer: error",!1,d)})}function An(c,d,f,g,k){try{k&&(k.onload=null,k.onerror=null,k.onabort=null,k.ontimeout=null),g(f)}catch{}}function $_(){this.g=new p_}function V_(c,d,f){const g=f||"";try{eh(c,function(k,D){let M=k;u(k)&&(M=kc(k)),d.push(g+D+"="+encodeURIComponent(M))})}catch(k){throw d.push(g+"type="+encodeURIComponent("_badmap")),k}}function Xi(c){this.l=c.Ub||null,this.j=c.eb||!1}E(Xi,Rc),Xi.prototype.g=function(){return new Ro(this.l,this.j)},Xi.prototype.i=function(c){return function(){return c}}({});function Ro(c,d){it.call(this),this.D=c,this.o=d,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}E(Ro,it),n=Ro.prototype,n.open=function(c,d){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=c,this.A=d,this.readyState=1,er(this)},n.send=function(c){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const d={headers:this.u,method:this.B,credentials:this.m,cache:void 0};c&&(d.body=c),(this.D||a).fetch(new Request(this.A,d)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,Zi(this)),this.readyState=0},n.Sa=function(c){if(this.g&&(this.l=c,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=c.headers,this.readyState=2,er(this)),this.g&&(this.readyState=3,er(this),this.g)))if(this.responseType==="arraybuffer")c.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof a.ReadableStream<"u"&&"body"in c){if(this.j=c.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;ah(this)}else c.text().then(this.Ra.bind(this),this.ga.bind(this))};function ah(c){c.j.read().then(c.Pa.bind(c)).catch(c.ga.bind(c))}n.Pa=function(c){if(this.g){if(this.o&&c.value)this.response.push(c.value);else if(!this.o){var d=c.value?c.value:new Uint8Array(0);(d=this.v.decode(d,{stream:!c.done}))&&(this.response=this.responseText+=d)}c.done?Zi(this):er(this),this.readyState==3&&ah(this)}},n.Ra=function(c){this.g&&(this.response=this.responseText=c,Zi(this))},n.Qa=function(c){this.g&&(this.response=c,Zi(this))},n.ga=function(){this.g&&Zi(this)};function Zi(c){c.readyState=4,c.l=null,c.j=null,c.v=null,er(c)}n.setRequestHeader=function(c,d){this.u.append(c,d)},n.getResponseHeader=function(c){return this.h&&this.h.get(c.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const c=[],d=this.h.entries();for(var f=d.next();!f.done;)f=f.value,c.push(f[0]+": "+f[1]),f=d.next();return c.join(`\r
`)};function er(c){c.onreadystatechange&&c.onreadystatechange.call(c)}Object.defineProperty(Ro.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(c){this.m=c?"include":"same-origin"}});function ch(c){let d="";return L(c,function(f,g){d+=g,d+=":",d+=f,d+=`\r
`}),d}function Lc(c,d,f){e:{for(g in f){var g=!1;break e}g=!0}g||(f=ch(f),typeof c=="string"?f!=null&&encodeURIComponent(String(f)):ke(c,d,f))}function xe(c){it.call(this),this.headers=new Map,this.o=c||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}E(xe,it);var N_=/^https?$/i,x_=["POST","PUT"];n=xe.prototype,n.Ha=function(c){this.J=c},n.ea=function(c,d,f,g){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+c);d=d?d.toUpperCase():"GET",this.D=c,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():Dc.g(),this.v=this.o?Md(this.o):Md(Dc),this.g.onreadystatechange=m(this.Ea,this);try{this.B=!0,this.g.open(d,String(c),!0),this.B=!1}catch(D){lh(this,D);return}if(c=f||"",f=new Map(this.headers),g)if(Object.getPrototypeOf(g)===Object.prototype)for(var k in g)f.set(k,g[k]);else if(typeof g.keys=="function"&&typeof g.get=="function")for(const D of g.keys())f.set(D,g.get(D));else throw Error("Unknown input type for opt_headers: "+String(g));g=Array.from(f.keys()).find(D=>D.toLowerCase()=="content-type"),k=a.FormData&&c instanceof a.FormData,!(0<=Array.prototype.indexOf.call(x_,d,void 0))||g||k||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[D,M]of f)this.g.setRequestHeader(D,M);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{hh(this),this.u=!0,this.g.send(c),this.u=!1}catch(D){lh(this,D)}};function lh(c,d){c.h=!1,c.g&&(c.j=!0,c.g.abort(),c.j=!1),c.l=d,c.m=5,uh(c),Po(c)}function uh(c){c.A||(c.A=!0,dt(c,"complete"),dt(c,"error"))}n.abort=function(c){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=c||7,dt(this,"complete"),dt(this,"abort"),Po(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Po(this,!0)),xe.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?dh(this):this.bb())},n.bb=function(){dh(this)};function dh(c){if(c.h&&typeof o<"u"&&(!c.v[1]||tn(c)!=4||c.Z()!=2)){if(c.u&&tn(c)==4)Vd(c.Ea,0,c);else if(dt(c,"readystatechange"),tn(c)==4){c.h=!1;try{const M=c.Z();e:switch(M){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var d=!0;break e;default:d=!1}var f;if(!(f=d)){var g;if(g=M===0){var k=String(c.D).match(th)[1]||null;!k&&a.self&&a.self.location&&(k=a.self.location.protocol.slice(0,-1)),g=!N_.test(k?k.toLowerCase():"")}f=g}if(f)dt(c,"complete"),dt(c,"success");else{c.m=6;try{var D=2<tn(c)?c.g.statusText:""}catch{D=""}c.l=D+" ["+c.Z()+"]",uh(c)}}finally{Po(c)}}}}function Po(c,d){if(c.g){hh(c);const f=c.g,g=c.v[0]?()=>{}:null;c.g=null,c.v=null,d||dt(c,"ready");try{f.onreadystatechange=g}catch{}}}function hh(c){c.I&&(a.clearTimeout(c.I),c.I=null)}n.isActive=function(){return!!this.g};function tn(c){return c.g?c.g.readyState:0}n.Z=function(){try{return 2<tn(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(c){if(this.g){var d=this.g.responseText;return c&&d.indexOf(c)==0&&(d=d.substring(c.length)),f_(d)}};function fh(c){try{if(!c.g)return null;if("response"in c.g)return c.g.response;switch(c.H){case"":case"text":return c.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in c.g)return c.g.mozResponseArrayBuffer}return null}catch{return null}}function O_(c){const d={};c=(c.g&&2<=tn(c)&&c.g.getAllResponseHeaders()||"").split(`\r
`);for(let g=0;g<c.length;g++){if(H(c[g]))continue;var f=T(c[g]);const k=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const D=d[k]||[];d[k]=D,D.push(f)}b(d,function(g){return g.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function tr(c,d,f){return f&&f.internalChannelParams&&f.internalChannelParams[c]||d}function ph(c){this.Aa=0,this.i=[],this.j=new Wi,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=tr("failFast",!1,c),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=tr("baseRetryDelayMs",5e3,c),this.cb=tr("retryDelaySeedMs",1e4,c),this.Wa=tr("forwardChannelMaxRetries",2,c),this.wa=tr("forwardChannelRequestTimeoutMs",2e4,c),this.pa=c&&c.xmlHttpFactory||void 0,this.Xa=c&&c.Tb||void 0,this.Ca=c&&c.useFetchStreams||!1,this.L=void 0,this.J=c&&c.supportsCrossDomainXhr||!1,this.K="",this.h=new Qd(c&&c.concurrentRequestLimit),this.Da=new $_,this.P=c&&c.fastHandshake||!1,this.O=c&&c.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=c&&c.Rb||!1,c&&c.xa&&this.j.xa(),c&&c.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&c&&c.detectBufferingProxy||!1,this.ja=void 0,c&&c.longPollingTimeout&&0<c.longPollingTimeout&&(this.ja=c.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=ph.prototype,n.la=8,n.G=1,n.connect=function(c,d,f,g){ht(0),this.W=c,this.H=d||{},f&&g!==void 0&&(this.H.OSID=f,this.H.OAID=g),this.F=this.X,this.I=Eh(this,null,this.W),Do(this)};function Fc(c){if(mh(c),c.G==3){var d=c.U++,f=en(c.I);if(ke(f,"SID",c.K),ke(f,"RID",d),ke(f,"TYPE","terminate"),nr(c,f),d=new En(c,c.j,d),d.L=2,d.v=ko(en(f)),f=!1,a.navigator&&a.navigator.sendBeacon)try{f=a.navigator.sendBeacon(d.v.toString(),"")}catch{}!f&&a.Image&&(new Image().src=d.v,f=!0),f||(d.g=Th(d.j,null),d.g.ea(d.v)),d.F=Date.now(),To(d)}Ih(c)}function Co(c){c.g&&(qc(c),c.g.cancel(),c.g=null)}function mh(c){Co(c),c.u&&(a.clearTimeout(c.u),c.u=null),$o(c),c.h.cancel(),c.s&&(typeof c.s=="number"&&a.clearTimeout(c.s),c.s=null)}function Do(c){if(!Jd(c.h)&&!c.s){c.s=!0;var d=c.Ga;Ui||Rd(),qi||(Ui(),qi=!0),_c.add(d,c),c.B=0}}function M_(c,d){return Yd(c.h)>=c.h.j-(c.s?1:0)?!1:c.s?(c.i=d.D.concat(c.i),!0):c.G==1||c.G==2||c.B>=(c.Va?0:c.Wa)?!1:(c.s=Ki(m(c.Ga,c,d),wh(c,c.B)),c.B++,!0)}n.Ga=function(c){if(this.s)if(this.s=null,this.G==1){if(!c){this.U=Math.floor(1e5*Math.random()),c=this.U++;const k=new En(this,this.j,c);let D=this.o;if(this.S&&(D?(D=y(D),I(D,this.S)):D=this.S),this.m!==null||this.O||(k.H=D,D=null),this.P)e:{for(var d=0,f=0;f<this.i.length;f++){t:{var g=this.i[f];if("__data__"in g.map&&(g=g.map.__data__,typeof g=="string")){g=g.length;break t}g=void 0}if(g===void 0)break;if(d+=g,4096<d){d=f;break e}if(d===4096||f===this.i.length-1){d=f+1;break e}}d=1e3}else d=1e3;d=yh(this,k,d),f=en(this.I),ke(f,"RID",c),ke(f,"CVER",22),this.D&&ke(f,"X-HTTP-Session-Id",this.D),nr(this,f),D&&(this.O?d="headers="+encodeURIComponent(String(ch(D)))+"&"+d:this.m&&Lc(f,this.m,D)),Mc(this.h,k),this.Ua&&ke(f,"TYPE","init"),this.P?(ke(f,"$req",d),ke(f,"SID","null"),k.T=!0,Vc(k,f,null)):Vc(k,f,d),this.G=2}}else this.G==3&&(c?gh(this,c):this.i.length==0||Jd(this.h)||gh(this))};function gh(c,d){var f;d?f=d.l:f=c.U++;const g=en(c.I);ke(g,"SID",c.K),ke(g,"RID",f),ke(g,"AID",c.T),nr(c,g),c.m&&c.o&&Lc(g,c.m,c.o),f=new En(c,c.j,f,c.B+1),c.m===null&&(f.H=c.o),d&&(c.i=d.D.concat(c.i)),d=yh(c,f,1e3),f.I=Math.round(.5*c.wa)+Math.round(.5*c.wa*Math.random()),Mc(c.h,f),Vc(f,g,d)}function nr(c,d){c.H&&L(c.H,function(f,g){ke(d,g,f)}),c.l&&eh({},function(f,g){ke(d,g,f)})}function yh(c,d,f){f=Math.min(c.i.length,f);var g=c.l?m(c.l.Na,c.l,c):null;e:{var k=c.i;let D=-1;for(;;){const M=["count="+f];D==-1?0<f?(D=k[0].g,M.push("ofs="+D)):D=0:M.push("ofs="+D);let Te=!0;for(let Xe=0;Xe<f;Xe++){let ge=k[Xe].g;const rt=k[Xe].map;if(ge-=D,0>ge)D=Math.max(0,k[Xe].g-100),Te=!1;else try{V_(rt,M,"req"+ge+"_")}catch{g&&g(rt)}}if(Te){g=M.join("&");break e}}}return c=c.i.splice(0,f),d.D=c,g}function vh(c){if(!c.g&&!c.u){c.Y=1;var d=c.Fa;Ui||Rd(),qi||(Ui(),qi=!0),_c.add(d,c),c.v=0}}function Uc(c){return c.g||c.u||3<=c.v?!1:(c.Y++,c.u=Ki(m(c.Fa,c),wh(c,c.v)),c.v++,!0)}n.Fa=function(){if(this.u=null,_h(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var c=2*this.R;this.j.info("BP detection timer enabled: "+c),this.A=Ki(m(this.ab,this),c)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,ht(10),Co(this),_h(this))};function qc(c){c.A!=null&&(a.clearTimeout(c.A),c.A=null)}function _h(c){c.g=new En(c,c.j,"rpc",c.Y),c.m===null&&(c.g.H=c.o),c.g.O=0;var d=en(c.qa);ke(d,"RID","rpc"),ke(d,"SID",c.K),ke(d,"AID",c.T),ke(d,"CI",c.F?"0":"1"),!c.F&&c.ja&&ke(d,"TO",c.ja),ke(d,"TYPE","xmlhttp"),nr(c,d),c.m&&c.o&&Lc(d,c.m,c.o),c.L&&(c.g.I=c.L);var f=c.g;c=c.ia,f.L=1,f.v=ko(en(d)),f.m=null,f.P=!0,Kd(f,c)}n.Za=function(){this.C!=null&&(this.C=null,Co(this),Uc(this),ht(19))};function $o(c){c.C!=null&&(a.clearTimeout(c.C),c.C=null)}function bh(c,d){var f=null;if(c.g==d){$o(c),qc(c),c.g=null;var g=2}else if(Oc(c.h,d))f=d.D,Xd(c.h,d),g=1;else return;if(c.G!=0){if(d.o)if(g==1){f=d.m?d.m.length:0,d=Date.now()-d.F;var k=c.B;g=wo(),dt(g,new Bd(g,f)),Do(c)}else vh(c);else if(k=d.s,k==3||k==0&&0<d.X||!(g==1&&M_(c,d)||g==2&&Uc(c)))switch(f&&0<f.length&&(d=c.h,d.i=d.i.concat(f)),k){case 1:as(c,5);break;case 4:as(c,10);break;case 3:as(c,6);break;default:as(c,2)}}}function wh(c,d){let f=c.Ta+Math.floor(Math.random()*c.cb);return c.isActive()||(f*=2),f*d}function as(c,d){if(c.j.info("Error code "+d),d==2){var f=m(c.fb,c),g=c.Xa;const k=!g;g=new os(g||"//www.google.com/images/cleardot.gif"),a.location&&a.location.protocol=="http"||Ao(g,"https"),ko(g),k?C_(g.toString(),f):D_(g.toString(),f)}else ht(2);c.G=0,c.l&&c.l.sa(d),Ih(c),mh(c)}n.fb=function(c){c?(this.j.info("Successfully pinged google.com"),ht(2)):(this.j.info("Failed to ping google.com"),ht(1))};function Ih(c){if(c.G=0,c.ka=[],c.l){const d=Zd(c.h);(d.length!=0||c.i.length!=0)&&(R(c.ka,d),R(c.ka,c.i),c.h.i.length=0,$(c.i),c.i.length=0),c.l.ra()}}function Eh(c,d,f){var g=f instanceof os?en(f):new os(f);if(g.g!="")d&&(g.g=d+"."+g.g),So(g,g.s);else{var k=a.location;g=k.protocol,d=d?d+"."+k.hostname:k.hostname,k=+k.port;var D=new os(null);g&&Ao(D,g),d&&(D.g=d),k&&So(D,k),f&&(D.l=f),g=D}return f=c.D,d=c.ya,f&&d&&ke(g,f,d),ke(g,"VER",c.la),nr(c,g),g}function Th(c,d,f){if(d&&!c.J)throw Error("Can't create secondary domain capable XhrIo object.");return d=c.Ca&&!c.pa?new xe(new Xi({eb:f})):new xe(c.pa),d.Ha(c.J),d}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function Ah(){}n=Ah.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function Vo(){}Vo.prototype.g=function(c,d){return new Tt(c,d)};function Tt(c,d){it.call(this),this.g=new ph(d),this.l=c,this.h=d&&d.messageUrlParams||null,c=d&&d.messageHeaders||null,d&&d.clientProtocolHeaderRequired&&(c?c["X-Client-Protocol"]="webchannel":c={"X-Client-Protocol":"webchannel"}),this.g.o=c,c=d&&d.initMessageHeaders||null,d&&d.messageContentType&&(c?c["X-WebChannel-Content-Type"]=d.messageContentType:c={"X-WebChannel-Content-Type":d.messageContentType}),d&&d.va&&(c?c["X-WebChannel-Client-Profile"]=d.va:c={"X-WebChannel-Client-Profile":d.va}),this.g.S=c,(c=d&&d.Sb)&&!H(c)&&(this.g.m=c),this.v=d&&d.supportsCrossDomainXhr||!1,this.u=d&&d.sendRawJson||!1,(d=d&&d.httpSessionIdParam)&&!H(d)&&(this.g.D=d,c=this.h,c!==null&&d in c&&(c=this.h,d in c&&delete c[d])),this.j=new qs(this)}E(Tt,it),Tt.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},Tt.prototype.close=function(){Fc(this.g)},Tt.prototype.o=function(c){var d=this.g;if(typeof c=="string"){var f={};f.__data__=c,c=f}else this.u&&(f={},f.__data__=kc(c),c=f);d.i.push(new b_(d.Ya++,c)),d.G==3&&Do(d)},Tt.prototype.N=function(){this.g.l=null,delete this.j,Fc(this.g),delete this.g,Tt.aa.N.call(this)};function Sh(c){Pc.call(this),c.__headers__&&(this.headers=c.__headers__,this.statusCode=c.__status__,delete c.__headers__,delete c.__status__);var d=c.__sm__;if(d){e:{for(const f in d){c=f;break e}c=void 0}(this.i=c)&&(c=this.i,d=d!==null&&c in d?d[c]:void 0),this.data=d}else this.data=c}E(Sh,Pc);function kh(){Cc.call(this),this.status=1}E(kh,Cc);function qs(c){this.g=c}E(qs,Ah),qs.prototype.ua=function(){dt(this.g,"a")},qs.prototype.ta=function(c){dt(this.g,new Sh(c))},qs.prototype.sa=function(c){dt(this.g,new kh)},qs.prototype.ra=function(){dt(this.g,"b")},Vo.prototype.createWebChannel=Vo.prototype.g,Tt.prototype.send=Tt.prototype.o,Tt.prototype.open=Tt.prototype.m,Tt.prototype.close=Tt.prototype.close,Ym=function(){return new Vo},Jm=function(){return wo()},Qm=is,bl={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Io.NO_ERROR=0,Io.TIMEOUT=8,Io.HTTP_ERROR=6,Jo=Io,jd.COMPLETE="complete",Hm=jd,Ld.EventType=zi,zi.OPEN="a",zi.CLOSE="b",zi.ERROR="c",zi.MESSAGE="d",it.prototype.listen=it.prototype.K,fr=Ld,Wm=Xi,xe.prototype.listenOnce=xe.prototype.L,xe.prototype.getLastError=xe.prototype.Ka,xe.prototype.getLastErrorCode=xe.prototype.Ba,xe.prototype.getStatus=xe.prototype.Z,xe.prototype.getResponseJson=xe.prototype.Oa,xe.prototype.getResponseText=xe.prototype.oa,xe.prototype.send=xe.prototype.ea,xe.prototype.setWithCredentials=xe.prototype.Ha,Km=xe}).apply(typeof Oo<"u"?Oo:typeof self<"u"?self:typeof window<"u"?window:{});const of="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ct{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}ct.UNAUTHENTICATED=new ct(null),ct.GOOGLE_CREDENTIALS=new ct("google-credentials-uid"),ct.FIRST_PARTY=new ct("first-party-uid"),ct.MOCK_USER=new ct("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ni="10.12.1";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const As=new iu("@firebase/firestore");function Ys(){return As.logLevel}function N(n,...e){if(As.logLevel<=ce.DEBUG){const t=e.map(gu);As.debug(`Firestore (${Ni}): ${n}`,...t)}}function Fe(n,...e){if(As.logLevel<=ce.ERROR){const t=e.map(gu);As.error(`Firestore (${Ni}): ${n}`,...t)}}function Vr(n,...e){if(As.logLevel<=ce.WARN){const t=e.map(gu);As.warn(`Firestore (${Ni}): ${n}`,...t)}}function gu(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function G(n="Unexpected state"){const e=`FIRESTORE (${Ni}) INTERNAL ASSERTION FAILED: `+n;throw Fe(e),new Error(e)}function X(n,e){n||G()}function W(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const V={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class F extends yn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fn{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PE{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class CE{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(ct.UNAUTHENTICATED))}shutdown(){}}class DE{constructor(e){this.t=e,this.currentUser=ct.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let s=this.i;const i=l=>this.i!==s?(s=this.i,t(l)):Promise.resolve();let r=new fn;this.o=()=>{this.i++,this.currentUser=this.u(),r.resolve(),r=new fn,e.enqueueRetryable(()=>i(this.currentUser))};const o=()=>{const l=r;e.enqueueRetryable(async()=>{await l.promise,await i(this.currentUser)})},a=l=>{N("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),o()};this.t.onInit(l=>a(l)),setTimeout(()=>{if(!this.auth){const l=this.t.getImmediate({optional:!0});l?a(l):(N("FirebaseAuthCredentialsProvider","Auth not yet detected"),r.resolve(),r=new fn)}},0),o()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(s=>this.i!==e?(N("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(X(typeof s.accessToken=="string"),new PE(s.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const e=this.auth&&this.auth.getUid();return X(e===null||typeof e=="string"),new ct(e)}}class $E{constructor(e,t,s){this.l=e,this.h=t,this.P=s,this.type="FirstParty",this.user=ct.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class VE{constructor(e,t,s){this.l=e,this.h=t,this.P=s}getToken(){return Promise.resolve(new $E(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(ct.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class NE{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class xE{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,t){const s=r=>{r.error!=null&&N("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${r.error.message}`);const o=r.token!==this.R;return this.R=r.token,N("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(r.token):Promise.resolve()};this.o=r=>{e.enqueueRetryable(()=>s(r))};const i=r=>{N("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=r,this.appCheck.addTokenListener(this.o)};this.A.onInit(r=>i(r)),setTimeout(()=>{if(!this.appCheck){const r=this.A.getImmediate({optional:!0});r?i(r):N("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(X(typeof t.token=="string"),this.R=t.token,new NE(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function OE(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<n;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xm{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length;let s="";for(;s.length<20;){const i=OE(40);for(let r=0;r<i.length;++r)s.length<20&&i[r]<t&&(s+=e.charAt(i[r]%e.length))}return s}}function ne(n,e){return n<e?-1:n>e?1:0}function fi(n,e,t){return n.length===e.length&&n.every((s,i)=>t(s,e[i]))}function Zm(n){return n+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ne{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new F(V.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new F(V.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800)throw new F(V.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new F(V.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return Ne.fromMillis(Date.now())}static fromDate(e){return Ne.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor(1e6*(e-1e3*t));return new Ne(t,s)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?ne(this.nanoseconds,e.nanoseconds):ne(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Z{constructor(e){this.timestamp=e}static fromTimestamp(e){return new Z(e)}static min(){return new Z(new Ne(0,0))}static max(){return new Z(new Ne(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nr{constructor(e,t,s){t===void 0?t=0:t>e.length&&G(),s===void 0?s=e.length-t:s>e.length-t&&G(),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return Nr.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Nr?e.forEach(s=>{t.push(s)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let i=0;i<s;i++){const r=e.get(i),o=t.get(i);if(r<o)return-1;if(r>o)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class be extends Nr{construct(e,t,s){return new be(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new F(V.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter(i=>i.length>0))}return new be(t)}static emptyPath(){return new be([])}}const ME=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Ve extends Nr{construct(e,t,s){return new Ve(e,t,s)}static isValidIdentifier(e){return ME.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Ve.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new Ve(["__name__"])}static fromServerFormat(e){const t=[];let s="",i=0;const r=()=>{if(s.length===0)throw new F(V.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let o=!1;for(;i<e.length;){const a=e[i];if(a==="\\"){if(i+1===e.length)throw new F(V.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const l=e[i+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new F(V.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=l,i+=2}else a==="`"?(o=!o,i++):a!=="."||o?(s+=a,i++):(r(),i++)}if(r(),o)throw new F(V.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Ve(t)}static emptyPath(){return new Ve([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{constructor(e){this.path=e}static fromPath(e){return new q(be.fromString(e))}static fromName(e){return new q(be.fromString(e).popFirst(5))}static empty(){return new q(be.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&be.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return be.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new q(new be(e.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ga{constructor(e,t,s,i){this.indexId=e,this.collectionGroup=t,this.fields=s,this.indexState=i}}function wl(n){return n.fields.find(e=>e.kind===2)}function us(n){return n.fields.filter(e=>e.kind!==2)}ga.UNKNOWN_ID=-1;class Yo{constructor(e,t){this.fieldPath=e,this.kind=t}}class xr{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new xr(0,Rt.min())}}function eg(n,e){const t=n.toTimestamp().seconds,s=n.toTimestamp().nanoseconds+1,i=Z.fromTimestamp(s===1e9?new Ne(t+1,0):new Ne(t,s));return new Rt(i,q.empty(),e)}function tg(n){return new Rt(n.readTime,n.key,-1)}class Rt{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new Rt(Z.min(),q.empty(),-1)}static max(){return new Rt(Z.max(),q.empty(),-1)}}function yu(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=q.comparator(n.documentKey,e.documentKey),t!==0?t:ne(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ng="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class sg{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Zn(n){if(n.code!==V.FAILED_PRECONDITION||n.message!==ng)throw n;N("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class C{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&G(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new C((s,i)=>{this.nextCallback=r=>{this.wrapSuccess(e,r).next(s,i)},this.catchCallback=r=>{this.wrapFailure(t,r).next(s,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof C?t:C.resolve(t)}catch(t){return C.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):C.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):C.reject(t)}static resolve(e){return new C((t,s)=>{t(e)})}static reject(e){return new C((t,s)=>{s(e)})}static waitFor(e){return new C((t,s)=>{let i=0,r=0,o=!1;e.forEach(a=>{++i,a.next(()=>{++r,o&&r===i&&t()},l=>s(l))}),o=!0,r===i&&t()})}static or(e){let t=C.resolve(!1);for(const s of e)t=t.next(i=>i?C.resolve(i):s());return t}static forEach(e,t){const s=[];return e.forEach((i,r)=>{s.push(t.call(this,i,r))}),this.waitFor(s)}static mapArray(e,t){return new C((s,i)=>{const r=e.length,o=new Array(r);let a=0;for(let l=0;l<r;l++){const u=l;t(e[u]).next(h=>{o[u]=h,++a,a===r&&s(o)},h=>i(h))}})}static doWhile(e,t){return new C((s,i)=>{const r=()=>{e()===!0?t().next(()=>{r()},i):s()};r()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ha{constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.V=new fn,this.transaction.oncomplete=()=>{this.V.resolve()},this.transaction.onabort=()=>{t.error?this.V.reject(new _r(e,t.error)):this.V.resolve()},this.transaction.onerror=s=>{const i=vu(s.target.error);this.V.reject(new _r(e,i))}}static open(e,t,s,i){try{return new Ha(t,e.transaction(i,s))}catch(r){throw new _r(t,r)}}get m(){return this.V.promise}abort(e){e&&this.V.reject(e),this.aborted||(N("SimpleDb","Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}g(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new FE(t)}}class Bn{constructor(e,t,s){this.name=e,this.version=t,this.p=s,Bn.S(ze())===12.2&&Fe("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(e){return N("SimpleDb","Removing database:",e),ds(window.indexedDB.deleteDatabase(e)).toPromise()}static D(){if(!am())return!1;if(Bn.C())return!0;const e=ze(),t=Bn.S(e),s=0<t&&t<10,i=ig(e),r=0<i&&i<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||s||r)}static C(){var e;return typeof process<"u"&&((e=process.__PRIVATE_env)===null||e===void 0?void 0:e.v)==="YES"}static F(e,t){return e.store(t)}static S(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),s=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(s)}async M(e){return this.db||(N("SimpleDb","Opening database:",this.name),this.db=await new Promise((t,s)=>{const i=indexedDB.open(this.name,this.version);i.onsuccess=r=>{const o=r.target.result;t(o)},i.onblocked=()=>{s(new _r(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},i.onerror=r=>{const o=r.target.error;o.name==="VersionError"?s(new F(V.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):o.name==="InvalidStateError"?s(new F(V.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+o)):s(new _r(e,o))},i.onupgradeneeded=r=>{N("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',r.oldVersion);const o=r.target.result;this.p.O(o,i.transaction,r.oldVersion,this.version).next(()=>{N("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.N&&(this.db.onversionchange=t=>this.N(t)),this.db}L(e){this.N=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,s,i){const r=t==="readonly";let o=0;for(;;){++o;try{this.db=await this.M(e);const a=Ha.open(this.db,e,r?"readonly":"readwrite",s),l=i(a).next(u=>(a.g(),u)).catch(u=>(a.abort(u),C.reject(u))).toPromise();return l.catch(()=>{}),await a.m,l}catch(a){const l=a,u=l.name!=="FirebaseError"&&o<3;if(N("SimpleDb","Transaction failed with error:",l.message,"Retrying:",u),this.close(),!u)return Promise.reject(l)}}}close(){this.db&&this.db.close(),this.db=void 0}}function ig(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class LE{constructor(e){this.B=e,this.k=!1,this.q=null}get isDone(){return this.k}get K(){return this.q}set cursor(e){this.B=e}done(){this.k=!0}$(e){this.q=e}delete(){return ds(this.B.delete())}}class _r extends F{constructor(e,t){super(V.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function es(n){return n.name==="IndexedDbTransactionError"}class FE{constructor(e){this.store=e}put(e,t){let s;return t!==void 0?(N("SimpleDb","PUT",this.store.name,e,t),s=this.store.put(t,e)):(N("SimpleDb","PUT",this.store.name,"<auto-key>",e),s=this.store.put(e)),ds(s)}add(e){return N("SimpleDb","ADD",this.store.name,e,e),ds(this.store.add(e))}get(e){return ds(this.store.get(e)).next(t=>(t===void 0&&(t=null),N("SimpleDb","GET",this.store.name,e,t),t))}delete(e){return N("SimpleDb","DELETE",this.store.name,e),ds(this.store.delete(e))}count(){return N("SimpleDb","COUNT",this.store.name),ds(this.store.count())}U(e,t){const s=this.options(e,t),i=s.index?this.store.index(s.index):this.store;if(typeof i.getAll=="function"){const r=i.getAll(s.range);return new C((o,a)=>{r.onerror=l=>{a(l.target.error)},r.onsuccess=l=>{o(l.target.result)}})}{const r=this.cursor(s),o=[];return this.W(r,(a,l)=>{o.push(l)}).next(()=>o)}}G(e,t){const s=this.store.getAll(e,t===null?void 0:t);return new C((i,r)=>{s.onerror=o=>{r(o.target.error)},s.onsuccess=o=>{i(o.target.result)}})}j(e,t){N("SimpleDb","DELETE ALL",this.store.name);const s=this.options(e,t);s.H=!1;const i=this.cursor(s);return this.W(i,(r,o,a)=>a.delete())}J(e,t){let s;t?s=e:(s={},t=e);const i=this.cursor(s);return this.W(i,t)}Y(e){const t=this.cursor({});return new C((s,i)=>{t.onerror=r=>{const o=vu(r.target.error);i(o)},t.onsuccess=r=>{const o=r.target.result;o?e(o.primaryKey,o.value).next(a=>{a?o.continue():s()}):s()}})}W(e,t){const s=[];return new C((i,r)=>{e.onerror=o=>{r(o.target.error)},e.onsuccess=o=>{const a=o.target.result;if(!a)return void i();const l=new LE(a),u=t(a.primaryKey,a.value,l);if(u instanceof C){const h=u.catch(p=>(l.done(),C.reject(p)));s.push(h)}l.isDone?i():l.K===null?a.continue():a.continue(l.K)}}).next(()=>C.waitFor(s))}options(e,t){let s;return e!==void 0&&(typeof e=="string"?s=e:t=e),{index:s,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const s=this.store.index(e.index);return e.H?s.openKeyCursor(e.range,t):s.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function ds(n){return new C((e,t)=>{n.onsuccess=s=>{const i=s.target.result;e(i)},n.onerror=s=>{const i=vu(s.target.error);t(i)}})}let af=!1;function vu(n){const e=Bn.S(ze());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(n.message.indexOf(t)>=0){const s=new F("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return af||(af=!0,setTimeout(()=>{throw s},0)),s}}return n}class UE{constructor(e,t){this.asyncQueue=e,this.Z=t,this.task=null}start(){this.X(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}X(e){N("IndexBackfiller",`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,async()=>{this.task=null;try{N("IndexBackfiller",`Documents written: ${await this.Z.ee()}`)}catch(t){es(t)?N("IndexBackfiller","Ignoring IndexedDB error during index backfill: ",t):await Zn(t)}await this.X(6e4)})}}class qE{constructor(e,t){this.localStore=e,this.persistence=t}async ee(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",t=>this.te(t,e))}te(e,t){const s=new Set;let i=t,r=!0;return C.doWhile(()=>r===!0&&i>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next(o=>{if(o!==null&&!s.has(o))return N("IndexBackfiller",`Processing collection: ${o}`),this.ne(e,o,i).next(a=>{i-=a,s.add(o)});r=!1})).next(()=>t-i)}ne(e,t,s){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next(i=>this.localStore.localDocuments.getNextDocuments(e,t,i,s).next(r=>{const o=r.changes;return this.localStore.indexManager.updateIndexEntries(e,o).next(()=>this.re(i,r)).next(a=>(N("IndexBackfiller",`Updating offset: ${a}`),this.localStore.indexManager.updateCollectionGroup(e,t,a))).next(()=>o.size)}))}re(e,t){let s=e;return t.changes.forEach((i,r)=>{const o=tg(r);yu(o,s)>0&&(s=o)}),new Rt(s.readTime,s.documentKey,Math.max(t.batchId,e.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class It{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.ie(s),this.se=s=>t.writeSequenceNumber(s))}ie(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.se&&this.se(e),e}}It.oe=-1;function Qa(n){return n==null}function Or(n){return n===0&&1/n==-1/0}function rg(n){return typeof n=="number"&&Number.isInteger(n)&&!Or(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mt(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=cf(e)),e=BE(n.get(t),e);return cf(e)}function BE(n,e){let t=e;const s=n.length;for(let i=0;i<s;i++){const r=n.charAt(i);switch(r){case"\0":t+="";break;case"":t+="";break;default:t+=r}}return t}function cf(n){return n+""}function zt(n){const e=n.length;if(X(e>=2),e===2)return X(n.charAt(0)===""&&n.charAt(1)===""),be.emptyPath();const t=e-2,s=[];let i="";for(let r=0;r<e;){const o=n.indexOf("",r);switch((o<0||o>t)&&G(),n.charAt(o+1)){case"":const a=n.substring(r,o);let l;i.length===0?l=a:(i+=a,l=i,i=""),s.push(l);break;case"":i+=n.substring(r,o),i+="\0";break;case"":i+=n.substring(r,o+1);break;default:G()}r=o+2}return new be(s)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lf=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xo(n,e){return[n,mt(e)]}function og(n,e,t){return[n,mt(e),t]}const jE={},zE=["prefixPath","collectionGroup","readTime","documentId"],GE=["prefixPath","collectionGroup","documentId"],KE=["collectionGroup","readTime","prefixPath","documentId"],WE=["canonicalId","targetId"],HE=["targetId","path"],QE=["path","targetId"],JE=["collectionId","parent"],YE=["indexId","uid"],XE=["uid","sequenceNumber"],ZE=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],eT=["indexId","uid","orderedDocumentKey"],tT=["userId","collectionPath","documentId"],nT=["userId","collectionPath","largestBatchId"],sT=["userId","collectionGroup","largestBatchId"],ag=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],iT=[...ag,"documentOverlays"],cg=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],lg=cg,ug=[...lg,"indexConfiguration","indexState","indexEntries"],rT=ug;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Il extends sg{constructor(e,t){super(),this._e=e,this.currentSequenceNumber=t}}function Ye(n,e){const t=W(n);return Bn.F(t._e,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uf(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function xs(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function dg(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Se{constructor(e,t){this.comparator=e,this.root=t||et.EMPTY}insert(e,t){return new Se(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,et.BLACK,null,null))}remove(e){return new Se(this.comparator,this.root.remove(e,this.comparator).copy(null,null,et.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const i=this.comparator(e,s.key);if(i===0)return t+s.left.size;i<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,s)=>(e(t,s),!1))}toString(){const e=[];return this.inorderTraversal((t,s)=>(e.push(`${t}:${s}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Mo(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Mo(this.root,e,this.comparator,!1)}getReverseIterator(){return new Mo(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Mo(this.root,e,this.comparator,!0)}}class Mo{constructor(e,t,s,i){this.isReverse=i,this.nodeStack=[];let r=1;for(;!e.isEmpty();)if(r=t?s(e.key,t):1,t&&i&&(r*=-1),r<0)e=this.isReverse?e.left:e.right;else{if(r===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class et{constructor(e,t,s,i,r){this.key=e,this.value=t,this.color=s??et.RED,this.left=i??et.EMPTY,this.right=r??et.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,i,r){return new et(e??this.key,t??this.value,s??this.color,i??this.left,r??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let i=this;const r=s(e,i.key);return i=r<0?i.copy(null,null,null,i.left.insert(e,t,s),null):r===0?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,s)),i.fixUp()}removeMin(){if(this.left.isEmpty())return et.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,i=this;if(t(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),t(e,i.key)===0){if(i.right.isEmpty())return et.EMPTY;s=i.right.min(),i=i.copy(s.key,s.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,et.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,et.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw G();const e=this.left.check();if(e!==this.right.check())throw G();return e+(this.isRed()?0:1)}}et.EMPTY=null,et.RED=!0,et.BLACK=!1;et.EMPTY=new class{constructor(){this.size=0}get key(){throw G()}get value(){throw G()}get color(){throw G()}get left(){throw G()}get right(){throw G()}copy(e,t,s,i,r){return this}insert(e,t,s){return new et(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ee{constructor(e){this.comparator=e,this.data=new Se(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,s)=>(e(t),!1))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const i=s.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new df(this.data.getIterator())}getIteratorFrom(e){return new df(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(s=>{t=t.add(s)}),t}isEqual(e){if(!(e instanceof Ee)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const i=t.getNext().key,r=s.getNext().key;if(this.comparator(i,r)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Ee(this.comparator);return t.data=e,t}}class df{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function js(n){return n.hasNext()?n.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Et{constructor(e){this.fields=e,e.sort(Ve.comparator)}static empty(){return new Et([])}unionWith(e){let t=new Ee(Ve.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new Et(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return fi(this.fields,e.fields,(t,s)=>t.isEqual(s))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hg extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Je{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(i){try{return atob(i)}catch(r){throw typeof DOMException<"u"&&r instanceof DOMException?new hg("Invalid base64 string: "+r):r}}(e);return new Je(t)}static fromUint8Array(e){const t=function(i){let r="";for(let o=0;o<i.length;++o)r+=String.fromCharCode(i[o]);return r}(e);return new Je(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const s=new Uint8Array(t.length);for(let i=0;i<t.length;i++)s[i]=t.charCodeAt(i);return s}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ne(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}Je.EMPTY_BYTE_STRING=new Je("");const oT=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function mn(n){if(X(!!n),typeof n=="string"){let e=0;const t=oT.exec(n);if(X(!!t),t[1]){let i=t[1];i=(i+"000000000").substr(0,9),e=Number(i)}const s=new Date(n);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:Me(n.seconds),nanos:Me(n.nanos)}}function Me(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function Hn(n){return typeof n=="string"?Je.fromBase64String(n):Je.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _u(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{}).__type__)===null||t===void 0?void 0:t.stringValue)==="server_timestamp"}function bu(n){const e=n.mapValue.fields.__previous_value__;return _u(e)?bu(e):e}function Mr(n){const e=mn(n.mapValue.fields.__local_write_time__.timestampValue);return new Ne(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aT{constructor(e,t,s,i,r,o,a,l,u){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=i,this.ssl=r,this.forceLongPolling=o,this.autoDetectLongPolling=a,this.longPollingOptions=l,this.useFetchStreams=u}}class Ss{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new Ss("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof Ss&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mn={mapValue:{fields:{__type__:{stringValue:"__max__"}}}},Zo={nullValue:"NULL_VALUE"};function ks(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?_u(n)?4:fg(n)?9007199254740991:10:G()}function Xt(n,e){if(n===e)return!0;const t=ks(n);if(t!==ks(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return Mr(n).isEqual(Mr(e));case 3:return function(i,r){if(typeof i.timestampValue=="string"&&typeof r.timestampValue=="string"&&i.timestampValue.length===r.timestampValue.length)return i.timestampValue===r.timestampValue;const o=mn(i.timestampValue),a=mn(r.timestampValue);return o.seconds===a.seconds&&o.nanos===a.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,r){return Hn(i.bytesValue).isEqual(Hn(r.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,r){return Me(i.geoPointValue.latitude)===Me(r.geoPointValue.latitude)&&Me(i.geoPointValue.longitude)===Me(r.geoPointValue.longitude)}(n,e);case 2:return function(i,r){if("integerValue"in i&&"integerValue"in r)return Me(i.integerValue)===Me(r.integerValue);if("doubleValue"in i&&"doubleValue"in r){const o=Me(i.doubleValue),a=Me(r.doubleValue);return o===a?Or(o)===Or(a):isNaN(o)&&isNaN(a)}return!1}(n,e);case 9:return fi(n.arrayValue.values||[],e.arrayValue.values||[],Xt);case 10:return function(i,r){const o=i.mapValue.fields||{},a=r.mapValue.fields||{};if(uf(o)!==uf(a))return!1;for(const l in o)if(o.hasOwnProperty(l)&&(a[l]===void 0||!Xt(o[l],a[l])))return!1;return!0}(n,e);default:return G()}}function Lr(n,e){return(n.values||[]).find(t=>Xt(t,e))!==void 0}function Qn(n,e){if(n===e)return 0;const t=ks(n),s=ks(e);if(t!==s)return ne(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return ne(n.booleanValue,e.booleanValue);case 2:return function(r,o){const a=Me(r.integerValue||r.doubleValue),l=Me(o.integerValue||o.doubleValue);return a<l?-1:a>l?1:a===l?0:isNaN(a)?isNaN(l)?0:-1:1}(n,e);case 3:return hf(n.timestampValue,e.timestampValue);case 4:return hf(Mr(n),Mr(e));case 5:return ne(n.stringValue,e.stringValue);case 6:return function(r,o){const a=Hn(r),l=Hn(o);return a.compareTo(l)}(n.bytesValue,e.bytesValue);case 7:return function(r,o){const a=r.split("/"),l=o.split("/");for(let u=0;u<a.length&&u<l.length;u++){const h=ne(a[u],l[u]);if(h!==0)return h}return ne(a.length,l.length)}(n.referenceValue,e.referenceValue);case 8:return function(r,o){const a=ne(Me(r.latitude),Me(o.latitude));return a!==0?a:ne(Me(r.longitude),Me(o.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return function(r,o){const a=r.values||[],l=o.values||[];for(let u=0;u<a.length&&u<l.length;++u){const h=Qn(a[u],l[u]);if(h)return h}return ne(a.length,l.length)}(n.arrayValue,e.arrayValue);case 10:return function(r,o){if(r===Mn.mapValue&&o===Mn.mapValue)return 0;if(r===Mn.mapValue)return 1;if(o===Mn.mapValue)return-1;const a=r.fields||{},l=Object.keys(a),u=o.fields||{},h=Object.keys(u);l.sort(),h.sort();for(let p=0;p<l.length&&p<h.length;++p){const m=ne(l[p],h[p]);if(m!==0)return m;const w=Qn(a[l[p]],u[h[p]]);if(w!==0)return w}return ne(l.length,h.length)}(n.mapValue,e.mapValue);default:throw G()}}function hf(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return ne(n,e);const t=mn(n),s=mn(e),i=ne(t.seconds,s.seconds);return i!==0?i:ne(t.nanos,s.nanos)}function pi(n){return El(n)}function El(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const s=mn(t);return`time(${s.seconds},${s.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return Hn(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return q.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let s="[",i=!0;for(const r of t.values||[])i?i=!1:s+=",",s+=El(r);return s+"]"}(n.arrayValue):"mapValue"in n?function(t){const s=Object.keys(t.fields||{}).sort();let i="{",r=!0;for(const o of s)r?r=!1:i+=",",i+=`${o}:${El(t.fields[o])}`;return i+"}"}(n.mapValue):G()}function Fr(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function Tl(n){return!!n&&"integerValue"in n}function Ur(n){return!!n&&"arrayValue"in n}function ff(n){return!!n&&"nullValue"in n}function pf(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function ea(n){return!!n&&"mapValue"in n}function br(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const e={mapValue:{fields:{}}};return xs(n.mapValue.fields,(t,s)=>e.mapValue.fields[t]=br(s)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=br(n.arrayValue.values[t]);return e}return Object.assign({},n)}function fg(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}function cT(n){return"nullValue"in n?Zo:"booleanValue"in n?{booleanValue:!1}:"integerValue"in n||"doubleValue"in n?{doubleValue:NaN}:"timestampValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in n?{stringValue:""}:"bytesValue"in n?{bytesValue:""}:"referenceValue"in n?Fr(Ss.empty(),q.empty()):"geoPointValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in n?{arrayValue:{}}:"mapValue"in n?{mapValue:{}}:G()}function lT(n){return"nullValue"in n?{booleanValue:!1}:"booleanValue"in n?{doubleValue:NaN}:"integerValue"in n||"doubleValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in n?{stringValue:""}:"stringValue"in n?{bytesValue:""}:"bytesValue"in n?Fr(Ss.empty(),q.empty()):"referenceValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in n?{arrayValue:{}}:"arrayValue"in n?{mapValue:{}}:"mapValue"in n?Mn:G()}function mf(n,e){const t=Qn(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?-1:!n.inclusive&&e.inclusive?1:0}function gf(n,e){const t=Qn(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?1:!n.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lt{constructor(e){this.value=e}static empty(){return new lt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!ea(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=br(t)}setAll(e){let t=Ve.emptyPath(),s={},i=[];e.forEach((o,a)=>{if(!t.isImmediateParentOf(a)){const l=this.getFieldsMap(t);this.applyChanges(l,s,i),s={},i=[],t=a.popLast()}o?s[a.lastSegment()]=br(o):i.push(a.lastSegment())});const r=this.getFieldsMap(t);this.applyChanges(r,s,i)}delete(e){const t=this.field(e.popLast());ea(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Xt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let i=t.mapValue.fields[e.get(s)];ea(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,s){xs(t,(i,r)=>e[i]=r);for(const i of s)delete e[i]}clone(){return new lt(br(this.value))}}function pg(n){const e=[];return xs(n.fields,(t,s)=>{const i=new Ve([t]);if(ea(s)){const r=pg(s.mapValue).fields;if(r.length===0)e.push(i);else for(const o of r)e.push(i.child(o))}else e.push(i)}),new Et(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(e,t,s,i,r,o,a){this.key=e,this.documentType=t,this.version=s,this.readTime=i,this.createTime=r,this.data=o,this.documentState=a}static newInvalidDocument(e){return new Le(e,0,Z.min(),Z.min(),Z.min(),lt.empty(),0)}static newFoundDocument(e,t,s,i){return new Le(e,1,t,Z.min(),s,i,0)}static newNoDocument(e,t){return new Le(e,2,t,Z.min(),Z.min(),lt.empty(),0)}static newUnknownDocument(e,t){return new Le(e,3,t,Z.min(),Z.min(),lt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(Z.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=lt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=lt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=Z.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Le&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Le(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mi{constructor(e,t){this.position=e,this.inclusive=t}}function yf(n,e,t){let s=0;for(let i=0;i<n.position.length;i++){const r=e[i],o=n.position[i];if(r.field.isKeyField()?s=q.comparator(q.fromName(o.referenceValue),t.key):s=Qn(o,t.data.field(r.field)),r.dir==="desc"&&(s*=-1),s!==0)break}return s}function vf(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!Xt(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qr{constructor(e,t="asc"){this.field=e,this.dir=t}}function uT(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mg{}class le extends mg{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new dT(e,t,s):t==="array-contains"?new pT(e,s):t==="in"?new wg(e,s):t==="not-in"?new mT(e,s):t==="array-contains-any"?new gT(e,s):new le(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new hT(e,s):new fT(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&this.matchesComparison(Qn(t,this.value)):t!==null&&ks(this.value)===ks(t)&&this.matchesComparison(Qn(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return G()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Ie extends mg{constructor(e,t){super(),this.filters=e,this.op=t,this.ae=null}static create(e,t){return new Ie(e,t)}matches(e){return gi(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.ae!==null||(this.ae=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ae}getFilters(){return Object.assign([],this.filters)}}function gi(n){return n.op==="and"}function Al(n){return n.op==="or"}function wu(n){return gg(n)&&gi(n)}function gg(n){for(const e of n.filters)if(e instanceof Ie)return!1;return!0}function Sl(n){if(n instanceof le)return n.field.canonicalString()+n.op.toString()+pi(n.value);if(wu(n))return n.filters.map(e=>Sl(e)).join(",");{const e=n.filters.map(t=>Sl(t)).join(",");return`${n.op}(${e})`}}function yg(n,e){return n instanceof le?function(s,i){return i instanceof le&&s.op===i.op&&s.field.isEqual(i.field)&&Xt(s.value,i.value)}(n,e):n instanceof Ie?function(s,i){return i instanceof Ie&&s.op===i.op&&s.filters.length===i.filters.length?s.filters.reduce((r,o,a)=>r&&yg(o,i.filters[a]),!0):!1}(n,e):void G()}function vg(n,e){const t=n.filters.concat(e);return Ie.create(t,n.op)}function _g(n){return n instanceof le?function(t){return`${t.field.canonicalString()} ${t.op} ${pi(t.value)}`}(n):n instanceof Ie?function(t){return t.op.toString()+" {"+t.getFilters().map(_g).join(" ,")+"}"}(n):"Filter"}class dT extends le{constructor(e,t,s){super(e,t,s),this.key=q.fromName(s.referenceValue)}matches(e){const t=q.comparator(e.key,this.key);return this.matchesComparison(t)}}class hT extends le{constructor(e,t){super(e,"in",t),this.keys=bg("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class fT extends le{constructor(e,t){super(e,"not-in",t),this.keys=bg("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function bg(n,e){var t;return(((t=e.arrayValue)===null||t===void 0?void 0:t.values)||[]).map(s=>q.fromName(s.referenceValue))}class pT extends le{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return Ur(t)&&Lr(t.arrayValue,this.value)}}class wg extends le{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Lr(this.value.arrayValue,t)}}class mT extends le{constructor(e,t){super(e,"not-in",t)}matches(e){if(Lr(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&!Lr(this.value.arrayValue,t)}}class gT extends le{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!Ur(t)||!t.arrayValue.values)&&t.arrayValue.values.some(s=>Lr(this.value.arrayValue,s))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yT{constructor(e,t=null,s=[],i=[],r=null,o=null,a=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=i,this.limit=r,this.startAt=o,this.endAt=a,this.ue=null}}function kl(n,e=null,t=[],s=[],i=null,r=null,o=null){return new yT(n,e,t,s,i,r,o)}function Rs(n){const e=W(n);if(e.ue===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(s=>Sl(s)).join(","),t+="|ob:",t+=e.orderBy.map(s=>function(r){return r.field.canonicalString()+r.dir}(s)).join(","),Qa(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(s=>pi(s)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(s=>pi(s)).join(",")),e.ue=t}return e.ue}function io(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!uT(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!yg(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!vf(n.startAt,e.startAt)&&vf(n.endAt,e.endAt)}function ya(n){return q.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function va(n,e){return n.filters.filter(t=>t instanceof le&&t.field.isEqual(e))}function _f(n,e,t){let s=Zo,i=!0;for(const r of va(n,e)){let o=Zo,a=!0;switch(r.op){case"<":case"<=":o=cT(r.value);break;case"==":case"in":case">=":o=r.value;break;case">":o=r.value,a=!1;break;case"!=":case"not-in":o=Zo}mf({value:s,inclusive:i},{value:o,inclusive:a})<0&&(s=o,i=a)}if(t!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(e)){const o=t.position[r];mf({value:s,inclusive:i},{value:o,inclusive:t.inclusive})<0&&(s=o,i=t.inclusive);break}}return{value:s,inclusive:i}}function bf(n,e,t){let s=Mn,i=!0;for(const r of va(n,e)){let o=Mn,a=!0;switch(r.op){case">=":case">":o=lT(r.value),a=!1;break;case"==":case"in":case"<=":o=r.value;break;case"<":o=r.value,a=!1;break;case"!=":case"not-in":o=Mn}gf({value:s,inclusive:i},{value:o,inclusive:a})>0&&(s=o,i=a)}if(t!==null){for(let r=0;r<n.orderBy.length;++r)if(n.orderBy[r].field.isEqual(e)){const o=t.position[r];gf({value:s,inclusive:i},{value:o,inclusive:t.inclusive})>0&&(s=o,i=t.inclusive);break}}return{value:s,inclusive:i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xi{constructor(e,t=null,s=[],i=[],r=null,o="F",a=null,l=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=i,this.limit=r,this.limitType=o,this.startAt=a,this.endAt=l,this.ce=null,this.le=null,this.he=null,this.startAt,this.endAt}}function Ig(n,e,t,s,i,r,o,a){return new xi(n,e,t,s,i,r,o,a)}function Ja(n){return new xi(n)}function wf(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function Eg(n){return n.collectionGroup!==null}function wr(n){const e=W(n);if(e.ce===null){e.ce=[];const t=new Set;for(const r of e.explicitOrderBy)e.ce.push(r),t.add(r.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let a=new Ee(Ve.comparator);return o.filters.forEach(l=>{l.getFlattenedFilters().forEach(u=>{u.isInequality()&&(a=a.add(u.field))})}),a})(e).forEach(r=>{t.has(r.canonicalString())||r.isKeyField()||e.ce.push(new qr(r,s))}),t.has(Ve.keyField().canonicalString())||e.ce.push(new qr(Ve.keyField(),s))}return e.ce}function St(n){const e=W(n);return e.le||(e.le=vT(e,wr(n))),e.le}function vT(n,e){if(n.limitType==="F")return kl(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(i=>{const r=i.dir==="desc"?"asc":"desc";return new qr(i.field,r)});const t=n.endAt?new mi(n.endAt.position,n.endAt.inclusive):null,s=n.startAt?new mi(n.startAt.position,n.startAt.inclusive):null;return kl(n.path,n.collectionGroup,e,n.filters,n.limit,t,s)}}function Rl(n,e){const t=n.filters.concat([e]);return new xi(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function _a(n,e,t){return new xi(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function Ya(n,e){return io(St(n),St(e))&&n.limitType===e.limitType}function Tg(n){return`${Rs(St(n))}|lt:${n.limitType}`}function Xs(n){return`Query(target=${function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map(i=>_g(i)).join(", ")}]`),Qa(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map(i=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(i)).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map(i=>pi(i)).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map(i=>pi(i)).join(",")),`Target(${s})`}(St(n))}; limitType=${n.limitType})`}function ro(n,e){return e.isFoundDocument()&&function(s,i){const r=i.key.path;return s.collectionGroup!==null?i.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(r):q.isDocumentKey(s.path)?s.path.isEqual(r):s.path.isImmediateParentOf(r)}(n,e)&&function(s,i){for(const r of wr(s))if(!r.field.isKeyField()&&i.data.field(r.field)===null)return!1;return!0}(n,e)&&function(s,i){for(const r of s.filters)if(!r.matches(i))return!1;return!0}(n,e)&&function(s,i){return!(s.startAt&&!function(o,a,l){const u=yf(o,a,l);return o.inclusive?u<=0:u<0}(s.startAt,wr(s),i)||s.endAt&&!function(o,a,l){const u=yf(o,a,l);return o.inclusive?u>=0:u>0}(s.endAt,wr(s),i))}(n,e)}function Ag(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Sg(n){return(e,t)=>{let s=!1;for(const i of wr(n)){const r=_T(i,e,t);if(r!==0)return r;s=s||i.field.isKeyField()}return 0}}function _T(n,e,t){const s=n.field.isKeyField()?q.comparator(e.key,t.key):function(r,o,a){const l=o.data.field(r),u=a.data.field(r);return l!==null&&u!==null?Qn(l,u):G()}(n.field,e,t);switch(n.dir){case"asc":return s;case"desc":return-1*s;default:return G()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ts{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[i,r]of s)if(this.equalsFn(i,e))return r}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),i=this.inner[s];if(i===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let r=0;r<i.length;r++)if(this.equalsFn(i[r][0],e))return void(i[r]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return s.length===1?delete this.inner[t]:s.splice(i,1),this.innerSize--,!0;return!1}forEach(e){xs(this.inner,(t,s)=>{for(const[i,r]of s)e(i,r)})}isEmpty(){return dg(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bT=new Se(q.comparator);function At(){return bT}const kg=new Se(q.comparator);function pr(...n){let e=kg;for(const t of n)e=e.insert(t.key,t);return e}function Rg(n){let e=kg;return n.forEach((t,s)=>e=e.insert(t,s.overlayedDocument)),e}function Gt(){return Ir()}function Pg(){return Ir()}function Ir(){return new ts(n=>n.toString(),(n,e)=>n.isEqual(e))}const wT=new Se(q.comparator),IT=new Ee(q.comparator);function re(...n){let e=IT;for(const t of n)e=e.add(t);return e}const ET=new Ee(ne);function Iu(){return ET}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cg(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Or(e)?"-0":e}}function Dg(n){return{integerValue:""+n}}function TT(n,e){return rg(e)?Dg(e):Cg(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xa{constructor(){this._=void 0}}function AT(n,e,t){return n instanceof Br?function(i,r){const o={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return r&&_u(r)&&(r=bu(r)),r&&(o.fields.__previous_value__=r),{mapValue:o}}(t,e):n instanceof yi?Vg(n,e):n instanceof vi?Ng(n,e):function(i,r){const o=$g(i,r),a=If(o)+If(i.Pe);return Tl(o)&&Tl(i.Pe)?Dg(a):Cg(i.serializer,a)}(n,e)}function ST(n,e,t){return n instanceof yi?Vg(n,e):n instanceof vi?Ng(n,e):t}function $g(n,e){return n instanceof jr?function(s){return Tl(s)||function(r){return!!r&&"doubleValue"in r}(s)}(e)?e:{integerValue:0}:null}class Br extends Xa{}class yi extends Xa{constructor(e){super(),this.elements=e}}function Vg(n,e){const t=xg(e);for(const s of n.elements)t.some(i=>Xt(i,s))||t.push(s);return{arrayValue:{values:t}}}class vi extends Xa{constructor(e){super(),this.elements=e}}function Ng(n,e){let t=xg(e);for(const s of n.elements)t=t.filter(i=>!Xt(i,s));return{arrayValue:{values:t}}}class jr extends Xa{constructor(e,t){super(),this.serializer=e,this.Pe=t}}function If(n){return Me(n.integerValue||n.doubleValue)}function xg(n){return Ur(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kT{constructor(e,t){this.field=e,this.transform=t}}function RT(n,e){return n.field.isEqual(e.field)&&function(s,i){return s instanceof yi&&i instanceof yi||s instanceof vi&&i instanceof vi?fi(s.elements,i.elements,Xt):s instanceof jr&&i instanceof jr?Xt(s.Pe,i.Pe):s instanceof Br&&i instanceof Br}(n.transform,e.transform)}class PT{constructor(e,t){this.version=e,this.transformResults=t}}class pt{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new pt}static exists(e){return new pt(void 0,e)}static updateTime(e){return new pt(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function ta(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class Za{}function Og(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new ec(n.key,pt.none()):new Oi(n.key,n.data,pt.none());{const t=n.data,s=lt.empty();let i=new Ee(Ve.comparator);for(let r of e.fields)if(!i.has(r)){let o=t.field(r);o===null&&r.length>1&&(r=r.popLast(),o=t.field(r)),o===null?s.delete(r):s.set(r,o),i=i.add(r)}return new vn(n.key,s,new Et(i.toArray()),pt.none())}}function CT(n,e,t){n instanceof Oi?function(i,r,o){const a=i.value.clone(),l=Tf(i.fieldTransforms,r,o.transformResults);a.setAll(l),r.convertToFoundDocument(o.version,a).setHasCommittedMutations()}(n,e,t):n instanceof vn?function(i,r,o){if(!ta(i.precondition,r))return void r.convertToUnknownDocument(o.version);const a=Tf(i.fieldTransforms,r,o.transformResults),l=r.data;l.setAll(Mg(i)),l.setAll(a),r.convertToFoundDocument(o.version,l).setHasCommittedMutations()}(n,e,t):function(i,r,o){r.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,t)}function Er(n,e,t,s){return n instanceof Oi?function(r,o,a,l){if(!ta(r.precondition,o))return a;const u=r.value.clone(),h=Af(r.fieldTransforms,l,o);return u.setAll(h),o.convertToFoundDocument(o.version,u).setHasLocalMutations(),null}(n,e,t,s):n instanceof vn?function(r,o,a,l){if(!ta(r.precondition,o))return a;const u=Af(r.fieldTransforms,l,o),h=o.data;return h.setAll(Mg(r)),h.setAll(u),o.convertToFoundDocument(o.version,h).setHasLocalMutations(),a===null?null:a.unionWith(r.fieldMask.fields).unionWith(r.fieldTransforms.map(p=>p.field))}(n,e,t,s):function(r,o,a){return ta(r.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):a}(n,e,t)}function DT(n,e){let t=null;for(const s of n.fieldTransforms){const i=e.data.field(s.field),r=$g(s.transform,i||null);r!=null&&(t===null&&(t=lt.empty()),t.set(s.field,r))}return t||null}function Ef(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(s,i){return s===void 0&&i===void 0||!(!s||!i)&&fi(s,i,(r,o)=>RT(r,o))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Oi extends Za{constructor(e,t,s,i=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class vn extends Za{constructor(e,t,s,i,r=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=i,this.fieldTransforms=r,this.type=1}getFieldMask(){return this.fieldMask}}function Mg(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const s=n.data.field(t);e.set(t,s)}}),e}function Tf(n,e,t){const s=new Map;X(n.length===t.length);for(let i=0;i<t.length;i++){const r=n[i],o=r.transform,a=e.data.field(r.field);s.set(r.field,ST(o,a,t[i]))}return s}function Af(n,e,t){const s=new Map;for(const i of n){const r=i.transform,o=t.data.field(i.field);s.set(i.field,AT(r,o,e))}return s}class ec extends Za{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Lg extends Za{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Eu{constructor(e,t,s,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=i}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let i=0;i<this.mutations.length;i++){const r=this.mutations[i];r.key.isEqual(e.key)&&CT(r,e,s[i])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=Er(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=Er(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=Pg();return this.mutations.forEach(i=>{const r=e.get(i.key),o=r.overlayedDocument;let a=this.applyToLocalView(o,r.mutatedFields);a=t.has(i.key)?null:a;const l=Og(o,a);l!==null&&s.set(i.key,l),o.isValidDocument()||o.convertToNoDocument(Z.min())}),s}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),re())}isEqual(e){return this.batchId===e.batchId&&fi(this.mutations,e.mutations,(t,s)=>Ef(t,s))&&fi(this.baseMutations,e.baseMutations,(t,s)=>Ef(t,s))}}class Tu{constructor(e,t,s,i){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=i}static from(e,t,s){X(e.mutations.length===s.length);let i=function(){return wT}();const r=e.mutations;for(let o=0;o<r.length;o++)i=i.insert(r[o].key,s[o].version);return new Tu(e,t,s,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Au{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $T{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var qe,he;function VT(n){switch(n){default:return G();case V.CANCELLED:case V.UNKNOWN:case V.DEADLINE_EXCEEDED:case V.RESOURCE_EXHAUSTED:case V.INTERNAL:case V.UNAVAILABLE:case V.UNAUTHENTICATED:return!1;case V.INVALID_ARGUMENT:case V.NOT_FOUND:case V.ALREADY_EXISTS:case V.PERMISSION_DENIED:case V.FAILED_PRECONDITION:case V.ABORTED:case V.OUT_OF_RANGE:case V.UNIMPLEMENTED:case V.DATA_LOSS:return!0}}function Fg(n){if(n===void 0)return Fe("GRPC error has no .code"),V.UNKNOWN;switch(n){case qe.OK:return V.OK;case qe.CANCELLED:return V.CANCELLED;case qe.UNKNOWN:return V.UNKNOWN;case qe.DEADLINE_EXCEEDED:return V.DEADLINE_EXCEEDED;case qe.RESOURCE_EXHAUSTED:return V.RESOURCE_EXHAUSTED;case qe.INTERNAL:return V.INTERNAL;case qe.UNAVAILABLE:return V.UNAVAILABLE;case qe.UNAUTHENTICATED:return V.UNAUTHENTICATED;case qe.INVALID_ARGUMENT:return V.INVALID_ARGUMENT;case qe.NOT_FOUND:return V.NOT_FOUND;case qe.ALREADY_EXISTS:return V.ALREADY_EXISTS;case qe.PERMISSION_DENIED:return V.PERMISSION_DENIED;case qe.FAILED_PRECONDITION:return V.FAILED_PRECONDITION;case qe.ABORTED:return V.ABORTED;case qe.OUT_OF_RANGE:return V.OUT_OF_RANGE;case qe.UNIMPLEMENTED:return V.UNIMPLEMENTED;case qe.DATA_LOSS:return V.DATA_LOSS;default:return G()}}(he=qe||(qe={}))[he.OK=0]="OK",he[he.CANCELLED=1]="CANCELLED",he[he.UNKNOWN=2]="UNKNOWN",he[he.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",he[he.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",he[he.NOT_FOUND=5]="NOT_FOUND",he[he.ALREADY_EXISTS=6]="ALREADY_EXISTS",he[he.PERMISSION_DENIED=7]="PERMISSION_DENIED",he[he.UNAUTHENTICATED=16]="UNAUTHENTICATED",he[he.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",he[he.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",he[he.ABORTED=10]="ABORTED",he[he.OUT_OF_RANGE=11]="OUT_OF_RANGE",he[he.UNIMPLEMENTED=12]="UNIMPLEMENTED",he[he.INTERNAL=13]="INTERNAL",he[he.UNAVAILABLE=14]="UNAVAILABLE",he[he.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function NT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xT=new vs([4294967295,4294967295],0);function Sf(n){const e=NT().encode(n),t=new Gm;return t.update(e),new Uint8Array(t.digest())}function kf(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),i=e.getUint32(8,!0),r=e.getUint32(12,!0);return[new vs([t,s],0),new vs([i,r],0)]}class Su{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new mr(`Invalid padding: ${t}`);if(s<0)throw new mr(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new mr(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new mr(`Invalid padding when bitmap length is 0: ${t}`);this.Ie=8*e.length-t,this.Te=vs.fromNumber(this.Ie)}Ee(e,t,s){let i=e.add(t.multiply(vs.fromNumber(s)));return i.compare(xT)===1&&(i=new vs([i.getBits(0),i.getBits(1)],0)),i.modulo(this.Te).toNumber()}de(e){return(this.bitmap[Math.floor(e/8)]&1<<e%8)!=0}mightContain(e){if(this.Ie===0)return!1;const t=Sf(e),[s,i]=kf(t);for(let r=0;r<this.hashCount;r++){const o=this.Ee(s,i,r);if(!this.de(o))return!1}return!0}static create(e,t,s){const i=e%8==0?0:8-e%8,r=new Uint8Array(Math.ceil(e/8)),o=new Su(r,i,t);return s.forEach(a=>o.insert(a)),o}insert(e){if(this.Ie===0)return;const t=Sf(e),[s,i]=kf(t);for(let r=0;r<this.hashCount;r++){const o=this.Ee(s,i,r);this.Ae(o)}}Ae(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class mr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oo{constructor(e,t,s,i,r){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=i,this.resolvedLimboDocuments=r}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const i=new Map;return i.set(e,ao.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new oo(Z.min(),i,new Se(ne),At(),re())}}class ao{constructor(e,t,s,i,r){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=i,this.removedDocuments=r}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new ao(s,t,re(),re(),re())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class na{constructor(e,t,s,i){this.Re=e,this.removedTargetIds=t,this.key=s,this.Ve=i}}class Ug{constructor(e,t){this.targetId=e,this.me=t}}class qg{constructor(e,t,s=Je.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=i}}class Rf{constructor(){this.fe=0,this.ge=Cf(),this.pe=Je.EMPTY_BYTE_STRING,this.ye=!1,this.we=!0}get current(){return this.ye}get resumeToken(){return this.pe}get Se(){return this.fe!==0}get be(){return this.we}De(e){e.approximateByteSize()>0&&(this.we=!0,this.pe=e)}Ce(){let e=re(),t=re(),s=re();return this.ge.forEach((i,r)=>{switch(r){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:s=s.add(i);break;default:G()}}),new ao(this.pe,this.ye,e,t,s)}ve(){this.we=!1,this.ge=Cf()}Fe(e,t){this.we=!0,this.ge=this.ge.insert(e,t)}Me(e){this.we=!0,this.ge=this.ge.remove(e)}xe(){this.fe+=1}Oe(){this.fe-=1,X(this.fe>=0)}Ne(){this.we=!0,this.ye=!0}}class OT{constructor(e){this.Le=e,this.Be=new Map,this.ke=At(),this.qe=Pf(),this.Qe=new Se(ne)}Ke(e){for(const t of e.Re)e.Ve&&e.Ve.isFoundDocument()?this.$e(t,e.Ve):this.Ue(t,e.key,e.Ve);for(const t of e.removedTargetIds)this.Ue(t,e.key,e.Ve)}We(e){this.forEachTarget(e,t=>{const s=this.Ge(t);switch(e.state){case 0:this.ze(t)&&s.De(e.resumeToken);break;case 1:s.Oe(),s.Se||s.ve(),s.De(e.resumeToken);break;case 2:s.Oe(),s.Se||this.removeTarget(t);break;case 3:this.ze(t)&&(s.Ne(),s.De(e.resumeToken));break;case 4:this.ze(t)&&(this.je(t),s.De(e.resumeToken));break;default:G()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.Be.forEach((s,i)=>{this.ze(i)&&t(i)})}He(e){const t=e.targetId,s=e.me.count,i=this.Je(t);if(i){const r=i.target;if(ya(r))if(s===0){const o=new q(r.path);this.Ue(t,o,Le.newNoDocument(o,Z.min()))}else X(s===1);else{const o=this.Ye(t);if(o!==s){const a=this.Ze(e),l=a?this.Xe(a,e,o):1;if(l!==0){this.je(t);const u=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Qe=this.Qe.insert(t,u)}}}}}Ze(e){const t=e.me.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:i=0},hashCount:r=0}=t;let o,a;try{o=Hn(s).toUint8Array()}catch(l){if(l instanceof hg)return Vr("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{a=new Su(o,i,r)}catch(l){return Vr(l instanceof mr?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return a.Ie===0?null:a}Xe(e,t,s){return t.me.count===s-this.nt(e,t.targetId)?0:2}nt(e,t){const s=this.Le.getRemoteKeysForTarget(t);let i=0;return s.forEach(r=>{const o=this.Le.tt(),a=`projects/${o.projectId}/databases/${o.database}/documents/${r.path.canonicalString()}`;e.mightContain(a)||(this.Ue(t,r,null),i++)}),i}rt(e){const t=new Map;this.Be.forEach((r,o)=>{const a=this.Je(o);if(a){if(r.current&&ya(a.target)){const l=new q(a.target.path);this.ke.get(l)!==null||this.it(o,l)||this.Ue(o,l,Le.newNoDocument(l,e))}r.be&&(t.set(o,r.Ce()),r.ve())}});let s=re();this.qe.forEach((r,o)=>{let a=!0;o.forEachWhile(l=>{const u=this.Je(l);return!u||u.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)}),a&&(s=s.add(r))}),this.ke.forEach((r,o)=>o.setReadTime(e));const i=new oo(e,t,this.Qe,this.ke,s);return this.ke=At(),this.qe=Pf(),this.Qe=new Se(ne),i}$e(e,t){if(!this.ze(e))return;const s=this.it(e,t.key)?2:0;this.Ge(e).Fe(t.key,s),this.ke=this.ke.insert(t.key,t),this.qe=this.qe.insert(t.key,this.st(t.key).add(e))}Ue(e,t,s){if(!this.ze(e))return;const i=this.Ge(e);this.it(e,t)?i.Fe(t,1):i.Me(t),this.qe=this.qe.insert(t,this.st(t).delete(e)),s&&(this.ke=this.ke.insert(t,s))}removeTarget(e){this.Be.delete(e)}Ye(e){const t=this.Ge(e).Ce();return this.Le.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}xe(e){this.Ge(e).xe()}Ge(e){let t=this.Be.get(e);return t||(t=new Rf,this.Be.set(e,t)),t}st(e){let t=this.qe.get(e);return t||(t=new Ee(ne),this.qe=this.qe.insert(e,t)),t}ze(e){const t=this.Je(e)!==null;return t||N("WatchChangeAggregator","Detected inactive target",e),t}Je(e){const t=this.Be.get(e);return t&&t.Se?null:this.Le.ot(e)}je(e){this.Be.set(e,new Rf),this.Le.getRemoteKeysForTarget(e).forEach(t=>{this.Ue(e,t,null)})}it(e,t){return this.Le.getRemoteKeysForTarget(e).has(t)}}function Pf(){return new Se(q.comparator)}function Cf(){return new Se(q.comparator)}const MT={asc:"ASCENDING",desc:"DESCENDING"},LT={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},FT={and:"AND",or:"OR"};class UT{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Pl(n,e){return n.useProto3Json||Qa(e)?e:{value:e}}function _i(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Bg(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function qT(n,e){return _i(n,e.toTimestamp())}function gt(n){return X(!!n),Z.fromTimestamp(function(t){const s=mn(t);return new Ne(s.seconds,s.nanos)}(n))}function ku(n,e){return Cl(n,e).canonicalString()}function Cl(n,e){const t=function(i){return new be(["projects",i.projectId,"databases",i.database])}(n).child("documents");return e===void 0?t:t.child(e)}function jg(n){const e=be.fromString(n);return X(Xg(e)),e}function ba(n,e){return ku(n.databaseId,e.path)}function _s(n,e){const t=jg(e);if(t.get(1)!==n.databaseId.projectId)throw new F(V.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new F(V.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new q(Kg(t))}function zg(n,e){return ku(n.databaseId,e)}function Gg(n){const e=jg(n);return e.length===4?be.emptyPath():Kg(e)}function Dl(n){return new be(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function Kg(n){return X(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function Df(n,e,t){return{name:ba(n,e),fields:t.value.mapValue.fields}}function BT(n,e,t){const s=_s(n,e.name),i=gt(e.updateTime),r=e.createTime?gt(e.createTime):Z.min(),o=new lt({mapValue:{fields:e.fields}}),a=Le.newFoundDocument(s,i,r,o);return t&&a.setHasCommittedMutations(),t?a.setHasCommittedMutations():a}function jT(n,e){let t;if("targetChange"in e){e.targetChange;const s=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:G()}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],r=function(u,h){return u.useProto3Json?(X(h===void 0||typeof h=="string"),Je.fromBase64String(h||"")):(X(h===void 0||h instanceof Buffer||h instanceof Uint8Array),Je.fromUint8Array(h||new Uint8Array))}(n,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&function(u){const h=u.code===void 0?V.UNKNOWN:Fg(u.code);return new F(h,u.message||"")}(o);t=new qg(s,i,r,a||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const i=_s(n,s.document.name),r=gt(s.document.updateTime),o=s.document.createTime?gt(s.document.createTime):Z.min(),a=new lt({mapValue:{fields:s.document.fields}}),l=Le.newFoundDocument(i,r,o,a),u=s.targetIds||[],h=s.removedTargetIds||[];t=new na(u,h,l.key,l)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const i=_s(n,s.document),r=s.readTime?gt(s.readTime):Z.min(),o=Le.newNoDocument(i,r),a=s.removedTargetIds||[];t=new na([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const i=_s(n,s.document),r=s.removedTargetIds||[];t=new na([],r,i,null)}else{if(!("filter"in e))return G();{e.filter;const s=e.filter;s.targetId;const{count:i=0,unchangedNames:r}=s,o=new $T(i,r),a=s.targetId;t=new Ug(a,o)}}return t}function wa(n,e){let t;if(e instanceof Oi)t={update:Df(n,e.key,e.value)};else if(e instanceof ec)t={delete:ba(n,e.key)};else if(e instanceof vn)t={update:Df(n,e.key,e.data),updateMask:QT(e.fieldMask)};else{if(!(e instanceof Lg))return G();t={verify:ba(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(s=>function(r,o){const a=o.transform;if(a instanceof Br)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(a instanceof yi)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:a.elements}};if(a instanceof vi)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:a.elements}};if(a instanceof jr)return{fieldPath:o.field.canonicalString(),increment:a.Pe};throw G()}(0,s))),e.precondition.isNone||(t.currentDocument=function(i,r){return r.updateTime!==void 0?{updateTime:qT(i,r.updateTime)}:r.exists!==void 0?{exists:r.exists}:G()}(n,e.precondition)),t}function $l(n,e){const t=e.currentDocument?function(r){return r.updateTime!==void 0?pt.updateTime(gt(r.updateTime)):r.exists!==void 0?pt.exists(r.exists):pt.none()}(e.currentDocument):pt.none(),s=e.updateTransforms?e.updateTransforms.map(i=>function(o,a){let l=null;if("setToServerValue"in a)X(a.setToServerValue==="REQUEST_TIME"),l=new Br;else if("appendMissingElements"in a){const h=a.appendMissingElements.values||[];l=new yi(h)}else if("removeAllFromArray"in a){const h=a.removeAllFromArray.values||[];l=new vi(h)}else"increment"in a?l=new jr(o,a.increment):G();const u=Ve.fromServerFormat(a.fieldPath);return new kT(u,l)}(n,i)):[];if(e.update){e.update.name;const i=_s(n,e.update.name),r=new lt({mapValue:{fields:e.update.fields}});if(e.updateMask){const o=function(l){const u=l.fieldPaths||[];return new Et(u.map(h=>Ve.fromServerFormat(h)))}(e.updateMask);return new vn(i,r,o,t,s)}return new Oi(i,r,t,s)}if(e.delete){const i=_s(n,e.delete);return new ec(i,t)}if(e.verify){const i=_s(n,e.verify);return new Lg(i,t)}return G()}function zT(n,e){return n&&n.length>0?(X(e!==void 0),n.map(t=>function(i,r){let o=i.updateTime?gt(i.updateTime):gt(r);return o.isEqual(Z.min())&&(o=gt(r)),new PT(o,i.transformResults||[])}(t,e))):[]}function Wg(n,e){return{documents:[zg(n,e.path)]}}function Hg(n,e){const t={structuredQuery:{}},s=e.path;let i;e.collectionGroup!==null?(i=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(i=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=zg(n,i);const r=function(u){if(u.length!==0)return Yg(Ie.create(u,"and"))}(e.filters);r&&(t.structuredQuery.where=r);const o=function(u){if(u.length!==0)return u.map(h=>function(m){return{field:Zs(m.field),direction:KT(m.dir)}}(h))}(e.orderBy);o&&(t.structuredQuery.orderBy=o);const a=Pl(n,e.limit);return a!==null&&(t.structuredQuery.limit=a),e.startAt&&(t.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(e.endAt)),{_t:t,parent:i}}function Qg(n){let e=Gg(n.parent);const t=n.structuredQuery,s=t.from?t.from.length:0;let i=null;if(s>0){X(s===1);const h=t.from[0];h.allDescendants?i=h.collectionId:e=e.child(h.collectionId)}let r=[];t.where&&(r=function(p){const m=Jg(p);return m instanceof Ie&&wu(m)?m.getFilters():[m]}(t.where));let o=[];t.orderBy&&(o=function(p){return p.map(m=>function(E){return new qr(ei(E.field),function(R){switch(R){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(E.direction))}(m))}(t.orderBy));let a=null;t.limit&&(a=function(p){let m;return m=typeof p=="object"?p.value:p,Qa(m)?null:m}(t.limit));let l=null;t.startAt&&(l=function(p){const m=!!p.before,w=p.values||[];return new mi(w,m)}(t.startAt));let u=null;return t.endAt&&(u=function(p){const m=!p.before,w=p.values||[];return new mi(w,m)}(t.endAt)),Ig(e,i,o,r,a,"F",l,u)}function GT(n,e){const t=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return G()}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function Jg(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=ei(t.unaryFilter.field);return le.create(s,"==",{doubleValue:NaN});case"IS_NULL":const i=ei(t.unaryFilter.field);return le.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const r=ei(t.unaryFilter.field);return le.create(r,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=ei(t.unaryFilter.field);return le.create(o,"!=",{nullValue:"NULL_VALUE"});default:return G()}}(n):n.fieldFilter!==void 0?function(t){return le.create(ei(t.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return G()}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Ie.create(t.compositeFilter.filters.map(s=>Jg(s)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return G()}}(t.compositeFilter.op))}(n):G()}function KT(n){return MT[n]}function WT(n){return LT[n]}function HT(n){return FT[n]}function Zs(n){return{fieldPath:n.canonicalString()}}function ei(n){return Ve.fromServerFormat(n.fieldPath)}function Yg(n){return n instanceof le?function(t){if(t.op==="=="){if(pf(t.value))return{unaryFilter:{field:Zs(t.field),op:"IS_NAN"}};if(ff(t.value))return{unaryFilter:{field:Zs(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(pf(t.value))return{unaryFilter:{field:Zs(t.field),op:"IS_NOT_NAN"}};if(ff(t.value))return{unaryFilter:{field:Zs(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Zs(t.field),op:WT(t.op),value:t.value}}}(n):n instanceof Ie?function(t){const s=t.getFilters().map(i=>Yg(i));return s.length===1?s[0]:{compositeFilter:{op:HT(t.op),filters:s}}}(n):G()}function QT(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Xg(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dn{constructor(e,t,s,i,r=Z.min(),o=Z.min(),a=Je.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=i,this.snapshotVersion=r,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=l}withSequenceNumber(e){return new dn(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new dn(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new dn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new dn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zg{constructor(e){this.ct=e}}function JT(n,e){let t;if(e.document)t=BT(n.ct,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const s=q.fromSegments(e.noDocument.path),i=Cs(e.noDocument.readTime);t=Le.newNoDocument(s,i),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return G();{const s=q.fromSegments(e.unknownDocument.path),i=Cs(e.unknownDocument.version);t=Le.newUnknownDocument(s,i)}}return e.readTime&&t.setReadTime(function(i){const r=new Ne(i[0],i[1]);return Z.fromTimestamp(r)}(e.readTime)),t}function $f(n,e){const t=e.key,s={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:Ia(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())s.document=function(r,o){return{name:ba(r,o.key),fields:o.data.value.mapValue.fields,updateTime:_i(r,o.version.toTimestamp()),createTime:_i(r,o.createTime.toTimestamp())}}(n.ct,e);else if(e.isNoDocument())s.noDocument={path:t.path.toArray(),readTime:Ps(e.version)};else{if(!e.isUnknownDocument())return G();s.unknownDocument={path:t.path.toArray(),version:Ps(e.version)}}return s}function Ia(n){const e=n.toTimestamp();return[e.seconds,e.nanoseconds]}function Ps(n){const e=n.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function Cs(n){const e=new Ne(n.seconds,n.nanoseconds);return Z.fromTimestamp(e)}function hs(n,e){const t=(e.baseMutations||[]).map(r=>$l(n.ct,r));for(let r=0;r<e.mutations.length-1;++r){const o=e.mutations[r];if(r+1<e.mutations.length&&e.mutations[r+1].transform!==void 0){const a=e.mutations[r+1];o.updateTransforms=a.transform.fieldTransforms,e.mutations.splice(r+1,1),++r}}const s=e.mutations.map(r=>$l(n.ct,r)),i=Ne.fromMillis(e.localWriteTimeMs);return new Eu(e.batchId,i,t,s)}function gr(n){const e=Cs(n.readTime),t=n.lastLimboFreeSnapshotVersion!==void 0?Cs(n.lastLimboFreeSnapshotVersion):Z.min();let s;return s=function(r){return r.documents!==void 0}(n.query)?function(r){return X(r.documents.length===1),St(Ja(Gg(r.documents[0])))}(n.query):function(r){return St(Qg(r))}(n.query),new dn(s,n.targetId,"TargetPurposeListen",n.lastListenSequenceNumber,e,t,Je.fromBase64String(n.resumeToken))}function ey(n,e){const t=Ps(e.snapshotVersion),s=Ps(e.lastLimboFreeSnapshotVersion);let i;i=ya(e.target)?Wg(n.ct,e.target):Hg(n.ct,e.target)._t;const r=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:Rs(e.target),readTime:t,resumeToken:r,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:s,query:i}}function ty(n){const e=Qg({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?_a(e,e.limit,"L"):e}function Jc(n,e){return new Au(e.largestBatchId,$l(n.ct,e.overlayMutation))}function Vf(n,e){const t=e.path.lastSegment();return[n,mt(e.path.popLast()),t]}function Nf(n,e,t,s){return{indexId:n,uid:e,sequenceNumber:t,readTime:Ps(s.readTime),documentKey:mt(s.documentKey.path),largestBatchId:s.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class YT{getBundleMetadata(e,t){return xf(e).get(t).next(s=>{if(s)return function(r){return{id:r.bundleId,createTime:Cs(r.createTime),version:r.version}}(s)})}saveBundleMetadata(e,t){return xf(e).put(function(i){return{bundleId:i.id,createTime:Ps(gt(i.createTime)),version:i.version}}(t))}getNamedQuery(e,t){return Of(e).get(t).next(s=>{if(s)return function(r){return{name:r.name,query:ty(r.bundledQuery),readTime:Cs(r.readTime)}}(s)})}saveNamedQuery(e,t){return Of(e).put(function(i){return{name:i.name,readTime:Ps(gt(i.readTime)),bundledQuery:i.bundledQuery}}(t))}}function xf(n){return Ye(n,"bundles")}function Of(n){return Ye(n,"namedQueries")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tc{constructor(e,t){this.serializer=e,this.userId=t}static lt(e,t){const s=t.uid||"";return new tc(e,s)}getOverlay(e,t){return sr(e).get(Vf(this.userId,t)).next(s=>s?Jc(this.serializer,s):null)}getOverlays(e,t){const s=Gt();return C.forEach(t,i=>this.getOverlay(e,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(e,t,s){const i=[];return s.forEach((r,o)=>{const a=new Au(t,o);i.push(this.ht(e,a))}),C.waitFor(i)}removeOverlaysForBatchId(e,t,s){const i=new Set;t.forEach(o=>i.add(mt(o.getCollectionPath())));const r=[];return i.forEach(o=>{const a=IDBKeyRange.bound([this.userId,o,s],[this.userId,o,s+1],!1,!0);r.push(sr(e).j("collectionPathOverlayIndex",a))}),C.waitFor(r)}getOverlaysForCollection(e,t,s){const i=Gt(),r=mt(t),o=IDBKeyRange.bound([this.userId,r,s],[this.userId,r,Number.POSITIVE_INFINITY],!0);return sr(e).U("collectionPathOverlayIndex",o).next(a=>{for(const l of a){const u=Jc(this.serializer,l);i.set(u.getKey(),u)}return i})}getOverlaysForCollectionGroup(e,t,s,i){const r=Gt();let o;const a=IDBKeyRange.bound([this.userId,t,s],[this.userId,t,Number.POSITIVE_INFINITY],!0);return sr(e).J({index:"collectionGroupOverlayIndex",range:a},(l,u,h)=>{const p=Jc(this.serializer,u);r.size()<i||p.largestBatchId===o?(r.set(p.getKey(),p),o=p.largestBatchId):h.done()}).next(()=>r)}ht(e,t){return sr(e).put(function(i,r,o){const[a,l,u]=Vf(r,o.mutation.key);return{userId:r,collectionPath:l,documentId:u,collectionGroup:o.mutation.key.getCollectionGroup(),largestBatchId:o.largestBatchId,overlayMutation:wa(i.ct,o.mutation)}}(this.serializer,this.userId,t))}}function sr(n){return Ye(n,"documentOverlays")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fs{constructor(){}Pt(e,t){this.It(e,t),t.Tt()}It(e,t){if("nullValue"in e)this.Et(t,5);else if("booleanValue"in e)this.Et(t,10),t.dt(e.booleanValue?1:0);else if("integerValue"in e)this.Et(t,15),t.dt(Me(e.integerValue));else if("doubleValue"in e){const s=Me(e.doubleValue);isNaN(s)?this.Et(t,13):(this.Et(t,15),Or(s)?t.dt(0):t.dt(s))}else if("timestampValue"in e){let s=e.timestampValue;this.Et(t,20),typeof s=="string"&&(s=mn(s)),t.At(`${s.seconds||""}`),t.dt(s.nanos||0)}else if("stringValue"in e)this.Rt(e.stringValue,t),this.Vt(t);else if("bytesValue"in e)this.Et(t,30),t.ft(Hn(e.bytesValue)),this.Vt(t);else if("referenceValue"in e)this.gt(e.referenceValue,t);else if("geoPointValue"in e){const s=e.geoPointValue;this.Et(t,45),t.dt(s.latitude||0),t.dt(s.longitude||0)}else"mapValue"in e?fg(e)?this.Et(t,Number.MAX_SAFE_INTEGER):(this.yt(e.mapValue,t),this.Vt(t)):"arrayValue"in e?(this.wt(e.arrayValue,t),this.Vt(t)):G()}Rt(e,t){this.Et(t,25),this.St(e,t)}St(e,t){t.At(e)}yt(e,t){const s=e.fields||{};this.Et(t,55);for(const i of Object.keys(s))this.Rt(i,t),this.It(s[i],t)}wt(e,t){const s=e.values||[];this.Et(t,50);for(const i of s)this.It(i,t)}gt(e,t){this.Et(t,37),q.fromName(e).path.forEach(s=>{this.Et(t,60),this.St(s,t)})}Et(e,t){e.dt(t)}Vt(e){e.dt(2)}}fs.bt=new fs;function XT(n){if(n===0)return 8;let e=0;return!(n>>4)&&(e+=4,n<<=4),!(n>>6)&&(e+=2,n<<=2),!(n>>7)&&(e+=1),e}function Mf(n){const e=64-function(s){let i=0;for(let r=0;r<8;++r){const o=XT(255&s[r]);if(i+=o,o!==8)break}return i}(n);return Math.ceil(e/8)}class ZT{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Dt(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Ct(s.value),s=t.next();this.vt()}Ft(e){const t=e[Symbol.iterator]();let s=t.next();for(;!s.done;)this.Mt(s.value),s=t.next();this.xt()}Ot(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Ct(s);else if(s<2048)this.Ct(960|s>>>6),this.Ct(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Ct(480|s>>>12),this.Ct(128|63&s>>>6),this.Ct(128|63&s);else{const i=t.codePointAt(0);this.Ct(240|i>>>18),this.Ct(128|63&i>>>12),this.Ct(128|63&i>>>6),this.Ct(128|63&i)}}this.vt()}Nt(e){for(const t of e){const s=t.charCodeAt(0);if(s<128)this.Mt(s);else if(s<2048)this.Mt(960|s>>>6),this.Mt(128|63&s);else if(t<"\uD800"||"\uDBFF"<t)this.Mt(480|s>>>12),this.Mt(128|63&s>>>6),this.Mt(128|63&s);else{const i=t.codePointAt(0);this.Mt(240|i>>>18),this.Mt(128|63&i>>>12),this.Mt(128|63&i>>>6),this.Mt(128|63&i)}}this.xt()}Lt(e){const t=this.Bt(e),s=Mf(t);this.kt(1+s),this.buffer[this.position++]=255&s;for(let i=t.length-s;i<t.length;++i)this.buffer[this.position++]=255&t[i]}qt(e){const t=this.Bt(e),s=Mf(t);this.kt(1+s),this.buffer[this.position++]=~(255&s);for(let i=t.length-s;i<t.length;++i)this.buffer[this.position++]=~(255&t[i])}Qt(){this.Kt(255),this.Kt(255)}$t(){this.Ut(255),this.Ut(255)}reset(){this.position=0}seed(e){this.kt(e.length),this.buffer.set(e,this.position),this.position+=e.length}Wt(){return this.buffer.slice(0,this.position)}Bt(e){const t=function(r){const o=new DataView(new ArrayBuffer(8));return o.setFloat64(0,r,!1),new Uint8Array(o.buffer)}(e),s=(128&t[0])!=0;t[0]^=s?255:128;for(let i=1;i<t.length;++i)t[i]^=s?255:0;return t}Ct(e){const t=255&e;t===0?(this.Kt(0),this.Kt(255)):t===255?(this.Kt(255),this.Kt(0)):this.Kt(t)}Mt(e){const t=255&e;t===0?(this.Ut(0),this.Ut(255)):t===255?(this.Ut(255),this.Ut(0)):this.Ut(e)}vt(){this.Kt(0),this.Kt(1)}xt(){this.Ut(0),this.Ut(1)}Kt(e){this.kt(1),this.buffer[this.position++]=e}Ut(e){this.kt(1),this.buffer[this.position++]=~e}kt(e){const t=e+this.position;if(t<=this.buffer.length)return;let s=2*this.buffer.length;s<t&&(s=t);const i=new Uint8Array(s);i.set(this.buffer),this.buffer=i}}class e0{constructor(e){this.Gt=e}ft(e){this.Gt.Dt(e)}At(e){this.Gt.Ot(e)}dt(e){this.Gt.Lt(e)}Tt(){this.Gt.Qt()}}class t0{constructor(e){this.Gt=e}ft(e){this.Gt.Ft(e)}At(e){this.Gt.Nt(e)}dt(e){this.Gt.qt(e)}Tt(){this.Gt.$t()}}class ir{constructor(){this.Gt=new ZT,this.zt=new e0(this.Gt),this.jt=new t0(this.Gt)}seed(e){this.Gt.seed(e)}Ht(e){return e===0?this.zt:this.jt}Wt(){return this.Gt.Wt()}reset(){this.Gt.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ps{constructor(e,t,s,i){this.indexId=e,this.documentKey=t,this.arrayValue=s,this.directionalValue=i}Jt(){const e=this.directionalValue.length,t=e===0||this.directionalValue[e-1]===255?e+1:e,s=new Uint8Array(t);return s.set(this.directionalValue,0),t!==e?s.set([0],this.directionalValue.length):++s[s.length-1],new ps(this.indexId,this.documentKey,this.arrayValue,s)}}function kn(n,e){let t=n.indexId-e.indexId;return t!==0?t:(t=Lf(n.arrayValue,e.arrayValue),t!==0?t:(t=Lf(n.directionalValue,e.directionalValue),t!==0?t:q.comparator(n.documentKey,e.documentKey)))}function Lf(n,e){for(let t=0;t<n.length&&t<e.length;++t){const s=n[t]-e[t];if(s!==0)return s}return n.length-e.length}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ff{constructor(e){this.Yt=new Ee((t,s)=>Ve.comparator(t.field,s.field)),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.Zt=e.orderBy,this.Xt=[];for(const t of e.filters){const s=t;s.isInequality()?this.Yt=this.Yt.add(s):this.Xt.push(s)}}get en(){return this.Yt.size>1}tn(e){if(X(e.collectionGroup===this.collectionId),this.en)return!1;const t=wl(e);if(t!==void 0&&!this.nn(t))return!1;const s=us(e);let i=new Set,r=0,o=0;for(;r<s.length&&this.nn(s[r]);++r)i=i.add(s[r].fieldPath.canonicalString());if(r===s.length)return!0;if(this.Yt.size>0){const a=this.Yt.getIterator().getNext();if(!i.has(a.field.canonicalString())){const l=s[r];if(!this.rn(a,l)||!this.sn(this.Zt[o++],l))return!1}++r}for(;r<s.length;++r){const a=s[r];if(o>=this.Zt.length||!this.sn(this.Zt[o++],a))return!1}return!0}on(){if(this.en)return null;let e=new Ee(Ve.comparator);const t=[];for(const s of this.Xt)if(!s.field.isKeyField())if(s.op==="array-contains"||s.op==="array-contains-any")t.push(new Yo(s.field,2));else{if(e.has(s.field))continue;e=e.add(s.field),t.push(new Yo(s.field,0))}for(const s of this.Zt)s.field.isKeyField()||e.has(s.field)||(e=e.add(s.field),t.push(new Yo(s.field,s.dir==="asc"?0:1)));return new ga(ga.UNKNOWN_ID,this.collectionId,t,xr.empty())}nn(e){for(const t of this.Xt)if(this.rn(t,e))return!0;return!1}rn(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const s=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===s}sn(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ny(n){var e,t;if(X(n instanceof le||n instanceof Ie),n instanceof le){if(n instanceof wg){const i=((t=(e=n.value.arrayValue)===null||e===void 0?void 0:e.values)===null||t===void 0?void 0:t.map(r=>le.create(n.field,"==",r)))||[];return Ie.create(i,"or")}return n}const s=n.filters.map(i=>ny(i));return Ie.create(s,n.op)}function n0(n){if(n.getFilters().length===0)return[];const e=xl(ny(n));return X(sy(e)),Vl(e)||Nl(e)?[e]:e.getFilters()}function Vl(n){return n instanceof le}function Nl(n){return n instanceof Ie&&wu(n)}function sy(n){return Vl(n)||Nl(n)||function(t){if(t instanceof Ie&&Al(t)){for(const s of t.getFilters())if(!Vl(s)&&!Nl(s))return!1;return!0}return!1}(n)}function xl(n){if(X(n instanceof le||n instanceof Ie),n instanceof le)return n;if(n.filters.length===1)return xl(n.filters[0]);const e=n.filters.map(s=>xl(s));let t=Ie.create(e,n.op);return t=Ea(t),sy(t)?t:(X(t instanceof Ie),X(gi(t)),X(t.filters.length>1),t.filters.reduce((s,i)=>Ru(s,i)))}function Ru(n,e){let t;return X(n instanceof le||n instanceof Ie),X(e instanceof le||e instanceof Ie),t=n instanceof le?e instanceof le?function(i,r){return Ie.create([i,r],"and")}(n,e):Uf(n,e):e instanceof le?Uf(e,n):function(i,r){if(X(i.filters.length>0&&r.filters.length>0),gi(i)&&gi(r))return vg(i,r.getFilters());const o=Al(i)?i:r,a=Al(i)?r:i,l=o.filters.map(u=>Ru(u,a));return Ie.create(l,"or")}(n,e),Ea(t)}function Uf(n,e){if(gi(e))return vg(e,n.getFilters());{const t=e.filters.map(s=>Ru(n,s));return Ie.create(t,"or")}}function Ea(n){if(X(n instanceof le||n instanceof Ie),n instanceof le)return n;const e=n.getFilters();if(e.length===1)return Ea(e[0]);if(gg(n))return n;const t=e.map(i=>Ea(i)),s=[];return t.forEach(i=>{i instanceof le?s.push(i):i instanceof Ie&&(i.op===n.op?s.push(...i.filters):s.push(i))}),s.length===1?s[0]:Ie.create(s,n.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class s0{constructor(){this._n=new Pu}addToCollectionParentIndex(e,t){return this._n.add(t),C.resolve()}getCollectionParents(e,t){return C.resolve(this._n.getEntries(t))}addFieldIndex(e,t){return C.resolve()}deleteFieldIndex(e,t){return C.resolve()}deleteAllFieldIndexes(e){return C.resolve()}createTargetIndexes(e,t){return C.resolve()}getDocumentsMatchingTarget(e,t){return C.resolve(null)}getIndexType(e,t){return C.resolve(0)}getFieldIndexes(e,t){return C.resolve([])}getNextCollectionGroupToUpdate(e){return C.resolve(null)}getMinOffset(e,t){return C.resolve(Rt.min())}getMinOffsetFromCollectionGroup(e,t){return C.resolve(Rt.min())}updateCollectionGroup(e,t,s){return C.resolve()}updateIndexEntries(e,t){return C.resolve()}}class Pu{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),i=this.index[t]||new Ee(be.comparator),r=!i.has(s);return this.index[t]=i.add(s),r}has(e){const t=e.lastSegment(),s=e.popLast(),i=this.index[t];return i&&i.has(s)}getEntries(e){return(this.index[e]||new Ee(be.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lo=new Uint8Array(0);class i0{constructor(e,t){this.databaseId=t,this.an=new Pu,this.un=new ts(s=>Rs(s),(s,i)=>io(s,i)),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.an.has(t)){const s=t.lastSegment(),i=t.popLast();e.addOnCommittedListener(()=>{this.an.add(t)});const r={collectionId:s,parent:mt(i)};return qf(e).put(r)}return C.resolve()}getCollectionParents(e,t){const s=[],i=IDBKeyRange.bound([t,""],[Zm(t),""],!1,!0);return qf(e).U(i).next(r=>{for(const o of r){if(o.collectionId!==t)break;s.push(zt(o.parent))}return s})}addFieldIndex(e,t){const s=rr(e),i=function(a){return{indexId:a.indexId,collectionGroup:a.collectionGroup,fields:a.fields.map(l=>[l.fieldPath.canonicalString(),l.kind])}}(t);delete i.indexId;const r=s.add(i);if(t.indexState){const o=Gs(e);return r.next(a=>{o.put(Nf(a,this.uid,t.indexState.sequenceNumber,t.indexState.offset))})}return r.next()}deleteFieldIndex(e,t){const s=rr(e),i=Gs(e),r=zs(e);return s.delete(t.indexId).next(()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))).next(()=>r.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))}deleteAllFieldIndexes(e){const t=rr(e),s=zs(e),i=Gs(e);return t.j().next(()=>s.j()).next(()=>i.j())}createTargetIndexes(e,t){return C.forEach(this.cn(t),s=>this.getIndexType(e,s).next(i=>{if(i===0||i===1){const r=new Ff(s).on();if(r!=null)return this.addFieldIndex(e,r)}}))}getDocumentsMatchingTarget(e,t){const s=zs(e);let i=!0;const r=new Map;return C.forEach(this.cn(t),o=>this.ln(e,o).next(a=>{i&&(i=!!a),r.set(o,a)})).next(()=>{if(i){let o=re();const a=[];return C.forEach(r,(l,u)=>{N("IndexedDbIndexManager",`Using index ${function(K){return`id=${K.indexId}|cg=${K.collectionGroup}|f=${K.fields.map(se=>`${se.fieldPath}:${se.kind}`).join(",")}`}(l)} to execute ${Rs(t)}`);const h=function(K,se){const x=wl(se);if(x===void 0)return null;for(const L of va(K,x.fieldPath))switch(L.op){case"array-contains-any":return L.value.arrayValue.values||[];case"array-contains":return[L.value]}return null}(u,l),p=function(K,se){const x=new Map;for(const L of us(se))for(const b of va(K,L.fieldPath))switch(b.op){case"==":case"in":x.set(L.fieldPath.canonicalString(),b.value);break;case"not-in":case"!=":return x.set(L.fieldPath.canonicalString(),b.value),Array.from(x.values())}return null}(u,l),m=function(K,se){const x=[];let L=!0;for(const b of us(se)){const y=b.kind===0?_f(K,b.fieldPath,K.startAt):bf(K,b.fieldPath,K.startAt);x.push(y.value),L&&(L=y.inclusive)}return new mi(x,L)}(u,l),w=function(K,se){const x=[];let L=!0;for(const b of us(se)){const y=b.kind===0?bf(K,b.fieldPath,K.endAt):_f(K,b.fieldPath,K.endAt);x.push(y.value),L&&(L=y.inclusive)}return new mi(x,L)}(u,l),E=this.hn(l,u,m),$=this.hn(l,u,w),R=this.Pn(l,u,p),B=this.In(l.indexId,h,E,m.inclusive,$,w.inclusive,R);return C.forEach(B,H=>s.G(H,t.limit).next(K=>{K.forEach(se=>{const x=q.fromSegments(se.documentKey);o.has(x)||(o=o.add(x),a.push(x))})}))}).next(()=>a)}return C.resolve(null)})}cn(e){let t=this.un.get(e);return t||(e.filters.length===0?t=[e]:t=n0(Ie.create(e.filters,"and")).map(s=>kl(e.path,e.collectionGroup,e.orderBy,s.getFilters(),e.limit,e.startAt,e.endAt)),this.un.set(e,t),t)}In(e,t,s,i,r,o,a){const l=(t!=null?t.length:1)*Math.max(s.length,r.length),u=l/(t!=null?t.length:1),h=[];for(let p=0;p<l;++p){const m=t?this.Tn(t[p/u]):Lo,w=this.En(e,m,s[p%u],i),E=this.dn(e,m,r[p%u],o),$=a.map(R=>this.En(e,m,R,!0));h.push(...this.createRange(w,E,$))}return h}En(e,t,s,i){const r=new ps(e,q.empty(),t,s);return i?r:r.Jt()}dn(e,t,s,i){const r=new ps(e,q.empty(),t,s);return i?r.Jt():r}ln(e,t){const s=new Ff(t),i=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,i).next(r=>{let o=null;for(const a of r)s.tn(a)&&(!o||a.fields.length>o.fields.length)&&(o=a);return o})}getIndexType(e,t){let s=2;const i=this.cn(t);return C.forEach(i,r=>this.ln(e,r).next(o=>{o?s!==0&&o.fields.length<function(l){let u=new Ee(Ve.comparator),h=!1;for(const p of l.filters)for(const m of p.getFlattenedFilters())m.field.isKeyField()||(m.op==="array-contains"||m.op==="array-contains-any"?h=!0:u=u.add(m.field));for(const p of l.orderBy)p.field.isKeyField()||(u=u.add(p.field));return u.size+(h?1:0)}(r)&&(s=1):s=0})).next(()=>function(o){return o.limit!==null}(t)&&i.length>1&&s===2?1:s)}An(e,t){const s=new ir;for(const i of us(e)){const r=t.data.field(i.fieldPath);if(r==null)return null;const o=s.Ht(i.kind);fs.bt.Pt(r,o)}return s.Wt()}Tn(e){const t=new ir;return fs.bt.Pt(e,t.Ht(0)),t.Wt()}Rn(e,t){const s=new ir;return fs.bt.Pt(Fr(this.databaseId,t),s.Ht(function(r){const o=us(r);return o.length===0?0:o[o.length-1].kind}(e))),s.Wt()}Pn(e,t,s){if(s===null)return[];let i=[];i.push(new ir);let r=0;for(const o of us(e)){const a=s[r++];for(const l of i)if(this.Vn(t,o.fieldPath)&&Ur(a))i=this.mn(i,o,a);else{const u=l.Ht(o.kind);fs.bt.Pt(a,u)}}return this.fn(i)}hn(e,t,s){return this.Pn(e,t,s.position)}fn(e){const t=[];for(let s=0;s<e.length;++s)t[s]=e[s].Wt();return t}mn(e,t,s){const i=[...e],r=[];for(const o of s.arrayValue.values||[])for(const a of i){const l=new ir;l.seed(a.Wt()),fs.bt.Pt(o,l.Ht(t.kind)),r.push(l)}return r}Vn(e,t){return!!e.filters.find(s=>s instanceof le&&s.field.isEqual(t)&&(s.op==="in"||s.op==="not-in"))}getFieldIndexes(e,t){const s=rr(e),i=Gs(e);return(t?s.U("collectionGroupIndex",IDBKeyRange.bound(t,t)):s.U()).next(r=>{const o=[];return C.forEach(r,a=>i.get([a.indexId,this.uid]).next(l=>{o.push(function(h,p){const m=p?new xr(p.sequenceNumber,new Rt(Cs(p.readTime),new q(zt(p.documentKey)),p.largestBatchId)):xr.empty(),w=h.fields.map(([E,$])=>new Yo(Ve.fromServerFormat(E),$));return new ga(h.indexId,h.collectionGroup,w,m)}(a,l))})).next(()=>o)})}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next(t=>t.length===0?null:(t.sort((s,i)=>{const r=s.indexState.sequenceNumber-i.indexState.sequenceNumber;return r!==0?r:ne(s.collectionGroup,i.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(e,t,s){const i=rr(e),r=Gs(e);return this.gn(e).next(o=>i.U("collectionGroupIndex",IDBKeyRange.bound(t,t)).next(a=>C.forEach(a,l=>r.put(Nf(l.indexId,this.uid,o,s)))))}updateIndexEntries(e,t){const s=new Map;return C.forEach(t,(i,r)=>{const o=s.get(i.collectionGroup);return(o?C.resolve(o):this.getFieldIndexes(e,i.collectionGroup)).next(a=>(s.set(i.collectionGroup,a),C.forEach(a,l=>this.pn(e,i,l).next(u=>{const h=this.yn(r,l);return u.isEqual(h)?C.resolve():this.wn(e,r,l,u,h)}))))})}Sn(e,t,s,i){return zs(e).put({indexId:i.indexId,uid:this.uid,arrayValue:i.arrayValue,directionalValue:i.directionalValue,orderedDocumentKey:this.Rn(s,t.key),documentKey:t.key.path.toArray()})}bn(e,t,s,i){return zs(e).delete([i.indexId,this.uid,i.arrayValue,i.directionalValue,this.Rn(s,t.key),t.key.path.toArray()])}pn(e,t,s){const i=zs(e);let r=new Ee(kn);return i.J({index:"documentKeyIndex",range:IDBKeyRange.only([s.indexId,this.uid,this.Rn(s,t)])},(o,a)=>{r=r.add(new ps(s.indexId,t,a.arrayValue,a.directionalValue))}).next(()=>r)}yn(e,t){let s=new Ee(kn);const i=this.An(t,e);if(i==null)return s;const r=wl(t);if(r!=null){const o=e.data.field(r.fieldPath);if(Ur(o))for(const a of o.arrayValue.values||[])s=s.add(new ps(t.indexId,e.key,this.Tn(a),i))}else s=s.add(new ps(t.indexId,e.key,Lo,i));return s}wn(e,t,s,i,r){N("IndexedDbIndexManager","Updating index entries for document '%s'",t.key);const o=[];return function(l,u,h,p,m){const w=l.getIterator(),E=u.getIterator();let $=js(w),R=js(E);for(;$||R;){let B=!1,H=!1;if($&&R){const K=h($,R);K<0?H=!0:K>0&&(B=!0)}else $!=null?H=!0:B=!0;B?(p(R),R=js(E)):H?(m($),$=js(w)):($=js(w),R=js(E))}}(i,r,kn,a=>{o.push(this.Sn(e,t,s,a))},a=>{o.push(this.bn(e,t,s,a))}),C.waitFor(o)}gn(e){let t=1;return Gs(e).J({index:"sequenceNumberIndex",reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(s,i,r)=>{r.done(),t=i.sequenceNumber+1}).next(()=>t)}createRange(e,t,s){s=s.sort((o,a)=>kn(o,a)).filter((o,a,l)=>!a||kn(o,l[a-1])!==0);const i=[];i.push(e);for(const o of s){const a=kn(o,e),l=kn(o,t);if(a===0)i[0]=e.Jt();else if(a>0&&l<0)i.push(o),i.push(o.Jt());else if(l>0)break}i.push(t);const r=[];for(let o=0;o<i.length;o+=2){if(this.Dn(i[o],i[o+1]))return[];const a=[i[o].indexId,this.uid,i[o].arrayValue,i[o].directionalValue,Lo,[]],l=[i[o+1].indexId,this.uid,i[o+1].arrayValue,i[o+1].directionalValue,Lo,[]];r.push(IDBKeyRange.bound(a,l))}return r}Dn(e,t){return kn(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(Bf)}getMinOffset(e,t){return C.mapArray(this.cn(t),s=>this.ln(e,s).next(i=>i||G())).next(Bf)}}function qf(n){return Ye(n,"collectionParents")}function zs(n){return Ye(n,"indexEntries")}function rr(n){return Ye(n,"indexConfiguration")}function Gs(n){return Ye(n,"indexState")}function Bf(n){X(n.length!==0);let e=n[0].indexState.offset,t=e.largestBatchId;for(let s=1;s<n.length;s++){const i=n[s].indexState.offset;yu(i,e)<0&&(e=i),t<i.largestBatchId&&(t=i.largestBatchId)}return new Rt(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jf={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class bt{constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}static withCacheSize(e){return new bt(e,bt.DEFAULT_COLLECTION_PERCENTILE,bt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function iy(n,e,t){const s=n.store("mutations"),i=n.store("documentMutations"),r=[],o=IDBKeyRange.only(t.batchId);let a=0;const l=s.J({range:o},(h,p,m)=>(a++,m.delete()));r.push(l.next(()=>{X(a===1)}));const u=[];for(const h of t.mutations){const p=og(e,h.key.path,t.batchId);r.push(i.delete(p)),u.push(h.key)}return C.waitFor(r).next(()=>u)}function Ta(n){if(!n)return 0;let e;if(n.document)e=n.document;else if(n.unknownDocument)e=n.unknownDocument;else{if(!n.noDocument)throw G();e=n.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */bt.DEFAULT_COLLECTION_PERCENTILE=10,bt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,bt.DEFAULT=new bt(41943040,bt.DEFAULT_COLLECTION_PERCENTILE,bt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),bt.DISABLED=new bt(-1,0,0);class nc{constructor(e,t,s,i){this.userId=e,this.serializer=t,this.indexManager=s,this.referenceDelegate=i,this.Cn={}}static lt(e,t,s,i){X(e.uid!=="");const r=e.isAuthenticated()?e.uid:"";return new nc(r,t,s,i)}checkEmpty(e){let t=!0;const s=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Rn(e).J({index:"userMutationsIndex",range:s},(i,r,o)=>{t=!1,o.done()}).next(()=>t)}addMutationBatch(e,t,s,i){const r=ti(e),o=Rn(e);return o.add({}).next(a=>{X(typeof a=="number");const l=new Eu(a,t,s,i),u=function(w,E,$){const R=$.baseMutations.map(H=>wa(w.ct,H)),B=$.mutations.map(H=>wa(w.ct,H));return{userId:E,batchId:$.batchId,localWriteTimeMs:$.localWriteTime.toMillis(),baseMutations:R,mutations:B}}(this.serializer,this.userId,l),h=[];let p=new Ee((m,w)=>ne(m.canonicalString(),w.canonicalString()));for(const m of i){const w=og(this.userId,m.key.path,a);p=p.add(m.key.path.popLast()),h.push(o.put(u)),h.push(r.put(w,jE))}return p.forEach(m=>{h.push(this.indexManager.addToCollectionParentIndex(e,m))}),e.addOnCommittedListener(()=>{this.Cn[a]=l.keys()}),C.waitFor(h).next(()=>l)})}lookupMutationBatch(e,t){return Rn(e).get(t).next(s=>s?(X(s.userId===this.userId),hs(this.serializer,s)):null)}vn(e,t){return this.Cn[t]?C.resolve(this.Cn[t]):this.lookupMutationBatch(e,t).next(s=>{if(s){const i=s.keys();return this.Cn[t]=i,i}return null})}getNextMutationBatchAfterBatchId(e,t){const s=t+1,i=IDBKeyRange.lowerBound([this.userId,s]);let r=null;return Rn(e).J({index:"userMutationsIndex",range:i},(o,a,l)=>{a.userId===this.userId&&(X(a.batchId>=s),r=hs(this.serializer,a)),l.done()}).next(()=>r)}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let s=-1;return Rn(e).J({index:"userMutationsIndex",range:t,reverse:!0},(i,r,o)=>{s=r.batchId,o.done()}).next(()=>s)}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return Rn(e).U("userMutationsIndex",t).next(s=>s.map(i=>hs(this.serializer,i)))}getAllMutationBatchesAffectingDocumentKey(e,t){const s=Xo(this.userId,t.path),i=IDBKeyRange.lowerBound(s),r=[];return ti(e).J({range:i},(o,a,l)=>{const[u,h,p]=o,m=zt(h);if(u===this.userId&&t.path.isEqual(m))return Rn(e).get(p).next(w=>{if(!w)throw G();X(w.userId===this.userId),r.push(hs(this.serializer,w))});l.done()}).next(()=>r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new Ee(ne);const i=[];return t.forEach(r=>{const o=Xo(this.userId,r.path),a=IDBKeyRange.lowerBound(o),l=ti(e).J({range:a},(u,h,p)=>{const[m,w,E]=u,$=zt(w);m===this.userId&&r.path.isEqual($)?s=s.add(E):p.done()});i.push(l)}),C.waitFor(i).next(()=>this.Fn(e,s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,i=s.length+1,r=Xo(this.userId,s),o=IDBKeyRange.lowerBound(r);let a=new Ee(ne);return ti(e).J({range:o},(l,u,h)=>{const[p,m,w]=l,E=zt(m);p===this.userId&&s.isPrefixOf(E)?E.length===i&&(a=a.add(w)):h.done()}).next(()=>this.Fn(e,a))}Fn(e,t){const s=[],i=[];return t.forEach(r=>{i.push(Rn(e).get(r).next(o=>{if(o===null)throw G();X(o.userId===this.userId),s.push(hs(this.serializer,o))}))}),C.waitFor(i).next(()=>s)}removeMutationBatch(e,t){return iy(e._e,this.userId,t).next(s=>(e.addOnCommittedListener(()=>{this.Mn(t.batchId)}),C.forEach(s,i=>this.referenceDelegate.markPotentiallyOrphaned(e,i))))}Mn(e){delete this.Cn[e]}performConsistencyCheck(e){return this.checkEmpty(e).next(t=>{if(!t)return C.resolve();const s=IDBKeyRange.lowerBound(function(o){return[o]}(this.userId)),i=[];return ti(e).J({range:s},(r,o,a)=>{if(r[0]===this.userId){const l=zt(r[1]);i.push(l)}else a.done()}).next(()=>{X(i.length===0)})})}containsKey(e,t){return ry(e,this.userId,t)}xn(e){return oy(e).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:-1,lastStreamToken:""})}}function ry(n,e,t){const s=Xo(e,t.path),i=s[1],r=IDBKeyRange.lowerBound(s);let o=!1;return ti(n).J({range:r,H:!0},(a,l,u)=>{const[h,p,m]=a;h===e&&p===i&&(o=!0),u.done()}).next(()=>o)}function Rn(n){return Ye(n,"mutations")}function ti(n){return Ye(n,"documentMutations")}function oy(n){return Ye(n,"mutationQueues")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ds{constructor(e){this.On=e}next(){return this.On+=2,this.On}static Nn(){return new Ds(0)}static Ln(){return new Ds(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class r0{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.Bn(e).next(t=>{const s=new Ds(t.highestTargetId);return t.highestTargetId=s.next(),this.kn(e,t).next(()=>t.highestTargetId)})}getLastRemoteSnapshotVersion(e){return this.Bn(e).next(t=>Z.fromTimestamp(new Ne(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(e){return this.Bn(e).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(e,t,s){return this.Bn(e).next(i=>(i.highestListenSequenceNumber=t,s&&(i.lastRemoteSnapshotVersion=s.toTimestamp()),t>i.highestListenSequenceNumber&&(i.highestListenSequenceNumber=t),this.kn(e,i)))}addTargetData(e,t){return this.qn(e,t).next(()=>this.Bn(e).next(s=>(s.targetCount+=1,this.Qn(t,s),this.kn(e,s))))}updateTargetData(e,t){return this.qn(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next(()=>Ks(e).delete(t.targetId)).next(()=>this.Bn(e)).next(s=>(X(s.targetCount>0),s.targetCount-=1,this.kn(e,s)))}removeTargets(e,t,s){let i=0;const r=[];return Ks(e).J((o,a)=>{const l=gr(a);l.sequenceNumber<=t&&s.get(l.targetId)===null&&(i++,r.push(this.removeTargetData(e,l)))}).next(()=>C.waitFor(r)).next(()=>i)}forEachTarget(e,t){return Ks(e).J((s,i)=>{const r=gr(i);t(r)})}Bn(e){return zf(e).get("targetGlobalKey").next(t=>(X(t!==null),t))}kn(e,t){return zf(e).put("targetGlobalKey",t)}qn(e,t){return Ks(e).put(ey(this.serializer,t))}Qn(e,t){let s=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,s=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,s=!0),s}getTargetCount(e){return this.Bn(e).next(t=>t.targetCount)}getTargetData(e,t){const s=Rs(t),i=IDBKeyRange.bound([s,Number.NEGATIVE_INFINITY],[s,Number.POSITIVE_INFINITY]);let r=null;return Ks(e).J({range:i,index:"queryTargetsIndex"},(o,a,l)=>{const u=gr(a);io(t,u.target)&&(r=u,l.done())}).next(()=>r)}addMatchingKeys(e,t,s){const i=[],r=On(e);return t.forEach(o=>{const a=mt(o.path);i.push(r.put({targetId:s,path:a})),i.push(this.referenceDelegate.addReference(e,s,o))}),C.waitFor(i)}removeMatchingKeys(e,t,s){const i=On(e);return C.forEach(t,r=>{const o=mt(r.path);return C.waitFor([i.delete([s,o]),this.referenceDelegate.removeReference(e,s,r)])})}removeMatchingKeysForTargetId(e,t){const s=On(e),i=IDBKeyRange.bound([t],[t+1],!1,!0);return s.delete(i)}getMatchingKeysForTargetId(e,t){const s=IDBKeyRange.bound([t],[t+1],!1,!0),i=On(e);let r=re();return i.J({range:s,H:!0},(o,a,l)=>{const u=zt(o[1]),h=new q(u);r=r.add(h)}).next(()=>r)}containsKey(e,t){const s=mt(t.path),i=IDBKeyRange.bound([s],[Zm(s)],!1,!0);let r=0;return On(e).J({index:"documentTargetsIndex",H:!0,range:i},([o,a],l,u)=>{o!==0&&(r++,u.done())}).next(()=>r>0)}ot(e,t){return Ks(e).get(t).next(s=>s?gr(s):null)}}function Ks(n){return Ye(n,"targets")}function zf(n){return Ye(n,"targetGlobal")}function On(n){return Ye(n,"targetDocuments")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gf([n,e],[t,s]){const i=ne(n,t);return i===0?ne(e,s):i}class o0{constructor(e){this.Kn=e,this.buffer=new Ee(Gf),this.$n=0}Un(){return++this.$n}Wn(e){const t=[e,this.Un()];if(this.buffer.size<this.Kn)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();Gf(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class a0{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.Gn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.zn(6e4)}stop(){this.Gn&&(this.Gn.cancel(),this.Gn=null)}get started(){return this.Gn!==null}zn(e){N("LruGarbageCollector",`Garbage collection scheduled in ${e}ms`),this.Gn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Gn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){es(t)?N("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",t):await Zn(t)}await this.zn(3e5)})}}class c0{constructor(e,t){this.jn=e,this.params=t}calculateTargetCount(e,t){return this.jn.Hn(e).next(s=>Math.floor(t/100*s))}nthSequenceNumber(e,t){if(t===0)return C.resolve(It.oe);const s=new o0(t);return this.jn.forEachTarget(e,i=>s.Wn(i.sequenceNumber)).next(()=>this.jn.Jn(e,i=>s.Wn(i))).next(()=>s.maxValue)}removeTargets(e,t,s){return this.jn.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.jn.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(N("LruGarbageCollector","Garbage collection skipped; disabled"),C.resolve(jf)):this.getCacheSize(e).next(s=>s<this.params.cacheSizeCollectionThreshold?(N("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),jf):this.Yn(e,t))}getCacheSize(e){return this.jn.getCacheSize(e)}Yn(e,t){let s,i,r,o,a,l,u;const h=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(p=>(p>this.params.maximumSequenceNumbersToCollect?(N("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${p}`),i=this.params.maximumSequenceNumbersToCollect):i=p,o=Date.now(),this.nthSequenceNumber(e,i))).next(p=>(s=p,a=Date.now(),this.removeTargets(e,s,t))).next(p=>(r=p,l=Date.now(),this.removeOrphanedDocuments(e,s))).next(p=>(u=Date.now(),Ys()<=ce.DEBUG&&N("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-h}ms
	Determined least recently used ${i} in `+(a-o)+`ms
	Removed ${r} targets in `+(l-a)+`ms
	Removed ${p} documents in `+(u-l)+`ms
Total Duration: ${u-h}ms`),C.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:r,documentsRemoved:p})))}}function l0(n,e){return new c0(n,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u0{constructor(e,t){this.db=e,this.garbageCollector=l0(this,t)}Hn(e){const t=this.Zn(e);return this.db.getTargetCache().getTargetCount(e).next(s=>t.next(i=>s+i))}Zn(e){let t=0;return this.Jn(e,s=>{t++}).next(()=>t)}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}Jn(e,t){return this.Xn(e,(s,i)=>t(i))}addReference(e,t,s){return Fo(e,s)}removeReference(e,t,s){return Fo(e,s)}removeTargets(e,t,s){return this.db.getTargetCache().removeTargets(e,t,s)}markPotentiallyOrphaned(e,t){return Fo(e,t)}er(e,t){return function(i,r){let o=!1;return oy(i).Y(a=>ry(i,a,r).next(l=>(l&&(o=!0),C.resolve(!l)))).next(()=>o)}(e,t)}removeOrphanedDocuments(e,t){const s=this.db.getRemoteDocumentCache().newChangeBuffer(),i=[];let r=0;return this.Xn(e,(o,a)=>{if(a<=t){const l=this.er(e,o).next(u=>{if(!u)return r++,s.getEntry(e,o).next(()=>(s.removeEntry(o,Z.min()),On(e).delete(function(p){return[0,mt(p.path)]}(o))))});i.push(l)}}).next(()=>C.waitFor(i)).next(()=>s.apply(e)).next(()=>r)}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,s)}updateLimboDocument(e,t){return Fo(e,t)}Xn(e,t){const s=On(e);let i,r=It.oe;return s.J({index:"documentTargetsIndex"},([o,a],{path:l,sequenceNumber:u})=>{o===0?(r!==It.oe&&t(new q(zt(i)),r),r=u,i=l):r=It.oe}).next(()=>{r!==It.oe&&t(new q(zt(i)),r)})}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function Fo(n,e){return On(n).put(function(s,i){return{targetId:0,path:mt(s.path),sequenceNumber:i}}(e,n.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ay{constructor(){this.changes=new ts(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Le.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?C.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class d0{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,s){return cs(e).put(s)}removeEntry(e,t,s){return cs(e).delete(function(r,o){const a=r.path.toArray();return[a.slice(0,a.length-2),a[a.length-2],Ia(o),a[a.length-1]]}(t,s))}updateMetadata(e,t){return this.getMetadata(e).next(s=>(s.byteSize+=t,this.tr(e,s)))}getEntry(e,t){let s=Le.newInvalidDocument(t);return cs(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(or(t))},(i,r)=>{s=this.nr(t,r)}).next(()=>s)}rr(e,t){let s={size:0,document:Le.newInvalidDocument(t)};return cs(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(or(t))},(i,r)=>{s={document:this.nr(t,r),size:Ta(r)}}).next(()=>s)}getEntries(e,t){let s=At();return this.ir(e,t,(i,r)=>{const o=this.nr(i,r);s=s.insert(i,o)}).next(()=>s)}sr(e,t){let s=At(),i=new Se(q.comparator);return this.ir(e,t,(r,o)=>{const a=this.nr(r,o);s=s.insert(r,a),i=i.insert(r,Ta(o))}).next(()=>({documents:s,_r:i}))}ir(e,t,s){if(t.isEmpty())return C.resolve();let i=new Ee(Hf);t.forEach(l=>i=i.add(l));const r=IDBKeyRange.bound(or(i.first()),or(i.last())),o=i.getIterator();let a=o.getNext();return cs(e).J({index:"documentKeyIndex",range:r},(l,u,h)=>{const p=q.fromSegments([...u.prefixPath,u.collectionGroup,u.documentId]);for(;a&&Hf(a,p)<0;)s(a,null),a=o.getNext();a&&a.isEqual(p)&&(s(a,u),a=o.hasNext()?o.getNext():null),a?h.$(or(a)):h.done()}).next(()=>{for(;a;)s(a,null),a=o.hasNext()?o.getNext():null})}getDocumentsMatchingQuery(e,t,s,i,r){const o=t.path,a=[o.popLast().toArray(),o.lastSegment(),Ia(s.readTime),s.documentKey.path.isEmpty()?"":s.documentKey.path.lastSegment()],l=[o.popLast().toArray(),o.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return cs(e).U(IDBKeyRange.bound(a,l,!0)).next(u=>{r==null||r.incrementDocumentReadCount(u.length);let h=At();for(const p of u){const m=this.nr(q.fromSegments(p.prefixPath.concat(p.collectionGroup,p.documentId)),p);m.isFoundDocument()&&(ro(t,m)||i.has(m.key))&&(h=h.insert(m.key,m))}return h})}getAllFromCollectionGroup(e,t,s,i){let r=At();const o=Wf(t,s),a=Wf(t,Rt.max());return cs(e).J({index:"collectionGroupIndex",range:IDBKeyRange.bound(o,a,!0)},(l,u,h)=>{const p=this.nr(q.fromSegments(u.prefixPath.concat(u.collectionGroup,u.documentId)),u);r=r.insert(p.key,p),r.size===i&&h.done()}).next(()=>r)}newChangeBuffer(e){return new h0(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next(t=>t.byteSize)}getMetadata(e){return Kf(e).get("remoteDocumentGlobalKey").next(t=>(X(!!t),t))}tr(e,t){return Kf(e).put("remoteDocumentGlobalKey",t)}nr(e,t){if(t){const s=JT(this.serializer,t);if(!(s.isNoDocument()&&s.version.isEqual(Z.min())))return s}return Le.newInvalidDocument(e)}}function cy(n){return new d0(n)}class h0 extends ay{constructor(e,t){super(),this.ar=e,this.trackRemovals=t,this.ur=new ts(s=>s.toString(),(s,i)=>s.isEqual(i))}applyChanges(e){const t=[];let s=0,i=new Ee((r,o)=>ne(r.canonicalString(),o.canonicalString()));return this.changes.forEach((r,o)=>{const a=this.ur.get(r);if(t.push(this.ar.removeEntry(e,r,a.readTime)),o.isValidDocument()){const l=$f(this.ar.serializer,o);i=i.add(r.path.popLast());const u=Ta(l);s+=u-a.size,t.push(this.ar.addEntry(e,r,l))}else if(s-=a.size,this.trackRemovals){const l=$f(this.ar.serializer,o.convertToNoDocument(Z.min()));t.push(this.ar.addEntry(e,r,l))}}),i.forEach(r=>{t.push(this.ar.indexManager.addToCollectionParentIndex(e,r))}),t.push(this.ar.updateMetadata(e,s)),C.waitFor(t)}getFromCache(e,t){return this.ar.rr(e,t).next(s=>(this.ur.set(t,{size:s.size,readTime:s.document.readTime}),s.document))}getAllFromCache(e,t){return this.ar.sr(e,t).next(({documents:s,_r:i})=>(i.forEach((r,o)=>{this.ur.set(r,{size:o,readTime:s.get(r).readTime})}),s))}}function Kf(n){return Ye(n,"remoteDocumentGlobal")}function cs(n){return Ye(n,"remoteDocumentsV14")}function or(n){const e=n.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function Wf(n,e){const t=e.documentKey.path.toArray();return[n,Ia(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function Hf(n,e){const t=n.path.toArray(),s=e.path.toArray();let i=0;for(let r=0;r<t.length-2&&r<s.length-2;++r)if(i=ne(t[r],s[r]),i)return i;return i=ne(t.length,s.length),i||(i=ne(t[t.length-2],s[s.length-2]),i||ne(t[t.length-1],s[s.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class f0{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ly{constructor(e,t,s,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=i}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(s=i,this.remoteDocumentCache.getEntry(e,t))).next(i=>(s!==null&&Er(s.mutation,i,Et.empty(),Ne.now()),i))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.getLocalViewOfDocuments(e,s,re()).next(()=>s))}getLocalViewOfDocuments(e,t,s=re()){const i=Gt();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,s).next(r=>{let o=pr();return r.forEach((a,l)=>{o=o.insert(a,l.overlayedDocument)}),o}))}getOverlayedDocuments(e,t){const s=Gt();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,re()))}populateOverlays(e,t,s){const i=[];return s.forEach(r=>{t.has(r)||i.push(r)}),this.documentOverlayCache.getOverlays(e,i).next(r=>{r.forEach((o,a)=>{t.set(o,a)})})}computeViews(e,t,s,i){let r=At();const o=Ir(),a=function(){return Ir()}();return t.forEach((l,u)=>{const h=s.get(u.key);i.has(u.key)&&(h===void 0||h.mutation instanceof vn)?r=r.insert(u.key,u):h!==void 0?(o.set(u.key,h.mutation.getFieldMask()),Er(h.mutation,u,h.mutation.getFieldMask(),Ne.now())):o.set(u.key,Et.empty())}),this.recalculateAndSaveOverlays(e,r).next(l=>(l.forEach((u,h)=>o.set(u,h)),t.forEach((u,h)=>{var p;return a.set(u,new f0(h,(p=o.get(u))!==null&&p!==void 0?p:null))}),a))}recalculateAndSaveOverlays(e,t){const s=Ir();let i=new Se((o,a)=>o-a),r=re();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(o=>{for(const a of o)a.keys().forEach(l=>{const u=t.get(l);if(u===null)return;let h=s.get(l)||Et.empty();h=a.applyToLocalView(u,h),s.set(l,h);const p=(i.get(a.batchId)||re()).add(l);i=i.insert(a.batchId,p)})}).next(()=>{const o=[],a=i.getReverseIterator();for(;a.hasNext();){const l=a.getNext(),u=l.key,h=l.value,p=Pg();h.forEach(m=>{if(!r.has(m)){const w=Og(t.get(m),s.get(m));w!==null&&p.set(m,w),r=r.add(m)}}),o.push(this.documentOverlayCache.saveOverlays(e,u,p))}return C.waitFor(o)}).next(()=>s)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.recalculateAndSaveOverlays(e,s))}getDocumentsMatchingQuery(e,t,s,i){return function(o){return q.isDocumentKey(o.path)&&o.collectionGroup===null&&o.filters.length===0}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):Eg(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,i):this.getDocumentsMatchingCollectionQuery(e,t,s,i)}getNextDocuments(e,t,s,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,i).next(r=>{const o=i-r.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,i-r.size):C.resolve(Gt());let a=-1,l=r;return o.next(u=>C.forEach(u,(h,p)=>(a<p.largestBatchId&&(a=p.largestBatchId),r.get(h)?C.resolve():this.remoteDocumentCache.getEntry(e,h).next(m=>{l=l.insert(h,m)}))).next(()=>this.populateOverlays(e,u,r)).next(()=>this.computeViews(e,l,u,re())).next(h=>({batchId:a,changes:Rg(h)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new q(t)).next(s=>{let i=pr();return s.isFoundDocument()&&(i=i.insert(s.key,s)),i})}getDocumentsMatchingCollectionGroupQuery(e,t,s,i){const r=t.collectionGroup;let o=pr();return this.indexManager.getCollectionParents(e,r).next(a=>C.forEach(a,l=>{const u=function(p,m){return new xi(m,null,p.explicitOrderBy.slice(),p.filters.slice(),p.limit,p.limitType,p.startAt,p.endAt)}(t,l.child(r));return this.getDocumentsMatchingCollectionQuery(e,u,s,i).next(h=>{h.forEach((p,m)=>{o=o.insert(p,m)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,t,s,i){let r;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next(o=>(r=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,r,i))).next(o=>{r.forEach((l,u)=>{const h=u.getKey();o.get(h)===null&&(o=o.insert(h,Le.newInvalidDocument(h)))});let a=pr();return o.forEach((l,u)=>{const h=r.get(l);h!==void 0&&Er(h.mutation,u,Et.empty(),Ne.now()),ro(t,u)&&(a=a.insert(l,u))}),a})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p0{constructor(e){this.serializer=e,this.cr=new Map,this.lr=new Map}getBundleMetadata(e,t){return C.resolve(this.cr.get(t))}saveBundleMetadata(e,t){return this.cr.set(t.id,function(i){return{id:i.id,version:i.version,createTime:gt(i.createTime)}}(t)),C.resolve()}getNamedQuery(e,t){return C.resolve(this.lr.get(t))}saveNamedQuery(e,t){return this.lr.set(t.name,function(i){return{name:i.name,query:ty(i.bundledQuery),readTime:gt(i.readTime)}}(t)),C.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class m0{constructor(){this.overlays=new Se(q.comparator),this.hr=new Map}getOverlay(e,t){return C.resolve(this.overlays.get(t))}getOverlays(e,t){const s=Gt();return C.forEach(t,i=>this.getOverlay(e,i).next(r=>{r!==null&&s.set(i,r)})).next(()=>s)}saveOverlays(e,t,s){return s.forEach((i,r)=>{this.ht(e,t,r)}),C.resolve()}removeOverlaysForBatchId(e,t,s){const i=this.hr.get(s);return i!==void 0&&(i.forEach(r=>this.overlays=this.overlays.remove(r)),this.hr.delete(s)),C.resolve()}getOverlaysForCollection(e,t,s){const i=Gt(),r=t.length+1,o=new q(t.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){const l=a.getNext().value,u=l.getKey();if(!t.isPrefixOf(u.path))break;u.path.length===r&&l.largestBatchId>s&&i.set(l.getKey(),l)}return C.resolve(i)}getOverlaysForCollectionGroup(e,t,s,i){let r=new Se((u,h)=>u-h);const o=this.overlays.getIterator();for(;o.hasNext();){const u=o.getNext().value;if(u.getKey().getCollectionGroup()===t&&u.largestBatchId>s){let h=r.get(u.largestBatchId);h===null&&(h=Gt(),r=r.insert(u.largestBatchId,h)),h.set(u.getKey(),u)}}const a=Gt(),l=r.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((u,h)=>a.set(u,h)),!(a.size()>=i)););return C.resolve(a)}ht(e,t,s){const i=this.overlays.get(s.key);if(i!==null){const o=this.hr.get(i.largestBatchId).delete(s.key);this.hr.set(i.largestBatchId,o)}this.overlays=this.overlays.insert(s.key,new Au(t,s));let r=this.hr.get(t);r===void 0&&(r=re(),this.hr.set(t,r)),this.hr.set(t,r.add(s.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cu{constructor(){this.Pr=new Ee(Qe.Ir),this.Tr=new Ee(Qe.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(e,t){const s=new Qe(e,t);this.Pr=this.Pr.add(s),this.Tr=this.Tr.add(s)}dr(e,t){e.forEach(s=>this.addReference(s,t))}removeReference(e,t){this.Ar(new Qe(e,t))}Rr(e,t){e.forEach(s=>this.removeReference(s,t))}Vr(e){const t=new q(new be([])),s=new Qe(t,e),i=new Qe(t,e+1),r=[];return this.Tr.forEachInRange([s,i],o=>{this.Ar(o),r.push(o.key)}),r}mr(){this.Pr.forEach(e=>this.Ar(e))}Ar(e){this.Pr=this.Pr.delete(e),this.Tr=this.Tr.delete(e)}gr(e){const t=new q(new be([])),s=new Qe(t,e),i=new Qe(t,e+1);let r=re();return this.Tr.forEachInRange([s,i],o=>{r=r.add(o.key)}),r}containsKey(e){const t=new Qe(e,0),s=this.Pr.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class Qe{constructor(e,t){this.key=e,this.pr=t}static Ir(e,t){return q.comparator(e.key,t.key)||ne(e.pr,t.pr)}static Er(e,t){return ne(e.pr,t.pr)||q.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class g0{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.yr=1,this.wr=new Ee(Qe.Ir)}checkEmpty(e){return C.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,i){const r=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new Eu(r,t,s,i);this.mutationQueue.push(o);for(const a of i)this.wr=this.wr.add(new Qe(a.key,r)),this.indexManager.addToCollectionParentIndex(e,a.key.path.popLast());return C.resolve(o)}lookupMutationBatch(e,t){return C.resolve(this.Sr(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,i=this.br(s),r=i<0?0:i;return C.resolve(this.mutationQueue.length>r?this.mutationQueue[r]:null)}getHighestUnacknowledgedBatchId(){return C.resolve(this.mutationQueue.length===0?-1:this.yr-1)}getAllMutationBatches(e){return C.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new Qe(t,0),i=new Qe(t,Number.POSITIVE_INFINITY),r=[];return this.wr.forEachInRange([s,i],o=>{const a=this.Sr(o.pr);r.push(a)}),C.resolve(r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new Ee(ne);return t.forEach(i=>{const r=new Qe(i,0),o=new Qe(i,Number.POSITIVE_INFINITY);this.wr.forEachInRange([r,o],a=>{s=s.add(a.pr)})}),C.resolve(this.Dr(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,i=s.length+1;let r=s;q.isDocumentKey(r)||(r=r.child(""));const o=new Qe(new q(r),0);let a=new Ee(ne);return this.wr.forEachWhile(l=>{const u=l.key.path;return!!s.isPrefixOf(u)&&(u.length===i&&(a=a.add(l.pr)),!0)},o),C.resolve(this.Dr(a))}Dr(e){const t=[];return e.forEach(s=>{const i=this.Sr(s);i!==null&&t.push(i)}),t}removeMutationBatch(e,t){X(this.Cr(t.batchId,"removed")===0),this.mutationQueue.shift();let s=this.wr;return C.forEach(t.mutations,i=>{const r=new Qe(i.key,t.batchId);return s=s.delete(r),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.wr=s})}Mn(e){}containsKey(e,t){const s=new Qe(t,0),i=this.wr.firstAfterOrEqual(s);return C.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,C.resolve()}Cr(e,t){return this.br(e)}br(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Sr(e){const t=this.br(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y0{constructor(e){this.vr=e,this.docs=function(){return new Se(q.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,i=this.docs.get(s),r=i?i.size:0,o=this.vr(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:o}),this.size+=o-r,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return C.resolve(s?s.document.mutableCopy():Le.newInvalidDocument(t))}getEntries(e,t){let s=At();return t.forEach(i=>{const r=this.docs.get(i);s=s.insert(i,r?r.document.mutableCopy():Le.newInvalidDocument(i))}),C.resolve(s)}getDocumentsMatchingQuery(e,t,s,i){let r=At();const o=t.path,a=new q(o.child("")),l=this.docs.getIteratorFrom(a);for(;l.hasNext();){const{key:u,value:{document:h}}=l.getNext();if(!o.isPrefixOf(u.path))break;u.path.length>o.length+1||yu(tg(h),s)<=0||(i.has(h.key)||ro(t,h))&&(r=r.insert(h.key,h.mutableCopy()))}return C.resolve(r)}getAllFromCollectionGroup(e,t,s,i){G()}Fr(e,t){return C.forEach(this.docs,s=>t(s))}newChangeBuffer(e){return new v0(this)}getSize(e){return C.resolve(this.size)}}class v0 extends ay{constructor(e){super(),this.ar=e}applyChanges(e){const t=[];return this.changes.forEach((s,i)=>{i.isValidDocument()?t.push(this.ar.addEntry(e,i)):this.ar.removeEntry(s)}),C.waitFor(t)}getFromCache(e,t){return this.ar.getEntry(e,t)}getAllFromCache(e,t){return this.ar.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _0{constructor(e){this.persistence=e,this.Mr=new ts(t=>Rs(t),io),this.lastRemoteSnapshotVersion=Z.min(),this.highestTargetId=0,this.Or=0,this.Nr=new Cu,this.targetCount=0,this.Lr=Ds.Nn()}forEachTarget(e,t){return this.Mr.forEach((s,i)=>t(i)),C.resolve()}getLastRemoteSnapshotVersion(e){return C.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return C.resolve(this.Or)}allocateTargetId(e){return this.highestTargetId=this.Lr.next(),C.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.Or&&(this.Or=t),C.resolve()}qn(e){this.Mr.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Lr=new Ds(t),this.highestTargetId=t),e.sequenceNumber>this.Or&&(this.Or=e.sequenceNumber)}addTargetData(e,t){return this.qn(t),this.targetCount+=1,C.resolve()}updateTargetData(e,t){return this.qn(t),C.resolve()}removeTargetData(e,t){return this.Mr.delete(t.target),this.Nr.Vr(t.targetId),this.targetCount-=1,C.resolve()}removeTargets(e,t,s){let i=0;const r=[];return this.Mr.forEach((o,a)=>{a.sequenceNumber<=t&&s.get(a.targetId)===null&&(this.Mr.delete(o),r.push(this.removeMatchingKeysForTargetId(e,a.targetId)),i++)}),C.waitFor(r).next(()=>i)}getTargetCount(e){return C.resolve(this.targetCount)}getTargetData(e,t){const s=this.Mr.get(t)||null;return C.resolve(s)}addMatchingKeys(e,t,s){return this.Nr.dr(t,s),C.resolve()}removeMatchingKeys(e,t,s){this.Nr.Rr(t,s);const i=this.persistence.referenceDelegate,r=[];return i&&t.forEach(o=>{r.push(i.markPotentiallyOrphaned(e,o))}),C.waitFor(r)}removeMatchingKeysForTargetId(e,t){return this.Nr.Vr(t),C.resolve()}getMatchingKeysForTargetId(e,t){const s=this.Nr.gr(t);return C.resolve(s)}containsKey(e,t){return C.resolve(this.Nr.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uy{constructor(e,t){this.Br={},this.overlays={},this.kr=new It(0),this.qr=!1,this.qr=!0,this.referenceDelegate=e(this),this.Qr=new _0(this),this.indexManager=new s0,this.remoteDocumentCache=function(i){return new y0(i)}(s=>this.referenceDelegate.Kr(s)),this.serializer=new Zg(t),this.$r=new p0(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new m0,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this.Br[e.toKey()];return s||(s=new g0(t,this.referenceDelegate),this.Br[e.toKey()]=s),s}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(e,t,s){N("MemoryPersistence","Starting transaction:",e);const i=new b0(this.kr.next());return this.referenceDelegate.Ur(),s(i).next(r=>this.referenceDelegate.Wr(i).next(()=>r)).toPromise().then(r=>(i.raiseOnCommittedEvent(),r))}Gr(e,t){return C.or(Object.values(this.Br).map(s=>()=>s.containsKey(e,t)))}}class b0 extends sg{constructor(e){super(),this.currentSequenceNumber=e}}class sc{constructor(e){this.persistence=e,this.zr=new Cu,this.jr=null}static Hr(e){return new sc(e)}get Jr(){if(this.jr)return this.jr;throw G()}addReference(e,t,s){return this.zr.addReference(s,t),this.Jr.delete(s.toString()),C.resolve()}removeReference(e,t,s){return this.zr.removeReference(s,t),this.Jr.add(s.toString()),C.resolve()}markPotentiallyOrphaned(e,t){return this.Jr.add(t.toString()),C.resolve()}removeTarget(e,t){this.zr.Vr(t.targetId).forEach(i=>this.Jr.add(i.toString()));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next(i=>{i.forEach(r=>this.Jr.add(r.toString()))}).next(()=>s.removeTargetData(e,t))}Ur(){this.jr=new Set}Wr(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return C.forEach(this.Jr,s=>{const i=q.fromPath(s);return this.Yr(e,i).next(r=>{r||t.removeEntry(i,Z.min())})}).next(()=>(this.jr=null,t.apply(e)))}updateLimboDocument(e,t){return this.Yr(e,t).next(s=>{s?this.Jr.delete(t.toString()):this.Jr.add(t.toString())})}Kr(e){return 0}Yr(e,t){return C.or([()=>C.resolve(this.zr.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gr(e,t)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class w0{constructor(e){this.serializer=e}O(e,t,s,i){const r=new Ha("createOrUpgrade",t);s<1&&i>=1&&(function(l){l.createObjectStore("owner")}(e),function(l){l.createObjectStore("mutationQueues",{keyPath:"userId"}),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",lf,{unique:!0}),l.createObjectStore("documentMutations")}(e),Qf(e),function(l){l.createObjectStore("remoteDocuments")}(e));let o=C.resolve();return s<3&&i>=3&&(s!==0&&(function(l){l.deleteObjectStore("targetDocuments"),l.deleteObjectStore("targets"),l.deleteObjectStore("targetGlobal")}(e),Qf(e)),o=o.next(()=>function(l){const u=l.store("targetGlobal"),h={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:Z.min().toTimestamp(),targetCount:0};return u.put("targetGlobalKey",h)}(r))),s<4&&i>=4&&(s!==0&&(o=o.next(()=>function(l,u){return u.store("mutations").U().next(h=>{l.deleteObjectStore("mutations"),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",lf,{unique:!0});const p=u.store("mutations"),m=h.map(w=>p.put(w));return C.waitFor(m)})}(e,r))),o=o.next(()=>{(function(l){l.createObjectStore("clientMetadata",{keyPath:"clientId"})})(e)})),s<5&&i>=5&&(o=o.next(()=>this.Xr(r))),s<6&&i>=6&&(o=o.next(()=>(function(l){l.createObjectStore("remoteDocumentGlobal")}(e),this.ei(r)))),s<7&&i>=7&&(o=o.next(()=>this.ti(r))),s<8&&i>=8&&(o=o.next(()=>this.ni(e,r))),s<9&&i>=9&&(o=o.next(()=>{(function(l){l.objectStoreNames.contains("remoteDocumentChanges")&&l.deleteObjectStore("remoteDocumentChanges")})(e)})),s<10&&i>=10&&(o=o.next(()=>this.ri(r))),s<11&&i>=11&&(o=o.next(()=>{(function(l){l.createObjectStore("bundles",{keyPath:"bundleId"})})(e),function(l){l.createObjectStore("namedQueries",{keyPath:"name"})}(e)})),s<12&&i>=12&&(o=o.next(()=>{(function(l){const u=l.createObjectStore("documentOverlays",{keyPath:tT});u.createIndex("collectionPathOverlayIndex",nT,{unique:!1}),u.createIndex("collectionGroupOverlayIndex",sT,{unique:!1})})(e)})),s<13&&i>=13&&(o=o.next(()=>function(l){const u=l.createObjectStore("remoteDocumentsV14",{keyPath:zE});u.createIndex("documentKeyIndex",GE),u.createIndex("collectionGroupIndex",KE)}(e)).next(()=>this.ii(e,r)).next(()=>e.deleteObjectStore("remoteDocuments"))),s<14&&i>=14&&(o=o.next(()=>this.si(e,r))),s<15&&i>=15&&(o=o.next(()=>function(l){l.createObjectStore("indexConfiguration",{keyPath:"indexId",autoIncrement:!0}).createIndex("collectionGroupIndex","collectionGroup",{unique:!1}),l.createObjectStore("indexState",{keyPath:YE}).createIndex("sequenceNumberIndex",XE,{unique:!1}),l.createObjectStore("indexEntries",{keyPath:ZE}).createIndex("documentKeyIndex",eT,{unique:!1})}(e))),s<16&&i>=16&&(o=o.next(()=>{t.objectStore("indexState").clear()}).next(()=>{t.objectStore("indexEntries").clear()})),o}ei(e){let t=0;return e.store("remoteDocuments").J((s,i)=>{t+=Ta(i)}).next(()=>{const s={byteSize:t};return e.store("remoteDocumentGlobal").put("remoteDocumentGlobalKey",s)})}Xr(e){const t=e.store("mutationQueues"),s=e.store("mutations");return t.U().next(i=>C.forEach(i,r=>{const o=IDBKeyRange.bound([r.userId,-1],[r.userId,r.lastAcknowledgedBatchId]);return s.U("userMutationsIndex",o).next(a=>C.forEach(a,l=>{X(l.userId===r.userId);const u=hs(this.serializer,l);return iy(e,r.userId,u).next(()=>{})}))}))}ti(e){const t=e.store("targetDocuments"),s=e.store("remoteDocuments");return e.store("targetGlobal").get("targetGlobalKey").next(i=>{const r=[];return s.J((o,a)=>{const l=new be(o),u=function(p){return[0,mt(p)]}(l);r.push(t.get(u).next(h=>h?C.resolve():(p=>t.put({targetId:0,path:mt(p),sequenceNumber:i.highestListenSequenceNumber}))(l)))}).next(()=>C.waitFor(r))})}ni(e,t){e.createObjectStore("collectionParents",{keyPath:JE});const s=t.store("collectionParents"),i=new Pu,r=o=>{if(i.add(o)){const a=o.lastSegment(),l=o.popLast();return s.put({collectionId:a,parent:mt(l)})}};return t.store("remoteDocuments").J({H:!0},(o,a)=>{const l=new be(o);return r(l.popLast())}).next(()=>t.store("documentMutations").J({H:!0},([o,a,l],u)=>{const h=zt(a);return r(h.popLast())}))}ri(e){const t=e.store("targets");return t.J((s,i)=>{const r=gr(i),o=ey(this.serializer,r);return t.put(o)})}ii(e,t){const s=t.store("remoteDocuments"),i=[];return s.J((r,o)=>{const a=t.store("remoteDocumentsV14"),l=function(p){return p.document?new q(be.fromString(p.document.name).popFirst(5)):p.noDocument?q.fromSegments(p.noDocument.path):p.unknownDocument?q.fromSegments(p.unknownDocument.path):G()}(o).path.toArray(),u={prefixPath:l.slice(0,l.length-2),collectionGroup:l[l.length-2],documentId:l[l.length-1],readTime:o.readTime||[0,0],unknownDocument:o.unknownDocument,noDocument:o.noDocument,document:o.document,hasCommittedMutations:!!o.hasCommittedMutations};i.push(a.put(u))}).next(()=>C.waitFor(i))}si(e,t){const s=t.store("mutations"),i=cy(this.serializer),r=new uy(sc.Hr,this.serializer.ct);return s.U().next(o=>{const a=new Map;return o.forEach(l=>{var u;let h=(u=a.get(l.userId))!==null&&u!==void 0?u:re();hs(this.serializer,l).keys().forEach(p=>h=h.add(p)),a.set(l.userId,h)}),C.forEach(a,(l,u)=>{const h=new ct(u),p=tc.lt(this.serializer,h),m=r.getIndexManager(h),w=nc.lt(h,this.serializer,m,r.referenceDelegate);return new ly(i,w,p,m).recalculateAndSaveOverlaysForDocumentKeys(new Il(t,It.oe),l).next()})})}}function Qf(n){n.createObjectStore("targetDocuments",{keyPath:HE}).createIndex("documentTargetsIndex",QE,{unique:!0}),n.createObjectStore("targets",{keyPath:"targetId"}).createIndex("queryTargetsIndex",WE,{unique:!0}),n.createObjectStore("targetGlobal")}const Yc="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class Du{constructor(e,t,s,i,r,o,a,l,u,h,p=16){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=s,this.oi=r,this.window=o,this.document=a,this._i=u,this.ai=h,this.ui=p,this.kr=null,this.qr=!1,this.isPrimary=!1,this.networkEnabled=!0,this.ci=null,this.inForeground=!1,this.li=null,this.hi=null,this.Pi=Number.NEGATIVE_INFINITY,this.Ii=m=>Promise.resolve(),!Du.D())throw new F(V.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new u0(this,i),this.Ti=t+"main",this.serializer=new Zg(l),this.Ei=new Bn(this.Ti,this.ui,new w0(this.serializer)),this.Qr=new r0(this.referenceDelegate,this.serializer),this.remoteDocumentCache=cy(this.serializer),this.$r=new YT,this.window&&this.window.localStorage?this.di=this.window.localStorage:(this.di=null,h===!1&&Fe("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ai().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new F(V.FAILED_PRECONDITION,Yc);return this.Ri(),this.Vi(),this.mi(),this.runTransaction("getHighestListenSequenceNumber","readonly",e=>this.Qr.getHighestSequenceNumber(e))}).then(e=>{this.kr=new It(e,this._i)}).then(()=>{this.qr=!0}).catch(e=>(this.Ei&&this.Ei.close(),Promise.reject(e)))}fi(e){return this.Ii=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.Ei.L(async t=>{t.newVersion===null&&await e()})}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.oi.enqueueAndForget(async()=>{this.started&&await this.Ai()}))}Ai(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",e=>Uo(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.gi(e).next(t=>{t||(this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)))})}).next(()=>this.pi(e)).next(t=>this.isPrimary&&!t?this.yi(e).next(()=>!1):!!t&&this.wi(e).next(()=>!0))).catch(e=>{if(es(e))return N("IndexedDbPersistence","Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return N("IndexedDbPersistence","Releasing owner lease after error during lease refresh",e),!1}).then(e=>{this.isPrimary!==e&&this.oi.enqueueRetryable(()=>this.Ii(e)),this.isPrimary=e})}gi(e){return ar(e).get("owner").next(t=>C.resolve(this.Si(t)))}bi(e){return Uo(e).delete(this.clientId)}async Di(){if(this.isPrimary&&!this.Ci(this.Pi,18e5)){this.Pi=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const s=Ye(t,"clientMetadata");return s.U().next(i=>{const r=this.vi(i,18e5),o=i.filter(a=>r.indexOf(a)===-1);return C.forEach(o,a=>s.delete(a.clientId)).next(()=>o)})}).catch(()=>[]);if(this.di)for(const t of e)this.di.removeItem(this.Fi(t.clientId))}}mi(){this.hi=this.oi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Ai().then(()=>this.Di()).then(()=>this.mi()))}Si(e){return!!e&&e.ownerId===this.clientId}pi(e){return this.ai?C.resolve(!0):ar(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)){if(this.Si(t)&&this.networkEnabled)return!0;if(!this.Si(t)){if(!t.allowTabSynchronization)throw new F(V.FAILED_PRECONDITION,Yc);return!1}}return!(!this.networkEnabled||!this.inForeground)||Uo(e).U().next(s=>this.vi(s,5e3).find(i=>{if(this.clientId!==i.clientId){const r=!this.networkEnabled&&i.networkEnabled,o=!this.inForeground&&i.inForeground,a=this.networkEnabled===i.networkEnabled;if(r||o&&a)return!0}return!1})===void 0)}).next(t=>(this.isPrimary!==t&&N("IndexedDbPersistence",`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.qr=!1,this.xi(),this.hi&&(this.hi.cancel(),this.hi=null),this.Oi(),this.Ni(),await this.Ei.runTransaction("shutdown","readwrite",["owner","clientMetadata"],e=>{const t=new Il(e,It.oe);return this.yi(t).next(()=>this.bi(t))}),this.Ei.close(),this.Li()}vi(e,t){return e.filter(s=>this.Ci(s.updateTimeMs,t)&&!this.Mi(s.clientId))}Bi(){return this.runTransaction("getActiveClients","readonly",e=>Uo(e).U().next(t=>this.vi(t,18e5).map(s=>s.clientId)))}get started(){return this.qr}getMutationQueue(e,t){return nc.lt(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new i0(e,this.serializer.ct.databaseId)}getDocumentOverlayCache(e){return tc.lt(this.serializer,e)}getBundleCache(){return this.$r}runTransaction(e,t,s){N("IndexedDbPersistence","Starting transaction:",e);const i=t==="readonly"?"readonly":"readwrite",r=function(l){return l===16?rT:l===15?ug:l===14?lg:l===13?cg:l===12?iT:l===11?ag:void G()}(this.ui);let o;return this.Ei.runTransaction(e,i,r,a=>(o=new Il(a,this.kr?this.kr.next():It.oe),t==="readwrite-primary"?this.gi(o).next(l=>!!l||this.pi(o)).next(l=>{if(!l)throw Fe(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)),new F(V.FAILED_PRECONDITION,ng);return s(o)}).next(l=>this.wi(o).next(()=>l)):this.ki(o).next(()=>s(o)))).then(a=>(o.raiseOnCommittedEvent(),a))}ki(e){return ar(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)&&!this.Si(t)&&!(this.ai||this.allowTabSynchronization&&t.allowTabSynchronization))throw new F(V.FAILED_PRECONDITION,Yc)})}wi(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return ar(e).put("owner",t)}static D(){return Bn.D()}yi(e){const t=ar(e);return t.get("owner").next(s=>this.Si(s)?(N("IndexedDbPersistence","Releasing primary lease."),t.delete("owner")):C.resolve())}Ci(e,t){const s=Date.now();return!(e<s-t)&&(!(e>s)||(Fe(`Detected an update time that is in the future: ${e} > ${s}`),!1))}Ri(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.li=()=>{this.oi.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.Ai()))},this.document.addEventListener("visibilitychange",this.li),this.inForeground=this.document.visibilityState==="visible")}Oi(){this.li&&(this.document.removeEventListener("visibilitychange",this.li),this.li=null)}Vi(){var e;typeof((e=this.window)===null||e===void 0?void 0:e.addEventListener)=="function"&&(this.ci=()=>{this.xi();const t=/(?:Version|Mobile)\/1[456]/;om()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.oi.enterRestrictedMode(!0),this.oi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.ci))}Ni(){this.ci&&(this.window.removeEventListener("pagehide",this.ci),this.ci=null)}Mi(e){var t;try{const s=((t=this.di)===null||t===void 0?void 0:t.getItem(this.Fi(e)))!==null;return N("IndexedDbPersistence",`Client '${e}' ${s?"is":"is not"} zombied in LocalStorage`),s}catch(s){return Fe("IndexedDbPersistence","Failed to get zombied client id.",s),!1}}xi(){if(this.di)try{this.di.setItem(this.Fi(this.clientId),String(Date.now()))}catch(e){Fe("Failed to set zombie client id.",e)}}Li(){if(this.di)try{this.di.removeItem(this.Fi(this.clientId))}catch{}}Fi(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function ar(n){return Ye(n,"owner")}function Uo(n){return Ye(n,"clientMetadata")}function dy(n,e){let t=n.projectId;return n.isDefaultDatabase||(t+="."+n.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $u{constructor(e,t,s,i){this.targetId=e,this.fromCache=t,this.qi=s,this.Qi=i}static Ki(e,t){let s=re(),i=re();for(const r of t.docChanges)switch(r.type){case 0:s=s.add(r.doc.key);break;case 1:i=i.add(r.doc.key)}return new $u(e,t.fromCache,s,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class I0{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hy{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=function(){return om()?8:ig(ze())>0?6:4}()}initialize(e,t){this.zi=e,this.indexManager=t,this.$i=!0}getDocumentsMatchingQuery(e,t,s,i){const r={result:null};return this.ji(e,t).next(o=>{r.result=o}).next(()=>{if(!r.result)return this.Hi(e,t,i,s).next(o=>{r.result=o})}).next(()=>{if(r.result)return;const o=new I0;return this.Ji(e,t,o).next(a=>{if(r.result=a,this.Ui)return this.Yi(e,t,o,a.size)})}).next(()=>r.result)}Yi(e,t,s,i){return s.documentReadCount<this.Wi?(Ys()<=ce.DEBUG&&N("QueryEngine","SDK will not create cache indexes for query:",Xs(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),C.resolve()):(Ys()<=ce.DEBUG&&N("QueryEngine","Query:",Xs(t),"scans",s.documentReadCount,"local documents and returns",i,"documents as results."),s.documentReadCount>this.Gi*i?(Ys()<=ce.DEBUG&&N("QueryEngine","The SDK decides to create cache indexes for query:",Xs(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,St(t))):C.resolve())}ji(e,t){if(wf(t))return C.resolve(null);let s=St(t);return this.indexManager.getIndexType(e,s).next(i=>i===0?null:(t.limit!==null&&i===1&&(t=_a(t,null,"F"),s=St(t)),this.indexManager.getDocumentsMatchingTarget(e,s).next(r=>{const o=re(...r);return this.zi.getDocuments(e,o).next(a=>this.indexManager.getMinOffset(e,s).next(l=>{const u=this.Zi(t,a);return this.Xi(t,u,o,l.readTime)?this.ji(e,_a(t,null,"F")):this.es(e,u,t,l)}))})))}Hi(e,t,s,i){return wf(t)||i.isEqual(Z.min())?C.resolve(null):this.zi.getDocuments(e,s).next(r=>{const o=this.Zi(t,r);return this.Xi(t,o,s,i)?C.resolve(null):(Ys()<=ce.DEBUG&&N("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),Xs(t)),this.es(e,o,t,eg(i,-1)).next(a=>a))})}Zi(e,t){let s=new Ee(Sg(e));return t.forEach((i,r)=>{ro(e,r)&&(s=s.add(r))}),s}Xi(e,t,s,i){if(e.limit===null)return!1;if(s.size!==t.size)return!0;const r=e.limitType==="F"?t.last():t.first();return!!r&&(r.hasPendingWrites||r.version.compareTo(i)>0)}Ji(e,t,s){return Ys()<=ce.DEBUG&&N("QueryEngine","Using full collection scan to execute query:",Xs(t)),this.zi.getDocumentsMatchingQuery(e,t,Rt.min(),s)}es(e,t,s,i){return this.zi.getDocumentsMatchingQuery(e,s,i).next(r=>(t.forEach(o=>{r=r.insert(o.key,o)}),r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class E0{constructor(e,t,s,i){this.persistence=e,this.ts=t,this.serializer=i,this.ns=new Se(ne),this.rs=new ts(r=>Rs(r),io),this.ss=new Map,this.os=e.getRemoteDocumentCache(),this.Qr=e.getTargetCache(),this.$r=e.getBundleCache(),this._s(s)}_s(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new ly(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.ns))}}function fy(n,e,t,s){return new E0(n,e,t,s)}async function py(n,e){const t=W(n);return await t.persistence.runTransaction("Handle user change","readonly",s=>{let i;return t.mutationQueue.getAllMutationBatches(s).next(r=>(i=r,t._s(e),t.mutationQueue.getAllMutationBatches(s))).next(r=>{const o=[],a=[];let l=re();for(const u of i){o.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}for(const u of r){a.push(u.batchId);for(const h of u.mutations)l=l.add(h.key)}return t.localDocuments.getDocuments(s,l).next(u=>({us:u,removedBatchIds:o,addedBatchIds:a}))})})}function T0(n,e){const t=W(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",s=>{const i=e.batch.keys(),r=t.os.newChangeBuffer({trackRemovals:!0});return function(a,l,u,h){const p=u.batch,m=p.keys();let w=C.resolve();return m.forEach(E=>{w=w.next(()=>h.getEntry(l,E)).next($=>{const R=u.docVersions.get(E);X(R!==null),$.version.compareTo(R)<0&&(p.applyToRemoteDocument($,u),$.isValidDocument()&&($.setReadTime(u.commitVersion),h.addEntry($)))})}),w.next(()=>a.mutationQueue.removeMutationBatch(l,p))}(t,s,e,r).next(()=>r.apply(s)).next(()=>t.mutationQueue.performConsistencyCheck(s)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(s,i,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,function(a){let l=re();for(let u=0;u<a.mutationResults.length;++u)a.mutationResults[u].transformResults.length>0&&(l=l.add(a.batch.mutations[u].key));return l}(e))).next(()=>t.localDocuments.getDocuments(s,i))})}function my(n){const e=W(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Qr.getLastRemoteSnapshotVersion(t))}function A0(n,e){const t=W(n),s=e.snapshotVersion;let i=t.ns;return t.persistence.runTransaction("Apply remote event","readwrite-primary",r=>{const o=t.os.newChangeBuffer({trackRemovals:!0});i=t.ns;const a=[];e.targetChanges.forEach((h,p)=>{const m=i.get(p);if(!m)return;a.push(t.Qr.removeMatchingKeys(r,h.removedDocuments,p).next(()=>t.Qr.addMatchingKeys(r,h.addedDocuments,p)));let w=m.withSequenceNumber(r.currentSequenceNumber);e.targetMismatches.get(p)!==null?w=w.withResumeToken(Je.EMPTY_BYTE_STRING,Z.min()).withLastLimboFreeSnapshotVersion(Z.min()):h.resumeToken.approximateByteSize()>0&&(w=w.withResumeToken(h.resumeToken,s)),i=i.insert(p,w),function($,R,B){return $.resumeToken.approximateByteSize()===0||R.snapshotVersion.toMicroseconds()-$.snapshotVersion.toMicroseconds()>=3e8?!0:B.addedDocuments.size+B.modifiedDocuments.size+B.removedDocuments.size>0}(m,w,h)&&a.push(t.Qr.updateTargetData(r,w))});let l=At(),u=re();if(e.documentUpdates.forEach(h=>{e.resolvedLimboDocuments.has(h)&&a.push(t.persistence.referenceDelegate.updateLimboDocument(r,h))}),a.push(S0(r,o,e.documentUpdates).next(h=>{l=h.cs,u=h.ls})),!s.isEqual(Z.min())){const h=t.Qr.getLastRemoteSnapshotVersion(r).next(p=>t.Qr.setTargetsMetadata(r,r.currentSequenceNumber,s));a.push(h)}return C.waitFor(a).next(()=>o.apply(r)).next(()=>t.localDocuments.getLocalViewOfDocuments(r,l,u)).next(()=>l)}).then(r=>(t.ns=i,r))}function S0(n,e,t){let s=re(),i=re();return t.forEach(r=>s=s.add(r)),e.getEntries(n,s).next(r=>{let o=At();return t.forEach((a,l)=>{const u=r.get(a);l.isFoundDocument()!==u.isFoundDocument()&&(i=i.add(a)),l.isNoDocument()&&l.version.isEqual(Z.min())?(e.removeEntry(a,l.readTime),o=o.insert(a,l)):!u.isValidDocument()||l.version.compareTo(u.version)>0||l.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(l),o=o.insert(a,l)):N("LocalStore","Ignoring outdated watch update for ",a,". Current version:",u.version," Watch version:",l.version)}),{cs:o,ls:i}})}function k0(n,e){const t=W(n);return t.persistence.runTransaction("Get next mutation batch","readonly",s=>(e===void 0&&(e=-1),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e)))}function Aa(n,e){const t=W(n);return t.persistence.runTransaction("Allocate target","readwrite",s=>{let i;return t.Qr.getTargetData(s,e).next(r=>r?(i=r,C.resolve(i)):t.Qr.allocateTargetId(s).next(o=>(i=new dn(e,o,"TargetPurposeListen",s.currentSequenceNumber),t.Qr.addTargetData(s,i).next(()=>i))))}).then(s=>{const i=t.ns.get(s.targetId);return(i===null||s.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(t.ns=t.ns.insert(s.targetId,s),t.rs.set(e,s.targetId)),s})}async function bi(n,e,t){const s=W(n),i=s.ns.get(e),r=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",r,o=>s.persistence.referenceDelegate.removeTarget(o,i))}catch(o){if(!es(o))throw o;N("LocalStore",`Failed to update sequence numbers for target ${e}: ${o}`)}s.ns=s.ns.remove(e),s.rs.delete(i.target)}function Ol(n,e,t){const s=W(n);let i=Z.min(),r=re();return s.persistence.runTransaction("Execute query","readwrite",o=>function(l,u,h){const p=W(l),m=p.rs.get(h);return m!==void 0?C.resolve(p.ns.get(m)):p.Qr.getTargetData(u,h)}(s,o,St(e)).next(a=>{if(a)return i=a.lastLimboFreeSnapshotVersion,s.Qr.getMatchingKeysForTargetId(o,a.targetId).next(l=>{r=l})}).next(()=>s.ts.getDocumentsMatchingQuery(o,e,t?i:Z.min(),t?r:re())).next(a=>(vy(s,Ag(e),a),{documents:a,hs:r})))}function gy(n,e){const t=W(n),s=W(t.Qr),i=t.ns.get(e);return i?Promise.resolve(i.target):t.persistence.runTransaction("Get target data","readonly",r=>s.ot(r,e).next(o=>o?o.target:null))}function yy(n,e){const t=W(n),s=t.ss.get(e)||Z.min();return t.persistence.runTransaction("Get new document changes","readonly",i=>t.os.getAllFromCollectionGroup(i,e,eg(s,-1),Number.MAX_SAFE_INTEGER)).then(i=>(vy(t,e,i),i))}function vy(n,e,t){let s=n.ss.get(e)||Z.min();t.forEach((i,r)=>{r.readTime.compareTo(s)>0&&(s=r.readTime)}),n.ss.set(e,s)}function Jf(n,e){return`firestore_clients_${n}_${e}`}function Yf(n,e,t){let s=`firestore_mutations_${n}_${t}`;return e.isAuthenticated()&&(s+=`_${e.uid}`),s}function Xc(n,e){return`firestore_targets_${n}_${e}`}class Sa{constructor(e,t,s,i){this.user=e,this.batchId=t,this.state=s,this.error=i}static Es(e,t,s){const i=JSON.parse(s);let r,o=typeof i=="object"&&["pending","acknowledged","rejected"].indexOf(i.state)!==-1&&(i.error===void 0||typeof i.error=="object");return o&&i.error&&(o=typeof i.error.message=="string"&&typeof i.error.code=="string",o&&(r=new F(i.error.code,i.error.message))),o?new Sa(e,t,i.state,r):(Fe("SharedClientState",`Failed to parse mutation state for ID '${t}': ${s}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Tr{constructor(e,t,s){this.targetId=e,this.state=t,this.error=s}static Es(e,t){const s=JSON.parse(t);let i,r=typeof s=="object"&&["not-current","current","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return r&&s.error&&(r=typeof s.error.message=="string"&&typeof s.error.code=="string",r&&(i=new F(s.error.code,s.error.message))),r?new Tr(e,s.state,i):(Fe("SharedClientState",`Failed to parse target state for ID '${e}': ${t}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class ka{constructor(e,t){this.clientId=e,this.activeTargetIds=t}static Es(e,t){const s=JSON.parse(t);let i=typeof s=="object"&&s.activeTargetIds instanceof Array,r=Iu();for(let o=0;i&&o<s.activeTargetIds.length;++o)i=rg(s.activeTargetIds[o]),r=r.add(s.activeTargetIds[o]);return i?new ka(e,r):(Fe("SharedClientState",`Failed to parse client data for instance '${e}': ${t}`),null)}}class Vu{constructor(e,t){this.clientId=e,this.onlineState=t}static Es(e){const t=JSON.parse(e);return typeof t=="object"&&["Unknown","Online","Offline"].indexOf(t.onlineState)!==-1&&typeof t.clientId=="string"?new Vu(t.clientId,t.onlineState):(Fe("SharedClientState",`Failed to parse online state: ${e}`),null)}}class Ml{constructor(){this.activeTargetIds=Iu()}As(e){this.activeTargetIds=this.activeTargetIds.add(e)}Rs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ds(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class Zc{constructor(e,t,s,i,r){this.window=e,this.oi=t,this.persistenceKey=s,this.Vs=i,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.fs=this.gs.bind(this),this.ps=new Se(ne),this.started=!1,this.ys=[];const o=s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=r,this.ws=Jf(this.persistenceKey,this.Vs),this.Ss=function(l){return`firestore_sequence_number_${l}`}(this.persistenceKey),this.ps=this.ps.insert(this.Vs,new Ml),this.bs=new RegExp(`^firestore_clients_${o}_([^_]*)$`),this.Ds=new RegExp(`^firestore_mutations_${o}_(\\d+)(?:_(.*))?$`),this.Cs=new RegExp(`^firestore_targets_${o}_(\\d+)$`),this.vs=function(l){return`firestore_online_state_${l}`}(this.persistenceKey),this.Fs=function(l){return`firestore_bundle_loaded_v2_${l}`}(this.persistenceKey),this.window.addEventListener("storage",this.fs)}static D(e){return!(!e||!e.localStorage)}async start(){const e=await this.syncEngine.Bi();for(const s of e){if(s===this.Vs)continue;const i=this.getItem(Jf(this.persistenceKey,s));if(i){const r=ka.Es(s,i);r&&(this.ps=this.ps.insert(r.clientId,r))}}this.Ms();const t=this.storage.getItem(this.vs);if(t){const s=this.xs(t);s&&this.Os(s)}for(const s of this.ys)this.gs(s);this.ys=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(e){this.setItem(this.Ss,JSON.stringify(e))}getAllActiveQueryTargets(){return this.Ns(this.ps)}isActiveQueryTarget(e){let t=!1;return this.ps.forEach((s,i)=>{i.activeTargetIds.has(e)&&(t=!0)}),t}addPendingMutation(e){this.Ls(e,"pending")}updateMutationState(e,t,s){this.Ls(e,t,s),this.Bs(e)}addLocalQueryTarget(e){let t="not-current";if(this.isActiveQueryTarget(e)){const s=this.storage.getItem(Xc(this.persistenceKey,e));if(s){const i=Tr.Es(e,s);i&&(t=i.state)}}return this.ks.As(e),this.Ms(),t}removeLocalQueryTarget(e){this.ks.Rs(e),this.Ms()}isLocalQueryTarget(e){return this.ks.activeTargetIds.has(e)}clearQueryState(e){this.removeItem(Xc(this.persistenceKey,e))}updateQueryState(e,t,s){this.qs(e,t,s)}handleUserChange(e,t,s){t.forEach(i=>{this.Bs(i)}),this.currentUser=e,s.forEach(i=>{this.addPendingMutation(i)})}setOnlineState(e){this.Qs(e)}notifyBundleLoaded(e){this.Ks(e)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.fs),this.removeItem(this.ws),this.started=!1)}getItem(e){const t=this.storage.getItem(e);return N("SharedClientState","READ",e,t),t}setItem(e,t){N("SharedClientState","SET",e,t),this.storage.setItem(e,t)}removeItem(e){N("SharedClientState","REMOVE",e),this.storage.removeItem(e)}gs(e){const t=e;if(t.storageArea===this.storage){if(N("SharedClientState","EVENT",t.key,t.newValue),t.key===this.ws)return void Fe("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.oi.enqueueRetryable(async()=>{if(this.started){if(t.key!==null){if(this.bs.test(t.key)){if(t.newValue==null){const s=this.$s(t.key);return this.Us(s,null)}{const s=this.Ws(t.key,t.newValue);if(s)return this.Us(s.clientId,s)}}else if(this.Ds.test(t.key)){if(t.newValue!==null){const s=this.Gs(t.key,t.newValue);if(s)return this.zs(s)}}else if(this.Cs.test(t.key)){if(t.newValue!==null){const s=this.js(t.key,t.newValue);if(s)return this.Hs(s)}}else if(t.key===this.vs){if(t.newValue!==null){const s=this.xs(t.newValue);if(s)return this.Os(s)}}else if(t.key===this.Ss){const s=function(r){let o=It.oe;if(r!=null)try{const a=JSON.parse(r);X(typeof a=="number"),o=a}catch(a){Fe("SharedClientState","Failed to read sequence number from WebStorage",a)}return o}(t.newValue);s!==It.oe&&this.sequenceNumberHandler(s)}else if(t.key===this.Fs){const s=this.Js(t.newValue);await Promise.all(s.map(i=>this.syncEngine.Ys(i)))}}}else this.ys.push(t)})}}get ks(){return this.ps.get(this.Vs)}Ms(){this.setItem(this.ws,this.ks.ds())}Ls(e,t,s){const i=new Sa(this.currentUser,e,t,s),r=Yf(this.persistenceKey,this.currentUser,e);this.setItem(r,i.ds())}Bs(e){const t=Yf(this.persistenceKey,this.currentUser,e);this.removeItem(t)}Qs(e){const t={clientId:this.Vs,onlineState:e};this.storage.setItem(this.vs,JSON.stringify(t))}qs(e,t,s){const i=Xc(this.persistenceKey,e),r=new Tr(e,t,s);this.setItem(i,r.ds())}Ks(e){const t=JSON.stringify(Array.from(e));this.setItem(this.Fs,t)}$s(e){const t=this.bs.exec(e);return t?t[1]:null}Ws(e,t){const s=this.$s(e);return ka.Es(s,t)}Gs(e,t){const s=this.Ds.exec(e),i=Number(s[1]),r=s[2]!==void 0?s[2]:null;return Sa.Es(new ct(r),i,t)}js(e,t){const s=this.Cs.exec(e),i=Number(s[1]);return Tr.Es(i,t)}xs(e){return Vu.Es(e)}Js(e){return JSON.parse(e)}async zs(e){if(e.user.uid===this.currentUser.uid)return this.syncEngine.Zs(e.batchId,e.state,e.error);N("SharedClientState",`Ignoring mutation for non-active user ${e.user.uid}`)}Hs(e){return this.syncEngine.Xs(e.targetId,e.state,e.error)}Us(e,t){const s=t?this.ps.insert(e,t):this.ps.remove(e),i=this.Ns(this.ps),r=this.Ns(s),o=[],a=[];return r.forEach(l=>{i.has(l)||o.push(l)}),i.forEach(l=>{r.has(l)||a.push(l)}),this.syncEngine.eo(o,a).then(()=>{this.ps=s})}Os(e){this.ps.get(e.clientId)&&this.onlineStateHandler(e.onlineState)}Ns(e){let t=Iu();return e.forEach((s,i)=>{t=t.unionWith(i.activeTargetIds)}),t}}class _y{constructor(){this.no=new Ml,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e){return this.no.As(e),this.ro[e]||"not-current"}updateQueryState(e,t,s){this.ro[e]=t}removeLocalQueryTarget(e){this.no.Rs(e)}isLocalQueryTarget(e){return this.no.activeTargetIds.has(e)}clearQueryState(e){delete this.ro[e]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(e){return this.no.activeTargetIds.has(e)}start(){return this.no=new Ml,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class R0{io(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xf{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(e){this.uo.push(e)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){N("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const e of this.uo)e(0)}ao(){N("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const e of this.uo)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let qo=null;function el(){return qo===null?qo=function(){return 268435456+Math.round(2147483648*Math.random())}():qo++,"0x"+qo.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P0={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class C0{constructor(e){this.lo=e.lo,this.ho=e.ho}Po(e){this.Io=e}To(e){this.Eo=e}Ao(e){this.Ro=e}onMessage(e){this.Vo=e}close(){this.ho()}send(e){this.lo(e)}mo(){this.Io()}fo(){this.Eo()}po(e){this.Ro(e)}yo(e){this.Vo(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const at="WebChannelConnection";class D0 extends class{constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const s=t.ssl?"https":"http",i=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.wo=s+"://"+t.host,this.So=`projects/${i}/databases/${r}`,this.bo=this.databaseId.database==="(default)"?`project_id=${i}`:`project_id=${i}&database_id=${r}`}get Do(){return!1}Co(t,s,i,r,o){const a=el(),l=this.vo(t,s.toUriEncodedString());N("RestConnection",`Sending RPC '${t}' ${a}:`,l,i);const u={"google-cloud-resource-prefix":this.So,"x-goog-request-params":this.bo};return this.Fo(u,r,o),this.Mo(t,l,u,i).then(h=>(N("RestConnection",`Received RPC '${t}' ${a}: `,h),h),h=>{throw Vr("RestConnection",`RPC '${t}' ${a} failed with error: `,h,"url: ",l,"request:",i),h})}xo(t,s,i,r,o,a){return this.Co(t,s,i,r,o)}Fo(t,s,i){t["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Ni}(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),s&&s.headers.forEach((r,o)=>t[o]=r),i&&i.headers.forEach((r,o)=>t[o]=r)}vo(t,s){const i=P0[t];return`${this.wo}/v1/${s}:${i}`}terminate(){}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Mo(e,t,s,i){const r=el();return new Promise((o,a)=>{const l=new Km;l.setWithCredentials(!0),l.listenOnce(Hm.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case Jo.NO_ERROR:const h=l.getResponseJson();N(at,`XHR for RPC '${e}' ${r} received:`,JSON.stringify(h)),o(h);break;case Jo.TIMEOUT:N(at,`RPC '${e}' ${r} timed out`),a(new F(V.DEADLINE_EXCEEDED,"Request time out"));break;case Jo.HTTP_ERROR:const p=l.getStatus();if(N(at,`RPC '${e}' ${r} failed with status:`,p,"response text:",l.getResponseText()),p>0){let m=l.getResponseJson();Array.isArray(m)&&(m=m[0]);const w=m==null?void 0:m.error;if(w&&w.status&&w.message){const E=function(R){const B=R.toLowerCase().replace(/_/g,"-");return Object.values(V).indexOf(B)>=0?B:V.UNKNOWN}(w.status);a(new F(E,w.message))}else a(new F(V.UNKNOWN,"Server responded with status "+l.getStatus()))}else a(new F(V.UNAVAILABLE,"Connection failed."));break;default:G()}}finally{N(at,`RPC '${e}' ${r} completed.`)}});const u=JSON.stringify(i);N(at,`RPC '${e}' ${r} sending request:`,i),l.send(t,"POST",u,s,15)})}Oo(e,t,s){const i=el(),r=[this.wo,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=Ym(),a=Jm(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.xmlHttpFactory=new Wm({})),this.Fo(l.initMessageHeaders,t,s),l.encodeInitMessageHeaders=!0;const h=r.join("");N(at,`Creating RPC '${e}' stream ${i}: ${h}`,l);const p=o.createWebChannel(h,l);let m=!1,w=!1;const E=new C0({lo:R=>{w?N(at,`Not sending because RPC '${e}' stream ${i} is closed:`,R):(m||(N(at,`Opening RPC '${e}' stream ${i} transport.`),p.open(),m=!0),N(at,`RPC '${e}' stream ${i} sending:`,R),p.send(R))},ho:()=>p.close()}),$=(R,B,H)=>{R.listen(B,K=>{try{H(K)}catch(se){setTimeout(()=>{throw se},0)}})};return $(p,fr.EventType.OPEN,()=>{w||(N(at,`RPC '${e}' stream ${i} transport opened.`),E.mo())}),$(p,fr.EventType.CLOSE,()=>{w||(w=!0,N(at,`RPC '${e}' stream ${i} transport closed`),E.po())}),$(p,fr.EventType.ERROR,R=>{w||(w=!0,Vr(at,`RPC '${e}' stream ${i} transport errored:`,R),E.po(new F(V.UNAVAILABLE,"The operation could not be completed")))}),$(p,fr.EventType.MESSAGE,R=>{var B;if(!w){const H=R.data[0];X(!!H);const K=H,se=K.error||((B=K[0])===null||B===void 0?void 0:B.error);if(se){N(at,`RPC '${e}' stream ${i} received error:`,se);const x=se.status;let L=function(v){const I=qe[v];if(I!==void 0)return Fg(I)}(x),b=se.message;L===void 0&&(L=V.INTERNAL,b="Unknown error status: "+x+" with message "+se.message),w=!0,E.po(new F(L,b)),p.close()}else N(at,`RPC '${e}' stream ${i} received:`,H),E.yo(H)}}),$(a,Qm.STAT_EVENT,R=>{R.stat===bl.PROXY?N(at,`RPC '${e}' stream ${i} detected buffering proxy`):R.stat===bl.NOPROXY&&N(at,`RPC '${e}' stream ${i} detected no buffering proxy`)}),setTimeout(()=>{E.fo()},0),E}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function by(){return typeof window<"u"?window:null}function sa(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ic(n){return new UT(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wy{constructor(e,t,s=1e3,i=1.5,r=6e4){this.oi=e,this.timerId=t,this.No=s,this.Lo=i,this.Bo=r,this.ko=0,this.qo=null,this.Qo=Date.now(),this.reset()}reset(){this.ko=0}Ko(){this.ko=this.Bo}$o(e){this.cancel();const t=Math.floor(this.ko+this.Uo()),s=Math.max(0,Date.now()-this.Qo),i=Math.max(0,t-s);i>0&&N("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.ko} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.qo=this.oi.enqueueAfterDelay(this.timerId,i,()=>(this.Qo=Date.now(),e())),this.ko*=this.Lo,this.ko<this.No&&(this.ko=this.No),this.ko>this.Bo&&(this.ko=this.Bo)}Wo(){this.qo!==null&&(this.qo.skipDelay(),this.qo=null)}cancel(){this.qo!==null&&(this.qo.cancel(),this.qo=null)}Uo(){return(Math.random()-.5)*this.ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Iy{constructor(e,t,s,i,r,o,a,l){this.oi=e,this.Go=s,this.zo=i,this.connection=r,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=l,this.state=0,this.jo=0,this.Ho=null,this.Jo=null,this.stream=null,this.Yo=new wy(e,t)}Zo(){return this.state===1||this.state===5||this.Xo()}Xo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.e_()}async stop(){this.Zo()&&await this.close(0)}t_(){this.state=0,this.Yo.reset()}n_(){this.Xo()&&this.Ho===null&&(this.Ho=this.oi.enqueueAfterDelay(this.Go,6e4,()=>this.r_()))}i_(e){this.s_(),this.stream.send(e)}async r_(){if(this.Xo())return this.close(0)}s_(){this.Ho&&(this.Ho.cancel(),this.Ho=null)}o_(){this.Jo&&(this.Jo.cancel(),this.Jo=null)}async close(e,t){this.s_(),this.o_(),this.Yo.cancel(),this.jo++,e!==4?this.Yo.reset():t&&t.code===V.RESOURCE_EXHAUSTED?(Fe(t.toString()),Fe("Using maximum backoff delay to prevent overloading the backend."),this.Yo.Ko()):t&&t.code===V.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.__(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Ao(t)}__(){}auth(){this.state=1;const e=this.a_(this.jo),t=this.jo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([s,i])=>{this.jo===t&&this.u_(s,i)},s=>{e(()=>{const i=new F(V.UNKNOWN,"Fetching auth token failed: "+s.message);return this.c_(i)})})}u_(e,t){const s=this.a_(this.jo);this.stream=this.l_(e,t),this.stream.Po(()=>{s(()=>this.listener.Po())}),this.stream.To(()=>{s(()=>(this.state=2,this.Jo=this.oi.enqueueAfterDelay(this.zo,1e4,()=>(this.Xo()&&(this.state=3),Promise.resolve())),this.listener.To()))}),this.stream.Ao(i=>{s(()=>this.c_(i))}),this.stream.onMessage(i=>{s(()=>this.onMessage(i))})}e_(){this.state=5,this.Yo.$o(async()=>{this.state=0,this.start()})}c_(e){return N("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}a_(e){return t=>{this.oi.enqueueAndForget(()=>this.jo===e?t():(N("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class $0 extends Iy{constructor(e,t,s,i,r,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,i,o),this.serializer=r}l_(e,t){return this.connection.Oo("Listen",e,t)}onMessage(e){this.Yo.reset();const t=jT(this.serializer,e),s=function(r){if(!("targetChange"in r))return Z.min();const o=r.targetChange;return o.targetIds&&o.targetIds.length?Z.min():o.readTime?gt(o.readTime):Z.min()}(e);return this.listener.h_(t,s)}P_(e){const t={};t.database=Dl(this.serializer),t.addTarget=function(r,o){let a;const l=o.target;if(a=ya(l)?{documents:Wg(r,l)}:{query:Hg(r,l)._t},a.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){a.resumeToken=Bg(r,o.resumeToken);const u=Pl(r,o.expectedCount);u!==null&&(a.expectedCount=u)}else if(o.snapshotVersion.compareTo(Z.min())>0){a.readTime=_i(r,o.snapshotVersion.toTimestamp());const u=Pl(r,o.expectedCount);u!==null&&(a.expectedCount=u)}return a}(this.serializer,e);const s=GT(this.serializer,e);s&&(t.labels=s),this.i_(t)}I_(e){const t={};t.database=Dl(this.serializer),t.removeTarget=e,this.i_(t)}}class V0 extends Iy{constructor(e,t,s,i,r,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,i,o),this.serializer=r,this.T_=!1}get E_(){return this.T_}start(){this.T_=!1,this.lastStreamToken=void 0,super.start()}__(){this.T_&&this.d_([])}l_(e,t){return this.connection.Oo("Write",e,t)}onMessage(e){if(X(!!e.streamToken),this.lastStreamToken=e.streamToken,this.T_){this.Yo.reset();const t=zT(e.writeResults,e.commitTime),s=gt(e.commitTime);return this.listener.A_(s,t)}return X(!e.writeResults||e.writeResults.length===0),this.T_=!0,this.listener.R_()}V_(){const e={};e.database=Dl(this.serializer),this.i_(e)}d_(e){const t={streamToken:this.lastStreamToken,writes:e.map(s=>wa(this.serializer,s))};this.i_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class N0 extends class{}{constructor(e,t,s,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=i,this.m_=!1}f_(){if(this.m_)throw new F(V.FAILED_PRECONDITION,"The client has already been terminated.")}Co(e,t,s,i){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([r,o])=>this.connection.Co(e,Cl(t,s),i,r,o)).catch(r=>{throw r.name==="FirebaseError"?(r.code===V.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),r):new F(V.UNKNOWN,r.toString())})}xo(e,t,s,i,r){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,a])=>this.connection.xo(e,Cl(t,s),i,o,a,r)).catch(o=>{throw o.name==="FirebaseError"?(o.code===V.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new F(V.UNKNOWN,o.toString())})}terminate(){this.m_=!0,this.connection.terminate()}}class x0{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.g_=0,this.p_=null,this.y_=!0}w_(){this.g_===0&&(this.S_("Unknown"),this.p_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.p_=null,this.b_("Backend didn't respond within 10 seconds."),this.S_("Offline"),Promise.resolve())))}D_(e){this.state==="Online"?this.S_("Unknown"):(this.g_++,this.g_>=1&&(this.C_(),this.b_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.S_("Offline")))}set(e){this.C_(),this.g_=0,e==="Online"&&(this.y_=!1),this.S_(e)}S_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}b_(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.y_?(Fe(t),this.y_=!1):N("OnlineStateTracker",t)}C_(){this.p_!==null&&(this.p_.cancel(),this.p_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class O0{constructor(e,t,s,i,r){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.v_=[],this.F_=new Map,this.M_=new Set,this.x_=[],this.O_=r,this.O_.io(o=>{s.enqueueAndForget(async()=>{Os(this)&&(N("RemoteStore","Restarting streams for network reachability change."),await async function(l){const u=W(l);u.M_.add(4),await co(u),u.N_.set("Unknown"),u.M_.delete(4),await rc(u)}(this))})}),this.N_=new x0(s,i)}}async function rc(n){if(Os(n))for(const e of n.x_)await e(!0)}async function co(n){for(const e of n.x_)await e(!1)}function oc(n,e){const t=W(n);t.F_.has(e.targetId)||(t.F_.set(e.targetId,e),Ou(t)?xu(t):Li(t).Xo()&&Nu(t,e))}function wi(n,e){const t=W(n),s=Li(t);t.F_.delete(e),s.Xo()&&Ey(t,e),t.F_.size===0&&(s.Xo()?s.n_():Os(t)&&t.N_.set("Unknown"))}function Nu(n,e){if(n.L_.xe(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(Z.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Li(n).P_(e)}function Ey(n,e){n.L_.xe(e),Li(n).I_(e)}function xu(n){n.L_=new OT({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),ot:e=>n.F_.get(e)||null,tt:()=>n.datastore.serializer.databaseId}),Li(n).start(),n.N_.w_()}function Ou(n){return Os(n)&&!Li(n).Zo()&&n.F_.size>0}function Os(n){return W(n).M_.size===0}function Ty(n){n.L_=void 0}async function M0(n){n.N_.set("Online")}async function L0(n){n.F_.forEach((e,t)=>{Nu(n,e)})}async function F0(n,e){Ty(n),Ou(n)?(n.N_.D_(e),xu(n)):n.N_.set("Unknown")}async function U0(n,e,t){if(n.N_.set("Online"),e instanceof qg&&e.state===2&&e.cause)try{await async function(i,r){const o=r.cause;for(const a of r.targetIds)i.F_.has(a)&&(await i.remoteSyncer.rejectListen(a,o),i.F_.delete(a),i.L_.removeTarget(a))}(n,e)}catch(s){N("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),s),await Ra(n,s)}else if(e instanceof na?n.L_.Ke(e):e instanceof Ug?n.L_.He(e):n.L_.We(e),!t.isEqual(Z.min()))try{const s=await my(n.localStore);t.compareTo(s)>=0&&await function(r,o){const a=r.L_.rt(o);return a.targetChanges.forEach((l,u)=>{if(l.resumeToken.approximateByteSize()>0){const h=r.F_.get(u);h&&r.F_.set(u,h.withResumeToken(l.resumeToken,o))}}),a.targetMismatches.forEach((l,u)=>{const h=r.F_.get(l);if(!h)return;r.F_.set(l,h.withResumeToken(Je.EMPTY_BYTE_STRING,h.snapshotVersion)),Ey(r,l);const p=new dn(h.target,l,u,h.sequenceNumber);Nu(r,p)}),r.remoteSyncer.applyRemoteEvent(a)}(n,t)}catch(s){N("RemoteStore","Failed to raise snapshot:",s),await Ra(n,s)}}async function Ra(n,e,t){if(!es(e))throw e;n.M_.add(1),await co(n),n.N_.set("Offline"),t||(t=()=>my(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{N("RemoteStore","Retrying IndexedDB access"),await t(),n.M_.delete(1),await rc(n)})}function Ay(n,e){return e().catch(t=>Ra(n,t,e))}async function Mi(n){const e=W(n),t=Jn(e);let s=e.v_.length>0?e.v_[e.v_.length-1].batchId:-1;for(;q0(e);)try{const i=await k0(e.localStore,s);if(i===null){e.v_.length===0&&t.n_();break}s=i.batchId,B0(e,i)}catch(i){await Ra(e,i)}Sy(e)&&ky(e)}function q0(n){return Os(n)&&n.v_.length<10}function B0(n,e){n.v_.push(e);const t=Jn(n);t.Xo()&&t.E_&&t.d_(e.mutations)}function Sy(n){return Os(n)&&!Jn(n).Zo()&&n.v_.length>0}function ky(n){Jn(n).start()}async function j0(n){Jn(n).V_()}async function z0(n){const e=Jn(n);for(const t of n.v_)e.d_(t.mutations)}async function G0(n,e,t){const s=n.v_.shift(),i=Tu.from(s,e,t);await Ay(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await Mi(n)}async function K0(n,e){e&&Jn(n).E_&&await async function(s,i){if(function(o){return VT(o)&&o!==V.ABORTED}(i.code)){const r=s.v_.shift();Jn(s).t_(),await Ay(s,()=>s.remoteSyncer.rejectFailedWrite(r.batchId,i)),await Mi(s)}}(n,e),Sy(n)&&ky(n)}async function Zf(n,e){const t=W(n);t.asyncQueue.verifyOperationInProgress(),N("RemoteStore","RemoteStore received new credentials");const s=Os(t);t.M_.add(3),await co(t),s&&t.N_.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.M_.delete(3),await rc(t)}async function Ll(n,e){const t=W(n);e?(t.M_.delete(2),await rc(t)):e||(t.M_.add(2),await co(t),t.N_.set("Unknown"))}function Li(n){return n.B_||(n.B_=function(t,s,i){const r=W(t);return r.f_(),new $0(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:M0.bind(null,n),To:L0.bind(null,n),Ao:F0.bind(null,n),h_:U0.bind(null,n)}),n.x_.push(async e=>{e?(n.B_.t_(),Ou(n)?xu(n):n.N_.set("Unknown")):(await n.B_.stop(),Ty(n))})),n.B_}function Jn(n){return n.k_||(n.k_=function(t,s,i){const r=W(t);return r.f_(),new V0(s,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,i)}(n.datastore,n.asyncQueue,{Po:()=>Promise.resolve(),To:j0.bind(null,n),Ao:K0.bind(null,n),R_:z0.bind(null,n),A_:G0.bind(null,n)}),n.x_.push(async e=>{e?(n.k_.t_(),await Mi(n)):(await n.k_.stop(),n.v_.length>0&&(N("RemoteStore",`Stopping write stream with ${n.v_.length} pending writes`),n.v_=[]))})),n.k_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mu{constructor(e,t,s,i,r){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=i,this.removalCallback=r,this.deferred=new fn,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,i,r){const o=Date.now()+s,a=new Mu(e,t,o,i,r);return a.start(s),a}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new F(V.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Lu(n,e){if(Fe("AsyncQueue",`${e}: ${n}`),es(n))return new F(V.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ai{constructor(e){this.comparator=e?(t,s)=>e(t,s)||q.comparator(t.key,s.key):(t,s)=>q.comparator(t.key,s.key),this.keyedMap=pr(),this.sortedSet=new Se(this.comparator)}static emptySet(e){return new ai(e.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,s)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof ai)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const i=t.getNext().key,r=s.getNext().key;if(!i.isEqual(r))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new ai;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ep{constructor(){this.q_=new Se(q.comparator)}track(e){const t=e.doc.key,s=this.q_.get(t);s?e.type!==0&&s.type===3?this.q_=this.q_.insert(t,e):e.type===3&&s.type!==1?this.q_=this.q_.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.q_=this.q_.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.q_=this.q_.remove(t):e.type===1&&s.type===2?this.q_=this.q_.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):G():this.q_=this.q_.insert(t,e)}Q_(){const e=[];return this.q_.inorderTraversal((t,s)=>{e.push(s)}),e}}class Ii{constructor(e,t,s,i,r,o,a,l,u){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=i,this.mutatedKeys=r,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=l,this.hasCachedResults=u}static fromInitialDocuments(e,t,s,i,r){const o=[];return t.forEach(a=>{o.push({type:0,doc:a})}),new Ii(e,t,ai.emptySet(t),o,s,i,!0,!1,r)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&Ya(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==s[i].type||!t[i].doc.isEqual(s[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W0{constructor(){this.K_=void 0,this.U_=[]}W_(){return this.U_.some(e=>e.G_())}}class H0{constructor(){this.queries=new ts(e=>Tg(e),Ya),this.onlineState="Unknown",this.z_=new Set}}async function Ry(n,e){const t=W(n);let s=3;const i=e.query;let r=t.queries.get(i);r?!r.W_()&&e.G_()&&(s=2):(r=new W0,s=e.G_()?0:1);try{switch(s){case 0:r.K_=await t.onListen(i,!0);break;case 1:r.K_=await t.onListen(i,!1);break;case 2:await t.onFirstRemoteStoreListen(i)}}catch(o){const a=Lu(o,`Initialization of query '${Xs(e.query)}' failed`);return void e.onError(a)}t.queries.set(i,r),r.U_.push(e),e.j_(t.onlineState),r.K_&&e.H_(r.K_)&&Fu(t)}async function Py(n,e){const t=W(n),s=e.query;let i=3;const r=t.queries.get(s);if(r){const o=r.U_.indexOf(e);o>=0&&(r.U_.splice(o,1),r.U_.length===0?i=e.G_()?0:1:!r.W_()&&e.G_()&&(i=2))}switch(i){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function Q0(n,e){const t=W(n);let s=!1;for(const i of e){const r=i.query,o=t.queries.get(r);if(o){for(const a of o.U_)a.H_(i)&&(s=!0);o.K_=i}}s&&Fu(t)}function J0(n,e,t){const s=W(n),i=s.queries.get(e);if(i)for(const r of i.U_)r.onError(t);s.queries.delete(e)}function Fu(n){n.z_.forEach(e=>{e.next()})}var Fl,tp;(tp=Fl||(Fl={})).J_="default",tp.Cache="cache";class Cy{constructor(e,t,s){this.query=e,this.Y_=t,this.Z_=!1,this.X_=null,this.onlineState="Unknown",this.options=s||{}}H_(e){if(!this.options.includeMetadataChanges){const s=[];for(const i of e.docChanges)i.type!==3&&s.push(i);e=new Ii(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Z_?this.ea(e)&&(this.Y_.next(e),t=!0):this.ta(e,this.onlineState)&&(this.na(e),t=!0),this.X_=e,t}onError(e){this.Y_.error(e)}j_(e){this.onlineState=e;let t=!1;return this.X_&&!this.Z_&&this.ta(this.X_,e)&&(this.na(this.X_),t=!0),t}ta(e,t){if(!e.fromCache||!this.G_())return!0;const s=t!=="Offline";return(!this.options.ra||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}ea(e){if(e.docChanges.length>0)return!0;const t=this.X_&&this.X_.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}na(e){e=Ii.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Z_=!0,this.Y_.next(e)}G_(){return this.options.source!==Fl.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dy{constructor(e){this.key=e}}class $y{constructor(e){this.key=e}}class Y0{constructor(e,t){this.query=e,this.la=t,this.ha=null,this.hasCachedResults=!1,this.current=!1,this.Pa=re(),this.mutatedKeys=re(),this.Ia=Sg(e),this.Ta=new ai(this.Ia)}get Ea(){return this.la}da(e,t){const s=t?t.Aa:new ep,i=t?t.Ta:this.Ta;let r=t?t.mutatedKeys:this.mutatedKeys,o=i,a=!1;const l=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,u=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((h,p)=>{const m=i.get(h),w=ro(this.query,p)?p:null,E=!!m&&this.mutatedKeys.has(m.key),$=!!w&&(w.hasLocalMutations||this.mutatedKeys.has(w.key)&&w.hasCommittedMutations);let R=!1;m&&w?m.data.isEqual(w.data)?E!==$&&(s.track({type:3,doc:w}),R=!0):this.Ra(m,w)||(s.track({type:2,doc:w}),R=!0,(l&&this.Ia(w,l)>0||u&&this.Ia(w,u)<0)&&(a=!0)):!m&&w?(s.track({type:0,doc:w}),R=!0):m&&!w&&(s.track({type:1,doc:m}),R=!0,(l||u)&&(a=!0)),R&&(w?(o=o.add(w),r=$?r.add(h):r.delete(h)):(o=o.delete(h),r=r.delete(h)))}),this.query.limit!==null)for(;o.size>this.query.limit;){const h=this.query.limitType==="F"?o.last():o.first();o=o.delete(h.key),r=r.delete(h.key),s.track({type:1,doc:h})}return{Ta:o,Aa:s,Xi:a,mutatedKeys:r}}Ra(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,i){const r=this.Ta;this.Ta=e.Ta,this.mutatedKeys=e.mutatedKeys;const o=e.Aa.Q_();o.sort((h,p)=>function(w,E){const $=R=>{switch(R){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return G()}};return $(w)-$(E)}(h.type,p.type)||this.Ia(h.doc,p.doc)),this.Va(s),i=i!=null&&i;const a=t&&!i?this.ma():[],l=this.Pa.size===0&&this.current&&!i?1:0,u=l!==this.ha;return this.ha=l,o.length!==0||u?{snapshot:new Ii(this.query,e.Ta,r,o,e.mutatedKeys,l===0,u,!1,!!s&&s.resumeToken.approximateByteSize()>0),fa:a}:{fa:a}}j_(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Ta:this.Ta,Aa:new ep,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{fa:[]}}ga(e){return!this.la.has(e)&&!!this.Ta.has(e)&&!this.Ta.get(e).hasLocalMutations}Va(e){e&&(e.addedDocuments.forEach(t=>this.la=this.la.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.la=this.la.delete(t)),this.current=e.current)}ma(){if(!this.current)return[];const e=this.Pa;this.Pa=re(),this.Ta.forEach(s=>{this.ga(s.key)&&(this.Pa=this.Pa.add(s.key))});const t=[];return e.forEach(s=>{this.Pa.has(s)||t.push(new $y(s))}),this.Pa.forEach(s=>{e.has(s)||t.push(new Dy(s))}),t}pa(e){this.la=e.hs,this.Pa=re();const t=this.da(e.documents);return this.applyChanges(t,!0)}ya(){return Ii.fromInitialDocuments(this.query,this.Ta,this.mutatedKeys,this.ha===0,this.hasCachedResults)}}class X0{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class Z0{constructor(e){this.key=e,this.wa=!1}}class eA{constructor(e,t,s,i,r,o){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=i,this.currentUser=r,this.maxConcurrentLimboResolutions=o,this.Sa={},this.ba=new ts(a=>Tg(a),Ya),this.Da=new Map,this.Ca=new Set,this.va=new Se(q.comparator),this.Fa=new Map,this.Ma=new Cu,this.xa={},this.Oa=new Map,this.Na=Ds.Ln(),this.onlineState="Unknown",this.La=void 0}get isPrimaryClient(){return this.La===!0}}async function tA(n,e,t=!0){const s=ac(n);let i;const r=s.ba.get(e);return r?(s.sharedClientState.addLocalQueryTarget(r.targetId),i=r.view.ya()):i=await Vy(s,e,t,!0),i}async function nA(n,e){const t=ac(n);await Vy(t,e,!0,!1)}async function Vy(n,e,t,s){const i=await Aa(n.localStore,St(e)),r=i.targetId,o=t?n.sharedClientState.addLocalQueryTarget(r):"not-current";let a;return s&&(a=await Uu(n,e,r,o==="current",i.resumeToken)),n.isPrimaryClient&&t&&oc(n.remoteStore,i),a}async function Uu(n,e,t,s,i){n.Ba=(p,m,w)=>async function($,R,B,H){let K=R.view.da(B);K.Xi&&(K=await Ol($.localStore,R.query,!1).then(({documents:b})=>R.view.da(b,K)));const se=H&&H.targetChanges.get(R.targetId),x=H&&H.targetMismatches.get(R.targetId)!=null,L=R.view.applyChanges(K,$.isPrimaryClient,se,x);return Ul($,R.targetId,L.fa),L.snapshot}(n,p,m,w);const r=await Ol(n.localStore,e,!0),o=new Y0(e,r.hs),a=o.da(r.documents),l=ao.createSynthesizedTargetChangeForCurrentChange(t,s&&n.onlineState!=="Offline",i),u=o.applyChanges(a,n.isPrimaryClient,l);Ul(n,t,u.fa);const h=new X0(e,t,o);return n.ba.set(e,h),n.Da.has(t)?n.Da.get(t).push(e):n.Da.set(t,[e]),u.snapshot}async function sA(n,e,t){const s=W(n),i=s.ba.get(e),r=s.Da.get(i.targetId);if(r.length>1)return s.Da.set(i.targetId,r.filter(o=>!Ya(o,e))),void s.ba.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(i.targetId),s.sharedClientState.isActiveQueryTarget(i.targetId)||await bi(s.localStore,i.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(i.targetId),t&&wi(s.remoteStore,i.targetId),Ei(s,i.targetId)}).catch(Zn)):(Ei(s,i.targetId),await bi(s.localStore,i.targetId,!0))}async function iA(n,e){const t=W(n),s=t.ba.get(e),i=t.Da.get(s.targetId);t.isPrimaryClient&&i.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),wi(t.remoteStore,s.targetId))}async function rA(n,e,t){const s=zu(n);try{const i=await function(o,a){const l=W(o),u=Ne.now(),h=a.reduce((w,E)=>w.add(E.key),re());let p,m;return l.persistence.runTransaction("Locally write mutations","readwrite",w=>{let E=At(),$=re();return l.os.getEntries(w,h).next(R=>{E=R,E.forEach((B,H)=>{H.isValidDocument()||($=$.add(B))})}).next(()=>l.localDocuments.getOverlayedDocuments(w,E)).next(R=>{p=R;const B=[];for(const H of a){const K=DT(H,p.get(H.key).overlayedDocument);K!=null&&B.push(new vn(H.key,K,pg(K.value.mapValue),pt.exists(!0)))}return l.mutationQueue.addMutationBatch(w,u,B,a)}).next(R=>{m=R;const B=R.applyToLocalDocumentSet(p,$);return l.documentOverlayCache.saveOverlays(w,R.batchId,B)})}).then(()=>({batchId:m.batchId,changes:Rg(p)}))}(s.localStore,e);s.sharedClientState.addPendingMutation(i.batchId),function(o,a,l){let u=o.xa[o.currentUser.toKey()];u||(u=new Se(ne)),u=u.insert(a,l),o.xa[o.currentUser.toKey()]=u}(s,i.batchId,t),await ns(s,i.changes),await Mi(s.remoteStore)}catch(i){const r=Lu(i,"Failed to persist write");t.reject(r)}}async function Ny(n,e){const t=W(n);try{const s=await A0(t.localStore,e);e.targetChanges.forEach((i,r)=>{const o=t.Fa.get(r);o&&(X(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1),i.addedDocuments.size>0?o.wa=!0:i.modifiedDocuments.size>0?X(o.wa):i.removedDocuments.size>0&&(X(o.wa),o.wa=!1))}),await ns(t,s,e)}catch(s){await Zn(s)}}function np(n,e,t){const s=W(n);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const i=[];s.ba.forEach((r,o)=>{const a=o.view.j_(e);a.snapshot&&i.push(a.snapshot)}),function(o,a){const l=W(o);l.onlineState=a;let u=!1;l.queries.forEach((h,p)=>{for(const m of p.U_)m.j_(a)&&(u=!0)}),u&&Fu(l)}(s.eventManager,e),i.length&&s.Sa.h_(i),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function oA(n,e,t){const s=W(n);s.sharedClientState.updateQueryState(e,"rejected",t);const i=s.Fa.get(e),r=i&&i.key;if(r){let o=new Se(q.comparator);o=o.insert(r,Le.newNoDocument(r,Z.min()));const a=re().add(r),l=new oo(Z.min(),new Map,new Se(ne),o,a);await Ny(s,l),s.va=s.va.remove(r),s.Fa.delete(e),ju(s)}else await bi(s.localStore,e,!1).then(()=>Ei(s,e,t)).catch(Zn)}async function aA(n,e){const t=W(n),s=e.batch.batchId;try{const i=await T0(t.localStore,e);Bu(t,s,null),qu(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await ns(t,i)}catch(i){await Zn(i)}}async function cA(n,e,t){const s=W(n);try{const i=await function(o,a){const l=W(o);return l.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let h;return l.mutationQueue.lookupMutationBatch(u,a).next(p=>(X(p!==null),h=p.keys(),l.mutationQueue.removeMutationBatch(u,p))).next(()=>l.mutationQueue.performConsistencyCheck(u)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(u,h,a)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,h)).next(()=>l.localDocuments.getDocuments(u,h))})}(s.localStore,e);Bu(s,e,t),qu(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await ns(s,i)}catch(i){await Zn(i)}}function qu(n,e){(n.Oa.get(e)||[]).forEach(t=>{t.resolve()}),n.Oa.delete(e)}function Bu(n,e,t){const s=W(n);let i=s.xa[s.currentUser.toKey()];if(i){const r=i.get(e);r&&(t?r.reject(t):r.resolve(),i=i.remove(e)),s.xa[s.currentUser.toKey()]=i}}function Ei(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const s of n.Da.get(e))n.ba.delete(s),t&&n.Sa.ka(s,t);n.Da.delete(e),n.isPrimaryClient&&n.Ma.Vr(e).forEach(s=>{n.Ma.containsKey(s)||xy(n,s)})}function xy(n,e){n.Ca.delete(e.path.canonicalString());const t=n.va.get(e);t!==null&&(wi(n.remoteStore,t),n.va=n.va.remove(e),n.Fa.delete(t),ju(n))}function Ul(n,e,t){for(const s of t)s instanceof Dy?(n.Ma.addReference(s.key,e),lA(n,s)):s instanceof $y?(N("SyncEngine","Document no longer in limbo: "+s.key),n.Ma.removeReference(s.key,e),n.Ma.containsKey(s.key)||xy(n,s.key)):G()}function lA(n,e){const t=e.key,s=t.path.canonicalString();n.va.get(t)||n.Ca.has(s)||(N("SyncEngine","New document in limbo: "+t),n.Ca.add(s),ju(n))}function ju(n){for(;n.Ca.size>0&&n.va.size<n.maxConcurrentLimboResolutions;){const e=n.Ca.values().next().value;n.Ca.delete(e);const t=new q(be.fromString(e)),s=n.Na.next();n.Fa.set(s,new Z0(t)),n.va=n.va.insert(t,s),oc(n.remoteStore,new dn(St(Ja(t.path)),s,"TargetPurposeLimboResolution",It.oe))}}async function ns(n,e,t){const s=W(n),i=[],r=[],o=[];s.ba.isEmpty()||(s.ba.forEach((a,l)=>{o.push(s.Ba(l,e,t).then(u=>{if((u||t)&&s.isPrimaryClient){const h=u&&!u.fromCache;s.sharedClientState.updateQueryState(l.targetId,h?"current":"not-current")}if(u){i.push(u);const h=$u.Ki(l.targetId,u);r.push(h)}}))}),await Promise.all(o),s.Sa.h_(i),await async function(l,u){const h=W(l);try{await h.persistence.runTransaction("notifyLocalViewChanges","readwrite",p=>C.forEach(u,m=>C.forEach(m.qi,w=>h.persistence.referenceDelegate.addReference(p,m.targetId,w)).next(()=>C.forEach(m.Qi,w=>h.persistence.referenceDelegate.removeReference(p,m.targetId,w)))))}catch(p){if(!es(p))throw p;N("LocalStore","Failed to update sequence numbers: "+p)}for(const p of u){const m=p.targetId;if(!p.fromCache){const w=h.ns.get(m),E=w.snapshotVersion,$=w.withLastLimboFreeSnapshotVersion(E);h.ns=h.ns.insert(m,$)}}}(s.localStore,r))}async function uA(n,e){const t=W(n);if(!t.currentUser.isEqual(e)){N("SyncEngine","User change. New user:",e.toKey());const s=await py(t.localStore,e);t.currentUser=e,function(r,o){r.Oa.forEach(a=>{a.forEach(l=>{l.reject(new F(V.CANCELLED,o))})}),r.Oa.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await ns(t,s.us)}}function dA(n,e){const t=W(n),s=t.Fa.get(e);if(s&&s.wa)return re().add(s.key);{let i=re();const r=t.Da.get(e);if(!r)return i;for(const o of r){const a=t.ba.get(o);i=i.unionWith(a.view.Ea)}return i}}async function hA(n,e){const t=W(n),s=await Ol(t.localStore,e.query,!0),i=e.view.pa(s);return t.isPrimaryClient&&Ul(t,e.targetId,i.fa),i}async function fA(n,e){const t=W(n);return yy(t.localStore,e).then(s=>ns(t,s))}async function pA(n,e,t,s){const i=W(n),r=await function(a,l){const u=W(a),h=W(u.mutationQueue);return u.persistence.runTransaction("Lookup mutation documents","readonly",p=>h.vn(p,l).next(m=>m?u.localDocuments.getDocuments(p,m):C.resolve(null)))}(i.localStore,e);r!==null?(t==="pending"?await Mi(i.remoteStore):t==="acknowledged"||t==="rejected"?(Bu(i,e,s||null),qu(i,e),function(a,l){W(W(a).mutationQueue).Mn(l)}(i.localStore,e)):G(),await ns(i,r)):N("SyncEngine","Cannot apply mutation batch with id: "+e)}async function mA(n,e){const t=W(n);if(ac(t),zu(t),e===!0&&t.La!==!0){const s=t.sharedClientState.getAllActiveQueryTargets(),i=await sp(t,s.toArray());t.La=!0,await Ll(t.remoteStore,!0);for(const r of i)oc(t.remoteStore,r)}else if(e===!1&&t.La!==!1){const s=[];let i=Promise.resolve();t.Da.forEach((r,o)=>{t.sharedClientState.isLocalQueryTarget(o)?s.push(o):i=i.then(()=>(Ei(t,o),bi(t.localStore,o,!0))),wi(t.remoteStore,o)}),await i,await sp(t,s),function(o){const a=W(o);a.Fa.forEach((l,u)=>{wi(a.remoteStore,u)}),a.Ma.mr(),a.Fa=new Map,a.va=new Se(q.comparator)}(t),t.La=!1,await Ll(t.remoteStore,!1)}}async function sp(n,e,t){const s=W(n),i=[],r=[];for(const o of e){let a;const l=s.Da.get(o);if(l&&l.length!==0){a=await Aa(s.localStore,St(l[0]));for(const u of l){const h=s.ba.get(u),p=await hA(s,h);p.snapshot&&r.push(p.snapshot)}}else{const u=await gy(s.localStore,o);a=await Aa(s.localStore,u),await Uu(s,Oy(u),o,!1,a.resumeToken)}i.push(a)}return s.Sa.h_(r),i}function Oy(n){return Ig(n.path,n.collectionGroup,n.orderBy,n.filters,n.limit,"F",n.startAt,n.endAt)}function gA(n){return function(t){return W(W(t).persistence).Bi()}(W(n).localStore)}async function yA(n,e,t,s){const i=W(n);if(i.La)return void N("SyncEngine","Ignoring unexpected query state notification.");const r=i.Da.get(e);if(r&&r.length>0)switch(t){case"current":case"not-current":{const o=await yy(i.localStore,Ag(r[0])),a=oo.createSynthesizedRemoteEventForCurrentChange(e,t==="current",Je.EMPTY_BYTE_STRING);await ns(i,o,a);break}case"rejected":await bi(i.localStore,e,!0),Ei(i,e,s);break;default:G()}}async function vA(n,e,t){const s=ac(n);if(s.La){for(const i of e){if(s.Da.has(i)&&s.sharedClientState.isActiveQueryTarget(i)){N("SyncEngine","Adding an already active target "+i);continue}const r=await gy(s.localStore,i),o=await Aa(s.localStore,r);await Uu(s,Oy(r),o.targetId,!1,o.resumeToken),oc(s.remoteStore,o)}for(const i of t)s.Da.has(i)&&await bi(s.localStore,i,!1).then(()=>{wi(s.remoteStore,i),Ei(s,i)}).catch(Zn)}}function ac(n){const e=W(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Ny.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=dA.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=oA.bind(null,e),e.Sa.h_=Q0.bind(null,e.eventManager),e.Sa.ka=J0.bind(null,e.eventManager),e}function zu(n){const e=W(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=aA.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=cA.bind(null,e),e}class ql{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=ic(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){return fy(this.persistence,new hy,e.initialUser,this.serializer)}createPersistence(e){return new uy(sc.Hr,this.serializer)}createSharedClientState(e){return new _y}async terminate(){var e,t;(e=this.gcScheduler)===null||e===void 0||e.stop(),(t=this.indexBackfillerScheduler)===null||t===void 0||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class My extends ql{constructor(e,t,s){super(),this.Qa=e,this.cacheSizeBytes=t,this.forceOwnership=s,this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Qa.initialize(this,e),await zu(this.Qa.syncEngine),await Mi(this.Qa.remoteStore),await this.persistence.fi(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}createLocalStore(e){return fy(this.persistence,new hy,e.initialUser,this.serializer)}createGarbageCollectionScheduler(e,t){const s=this.persistence.referenceDelegate.garbageCollector;return new a0(s,e.asyncQueue,t)}createIndexBackfillerScheduler(e,t){const s=new qE(t,this.persistence);return new UE(e.asyncQueue,s)}createPersistence(e){const t=dy(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),s=this.cacheSizeBytes!==void 0?bt.withCacheSize(this.cacheSizeBytes):bt.DEFAULT;return new Du(this.synchronizeTabs,t,e.clientId,s,e.asyncQueue,by(),sa(),this.serializer,this.sharedClientState,!!this.forceOwnership)}createSharedClientState(e){return new _y}}class _A extends My{constructor(e,t){super(e,t,!1),this.Qa=e,this.cacheSizeBytes=t,this.synchronizeTabs=!0}async initialize(e){await super.initialize(e);const t=this.Qa.syncEngine;this.sharedClientState instanceof Zc&&(this.sharedClientState.syncEngine={Zs:pA.bind(null,t),Xs:yA.bind(null,t),eo:vA.bind(null,t),Bi:gA.bind(null,t),Ys:fA.bind(null,t)},await this.sharedClientState.start()),await this.persistence.fi(async s=>{await mA(this.Qa.syncEngine,s),this.gcScheduler&&(s&&!this.gcScheduler.started?this.gcScheduler.start():s||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(s&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():s||this.indexBackfillerScheduler.stop())})}createSharedClientState(e){const t=by();if(!Zc.D(t))throw new F(V.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const s=dy(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey);return new Zc(t,e.asyncQueue,s,e.clientId,e.initialUser)}}class Gu{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>np(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=uA.bind(null,this.syncEngine),await Ll(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new H0}()}createDatastore(e){const t=ic(e.databaseInfo.databaseId),s=function(r){return new D0(r)}(e.databaseInfo);return function(r,o,a,l){return new N0(r,o,a,l)}(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return function(s,i,r,o,a){return new O0(s,i,r,o,a)}(this.localStore,this.datastore,e.asyncQueue,t=>np(this.syncEngine,t,0),function(){return Xf.D()?new Xf:new R0}())}createSyncEngine(e,t){return function(i,r,o,a,l,u,h){const p=new eA(i,r,o,a,l,u);return h&&(p.La=!0),p}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e;await async function(s){const i=W(s);N("RemoteStore","RemoteStore shutting down."),i.M_.add(5),await co(i),i.O_.shutdown(),i.N_.set("Unknown")}(this.remoteStore),(e=this.datastore)===null||e===void 0||e.terminate()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ly{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Ka(this.observer.next,e)}error(e){this.observer.error?this.Ka(this.observer.error,e):Fe("Uncaught Error in snapshot listener:",e.toString())}$a(){this.muted=!0}Ka(e,t){this.muted||setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bA{constructor(e,t,s,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this.databaseInfo=i,this.user=ct.UNAUTHENTICATED,this.clientId=Xm.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(s,async r=>{N("FirestoreClient","Received user=",r.uid),await this.authCredentialListener(r),this.user=r}),this.appCheckCredentials.start(s,r=>(N("FirestoreClient","Received new app check token=",r),this.appCheckCredentialListener(r,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new F(V.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const e=new fn;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=Lu(t,"Failed to shutdown persistence");e.reject(s)}}),e.promise}}async function tl(n,e){n.asyncQueue.verifyOperationInProgress(),N("FirestoreClient","Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let s=t.initialUser;n.setCredentialChangeListener(async i=>{s.isEqual(i)||(await py(e.localStore,i),s=i)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function ip(n,e){n.asyncQueue.verifyOperationInProgress();const t=await IA(n);N("FirestoreClient","Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(s=>Zf(e.remoteStore,s)),n.setAppCheckTokenChangeListener((s,i)=>Zf(e.remoteStore,i)),n._onlineComponents=e}function wA(n){return n.name==="FirebaseError"?n.code===V.FAILED_PRECONDITION||n.code===V.UNIMPLEMENTED:!(typeof DOMException<"u"&&n instanceof DOMException)||n.code===22||n.code===20||n.code===11}async function IA(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){N("FirestoreClient","Using user provided OfflineComponentProvider");try{await tl(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!wA(t))throw t;Vr("Error using user provided cache. Falling back to memory cache: "+t),await tl(n,new ql)}}else N("FirestoreClient","Using default OfflineComponentProvider"),await tl(n,new ql);return n._offlineComponents}async function Fy(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(N("FirestoreClient","Using user provided OnlineComponentProvider"),await ip(n,n._uninitializedComponentsProvider._online)):(N("FirestoreClient","Using default OnlineComponentProvider"),await ip(n,new Gu))),n._onlineComponents}function EA(n){return Fy(n).then(e=>e.syncEngine)}async function Bl(n){const e=await Fy(n),t=e.eventManager;return t.onListen=tA.bind(null,e.syncEngine),t.onUnlisten=sA.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=nA.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=iA.bind(null,e.syncEngine),t}function TA(n,e,t={}){const s=new fn;return n.asyncQueue.enqueueAndForget(async()=>function(r,o,a,l,u){const h=new Ly({next:m=>{o.enqueueAndForget(()=>Py(r,p)),m.fromCache&&l.source==="server"?u.reject(new F(V.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):u.resolve(m)},error:m=>u.reject(m)}),p=new Cy(a,h,{includeMetadataChanges:!0,ra:!0});return Ry(r,p)}(await Bl(n),n.asyncQueue,e,t,s)),s.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uy(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rp=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qy(n,e,t){if(!t)throw new F(V.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function AA(n,e,t,s){if(e===!0&&s===!0)throw new F(V.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function op(n){if(!q.isDocumentKey(n))throw new F(V.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function ap(n){if(q.isDocumentKey(n))throw new F(V.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function cc(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(s){return s.constructor?s.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":G()}function Qt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new F(V.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=cc(n);throw new F(V.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cp{constructor(e){var t,s;if(e.host===void 0){if(e.ssl!==void 0)throw new F(V.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(t=e.ssl)===null||t===void 0||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new F(V.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}AA("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Uy((s=e.experimentalLongPollingOptions)!==null&&s!==void 0?s:{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new F(V.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new F(V.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new F(V.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(s,i){return s.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Ku{constructor(e,t,s,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new cp({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new F(V.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(e){if(this._settingsFrozen)throw new F(V.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new cp(e),e.credentials!==void 0&&(this._authCredentials=function(s){if(!s)return new CE;switch(s.type){case"firstParty":return new VE(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new F(V.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const s=rp.get(t);s&&(N("ComponentProvider","Removing Datastore"),rp.delete(t),s.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new _n(this.firestore,e,this._query)}}class yt{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new jn(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new yt(this.firestore,e,this._key)}}class jn extends _n{constructor(e,t,s){super(e,t,Ja(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new yt(this.firestore,null,new q(e))}withConverter(e){return new jn(this.firestore,e,this._path)}}function ms(n,e,...t){if(n=He(n),qy("collection","path",e),n instanceof Ku){const s=be.fromString(e,...t);return ap(s),new jn(n,null,s)}{if(!(n instanceof yt||n instanceof jn))throw new F(V.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(be.fromString(e,...t));return ap(s),new jn(n.firestore,null,s)}}function bn(n,e,...t){if(n=He(n),arguments.length===1&&(e=Xm.newId()),qy("doc","path",e),n instanceof Ku){const s=be.fromString(e,...t);return op(s),new yt(n,null,new q(s))}{if(!(n instanceof yt||n instanceof jn))throw new F(V.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(be.fromString(e,...t));return op(s),new yt(n.firestore,n instanceof jn?n.converter:null,new q(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SA{constructor(){this.iu=Promise.resolve(),this.su=[],this.ou=!1,this._u=[],this.au=null,this.uu=!1,this.cu=!1,this.lu=[],this.Yo=new wy(this,"async_queue_retry"),this.hu=()=>{const t=sa();t&&N("AsyncQueue","Visibility state changed to "+t.visibilityState),this.Yo.Wo()};const e=sa();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.hu)}get isShuttingDown(){return this.ou}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Pu(),this.Iu(e)}enterRestrictedMode(e){if(!this.ou){this.ou=!0,this.cu=e||!1;const t=sa();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.hu)}}enqueue(e){if(this.Pu(),this.ou)return new Promise(()=>{});const t=new fn;return this.Iu(()=>this.ou&&this.cu?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.su.push(e),this.Tu()))}async Tu(){if(this.su.length!==0){try{await this.su[0](),this.su.shift(),this.Yo.reset()}catch(e){if(!es(e))throw e;N("AsyncQueue","Operation failed with retryable error: "+e)}this.su.length>0&&this.Yo.$o(()=>this.Tu())}}Iu(e){const t=this.iu.then(()=>(this.uu=!0,e().catch(s=>{this.au=s,this.uu=!1;const i=function(o){let a=o.message||"";return o.stack&&(a=o.stack.includes(o.message)?o.stack:o.message+`
`+o.stack),a}(s);throw Fe("INTERNAL UNHANDLED ERROR: ",i),s}).then(s=>(this.uu=!1,s))));return this.iu=t,t}enqueueAfterDelay(e,t,s){this.Pu(),this.lu.indexOf(e)>-1&&(t=0);const i=Mu.createAndSchedule(this,e,t,s,r=>this.Eu(r));return this._u.push(i),i}Pu(){this.au&&G()}verifyOperationInProgress(){}async du(){let e;do e=this.iu,await e;while(e!==this.iu)}Au(e){for(const t of this._u)if(t.timerId===e)return!0;return!1}Ru(e){return this.du().then(()=>{this._u.sort((t,s)=>t.targetTimeMs-s.targetTimeMs);for(const t of this._u)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.du()})}Vu(e){this.lu.push(e)}Eu(e){const t=this._u.indexOf(e);this._u.splice(t,1)}}function lp(n){return function(t,s){if(typeof t!="object"||t===null)return!1;const i=t;for(const r of s)if(r in i&&typeof i[r]=="function")return!0;return!1}(n,["next","error","complete"])}class $s extends Ku{constructor(e,t,s,i){super(e,t,s,i),this.type="firestore",this._queue=function(){return new SA}(),this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||By(this),this._firestoreClient.terminate()}}function kA(n,e,t){t||(t="(default)");const s=ou(n,"firestore");if(s.isInitialized(t)){const i=s.getImmediate({identifier:t}),r=s.getOptions(t);if(Pr(r,e))return i;throw new F(V.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new F(V.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new F(V.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return s.initialize({options:e,instanceIdentifier:t})}function Wu(n){return n._firestoreClient||By(n),n._firestoreClient.verifyNotTerminated(),n._firestoreClient}function By(n){var e,t,s;const i=n._freezeSettings(),r=function(a,l,u,h){return new aT(a,l,u,h.host,h.ssl,h.experimentalForceLongPolling,h.experimentalAutoDetectLongPolling,Uy(h.experimentalLongPollingOptions),h.useFetchStreams)}(n._databaseId,((e=n._app)===null||e===void 0?void 0:e.options.appId)||"",n._persistenceKey,i);n._firestoreClient=new bA(n._authCredentials,n._appCheckCredentials,n._queue,r),!((t=i.localCache)===null||t===void 0)&&t._offlineComponentProvider&&(!((s=i.localCache)===null||s===void 0)&&s._onlineComponentProvider)&&(n._firestoreClient._uninitializedComponentsProvider={_offlineKind:i.localCache.kind,_offline:i.localCache._offlineComponentProvider,_online:i.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ti{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Ti(Je.fromBase64String(e))}catch(t){throw new F(V.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Ti(Je.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lc{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new F(V.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Ve(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hu{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qu{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new F(V.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new F(V.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return ne(this._lat,e._lat)||ne(this._long,e._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const RA=/^__.*__$/;class PA{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new vn(e,this.data,this.fieldMask,t,this.fieldTransforms):new Oi(e,this.data,t,this.fieldTransforms)}}class jy{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new vn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function zy(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw G()}}class Ju{constructor(e,t,s,i,r,o){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=i,r===void 0&&this.mu(),this.fieldTransforms=r||[],this.fieldMask=o||[]}get path(){return this.settings.path}get fu(){return this.settings.fu}gu(e){return new Ju(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}pu(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),i=this.gu({path:s,yu:!1});return i.wu(e),i}Su(e){var t;const s=(t=this.path)===null||t===void 0?void 0:t.child(e),i=this.gu({path:s,yu:!1});return i.mu(),i}bu(e){return this.gu({path:void 0,yu:!0})}Du(e){return Pa(e,this.settings.methodName,this.settings.Cu||!1,this.path,this.settings.vu)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}mu(){if(this.path)for(let e=0;e<this.path.length;e++)this.wu(this.path.get(e))}wu(e){if(e.length===0)throw this.Du("Document fields must not be empty");if(zy(this.fu)&&RA.test(e))throw this.Du('Document fields cannot begin and end with "__"')}}class CA{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||ic(e)}Fu(e,t,s,i=!1){return new Ju({fu:e,methodName:t,vu:s,path:Ve.emptyPath(),yu:!1,Cu:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Yu(n){const e=n._freezeSettings(),t=ic(n._databaseId);return new CA(n._databaseId,!!e.ignoreUndefinedProperties,t)}function DA(n,e,t,s,i,r={}){const o=n.Fu(r.merge||r.mergeFields?2:0,e,t,i);Xu("Data must be an object, but it was:",o,s);const a=Gy(s,o);let l,u;if(r.merge)l=new Et(o.fieldMask),u=o.fieldTransforms;else if(r.mergeFields){const h=[];for(const p of r.mergeFields){const m=jl(e,p,t);if(!o.contains(m))throw new F(V.INVALID_ARGUMENT,`Field '${m}' is specified in your field mask but missing from your input data.`);Wy(h,m)||h.push(m)}l=new Et(h),u=o.fieldTransforms.filter(p=>l.covers(p.field))}else l=null,u=o.fieldTransforms;return new PA(new lt(a),l,u)}class lo extends Hu{_toFieldTransform(e){if(e.fu!==2)throw e.fu===1?e.Du(`${this._methodName}() can only appear at the top level of your update data`):e.Du(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof lo}}function $A(n,e,t,s){const i=n.Fu(1,e,t);Xu("Data must be an object, but it was:",i,s);const r=[],o=lt.empty();xs(s,(l,u)=>{const h=Zu(e,l,t);u=He(u);const p=i.Su(h);if(u instanceof lo)r.push(h);else{const m=uo(u,p);m!=null&&(r.push(h),o.set(h,m))}});const a=new Et(r);return new jy(o,a,i.fieldTransforms)}function VA(n,e,t,s,i,r){const o=n.Fu(1,e,t),a=[jl(e,s,t)],l=[i];if(r.length%2!=0)throw new F(V.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let m=0;m<r.length;m+=2)a.push(jl(e,r[m])),l.push(r[m+1]);const u=[],h=lt.empty();for(let m=a.length-1;m>=0;--m)if(!Wy(u,a[m])){const w=a[m];let E=l[m];E=He(E);const $=o.Su(w);if(E instanceof lo)u.push(w);else{const R=uo(E,$);R!=null&&(u.push(w),h.set(w,R))}}const p=new Et(u);return new jy(h,p,o.fieldTransforms)}function NA(n,e,t,s=!1){return uo(t,n.Fu(s?4:3,e))}function uo(n,e){if(Ky(n=He(n)))return Xu("Unsupported field value:",e,n),Gy(n,e);if(n instanceof Hu)return function(s,i){if(!zy(i.fu))throw i.Du(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.Du(`${s._methodName}() is not currently supported inside arrays`);const r=s._toFieldTransform(i);r&&i.fieldTransforms.push(r)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.yu&&e.fu!==4)throw e.Du("Nested arrays are not supported");return function(s,i){const r=[];let o=0;for(const a of s){let l=uo(a,i.bu(o));l==null&&(l={nullValue:"NULL_VALUE"}),r.push(l),o++}return{arrayValue:{values:r}}}(n,e)}return function(s,i){if((s=He(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return TT(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const r=Ne.fromDate(s);return{timestampValue:_i(i.serializer,r)}}if(s instanceof Ne){const r=new Ne(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:_i(i.serializer,r)}}if(s instanceof Qu)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof Ti)return{bytesValue:Bg(i.serializer,s._byteString)};if(s instanceof yt){const r=i.databaseId,o=s.firestore._databaseId;if(!o.isEqual(r))throw i.Du(`Document reference is for database ${o.projectId}/${o.database} but should be for database ${r.projectId}/${r.database}`);return{referenceValue:ku(s.firestore._databaseId||i.databaseId,s._key.path)}}throw i.Du(`Unsupported field value: ${cc(s)}`)}(n,e)}function Gy(n,e){const t={};return dg(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):xs(n,(s,i)=>{const r=uo(i,e.pu(s));r!=null&&(t[s]=r)}),{mapValue:{fields:t}}}function Ky(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Ne||n instanceof Qu||n instanceof Ti||n instanceof yt||n instanceof Hu)}function Xu(n,e,t){if(!Ky(t)||!function(i){return typeof i=="object"&&i!==null&&(Object.getPrototypeOf(i)===Object.prototype||Object.getPrototypeOf(i)===null)}(t)){const s=cc(t);throw s==="an object"?e.Du(n+" a custom object"):e.Du(n+" "+s)}}function jl(n,e,t){if((e=He(e))instanceof lc)return e._internalPath;if(typeof e=="string")return Zu(n,e);throw Pa("Field path arguments must be of type string or ",n,!1,void 0,t)}const xA=new RegExp("[~\\*/\\[\\]]");function Zu(n,e,t){if(e.search(xA)>=0)throw Pa(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new lc(...e.split("."))._internalPath}catch{throw Pa(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Pa(n,e,t,s,i){const r=s&&!s.isEmpty(),o=i!==void 0;let a=`Function ${e}() called with invalid data`;t&&(a+=" (via `toFirestore()`)"),a+=". ";let l="";return(r||o)&&(l+=" (found",r&&(l+=` in field ${s}`),o&&(l+=` in document ${i}`),l+=")"),new F(V.INVALID_ARGUMENT,a+n+l)}function Wy(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hy{constructor(e,t,s,i,r){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=i,this._converter=r}get id(){return this._key.path.lastSegment()}get ref(){return new yt(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new OA(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field(uc("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class OA extends Hy{data(){return super.data()}}function uc(n,e){return typeof e=="string"?Zu(n,e):e instanceof lc?e._internalPath:e._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qy(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new F(V.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class ed{}class td extends ed{}function zl(n,e,...t){let s=[];e instanceof ed&&s.push(e),s=s.concat(t),function(r){const o=r.filter(l=>l instanceof nd).length,a=r.filter(l=>l instanceof dc).length;if(o>1||o>0&&a>0)throw new F(V.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(s);for(const i of s)n=i._apply(n);return n}class dc extends td{constructor(e,t,s){super(),this._field=e,this._op=t,this._value=s,this.type="where"}static _create(e,t,s){return new dc(e,t,s)}_apply(e){const t=this._parse(e);return Jy(e._query,t),new _n(e.firestore,e.converter,Rl(e._query,t))}_parse(e){const t=Yu(e.firestore);return function(r,o,a,l,u,h,p){let m;if(u.isKeyField()){if(h==="array-contains"||h==="array-contains-any")throw new F(V.INVALID_ARGUMENT,`Invalid Query. You can't perform '${h}' queries on documentId().`);if(h==="in"||h==="not-in"){hp(p,h);const w=[];for(const E of p)w.push(dp(l,r,E));m={arrayValue:{values:w}}}else m=dp(l,r,p)}else h!=="in"&&h!=="not-in"&&h!=="array-contains-any"||hp(p,h),m=NA(a,o,p,h==="in"||h==="not-in");return le.create(u,h,m)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function up(n,e,t){const s=e,i=uc("where",n);return dc._create(i,s,t)}class nd extends ed{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new nd(e,t)}_parse(e){const t=this._queryConstraints.map(s=>s._parse(e)).filter(s=>s.getFilters().length>0);return t.length===1?t[0]:Ie.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(i,r){let o=i;const a=r.getFlattenedFilters();for(const l of a)Jy(o,l),o=Rl(o,l)}(e._query,t),new _n(e.firestore,e.converter,Rl(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class sd extends td{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new sd(e,t)}_apply(e){const t=function(i,r,o){if(i.startAt!==null)throw new F(V.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(i.endAt!==null)throw new F(V.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new qr(r,o)}(e._query,this._field,this._direction);return new _n(e.firestore,e.converter,function(i,r){const o=i.explicitOrderBy.concat([r]);return new xi(i.path,i.collectionGroup,o,i.filters.slice(),i.limit,i.limitType,i.startAt,i.endAt)}(e._query,t))}}function MA(n,e="asc"){const t=e,s=uc("orderBy",n);return sd._create(s,t)}class id extends td{constructor(e,t,s){super(),this.type=e,this._limit=t,this._limitType=s}static _create(e,t,s){return new id(e,t,s)}_apply(e){return new _n(e.firestore,e.converter,_a(e._query,this._limit,this._limitType))}}function LA(n){return id._create("limit",n,"F")}function dp(n,e,t){if(typeof(t=He(t))=="string"){if(t==="")throw new F(V.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!Eg(e)&&t.indexOf("/")!==-1)throw new F(V.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const s=e.path.child(be.fromString(t));if(!q.isDocumentKey(s))throw new F(V.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return Fr(n,new q(s))}if(t instanceof yt)return Fr(n,t._key);throw new F(V.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${cc(t)}.`)}function hp(n,e){if(!Array.isArray(n)||n.length===0)throw new F(V.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Jy(n,e){const t=function(i,r){for(const o of i)for(const a of o.getFlattenedFilters())if(r.indexOf(a.op)>=0)return a.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new F(V.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new F(V.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}class FA{convertValue(e,t="none"){switch(ks(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Me(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(Hn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw G()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return xs(e,(i,r)=>{s[i]=this.convertValue(r,t)}),s}convertGeoPoint(e){return new Qu(Me(e.latitude),Me(e.longitude))}convertArray(e,t){return(e.values||[]).map(s=>this.convertValue(s,t))}convertServerTimestamp(e,t){switch(t){case"previous":const s=bu(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(Mr(e));default:return null}}convertTimestamp(e){const t=mn(e);return new Ne(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=be.fromString(e);X(Xg(s));const i=new Ss(s.get(1),s.get(3)),r=new q(s.popFirst(5));return i.isEqual(t)||Fe(`Document ${r} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function UA(n,e,t){let s;return s=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yr{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class Yy extends Hy{constructor(e,t,s,i,r,o){super(e,t,s,i,o),this._firestore=e,this._firestoreImpl=e,this.metadata=r}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new ia(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field(uc("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}}class ia extends Yy{data(e={}){return super.data(e)}}class Xy{constructor(e,t,s,i){this._firestore=e,this._userDataWriter=t,this._snapshot=i,this.metadata=new yr(i.hasPendingWrites,i.fromCache),this.query=s}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(s=>{e.call(t,new ia(this._firestore,this._userDataWriter,s.key,s,new yr(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new F(V.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(i,r){if(i._snapshot.oldDocs.isEmpty()){let o=0;return i._snapshot.docChanges.map(a=>{const l=new ia(i._firestore,i._userDataWriter,a.doc.key,a.doc,new yr(i._snapshot.mutatedKeys.has(a.doc.key),i._snapshot.fromCache),i.query.converter);return a.doc,{type:"added",doc:l,oldIndex:-1,newIndex:o++}})}{let o=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(a=>r||a.type!==3).map(a=>{const l=new ia(i._firestore,i._userDataWriter,a.doc.key,a.doc,new yr(i._snapshot.mutatedKeys.has(a.doc.key),i._snapshot.fromCache),i.query.converter);let u=-1,h=-1;return a.type!==0&&(u=o.indexOf(a.doc.key),o=o.delete(a.doc.key)),a.type!==1&&(o=o.add(a.doc),h=o.indexOf(a.doc.key)),{type:qA(a.type),doc:l,oldIndex:u,newIndex:h}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function qA(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return G()}}class rd extends FA{constructor(e){super(),this.firestore=e}convertBytes(e){return new Ti(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new yt(this.firestore,null,t)}}function BA(n){n=Qt(n,_n);const e=Qt(n.firestore,$s),t=Wu(e),s=new rd(e);return Qy(n._query),TA(t,n._query).then(i=>new Xy(e,s,n,i))}function ho(n,e,t){n=Qt(n,yt);const s=Qt(n.firestore,$s),i=UA(n.converter,e,t);return od(s,[DA(Yu(s),"setDoc",n._key,i,n.converter!==null,t).toMutation(n._key,pt.none())])}function Zy(n,e,t,...s){n=Qt(n,yt);const i=Qt(n.firestore,$s),r=Yu(i);let o;return o=typeof(e=He(e))=="string"||e instanceof lc?VA(r,"updateDoc",n._key,e,t,s):$A(r,"updateDoc",n._key,e),od(i,[o.toMutation(n._key,pt.exists(!0))])}function jA(n){return od(Qt(n.firestore,$s),[new ec(n._key,pt.none())])}function Gl(n,...e){var t,s,i;n=He(n);let r={includeMetadataChanges:!1,source:"default"},o=0;typeof e[o]!="object"||lp(e[o])||(r=e[o],o++);const a={includeMetadataChanges:r.includeMetadataChanges,source:r.source};if(lp(e[o])){const p=e[o];e[o]=(t=p.next)===null||t===void 0?void 0:t.bind(p),e[o+1]=(s=p.error)===null||s===void 0?void 0:s.bind(p),e[o+2]=(i=p.complete)===null||i===void 0?void 0:i.bind(p)}let l,u,h;if(n instanceof yt)u=Qt(n.firestore,$s),h=Ja(n._key.path),l={next:p=>{e[o]&&e[o](zA(u,n,p))},error:e[o+1],complete:e[o+2]};else{const p=Qt(n,_n);u=Qt(p.firestore,$s),h=p._query;const m=new rd(u);l={next:w=>{e[o]&&e[o](new Xy(u,m,p,w))},error:e[o+1],complete:e[o+2]},Qy(n._query)}return function(m,w,E,$){const R=new Ly($),B=new Cy(w,R,E);return m.asyncQueue.enqueueAndForget(async()=>Ry(await Bl(m),B)),()=>{R.$a(),m.asyncQueue.enqueueAndForget(async()=>Py(await Bl(m),B))}}(Wu(u),h,a,l)}function od(n,e){return function(s,i){const r=new fn;return s.asyncQueue.enqueueAndForget(async()=>rA(await EA(s),i,r)),r.promise}(Wu(n),e)}function zA(n,e,t){const s=t.docs.get(e._key),i=new rd(n);return new Yy(n,i,e._key,s,new yr(t.hasPendingWrites,t.fromCache),e.converter)}class GA{constructor(e){let t;this.kind="persistent",e!=null&&e.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=QA(),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function KA(n){return new GA(n)}class WA{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Gu,this._offlineComponentProvider=new My(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes,this.forceOwnership)}}class HA{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Gu,this._offlineComponentProvider=new _A(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes)}}function QA(n){return new WA(void 0)}function JA(){return new HA}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ev(){return new lo("deleteField")}(function(e,t=!0){(function(i){Ni=i})(Di),di(new Is("firestore",(s,{instanceIdentifier:i,options:r})=>{const o=s.getProvider("app").getImmediate(),a=new $s(new DE(s.getProvider("auth-internal")),new xE(s.getProvider("app-check-internal")),function(u,h){if(!Object.prototype.hasOwnProperty.apply(u.options,["projectId"]))throw new F(V.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Ss(u.options.projectId,h)}(o,i),o);return r=Object.assign({useFetchStreams:t},r),a._setSettings(r),a},"PUBLIC").setMultipleInstances(!0)),Un(of,"4.6.3",e),Un(of,"4.6.3","esm2017")})();const Kl={apiKey:"AIzaSyC9Um4cxmF3LT_f9Ade5gYSj4ZjMbPHZU4",authDomain:"cursing-offers.firebaseapp.com",projectId:"cursing-offers",storageBucket:"cursing-offers.firebasestorage.app",messagingSenderId:"782347533500",appId:"1:782347533500:web:5da31b9357632fc055a4b9"};function YA(){const n=Date.now(),e=864e5,t=new Date().toISOString().slice(0,10),s=(r,o,a)=>({desc:r,qty:o,price:a,disc:0}),i=(r,o,a,l,u,h,p,m,w,E)=>({id:r,number:o,ts:n-w*e,date:new Date(n-w*e).toISOString().slice(0,10),customer:{name:a,phone:l,email:"",afm:"",address:u},subject:h,status:p,total:m,vatMode:"on",lines:E});return{quotes:[i("q1","2311","Γιώργος Παπαδόπουλος","6900000001","Πρέβεζα","Εγκατάσταση CCTV και WiFi","accepted",1437.16,3,[s("Hikvision IP 4MP Bullet",4,89),s("NVR 8 καναλιών + 2TB",1,245),s("UniFi U6 Lite",2,119),s("Εργασία εγκατάστασης",1,320)]),i("q2","2310","Hotel Aktaion","6900000002","Βόνιτσα","WiFi ξενοδοχείου 40 δωμάτια","pending",6920,5,[s("UniFi U6+",20,159),s("Switch PoE 24 θυρών",1,420),s("Εργασία",1,1700)]),i("q3","2309","Μαρία Νικολάου","6900000003","Λευκάδα","Συναγερμός Paradox","done",780,700,[s("Paradox MG5050 set",1,480),s("Εργασία",1,149)]),i("q4","2307","Κώστας Δήμου","6900000004","Πρέβεζα","Κάμερες καταστήματος","rejected",1150,12,[s("Dahua 4MP Dome",6,95),s("Εργασία",1,357)]),i("q5","2306","Σταύρος Σταύρου","6900000005","Πάλαιρος","Θυροτηλέφωνο + κάμερα","pending",540,1,[s("Θυροτηλέφωνο IP",1,290),s("Εργασία",1,145)])],products:[{id:"p1",cat:"Κάμερες",model:"Hikvision IP 4MP Bullet",desc:"DS-2CD2043",cost:71.2,minQty:8,links:[{sup:"Xpatit",url:"https://xpatit.gr",code:"HK-2043"}]},{id:"p2",cat:"Κάμερες",model:"Dahua 4MP Dome",desc:"",cost:76},{id:"p3",cat:"Καταγραφικά",model:"NVR 8 καναλιών",desc:"με δίσκο 2TB",cost:196},{id:"p4",cat:"WiFi",model:"UniFi U6 Lite",desc:"Access Point",cost:95.2},{id:"p5",cat:"WiFi",model:"UniFi U6+",desc:"",cost:127.2},{id:"p6",cat:"Συναγερμοί",model:"Paradox MG5050",desc:"set",cost:384}],smoves:[{id:"m1",pid:"p1",qty:6}],custs:[{id:"c1",name:"Γιώργος Παπαδόπουλος",phone:"6900000001",address:"Πρέβεζα",ts:n-30*e}],tasks:[{id:"t1",title:"Εγκατάσταση CCTV",date:t,time:"09:00",cust:"Γιώργος Παπαδόπουλος",tel:"6900000001",addr:"Πρέβεζα",emps:["e1"],rems:[60,0],done:!1,chk:[{tx:"4 κάμερες",dn:!0},{tx:"NVR + δίσκος",dn:!1},{tx:"Ρύθμιση εφαρμογής",dn:!1}],quoteId:"q1"},{id:"t2",title:"Αυτοψία WiFi ξενοδοχείου",date:t,time:"13:30",cust:"Hotel Aktaion",addr:"Βόνιτσα",done:!1,clr:9},{id:"t3",title:"Service συναγερμού",date:t,time:"17:00",cust:"Μαρία Νικολάου",addr:"Λευκάδα",done:!0},{id:"t4",title:"Ασφάλεια βαν",kind:"due",rep:"y",date:new Date(n+5*e).toISOString().slice(0,10),done:!1,rems:[1440,0]},{id:"t5",title:"Παραγγελία Xpatit",date:new Date(n-2*e).toISOString().slice(0,10),done:!1},{id:"t6",title:"Τηλέφωνο σε Σταύρο για θυροτηλέφωνο",date:"",done:!1},{id:"t7",title:"Συνδρομή Starlink",kind:"due",rep:"m",date:new Date(n+9*e).toISOString().slice(0,10),done:!1},{id:"t8",title:"Εγκατάσταση WiFi",date:new Date(n+e).toISOString().slice(0,10),time:"10:00",cust:"Hotel Aktaion",addr:"Βόνιτσα",emps:["e1"],done:!1}],ldocs:[{id:"d3",kind:"purchase",party:"Xpatit",number:"ΤΔΑ 1182",cat:"Εμπορεύματα",net:820,vat:196.8,rate:24,gross:1016.8,date:t,ts:n-e,items:[]},{id:"d4",kind:"purchase",party:"Cosmote",number:"",cat:"Τηλεπικοινωνίες",net:45,vat:10.8,rate:24,gross:55.8,date:t,ts:n-3*e,items:[]},{id:"d1",kind:"sale",qid:"q1",number:"2311",party:"Γιώργος Παπαδόπουλος",net:1159,vat:278.16,rate:24,gross:1437.16,date:t,ts:n-2*e},{id:"d2",kind:"sale",party:"Μαρία Νικολάου",gross:780,date:t,ts:n-30*e}],wdays:[{id:"w1",empId:"e1",date:t,days:1,amount:60},{id:"w2",empId:"e1",date:t,days:1,amount:60}],needs:[{id:"n1",ts:n-e,title:"Κρουστικό δράπανο",qty:"1",notes:"",by:{uid:"e",name:"Νίκος Τεχνικός"},done:!1},{id:"n2",ts:n-3*e,title:"Βίδες γυψοσανίδας",qty:"2 κουτιά",by:{uid:"demo",name:"Διαχειριστής"},done:!0,doneAt:n-e}],wpays:[{id:"wp1",empId:"e1",date:t,amount:50,method:"cash"}],lpays:[{id:"p3",dir:"out",date:t,party:"Xpatit",docId:"d3",amount:400,method:"bank",note:""},{id:"p1",docId:"d1",amount:500,dir:"in",date:t,party:"Γιώργος Παπαδόπουλος",method:"bank",note:"Προκαταβολή"},{id:"p2",docId:"d2",amount:780,dir:"in",date:t,party:"Μαρία Νικολάου",method:"cash",note:""}],emps:[{id:"e1",name:"Νίκος Τεχνικός",rate:60}],st:{main:{vat:24,margin:25,next:2312},books:{opening:1500,costCats:["Εμπορεύματα","Υλικά","Καύσιμα","Τηλεπικοινωνίες","Λοιπά έξοδα"]}}}}const Wl={quotes:"quotes",custs:"customers",tasks:"tasks",ldocs:"ledger_docs",lpays:"ledger_pays",emps:"employees",products:"products",smoves:"stock_moves",wdays:"workdays",wpays:"wagepays",needs:"tool_needs"},fo={...Wl,qlog:"quote_log",pbuys:"partner_buys"},A={quotes:[],custs:[],tasks:[],ldocs:[],lpays:[],emps:[],products:[],smoves:[],wdays:[],wpays:[],needs:[],st:{}},tv=new Set;function XA(n){tv.add(n)}function Dt(){tv.forEach(n=>n())}const Pt=new URLSearchParams(location.search).has("demo"),Ms=Pt;let gn=null,tt=null,Ca=[];const Ar={},ZA=()=>gn&&gn.currentUser||null;function eS(n){if(Pt){Object.assign(A,YA()),n({email:"demo@techmate"}),setTimeout(Dt,0);return}const e=um(Kl);gn=kE(e),tt=kA(e,{localCache:KA({tabManager:JA()})}),pI(gn,t=>{Ca.forEach(s=>s()),Ca=[],t&&tS(),n(t)})}let si=[],cr=null;function tS(){cr=null,Ca.push(Gl(ms(tt,"settings"),n=>{const e={};n.docs.forEach(r=>e[r.id]=r.data()),A.st=e;const t=gn.currentUser,s=t&&(e.roles&&e.roles.users||{})[t.uid],i=s&&s.role==="team"?"team:"+(s.empId||""):"owner";i!==cr&&(cr=i,fp(i)),Dt()},()=>{cr===null&&(cr="owner",fp("owner"))})),Ca.push(()=>{si.forEach(n=>n()),si=[]})}function fp(n){si.forEach(s=>s()),si=[],Object.keys(Wl).forEach(s=>{s!=="tasks"&&(A[s]=[],delete Ar[s])});const e=(s,i)=>si.push(Gl(i,r=>{A[s]=r.docs.map(o=>({...o.data(),id:o.id})),Ar[s]=!0,Dt()},()=>{A[s]=[],Dt()}));if(n==="owner"){Object.entries(Wl).forEach(([s,i])=>e(s,ms(tt,i)));return}const t=n.slice(5);e("tasks",ms(tt,"tasks")),e("needs",ms(tt,"tool_needs")),t&&(e("wdays",zl(ms(tt,"workdays"),up("empId","==",t))),e("wpays",zl(ms(tt,"wagepays"),up("empId","==",t))),si.push(Gl(bn(tt,"employees",t),s=>{A.emps=s.exists()?[{...s.data(),id:s.id}]:[],Ar.emps=!0,Dt()},()=>{A.emps=[],Dt()})))}function nS(n,e){return dI(gn,n,e)}function sS(){return Pt?location.assign(location.pathname):mI(gn)}const $e=n=>String(n||"").trim().toLowerCase(),P=(n,e=0)=>{const t=parseFloat(n);return isNaN(t)?e:t},U=n=>Math.round(n*100)/100,nt=n=>n.status||"pending",Jt=n=>!!(n&&n.kind==="install"),ra={pending:"Σε αναμονή",accepted:"Δεκτή",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"};function hc(n){let e=0;return A.lpays.forEach(t=>{t.docId===n&&(e+=P(t.amount))}),U(e)}function nv(n){return Math.max(0,U(P(n.gross)-hc(n.id)))}function Zt(){const n={},e=t=>{const s=$e(t)||"_none";return n[s]||(n[s]={k:s,name:t||"(χωρίς όνομα)",quotes:[],mins:[],last:0})};return A.custs.forEach(t=>{const s=e(t.name);s.name=t.name,s.rec=t,s.last=Math.max(s.last,t.upd||t.ts||0)}),A.quotes.forEach(t=>{const s=e(t.customer&&t.customer.name);(Jt(t)?s.mins:s.quotes).push(t),s.last=Math.max(s.last,t.ts||0)}),A.ldocs.forEach(t=>{t.kind==="sale"&&e(t.party)}),Object.values(n).map(t=>{t.won=0,t.owed=0,t.docs=A.ldocs.filter(r=>r.kind==="sale"&&$e(r.party)===t.k),t.quotes.forEach(r=>{const o=nt(r);(o==="accepted"||o==="done")&&(t.won+=P(r.total))}),t.docs.forEach(r=>{t.owed+=nv(r),t.last=Math.max(t.last,r.ts||0)}),t.owed=U(t.owed),t.won=U(t.won);const s=t.quotes.slice().sort((r,o)=>(o.ts||0)-(r.ts||0))[0],i=s&&s.customer||{};return t.info={},["phone","email","afm","address"].forEach(r=>t.info[r]=t.rec&&t.rec[r]||i[r]||""),t})}const je=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),ut=n=>JSON.parse(JSON.stringify(n)),ae=()=>A.st.main;let sv=()=>{};function iS(n){sv=n}const ss=n=>{n.catch(e=>sv(e))};function Ue(n,e){const t=ut(e);delete t.id;const s=A[n];if(s){const i=s.findIndex(r=>r.id===e.id);i>=0?s[i]=ut(e):s.push(ut(e))}Pt||ss(ho(bn(tt,fo[n],e.id),t)),Dt()}function iv(n,e){A[n]&&(A[n]=A[n].filter(t=>t.id!==e)),Pt||ss(jA(bn(tt,fo[n],e))),Dt()}const Ai=()=>Pt?{uid:"demo",email:"demo@techmate"}:gn&&gn.currentUser;function Vs(n,e,t){const s=(A[n]||[]).find(r=>r.id===e);s&&Object.keys(t).forEach(r=>{t[r]===void 0?delete s[r]:s[r]=t[r]});const i={};Object.keys(t).forEach(r=>i[r]=t[r]===void 0?ev():t[r]),Pt||ss(Zy(bn(tt,fo[n],e),i)),Dt()}function Yt(n,e,t){const s=A[n];let i=s&&s.find(o=>o.id===e);s&&!i&&(i={id:e},s.push(i)),i&&Object.keys(t).forEach(o=>{t[o]===void 0?delete i[o]:i[o]=ut(t[o])});const r={};Object.keys(t).forEach(o=>{o!=="id"&&(r[o]=t[o]===void 0?ev():ut(t[o]))}),Pt||ss(ho(bn(tt,fo[n],e),r,{merge:!0})),Dt()}function rS(n){A.st.main&&(A.st.main.next=n),Pt||ss(ho(bn(tt,"settings","main"),{next:n},{merge:!0}))}const ad=n=>P(n.qty)*P(n.price)*(1-P(n.disc)/100),cd=n=>U((n.lines||[]).reduce((e,t)=>e+ad(t),0));function rv(n){const e=cd(n),t=n.vatMode==="off",s=P(ae()&&ae().vat,24),i=t?0:U(e*s/100);return{sub:e,vat:i,vp:s,off:t,total:U(e+i)}}function ov(n){const e=P(n.cost,0);if(n.marginEur!=null&&n.marginEur!=="")return U(e+P(n.marginEur));const t=n.margin==null||n.margin===""?P(ae()&&ae().margin,25):P(n.margin);return U(e*(1+t/100))}function av(n,e){let t=0,s=0,i=0;return A.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(o=>{o.pid===n&&(t+=P(o.qty))})}),A.smoves.forEach(r=>{r.pid===n&&(t+=P(r.qty))}),A.quotes.forEach(r=>{if(r.id===e)return;const o=nt(r);(r.lines||[]).forEach(a=>{if(a.pid!==n||a.src!=="stock")return;const l=P(a.qty);o==="done"?r.noStock||(s+=l):o==="accepted"&&(i+=l)})}),U(t-s-i)}function pp(n,e){if(!["main","logo"].includes(n))return;const t=A.st[n]||(A.st[n]={});Object.keys(e).forEach(i=>{t[i]=ut(e[i])});const s={};Object.keys(e).forEach(i=>s[i]=ut(e[i])),Pt||ss(ho(bn(tt,"settings",n),s,{merge:!0})),Dt()}function Da(n,e,t,s){const i=(A[n]||[]).find(a=>a.id===e);if(!i)return;const r=t.split(".");let o=i;for(let a=0;a<r.length-1;a++)(!o[r[a]]||typeof o[r[a]]!="object")&&(o[r[a]]={}),o=o[r[a]];o[r[r.length-1]]=ut(s),Pt||ss(Zy(bn(tt,fo[n],e),{[t]:ut(s)})),Dt()}async function oS(){return Pt?[{id:"m1",name:"Νίκος Δημητρίου",phone:"6911111111",email:"",msg:"Θέλω προσφορά για 4 κάμερες σε κατάστημα.",svc:"Κάμερες",area:"Χαλκίδα",day:"Απόγευμα",at:new Date().toISOString(),read:!1},{id:"m2",name:"Ελένη Κ.",phone:"",email:"eleni@example.gr",msg:"Πρόβλημα με το WiFi στο ξενοδοχείο.",svc:"WiFi",area:"",day:"",at:new Date(Date.now()-864e5*3).toISOString(),read:!0}]:(await BA(zl(ms(tt,"contact"),MA("at","desc"),LA(50)))).docs.map(e=>({...e.data(),id:e.id}))}function aS(n){Pt||ss(ho(bn(tt,"contact",n),{read:!0},{merge:!0}))}/*! Capacitor: https://capacitorjs.com/ - MIT License */var Si;(function(n){n.Unimplemented="UNIMPLEMENTED",n.Unavailable="UNAVAILABLE"})(Si||(Si={}));class nl extends Error{constructor(e,t,s){super(e),this.message=e,this.code=t,this.data=s}}const cS=n=>{var e,t;return n!=null&&n.androidBridge?"android":!((t=(e=n==null?void 0:n.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||t===void 0)&&t.bridge?"ios":"web"},lS=n=>{const e=n.CapacitorCustomPlatform||null,t=n.Capacitor||{},s=t.Plugins=t.Plugins||{},i=()=>e!==null?e.name:cS(n),r=()=>i()!=="web",o=p=>{const m=u.get(p);return!!(m!=null&&m.platforms.has(i())||a(p))},a=p=>{var m;return(m=t.PluginHeaders)===null||m===void 0?void 0:m.find(w=>w.name===p)},l=p=>n.console.error(p),u=new Map,h=(p,m={})=>{const w=u.get(p);if(w)return console.warn(`Capacitor plugin "${p}" already registered. Cannot register plugins twice.`),w.proxy;const E=i(),$=a(p);let R;const B=async()=>(!R&&E in m?R=typeof m[E]=="function"?R=await m[E]():R=m[E]:e!==null&&!R&&"web"in m&&(R=typeof m.web=="function"?R=await m.web():R=m.web),R),H=(y,v)=>{var I,T;if($){const S=$==null?void 0:$.methods.find(_=>v===_.name);if(S)return S.rtype==="promise"?_=>t.nativePromise(p,v.toString(),_):(_,vt)=>t.nativeCallback(p,v.toString(),_,vt);if(y)return(I=y[v])===null||I===void 0?void 0:I.bind(y)}else{if(y)return(T=y[v])===null||T===void 0?void 0:T.bind(y);throw new nl(`"${p}" plugin is not implemented on ${E}`,Si.Unimplemented)}},K=y=>{let v;const I=(...T)=>{const S=B().then(_=>{const vt=H(_,y);if(vt){const qt=vt(...T);return v=qt==null?void 0:qt.remove,qt}else throw new nl(`"${p}.${y}()" is not implemented on ${E}`,Si.Unimplemented)});return y==="addListener"&&(S.remove=async()=>v()),S};return I.toString=()=>`${y.toString()}() { [capacitor code] }`,Object.defineProperty(I,"name",{value:y,writable:!1,configurable:!1}),I},se=K("addListener"),x=K("removeListener"),L=(y,v)=>{const I=se({eventName:y},v).then(_=>_),T=async()=>{const _=await I;await x({eventName:y,callbackId:_})},S=new Promise(_=>I.then(()=>_({remove:T})));return S.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await T()},S},b=new Proxy({},{get(y,v){switch(v){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return $?L:se;case"removeListener":return x;default:return K(v)}}});return s[p]=b,u.set(p,{name:p,proxy:b,platforms:new Set([...Object.keys(m),...$?[E]:[]])}),b};return t.convertFileSrc||(t.convertFileSrc=p=>p),t.getPlatform=i,t.handleError=l,t.isNativePlatform=r,t.isPluginAvailable=o,t.registerPlugin=h,t.Exception=nl,t.DEBUG=!!t.DEBUG,t.isLoggingEnabled=!!t.isLoggingEnabled,t},uS=n=>n.Capacitor=lS(n),zr=uS(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),po=zr.registerPlugin;class ld{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let s=!1;this.listeners[e]||(this.listeners[e]=[],s=!0),this.listeners[e].push(t);const r=this.windowListeners[e];r&&!r.registered&&this.addWindowListener(r),s&&this.sendRetainedArgumentsForEvent(e);const o=async()=>this.removeListener(e,t);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,s){const i=this.listeners[e];if(!i){if(s){let r=this.retainedEventArguments[e];r||(r=[]),r.push(t),this.retainedEventArguments[e]=r}return}i.forEach(r=>r(t))}hasListeners(e){var t;return!!(!((t=this.listeners[e])===null||t===void 0)&&t.length)}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:s=>{this.notifyListeners(t,s)}}}unimplemented(e="not implemented"){return new zr.Exception(e,Si.Unimplemented)}unavailable(e="not available"){return new zr.Exception(e,Si.Unavailable)}async removeListener(e,t){const s=this.listeners[e];if(!s)return;const i=s.indexOf(t);i!==-1&&this.listeners[e].splice(i,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(s=>{this.notifyListeners(e,s)}))}}const mp=n=>encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),gp=n=>n.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class dS extends ld{async getCookies(){const e=document.cookie,t={};return e.split(";").forEach(s=>{if(s.length<=0)return;let[i,r]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");i=gp(i).trim(),r=gp(r).trim(),t[i]=r}),t}async setCookie(e){try{const t=mp(e.key),s=mp(e.value),i=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",r=(e.path||"/").replace("path=",""),o=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${t}=${s||""}${i}; path=${r}; ${o};`}catch(t){return Promise.reject(t)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(t){return Promise.reject(t)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const t of e)document.cookie=t.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}po("CapacitorCookies",{web:()=>new dS});const hS=async n=>new Promise((e,t)=>{const s=new FileReader;s.onload=()=>{const i=s.result;e(i.indexOf(",")>=0?i.split(",")[1]:i)},s.onerror=i=>t(i),s.readAsDataURL(n)}),fS=(n={})=>{const e=Object.keys(n);return Object.keys(n).map(i=>i.toLocaleLowerCase()).reduce((i,r,o)=>(i[r]=n[e[o]],i),{})},pS=(n,e=!0)=>n?Object.entries(n).reduce((s,i)=>{const[r,o]=i;let a,l;return Array.isArray(o)?(l="",o.forEach(u=>{a=e?encodeURIComponent(u):u,l+=`${r}=${a}&`}),l.slice(0,-1)):(a=e?encodeURIComponent(o):o,l=`${r}=${a}`),`${s}&${l}`},"").substr(1):null,mS=(n,e={})=>{const t=Object.assign({method:n.method||"GET",headers:n.headers},e),i=fS(n.headers)["content-type"]||"";if(typeof n.data=="string")t.body=n.data;else if(i.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[o,a]of Object.entries(n.data||{}))r.set(o,a);t.body=r.toString()}else if(i.includes("multipart/form-data")||n.data instanceof FormData){const r=new FormData;if(n.data instanceof FormData)n.data.forEach((a,l)=>{r.append(l,a)});else for(const a of Object.keys(n.data))r.append(a,n.data[a]);t.body=r;const o=new Headers(t.headers);o.delete("content-type"),t.headers=o}else(i.includes("application/json")||typeof n.data=="object")&&(t.body=JSON.stringify(n.data));return t};class gS extends ld{async request(e){const t=mS(e,e.webFetchExtra),s=pS(e.params,e.shouldEncodeUrlParams),i=s?`${e.url}?${s}`:e.url,r=await fetch(i,t),o=r.headers.get("content-type")||"";let{responseType:a="text"}=r.ok?e:{};o.includes("application/json")&&(a="json");let l,u;switch(a){case"arraybuffer":case"blob":u=await r.blob(),l=await hS(u);break;case"json":l=await r.json();break;case"document":case"text":default:l=await r.text()}const h={};return r.headers.forEach((p,m)=>{h[m]=p}),{data:l,headers:h,status:r.status,url:r.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}po("CapacitorHttp",{web:()=>new gS});var yp;(function(n){n.Dark="DARK",n.Light="LIGHT",n.Default="DEFAULT"})(yp||(yp={}));var vp;(function(n){n.StatusBar="StatusBar",n.NavigationBar="NavigationBar"})(vp||(vp={}));class yS extends ld{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}po("SystemBars",{web:()=>new yS});const vS="modulepreload",_S=function(n){return"/"+n},_p={},Cn=function(e,t,s){let i=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const o=document.querySelector("meta[property=csp-nonce]"),a=(o==null?void 0:o.nonce)||(o==null?void 0:o.getAttribute("nonce"));i=Promise.allSettled(t.map(l=>{if(l=_S(l),l in _p)return;_p[l]=!0;const u=l.endsWith(".css"),h=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${h}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":vS,u||(p.as="script"),p.crossOrigin="",p.href=l,a&&p.setAttribute("nonce",a),document.head.appendChild(p),u)return new Promise((m,w)=>{p.addEventListener("load",m),p.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${l}`)))})}))}function r(o){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=o,window.dispatchEvent(a),!a.defaultPrevented)throw o}return i.then(o=>{for(const a of o||[])a.status==="rejected"&&r(a.reason);return e().catch(r)})},bS="__capgo_keep_url_path_after_reload",sl="__capgo_history_stack__",bp=100,wS=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(wS){const n=window;if(!n.__capgoHistoryPatched){n.__capgoHistoryPatched=!0;const e=()=>{try{if(n.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(bS)==="1"}catch{return!1}},t=()=>{try{const x=window.sessionStorage.getItem(sl);if(!x)return{stack:[],index:-1};const L=JSON.parse(x);return!L||!Array.isArray(L.stack)||typeof L.index!="number"?{stack:[],index:-1}:L}catch{return{stack:[],index:-1}}},s=(x,L)=>{try{window.sessionStorage.setItem(sl,JSON.stringify({stack:x,index:L}))}catch{}},i=()=>{try{window.sessionStorage.removeItem(sl)}catch{}},r=x=>{try{const L=x??window.location.href,b=new URL(L instanceof URL?L.toString():L,window.location.href);return`${b.pathname}${b.search}${b.hash}`}catch{return null}},o=(x,L)=>{if(x.length<=bp)return{stack:x,index:L};const b=x.length-bp,y=x.slice(b),v=Math.max(0,L-b);return{stack:y,index:v}},a=x=>{document.readyState==="complete"||document.readyState==="interactive"?x():window.addEventListener("DOMContentLoaded",x,{once:!0})};let l=!1,u=!1,h=!1;const p=()=>{if(!l)return;const x=t(),L=r();if(L){if(x.stack.length===0){x.stack.push(L),x.index=0,s(x.stack,x.index);return}(x.index<0||x.index>=x.stack.length)&&(x.index=x.stack.length-1),x.stack[x.index]!==L&&(x.stack[x.index]=L,s(x.stack,x.index))}},m=(x,L)=>{if(!l||u)return;const b=r(x);if(!b)return;let{stack:y,index:v}=t();y.length===0?(y.push(b),v=y.length-1):L?((v<0||v>=y.length)&&(v=y.length-1),y[v]=b):v>=y.length-1?(y.push(b),v=y.length-1):(y=y.slice(0,v+1),y.push(b),v=y.length-1),{stack:y,index:v}=o(y,v),s(y,v)},w=()=>{if(!l||u)return;const x=t();if(x.stack.length===0){p();return}const L=x.index>=0&&x.index<x.stack.length?x.index:x.stack.length-1,b=r();if(x.stack.length===1&&b===x.stack[0])return;const y=x.stack[0];if(!y)return;u=!0;try{history.replaceState(history.state,document.title,y);for(let T=1;T<x.stack.length;T+=1)history.pushState(history.state,document.title,x.stack[T])}catch{u=!1;return}u=!1;const v=x.stack.length-1,I=L-v;I!==0?history.go(I):(history.replaceState(history.state,document.title,x.stack[L]),window.dispatchEvent(new PopStateEvent("popstate")))},E=()=>{!l||h||(h=!0,a(()=>{h=!1,w()}))};let $=null,R=null;const B=()=>{if(!l||u)return;const x=r();if(!x)return;const L=t(),b=L.stack.lastIndexOf(x);b>=0?L.index=b:(L.stack.push(x),L.index=L.stack.length-1);const y=o(L.stack,L.index);s(y.stack,y.index)},H=()=>{$&&R||($=history.pushState,R=history.replaceState,history.pushState=function(L,b,y){const v=$==null?void 0:$.call(history,L,b,y);return m(y,!1),v},history.replaceState=function(L,b,y){const v=R==null?void 0:R.call(history,L,b,y);return m(y,!0),v},window.addEventListener("popstate",B))},K=()=>{$&&(history.pushState=$,$=null),R&&(history.replaceState=R,R=null),window.removeEventListener("popstate",B)},se=x=>{if(l===x){l&&(p(),E());return}l=x,l?(H(),p(),E()):(K(),i())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",x=>{var L;const b=x,y=(L=b==null?void 0:b.detail)===null||L===void 0?void 0:L.enabled;typeof y=="boolean"?(n.__capgoKeepUrlPathAfterReload=y,se(y)):(n.__capgoKeepUrlPathAfterReload=!0,se(!0))}),se(e())}}var wp;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",n[n.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",n[n.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(wp||(wp={}));var Ip;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.PENDING=1]="PENDING",n[n.DOWNLOADING=2]="DOWNLOADING",n[n.INSTALLING=3]="INSTALLING",n[n.INSTALLED=4]="INSTALLED",n[n.FAILED=5]="FAILED",n[n.CANCELED=6]="CANCELED",n[n.DOWNLOADED=11]="DOWNLOADED"})(Ip||(Ip={}));var Ep;(function(n){n[n.OK=0]="OK",n[n.CANCELED=1]="CANCELED",n[n.FAILED=2]="FAILED",n[n.NOT_AVAILABLE=3]="NOT_AVAILABLE",n[n.NOT_ALLOWED=4]="NOT_ALLOWED",n[n.INFO_MISSING=5]="INFO_MISSING"})(Ep||(Ep={}));const Gr=po("CapacitorUpdater",{web:()=>Cn(()=>import("./web-DN4mk4-J.js"),[]).then(n=>new n.CapacitorUpdaterWeb)}),wn=zr.isNativePlatform(),Mt=wn?po("TechMate"):null,Hl={accent:0,view:"lists",sun:!1,showDone:!0,compact:!1,defRems:"60,0",dueRems:"1440,0",rep:!0,repMin:5,repMax:6,snooze:10,alarmSound:!1,clockMode:!1,syncMin:60,notifyNew:!0,wAlpha:95,wMode:"todo",wList:"",wDays:2,autoUpd:!0,empClr:"{}",bUri:"",bAuto:!0,bLast:0};let bs={...Hl};const cv="tm-settings",We=()=>bs;async function Kr(){if(Mt)try{const n=await Mt.getSettings();bs={...Hl,...n||{}}}catch{}else try{bs={...Hl,...JSON.parse(localStorage.getItem(cv)||"{}")}}catch{}return bs}async function Sr(n,e){if(bs={...bs,[n]:e},Mt)try{await Mt.setSetting({k:n,v:e})}catch{}else try{localStorage.setItem(cv,JSON.stringify(bs))}catch{}}const Re=async(n,e={},t=null)=>{if(!Mt)return t;try{return await Mt[n](e)}catch(s){return{error:s&&s.message||"σφάλμα"}}},ye={setSession:n=>Re("setSession",n),clearSession:()=>Re("clearSession"),setTasks:(n,e,t)=>Re("setTasks",{json:n,emps:e,lists:t}),testNotif:()=>Re("testNotif"),openBattery:()=>Re("openBattery"),openNotifSettings:()=>Re("openNotifSettings"),exactAlarms:()=>Re("exactAlarms",{},{ok:!0}),msStatus:()=>Re("msStatus",{},{connected:!1}),msLogin:()=>Re("msLogin"),msSync:()=>Re("msSync",{},{ok:!1}),msDisconnect:()=>Re("msDisconnect"),pull:()=>Re("pull",{},{ok:!1}),backupPick:()=>Re("backupPick",{},{error:"Μόνο στο κινητό"}),backupWrite:n=>Re("backupWrite",{json:n},{error:"Μόνο στο κινητό"}),takeLaunch:()=>Re("takeLaunch",{},{}),installApk:(n,e)=>Re("installApk",{url:n,size:e}),copy:async n=>{if(Mt)return Re("copy",{text:n});try{await navigator.clipboard.writeText(n)}catch{}},paste:async()=>{if(Mt){const n=await Re("paste");return n&&n.text||""}try{return await navigator.clipboard.readText()}catch{return""}},share:n=>Mt?Re("share",{text:n}):ye.copy(n),filesStatus:()=>Re("filesStatus",{},{connected:!1,account:""}),filesLogin:()=>Re("filesLogin"),filesDisconnect:()=>Re("filesDisconnect"),filesToken:()=>Re("filesToken",{},{ok:!1,error:"Μόνο στο κινητό"}),shareFile:n=>Re("shareFile",n,{error:"Μόνο στο κινητό"}),refreshWidgets:()=>Re("refreshWidgets")};function mo(n,e){Mt&&Mt.addListener(n,e)}const lv="1.3.0",IS="https://raw.githubusercontent.com/cursing/techmate-app-releases/main/latest.json",uv=zr.isNativePlatform(),Tp=(n,e)=>{const t=String(n).split(".").map(Number),s=String(e).split(".").map(Number);for(let i=0;i<3;i++){const r=(t[i]||0)-(s[i]||0);if(r)return r}return 0},Oe={state:"idle",latest:null,pct:0,err:"",needApk:!1,checkedAt:0};let dv=()=>{};function ES(n){dv=n}const Nt=n=>{Object.assign(Oe,n),dv()};function TS(){uv&&(Gr.notifyAppReady().catch(()=>{}),Gr.addListener("download",n=>{Oe.state==="downloading"&&Nt({pct:Math.round(n.percent||0)})}),mo("apk",n=>{Oe.state==="downloading"&&Nt({pct:n&&n.pct||0})}),Ql(),document.addEventListener("visibilitychange",()=>{!document.hidden&&Date.now()-Oe.checkedAt>30*6e4&&Ql()}))}async function Ql(n){if(!uv){n&&Nt({state:"none"});return}if(Oe.state!=="downloading"){n&&Nt({state:"checking",err:""});try{const e=await fetch(IS+"?t="+Date.now(),{cache:"no-store"});if(!e.ok)throw new Error("HTTP "+e.status);const t=await e.json();if(Oe.checkedAt=Date.now(),!t.version||Tp(t.version,lv)<=0)return Nt({state:n?"none":"idle",latest:null});let s="0";try{s=(await Gr.getBuiltinVersion()).version||"0"}catch{}Nt({state:"available",latest:t,needApk:!!t.minNative&&Tp(s,t.minNative)<0,err:""})}catch{Nt({state:n?"error":"idle",err:n?"Δεν μπόρεσα να ελέγξω για ενημέρωση. Έλεγξε τη σύνδεση.":""})}}}async function AS(){const n=Oe.latest;if(!(!n||Oe.state==="downloading")){if(Oe.needApk){Nt({state:"downloading",pct:0,err:""});const e=await ye.installApk(n.apk,n.apkSize||0);Nt({state:"available",err:e&&e.error?e.error:""});return}Nt({state:"downloading",pct:0,err:""});try{const e=await Gr.download({url:n.zip,version:n.version,checksum:n.sha256||""});await Gr.set(e)}catch(e){Nt({state:"available",err:"Η λήψη απέτυχε: "+(e&&(e.message||e.code)||"άγνωστο σφάλμα")})}}}const SS=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Jl=n=>SS.format(Math.round((n||0)*100)/100),Ap=n=>n<10?"0"+n:""+n,pe=()=>{const n=new Date;return n.getFullYear()+"-"+Ap(n.getMonth()+1)+"-"+Ap(n.getDate())},kS=n=>(n=P(n,24),[24,13,6,0].includes(n)?n:24),ud=()=>{const n=Ai();return n&&(A.st.roles&&A.st.roles.users||{})[n.uid]||null},_e=()=>{const n=ud();return!!(n&&n.role==="team")},Lt=()=>{const n=ud();return n&&n.empId||""},zn=()=>{const n=Ai();if(!n)return null;const e=ud();return{uid:n.uid,name:e?e.name||"Υπάλληλος":"Διαχειριστής"}},dd=n=>!_e()||!!(n&&n.by&&Ai()&&n.by.uid===Ai().uid),oa={pending:"Σε αναμονή απάντησης",accepted:"Έγινε δεκτή, προς εγκατάσταση",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"},il=(n,e,t)=>Ue("qlog",{id:je(),qid:n.id||"",number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:e,text:t}),hv=n=>A.ldocs.find(e=>e.kind==="sale"&&(e.qid===n.id||!e.qid&&n.number&&e.number===n.number&&$e(e.party)===$e(n.customer&&n.customer.name)))||null,Sp=n=>!(n&&n.war&&n.war.on===!1),RS=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(P(e.m,0))):P(ae().warrantyMonths,24)};function PS(n,e){let t=0,s=0,i=0;return A.ldocs.forEach(r=>{r.kind==="purchase"&&r.items&&r.items.forEach(o=>{o.pid===n&&(t+=P(o.qty))})}),A.smoves.forEach(r=>{r.pid===n&&(t+=P(r.qty))}),A.quotes.forEach(r=>{if(r.id===e)return;const o=nt(r);(r.lines||[]).forEach(a=>{if(a.pid!==n||a.src!=="stock")return;const l=P(a.qty);o==="done"?r.noStock||(s+=l):o==="accepted"&&(i+=l)})}),U(t-s-i)}function CS(n,e){const t=[],s=hv(n);if(e==="pending"||e==="rejected"?s&&s.qid===n.id&&s.note==="Από προσφορά "+(n.number||"")&&hc(s.id)===0&&t.push("Θα αφαιρεθεί το παραστατικό πώλησης που είχε δημιουργηθεί αυτόματα."):!s&&ae()&&ae().autoSale!==!1&&t.push("Θα δημιουργηθεί παραστατικό πώλησης "+Jl(fv(n).gross)+" στα Λογιστικά."),e==="done"&&!n.install&&t.push("Θα καταχωρηθεί ως εγκατάσταση με σημερινή ημερομηνία."),(e==="accepted"||e==="done")&&n.gid){const i=A.quotes.filter(r=>r.gid===n.gid&&r.id!==n.id&&nt(r)==="pending").length;i&&t.push("Οι "+i+" άλλες εναλλακτικές θα μπουν ως «Απορρίφθηκε».")}return t}function fv(n){const e=n.vatMode==="off"?0:kS(ae().vat),t=cd(n),s=U(t*e/100);return{rate:e,net:t,vat:s,gross:U(t+s)}}function DS(n,e){const t=A.quotes.find(a=>a.id===n);if(!t||nt(t)===e)return{ok:!1};if(!ae())return{ok:!1,msg:"Δεν έχουν φορτώσει οι ρυθμίσεις. Περίμενε λίγο ή έλεγξε τη σύνδεση."};const s=ut(t);il(s,"status",oa[nt(s)]+" → "+oa[e]),e==="done"&&!s.install&&(s.install={date:pe(),months:Sp(s)?RS(s):0,serials:"",nw:!Sp(s)}),s.status=e,s.statusDate=pe();const i=[];e==="accepted"&&(s.lines||[]).forEach(a=>{if(a.pid&&a.src==="stock"&&P(a.qty)>PS(a.pid,s.id)){const l=A.products.find(u=>u.id===a.pid);i.push(l?l.model:a.desc)}});const r=[],o=hv(s);if(e==="pending"||e==="rejected")o&&o.qid===s.id&&o.note==="Από προσφορά "+(s.number||"")&&hc(o.id)===0&&(iv("ldocs",o.id),r.push("Αφαιρέθηκε το αυτόματο παραστατικό πώλησης."));else if(!o&&ae().autoSale!==!1){const a=fv(s),l={id:je(),ts:Date.now(),kind:"sale",date:pe(),party:s.customer&&s.customer.name||"Πελάτης",number:s.number||"",cat:"",net:a.net,vat:a.vat,gross:a.gross,rate:a.rate,note:"Από προσφορά "+(s.number||""),items:[],qid:s.id};Ue("ldocs",l),A.lpays.forEach(u=>{u.qid===s.id&&!u.docId&&Vs("lpays",u.id,{docId:l.id,party:l.party||u.party})}),il(s,"edit","Δημιουργήθηκε αυτόματα παραστατικό πώλησης ("+Jl(a.gross)+")."),r.push("Δημιουργήθηκε παραστατικό πώλησης "+Jl(a.gross)+" στα Λογιστικά.")}return s.gid&&(e==="accepted"||e==="done")&&A.quotes.filter(a=>a.gid===s.gid&&a.id!==s.id&&nt(a)==="pending").forEach(a=>{const l=ut(a);l.status="rejected",l.statusDate=pe(),il(l,"status","Σε αναμονή → Απορρίφθηκε (έγινε δεκτή η εναλλακτική "+(s.number||"")+")"),Ue("quotes",l)}),Ue("quotes",s),i.length&&r.push("Δεν επαρκεί το απόθεμα για: "+i.join(", ")+"."),{ok:!0,msg:["Η κατάσταση άλλαξε: "+oa[e]+"."].concat(r).join(" ")}}function $S(n,e){const t=String(e.name||"").trim();if(!t)return{msg:"Γράψε όνομα πελάτη."};const s=$e(t),i=Zt(),r=n&&i.find(u=>u.k===n);if((!n||n!==s)&&i.some(u=>u.k===s))return{msg:"Υπάρχει ήδη πελάτης «"+t+"». Άνοιξε τον φάκελό του."};const o=n&&A.custs.find(u=>$e(u.name)===n),a=o?ut(o):{id:je(),ts:Date.now()},l=u=>String(e[u]||"").trim();return Object.assign(a,{name:t,phone:l("phone"),email:l("email"),afm:l("afm"),address:l("address"),notes:l("notes"),upd:Date.now()}),Ue("custs",a),n&&n!==s&&r&&(r.quotes.concat(r.mins).forEach(u=>{const h=ut(u);h.customer=Object.assign({},h.customer||{},{name:t}),Ue("quotes",h)}),A.ldocs.forEach(u=>{u.kind==="sale"&&$e(u.party)===n&&Vs("ldocs",u.id,{party:t})}),A.lpays.forEach(u=>{u.dir==="in"&&$e(u.party)===n&&Vs("lpays",u.id,{party:t})})),{ok:!0,k:s}}const Ke=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),VS=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),ue=n=>VS.format(Math.round((n||0)*100)/100),pv=n=>String(U(n)).replace(".",","),ci=n=>P(String(n).replace(",","."),NaN),Wr=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},kp=n=>n<10?"0"+n:""+n,Ws=n=>n.getFullYear()+"-"+kp(n.getMonth()+1)+"-"+kp(n.getDate()),mv=()=>A.st.books||{},NS=n=>(n=P(n,24),[24,13,6,0].includes(n)?n:24);let Hr="month";try{Hr=localStorage.getItem("tm_period")||"month"}catch{}const xS=[["month","Μήνας"],["prevmonth","Προηγ. μήνας"],["quarter","Τρίμηνο"],["year","Έτος"],["all","Όλα"]];function gv(){const n=new Date,e=n.getFullYear(),t=n.getMonth();switch(Hr){case"month":return[Ws(new Date(e,t,1)),Ws(new Date(e,t+1,0))];case"prevmonth":return[Ws(new Date(e,t-1,1)),Ws(new Date(e,t,0))];case"quarter":{const s=Math.floor(t/3)*3;return[Ws(new Date(e,s,1)),Ws(new Date(e,s+3,0))]}case"year":return[e+"-01-01",e+"-12-31"];default:return["",""]}}const gs=n=>{const e=gv();return(!e[0]||n>=e[0])&&(!e[1]||n<=e[1])},OS=()=>{const n=gv();return!n[0]&&!n[1]?"Όλες οι κινήσεις":Wr(n[0])+" έως "+Wr(n[1])};function yv(n){let e=0,t=0;return A.wdays.forEach(s=>{s.empId===n&&(e+=P(s.amount))}),A.wpays.forEach(s=>{s.empId===n&&(t+=P(s.amount))}),{earned:U(e),paid:U(t),bal:U(e-t)}}function fc(){const n={},e={},t=(i,r)=>{const o=$e(r)||"—";return i[o]||(i[o]={name:(r||"").trim()||"Χωρίς όνομα",inv:0,paid:0})};A.ldocs.forEach(i=>{t(i.kind==="sale"?e:n,i.party).inv+=P(i.gross)}),A.lpays.forEach(i=>{t(i.dir==="in"?e:n,i.party).paid+=P(i.amount)});const s=i=>Object.values(i).map(r=>(r.inv=U(r.inv),r.paid=U(r.paid),r.bal=U(r.inv-r.paid),r)).sort((r,o)=>o.bal-r.bal);return{sup:s(n),cus:s(e)}}function MS(){const n={sNet:0,sVat:0,pNet:0,pVat:0,inBank:0,inCash:0,outBank:0,outCash:0,wages:0,cats:{}};A.ldocs.forEach(i=>{if(!(i.opening||!gs(i.date)))if(i.kind==="sale")n.sNet+=P(i.net),n.sVat+=P(i.vat);else{n.pNet+=P(i.net),n.pVat+=P(i.vat);const r=i.cat||"Χωρίς κατηγορία";n.cats[r]=(n.cats[r]||0)+P(i.net)}}),A.lpays.forEach(i=>{gs(i.date)&&(i.dir==="in"?i.method==="bank"?n.inBank+=P(i.amount):n.inCash+=P(i.amount):i.method==="bank"?n.outBank+=P(i.amount):n.outCash+=P(i.amount))}),A.wdays.forEach(i=>{gs(i.date)&&(n.wages+=P(i.amount))}),A.wpays.forEach(i=>{gs(i.date)&&(i.method==="bank"?n.outBank+=P(i.amount):n.outCash+=P(i.amount))}),Object.keys(n).forEach(i=>{typeof n[i]=="number"&&(n[i]=U(n[i]))}),n.vatDue=U(n.sVat-n.pVat),n.profit=U(n.sNet-n.pNet-n.wages);let e=P(mv().opening,0),t=0;A.lpays.forEach(i=>{const r=i.dir==="in"?P(i.amount):-P(i.amount);i.method==="bank"?e+=r:t+=r}),A.wpays.forEach(i=>{i.method==="bank"?e-=P(i.amount):t-=P(i.amount)}),n.bank=U(e),n.cash=U(t),n.rcvAll=U(n.inBank+n.inCash),n.nRcv=A.lpays.filter(i=>i.dir==="in"&&gs(i.date)).length;const s=fc();return n.owe=0,n.due=0,n.nOwe=0,n.nDue=0,n.wOwe=0,n.nW=0,s.sup.forEach(i=>{i.bal>.004&&(n.owe+=i.bal,n.nOwe++)}),s.cus.forEach(i=>{i.bal>.004&&(n.due+=i.bal,n.nDue++)}),A.emps.forEach(i=>{const r=yv(i.id).bal;r>.004&&(n.wOwe+=r,n.nW++)}),n.owe=U(n.owe),n.due=U(n.due),n.wOwe=U(n.wOwe),n}function go(n){const e=hc(n.id),t=U(P(n.gross)-e);return P(n.gross)!==0&&t<=.004?{k:"paid",t:n.kind==="sale"?"Εισπράχθηκε":"Πληρώθηκε",rem:0}:e>0?{k:"part",t:"Μερικώς",rem:t}:{k:"open",t:n.kind==="sale"?"Δεν εισπράχθηκε":"Ανεξόφλητο",rem:t}}const LS=(n,e)=>{const t=e==="in"?"sale":"purchase",s=$e(n);return A.ldocs.filter(i=>i.kind===t&&(!s||$e(i.party)===s)&&go(i).k!=="paid").sort((i,r)=>i.date<r.date?1:-1)},vv=[["sum","Σύνοψη"],["docs","Παραστατικά"],["pays","Πληρωμές"],["bal","Υπόλοιπα"]];let aa="all",fe=null;const _v=()=>!!fe;function FS(){fe=null}const Bo=(n,e,t="")=>`<div class="kpi"><b class="${t}">${n}</b><span>${e}</span></div>`,US={paid:"p-ok",part:"p-w",open:"p-b"},qS=(n,e)=>`<div class="chips">${vv.map(([t,s])=>`<a href="#/books/${t}" class="chip${t===n?" on":""}">${s}</a>`).join("")}</div>
  ${n==="bal"?"":`<div class="chips">${xS.map(([t,s])=>`<button data-bper="${t}" class="${t===Hr?"on":""}">${s}</button>`).join("")}</div><div class="plabel">${OS()}</div>`}${e?"":'<div class="upd">Φόρτωση…</div>'}`;function BS(){const n=MS(),e=Object.entries(n.cats).sort((t,s)=>s[1]-t[1]);return`<div class="kpis">${Bo(ue(n.sNet),"Έσοδα (καθαρά)","ok")}${Bo(ue(n.pNet),"Αγορές και έξοδα (καθαρά)","bad")}${Bo(ue(n.wages),"Μεροκάματα")}${Bo(ue(n.profit),"Κέρδος περιόδου",n.profit<0?"bad":"")}</div>
  ${n.sVat||n.pVat?`<div class="h">ΦΠΑ</div><div class="card"><div class="tot"><span>ΦΠΑ πωλήσεων</span><span>${ue(n.sVat)}</span></div><div class="tot"><span>ΦΠΑ αγορών</span><span>${ue(n.pVat)}</span></div>
    <div class="tot big"><span>${n.vatDue>=0?"ΦΠΑ προς απόδοση":"ΦΠΑ πιστωτικό"}</span><span>${ue(Math.abs(n.vatDue))}</span></div></div>`:""}
  <div class="h">Χρήματα</div><div class="card"><div class="tot"><span>Εισπράξεις περιόδου${n.nRcv?" ("+n.nRcv+")":""}</span><span>${ue(n.rcvAll)}</span></div>
    <div class="tot"><span>· τράπεζα ${ue(n.inBank)} · μετρητά ${ue(n.inCash)}</span><span></span></div>
    <div class="tot"><span>Πληρωμές περιόδου</span><span>${ue(U(n.outBank+n.outCash))}</span></div>
    <div class="tot big"><span>Τράπεζα σήμερα</span><span>${ue(n.bank)}</span></div><div class="tot big"><span>Μετρητά στο ταμείο</span><span>${ue(n.cash)}</span></div></div>
  <div class="h">Υπόλοιπα</div><div class="card">
    <a class="row" href="#/books/bal"><div class="av">👥</div><div class="t"><b>Πελάτες μου χρωστούν</b><span>${n.nDue} πελάτες</span></div><span class="amt">${ue(n.due)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">🏭</div><div class="t"><b>Χρωστάω σε προμηθευτές</b><span>${n.nOwe} προμηθευτές</span></div><span class="amt">${ue(n.owe)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">👷</div><div class="t"><b>Μεροκάματα που χρωστάω</b><span>${n.nW} υπάλληλοι</span></div><span class="amt">${ue(n.wOwe)}</span></a></div>
  ${e.length?`<div class="h">Έξοδα ανά κατηγορία</div><div class="card">${e.map(([t,s])=>`<div class="tot"><span>${Ke(t)}</span><span>${ue(s)}</span></div>`).join("")}</div>`:""}`}function jS(){const n=A.ldocs.filter(e=>gs(e.date)&&(aa==="all"||e.kind===aa)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0));return`<div class="chips">${[["all","Όλα"],["sale","Πωλήσεις"],["purchase","Αγορές"]].map(([e,t])=>`<button data-bdk="${e}" class="${aa===e?"on":""}">${t}</button>`).join("")}</div>
  <div class="card">${n.map(e=>{const t=go(e);return`<div class="row"><div class="av">${e.kind==="sale"?"📤":"📥"}</div>
    <div class="t"><b>${Ke(e.party)}</b><span>${Wr(e.date)}${e.number?" · "+Ke(e.number):""}${e.cat?" · "+Ke(e.cat):""}${e.opening?" · παλιό υπόλοιπο":""}</span>${e.note?`<span>${Ke(e.note)}</span>`:""}
    ${t.k!=="paid"?`<button class="lnk" data-bpay="${Ke(e.id)}">${e.kind==="sale"?"💶 Είσπραξη":"💶 Πληρωμή"} ${ue(t.rem)}</button>`:""}</div>
    <div class="r"><div class="amt">${ue(e.gross)}</div><span class="pill ${US[t.k]}">${t.t}</span></div></div>`}).join("")||'<div class="empty">Κανένα παραστατικό στην περίοδο</div>'}</div>`}function zS(){return`<div class="card">${A.lpays.filter(e=>gs(e.date)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0)).map(e=>`<div class="row"><div class="av">${e.dir==="in"?"⬇️":"⬆️"}</div>
    <div class="t"><b>${Ke(e.party)}</b><span>${Wr(e.date)} · ${e.method==="bank"?"τράπεζα":"μετρητά"}${e.note?" · "+Ke(e.note):""}</span></div>
    <div class="r"><div class="amt ${e.dir==="in"?"ok":"bad"}">${e.dir==="in"?"+":"−"}${ue(e.amount)}</div></div></div>`).join("")||'<div class="empty">Καμία κίνηση στην περίοδο</div>'}</div>`}function GS(){const n=fc(),e=(s,i,r)=>s.map(o=>`<div class="row"><div class="t"><b>${Ke(o.name)}</b><span>τιμολογημένα ${ue(o.inv)} · πληρωμένα ${ue(o.paid)}</span>
    ${o.bal>.004?`<button class="lnk" data-bnew="${i}" data-party="${Ke(o.name)}">${i==="in"?"💶 Νέα είσπραξη":"💶 Νέα πληρωμή"}</button>`:""}</div>
    <div class="r"><span class="pill ${o.bal>.004?"p-b":o.bal<-.004?"p-w":"p-ok"}">${o.bal>.004?ue(o.bal):o.bal<-.004?"πιστωτικό "+ue(-o.bal):"εξοφλημένο"}</span></div></div>`).join("")||`<div class="empty">${r}</div>`,t=A.emps.slice().sort((s,i)=>String(s.name).localeCompare(i.name,"el"));return`<div class="h">Πελάτες</div><div class="card">${e(n.cus,"in","Δεν υπάρχουν πελάτες με παραστατικά")}</div>
  <div class="h">Προμηθευτές</div><div class="card">${e(n.sup,"out","Δεν υπάρχουν προμηθευτές")}</div>
  ${t.length?`<div class="h">Υπάλληλοι</div><div class="card">${t.map(s=>{const i=yv(s.id);return`<div class="row"><div class="t"><b>${Ke(s.name)}</b><span>δεδουλευμένα ${ue(i.earned)} · πληρωμένα ${ue(i.paid)}</span></div>
    <div class="r"><span class="pill ${i.bal>.004?"p-b":i.bal<-.004?"p-w":"p-ok"}">${i.bal>.004?ue(i.bal):i.bal<-.004?"προπληρωμή "+ue(-i.bal):"τακτοποιημένο"}</span></div></div>`}).join("")}</div>`:""}`}const Bt=(n,e,t="")=>`<label class="f">${e}<input class="in" data-bf="${n}" value="${Ke(fe.v[n]??"")}" ${t}></label>`,kr=(n,e)=>`<div class="seg">${e.map(([t,s])=>`<button data-bseg="${n}" data-v="${t}" class="${fe.v[n]===t?"on":""}">${s}</button>`).join("")}</div>`;function KS(){const n=fe.v,e=LS(n.party,n.dir),t=fc();return n.docId&&!e.some(s=>s.id===n.docId)&&(n.docId=""),`<div class="card pad">${kr("dir",[["in","Είσπραξη από πελάτη"],["out","Πληρωμή σε προμηθευτή"]])}
    ${Bt("date","Ημερομηνία",'type="date"')}${Bt("party",n.dir==="in"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.dir==="in"?t.cus:t.sup).map(s=>`<option value="${Ke(s.name)}">`).join("")}</datalist>
    <label class="f">Παραστατικό<select class="in" data-bf="docId"><option value="">Χωρίς σύνδεση με παραστατικό</option>${e.map(s=>`<option value="${Ke(s.id)}" ${s.id===n.docId?"selected":""}>${Wr(s.date)} · ${Ke(s.party)}${s.number?" · "+Ke(s.number):""} · υπόλοιπο ${ue(go(s).rem)}</option>`).join("")}</select></label>
    ${Bt("amount","Ποσό €",'inputmode="decimal"')}${kr("method",[["bank","Τράπεζα"],["cash","Μετρητά"]])}${Bt("note","Σημείωση")}</div>`}function hd(n){const e=ci(n.amount),t=P(n.rate,24);let s,i,r;return n.mode==="net"?(s=U(e),i=U(s*t/100),r=U(s+i)):(r=U(e),s=U(r/(1+t/100)),i=U(r-s)),{net:s,vat:i,gross:r,rate:t}}function WS(){const n=fe.v,e=fc(),t=isNaN(ci(n.amount))?null:hd(n);return`<div class="card pad">${kr("kind",[["purchase","Αγορά / έξοδο"],["sale","Πώληση"]])}
    ${Bt("date","Ημερομηνία",'type="date"')}${Bt("party",n.kind==="sale"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.kind==="sale"?e.cus:e.sup).map(s=>`<option value="${Ke(s.name)}">`).join("")}</datalist>
    ${Bt("number","Αριθμός παραστατικού")}
    ${n.kind==="purchase"?`${Bt("cat","Κατηγορία εξόδου",'list="bcl" autocomplete="off"')}<datalist id="bcl">${(mv().costCats||[]).map(s=>`<option value="${Ke(s)}">`).join("")}</datalist>`:""}
    ${Bt("amount","Ποσό €",'inputmode="decimal"')}${kr("mode",[["gross","Το ποσό είναι με ΦΠΑ"],["net","Το ποσό είναι χωρίς ΦΠΑ"]])}
    <div class="f">Συντελεστής ΦΠΑ</div>${kr("rate",[["24","24%"],["13","13%"],["6","6%"],["0","0%"]])}
    <div id="bprev" class="plabel">${t?`Καθαρό ${ue(t.net)} · ΦΠΑ ${ue(t.vat)} · Σύνολο ${ue(t.gross)}`:""}</div>${Bt("note","Σημείωση")}</div>`}function HS(n,e){if(n==="newpay"||n==="newdoc"){const s=n==="newpay"?"pay":"doc";return(!fe||fe.kind!==s)&&(fe={kind:s,v:s==="pay"?{dir:"in",date:pe(),party:"",docId:"",amount:"",method:"bank",note:"",...$a||{}}:{kind:"purchase",date:pe(),party:"",number:"",cat:"",amount:"",mode:"gross",rate:String(NS(ae()&&ae().vat)),note:""}}),$a=null,`<header class="top"><a class="ib" data-bact="cancel">←</a><h1>${s==="pay"?"Νέα κίνηση":"Νέο παραστατικό"}</h1></header><main class="body ed">${s==="pay"?KS():WS()}
      ${fe.msg?`<div class="err box">${Ke(fe.msg)}</div>`:""}</main><div class="bar"><button class="btn b2" data-bact="cancel">Άκυρο</button><button class="btn b1" data-bact="save">💾 Αποθήκευση</button></div>`}fe=null;const t=vv.some(([s])=>s===n)?n:"sum";return`<header class="top"><a class="ib" href="#/menu">←</a><h1>Λογιστικά</h1></header><main class="body">${qS(t,e)}${{sum:BS,docs:jS,pays:zS,bal:GS}[t]()}</main>
    <div class="fab2"><a class="btn b2" href="#/books/newdoc">＋ Παραστατικό</a><a class="btn b1" href="#/books/newpay">＋ Είσπραξη / πληρωμή</a></div>`}let $a=null;function QS(){const n=fe.v;if(!n.date)return"Βάλε ημερομηνία.";if(fe.kind==="pay"){let s=String(n.party||"").trim();const i=n.docId&&A.ldocs.find(r=>r.id===n.docId);return i&&(s=i.party),s?!String(n.amount).trim()||isNaN(ci(n.amount))?"Βάλε ποσό.":(Ue("lpays",{dir:n.dir,date:n.date,party:s,docId:n.docId||"",amount:U(ci(n.amount)),method:n.method,note:String(n.note||"").trim(),id:je(),ts:Date.now()}),""):"Βάλε "+(n.dir==="in"?"πελάτη":"προμηθευτή")+"."}const e=String(n.party||"").trim();if(!e)return"Βάλε "+(n.kind==="sale"?"πελάτη":"προμηθευτή")+".";if(!String(n.amount).trim()||isNaN(ci(n.amount)))return"Βάλε ποσό.";const t=hd(n);return Ue("ldocs",{kind:n.kind,date:n.date,party:e,number:String(n.number||"").trim(),cat:n.kind==="purchase"?String(n.cat||"").trim():"",net:t.net,vat:t.vat,gross:t.gross,rate:t.rate,note:String(n.note||"").trim(),items:[],id:je(),ts:Date.now()}),""}function JS(n,e,t,s){const i=n.closest("[data-bper],[data-bdk],[data-bpay],[data-bnew],[data-bseg],[data-bact]");if(!i)return!1;const r=i.dataset;if(r.bper){Hr=r.bper;try{localStorage.setItem("tm_period",Hr)}catch{}}else if(r.bdk)aa=r.bdk;else if(r.bpay){const o=A.ldocs.find(a=>a.id===r.bpay);return o&&($a={dir:o.kind==="sale"?"in":"out",party:o.party,docId:o.id,amount:pv(go(o).rem)}),fe=null,e("#/books/newpay"),!0}else{if(r.bnew)return $a={dir:r.bnew,party:r.party},fe=null,e("#/books/newpay"),!0;if(r.bseg)fe.v[r.bseg]=r.v,r.bseg==="dir"&&(fe.v.docId="");else if(r.bact==="cancel"){const o=fe&&fe.kind;return fe=null,e(o==="doc"?"#/books/docs":"#/books/pays",!0),!0}else if(r.bact==="save"){const o=QS();if(o)fe.msg=o;else{const a=fe.kind;return fe=null,s(a==="pay"?"Η κίνηση αποθηκεύτηκε.":"Το παραστατικό αποθηκεύτηκε."),e(a==="doc"?"#/books/docs":"#/books/pays",!0),!0}}}return t(),!0}function YS(n,e){if(!fe||!n.dataset.bf)return!1;const t=n.dataset.bf;if(fe.v[t]=n.value,fe.msg="",t==="docId"){const s=A.ldocs.find(i=>i.id===n.value);s&&(fe.v.party=s.party,fe.v.amount=pv(go(s).rem)),e()}else if(!(t==="party"&&fe.kind==="pay")){if(t==="amount"&&fe.kind==="doc"){const s=document.getElementById("bprev");if(s){const i=isNaN(ci(n.value))?null:hd(fe.v);s.textContent=i?`Καθαρό ${ue(i.net)} · ΦΠΑ ${ue(i.vat)} · Σύνολο ${ue(i.gross)}`:""}}}return!0}function XS(n,e){fe&&fe.kind==="pay"&&n.dataset.bf==="party"&&e()}const Be=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),ZS=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),xt=n=>ZS.format(Math.round((n||0)*100)/100),Kt=n=>String(U(n)).replace(".",","),ek=n=>P(String(n).replace(",","."),0),tk=()=>({war:{on:!0,m:null},id:null,number:null,date:null,ts:0,customer:{name:"",phone:"",email:"",afm:"",address:""},subject:"",notes:"",status:"pending",vatMode:"on",benefits:[],benShow:!0,planMarks:[],planOn:!0,gid:null,optName:"",validDays:null,payShow:!1,payIds:null,prepay:{type:"",val:0},lines:[]}),Va=n=>n===null||typeof n!="object"?JSON.stringify(n===void 0?null:n):Array.isArray(n)?"["+n.map(Va).join(",")+"]":"{"+Object.keys(n).sort().map(e=>JSON.stringify(e)+":"+Va(n[e])).join(",")+"}";let te=null;const bv=()=>!!te;function nk(){te=null}let ca=null;function sk(n){ca=n}function ik(n){if(n==="new"){const s=tk();return ca&&(Object.assign(s.customer,ca),ca=null),te={arg:n,q:s,base:null,pick:!1,pq:"",pcat:""}}const e=A.quotes.find(s=>s.id===n);if(!e)return null;const t=ut(e);return t.customer=Object.assign({name:"",phone:"",email:"",afm:"",address:""},t.customer),t.lines=t.lines||[],te={arg:n,q:t,base:Va(e),pick:!1,pq:"",pcat:""}}function rk(n,e){return`<div class="ln-ed" data-i="${e}">
    <div class="ln-top"><input class="in" data-l="desc" value="${Be(n.desc)}" placeholder="Περιγραφή"><button class="x" data-act="del" aria-label="Διαγραφή γραμμής">✕</button></div>
    <div class="ln-bot">
      <div class="step"><button data-act="dec">−</button><input class="in" data-l="qty" inputmode="decimal" value="${Be(Kt(P(n.qty)))}"><button data-act="inc">＋</button></div>
      <label>Τιμή €<input class="in" data-l="price" inputmode="decimal" value="${Be(Kt(P(n.price)))}"></label>
      <label>Έκπτ. %<input class="in" data-l="disc" inputmode="decimal" value="${Be(Kt(P(n.disc)))}"></label>
      <div class="ln-sum" data-sum>${xt(ad(n))}</div>
    </div></div>`}function wv(){const n=rv(te.q);return`<div class="tot"><span>Καθαρό</span><span>${xt(n.sub)}</span></div>
  ${n.off?"":`<div class="tot"><span>ΦΠΑ ${Kt(n.vp)}%</span><span>${xt(n.vat)}</span></div>`}
  <div class="tot big"><span>Σύνολο${n.off?" (χωρίς ΦΠΑ)":""}</span><span>${xt(n.total)}</span></div>`}function ok(){const n=[...new Set(A.products.map(s=>s.cat).filter(Boolean))].sort((s,i)=>s.localeCompare(i,"el")),e=$e(te.pq),t=A.products.filter(s=>(!te.pcat||s.cat===te.pcat)&&(!e||$e((s.model||"")+" "+(s.desc||"")+" "+(s.cat||"")).includes(e))).sort((s,i)=>((s.cat||"")+(s.model||"")).localeCompare((i.cat||"")+(i.model||""),"el")).slice(0,80);return`<div class="sheet"><div class="sheet-in">
    <div class="sheet-h"><b>Κατάλογος</b><button class="btn b1 sm" data-act="pick-close">Τέλος</button></div>
    <input class="search" id="pq" placeholder="🔍 Αναζήτηση προϊόντος" value="${Be(te.pq)}">
    <div class="chips"><button data-pcat="" class="${te.pcat?"":"on"}">Όλα</button>${n.map(s=>`<button data-pcat="${Be(s)}" class="${te.pcat===s?"on":""}">${Be(s)}</button>`).join("")}</div>
    <div class="sheet-list">${t.map(s=>{const i=te.q.lines.find(o=>o.pid===s.id),r=av(s.id,te.q.id);return`<button class="prow${i?" has":""}" data-pid="${Be(s.id)}"><div class="t"><b>${Be(s.model)}</b><span>${Be([s.cat,s.desc].filter(Boolean).join(" · "))}${r>=1?` · 📦 ${Kt(r)} στο ράφι`:""}</span></div>
      <div class="r"><div class="amt">${xt(ov(s))}</div>${i?`<span class="pill p-ok">×${Kt(P(i.qty))}</span>`:'<span class="muted">＋ προσθήκη</span>'}</div></button>`}).join("")||`<div class="empty">${A.products.length?"Δεν βρέθηκε προϊόν":"Ο κατάλογος είναι άδειος"}</div>`}</div>
  </div></div>`}function ak(n){if((!te||te.arg!==n)&&(te=null,!ik(n)))return null;const e=te.q,t=e.customer,s=Zt().map(i=>i.name).filter(i=>i&&i!=="(χωρίς όνομα)");return`<header class="top"><a class="ib" data-act="cancel">←</a><h1>${e.id?"Προσφορά #"+Be(e.number||"—"):"Νέα προσφορά"}<span class="sm">${e.id?"Επεξεργασία":"Δεν έχει αποθηκευτεί ακόμα"}</span></h1></header>
  <main class="body ed">
    <div class="card pad">
      <label class="f">Πελάτης<input class="in" data-c="name" list="cl" value="${Be(t.name)}" placeholder="Όνομα πελάτη" autocomplete="off"></label>
      <datalist id="cl">${s.map(i=>`<option value="${Be(i)}">`).join("")}</datalist>
      <details><summary>Τηλέφωνο, email, ΑΦΜ, διεύθυνση</summary>
        <label class="f">Τηλέφωνο<input class="in" data-c="phone" inputmode="tel" value="${Be(t.phone)}"></label>
        <label class="f">Email<input class="in" data-c="email" inputmode="email" value="${Be(t.email)}"></label>
        <label class="f">ΑΦΜ<input class="in" data-c="afm" inputmode="numeric" value="${Be(t.afm)}"></label>
        <label class="f">Διεύθυνση<input class="in" data-c="address" value="${Be(t.address)}"></label>
      </details>
      <label class="f">Θέμα<input class="in" data-q="subject" value="${Be(e.subject)}" placeholder="π.χ. Εγκατάσταση CCTV"></label>
    </div>
    <div class="h">Είδη (${e.lines.length})</div>
    <div class="card pad" id="lines">${e.lines.map(rk).join("")||'<div class="empty">Πρόσθεσε είδη από τον κατάλογο ή γράψε δική σου γραμμή.</div>'}</div>
    <div class="actions"><button class="btn b1" data-act="pick">📦 Κατάλογος</button><button class="btn b2" data-act="free">＋ Γραμμή</button><button class="btn b2" data-act="work">🛠️ Εργασία</button></div>
    <div class="card pad">
      <div class="seg"><button data-vat="on" class="${e.vatMode==="off"?"":"on"}">Με ΦΠΑ</button><button data-vat="off" class="${e.vatMode==="off"?"on":""}">Χωρίς ΦΠΑ</button></div>
      <div id="tots">${wv()}</div>
    </div>
    <div class="card pad"><label class="f">Σημειώσεις<textarea class="in" data-q="notes" rows="3">${Be(e.notes)}</textarea></label></div>
    ${te.msg?`<div class="err box">${Be(te.msg)}</div>`:""}
  </main>
  <div class="bar"><button class="btn b2" data-act="cancel">Άκυρο</button><button class="btn b1" data-act="save">💾 ${te.force?"Αποθήκευση (αντικατάσταση)":"Αποθήκευση"}</button></div>
  ${te.pick?ok():""}`}function ck(n,e,t){const s=()=>{const i=n.querySelector("#tots");i&&(i.innerHTML=wv())};n.oninput=i=>{const r=i.target,o=te&&te.q;if(o){if(r.dataset.c){if(o.customer[r.dataset.c]=r.value,r.dataset.c==="name"){const a=Zt().find(l=>l.k===$e(r.value));if(a){let l=!1;if(["phone","email","afm","address"].forEach(u=>{!o.customer[u]&&a.info[u]&&(o.customer[u]=a.info[u],l=!0)}),l){e();const u=n.querySelector('[data-c="name"]');u.focus(),u.setSelectionRange(u.value.length,u.value.length)}}}}else if(r.dataset.q)o[r.dataset.q]=r.value;else if(r.dataset.l){const a=r.closest(".ln-ed"),l=o.lines[+a.dataset.i];if(!l)return;l[r.dataset.l]=r.dataset.l==="desc"?r.value:ek(r.value),a.querySelector("[data-sum]").textContent=xt(ad(l)),s()}else if(r.id==="pq"){te.pq=r.value,e();const a=n.querySelector("#pq");a.focus(),a.setSelectionRange(a.value.length,a.value.length)}}},n.onclick=i=>{const r=te&&te.q;if(!r)return;const o=i.target.closest("[data-act],[data-vat],[data-pcat],[data-pid]");if(!o)return;const a=o.closest(".ln-ed"),l=a&&r.lines[+a.dataset.i],u=o.dataset.act;if(o.dataset.vat)r.vatMode=o.dataset.vat;else if(o.dataset.pcat!==void 0)te.pcat=o.dataset.pcat;else if(o.dataset.pid)lk(o.dataset.pid);else if(u==="inc")l.qty=U(P(l.qty)+1);else if(u==="dec")l.qty=Math.max(0,U(P(l.qty)-1));else if(u==="del")r.lines.splice(+a.dataset.i,1);else if(u==="free")r.lines.push({desc:"",qty:1,price:0,disc:0,showImg:!0});else if(u==="work")r.lines.push({desc:"Εργασία / εγκατάσταση",qty:1,price:0,disc:0,showImg:!0});else if(u==="pick")te.pick=!0;else if(u==="pick-close")te.pick=!1;else if(u==="cancel"){const h=r.id;return te=null,t(h)}else if(u==="save"){const h=hk();if(h)return te=null,t(h)}if(te.msg&&u!=="save"&&(te.msg="",te.force=!1),e(),u==="free"){const h=n.querySelectorAll('[data-l="desc"]');h[h.length-1].focus()}}}function lk(n){const e=A.products.find(s=>s.id===n);if(!e)return;const t=te.q.lines.find(s=>s.pid===n);t?t.qty=U(P(t.qty)+1):te.q.lines.push({pid:n,desc:e.model+(e.desc?" - "+e.desc:""),qty:1,price:ov(e),disc:0,src:av(n,te.q.id)>=1?"stock":"supplier",showImg:!!(e.img&&e.imgPdf!==!1)})}function uk(n,e){const t=[],s=(a,l,u)=>{String(l||"")!==String(u||"")&&t.push(a+": «"+(l||"—")+"» → «"+(u||"—")+"»")};s("Πελάτης",n.customer&&n.customer.name,e.customer&&e.customer.name),s("Θέμα",n.subject,e.subject),s("ΦΠΑ",n.vatMode==="off"?"χωρίς":"με",e.vatMode==="off"?"χωρίς":"με"),(n.notes||"")!==(e.notes||"")&&t.push("Άλλαξαν οι σημειώσεις");const i={},r={};if((n.lines||[]).forEach(a=>i[a.pid||a.desc]=a),(e.lines||[]).forEach(a=>r[a.pid||a.desc]=a),Object.keys(r).forEach(a=>{if(!i[a])t.push("Προστέθηκε: "+r[a].desc+" ×"+Kt(P(r[a].qty)));else{const l=i[a],u=r[a];P(l.qty)!==P(u.qty)&&t.push(u.desc+": ποσότητα "+Kt(P(l.qty))+" → "+Kt(P(u.qty))),P(l.price)!==P(u.price)&&t.push(u.desc+": τιμή "+xt(P(l.price))+" → "+xt(P(u.price))),P(l.disc)!==P(u.disc)&&t.push(u.desc+": έκπτωση "+Kt(P(u.disc))+"%")}}),Object.keys(i).forEach(a=>{r[a]||t.push("Αφαιρέθηκε: "+i[a].desc)}),!t.length)return"";const o=U(P(e.total)-P(n.total));return t.join("; ")+(o?" (σύνολο "+xt(P(n.total))+" → "+xt(P(e.total))+")":"")}const dk=n=>(n=P(n,24),[24,13,6,0].includes(n)?n:24);function hk(){const n=te.q,e=ae();if(n.lines=n.lines.filter(a=>String(a.desc||"").trim()).map(a=>({...a,desc:String(a.desc).trim(),qty:P(a.qty),price:P(a.price),disc:P(a.disc)})),!n.lines.length)return te.msg="Η προσφορά δεν έχει γραμμές.",null;if(!e)return te.msg="Δεν έχουν φορτώσει οι ρυθμίσεις (αρίθμηση, ΦΠΑ). Περίμενε λίγο ή έλεγξε τη σύνδεση.",null;const t=n.id?A.quotes.find(a=>a.id===n.id):null;if(n.id&&!t)return te.msg="Η προσφορά δεν υπάρχει πια (ίσως διαγράφηκε από άλλη συσκευή).",null;if(t&&Va(t)!==te.base&&!te.force)return te.force=!0,te.msg="Η προσφορά άλλαξε από άλλη συσκευή αφού την άνοιξες. Αν αποθηκεύσεις, οι αλλαγές εκείνες θα αντικατασταθούν. Πάτα ξανά «Αποθήκευση» για να συνεχίσεις, ή «Άκυρο».",null;let s=0;if(!n.number){const a=Math.max(1,Math.floor(P(e.next,1)));n.number=new Date().getFullYear()+"-"+String(a).padStart(3,"0"),s=a+1}n.date||(n.date=new Date().toLocaleDateString("el-GR")),n.id||(n.id=je(),n.ts=Date.now()),n.customer.name=String(n.customer.name||"").trim(),n.total=rv(n).total;const i=ut(n);Ue("quotes",i),s&&rS(s);const r=(a,l)=>Ue("qlog",{id:je(),qid:i.id,number:i.number||"",customer:i.customer.name||"",ts:Date.now(),type:a,text:l});if(!t)r("create","Νέα προσφορά, σύνολο "+xt(i.total)+", "+i.lines.length+" γραμμές.");else{const a=uk(t,i);a&&r("edit",a)}const o=A.ldocs.find(a=>a.kind==="sale"&&(a.qid===i.id||!a.qid&&i.number&&a.number===i.number&&$e(a.party)===$e(i.customer.name)));if(o){const a=i.vatMode==="off"?0:dk(e.vat),l=cd(i),u=U(l*a/100),h=U(l+u),p=i.customer.name||o.party;o.qid===i.id&&o.net===l&&o.vat===u&&o.gross===h&&o.rate===a&&o.party===p&&o.number===(i.number||"")||Vs("ldocs",o.id,{qid:i.id,net:l,vat:u,gross:h,rate:a,party:p,number:i.number||""})}return i.id}const ie=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Rp=n=>n<10?"0"+n:""+n,fd=n=>n.getFullYear()+"-"+Rp(n.getMonth()+1)+"-"+Rp(n.getDate()),Ls=n=>new Date(n+"T12:00:00"),kt=(n,e)=>{const t=Ls(n);return t.setDate(t.getDate()+e),fd(t)},Qr=(n,e)=>{const t=Ls(n),s=t.getDate();t.setDate(1),t.setMonth(t.getMonth()+e);const i=new Date(t.getFullYear(),t.getMonth()+1,0).getDate();return t.setDate(Math.min(s,i)),fd(t)},Fi="el-GR",Iv=n=>n.charAt(0).toUpperCase()+n.slice(1),pc=n=>Iv(Ls(n).toLocaleDateString(Fi,{weekday:"long",day:"numeric",month:"long",year:"numeric"})),Na=n=>Ls(n).toLocaleDateString(Fi,{weekday:"short",day:"numeric",month:"numeric"}),fk=n=>Iv(Ls(n).toLocaleDateString(Fi,{month:"long",year:"numeric"})),Ev=n=>{const e=pe();return n===e?"Σήμερα":n===kt(e,1)?"Αύριο":n===kt(e,-1)?"Χθες":Na(n)},li=[["Μπλε TechMate","#1F4E79"],["Γαλάζιο","#0288D1"],["Τιρκουάζ","#00897B"],["Πράσινο","#2E7D32"],["Λαχανί","#7CB342"],["Κίτρινο","#F2A900"],["Πορτοκαλί","#EF6C00"],["Κόκκινο","#D32F2F"],["Ροζ","#C2185B"],["Μωβ","#7B1FA2"],["Λουλακί","#3949AB"],["Γκρι","#546E7A"]],ys=n=>(li[n]||li[0])[1],Tv=()=>{try{return JSON.parse(We().empClr||"{}")}catch{return{}}},mc=n=>{const e=Tv()[n];return typeof e=="number"?e:-1};function Av(n){if(typeof n.clr=="number"&&n.clr>=0)return ys(n.clr);for(const e of n.emps||[]){const t=mc(e);if(t>=0)return ys(t)}return n.kind==="due"?ys(6):ys(P(We().accent,0))}const pd=-1,Sv=[0,15,30,60,120,1440,2880,10080,pd],xa=n=>String(n||"").split(",").map(e=>parseInt(e,10)).filter(e=>!isNaN(e));function md(n){return Array.isArray(n.rems)?n.rems.map(Number).filter(e=>!isNaN(e)):{none:[],eve:[pd],15:[15],30:[30],60:[60],120:[120]}[n.remOff||"at"]||[0]}function Yl(n){return n===0?"Στην ώρα":n===pd?"Το προηγ. βράδυ":n<60?n+"΄ πριν":n===60?"1 ώρα πριν":n<1440?n/60+" ώρες πριν":n===1440?"1 μέρα πριν":n===10080?"1 εβδομάδα πριν":n/1440+" μέρες πριν"}const pk=n=>n.length?n.includes(0)?"at":{[-1]:"eve",15:"15",30:"30",60:"60",120:"120"}[n[0]]||"at":"none",Xl={"":"Καμία",w:"Κάθε εβδομάδα",m:"Κάθε μήνα",y:"Κάθε χρόνο"},mk=n=>!_e()||!!Lt()&&(n.emps||[]).includes(Lt()),Zl=()=>A.tasks.filter(n=>!n.del&&mk(n)),gd=n=>!_e()||(n.emps||[]).includes(Lt()),yd=n=>{const e=A.emps.find(t=>t.id===n);return e?e.name:""},Jr=()=>A.emps.filter(n=>n.name&&String(n.name).trim()).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),Fi));function gc(){const n=A.st.main||{},e=n.msDefList||"",t=n.msToolList||"",s=n.msListNames||{},i=[...new Set((Array.isArray(n.msLists)?n.msLists:[]).filter(r=>r!==t).concat(e?[e]:[]))];return{def:e,lists:i.map(r=>({id:r,name:s[r]||"Λίστα"})).sort((r,o)=>(r.id===e?0:1)-(o.id===e?0:1))}}function vd(n,e){const t=String(e.title||"").trim();if(!t)return{msg:"Γράψε τίτλο πρώτα."};const s=n&&A.tasks.find(m=>m.id===n),i=!s;if(n&&!s)return{msg:"Η εργασία δεν υπάρχει πια (ίσως σβήστηκε)."};if(!i&&!dd(s))return{msg:"Μπορείς να αλλάξεις μόνο εργασίες που έγραψες εσύ."};if(_e()&&!Lt())return{msg:"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει."};const r=e.date||"",o=r&&e.time||"",a=Date.now(),l=!!(s&&s.done),u=(e.rems||[]).map(Number).filter((m,w,E)=>E.indexOf(m)===w).sort((m,w)=>w-m),h=i?{id:je(),ts:a,msId:"",msList:e.msList||"",rem:""}:{id:s.id};if(i){const m=zn();m&&(h.by=m)}!i&&(s.date!==r||(s.time||"")!==o||JSON.stringify(md(s).slice().sort((m,w)=>w-m))!==JSON.stringify(u))&&(h.rem="");let p=(e.emps||[]).slice();if(_e()&&(p=(i?e.emps||[]:s.emps||[]).slice(),p.includes(Lt())||p.push(Lt())),Object.assign(h,{title:t,date:r,time:o,emps:p,cust:String(e.cust||"").trim(),tel:String(e.tel||"").trim(),addr:String(e.addr||"").trim(),notes:String(e.notes||"").trim(),done:!!e.done,remOff:pk(u),rems:u,quoteId:e.quoteId||"",chk:(e.chk||[]).map(m=>({tx:String(m.tx||"").trim(),dn:!!m.dn})).filter(m=>m.tx),kind:e.kind||"",rep:e.rep||"",clr:typeof e.clr=="number"?e.clr:-1,upd:a,dirty:!0,del:!1}),h.done&&!l){h.doneAt=a;const m=zn();m&&(h.doneBy=m.name)}else h.done||(h.doneAt=void 0,h.doneBy=void 0);if(i){if(delete h.doneAt,delete h.doneBy,h.done){h.doneAt=a;const m=zn();m&&(h.doneBy=m.name)}Ue("tasks",h)}else Yt("tasks",h.id,h);return h.done&&!l&&kv(A.tasks.find(m=>m.id===h.id)||h),{ok:!0,id:h.id}}function rl(n,e){if(!n||!gd(n))return;const t=Date.now(),s=zn(),i=!!n.done;Vs("tasks",n.id,e?{done:!0,upd:t,dirty:!0,doneAt:t,doneBy:s&&s.name||""}:{done:!1,upd:t,dirty:!0,doneAt:void 0,doneBy:void 0}),e&&!i&&kv(n)}function gk(n,e){Vs("tasks",n.id,{chk:e.map(t=>({tx:t.tx,dn:!!t.dn})),upd:Date.now(),dirty:!0})}function kv(n){if(!n.date||!n.rep)return;const e=n.rep==="w"?kt(n.date,7):n.rep==="m"?Qr(n.date,1):n.rep==="y"?Qr(n.date,12):"";e&&vd(null,{...n,rems:md(n),date:e,done:!1,chk:(n.chk||[]).map(t=>({tx:t.tx,dn:!1})),msList:n.msList||""})}function yk(n){return dd(n)?(n.msId?Vs("tasks",n.id,{del:!0,dirty:!0,upd:Date.now()}):iv("tasks",n.id),{ok:!0}):{msg:"Μπορείς να σβήσεις μόνο εργασίες που έγραψες εσύ."}}const Q={view:"",sel:"",emp:"",q:"",srch:!1,list:"myday",showDone:!1,quick:"",preset:null,ms:null,emSel:""},ki=()=>Q.sel||(Q.sel=pe());let z=null;const Rv=()=>!!z,vk=()=>{z=null};function ui(n){Q.preset=n}const Yr=(n,e)=>n.done-e.done||(n.time||"99:99").localeCompare(e.time||"99:99")||String(n.title||"").localeCompare(String(e.title||""),Fi),_k=(n,e)=>(n.date?0:1)-(e.date?0:1)||(n.date||"").localeCompare(e.date||"")||(n.time||"99").localeCompare(e.time||"99")||(e.upd||0)-(n.upd||0),bk=(n,e)=>!e||[n.title,n.cust,n.addr,n.notes,n.tel].some(t=>String(t||"").toLowerCase().includes(e))||(n.chk||[]).some(t=>String(t.tx||"").toLowerCase().includes(e));function Pp(n){const e=Q.q.trim().toLowerCase();return Zl().filter(t=>(n||We().showDone||!t.done)&&(!Q.emp||(t.emps||[]).includes(Q.emp))&&bk(t,e))}function Gn(n,e){const t=!n.done&&n.date&&n.date<pe(),s=t?"var(--bad)":Av(n),i=[e&&n.date?t?"Καθυστέρηση · "+Na(n.date):Ev(n.date):"",n.cust,n.addr].filter(Boolean).join(" · "),r=(n.emps||[]).map(yd).filter(Boolean),o=(n.chk||[]).length?`<em>☑ ${(n.chk||[]).filter(u=>u.dn).length}/${n.chk.length}</em>`:"",a=[n.kind==="due"?"<em>💶 Λήξη</em>":"",n.rep?`<em>🔁 ${ie(Xl[n.rep]||"")}</em>`:"",o,!_e()&&r.length?`<em>👷 ${ie(r.join(", "))}</em>`:""].join(""),l=gd(n);return`<div class="tc${n.done?" dn":""}${We().compact?" cp":""}" style="--c:${s}">
    <button class="tick${n.done?" on":""}" ${l?`data-tk="${ie(n.id)}"`:"disabled"} aria-label="Ολοκληρώθηκε">${n.done?"✓":""}</button>
    <a class="tcb" href="#/t/${encodeURIComponent(n.id)}"><div class="t"><b>${n.kind==="due"?"💶 ":""}${ie(n.title||"(χωρίς τίτλο)")}</b>${i?`<span>${ie(i)}</span>`:""}${a&&!We().compact?`<div class="tags">${a}</div>`:""}</div>
    <div class="tcr" style="color:${s}">${ie(n.time||"")}</div></a></div>`}const ol=(n,e,t,s="")=>e.length?`<div class="h ${s}">${n}</div><div class="card">${e.map(i=>Gn(i,t)).join("")}</div>`:"";function wk(n){const e=ki(),t=Ls(e.slice(0,8)+"01"),s=!!We().sun,i=(t.getDay()+(s?0:6))%7,r=fd(new Date(t.getFullYear(),t.getMonth(),1-i)),o=s?["Κυρ","Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ"]:["Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ","Κυρ"],a=pe(),l=e.slice(0,7);let u="";for(let p=0;p<6;p++){const m=kt(r,p*7);if(p===5&&m.slice(0,7)!==l)break;for(let w=0;w<7;w++){const E=kt(m,w),$=(n[E]||[]).slice().sort(Yr);u+=`<button class="mc${E===e?" sel":""}${E===a?" now":""}${E.slice(0,7)!==l?" out":""}" data-csel="${E}"><b>${+E.slice(8)}</b><i>${$.slice(0,4).map(R=>`<u style="background:${Av(R)};opacity:${R.done?.35:1}"></u>`).join("")}</i>${$.length>4?`<small>+${$.length-4}</small>`:""}</button>`}}const h=(n[e]||[]).slice().sort(Yr);return`<div class="mnav"><button data-cmon="-1">‹</button><b>${fk(e)}</b><button data-cmon="1">›</button></div>
    <div class="card mgrid" id="mgrid"><div class="mh">${o.map(p=>`<span>${p}</span>`).join("")}</div><div class="mg">${u}</div></div>
    <div class="h">${ie(pc(e))}</div>
    <div class="card">${h.length?h.map(p=>Gn(p,!1)).join(""):'<div class="empty">Ελεύθερη μέρα. Πάτα «＋» για να προσθέσεις.</div>'}</div>`}function Ik(n){const e=ki(),t=!!We().sun,s=kt(e,-((Ls(e).getDay()+(t?0:6))%7)),i=pe();let r=`<div class="mnav"><button data-cwk="-1">‹</button><b>${Na(s)} – ${Na(kt(s,6))}</b><button data-cwk="1">›</button></div>`;for(let o=0;o<7;o++){const a=kt(s,o),l=(n[a]||[]).slice().sort(Yr);r+=`<div class="h wkh${a===i?" now":""}" data-csel="${a}">${a===i?"● ":""}${ie(pc(a))}${l.length?` · ${l.length}`:""}</div>`,r+=l.length?`<div class="card">${l.map(u=>Gn(u,!1)).join("")}</div>`:'<div class="wke">—</div>'}return r}function Ek(n){const e=pe(),t=(a,l)=>(a.date||"").localeCompare(l.date||"")||Yr(a,l),s=n.filter(a=>!a.done&&a.date&&a.date<e).sort(t),i={};n.filter(a=>a.date&&a.date>=e).sort(t).forEach(a=>(i[a.date]=i[a.date]||[]).push(a));const r=n.filter(a=>!a.date&&!a.done).sort((a,l)=>(l.upd||l.ts||0)-(a.upd||a.ts||0));return ol(`⚠️ Εκκρεμότητες από πριν (${s.length})`,s,!0,"badh")+Object.keys(i).map(a=>ol((a===e||a===kt(e,1)?Ev(a)+" · ":"")+pc(a),i[a],!1)).join("")+ol("Χωρίς ημερομηνία",r,!1)||'<div class="card"><div class="empty">Δεν υπάρχει τίποτα προγραμματισμένο.</div></div>'}function Tk(n){const{def:e,lists:t}=gc(),s=pe(),i=Q.list,r=n.filter(u=>i==="myday"?u.date&&u.date<=s&&(!u.done||u.date===s):i==="planned"?!!u.date:i==="all"?!0:u.msList===i||!u.msList&&i===e),o=r.filter(u=>!u.done).sort(_k),a=r.filter(u=>u.done).sort((u,h)=>(h.upd||0)-(u.upd||0));return`<div class="chips">${[["myday","☀️ Η μέρα μου"],["planned","📅 Προγραμματισμένες"],["all","📥 Όλες"]].concat(t.map(u=>[u.id,"≡ "+u.name])).map(([u,h])=>`<button data-clist="${ie(u)}" class="${i===u?"on":""}">${ie(h)}</button>`).join("")}</div>
    <div class="qadd"><input class="search" data-cqv placeholder="＋ Προσθήκη εργασίας" value="${ie(Q.quick)}" enterkeyhint="done"><button class="btn b1 sm" data-cqa>Προσθήκη</button></div>
    ${o.length?`<div class="card">${o.map(u=>Gn(u,!0)).join("")}</div>`:a.length?"":`<div class="card"><div class="empty">${i==="myday"?"Τίποτα για σήμερα 🙂":"Η λίστα είναι άδεια."}</div></div>`}
    ${a.length?`<div class="h lnk2" data-cdone>${Q.showDone?"▾":"▸"} Ολοκληρωμένες (${a.length})</div>${Q.showDone?`<div class="card">${a.map(u=>Gn(u,!0)).join("")}</div>`:""}`:""}`}function Cp(n,e,t,s){s&&s!==Q.argV&&["lists","month","week","agenda"].includes(s)&&(Q.view=s,Q.argV=s),Q.view||(Q.view=We().view||"lists");const i=Q.view,r=Pp(!1),o={};r.forEach(p=>{p.date&&(o[p.date]=o[p.date]||[]).push(p)});const a=[["lists","☑ Λίστες"],["month","🗓 Μήνας"],["week","Εβδ."],["agenda","Ατζέντα"]],l=_e()?[]:Jr(),u=e("Ημερολόγιο",_e()?(zn()||{}).name||"":"Πρόγραμμα · εργασίες · λήξεις","",`<button class="ib" data-csrch aria-label="Αναζήτηση">${Q.srch?"✕":"🔍"}</button><button class="ib" data-ctoday aria-label="Σήμερα">◎</button><a class="ib" href="#/cset" aria-label="Ρυθμίσεις">⚙️</a>`),h=`${Q.srch?`<input class="search" id="csq" data-csq placeholder="🔍 Αναζήτηση σε τίτλο, πελάτη, σημειώσεις…" value="${ie(Q.q)}">`:""}
    <div class="seg">${a.map(([p,m])=>`<button data-cv="${p}" class="${i===p?"on":""}">${m}</button>`).join("")}</div>
    ${l.length?`<div class="chips"><button data-cemp="" class="${Q.emp?"":"on"}">Όλοι</button>${l.map(p=>{const m=mc(p.id);return`<button data-cemp="${ie(p.id)}" class="${Q.emp===p.id?"on":""}">${m>=0?`<u class="dot" style="background:${ys(m)}"></u>`:""}${ie(p.name)}</button>`}).join("")}</div>`:""}
    ${n?i==="month"?wk(o):i==="week"?Ik(o):i==="agenda"?Ek(r):Tk(Pp(!0)):'<div class="card"><div class="empty">Φόρτωση…</div></div>'}`;return t(u,h,"cal",'<button class="fab" data-cnew aria-label="Νέα εργασία">＋</button>')}function Ak(n){const e=n!=="new"&&A.tasks.find(i=>i.id===n);if(n!=="new"&&!e)return!1;const t=Q.preset||{};Q.preset=null;const s=xa(t.kind==="due"?We().dueRems:We().defRems);return z={arg:n,t0:e||null,isNew:!e,canEdit:!e||dd(e),canTick:!e||gd(e),msg:"",ask:!1,pick:null,err:!1,v:e?{kind:e.kind||"",title:e.title||"",date:e.date||"",time:e.time||"",rems:md(e),rep:e.rep||"",cust:e.cust||"",tel:e.tel||"",addr:e.addr||"",quoteId:e.quoteId||"",emps:(e.emps||[]).slice(),clr:typeof e.clr=="number"?e.clr:-1,notes:e.notes||"",chk:(e.chk||[]).map(i=>({tx:i.tx||"",dn:!!i.dn})),done:!!e.done,msList:e.msList||""}:{kind:t.kind||"",title:t.title||"",date:t.date!==void 0?t.date:pe(),time:"",rems:t.rems||s,rep:"",cust:t.cust||"",tel:t.tel||"",addr:t.addr||"",quoteId:t.quoteId||"",emps:[],clr:-1,notes:"",chk:[],done:!1,msList:t.msList||""}},!0}const Rr=(n,e,t)=>`<div class="chips wrap">${n.map(([s,i])=>`<button ${t}="${ie(s)}" class="${e(s)?"on":""}">${i}</button>`).join("")}</div>`,Sk=n=>{const e=A.quotes.find(t=>t.id===n);return e?`#${e.number||"—"} · ${e.customer&&e.customer.name||""}${e.subject?" · "+e.subject:""}`:"Συνδεδεμένη προσφορά"},Dp=n=>[n.kind==="due"?"💶 "+n.title:n.title,n.date?pc(n.date)+(n.time?" "+n.time:""):"",n.cust?"Πελάτης: "+n.cust:"",n.tel?"Τηλ: "+n.tel:"",n.addr?"Διεύθυνση: "+n.addr:"",(n.emps||[]).length?"Τεχνικοί: "+n.emps.map(yd).filter(Boolean).join(", "):"",n.notes?`
`+n.notes:"",(n.chk||[]).length?`
`+n.chk.map(e=>(e.dn?"✔ ":"▫ ")+e.tx).join(`
`):""].filter(Boolean).join(`
`);function kk(n,e,t,s){if((!z||z.arg!==n)&&!Ak(n))return s(t("Εργασία","",'<a class="ib" href="#/cal">←</a>'),`<div class="card"><div class="empty">${e?"Η εργασία δεν βρέθηκε (ίσως σβήστηκε).":"Φόρτωση…"}</div></div>`,null);const i=z.v,r=z.canEdit,o=r?"":"disabled",a=!_e(),l=(R,B,H="",K="")=>`<label class="f">${B}<span class="fw"><input class="in${R==="title"&&z.err?" ine":""}" data-tf="${R}" value="${ie(i[R]||"")}" ${o} ${H}>${K}</span></label>`,{def:u,lists:h}=gc(),p=z.isNew?i.kind==="due"?"Νέα λήξη / πληρωμή":"Νέα εργασία":r?"Επεξεργασία":"Εργασία",m=i.tel.replace(/\s/g,""),w=i.chk.filter(R=>R.dn).length,E=`${r?"":`<div class="upd">🔒 Την έγραψε ${ie(z.t0.by&&z.t0.by.name||"άλλος")}. Μπορείς να τη σημειώσεις ολοκληρωμένη και να τσεκάρεις το checklist.</div>`}
  <div class="card pad"><div class="ch">📅 Τι και πότε</div>
    ${r?`<div class="seg">${[["","🛠 Εργασία"],["due","💶 Λήξη / πληρωμή"]].map(([R,B])=>`<button data-tfk="${R}" class="${i.kind===R?"on":""}">${B}</button>`).join("")}</div>`:""}
    ${a&&z.isNew&&h.length>1?`<div class="f">Λίστα To Do</div>${Rr(h.map(R=>[R.id,ie(R.name)]),R=>R===i.msList||!i.msList&&R===u,"data-tlist")}`:!z.isNew&&i.msList&&h.find(R=>R.id===i.msList)?`<div class="f">≡ Λίστα: ${ie(h.find(R=>R.id===i.msList).name)}</div>`:""}
    ${l("title",i.kind==="due"?"Τι λήγει / τι πληρώνεται":"Τίτλος",'placeholder="π.χ. Εγκατάσταση καμερών" autocomplete="off"')}
    <div class="two">${l("date","Ημερομηνία",'type="date"')}${l("time","Ώρα",`type="time" ${i.date?"":"disabled"}`)}</div>
    ${r?`<div class="chips wrap">${[["Σήμερα",pe()],["Αύριο",kt(pe(),1)],["+1 εβδομάδα",kt(pe(),7)],["+1 μήνας",Qr(pe(),1)]].map(([R,B])=>`<button data-tdq="${B}" class="${i.date===B?"on":""}">${R}</button>`).join("")}${i.date?'<button data-tdq="">✕ Χωρίς ημερομηνία</button>':""}</div>`:""}
  </div>
  <div class="card pad"><div class="ch">🔔 Υπενθυμίσεις</div>
    ${r?Rr(Sv.map(R=>[R,Yl(R)]),R=>i.rems.includes(+R),"data-trem")+(i.date&&!i.time?'<div class="hint">Χωρίς ώρα, οι υπενθυμίσεις υπολογίζονται από τις 08:00.</div>':"")+(i.date?"":'<div class="hint">Οι υπενθυμίσεις χρειάζονται ημερομηνία.</div>'):`<div class="hint">${i.rems.map(Yl).join(", ")||"Καμία"}</div>`}
    <div class="f" style="margin-top:8px">🔁 Επανάληψη</div>
    ${r?Rr(Object.entries(Xl),R=>R===i.rep,"data-trep")+(i.rep?'<div class="hint">Όταν την ολοκληρώσεις, δημιουργείται αυτόματα η επόμενη.</div>':""):`<div class="hint">${Xl[i.rep]||"Καμία"}</div>`}
  </div>
  <div class="card pad"><div class="ch">👤 Πελάτης</div>
    ${a&&r?`<div class="actions"><button class="btn b2" data-tpick="cust">📇 Από πελάτες</button><button class="btn b2" data-tpick="quote">📄 ${i.quoteId?"Άλλη προσφορά":"Προσφορά"}</button></div>`:""}
    ${i.quoteId?`<div class="qlink"><a href="#/q/${encodeURIComponent(i.quoteId)}">🔗 ${ie(Sk(i.quoteId))}</a>${a&&r?'<button class="x" data-tunq aria-label="Αποσύνδεση">✕</button>':""}</div>`:""}
    ${l("cust","Όνομα πελάτη",'autocomplete="off"')}
    ${l("tel","Τηλέφωνο",'inputmode="tel"',m?`<a class="fa" href="tel:${ie(m)}">📞</a>`:"")}
    ${l("addr","Διεύθυνση","",i.addr?`<a class="fa" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i.addr)}">🗺️</a>`:"")}
  </div>
  ${a&&A.emps.length||r?`<div class="card pad"><div class="ch">👷 Ποιος και χρώμα</div>
    ${a&&Jr().length?`<div class="chips wrap">${Jr().map(R=>{const B=mc(R.id),H=i.emps.includes(R.id);return`<button data-temp="${ie(R.id)}" class="${H?"on":""}" ${o}>${H?"✓ ":B>=0?`<u class="dot" style="background:${ys(B)}"></u>`:""}${ie(R.name)}</button>`}).join("")}</div>`:i.emps.length?`<div class="hint">${ie(i.emps.map(yd).filter(Boolean).join(", "))}</div>`:""}
    ${r?`<div class="f" style="margin-top:6px">Χρώμα</div><div class="clrs"><button data-tclr="-1" class="${i.clr<0?"on":""}">Αυτόματο</button>${li.map(([R,B],H)=>`<button data-tclr="${H}" class="sw${i.clr===H?" on":""}" style="background:${B}" aria-label="${R}"></button>`).join("")}</div>`:""}
  </div>`:""}
  <div class="card pad"><div class="ch">📝 Σημειώσεις</div>
    <textarea class="in" data-tf="notes" rows="4" placeholder="Ό,τι χρειάζεται να θυμάσαι…" ${o}>${ie(i.notes)}</textarea>
    <div class="actions"><button class="btn b2" data-tncopy>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tnpaste>📋 Επικόλληση</button>':""}</div>
  </div>
  <div class="card pad"><div class="ch">☑ Checklist${i.chk.length?` <span class="muted">${w}/${i.chk.length}</span>`:""}</div>
    ${i.chk.length?`<div class="prog"><i style="width:${Math.round(w/i.chk.length*100)}%"></i></div>`:""}
    ${i.chk.map((R,B)=>`<div class="ci"><button class="tick${R.dn?" on":""}" data-tchktg="${B}" ${z.canTick?"":"disabled"}>${R.dn?"✓":""}</button>${r?`<input class="in" data-tchk="${B}" value="${ie(R.tx)}"><button class="x" data-tchkdel="${B}">✕</button>`:`<span class="${R.dn?"strike":""}">${ie(R.tx)}</span>`}</div>`).join("")}
    <div class="actions">${r?'<button class="btn b2" data-tchkadd>＋ Στοιχείο</button>':""}<button class="btn b2" data-tccopy ${i.chk.length?"":"disabled"}>⧉ Αντιγραφή</button>${r?'<button class="btn b2" data-tcpaste>📋 Επικόλληση</button>':""}</div>
    ${r?'<div class="hint">Επικόλληση: κάθε γραμμή του προχείρου γίνεται ξεχωριστό στοιχείο.</div>':""}
  </div>
  <div class="card pad"><div class="ch">✅ Κατάσταση</div>
    <label class="chk2"><input type="checkbox" data-tf="done" ${i.done?"checked":""} ${z.canTick?"":"disabled"}> ${i.done?"Ολοκληρώθηκε":"Ανοιχτή"}</label>
    ${z.t0&&z.t0.by&&z.t0.by.name?`<div class="hint">Την έγραψε: ${ie(z.t0.by.uid===(zn()||{}).uid?"εσύ":z.t0.by.name)}${z.t0.done&&z.t0.doneBy?" · ολοκλήρωσε: "+ie(z.t0.doneBy):""}</div>`:""}
  </div>
  ${z.msg?`<div class="err box">${ie(z.msg)}</div>`:""}
  ${!z.isNew&&r?`<button class="btn wide del" data-tdel>${z.ask?"Σίγουρα; Πάτα ξανά για διαγραφή":"🗑️ Διαγραφή"}</button>`:""}
  ${z.pick?Rk():""}`;return`${t(p,"",'<a class="ib" data-tcancel>←</a>','<button class="ib" data-tcopy aria-label="Αντιγραφή">⧉</button><button class="ib" data-tshare aria-label="Αποστολή">📤</button>')}<main class="body ed">${E}</main><div class="bar"><button class="btn b2" data-tcancel>Άκυρο</button><button class="btn b1" data-tsave>💾 Αποθήκευση</button></div>`}function Pv(){return z.pick.kind==="cust"?Zt().filter(n=>n.name&&n.name!=="(χωρίς όνομα)").sort((n,e)=>(e.last||0)-(n.last||0)).map(n=>({t:n.name,s:[n.info.phone,n.info.address].filter(Boolean).join(" · "),v:{cust:n.name,tel:n.info.phone||"",addr:n.info.address||""}})):A.quotes.filter(n=>!Jt(n)).sort((n,e)=>(e.ts||0)-(n.ts||0)).map(n=>{const e=n.customer||{};return{t:`#${n.number||"—"} · ${e.name||""}`,s:[n.subject,e.address].filter(Boolean).join(" · "),v:{quoteId:n.id,cust:e.name||"",tel:e.phone||"",addr:e.address||"",q:!0}}})}function Rk(){const n=z.pick.q.trim().toLowerCase(),e=Pv().map((t,s)=>({...t,i:s})).filter(t=>!n||(t.t+" "+t.s).toLowerCase().includes(n)).slice(0,150);return`<div class="sheet" data-pkx><div class="sheet-in"><div class="sheet-h"><b>${z.pick.kind==="cust"?"Πελάτες":"Προσφορές"}</b><button class="ib dk" data-pkx>✕</button></div>
    <input class="search" id="pq" data-pq placeholder="🔍 Αναζήτηση…" value="${ie(z.pick.q)}">
    <div class="sheet-list">${e.map(t=>`<button class="prow" data-pk="${t.i}"><div class="t"><b>${ie(t.t)}</b><span>${ie(t.s)}</span></div></button>`).join("")||'<div class="empty">Τίποτα</div>'}</div></div></div>`}const nn=(n,e)=>`<label class="tg"><span>${e}</span><input type="checkbox" data-stg="${n}" ${We()[n]?"checked":""}></label>`,Pn=(n,e,t)=>`<div class="f">${e}</div>${Rr(t,s=>String(We()[n])===String(s),`data-s="${n}" data-v`)}`,$p=(n,e)=>`<div class="f">${e}</div>${Rr(Sv.map(t=>[t,Yl(t)]),t=>xa(We()[n]).includes(+t),`data-sr="${n}" data-v`)}`;async function _d(n){await Kr(),Q.ms=await ye.msStatus(),n()}function Pk(n,e){const t=We(),s=Q.ms||{},{lists:i}=gc(),r=!_e(),o=l=>l?new Date(l).toLocaleString(Fi,{dateStyle:"short",timeStyle:"short"}):"",a=`${wn?"":'<div class="upd">🧪 Preview στον browser: ειδοποιήσεις, widgets, backup και To Do λειτουργούν μόνο στο κινητό.</div>'}
  <div class="h">🎨 Εμφάνιση ημερολογίου</div><div class="card pad">
    ${Pn("view","Οθόνη έναρξης",[["lists","Λίστες"],["month","Μήνας"],["week","Εβδομάδα"],["agenda","Ατζέντα"]])}
    <div class="f">Χρώμα εργασιών (προεπιλογή)</div><div class="clrs">${li.map(([l,u],h)=>`<button data-s="accent" data-v="${h}" class="sw${P(t.accent)===h?" on":""}" style="background:${u}" aria-label="${l}"></button>`).join("")}</div>
    ${nn("sun","Η εβδομάδα ξεκινά Κυριακή")}${nn("showDone","Εμφάνιση ολοκληρωμένων")}${nn("compact","Συμπαγής λίστα (περισσότερα στην οθόνη)")}
  </div>
  ${r&&Jr().length?`<div class="h">👷 Χρώμα ανά τεχνικό</div><div class="card pad"><div class="hint">Οι εργασίες χωρίς δικό τους χρώμα παίρνουν το χρώμα του τεχνικού.</div>
    ${Jr().map(l=>{const u=mc(l.id);return`<div class="erow" data-sec="${ie(l.id)}"><u class="dot lg" style="background:${u>=0?ys(u):"var(--line)"}"></u><b>${ie(l.name)}</b><span class="muted">${u>=0?li[u][0]:"Αυτόματο"}</span></div>
      ${Q.emSel===l.id?`<div class="clrs"><button data-secv="${ie(l.id)}|-1" class="${u<0?"on":""}">Αυτόματο</button>${li.map(([h,p],m)=>`<button data-secv="${ie(l.id)}|${m}" class="sw${u===m?" on":""}" style="background:${p}" aria-label="${h}"></button>`).join("")}</div>`:""}`}).join("")}</div>`:""}
  <div class="h">🔔 Υπενθυμίσεις</div><div class="card pad">
    ${$p("defRems","Προεπιλογή για νέες εργασίες")}${$p("dueRems","Προεπιλογή για λήξεις / πληρωμές")}
    ${nn("rep","Να ξαναχτυπά μέχρι να πατήσω «ΟΚ»")}
    ${t.rep?Pn("repMin","Κάθε",[2,5,10,15,30].map(l=>[l,l+"΄"]))+Pn("repMax","Μέχρι",[3,6,12,24].map(l=>[l,l+" φορές"])):""}
    ${Pn("snooze","Αναβολή",[5,10,15,30,60].map(l=>[l,l+"΄"]))}
    ${nn("alarmSound","Δυνατός ήχος ξυπνητηριού")}${nn("clockMode","Μέγιστη ακρίβεια (σαν ξυπνητήρι)")}
    <div class="actions"><button class="btn b2" data-sact="test">🔔 Δοκιμή</button><button class="btn b2" data-sact="notif">🔊 Ήχοι</button></div>
    <div class="hint">Αν το κινητό (Xiaomi, Huawei, Samsung) «κοιμίζει» τις εφαρμογές, βάλε το TechMate «Χωρίς περιορισμό» μπαταρίας:</div>
    <div class="actions"><button class="btn b2" data-sact="battery">🔋 Ρυθμίσεις μπαταρίας</button></div>
  </div>
  <div class="h">🔄 Συγχρονισμός και μπαταρία</div><div class="card pad">
    <div class="hint">Όσο η εφαρμογή είναι ανοιχτή, όλα ενημερώνονται αμέσως. Κλειστή, ελέγχει για νέες εργασίες μόνο όσο συχνά ορίσεις. Οι υπενθυμίσεις δεν εξαρτώνται από αυτό.</div>
    ${Pn("syncMin","Έλεγχος για νέες εργασίες",[[0,"Ποτέ"],[15,"15΄"],[30,"30΄"],[60,"1 ώρα"],[180,"3 ώρες"],[360,"6 ώρες"]])}
    ${nn("notifyNew","Ειδοποίηση για νέα / αλλαγμένη εργασία")}
  </div>
  <div class="h">🧩 Widget</div><div class="card pad">
    <label class="f">Διαφάνεια φόντου: <b id="wav">${t.wAlpha}%</b><input type="range" min="20" max="100" step="10" value="${t.wAlpha}" data-sw class="rng"></label>
    ${Pn("wMode","Τι δείχνει το widget-λίστα",[["todo","Εργασίες (όπως το To Do)"],["cal","Μόνο ραντεβού με ημερομηνία"]])}
    ${t.wMode==="todo"&&i.length>1?Pn("wList","Λίστα To Do στο widget",[["","Όλες"]].concat(i.map(l=>[l.id,ie(l.name)]))):""}
    ${Pn("wDays",t.wMode==="todo"?"Μαζί με ραντεβού για":"Η λίστα του widget δείχνει",[[1,"Σήμερα"],[2,"Σήμερα & αύριο"],[3,"3 μέρες"],[7,"Εβδομάδα"]])}
    <div class="hint">Για να το προσθέσεις: πάτα παρατεταμένα την αρχική οθόνη → Widgets → TechMate.</div>
  </div>
  ${r?`<div class="h">💾 Backup στη συσκευή / Google Drive</div><div class="card pad">
    <div class="hint">Σώζει ΟΛΟ το TechMate (προσφορές, πελάτες, λογιστικά, εργασίες…) σε αρχείο που διαλέγεις. Για Google Drive, πάτα ☰ στον επιλογέα και διάλεξε «Drive». Μόνο διαβάζει τη βάση, δεν αλλάζει τίποτα.</div>
    <div class="actions"><button class="btn b2" data-sact="bpick">📁 ${t.bUri?"Άλλο αρχείο":"Επιλογή αρχείου"}</button>${t.bUri?'<button class="btn b2" data-sact="bnow">☁️ Backup τώρα</button>':""}</div>
    ${t.bUri?nn("bAuto","Αυτόματο backup μία φορά τη μέρα (όταν ανοίγεις την εφαρμογή)")+`<div class="hint">${t.bLast?"Τελευταίο: "+o(t.bLast):"Δεν έχει γίνει ακόμα"}</div>`:""}
    <label class="btn b2 wide filebtn">♻️ Επαναφορά εργασιών που λείπουν, από backup…<input type="file" accept="application/json,.json" data-restore hidden></label>
    <div class="hint">Η επαναφορά προσθέτει ΜΟΝΟ εργασίες που δεν υπάρχουν πια. Όσες υπάρχουν δεν αλλάζουν.</div>
  </div>
  <div class="h">✅ Microsoft To Do</div><div class="card pad">
    ${s.connected?`<div class="hint">👤 ${ie(s.account||"Συνδεδεμένο")}</div><div class="hint">${s.status==="sync"?"⏳ Συγχρονισμός…":s.status==="login"?"⚠️ Χρειάζεται ξανά σύνδεση":s.status&&s.status!=="ok"?"⚠️ "+ie(s.status):s.last?"✓ Τελευταίος συγχρονισμός: "+o(s.last):"✓ Συνδεδεμένο"}</div>
        <div class="actions">${s.status==="login"?'<button class="btn b1" data-sact="mslogin">Σύνδεση</button>':'<button class="btn b2" data-sact="mssync">🔄 Συγχρονισμός τώρα</button>'}<button class="btn b2" data-sact="msout">Αποσύνδεση</button></div>
        <div class="hint">Συγχρονίζονται οι λίστες που έχεις διαλέξει στο TechMate. Οι νέες εργασίες πάνε στην κύρια λίστα.</div>`:'<div class="hint">Σύνδεσε τον λογαριασμό Microsoft: οι εργασίες πηγαίνουν και έρχονται από το To Do απευθείας από το κινητό, με την ίδια λογική με το PWA (χωρίς διπλές).</div><button class="btn b1 wide" data-sact="mslogin">Σύνδεση με Microsoft</button>'}
  </div>`:'<div class="card pad"><div class="hint">Τον συγχρονισμό με το To Do και τα backup τα κάνει ο διαχειριστής.</div></div>'}
  <div class="card pad">${nn("autoUpd","Αυτόματος έλεγχος για νέα έκδοση εφαρμογής")}</div>`;return e(n("Ρυθμίσεις ημερολογίου","Ειδοποιήσεις · widget · backup · To Do",'<a class="ib" href="#/cal">←</a>'),a,null)}function eu(){const n=t=>Object.fromEntries((t||[]).map(s=>{const i={...s};return delete i.id,[s.id,i]})),e={};return["quotes","custs","tasks","ldocs","lpays","emps","products","smoves","wdays","wpays","needs"].forEach(t=>e[t]=n(A[t])),JSON.stringify({app:"TechMate",ver:2,at:new Date().toISOString(),tasks:e.tasks,data:e,settings:A.st},null,1)}async function Ck(n){const e=We();if(!wn||!n||_e()||!e.bUri||!e.bAuto||!A.tasks.length||!A.quotes.length||Date.now()-P(e.bLast)<20*36e5)return;const t=await ye.backupWrite(eu());t&&t.ok&&await Kr()}async function Dk(n,e,t){try{const s=JSON.parse(await n.text()),i=s.tasks||s.data&&s.data.tasks||{},r=new Set(A.tasks.map(a=>a.id));let o=0;Object.keys(i).forEach(a=>{r.has(a)||!i[a]||typeof i[a]!="object"||(Ue("tasks",{...i[a],id:a}),o++)}),e(o?`Επαναφέρθηκαν ${o} εργασίες που έλειπαν.`:"Δεν έλειπε καμία εργασία. Δεν άλλαξε τίποτα.")}catch{e("Το αρχείο δεν είναι σωστό backup.")}t()}function Cv(n){const e=Q.quick.trim();if(!e)return;const t=Q.list,s=vd(null,{title:e,date:t==="myday"?pe():"",rems:[],msList:["myday","planned","all"].includes(t)?"":t});if(s.msg)return n(s.msg);Q.quick="",n("Προστέθηκε: "+e)}function $k(){if(Q.view==="lists"){const e=Q.list;ui({date:e==="myday"||e==="planned"?pe():"",msList:["myday","planned","all"].includes(e)?"":e})}else ui({date:ki()});location.hash="#/t/new"}async function Vk(n,e,t){const s={test:async()=>{const i=await ye.testNotif();t(i&&i.error?i.error:wn?"Στάλθηκε δοκιμαστική ειδοποίηση":"Μόνο στο κινητό")},notif:()=>ye.openNotifSettings(),battery:()=>ye.openBattery(),mslogin:()=>ye.msLogin(),mssync:async()=>{Q.ms={...Q.ms||{},status:"sync"},e();const i=await ye.msSync();t(i&&i.ok?"Συγχρονίστηκε με το To Do":"Ο συγχρονισμός απέτυχε")},msout:async()=>{await ye.msDisconnect(),t("Αποσυνδέθηκε το Microsoft To Do")},bpick:async()=>{const i=await ye.backupPick();if(i&&i.error)return t(i.error);if(i&&i.ok){await Kr();const r=await ye.backupWrite(eu());t(r&&r.ok?"Έγινε το πρώτο backup":"Backup: "+(r&&r.error||"σφάλμα"))}},bnow:async()=>{const i=await ye.backupWrite(eu());t(i&&i.ok?"Έγινε backup":"Backup: "+(i&&i.error||"σφάλμα"))}}[n];s&&await s(),await Kr(),Q.ms=await ye.msStatus(),e()}function Nk(n,e,t){const s=n.closest("[data-tk],[data-cv],[data-csel],[data-cmon],[data-cwk],[data-cemp],[data-clist],[data-csrch],[data-ctoday],[data-cdone],[data-cnew],[data-cqa],[data-tfk],[data-trem],[data-trep],[data-temp],[data-tclr],[data-tdq],[data-tlist],[data-tunq],[data-tpick],[data-pk],[data-pkx],[data-tchkadd],[data-tchkdel],[data-tchktg],[data-tncopy],[data-tnpaste],[data-tccopy],[data-tcpaste],[data-tcopy],[data-tshare],[data-tsave],[data-tcancel],[data-tdel],[data-s],[data-sr],[data-sec],[data-secv],[data-sact]");if(!s)return!1;const i=s.dataset;if(i.tk){const o=A.tasks.find(l=>l.id===i.tk);if(!o)return!0;const a=!o.done;return rl(o,a),t((a?"✓ Ολοκληρώθηκε: ":"Άνοιξε ξανά: ")+(o.title||""),{label:"Αναίρεση",fn:()=>{const l=A.tasks.find(u=>u.id===o.id);l&&rl(l,!a)}}),!0}if(i.cv)return Q.view=i.cv,e(),!0;if(i.csel)return Q.sel=i.csel,Q.view==="week"&&(Q.view="month"),e(),!0;if(i.cmon)return Q.sel=Qr(ki().slice(0,8)+"01",+i.cmon),e(),!0;if(i.cwk)return Q.sel=kt(ki(),7*i.cwk),e(),!0;if("cemp"in i)return Q.emp=Q.emp===i.cemp?"":i.cemp,e(),!0;if(i.clist)return Q.list=i.clist,e(),!0;if("csrch"in i){Q.srch=!Q.srch,Q.srch||(Q.q=""),e();const o=document.getElementById("csq");return o&&o.focus(),!0}if("ctoday"in i)return Q.sel=pe(),e(),!0;if("cdone"in i)return Q.showDone=!Q.showDone,e(),!0;if("cnew"in i)return $k(),!0;if("cqa"in i)return Cv(t),e(),!0;if(i.s!==void 0&&i.v!==void 0){const o=We()[i.s],a=typeof o=="number"?+i.v:typeof o=="boolean"?i.v==="true":i.v;return Sr(i.s,a).then(e),!0}if(i.sr){const o=xa(We()[i.sr]),a=+i.v,l=o.includes(a)?o.filter(u=>u!==a):o.concat(a);return Sr(i.sr,l.join(",")).then(e),!0}if(i.secv){const[o,a]=i.secv.split("|"),l=Tv();return+a<0?delete l[o]:l[o]=+a,Q.emSel="",Sr("empClr",JSON.stringify(l)).then(e),!0}if(i.sec)return Q.emSel=Q.emSel===i.sec?"":i.sec,e(),!0;if(i.sact)return Vk(i.sact,e,t),!0;if(!z)return!1;const r=z.v;if("pkx"in i)return s.classList.contains("sheet")&&n!==s?!0:(z.pick=null,e(),!0);if(i.pk){const o=Pv()[+i.pk];if(o){const a=o.v;a.q?(r.quoteId=a.quoteId,r.cust||(r.cust=a.cust),r.tel||(r.tel=a.tel),r.addr||(r.addr=a.addr),r.title||(r.title="Εγκατάσταση – "+a.cust)):(r.cust=a.cust,a.tel&&(r.tel=a.tel),a.addr&&(r.addr=a.addr))}return z.pick=null,e(),!0}if(i.tfk!==void 0)r.kind!==i.tfk&&z.isNew&&(r.rems=xa(i.tfk==="due"?We().dueRems:We().defRems)),r.kind=i.tfk;else if(i.trem!==void 0){const o=+i.trem;r.rems=r.rems.includes(o)?r.rems.filter(a=>a!==o):r.rems.concat(o)}else if(i.trep!==void 0)r.rep=i.trep;else if(i.temp){const o=r.emps.indexOf(i.temp);o>=0?r.emps.splice(o,1):r.emps.push(i.temp)}else if(i.tclr!==void 0)r.clr=+i.tclr;else if(i.tdq!==void 0)r.date=i.tdq,r.date||(r.time="");else if(i.tlist)r.msList=i.tlist;else if("tunq"in i)r.quoteId="";else if(i.tpick)z.pick={kind:i.tpick,q:""};else if("tchkadd"in i)r.chk.push({tx:"",dn:!1});else if(i.tchkdel)r.chk.splice(+i.tchkdel,1);else if(i.tchktg){const o=r.chk[+i.tchktg];o&&z.canTick&&(o.dn=!o.dn)}else{if("tncopy"in i)return ye.copy(r.notes),t("Αντιγράφηκαν οι σημειώσεις"),!0;if("tnpaste"in i)return ye.paste().then(o=>{if(!o)return t("Το πρόχειρο είναι άδειο");r.notes=r.notes.trim()?r.notes.trimEnd()+`
`+o:o,t("Επικολλήθηκε"),e()}),!0;if("tccopy"in i)return ye.copy(r.chk.map(o=>(o.dn?"✔ ":"▫ ")+o.tx).join(`
`)),t("Αντιγράφηκε το checklist"),!0;if("tcpaste"in i)return ye.paste().then(o=>{const a=String(o||"").split(/\r?\n/).map(l=>l.trim()).filter(Boolean).map(l=>({tx:l.replace(/^([-*•▫☐☑✔✓]|\[[ xX]?\]|\d+[.)])\s*/,""),dn:/^(☑|✔|✓|\[[xX]\])/.test(l)})).filter(l=>l.tx);if(!a.length)return t("Το πρόχειρο είναι άδειο");r.chk.push(...a),t(`Προστέθηκαν ${a.length} στοιχεία`),e()}),!0;if("tcopy"in i)return ye.copy(Dp(r)),t("Αντιγράφηκε η εργασία"),!0;if("tshare"in i)return ye.share(Dp(r)),!0;if("tcancel"in i)return z=null,history.length>1?history.back():location.replace("#/cal"),!0;if("tdel"in i)if(!z.ask)z.ask=!0;else{const o=yk(z.t0);if(o.msg)z.msg=o.msg,z.ask=!1;else{const a=z.t0.title;return z=null,t("Διαγράφηκε: "+a),location.replace("#/cal"),!0}}else if("tsave"in i){if(z.canEdit){const l=vd(z.isNew?null:z.arg,r);if(l.msg)return z.msg=l.msg,z.err=!r.title.trim(),e(),!0}else{const l=A.tasks.find(h=>h.id===z.arg)||z.t0,u=r.chk.filter(h=>h.tx.trim());JSON.stringify(u)!==JSON.stringify((l.chk||[]).map(h=>({tx:h.tx,dn:!!h.dn})))&&gk(l,u),!!r.done!=!!l.done&&rl(l,r.done)}const o=r.title.trim(),a=z.isNew;return z=null,t(a?"Προστέθηκε: "+o:"Αποθηκεύτηκε"),history.length>1?history.back():location.replace("#/cal"),!0}}return e(),!0}function xk(n,e){const t=n.dataset;if("csq"in t){Q.q=n.value,e();const s=document.getElementById("csq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if("cqv"in t)return Q.quick=n.value,!0;if("sw"in t){const s=document.getElementById("wav");return s&&(s.textContent=n.value+"%"),!0}if(!z)return!1;if("pq"in t){z.pick.q=n.value,e();const s=document.getElementById("pq");return s&&(s.focus(),s.setSelectionRange(s.value.length,s.value.length)),!0}if(t.tchk!==void 0){const s=z.v.chk[+t.tchk];return s&&(s.tx=n.value),!0}return t.tf?(z.v[t.tf]=n.type==="checkbox"?n.checked:n.value,z.msg&&(z.msg=""),t.tf==="title"&&(z.err=!1),!0):!1}function Ok(n,e,t){const s=n.dataset;return s.stg?(Sr(s.stg,n.checked).then(e),!0):"sw"in s?(Sr("wAlpha",+n.value).then(e),!0):"restore"in s?(n.files&&n.files[0]&&Dk(n.files[0],t,e),!0):z&&(s.tf==="date"||s.tf==="done")?(z.v[s.tf]=n.type==="checkbox"?n.checked:n.value,s.tf==="date"&&!n.value&&(z.v.time=""),e(),!0):!1}function Mk(n,e,t){if(n.key==="Enter"&&n.target.dataset&&"cqv"in n.target.dataset){n.preventDefault(),Q.quick=n.target.value,Cv(t),e();const s=document.querySelector("[data-cqv]");return s&&s.focus(),!0}return!1}let lr=null;function Dv(n,e){if(!n.target.closest||!n.target.closest("#mgrid")){lr=null;return}if(n.type==="touchstart")lr=n.touches[0].clientX;else if(n.type==="touchend"&&lr!==null){const t=n.changedTouches[0].clientX-lr;lr=null,Math.abs(t)>70&&(Q.sel=Qr(ki().slice(0,8)+"01",t<0?1:-1),e())}}function Lk(){const n=pe(),e=Zl().filter(t=>!t.done);return{today:Zl().filter(t=>t.date===n).sort(Yr),late:e.filter(t=>t.date&&t.date<n).sort((t,s)=>t.date.localeCompare(s.date)),dues:e.filter(t=>t.kind==="due"&&t.date&&t.date>n&&t.date<=kt(n,14)).sort((t,s)=>t.date.localeCompare(s.date))}}let Vp=null,Np="";function Fk(){!wn||!Ar.tasks||(clearTimeout(Vp),Vp=setTimeout(()=>{const n={};A.tasks.forEach(r=>{const o={...r};delete o.id,n[r.id]=o});const e=JSON.stringify(n),t=A.emps.map(r=>({id:r.id,name:r.name||""})),s=gc(),i=e.length+":"+e+JSON.stringify(t)+JSON.stringify(s);i!==Np&&(Np=i,ye.setTasks(e,t,s))},400))}const sn=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),bd=(n,e)=>(n||[]).find(t=>t.id===e),Oa="https://graph.microsoft.com/v1.0",Uk="TechMate/Τιμολόγια",qk="TechMate/Φωτογραφίες εγκαταστάσεων",al=n=>String(n||"").replace(/[\\/:*?"<>|#%]+/g," ").replace(/\s+/g," ").trim(),cl=n=>(n=P(n,0),n>=1048576?(n/1048576).toFixed(1).replace(".",",")+" MB":Math.max(1,Math.round(n/1024))+" KB"),xp=n=>!(n&&n.war&&n.war.on===!1),Bk=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(P(e.m,0))):P((ae()||{}).warrantyMonths,24)},jk=n=>n.install||{date:n.statusDate||"",months:xp(n)?Bk(n):0,serials:"",nw:!xp(n)},Ae={st:null,busy:"",msg:"",pick:""},$v=()=>!!Ae.busy,Ri=n=>n&&n.install&&n.install.docs||[],Xr=n=>n&&n.install&&n.install.photos||[];async function wd(n){Ae.st=Ms?{connected:!0,account:"demo@hotmail.com"}:wn?await ye.filesStatus():{connected:!1,account:"",web:!0},n()}const Ma=(n,e,t)=>n.install?Da("quotes",n.id,"install."+e,t):Da("quotes",n.id,"install",{...jk(n),[e]:t}),tu=(n,e)=>Ue("qlog",{id:je(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:e}),Id=async()=>{if(Ms)return"demo";const n=await ye.filesToken();if(!n||!n.ok){const e=new Error(n&&n.error==="login"?"Συνδέσου στο OneDrive.":n&&n.error||"Δεν υπάρχει σύνδεση OneDrive.");throw e.login=!0,e}return n.token},Op=(n,e)=>"/me/drive/root:/"+e.split("/").map(encodeURIComponent).join("/")+"/"+encodeURIComponent(n);async function zk(n,e,t,s,i){if(Ms)return{id:"demo"+Date.now(),name:t,size:e.size,webUrl:""};const r={Authorization:"Bearer "+n},o=async h=>{if(!h.ok)throw new Error(h.status===507?"Γέμισε ο χώρος του OneDrive.":h.status===403||h.status===401?"Το OneDrive δεν επιτρέπει την πρόσβαση (άδεια Files.ReadWrite). Συνδέσου ξανά.":"Το OneDrive απέρριψε το αρχείο ("+h.status+").");return h.json()};if(e.size<=4e6)return o(await fetch(Oa+Op(t,s)+":/content?@microsoft.graph.conflictBehavior=rename",{method:"PUT",headers:{"Content-Type":e.type||"application/octet-stream",...r},body:e}));const a=await o(await fetch(Oa+Op(t,s)+":/createUploadSession",{method:"POST",headers:{"Content-Type":"application/json",...r},body:JSON.stringify({item:{"@microsoft.graph.conflictBehavior":"rename"}})})),l=327680*10;let u=0;for(;;){const h=Math.min(u+l,e.size);i&&i(Math.round(h/e.size*100));const p=await fetch(a.uploadUrl,{method:"PUT",headers:{"Content-Range":`bytes ${u}-${h-1}/${e.size}`},body:e.slice(u,h)});if(p.status===202){u=h;continue}return o(p)}}function Gk(n){return!/^image\/(jpeg|png|webp)$/i.test(n.type)||n.size<4e5?Promise.resolve(n):new Promise(e=>{const t=URL.createObjectURL(n),s=new Image;s.onload=()=>{const i=Math.min(1,2e3/Math.max(s.naturalWidth,s.naturalHeight)),r=document.createElement("canvas");r.width=Math.round(s.naturalWidth*i),r.height=Math.round(s.naturalHeight*i);const o=r.getContext("2d");o.fillStyle="#fff",o.fillRect(0,0,r.width,r.height),o.drawImage(s,0,0,r.width,r.height),URL.revokeObjectURL(t),r.toBlob(a=>!a||a.size>=n.size?e(n):e(new File([a],n.name.replace(/\.[^.]+$/,"")+".jpg",{type:"image/jpeg"})),"image/jpeg",.82)},s.onerror=()=>{URL.revokeObjectURL(t),e(n)},s.src=t})}function Kk(n,e,t){const s=bd(A.quotes,n),i='<a class="ib" href="#/inst">←</a>';if(!s)return t(e("Τιμολόγια & φωτο","",i),'<div class="empty">Δεν βρέθηκε</div>',"menu");const r=Ae.st,o=Ri(s),a=Xr(s),l=r&&r.connected,u=(h,p)=>{const m=a.filter(w=>w.kind===h);return`<div class="item"><div class="t"><b>${p} (${m.length})</b><span>${m.map(w=>cl(w.size)).join(" · ")||"—"}</span></div>
    <div class="r"><label class="btn b2 sm">📷<input type="file" accept="image/*" capture="environment" hidden data-fl-ph="${h}"></label><label class="btn b2 sm">🖼️<input type="file" accept="image/*" hidden data-fl-ph="${h}"></label></div></div>
    ${m.map((w,E)=>`<div class="item sub"><div class="t"><b>${sn(w.name)}</b><span>${w.ts?new Date(w.ts).toLocaleDateString("el-GR"):""} · ${cl(w.size)}</span></div><div class="r">${w.url?`<a class="btn b2 sm" href="${sn(w.url)}" target="_blank" rel="noopener">${E+1}</a>`:""}<button class="ib dk" data-fl-del="ph:${sn(w.id)}">🗑️</button></div></div>`).join("")}`};return t(e("Τιμολόγια & φωτογραφίες",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,i),`${r?l?`<div class="hint">OneDrive: <b>${sn(r.account||"συνδεδεμένο")}</b> · <a href="#" data-fl="logout">αποσύνδεση</a></div>`:`<div class="card pad"><b>Σύνδεση OneDrive</b><div class="muted small" style="margin:6px 0 10px">Τα αρχεία ανεβαίνουν στο OneDrive του λογαριασμού αποστολής (όπως στο PWA), φάκελος «TechMate». ${r.web?"Η σύνδεση γίνεται μόνο από την εφαρμογή στο κινητό.":""}</div>${r.web?"":'<button class="btn b1 wide" data-fl="login">🔗 Σύνδεση λογαριασμού Microsoft</button>'}</div>`:'<div class="empty">Φόρτωση…</div>'}
    ${Ae.busy?`<div class="upd">${sn(Ae.busy)}</div>`:""}${Ae.msg?`<div class="err box">${sn(Ae.msg)}</div>`:""}
    <div class="h">Τιμολόγια (${o.length})</div><div class="card">${o.map(h=>`<div class="item"><div class="t"><b>${sn(h.name)}</b><span>${h.ts?new Date(h.ts).toLocaleDateString("el-GR"):""} · ${cl(h.size)}</span></div><div class="r"><button class="btn b2 sm" data-fl-open="${sn(h.id)}">Άνοιγμα</button><button class="ib dk" data-fl-del="doc:${sn(h.id)}">🗑️</button></div></div>`).join("")||'<div class="empty">Κανένα τιμολόγιο.</div>'}
      <div class="pad"><label class="btn b1 wide ${l?"":"dis"}">🧾 Προσθήκη τιμολογίου<input type="file" accept="application/pdf,image/*" hidden data-fl-doc ${l?"":"disabled"}></label></div></div>
    <div class="h">Φωτογραφίες εγκατάστασης</div><div class="card ${l?"":"off"}">${u("before","Πριν")}${u("after","Μετά")}</div>
    <div class="hint">Η διαγραφή στέλνει το αρχείο και στον Κάδο ανακύκλωσης του OneDrive.</div>`,"menu")}async function Wk(n,e,t,s){if(e.size>6e7)return Ae.msg="Το αρχείο είναι πολύ μεγάλο (πάνω από 60 MB).",s();Ae.busy="Ανέβασμα…",Ae.msg="",s();try{const i=await Gk(e),r=await Id(),o=al(n.customer&&n.customer.name);let a=(/\.[a-z0-9]{2,5}$/i.exec(i.name)||[""])[0];i!==e&&(a=".jpg"),t&&!a&&(a=".jpg");const l=t?al([n.number||"έργο",o,t==="before"?"ΠΡΙΝ":"ΜΕΤΑ",Date.now().toString(36)].join("_")).slice(0,150)+".jpg":al([n.number,o,e.name.replace(/\.[^.]+$/,"")].filter(Boolean).join("_")).slice(0,150)+a.toLowerCase(),u=await zk(r,i,l,t?qk:Uk,m=>{Ae.busy="Ανέβασμα… "+m+"%",s()}),h=bd(A.quotes,n.id)||n,p=Date.now().toString(36)+Math.random().toString(36).slice(2,6);t?(Ma(h,"photos",Xr(h).concat([{id:p,odId:u.id,name:u.name||l,kind:t,size:u.size||i.size,url:u.webUrl||"",ts:Date.now()}])),tu(h,"Φωτογραφία "+(t==="before"?"ΠΡΙΝ":"ΜΕΤΑ")+" στο OneDrive.")):(Ma(h,"docs",Ri(h).concat([{id:p,odId:u.id,name:u.name||l,orig:e.name,size:u.size||i.size,mime:i.type||"",url:u.webUrl||"",ts:Date.now()}])),tu(h,"Τιμολόγιο στο OneDrive: "+(u.name||l))),Ae.busy="",Ae.msg=""}catch(i){Ae.busy="",Ae.msg=i&&i.message||"Το ανέβασμα απέτυχε."}s()}async function Hk(n,e,t,s){if(Ms)return t("Στο δοκιμαστικό δεν ανοίγουν αρχεία.");Ae.busy="Λήψη…",s();try{const i=await Id(),r=await fetch(Oa+"/me/drive/items/"+encodeURIComponent(e.odId)+"/content",{headers:{Authorization:"Bearer "+i}});if(r.status===404)throw new Error("Το αρχείο δεν βρέθηκε στο OneDrive (ίσως σβήστηκε από εκεί).");if(!r.ok)throw new Error("Το OneDrive δεν έδωσε το αρχείο ("+r.status+").");const o=await r.arrayBuffer(),a=new Uint8Array(o);let l="";for(let h=0;h<a.length;h+=32768)l+=String.fromCharCode.apply(null,a.subarray(h,h+32768));const u=e.mime||(/\.pdf$/i.test(e.name)?"application/pdf":"application/octet-stream");if(wn){const h=await ye.shareFile({name:e.name,b64:btoa(l),mime:u,view:!0});if(h&&h.error)throw new Error(h.error)}else{const h=URL.createObjectURL(new Blob([o],{type:u})),p=document.createElement("a");p.href=h,p.download=e.name,p.click(),setTimeout(()=>URL.revokeObjectURL(h),5e3)}Ae.busy=""}catch(i){Ae.busy="",Ae.msg=i&&i.message||"Η λήψη απέτυχε."}s()}async function Qk(n,e,t){const[s,i]=e.split(":"),r=(s==="ph"?Xr(n):Ri(n)).find(o=>o.id===i);if(r&&confirm("Να αφαιρεθεί «"+r.name+`»;
Θα πάει και στον Κάδο ανακύκλωσης του OneDrive (μπορείς να το επαναφέρεις από εκεί).`)){Ae.busy="Αφαίρεση…",Ae.msg="",t();try{if(!Ms){const o=await Id(),a=await fetch(Oa+"/me/drive/items/"+encodeURIComponent(r.odId),{method:"DELETE",headers:{Authorization:"Bearer "+o}});if(!a.ok&&a.status!==404)throw new Error("Το OneDrive δεν το έσβησε ("+a.status+").")}s==="ph"?Ma(n,"photos",Xr(n).filter(o=>o.id!==i)):Ma(n,"docs",Ri(n).filter(o=>o.id!==i)),tu(n,"Αφαιρέθηκε "+(s==="ph"?"φωτογραφία":"τιμολόγιο")+": "+r.name)}catch(o){Ae.msg=o&&o.message||"Η διαγραφή απέτυχε."}Ae.busy="",t()}}const Vv=()=>bd(A.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));function Jk(n,e,t){const s=n.closest("[data-fl],[data-fl-open],[data-fl-del]");if(!s)return!1;const i=s.dataset,r=Vv();return i.fl==="login"?ye.filesLogin():i.fl==="logout"?confirm("Αποσύνδεση του OneDrive από την εφαρμογή;")&&ye.filesDisconnect().then(()=>wd(e)):r&&i.flOpen?Hk(r,Ri(r).find(o=>o.id===i.flOpen),t,e):r&&i.flDel&&Qk(r,i.flDel,e),!0}function Yk(n,e){const t=n.dataset;if(!("flDoc"in t)&&!t.flPh)return!1;const s=n.files&&n.files[0],i=Vv();return n.value="",s&&i&&Wk(i,s,t.flPh||"",e),!0}const rn=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),ft={list:null,err:"",busy:!1};function Xk(n){ft.busy||(ft.busy=!0,oS().then(e=>{ft.list=e,ft.err=""},()=>{ft.err="Δεν φορτώθηκαν τα μηνύματα. Έλεγξε τη σύνδεση.",ft.list=ft.list||[]}).finally(()=>{ft.busy=!1,n()}))}function Zk(n,e){const t=ft.list,s=(t||[]).filter(i=>!i.read).length;return e(n("Μηνύματα ιστοσελίδας",s?s+" νέα":"",'<a class="ib" href="#/menu">←</a>'),`${ft.err?`<div class="err box">${rn(ft.err)}</div>`:""}<div class="card">${(t||[]).map(i=>{const r=String(i.phone||"").replace(/[^\d+]/g,""),o=i.at?new Date(i.at).toLocaleString("el-GR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"";return`<div class="item" style="align-items:flex-start;${i.read?"opacity:.7":""}"><div class="t" style="white-space:normal"><b>${i.read?"":"● "}${rn(i.name)}</b><span>${rn(o)}${[i.svc,i.area,i.day].filter(Boolean).length?" · "+[i.svc,i.area,i.day].filter(Boolean).map(rn).join(" · "):""}</span>
        <div style="margin:6px 0;white-space:pre-wrap">${rn(i.msg)}</div>
        <div class="actions">${r?`<a class="btn b2 sm" href="tel:${rn(r)}">📞 ${rn(i.phone)}</a>`:""}${i.email?`<a class="btn b2 sm" href="mailto:${rn(i.email)}">✉️ Email</a>`:""}${i.read?"":`<button class="btn b2 sm" data-mread="${rn(i.id)}">✔ Διαβάστηκε</button>`}</div></div></div>`}).join("")||`<div class="empty">${t?"Κανένα μήνυμα ακόμα.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Η διαγραφή μηνυμάτων γίνεται από το PWA.</div>`,"menu")}function eR(n,e){const t=n.closest("[data-mread]");if(!t)return!1;const s=(ft.list||[]).find(i=>i.id===t.dataset.mread);return s&&(s.read=!0,aS(s.id)),e(),!0}const Y=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),tR=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Ze=n=>tR.format(Math.round((n||0)*100)/100),ve=n=>String(U(P(n))).replace(".",","),Ot=n=>P(String(n??"").replace(",","."),NaN),Mp=n=>n<10?"0"+n:""+n,Ed=n=>n.getFullYear()+"-"+Mp(n.getMonth()+1)+"-"+Mp(n.getDate()),Kn=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},nR=n=>{try{return new Date(n+"T12:00").toLocaleDateString("el-GR",{weekday:"short"})}catch{return""}},we=(n,e)=>(n||[]).find(t=>t.id===e),sR=["Ιανουάριος","Φεβρουάριος","Μάρτιος","Απρίλιος","Μάιος","Ιούνιος","Ιούλιος","Αύγουστος","Σεπτέμβριος","Οκτώβριος","Νοέμβριος","Δεκέμβριος"],iR=n=>{const e=n.split("-");return sR[+e[1]-1]+" "+e[0]},Yn=n=>!!Ar[n]||!!A[n].length,O={openNext:"",emp:"",month:"",f:null,stTab:"stock",stQ:"",stAll:!1,sheet:null,inQ:""},Nv=()=>!!O.f||!!O.sheet;function rR(){O.f=null,O.sheet=null}function La(n){let e=0,t=0,s=0;return A.wdays.forEach(i=>{i.empId===n&&(e+=P(i.amount),s+=P(i.days))}),A.wpays.forEach(i=>{i.empId===n&&(t+=P(i.amount))}),{earned:U(e),paid:U(t),bal:U(e-t),days:U(s)}}function Lp(n){if(!n||!n.from||!n.until)return null;const e=n.from.split(":"),t=n.until.split(":");let s=+t[0]*60+ +t[1]-(+e[0]*60+ +e[1]);return s<=0&&(s+=1440),{txt:n.from+"–"+n.until,h:U(s/60)}}const Td=()=>A.emps.filter(n=>n.name&&(!_e()||n.id===Lt())).slice().sort((n,e)=>String(n.name).localeCompare(String(e.name),"el")),Dn=n=>n?JSON.parse(JSON.stringify(n)):null;function Hs(n,e,t,s,i){if(_e())return;const r=i||s||{},o=n==="emps"?t:r.empId||"",a=we(A.emps,o);Ue("pbuys",{id:je(),ts:Date.now(),kind:"hist",area:"wages",coll:n,act:e,recId:t,empId:o,empName:n==="emps"?r.name||"":a&&a.name||"",partner:"",at:new Date().toISOString(),before:Dn(s),after:Dn(i)})}const ll=(n,e)=>Object.keys({...n,...e}).some(t=>t!=="id"&&t!=="ts"&&JSON.stringify(n[t])!==JSON.stringify(e[t]));function oR(n,e){const t=Td();if(_e()){const r=t[0];return r?xv(r.id,n,e,!0):e(n("Μεροκάματα",""),`<div class="card"><div class="empty">${Yn("emps")?"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει.":"Φόρτωση…"}</div></div>`,"menu")}const s=t.reduce((r,o)=>r+Math.max(0,La(o.id).bal),0),i=`<div class="kpis"><div class="kpi"><b class="${s>0?"bad":""}">${Ze(s)}</b><span>Χρωστάω σε υπαλλήλους</span></div><div class="kpi"><b>${t.length}</b><span>Υπάλληλοι</span></div></div>
    <div class="card">${t.map(r=>{const o=La(r.id);return`<a class="row" href="#/wage/${encodeURIComponent(r.id)}"><div class="av">👷</div><div class="t"><b>${Y(r.name)}</b><span>${Ze(r.rate||0)} / ημέρα · ${ve(o.days)} ημέρες</span></div>
      <div class="r"><div class="amt ${o.bal>.004?"bad":""}">${o.bal>.004?Ze(o.bal):o.bal<-.004?"−"+Ze(-o.bal):"✓"}</div><span class="muted">${o.bal>.004?"του χρωστάω":o.bal<-.004?"προπληρωμή":"τακτοποιημένο"}</span></div></a>`}).join("")||`<div class="empty">${Yn("emps")?"Δεν υπάρχουν υπάλληλοι.":"Φόρτωση…"}</div>`}</div>
    <button class="btn b2 wide" data-wa="emp-new">＋ Νέος υπάλληλος</button>
    <div class="hint" style="margin-top:10px">Η διαγραφή μεροκάματων/πληρωμών γίνεται από το PWA, που τις κρατά στον κάδο.</div>`;return e(n("Μεροκάματα","Υπάλληλοι · υπόλοιπα"),i+Mv(),"menu",'<button class="fab" data-wa="work-new" aria-label="Νέο μεροκάματο">＋</button>')}function xv(n,e,t,s){const i=we(A.emps,n);if(!i)return t(e("Υπάλληλος","",'<a class="ib" href="#/wages">←</a>'),`<div class="card"><div class="empty">${Yn("emps")?"Δεν βρέθηκε.":"Φόρτωση…"}</div></div>`,null);const r=La(n),o=!_e(),a=[];A.wdays.forEach(E=>{E.empId===n&&a.push({t:"work",id:E.id,date:E.date,ts:E.ts||0,amt:P(E.amount),desc:(Lp(E)?Lp(E).txt+" · ":"")+ve(E.days)+(P(E.days)===1?" ημέρα":" ημέρες")+" × "+Ze(E.rate)+(E.note?" · "+E.note:"")})}),A.wpays.forEach(E=>{E.empId===n&&a.push({t:"pay",id:E.id,date:E.date,ts:E.ts||0,amt:-P(E.amount),desc:(E.method==="bank"?"Τράπεζα":"Μετρητά")+(E.note?" · "+E.note:"")})});const l=[...new Set(a.map(E=>String(E.date).slice(0,7)))].sort().reverse(),u=O.month&&l.includes(O.month)?O.month:"",h=a.filter(E=>!u||String(E.date).startsWith(u)).sort((E,$)=>E.date<$.date?1:E.date>$.date?-1:$.ts-E.ts),p=h.filter(E=>E.amt>0).reduce((E,$)=>E+$.amt,0),m=h.filter(E=>E.amt<0).reduce((E,$)=>E-$.amt,0),w=`<div class="kpis"><div class="kpi"><b class="${r.bal>.004?"bad":""}">${Ze(r.bal)}</b><span>${s?"Μου χρωστάνε":"Του χρωστάω"}</span></div><div class="kpi"><b>${ve(r.days)}</b><span>Ημέρες συνολικά</span></div>
    <div class="kpi"><b>${Ze(r.earned)}</b><span>Μεροκάματα</span></div><div class="kpi"><b>${Ze(r.paid)}</b><span>Πληρωμές</span></div></div>
    <div class="actions"><button class="btn b1" data-wa="work-new" data-emp="${Y(n)}">＋ Μεροκάματο</button>${o?`<button class="btn b2" data-wa="pay-new" data-emp="${Y(n)}">💶 Πληρωμή</button>`:""}</div>
    ${l.length>1?`<div class="chips"><button data-wm="" class="${u?"":"on"}">Όλοι οι μήνες</button>${l.map(E=>`<button data-wm="${E}" class="${u===E?"on":""}">${iR(E)}</button>`).join("")}</div>`:""}
    <div class="card">${h.map(E=>`<${o?`button class="row prow" data-wa="${E.t}-edit" data-id="${Y(E.id)}"`:'div class="row"'}><div class="av">${E.t==="work"?"🛠️":"💶"}</div>
      <div class="t"><b>${Kn(E.date)} · ${nR(E.date)}</b><span>${Y(E.desc)}</span></div><div class="r"><div class="amt ${E.amt<0?"ok":""}">${E.amt>0?"+":"−"}${Ze(Math.abs(E.amt))}</div><span class="muted">${E.t==="work"?"μεροκάματο":"πληρωμή"}</span></div></${o?"button":"div"}>`).join("")||`<div class="empty">${Yn("wdays")?"Καμία κίνηση.":"Φόρτωση…"}</div>`}
    ${h.length?`<div class="tot"><span>Μεροκάματα ${Ze(p)} · Πληρωμές ${Ze(m)}</span><b>${Ze(p-m)}</b></div>`:""}</div>
    ${o?`<button class="btn b2 wide" data-wa="emp-edit" data-emp="${Y(n)}">✏️ Στοιχεία υπαλλήλου</button>`:'<div class="hint">Τα μεροκάματα που καταχωρείς μπαίνουν με το ημερομίσθιο που έχει ορίσει ο διαχειριστής. Αλλαγές και πληρωμές τις κάνει εκείνος.</div>'}`;return t(e(i.name,`${Ze(i.rate||0)} / ημέρα`,s?"":'<a class="ib" href="#/wages">←</a>'),w+Mv(),s?"menu":null)}function aR(n,e,t){const s=[],i=n.split("-"),r=e.split("-"),o=new Date(+i[0],+i[1]-1,+i[2],12),a=new Date(+r[0],+r[1]-1,+r[2],12);for(;o<=a&&s.length<93;){const l=o.getDay();t&&(l===0||l===6)||s.push(Ed(o)),o.setDate(o.getDate()+1)}return s}function Ov(n){return n.date?n.id||!n.to||n.to<=n.date?[n.date]:aR(n.date,n.to,!!n.skipWe):[]}function Qs(n,e,t){const s=e||(_e()?Lt():O.emp)||(Td()[0]||{}).id||"";if(n==="work"){const i=t&&we(A.wdays,t),r=we(A.emps,i?i.empId:s);O.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,days:ve(i.days),rate:ve(i.rate!=null&&i.rate!==""?i.rate:P(i.days)?P(i.amount)/P(i.days):r&&r.rate||0),note:i.note||"",from:i.from||"",until:i.until||""}:{empId:s,date:pe(),to:"",skipWe:!0,days:"1",rate:ve(r&&r.rate||0),note:"",from:"",until:""},msg:""}}else if(n==="pay"){const i=t&&we(A.wpays,t);O.f={kind:n,v:i?{id:i.id,empId:i.empId,date:i.date,amount:ve(i.amount),method:i.method||"cash",note:i.note||""}:{empId:s,date:pe(),amount:"",method:"cash",note:""},msg:""}}else{const i=t&&we(A.emps,t);O.f={kind:"emp",v:i?{id:i.id,name:i.name||"",rate:ve(i.rate||0),phone:i.phone||"",email:i.email||""}:{name:"",rate:"",phone:"",email:""},msg:""}}}const _t=(n,e,t="")=>`<label class="f">${e}<input class="in" data-wf="${n}" value="${Y(O.f.v[n]??"")}" ${t}></label>`;function Mv(){const n=O.f;if(!n)return"";const e=n.v,t=_e(),s=Td();let i="",r="";const o=`<label class="f">Υπάλληλος<select class="in" data-wf="empId" ${t||e.id?"disabled":""}>${s.map(a=>`<option value="${Y(a.id)}" ${a.id===e.empId?"selected":""}>${Y(a.name)}</option>`).join("")}</select></label>`;if(n.kind==="work"){i=e.id?"Διόρθωση μεροκάματου":"Νέο μεροκάματο";const a=Ov(e).length,l=Ot(e.days),u=t?P((we(A.emps,Lt())||{}).rate):Ot(e.rate);r=`${o}<div class="two">${_t("date","Ημερομηνία",'type="date"')}${e.id?"":_t("to","Έως (για πολλές μέρες)",'type="date"')}</div>
      ${!e.id&&e.to&&e.to>e.date?`<label class="chk2"><input type="checkbox" data-wf="skipWe" ${e.skipWe?"checked":""}> Χωρίς Σάββατο/Κυριακή</label>`:""}
      <div class="f">Ημέρες ανά ημερομηνία</div><div class="chips wrap">${["1","0,5","1,5","2"].map(h=>`<button data-wd="${h}" class="${e.days===h?"on":""}">${h}</button>`).join("")}</div>
      <div class="two">${_t("days","Ημέρες",'inputmode="decimal"')}${_t("rate","Ημερομίσθιο €",`inputmode="decimal" ${t?"disabled":""}`)}</div>
      <div class="two">${_t("from","Από ώρα (προαιρετικό)",'type="time"')}${_t("until","Έως ώρα",'type="time"')}</div>
      ${_t("note","Σημείωση",'placeholder="π.χ. εγκατάσταση Βόνιτσα"')}
      <div class="ask">${a?`${a} ${a===1?"ημέρα":"ημέρες"} × ${isNaN(l)?"—":ve(l)} × ${Ze(isNaN(u)?0:u)} = <b>${Ze(U(a*(isNaN(l)?0:l)*(isNaN(u)?0:u)))}</b>`:"Βάλε ημερομηνία."}</div>`}else n.kind==="pay"?(i=e.id?"Διόρθωση πληρωμής":"Πληρωμή στον υπάλληλο",r=`${o}<div class="two">${_t("date","Ημερομηνία",'type="date"')}${_t("amount","Ποσό €",'inputmode="decimal"')}</div>
      <div class="seg">${[["cash","💵 Μετρητά"],["bank","🏦 Τράπεζα"]].map(([a,l])=>`<button data-wpm="${a}" class="${e.method===a?"on":""}">${l}</button>`).join("")}</div>
      ${_t("note","Σημείωση")}${e.empId?`<div class="ask">Του χρωστάω τώρα <b>${Ze(La(e.empId).bal)}</b></div>`:""}`):(i=e.id?"Στοιχεία υπαλλήλου":"Νέος υπάλληλος",r=`${_t("name","Όνομα",'autocomplete="off"')}${_t("rate","Ημερομίσθιο €",'inputmode="decimal"')}${_t("phone","Κινητό",'inputmode="tel"')}${_t("email","Email",'inputmode="email"')}
      ${e.id?'<div class="hint">Η αλλαγή ημερομισθίου ισχύει για τα νέα μεροκάματα· τα παλιά μένουν όπως είναι.</div>':""}`);return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${i}</b><button class="ib dk" data-wa="close">✕</button></div>
    <div class="sheet-list pad">${r}${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-wa="close">Άκυρο</button><button class="btn b1" data-wa="save">💾 Αποθήκευση</button></div></div></div>`}function cR(n){const e=O.f,t=e.v,s=_e();if(!Yn("emps"))return e.msg="Περίμενε να φορτώσουν τα δεδομένα.";if(e.kind==="emp"){const m=String(t.name||"").trim(),w=Ot(t.rate);if(!m)return e.msg="Γράψε όνομα.";if(isNaN(w)||w<0)return e.msg="Βάλε ημερομίσθιο.";const E={name:m,rate:U(w),phone:String(t.phone||"").trim(),email:String(t.email||"").trim()};if(t.id){const $=Dn(we(A.emps,t.id));Yt("emps",t.id,E);const R=we(A.emps,t.id);ll($,R)&&Hs("emps","edit",t.id,$,Dn(R))}else{const $={id:je(),ts:Date.now(),...E};Ue("emps",$),Hs("emps","create",$.id,null,$)}return O.f=null,n(t.id?"Ο υπάλληλος ενημερώθηκε.":"Ο υπάλληλος προστέθηκε."),""}const i=s?Lt():t.empId,r=we(A.emps,i);if(!r)return e.msg="Διάλεξε υπάλληλο.";if(e.kind==="pay"){const m=Ot(t.amount);if(!t.date)return e.msg="Βάλε ημερομηνία.";if(isNaN(m))return e.msg="Βάλε ποσό.";const w={empId:i,date:t.date,amount:U(m),method:t.method==="bank"?"bank":"cash",note:String(t.note||"").trim()};if(t.id){const E=Dn(we(A.wpays,t.id));Yt("wpays",t.id,w);const $=we(A.wpays,t.id);ll(E,$)&&Hs("wpays","edit",t.id,E,Dn($))}else{const E={id:je(),ts:Date.now(),...w};Ue("wpays",E),Hs("wpays","create",E.id,null,E)}return O.f=null,n(t.id?"Η πληρωμή ενημερώθηκε.":"Η πληρωμή αποθηκεύτηκε."),""}const o=Ov(t);if(!o.length)return e.msg="Βάλε ημερομηνία.";const a=Ot(t.days);let l=Ot(t.rate);if(s&&(l=P(r.rate,0),t.id))return e.msg="Τις αλλαγές τις κάνει ο διαχειριστής.";if(isNaN(a)||a<=0||a>31)return e.msg="Βάλε πόσες ημέρες δούλεψε (π.χ. 1 ή 0,5).";if(isNaN(l))return e.msg="Βάλε ημερομίσθιο.";const u=t.from||"",h=t.until||"";if(!!u!=!!h)return e.msg="Βάλε και τις δύο ώρες (από – έως) ή καμία.";const p={empId:i,days:a,rate:l,amount:U(a*l),note:String(t.note||"").trim(),from:u,until:h};if(t.id){const m=Dn(we(A.wdays,t.id));Yt("wdays",t.id,{...p,date:o[0]});const w=we(A.wdays,t.id);ll(m,w)&&Hs("wdays","edit",t.id,m,Dn(w))}else{const m=Date.now(),w=je();o.forEach((E,$)=>{const R={id:w+$,...p,date:E,ts:m+$};Ue("wdays",R),Hs("wdays","create",R.id,null,R)})}return O.f=null,n(t.id?"Το μεροκάματο ενημερώθηκε.":o.length===1?"Το μεροκάματο αποθηκεύτηκε.":`Προστέθηκαν ${o.length} μεροκάματα.`),""}function yc(n,e){let t=0,s=0,i=0,r=0;return A.ldocs.forEach(o=>{o.kind==="purchase"&&o.items&&o.items.forEach(a=>{a.pid===n&&(t+=P(a.qty))})}),A.smoves.forEach(o=>{o.pid===n&&(t+=P(o.qty))}),A.quotes.forEach(o=>{if(o.id===e)return;const a=nt(o);(o.lines||[]).forEach(l=>{if(l.pid!==n||l.src!=="stock")return;const u=P(l.qty);a==="done"?o.noStock||(s+=u):a==="accepted"?i+=u:a==="pending"&&(r+=u)})}),{inQ:U(t),onHand:U(t-s),reserved:U(i),pending:U(r),avail:U(t-s-i)}}const Lv=n=>n&&Array.isArray(n.links)&&n.links.length?n.links:n&&(n.sup||n.url)?[{sup:n.sup||"",url:n.url||""}]:[];function la(){const n={},e=(t,s)=>n[t]||(n[t]={pid:t,qty:0,sup:0,stk:0,qs:[],desc:s||"",why:[]});return A.quotes.forEach(t=>{nt(t)==="accepted"&&(t.lines||[]).forEach(s=>{if(!s.pid||s.src!=="supplier")return;const i=e(s.pid,s.desc);i.sup+=P(s.qty),i.qs.includes(t.number)||i.qs.push(t.number)})}),A.products.forEach(t=>{const s=P(t.minQty,0),i=yc(t.id),r=Math.max(0,s-i.avail);if(r>.004){const o=e(t.id,t.model);o.stk=U(r),o.why.push(i.avail<0?"λείπουν "+ve(-i.avail)+" για δεσμευμένες"+(s?" + ελάχιστο "+ve(s):""):"απόθεμα "+ve(i.avail)+" < ελάχιστο "+ve(s))}}),Object.values(n).map(t=>(t.qty=U(t.sup+t.stk),t.sup&&t.why.unshift(ve(t.sup)+" για προσφορές "+t.qs.join(", ")),t)).filter(t=>t.qty>0).sort((t,s)=>{const i=we(A.products,t.pid),r=we(A.products,s.pid);return String(i?i.model:t.desc).localeCompare(String(r?r.model:s.desc),"el")})}function lR(){const n={};return la().forEach(e=>{const t=we(A.products,e.pid),s=t?Lv(t)[0]:null,i=s&&s.sup||"Χωρίς προμηθευτή";(n[i]=n[i]||[]).push("• "+(t?t.model:e.desc)+" × "+ve(e.qty))}),Object.keys(n).sort().map(e=>e+`:
`+n[e].join(`
`)).join(`

`)}const uR={in:"Χειροκίνητη εισαγωγή",out:"Χειροκίνητη έξοδος",set:"Διόρθωση αποθέματος"};function dR(n,e){_e()&&(O.stTab="needs");const t=_e()?[["needs","🧰 Εργαλεία που λείπουν"]]:[["stock","📦 Απόθεμα"],["order","🛒 Παραγγελία"],["moves","↕ Κινήσεις"],["needs","🧰 Λείπουν"]],s=O.stTab;let i=t.length>1?`<div class="chips">${t.map(([r,o])=>`<button data-stt="${r}" class="${s===r?"on":""}">${o}${r==="order"&&la().length?` (${la().length})`:""}${r==="needs"?` (${A.needs.filter(a=>!a.gone&&!a.done).length})`:""}</button>`).join("")}</div>`:"";if(s==="stock"){const r=A.products.map(m=>({p:m,i:yc(m.id)}));let o=0,a=0,l=0,u=0;r.forEach(m=>{m.i.onHand>0&&(o++,a+=m.i.onHand,l+=m.i.onHand*P(m.p.cost)),m.i.avail<0&&u++});const h=$e(O.stQ),p=r.filter(m=>(O.stAll||m.i.inQ!==0||m.i.onHand!==0||m.i.reserved||m.i.pending||P(m.p.minQty,0)>0)&&$e((m.p.cat||"")+" "+m.p.model+" "+(m.p.desc||"")).includes(h)).sort((m,w)=>String(m.p.model).localeCompare(String(w.p.model),"el"));i+=`<div class="kpis"><div class="kpi"><b>${o}</b><span>Είδη στο ράφι</span></div><div class="kpi"><b>${ve(a)}</b><span>Τεμάχια</span></div><div class="kpi"><b>${Ze(l)}</b><span>Αξία (τιμή αγοράς)</span></div><div class="kpi"><b class="${u?"bad":""}">${u}</b><span>Ελλείψεις</span></div></div>
      <input class="search" id="stq" data-stq placeholder="🔍 Αναζήτηση προϊόντος" value="${Y(O.stQ)}">
      <label class="chk2"><input type="checkbox" data-stall ${O.stAll?"checked":""}> Όλα τα προϊόντα του καταλόγου</label>
      <div class="card">${p.slice(0,200).map(({p:m,i:w})=>{const E=P(m.minQty,0);return`<button class="row prow" data-sp="${Y(m.id)}"><div class="t"><b>${Y(m.model)}</b><span>${Y([m.cat,m.desc].filter(Boolean).join(" · "))}${w.reserved?` · δεσμευμένα ${ve(w.reserved)}`:""}${w.pending?` · σε προσφορές ${ve(w.pending)}`:""}${E?` · ελάχ. ${ve(E)}`:""}</span></div>
        <div class="r"><div class="amt">${ve(w.onHand)}</div><span class="pill ${w.avail<0?"p-b":E&&w.avail<E?"p-w":w.avail>0?"p-ok":"p-a"}">διαθ. ${ve(w.avail)}</span></div></button>`}).join("")||`<div class="empty">${Yn("products")?A.products.length?"Δεν υπάρχουν προϊόντα στην αποθήκη. Τσέκαρε «Όλα τα προϊόντα» για να βάλεις απόθεμα.":"Ο κατάλογος είναι άδειος.":"Φόρτωση…"}</div>`}</div>`}else if(s==="order"){const r=la();i+=`<div class="card">${r.map(o=>{const a=we(A.products,o.pid),l=a?Lv(a):[];return`<div class="item"><div class="t"><b>${Y(a?a.model:o.desc)} × ${ve(o.qty)}</b><span style="white-space:normal">${Y(o.why.join(" · "))}</span>
      ${l.map(u=>`<span>${Y(u.sup||"")}${u.code?" · "+Y(u.code):""}${/^https?:\/\//.test(u.url||"")?` · <a class="lnk" href="${Y(u.url)}">άνοιγμα</a>`:""}</span>`).join("")}</div></div>`}).join("")||'<div class="empty">Τίποτα προς παραγγελία. Εδώ μπαίνουν οι γραμμές «Από προμηθευτή» των δεκτών προσφορών, οι ελλείψεις και ό,τι είναι κάτω από το ελάχιστο απόθεμα.</div>'}</div>
      ${r.length?'<button class="btn b1 wide" data-sa="ocopy">📋 Αντιγραφή λίστας ανά προμηθευτή</button>':""}`}else if(s==="moves"){const r=[];A.smoves.forEach(o=>r.push({date:o.date,ts:o.ts||0,pid:o.pid,qty:P(o.qty),why:uR[o.kind]||"Κίνηση",note:o.note})),A.ldocs.forEach(o=>{o.kind==="purchase"&&o.items&&o.items.forEach(a=>r.push({date:o.date,ts:o.ts||0,pid:a.pid,qty:P(a.qty),why:"Αγορά από "+o.party+(o.number?" ("+o.number+")":""),note:""}))}),r.sort((o,a)=>o.date<a.date?1:o.date>a.date?-1:a.ts-o.ts),i+=`<div class="card">${r.slice(0,80).map(o=>{const a=we(A.products,o.pid);return`<div class="item"><div class="t"><b>${Y(a?a.model:"(διαγραμμένο προϊόν)")}</b><span>${Kn(o.date)} · ${Y(o.why)}${o.note?" · "+Y(o.note):""}</span></div><div class="amt ${o.qty<0?"bad":"ok"}">${o.qty>0?"+":""}${ve(o.qty)}</div></div>`}).join("")||'<div class="empty">Δεν υπάρχουν κινήσεις ακόμα.</div>'}</div>`}else i+=pR();return e(n(_e()?"Εργαλεία που λείπουν":"Αποθήκη",_e()?"Ό,τι λείπει από το συνεργείο":"Απόθεμα · παραγγελίες · εργαλεία"),i+hR(),"menu",s==="needs"?'<button class="fab" data-na="new" aria-label="Προσθήκη">＋</button>':"")}function hR(){const n=O.sheet;if(!n)return"";if(n.kind==="need"){const o=n.v;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${o.id?"Αλλαγή":"Τι λείπει;"}</b><button class="ib dk" data-na="close">✕</button></div><div class="sheet-list pad">
      <label class="f">Εργαλείο / υλικό<input class="in" data-nf="title" maxlength="120" value="${Y(o.title)}" placeholder="π.χ. Κρουστικό δράπανο"></label>
      <div class="two"><label class="f">Ποσότητα<input class="in" data-nf="qty" maxlength="20" value="${Y(o.qty)}"></label><label class="f">Σημείωση<input class="in" data-nf="notes" maxlength="300" value="${Y(o.notes)}"></label></div>
      ${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}</div><div class="actions"><button class="btn b2" data-na="close">Άκυρο</button><button class="btn b1" data-na="save">💾 Αποθήκευση</button></div></div></div>`}const e=we(A.products,n.pid);if(!e)return"";const t=yc(e.id),s=n.v,i=Ot(s.qty),r=isNaN(i)?null:s.type==="in"?t.onHand+i:s.type==="out"?t.onHand-i:i;return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${Y(e.model)}</b><button class="ib dk" data-sa="close">✕</button></div><div class="sheet-list pad">
    <div class="kpis"><div class="kpi"><b>${ve(t.onHand)}</b><span>Στο ράφι</span></div><div class="kpi"><b class="${t.avail<0?"bad":""}">${ve(t.avail)}</b><span>Διαθέσιμα (μετά τις δεσμευμένες)</span></div></div>
    <div class="seg">${[["in","➕ Εισαγωγή"],["out","➖ Έξοδος"],["set","✏️ Διόρθωση"]].map(([o,a])=>`<button data-smt="${o}" class="${s.type===o?"on":""}">${a}</button>`).join("")}</div>
    <div class="two"><label class="f">${s.type==="set"?"Πραγματική ποσότητα στο ράφι":"Ποσότητα"}<input class="in" data-sf="qty" inputmode="decimal" value="${Y(s.qty)}"></label><label class="f">Ημερομηνία<input class="in" type="date" data-sf="date" value="${Y(s.date)}"></label></div>
    <label class="f">Σημείωση<input class="in" data-sf="note" value="${Y(s.note)}"></label>
    <div class="ask" id="smprev">Τώρα στο ράφι: ${ve(t.onHand)} τεμ.${r!==null&&s.qty!==""?` → μετά: <b>${ve(U(r))}</b>`:""}</div>
    <label class="f" style="margin-top:10px">Ελάχιστο απόθεμα (κάτω από αυτό μπαίνει στη λίστα παραγγελίας)<input class="in" data-sf="min" inputmode="decimal" value="${Y(s.min)}" placeholder="—"></label>
    ${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}</div>
    <div class="actions"><button class="btn b2" data-sa="close">Άκυρο</button><button class="btn b1" data-sa="save">💾 Αποθήκευση</button></div></div></div>`}function fR(n){const e=O.sheet,t=e.v,s=we(A.products,e.pid);if(!s)return O.sheet=null;const i=t.min.trim()===""?0:Math.max(0,Ot(t.min));if(isNaN(i))return e.msg="Το ελάχιστο απόθεμα πρέπει να είναι αριθμός.";let r=[];if(t.qty.trim()!==""){const o=Ot(t.qty);if(isNaN(o)||o<0)return e.msg="Βάλε ποσότητα.";const a=yc(s.id),l=t.type==="in"?o:t.type==="out"?-o:U(o-a.onHand);if(!l)return e.msg="Δεν υπάρχει αλλαγή στην ποσότητα.";Ue("smoves",{id:je(),pid:s.id,qty:U(l),kind:t.type,date:t.date||pe(),note:t.note.trim(),ts:Date.now()}),r.push("Η κίνηση αποθηκεύτηκε")}P(s.minQty,0)!==i&&(Yt("products",s.id,{minQty:i}),r.push(i?"ελάχιστο "+ve(i):"χωρίς ελάχιστο")),O.sheet=null,n(r.length?r.join(" · ")+".":"Καμία αλλαγή.")}const Fa=n=>!_e()||!!(Ai()&&n.by&&n.by.uid===Ai().uid),Fp=n=>n?Kn(Ed(new Date(n))):"";function pR(){const n=A.needs.filter(i=>!i.gone),e=n.filter(i=>!i.done).sort((i,r)=>(r.ts||0)-(i.ts||0)),t=n.filter(i=>i.done).sort((i,r)=>(r.doneAt||r.ts||0)-(i.doneAt||i.ts||0)),s=(i,r)=>`<div class="tc${r?" dn":""}" style="--c:${r?"var(--ok)":"var(--warn)"}">
    ${_e()?`<span class="tick${r?" on":""}" style="display:flex;align-items:center;justify-content:center">${r?"✓":""}</span>`:`<button class="tick${r?" on":""}" data-na="done" data-id="${Y(i.id)}" aria-label="Παραγγέλθηκε">${r?"✓":""}</button>`}
    <div class="t" style="flex:1"><b>${Y(i.title)}${i.qty?" × "+Y(i.qty):""}</b><span>${Y(i.by&&i.by.name||"—")} · ${Y(Fp(i.ts))}${r&&i.doneAt?" · ✔ παραγγέλθηκε "+Y(Fp(i.doneAt)):""}${i.notes?" · "+Y(i.notes):""}</span></div>
    ${Fa(i)?`<button class="x" style="background:var(--accs);color:var(--acc)" data-na="edit" data-id="${Y(i.id)}" aria-label="Αλλαγή">✏️</button><button class="x" data-na="gone" data-id="${Y(i.id)}" aria-label="Αφαίρεση">✕</button>`:""}</div>`;return`<div class="hint">${_e()?"Ό,τι γράφεις εδώ το βλέπει και ο διαχειριστής και μπαίνει στη λίστα παραγγελιών του.":"Το PWA τα συγχρονίζει με τη λίστα «Εργαλεία που λείπουν» του Microsoft To Do."}</div>
    <div class="h">Να παραγγελθούν (${e.length})${!_e()&&e.length?'<a class="hl" data-na="copy">📋 Αντιγραφή</a>':""}</div>
    <div class="card">${e.map(i=>s(i,!1)).join("")||`<div class="empty">${Yn("needs")?"Δεν λείπει τίποτα αυτή τη στιγμή.":"Φόρτωση…"}</div>`}</div>
    ${t.length?`<div class="h">Παραγγέλθηκαν (${t.length})</div><div class="card">${t.slice(0,40).map(i=>s(i,!0)).join("")}</div>`:""}`}function mR(n){const e=O.sheet,t=e.v,s=String(t.title||"").trim().slice(0,120);if(!s)return e.msg="Γράψε ποιο εργαλείο λείπει.";const i=Date.now(),r=String(t.qty||"").trim().slice(0,20),o=String(t.notes||"").trim().slice(0,300);if(t.id){const a=we(A.needs,t.id);if(!a||!Fa(a))return O.sheet=null;Yt("needs",a.id,{title:s,qty:r,notes:o,by:a.by||{uid:"",name:""},upd:i,dirty:!0}),n("Η καταχώριση ενημερώθηκε.")}else Ue("needs",{id:je(),ts:i,title:s,qty:r,notes:o,done:!1,gone:!1,msId:"",msList:"",by:zn()||{uid:"",name:"Διαχειριστής"},upd:i,dirty:!0}),n("Προστέθηκε: "+s+".");O.sheet=null}const Fv=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(P(e.m,0))):P(ae()&&ae().warrantyMonths,24)},Up=n=>!(n&&n.war&&n.war.on===!1),ws=n=>n.install||{date:n.statusDate||"",months:Up(n)?Fv(n):0,serials:"",nw:!Up(n)},vc=(n,e)=>{if(!n)return"";const t=new Date(n+"T00:00:00");return isNaN(t)?"":(t.setMonth(t.getMonth()+P(e,0)),Ed(t))};function qp(n){const e=ws(n);if(e.nw)return{k:"na",t:"Χωρίς εγγύηση",end:""};const t=vc(e.date,e.months);if(!t)return{k:"na",t:"—",end:""};const s=Math.ceil((new Date(t+"T23:59:59")-Date.now())/864e5);return s<0?{k:"ex",t:"Έληξε",end:t,days:s}:s<=60?{k:"warn",t:"Λήγει σε "+s+" ημ.",end:t,days:s}:{k:"okp",t:"Ενεργή",end:t,days:s}}const gR=n=>{const e=ws(n);return P(e.mt,0)>0?vc(e.mtLast||e.date,e.mt):""},yR={okp:"p-ok",warn:"p-w",ex:"p-b",na:"p-a"};function vR(n,e){const t=A.quotes.filter(u=>nt(u)==="done").sort((u,h)=>(ws(h).date||"")<(ws(u).date||"")?-1:1),s={okp:0,warn:0,ex:0};t.forEach(u=>{const h=qp(u);s[h.k]!=null&&s[h.k]++});const i=$e(O.inQ),r=t.filter(u=>!i||$e([u.number,u.subject,u.customer&&u.customer.name,u.customer&&u.customer.address].join(" ")).includes(i)),o=pe().slice(0,10),a=vc(o,1),l=`<div class="kpis"><div class="kpi"><b>${t.length}</b><span>Εγκαταστάσεις</span></div><div class="kpi"><b>${s.okp}</b><span>Ενεργές εγγυήσεις</span></div>
    <div class="kpi"><b class="${s.warn?"bad":""}">${s.warn}</b><span>Λήγουν σε 60 ημέρες</span></div><div class="kpi"><b>${s.ex}</b><span>Έληξαν</span></div></div>
    <input class="search" id="inq" data-inq placeholder="🔍 Πελάτης, αριθμός, περιοχή" value="${Y(O.inQ)}">
    <div class="card">${r.map(u=>{const h=ws(u),p=qp(u),m=gR(u),w=u.customer&&u.customer.name||"";return`<button class="row prow" data-ie="${Y(u.id)}"><div class="av">${Jt(u)?"🛠️":"🛡️"}</div><div class="t"><b>${Jt(u)?Y(u.subject||"Παλιά εγκατάσταση"):"#"+Y(u.number||"—")+" · "+Y(w)}</b>
        <span>${Jt(u)?Y(w)+" · ":u.subject?Y(u.subject)+" · ":""}${h.date?"εγκατ. "+Kn(h.date):"χωρίς ημερομηνία"}${p.end?" · λήξη "+Kn(p.end):""}${m?" · 🔧 "+Kn(m):""}</span></div>
        <div class="r"><span class="pill ${yR[p.k]}">${Y(p.t)}</span>${m&&m<=a?'<span class="pill p-w">🔧 συντήρηση</span>':""}</div></button>`}).join("")||`<div class="empty">${Yn("quotes")?"Δεν υπάρχουν ολοκληρωμένες εγκαταστάσεις.":"Φόρτωση…"}</div>`}</div>
    <div class="hint">Βεβαίωση, υπογραφή και κωδικοί εγκατάστασης: από το PWA.</div>`;return e(n("Εγκαταστάσεις","Εγγυήσεις · συντηρήσεις"),l+_R(),"menu")}function _R(){const n=O.sheet;if(!n||n.kind!=="inst")return"";const e=we(A.quotes,n.id);if(!e)return"";const t=n.v,s=t.nw?"":vc(t.date,P(t.months,0));return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>${Jt(e)?Y(e.subject||"Εγκατάσταση"):"#"+Y(e.number)+" · "+Y(e.customer&&e.customer.name||"")}</b><button class="ib dk" data-ia="close">✕</button></div><div class="sheet-list pad">
    <label class="f">Ημερομηνία εγκατάστασης<input class="in" type="date" data-if="date" value="${Y(t.date)}"></label>
    <label class="chk2"><input type="checkbox" data-if="war" ${t.nw?"":"checked"}> Με εγγύηση</label>
    ${t.nw?"":`<label class="f">Μήνες εγγύησης<input class="in" data-if="months" inputmode="numeric" value="${Y(t.months)}"></label><div class="hint">Λήξη: <b>${s?Kn(s):"—"}</b></div>`}
    <a class="btn b2 wide" href="#/files/${encodeURIComponent(e.id)}">🧾 Τιμολόγια & φωτογραφίες (${(e.install&&e.install.docs||[]).length}/${(e.install&&e.install.photos||[]).length})</a>
    <a class="btn b2 wide" href="#/sn/${encodeURIComponent(e.id)}">🔢 Σειριακοί (${(e.install&&e.install.sns||[]).length})</a>
    <div class="f">🔧 Περιοδική συντήρηση</div><div class="chips wrap">${[[0,"Καμία"],[6,"Κάθε 6 μήνες"],[12,"Κάθε 12 μήνες"]].map(([i,r])=>`<button data-imt="${i}" class="${P(t.mt,0)===i?"on":""}">${r}</button>`).join("")}</div>
    ${P(t.mt,0)?`<label class="f">Τιμή συντήρησης €<input class="in" data-if="mtp" inputmode="decimal" value="${Y(t.mtp)}" placeholder="π.χ. 120"></label>`:""}
    ${n.msg?`<div class="err box">${Y(n.msg)}</div>`:""}
    <a class="btn b2 wide" href="#/q/${encodeURIComponent(e.id)}">📄 Άνοιγμα ${Jt(e)?"έργου":"προσφοράς"}</a></div>
    <div class="actions"><button class="btn b2" data-ia="close">Άκυρο</button><button class="btn b1" data-ia="save">💾 Αποθήκευση</button></div></div></div>`}function bR(n){const e=O.sheet,t=we(A.quotes,e.id);if(!t)return O.sheet=null;const s=e.v,i=ut(ws(t));if(i.date=s.date||"",i.nw=!!s.nw,!i.nw){const o=Math.floor(Ot(s.months));if(isNaN(o)||o<0)return e.msg="Βάλε μήνες εγγύησης.";i.months=o}const r=Math.max(0,Math.floor(P(s.mt,0)));if(r){i.mt=r;const o=Ot(s.mtp);o>0?i.mtp=U(o):delete i.mtp}else delete i.mt,delete i.mtLast,delete i.mtp;Yt("quotes",t.id,{install:i}),O.sheet=null,n("Αποθηκεύτηκε.")}function Uv(n){const e=we(A.products,n);return e?(O.stTab="stock",O.sheet={kind:"stock",pid:n,v:{type:"in",qty:"",date:pe(),note:"",min:P(e.minQty,0)?ve(e.minQty):""},msg:""},!0):!1}function wR(n,e,t){const s=n.closest("[data-wa],[data-wm],[data-wd],[data-wpm],[data-stt],[data-sp],[data-sa],[data-smt],[data-na],[data-ie],[data-ia],[data-imt]");if(!s)return!1;const i=s.dataset;if(i.wa){const r=i.wa;r==="close"?O.f=null:r==="save"?cR(t):r==="work-new"?Qs("work",i.emp):r==="pay-new"?Qs("pay",i.emp):r==="work-edit"?Qs("work","",i.id):r==="pay-edit"?Qs("pay","",i.id):r==="emp-new"?Qs("emp"):r==="emp-edit"&&Qs("emp","",i.emp)}else if(i.wm!==void 0)O.month=i.wm;else if(i.wd)O.f&&(O.f.v.days=i.wd);else if(i.wpm)O.f&&(O.f.v.method=i.wpm);else if(i.stt)O.stTab=i.stt;else if(i.sp){const r=we(A.products,i.sp);O.sheet={kind:"stock",pid:i.sp,v:{type:"in",qty:"",date:pe(),note:"",min:r&&P(r.minQty,0)?ve(r.minQty):""},msg:""}}else if(i.smt)O.sheet&&(O.sheet.v.type=i.smt);else if(i.sa){if(i.sa==="close")O.sheet=null;else if(i.sa==="save")fR(t);else if(i.sa==="ocopy"){const r=lR();return r&&(ye.copy("Λίστα παραγγελίας ("+Kn(pe())+`)

`+r),t("Η λίστα αντιγράφηκε, ανά προμηθευτή.")),!0}}else if(i.na){const r=i.id&&we(A.needs,i.id);if(i.na==="close")O.sheet=null;else if(i.na==="new")O.sheet={kind:"need",v:{title:"",qty:"",notes:""},msg:""};else if(i.na==="edit"&&r&&Fa(r))O.sheet={kind:"need",v:{id:r.id,title:r.title||"",qty:r.qty||"",notes:r.notes||""},msg:""};else if(i.na==="save")mR(t);else if(i.na==="done"&&r&&!_e()){const o=!r.done,a=Date.now();Yt("needs",r.id,{done:o,doneAt:o?a:void 0,upd:a,dirty:!0}),t(o?"Σημειώθηκε ως παραγγελμένο.":"Ξαναμπήκε στη λίστα.")}else if(i.na==="gone"&&r&&Fa(r))Yt("needs",r.id,{gone:!0,upd:Date.now(),dirty:!0}),t("Αφαιρέθηκε: "+r.title,{label:"Αναίρεση",fn:()=>{Yt("needs",r.id,{gone:!1,msId:"",upd:Date.now(),dirty:!0}),e()}});else if(i.na==="copy"){const o=A.needs.filter(a=>!a.gone&&!a.done).sort((a,l)=>(a.ts||0)-(l.ts||0)).map(a=>"• "+a.title+(a.qty?" × "+a.qty:"")+(a.notes?" ("+a.notes+")":"")).join(`
`);return o&&(ye.copy(o),t("Η λίστα αντιγράφηκε.")),!0}}else if(i.ie){const r=we(A.quotes,i.ie);if(r){const o=ws(r);O.sheet={kind:"inst",id:r.id,v:{date:o.date||"",nw:!!o.nw,months:String(P(o.months,Fv(r))),mt:P(o.mt,0),mtp:o.mtp?ve(o.mtp):""},msg:""}}}else i.imt!==void 0?O.sheet&&(O.sheet.v.mt=+i.imt):i.ia&&(i.ia==="close"?O.sheet=null:i.ia==="save"&&bR(t));return e(),!0}function IR(n,e){const t=n.dataset,s=i=>{e();const r=document.getElementById(i);r&&(r.focus(),r.setSelectionRange(r.value.length,r.value.length))};return"stq"in t?(O.stQ=n.value,s("stq"),!0):"inq"in t?(O.inQ=n.value,s("inq"),!0):t.wf&&O.f?(O.f.v[t.wf]=n.type==="checkbox"?n.checked:n.value,O.f.msg="",!0):t.nf&&O.sheet?(O.sheet.v[t.nf]=n.value,!0):t.sf&&O.sheet?(O.sheet.v[t.sf]=n.value,!0):t.if&&O.sheet?(O.sheet.v[t.if]=n.value,!0):!1}function ER(n,e){const t=n.dataset;if("stall"in t)return O.stAll=n.checked,e(),!0;if(t.wf&&O.f){if(O.f.v[t.wf]=n.type==="checkbox"?n.checked:n.value,t.wf==="empId"&&!O.f.v.id&&O.f.kind==="work"){const s=we(A.emps,n.value);s&&(O.f.v.rate=ve(s.rate||0))}return e(),!0}return t.sf&&O.sheet?(O.sheet.v[t.sf]=n.value,e(),!0):t.if&&O.sheet?(t.if==="war"?O.sheet.v.nw=!n.checked:O.sheet.v[t.if]=n.value,e(),!0):!1}const Ct=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),TR=n=>String(Math.round(P(n)*100)/100).replace(".",","),Wn=(n,e)=>(n||[]).find(t=>t.id===e),AR=["ean_13","ean_8","upc_a","upc_e","EAN_13","EAN_8","UPC_A","UPC_E"],j={stream:null,det:null,zx:null,t:0,ref:"",label:"",last:"",lastT:0,lastDup:"",added:[],track:null,torch:!1,qid:""},qv=()=>!!j.stream||!!document.getElementById("scan-ov"),Bp=n=>!(n&&n.war&&n.war.on===!1),SR=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(P(e.m,0))):P((ae()||{}).warrantyMonths,24)},kR=n=>n.install||{date:n.statusDate||"",months:Bp(n)?SR(n):0,serials:"",nw:!Bp(n)};function Bv(n){const e=[],t={};return(n.lines||[]).forEach((s,i)=>{const r=s.pid?"p:"+s.pid:"l:"+i;if(t[r]){t[r].qty+=P(s.qty,0);return}t[r]={ref:r,label:s.desc||"(χωρίς περιγραφή)",qty:P(s.qty,0)},e.push(t[r])}),e}const Ad=(n,e)=>{const t=Bv(n).find(s=>s.ref===e);return t?t.label:""},ul=(n,e)=>Ue("qlog",{id:je(),qid:n.id,number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:"edit",text:e});function Ua(n,e){n.install?Da("quotes",n.id,"install.sns",e):Da("quotes",n.id,"install",{...kR(n),sns:e})}const jv=n=>String(n||"").split(/[\r\n]+/)[0].trim().replace(/^(S\/?N|SN|SER(IAL)?(\s*NO\.?)?)\s*[:#.\-]?\s*/i,"").replace(/\s+/g," ").trim(),RR=n=>/^([0-9A-F]{2}[:\-]?){5}[0-9A-F]{2}$/i.test(n);function zv(n,e,t,s,i){if(!i&&AR.includes(s))return"skip";const r=i?String(t||"").trim():jv(t);if(!r||r.length<3||r.length>64||!i&&(RR(r)||/^https?:\/\//i.test(r)))return"skip";const o=(n.install&&n.install.sns||[]).slice(),a=r.toUpperCase();if(o.some(u=>String(u.sn).toUpperCase()===a))return"dup";const l={id:je(),sn:r,ref:e,item:Ad(n,e),name:"",ts:Date.now()};return o.push(l),j.added.push(l.id),Ua(n,o),"added"}function PR(n,e,t){const s=Wn(A.quotes,n);if(!s)return t(e("Σειριακοί","",'<a class="ib" href="#/inst">←</a>'),'<div class="empty">Δεν βρέθηκε</div>',"menu");const i=s.install&&s.install.sns||[],r=Bv(s),o={};r.forEach(l=>o[l.ref]=1);const a=i.filter(l=>!o[l.ref]);return a.length&&r.push({ref:"__other",label:"Άλλα (προϊόντα που δεν υπάρχουν πια στην προσφορά)",qty:0}),t(e("Σειριακοί",`#${s.number||""} · ${s.customer&&s.customer.name||""}`,'<a class="ib" href="#/inst">←</a>'),'<div class="hint">Πάτα «📷 Σάρωση» στο προϊόν και σκάναρε τα barcode ή QR των συσκευών. Δίπλα σε κάθε σειριακό γράψε όνομα θέσης (π.χ. «Κάμερα εισόδου»).</div>'+r.map(l=>{const u=l.ref==="__other"?a:i.filter(h=>h.ref===l.ref);return`<div class="card pad sn-g"><div class="sn-h"><div><b>${Ct(l.label)}</b> <span class="muted">(${u.length}${l.qty?" / "+TR(l.qty):""})</span></div>${l.ref==="__other"?"":`<button class="btn b1 sm" data-sn-scan="${Ct(l.ref)}">📷 Σάρωση</button>`}</div>
      ${u.map(h=>`<div class="sn-row"><code>${Ct(h.sn)}</code><input class="in" data-sn-name="${Ct(h.id)}" value="${Ct(h.name||"")}" placeholder="Όνομα / θέση"><button class="ib dk" data-sn-del="${Ct(h.id)}" aria-label="Διαγραφή">🗑️</button></div>`).join("")}
      ${l.ref==="__other"?"":`<div class="sn-add"><input class="in" data-sn-add="${Ct(l.ref)}" placeholder="ή πληκτρολόγησε σειριακό" autocapitalize="characters" spellcheck="false"><button class="btn b2 sm" data-sn-addb="${Ct(l.ref)}">＋</button></div>`}</div>`}).join("")||'<div class="empty">Η προσφορά δεν έχει γραμμές.</div>',"menu")}let jp=null;const CR=()=>jp||(jp=Cn(()=>import("./zxing-CRxvinjV.js"),[]).then(n=>new Function(n.default+"; return ZXing;")()));function Gv(){try{const n=window.AudioContext||window.webkitAudioContext;j.ac=j.ac||new n;const e=j.ac.createOscillator(),t=j.ac.createGain();e.frequency.value=1250,t.gain.value=.12,e.connect(t),t.connect(j.ac.destination),e.start(),e.stop(j.ac.currentTime+.09)}catch{}}function DR(){let n=document.getElementById("scan-ov");return n||(n=document.createElement("div"),n.id="scan-ov",document.body.appendChild(n)),n}function Sd(){const n=Wn(A.quotes,j.qid),e=n?(n.install&&n.install.sns||[]).filter(i=>i.ref===j.ref).length:0,t=document.getElementById("sc-count");t&&(t.textContent=`Σκαναρισμένοι σε αυτό το προϊόν: ${e} · σε αυτή τη σάρωση: ${j.added.length}`);const s=document.getElementById("sc-undo");s&&(s.disabled=!j.added.length)}const $R=n=>String(n.code||"").split(/[\s,;]+/).filter(Boolean).map(e=>e.toUpperCase()),VR=n=>{const e=String(n).trim().toUpperCase();return e&&(A.products.find(t=>$R(t).includes(e))||A.products.find(t=>String(t.model||"").trim().toUpperCase()===e))||null};function Kv(n){const e=String(n||"").split(/[\r\n]+/)[0].trim();if(!e||e.length>64)return;const t=Date.now();if(e===j.last&&t-j.lastT<1800)return;j.last=e,j.lastT=t;const s=VR(e),i=document.getElementById("sc-last"),r=document.getElementById("sc-flash");if(s){try{navigator.vibrate&&navigator.vibrate(80)}catch{}Gv();const o=j.rerender;kd(),location.hash.startsWith("#/stock")?(Uv(s.id),o&&o()):(O.openNext=s.id,location.hash="#/stock")}else r&&(r.className="dup",setTimeout(()=>r.className="",350)),i&&(i.innerHTML="❓ Άγνωστος κωδικός <b>"+Ct(e)+"</b>")}function zp(n,e,t){if(j.mode==="find")return Kv(n);const s=Wn(A.quotes,j.qid);if(!s)return;const i=Date.now(),r=jv(n);if(r===j.last&&i-j.lastT<2500)return;const o=zv(s,j.ref,n,e,!1);if(o==="skip")return;j.last=r,j.lastT=i;const a=document.getElementById("sc-last"),l=document.getElementById("sc-flash"),u=h=>{l&&(l.className=h,setTimeout(()=>l.className="",350))};if(o==="added"){j.lastDup=r;try{navigator.vibrate&&navigator.vibrate(90)}catch{}Gv(),u("ok"),a&&(a.innerHTML="✅ <b>"+Ct(r)+"</b>")}else r!==j.lastDup&&(j.lastDup=r,u("dup"),a&&(a.innerHTML="Υπάρχει ήδη: <b>"+Ct(r)+"</b>"));Sd()}async function Gp(n,e,t,s){const i=n==="",r=Wn(A.quotes,n);if(!r&&!i)return;if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return t("Η κάμερα δεν είναι διαθέσιμη εδώ.");Object.assign(j,{mode:i?"find":"sn",qid:n,ref:e,label:i?"Σάρωση προϊόντος":Ad(r,e),added:[],last:"",lastT:0,lastDup:"",rerender:s});const o=DR();o.innerHTML=`<div class="sc-top"><b id="sc-title">${Ct(j.label)}</b><button class="ib dk" data-sc="close">✕</button></div><video id="sc-video" playsinline muted></video><div id="sc-flash"></div>
  <div class="sc-bot"><div id="sc-last">${i?"Σκάναρε το barcode ενός προϊόντος για να δεις το απόθεμά του.":"Στρέψε την κάμερα στο barcode ή στο QR του σειριακού."}</div><div id="sc-count"></div>
  <div class="sc-btns">${i?"":'<button class="btn b2" data-sc="undo" id="sc-undo" disabled>↶ Αναίρεση</button>'}<button class="btn b2" data-sc="torch" id="sc-torch" hidden>🔦</button><button class="btn b1" data-sc="close">Τέλος</button></div></div>`,o.onclick=a=>Wv(a.target,s,t),Sd();try{const a=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920},height:{ideal:1080}},audio:!1});if(!document.getElementById("scan-ov")){a.getTracks().forEach(h=>h.stop());return}j.stream=a,j.track=a.getVideoTracks()[0];const l=document.getElementById("sc-video");l.srcObject=a,l.muted=!0,await l.play();try{const h=j.track.getCapabilities&&j.track.getCapabilities();h&&h.torch&&(document.getElementById("sc-torch").hidden=!1)}catch{}let u=!1;if("BarcodeDetector"in window)try{const h=(await Promise.race([BarcodeDetector.getSupportedFormats(),new Promise((p,m)=>setTimeout(()=>m(1),1500))])).filter(p=>p!=="unknown");if(h.length){j.det=new BarcodeDetector({formats:h}),u=!0;const p=()=>{!j.stream||!j.det||j.det.detect(l).then(m=>(m||[]).forEach(w=>zp(w.rawValue,w.format,t)),()=>{}).then(()=>{j.stream&&(j.t=setTimeout(p,160))})};p()}}catch{}if(!u){const h=await CR();if(!j.stream)return;j.zx=new h.BrowserMultiFormatReader,l.srcObject=null,j.zx.decodeFromStream(j.stream,l,p=>{if(p){let m="";try{m=h.BarcodeFormat[p.getBarcodeFormat()]||""}catch{}zp(p.getText(),m,t)}})}}catch(a){kd(),t(a&&a.name==="NotAllowedError"?"Δεν δόθηκε άδεια για την κάμερα. Δώσ' την από τις ρυθμίσεις του κινητού.":"Δεν άνοιξε η κάμερα.")}}function kd(){if(clearTimeout(j.t),j.det=null,j.zx){try{j.zx.reset()}catch{}j.zx=null}j.stream&&(j.stream.getTracks().forEach(e=>e.stop()),j.stream=null),j.track=null,j.torch=!1;const n=document.getElementById("scan-ov");n&&n.remove()}function Wv(n,e,t){const s=n.closest("[data-sn-scan],[data-sn-del],[data-sn-addb],[data-sc],[data-bcscan]");if(!s)return!1;if(s.dataset.bcscan!==void 0)return Gp("","",t,e),!0;const i=s.dataset,r=location.hash.replace(/^#\//,"").split("/");if(i.sc){if(i.sc==="close"){const a=Wn(A.quotes,j.qid),l=j.added.length;kd(),a&&l&&j.mode!=="find"&&(ul(a,"Σάρωση σειριακών: "+l+" για «"+j.label+"»"),t("Προστέθηκαν "+l+" σειριακοί.")),e()}else if(i.sc==="undo"){const a=Wn(A.quotes,j.qid);if(a&&j.added.length){const l=j.added.pop();Ua(a,(a.install&&a.install.sns||[]).filter(u=>u.id!==l)),j.last="",Sd()}}else i.sc==="torch"&&j.track&&(j.torch=!j.torch,j.track.applyConstraints({advanced:[{torch:j.torch}]}).catch(()=>j.torch=!1));return!0}const o=Wn(A.quotes,decodeURIComponent(r[1]||""));if(!o)return!0;if(i.snScan)Gp(o.id,i.snScan,t,e);else if(i.snDel){const a=(o.install&&o.install.sns||[]).find(l=>l.id===i.snDel);a&&confirm("Διαγραφή του σειριακού "+a.sn+";")&&(Ua(o,o.install.sns.filter(l=>l.id!==i.snDel)),ul(o,"Διαγραφή σειριακού "+a.sn),e())}else if(i.snAddb){const a=document.querySelector(`[data-sn-add="${CSS.escape(i.snAddb)}"]`),l=a&&a.value,u=zv(o,i.snAddb,l,"",!0);u==="dup"?t("Αυτός ο σειριακός υπάρχει ήδη."):u==="skip"?t("Γράψε έναν σειριακό αριθμό."):(ul(o,"Σειριακός "+String(l).trim()+" ("+Ad(o,i.snAddb)+")"),e())}return!0}function NR(n){if(!n.dataset.snName)return!1;const e=Wn(A.quotes,decodeURIComponent(location.hash.replace(/^#\//,"").split("/")[1]||""));if(!e||!e.install)return!0;const t=(e.install.sns||[]).map(s=>s.id===n.dataset.snName?{...s,name:n.value.trim()}:s);return Ua(e,t),!0}const jt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Kp=n=>String(n??"").replace(".",","),Js=n=>{const e=parseFloat(String(n??"").replace(",","."));return isNaN(e)?NaN:e},J={open:"company",f:null,msg:"",ok:""},Hv=()=>!!J.f,xR=()=>{J.f=null,J.msg="",J.ok=""},OR=[["company","🏢","Εταιρεία & PDF",()=>ae().name||""],["prices","💶","Τιμές & αρίθμηση",()=>"ΦΠΑ "+P(ae().vat,24)+"% · κέρδος "+P(ae().margin,25)+"%"],["banks","🏦","Τραπεζικοί λογαριασμοί",()=>(ae().banks||[]).filter(n=>n.iban).length+" λογαριασμοί"],["team","👥","Χρήστες ομάδας",()=>Object.keys((A.st.roles||{}).users||{}).length+" χρήστες"]],Wp={company:()=>{const n=ae();return{name:n.name||"",info:n.info||"",bizEmail:n.bizEmail||"",pdfColor:n.pdfColor||"#1d4e89",logoMM:String(P(n.logoMM,18)),terms:n.terms||"",termsEn:n.termsEn||"",pubUrl:n.pubUrl||"",qrOn:n.qrOn!==!1}},prices:()=>{const n=ae();return{vat:Kp(P(n.vat,24)),margin:Kp(P(n.margin,25)),next:String(P(n.next,1)),validDays:String(n.validDays==null?15:P(n.validDays,15)),followDays:String(n.followDays==null?7:P(n.followDays,7)),warrantyMonths:String(P(n.warrantyMonths,24)),autoSale:n.autoSale!==!1}},banks:()=>({banks:(ae().banks||[]).map(n=>({id:n.id||je(),bank:n.bank||"",iban:n.iban||"",holder:n.holder||"",afm:n.afm||""}))})},on=(n,e,t="")=>`<label class="f">${e}<input class="in" data-sf="${n}" value="${jt(J.f.v[n]??"")}" ${t}></label>`,dl=(n,e,t=3)=>`<label class="f">${e}<textarea class="in" data-sf="${n}" rows="${t}">${jt(J.f.v[n]??"")}</textarea></label>`,Hp=(n,e)=>`<label class="chk"><input type="checkbox" data-sf="${n}" ${J.f.v[n]?"checked":""}> ${e}</label>`;function MR(n){const e=J.f&&J.f.k===n?J.f:null;if(n==="team")return`<div class="muted small" style="margin-bottom:6px">Οι χρήστες ομάδας (τεχνικοί) προστίθενται και αφαιρούνται από το PWA, γιατί χρειάζονται λογαριασμό στο Firebase. Εδώ φαίνονται μόνο.</div>
    ${Object.entries((A.st.roles||{}).users||{}).map(([i,r])=>`<div class="item"><div class="t"><b>${jt(r.name||"—")}</b><span>${r.role==="team"?"Τεχνικός":"Διαχειριστής"}${r.empId?" · υπάλληλος":""}</span></div></div>`).join("")||'<div class="empty">Δεν υπάρχουν χρήστες ομάδας.</div>'}`;if(!e)return`<button class="btn b2 wide" data-st-edit="${n}">✏️ Αλλαγή</button>`+LR(n);let t="";if(n==="company"){const s=e.logo||A.st.logo||{};t=`${on("name","Επωνυμία")}${dl("info","Στοιχεία (διεύθυνση, τηλ., email, ΑΦΜ)",5)}${on("bizEmail","Email επιχείρησης",'inputmode="email" autocapitalize="off"')}
    <div class="lbl">Λογότυπο PDF ${s.data?"":"(δεν υπάρχει)"}</div>${s.data?`<img class="logo-prev" src="${jt(s.data)}">`:""}
    <label class="btn b2 wide">🖼️ ${s.data?"Αλλαγή":"Επιλογή"} λογοτύπου<input type="file" accept="image/png,image/jpeg" data-sl hidden></label>
    <label class="f">Μέγεθος λογοτύπου<select class="in" data-sf="logoMM">${[["12","Μικρό"],["18","Μεσαίο"],["26","Μεγάλο"]].map(([i,r])=>`<option value="${i}"${String(e.v.logoMM)===i?" selected":""}>${r}</option>`).join("")}</select></label>
    <label class="f">Χρώμα PDF<input class="in" type="color" data-sf="pdfColor" value="${jt(e.v.pdfColor)}" style="height:42px;padding:2px;max-width:120px"></label>
    ${dl("terms","Όροι (κάτω στο PDF, ελληνικά)",4)}${dl("termsEn","Όροι στα αγγλικά (κενό = τα ελληνικά)",4)}
    ${on("pubUrl","Διεύθυνση συνδέσμων προς πελάτες",'inputmode="url" placeholder="https://tech-mate.gr" autocapitalize="off"')}${Hp("qrOn","QR στο PDF προς την Περιοχή πελάτη")}`}else n==="prices"?t=`${on("vat","ΦΠΑ %",'inputmode="decimal"')}${on("margin","Προεπιλεγμένο κέρδος % (για προϊόντα χωρίς δικό τους)",'inputmode="decimal"')}
    ${on("next","Επόμενος αριθμός προσφοράς",'inputmode="numeric"')}${on("validDays","Ισχύς προσφοράς (ημέρες, 0 = χωρίς)",'inputmode="numeric"')}
    ${on("followDays","Υπενθύμιση για προσφορά χωρίς απάντηση μετά από (ημέρες, 0 = καμία)",'inputmode="numeric"')}${on("warrantyMonths","Εγγύηση εγκατάστασης (μήνες)",'inputmode="numeric"')}
    ${Hp("autoSale","Όταν μια προσφορά γίνεται δεκτή, να φτιάχνεται αυτόματα παραστατικό πώλησης")}
    <div class="upd">Προσοχή στον «Επόμενο αριθμό»: αν τον κατεβάσεις, θα ξαναδοθούν αριθμοί που υπάρχουν ήδη.</div>`:n==="banks"&&(t=e.v.banks.map((s,i)=>`<div class="card pad" style="margin:0 0 8px">
      ${["bank:Τράπεζα","iban:IBAN","holder:Δικαιούχος","afm:ΑΦΜ δικαιούχου"].map(r=>{const[o,a]=r.split(":");return`<label class="f">${a}<input class="in" data-sb="${i}:${o}" value="${jt(s[o])}" ${o==="iban"?'autocapitalize="characters"':""}></label>`}).join("")}
      <button class="btn b2" data-st-bdel="${i}">🗑️ Αφαίρεση</button></div>`).join("")+'<button class="btn b2 wide" data-st-badd>＋ Νέος λογαριασμός</button>');return`${t}${J.msg?`<div class="err box">${jt(J.msg)}</div>`:""}<div class="actions"><button class="btn b2" data-st-cancel>Άκυρο</button><button class="btn b1" data-st-save="${n}">Αποθήκευση</button></div>
  <div class="muted small">Αλλάζουν μόνο τα πεδία αυτής της ενότητας· όλα τα υπόλοιπα στοιχεία μένουν όπως είναι.</div>`}function LR(n){const e=ae(),t=(s,i)=>`<div class="fld"><label>${s}</label><div class="v">${jt(i)||"—"}</div></div>`;return n==="company"?`<div class="sm">${t("Επωνυμία",e.name)}${t("Email",e.bizEmail)}${t("Σύνδεσμοι πελατών",e.pubUrl)}</div>`:n==="prices"?`<div class="sm">${t("Επόμενη προσφορά","#"+P(e.next,1))}${t("Ισχύς προσφοράς",(e.validDays==null?15:e.validDays)+" ημέρες")}${t("Εγγύηση",P(e.warrantyMonths,24)+" μήνες")}</div>`:n==="banks"?`<div class="sm">${(e.banks||[]).filter(s=>s.iban).map(s=>t(s.bank||"Τράπεζα",s.iban)).join("")||'<div class="muted small">Κανένας λογαριασμός.</div>'}</div>`:""}function FR(n,e){return e(n("Ρυθμίσεις","Εταιρεία · PDF · Τιμές · Τράπεζες",'<a class="ib" href="#/menu">←</a>'),`<div class="card">${OR.map(([t,s,i,r])=>`<div class="acc${J.open===t?" open":""}"><button class="acc-h" data-st-open="${t}"><span class="ic">${s}</span><span class="t"><b>${i}</b><span>${jt(r())}</span></span><span class="chev">${J.open===t?"▾":"▸"}</span></button>
      ${J.open===t?`<div class="acc-b">${MR(t)}</div>`:""}</div>`).join("")}</div>
    ${J.ok?`<div class="upd">${jt(J.ok)}</div>`:""}
    <div class="card"><a class="mi" href="#/cset"><div class="ic">🔔</div><div class="t"><b>Ειδοποιήσεις, widget & backup</b><span>Υπενθυμίσεις · Microsoft To Do · Αντίγραφα ημερολογίου</span></div></a></div>
    <div class="muted small" style="padding:0 6px 10px">Email προς πελάτες (πρότυπα, Microsoft), ιστοσελίδα, PIN και Περιοχή πελάτη ρυθμίζονται ακόμα από το PWA — δεν αλλάζουν από εδώ.</div>`,"menu")}function UR(n){return new Promise((e,t)=>{const s=new FileReader;s.onerror=()=>t(new Error("Δεν διαβάστηκε")),s.onload=()=>{const i=new Image;i.onerror=()=>t(new Error("Δεν είναι εικόνα")),i.onload=()=>{const r=Math.min(1,700/Math.max(i.naturalWidth,i.naturalHeight)),o=Math.max(1,Math.round(i.naturalWidth*r)),a=Math.max(1,Math.round(i.naturalHeight*r)),l=document.createElement("canvas");l.width=o,l.height=a;const u=l.getContext("2d"),h=n.type==="image/png";h||(u.fillStyle="#fff",u.fillRect(0,0,o,a)),u.drawImage(i,0,0,o,a),e({data:l.toDataURL(h?"image/png":"image/jpeg",.9),w:o,h:a})},i.src=s.result},s.readAsDataURL(n)})}function qR(n,e){const t=J.f.v,s={};if(n==="company"){const o=String(t.name||"").trim();if(!o)return J.msg="Γράψε επωνυμία.";const a=String(t.bizEmail||"").trim();if(a&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(a))return J.msg="Το email δεν φαίνεται σωστό.";const l=String(t.pubUrl||"").trim();if(l&&!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}(:\d+)?\/?$/i.test(l))return J.msg="Η διεύθυνση πρέπει να είναι σαν https://tech-mate.gr";Object.assign(s,{name:o,info:t.info,bizEmail:a,pdfColor:t.pdfColor,logoMM:P(t.logoMM,18),terms:t.terms,termsEn:t.termsEn,pubUrl:l,qrOn:!!t.qrOn})}else if(n==="prices"){const o=Js(t.vat),a=Js(t.margin),l=Js(t.next),u=Js(t.validDays),h=Js(t.followDays),p=Js(t.warrantyMonths);if([o,a,l,u,h,p].some(isNaN)||o<0||o>30||a<0||l<1||u<0||h<0||p<0)return J.msg="Έλεγξε τους αριθμούς (δεν μπορούν να είναι κενοί ή αρνητικοί).";const m=A.quotes.reduce((w,E)=>Math.max(w,P(E.number,0)),0);if(Math.floor(l)<=m&&Math.floor(l)!==P(ae().next,1))return J.msg="Υπάρχουν ήδη προσφορές μέχρι το #"+m+". Ο επόμενος αριθμός πρέπει να είναι μεγαλύτερος.";Object.assign(s,{vat:o,margin:a,next:Math.floor(l),validDays:Math.floor(u),followDays:Math.floor(h),warrantyMonths:Math.floor(p),autoSale:!!t.autoSale})}else if(n==="banks"&&(s.banks=t.banks.map(o=>({id:o.id,bank:o.bank.trim(),iban:o.iban.replace(/\s+/g,"").toUpperCase(),holder:o.holder.trim(),afm:o.afm.trim()})).filter(o=>o.bank||o.iban||o.holder),s.banks.some(o=>o.iban&&!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(o.iban))))return J.msg="Ένα IBAN δεν φαίνεται σωστό.";const i={};Object.keys(s).forEach(o=>{JSON.stringify(J.f.v[o])!==JSON.stringify(J.f.v0[o])&&(i[o]=s[o])}),n==="company"&&J.f.logo&&pp("logo",J.f.logo),Object.keys(i).length&&pp("main",i);const r=Object.keys(i).length+(J.f.logo?1:0);J.f=null,J.msg="",J.ok=r?"Αποθηκεύτηκε.":"Καμία αλλαγή.",e(J.ok)}function BR(n,e,t){const s=n.closest("[data-st-open],[data-st-edit],[data-st-cancel],[data-st-save],[data-st-badd],[data-st-bdel]");if(!s)return!1;const i=s.dataset;if(i.stOpen){if(J.f)return!0;J.open=J.open===i.stOpen?"":i.stOpen,J.ok=""}else i.stEdit?(J.f={k:i.stEdit,v:Wp[i.stEdit](),v0:JSON.parse(JSON.stringify(Wp[i.stEdit]())),logo:null},J.msg="",J.ok=""):i.stCancel!==void 0?(J.f=null,J.msg=""):i.stSave?qR(i.stSave,t):i.stBadd!==void 0?J.f.v.banks.push({id:je(),bank:"",iban:"",holder:"",afm:""}):i.stBdel!==void 0&&J.f.v.banks.splice(+i.stBdel,1);return e(),!0}function jR(n){const e=n.dataset;if(e.sf&&J.f)return J.f.v[e.sf]=n.type==="checkbox"?n.checked:n.value,J.msg="",!0;if(e.sb&&J.f){const[t,s]=e.sb.split(":");return J.f.v.banks[+t][s]=n.value,J.msg="",!0}return!1}async function zR(n,e){const t=n.dataset;if(t.sl!==void 0&&J.f&&n.files&&n.files[0]){try{J.f.logo=await UR(n.files[0]),J.msg=""}catch(s){J.msg=s.message}return e(),!0}return t.sf&&J.f&&n.tagName==="SELECT"?(J.f.v[t.sf]=n.value,!0):!1}const GR=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),KR=new Intl.NumberFormat("en-GB",{style:"currency",currency:"EUR"}),WR=n=>GR.format(Math.round((n||0)*100)/100),HR=n=>KR.format(Math.round((n||0)*100)/100),QR=n=>String(U(n)).replace(".",","),JR=n=>String(U(n)),Qv=n=>n.qty*n.price*(1-(n.disc||0)/100),YR=864e5,Qp={el:{war:"Εγγύηση ",mUnit:"μήνες",noWar:"Χωρίς εγγύηση",planTitle:"Κάτοψη και θέσεις εξοπλισμού",planCam:"Κάμερα",planAp:"Access Point",planOther:"Σημείο",option:"Εναλλακτική: ",valid:"Ισχύει έως: ",payTitle:"Στοιχεία πληρωμής",payBank:"Τράπεζα",payIban:"IBAN",payHolder:"Δικαιούχος",payAfm:"ΑΦΜ",payRef:"Αιτιολογία",payRefVal:"Προσφορά ",payNote:"Παρακαλούμε ελέγξτε το όνομα δικαιούχου και το ΑΦΜ πριν στείλετε την πληρωμή.",notesTitle:"Σημειώσεις",termsTitle:"Όροι και προϋποθέσεις",page:"Σελίδα",of:"από",lang:"el",benTitle:"Τι κερδίζετε",file:"Prosfora_"},en:{war:"Warranty ",mUnit:"months",noWar:"No warranty",planTitle:"Layout and equipment positions",planCam:"Camera",planAp:"Access Point",planOther:"Point",option:"Option: ",valid:"Valid until: ",payTitle:"Payment details",payBank:"Bank",payIban:"IBAN",payHolder:"Beneficiary",payAfm:"VAT No.",payRef:"Reference",payRefVal:"Quotation ",payNote:"Please verify the beneficiary name and VAT number before sending your payment.",notesTitle:"Notes",termsTitle:"Terms and conditions",page:"Page",of:"of",lang:"en",benTitle:"What you gain",title:"QUOTATION",no:"No.: ",date:"Date: ",to:"To",subject:"Subject: ",desc:"Description",qty:"Qty",unit:"Unit price",disc:"Disc.",total:"Total",net:"Net amount",vat:"VAT ",grand:"TOTAL",grandNoVat:"TOTAL (no VAT)",file:"Quotation_"}},XR=n=>!(n&&n.war&&n.war.on===!1),ZR=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(P(e.m,0))):P(ae().warrantyMonths,24)},eP=(n,e,t)=>{e=e||{};const s=P(e.val,0);return t=t||0,e.type==="eurnet"?U(Math.min(Math.max(0,s)*(1+t/100),n)):e.type==="pct"?U(n*Math.min(100,Math.max(0,s))/100):e.type==="eur"?U(Math.min(Math.max(0,s),n)):0};function Jv(n){let e=0;(n.lines||[]).forEach(u=>e+=Qv(u)),e=U(e);const t=n.vatMode==="off",s=P(ae().vat,24),i=t?0:U(e*s/100),r=U(e+i),o=n.prepay||{},a=t?0:s,l=eP(r,o,a);return{preNet:o.type==="eurnet"?U(l/(1+a/100)):0,sub:e,vat:i,vp:s,vatOff:t,total:r,pre:l,rest:U(r-l),preType:o.type||"",preVal:P(o.val,0)}}const tP=n=>{if(n.descEn)return n.descEn;const e=n.pid&&A.products.find(t=>t.id===n.pid);if(e&&e.descEn){const t=e.model+(e.desc?" - "+e.desc:"");if(!n.desc||n.desc===t)return e.model+" - "+e.descEn}return n.desc},nP=n=>{const e=String(n||"").trim().match(/^(https:\/\/[a-z0-9.-]+\.[a-z]{2,})(:\d+)?\/?$/i);return e?e[1].toLowerCase()+(e[2]||"")+"/":""},sP=n=>String(n&&n.info||"").replace(/\{email\}/gi,n&&n.bizEmail||""),iP=n=>{const e=n.validDays,t=e!=null&&e!==""?P(e,0):ae().validDays==null?15:P(ae().validDays,15);return t?new Date((n.ts||Date.now())+t*YR).toLocaleDateString("el-GR"):""};let jo=null;async function rP(){if(jo)return jo;const[{jsPDF:n},e,t,s,i]=await Promise.all([Cn(()=>import("./jspdf.es.min-BKuoLFcq.js").then(a=>a.j),[]),Cn(()=>import("./jspdf.plugin.autotable-DYHf0IZ0.js"),[]),Cn(()=>import("./reg-DWYsL-bi.js"),[]),Cn(()=>import("./bold-BPkZ6IBK.js"),[]),Cn(()=>import("./qrlib-Bgozeulj.js"),[])]);(e.applyPlugin||e.default&&e.default.applyPlugin)(n);const r=new Function(i.default+"; return qrcode;")(),o=await Cn(()=>import("./gen-C78E_0f9.js"),[]);return jo={jsPDF:n,fonts:{reg:t.default.trim(),bold:s.default.trim()},qrcode:r,gen:o},jo}function oP(n,e){try{const t=n(0,"M");t.addData(e),t.make();const s=t.getModuleCount(),i=[];for(let r=0;r<s;r++){let o="";for(let a=0;a<s;a++)o+=t.isDark(r,a)?"1":"0";i.push(o)}return i}catch{return null}}async function aP(n,e){e=e==="en"?"en":"el";const{jsPDF:t,fonts:s,qrcode:i,gen:r}=await rP(),o=ae(),a=A.st.logo||{};let l=JSON.parse(JSON.stringify(n));e==="en"&&(l.lines=l.lines.map($=>({...$,desc:tP($)}))),l.war={on:XR(l),m:ZR(l)};const u=nP(o.pubUrl),p={qr:o.qrOn!==!1&&u?oP(i,u+"portal.html"):null,qrT1:e==="en"?"View your documents online":"Δείτε τα έγγραφά σας online",qrT2:e==="en"?"Scan the code and sign in with your personal access code.":"Σκανάρετε το QR και μπείτε με τον προσωπικό σας κωδικό πρόσβασης.",validTo:iP(l),banks:o.banks||[],name:o.name,info:sP(o),terms:e==="en"&&o.termsEn&&o.termsEn.trim()?o.termsEn:o.terms,logoMM:o.logoMM,color:o.pdfColor,logo:a.data,logoW:a.w,logoH:a.h,plan:null},m={};l.lines.forEach(($,R)=>{const B=$.pid&&A.products.find(H=>H.id===$.pid);$.showImg&&B&&B.img&&B.imgW&&B.imgH&&(m[R]={data:B.img,w:B.imgW,h:B.imgH})});const w=r.makePdf(t,s,p,l,Jv(l),e==="en"?HR:WR,e==="en"?JR:QR,Qv,m,Qp[e]),E=(l.customer.name||"").replace(/[^\p{L}\p{N}]+/gu,"_").replace(/^_|_$/g,"");return{buf:w,fn:Qp[e].file+l.number+(E?"_"+E:"")+".pdf"}}const cP=Jv,zo=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),lP=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),Jp=(n,e,t)=>String(n||"").replace(/\{(\w+)\}/g,(s,i)=>({number:e.number||"",customer:e.customer&&e.customer.name||"",total:lP.format(cP(e).total),subject:e.subject||"",company:ae().name||"",name:(e.customer&&e.customer.name||"").split(" ")[0]})[i]??s),uP={el:{subj:"Προσφορά {number} - {company}",body:`Καλησπέρα,
σας στέλνω την προσφορά {number} ({subject}). Σύνολο {total}.
Μένω στη διάθεσή σας για οτιδήποτε χρειαστείτε.
{company}`},en:{subj:"Quotation {number} - {company}",body:`Hello,
please find attached quotation {number} ({subject}). Total {total}.
Feel free to contact us for anything you need.
{company}`}};let de=null;const Yv=()=>!!de;function dP(){de=null}function hP(n){if(!A.quotes.find(s=>s.id===n))return;let t="el";try{t=localStorage.getItem("tm-pdflang")==="en"?"en":"el"}catch{}de={id:n,lang:t,busy:"",msg:""}}function fP(){if(!de)return"";const n=A.quotes.find(t=>t.id===de.id);if(!n)return de=null,"";const e=n.customer&&n.customer.email||"";return`<div class="sheet"><div class="sheet-in auto"><div class="sheet-h"><b>PDF προσφοράς #${zo(n.number)}</b><button class="ib dk" data-sd="close">✕</button></div>
  <div class="sheet-list pad"><div class="lbl">Γλώσσα PDF</div>
  <div class="seg"><button data-sdl="el" class="${de.lang==="el"?"on":""}">Ελληνικά</button><button data-sdl="en" class="${de.lang==="en"?"on":""}">English</button></div>
  <div class="sd-btns">
    <button class="btn b1 wide" data-sd="share" ${de.busy?"disabled":""}>📤 Αποστολή (WhatsApp, Viber, Drive…)</button>
    <button class="btn b2 wide" data-sd="mail" ${de.busy?"disabled":""}>✉️ Email${e?" στον "+zo(e):""}</button>
    <button class="btn b2 wide" data-sd="view" ${de.busy?"disabled":""}>👁️ Προβολή / Αποθήκευση</button>
  </div>
  ${de.busy?`<div class="upd">${zo(de.busy)}</div>`:""}${de.msg?`<div class="err box">${zo(de.msg)}</div>`:""}
  <div class="muted small">Δεν αλλάζει τίποτα στην προσφορά· καταγράφεται μόνο στο ιστορικό της.</div></div></div></div>`}const pP=n=>{const e=new Uint8Array(n);let t="";const s=32768;for(let i=0;i<e.length;i+=s)t+=String.fromCharCode.apply(null,e.subarray(i,i+s));return btoa(t)};async function mP(n,e,t){const s=A.quotes.find(i=>i.id===de.id);if(s){de.busy="Φτιάχνω το PDF…",de.msg="",e();try{const{buf:i,fn:r}=await aP(s,de.lang);try{localStorage.setItem("tm-pdflang",de.lang)}catch{}const o=uP[de.lang],a=ae(),l=Jp(a.mailSubj&&de.lang==="el"?a.mailSubj:o.subj,s,de.lang),u=Jp(a.mailBody&&de.lang==="el"?a.mailBody:o.body,s,de.lang);let h={ok:!0};if(wn)h=await ye.shareFile({name:r,b64:pP(i),mime:"application/pdf",text:u,subject:l,email:n==="mail"&&s.customer&&s.customer.email||"",view:n==="view"});else{const p=URL.createObjectURL(new Blob([i],{type:"application/pdf"})),m=document.createElement("a");m.href=p,m.download=r,document.body.appendChild(m),m.click(),m.remove(),setTimeout(()=>URL.revokeObjectURL(p),5e3)}if(h&&h.error)return de.busy="",de.msg=h.error,e();Ue("qlog",{id:je(),qid:s.id,number:s.number||"",customer:s.customer&&s.customer.name||"",ts:Date.now(),type:"pdf",text:"Εξαγωγή PDF ("+(de.lang==="en"?"αγγλικά":"ελληνικά")+") από την εφαρμογή Android."}),de=null,t("Το PDF είναι έτοιμο."),e()}catch(i){de.busy="",de.msg="Δεν δημιουργήθηκε το PDF. "+(i&&i.message||""),e()}}}function gP(n,e,t){const s=n.closest("[data-sd],[data-sdl],[data-sdq]");if(!s)return!1;const i=s.dataset;return i.sdq?(hP(i.sdq),e(),!0):de?i.sdl?(de.lang=i.sdl,e(),!0):(i.sd==="close"?(de=null,e()):de.busy||mP(i.sd,e,t),!0):!1}const Ft=document.getElementById("app"),oe=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Go=n=>P(n).toLocaleString("el-GR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €",Pi=n=>Math.round(P(n)).toLocaleString("el-GR")+" €",yP=n=>n?new Date(n).toLocaleDateString("el-GR",{day:"numeric",month:"short"}):"",Xv=n=>String(n||"?").split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]).join("").toUpperCase(),vP={pending:"p-a",accepted:"p-ok",done:"p-ok",rejected:"p-b"};let hn=null,$t=!1;const Ge={qf:"all",cq:"",stAsk:null};let De=null;const _P=[["home","🏠","Αρχική"],["cal","📅","Ημερολόγιο"],["quotes","📄","Προσφορές"],["custs","👥","Πελάτες"],["menu","☰","Μενού"]],bP=n=>`<nav class="nav">${_P.filter(([e])=>!_e()||e==="cal"||e==="menu").map(([e,t,s])=>`<a href="#/${e}" class="${e===n?"on":""}"><i>${t}</i>${s}</a>`).join("")}</nav>`,Pe=(n,e,t="",s="")=>`<header class="top">${t}<h1>${oe(n)}${e?`<span class="sm">${oe(e)}</span>`:""}</h1>${s}</header>`,Ci=n=>`<a class="ib" href="#/${n}">←</a>`,Ce=(n,e,t,s="")=>`${n}<main class="body">${e}</main>${s}${t?bP(t):""}`;function wP(n=""){return`<div class="login"><img class="lico" src="/icon-192.png" alt=""><div class="logo">TechMate</div><p>Συνδέσου με τον ίδιο λογαριασμό που έχεις στο PWA.</p>
  <form id="lf"><label>Email<input name="e" type="email" autocomplete="username" required></label>
  <label>Κωδικός<input name="p" type="password" autocomplete="current-password" required></label>
  <label class="chk"><input type="checkbox" id="sp"> Εμφάνιση κωδικού</label>
  ${n?`<div class="err">${oe(n)}</div>`:""}<button class="btn b1">Σύνδεση</button></form></div>`}function IP(){return A.quotes.filter(n=>!Jt(n)&&nt(n)==="pending")}function nu(){return Oe.state==="downloading"?`<div class="upd">⬇️ Κατεβαίνει η έκδοση ${oe(Oe.latest.version)}… ${Oe.pct}%</div>`:Oe.state!=="available"?"":`<div class="upd">⬇️ Νέα έκδοση ${oe(Oe.latest.version)}${Oe.latest.notes?": "+oe(Oe.latest.notes):""}${Oe.needApk?"<br>Χρειάζεται νέο αρχείο εγκατάστασης (APK).":""}${Oe.err?`<br><span class="bad">${oe(Oe.err)}</span>`:""}
    <button class="btn b1 sm" data-up="apply">${Oe.needApk?"Λήψη APK":"Ενημέρωση τώρα"}</button></div>`}function Yp(){const n={checking:"Έλεγχος…",none:"Έχεις την τελευταία έκδοση.",error:Oe.err}[Oe.state]||"";return`<div class="card pad ver"><div><b>TechMate ${oe(lv)}</b>${n?`<span>${oe(n)}</span>`:""}</div><button class="btn b2 sm" data-up="check">Έλεγχος ενημέρωσης</button></div>`}function Xp(){const n=new Date,e=new Date(n.getFullYear(),n.getMonth(),1).getTime(),t=A.quotes.filter(a=>!Jt(a)&&["accepted","done"].includes(nt(a))&&(a.ts||0)>=e).reduce((a,l)=>a+P(l.total),0),s=A.ldocs.filter(a=>a.kind==="sale").reduce((a,l)=>a+nv(l),0),i=Lk(),r=n.getHours(),o=r<12?"Καλημέρα":r<18?"Καλησπέρα":"Καλό βράδυ";return Ce(Pe("TechMate",`${o} · ${n.toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}`,"",'<a class="ib" href="#/menu">👤</a>'),`${Ms?'<div class="upd">🧪 Δοκιμαστικά δεδομένα (preview)</div>':""}${nu()}
    <div class="qa six"><a href="#/edit/new"><i>📝</i>Προσφορά</a><a data-hnew=""><i>📅</i>Ραντεβού</a><a data-hnew="due"><i>💶</i>Λήξη</a><a href="#/books/newdoc"><i>🧾</i>Έξοδο</a><a href="#/soon/Φωτογραφίες"><i>📷</i>Φωτο</a><a data-bcscan><i>🔍</i>Barcode</a></div>
    <div class="kpis">
      <a class="kpi" href="#/quotes"><b>${IP().length}</b><span>Σε αναμονή απάντησης</span></a>
      <div class="kpi"><b>${Pi(t)}</b><span>Δεκτές αυτόν τον μήνα</span></div>
      <a class="kpi" href="#/custs"><b>${Zt().length}</b><span>Πελάτες</span></a>
      <div class="kpi"><b class="${s>0?"bad":""}">${Pi(s)}</b><span>Μου χρωστούν</span></div>
    </div>
    <div class="h">Σήμερα <a class="hl" href="#/cal">Ημερολόγιο ›</a></div>
    <div class="card">${i.today.length?i.today.map(a=>Gn(a,!1)).join(""):'<div class="empty">Τίποτα για σήμερα 🙂</div>'}</div>
    ${i.late.length?`<div class="h badh">⚠️ Εκκρεμούν από πριν (${i.late.length})</div><div class="card">${i.late.slice(0,5).map(a=>Gn(a,!0)).join("")}${i.late.length>5?`<a class="empty" href="#/cal">+${i.late.length-5} ακόμα ›</a>`:""}</div>`:""}
    ${i.dues.length?`<div class="h">💶 Λήξεις & πληρωμές (14 μέρες)</div><div class="card">${i.dues.map(a=>Gn(a,!0)).join("")}</div>`:""}`,"home")}function Zv(n){const e=nt(n),t=n.customer&&n.customer.name||"";return`<a class="row" href="#/q/${encodeURIComponent(n.id)}"><div class="av">${oe(Xv(t))}</div>
  <div class="t"><b>${oe(n.subject||"(χωρίς θέμα)")}</b><span>#${oe(n.number||"—")} · ${oe(t)} · ${yP(n.ts)}</span></div>
  <div class="r"><div class="amt">${Pi(n.total)}</div><span class="pill ${vP[e]||"p-a"}">${ra[e]||e}</span></div></a>`}function EP(){const n=A.quotes.filter(s=>!Jt(s)).sort((s,i)=>(i.ts||0)-(s.ts||0)),e=[["all","Όλες"],["pending","Σε αναμονή"],["accepted","Δεκτές"],["done","Ολοκληρ."],["rejected","Απορρίφθ."]],t=Ge.qf==="all"?n:n.filter(s=>nt(s)===Ge.qf);return Ce(Pe("Προσφορές",`${n.length} συνολικά`),`<div class="chips">${e.map(([s,i])=>`<button data-qf="${s}" class="${Ge.qf===s?"on":""}">${i}</button>`).join("")}</div>
    <div class="card">${t.length?t.map(Zv).join(""):`<div class="empty">${$t?"Καμία προσφορά":"Φόρτωση…"}</div>`}</div>`,"quotes",'<a class="fab" href="#/edit/new">＋</a>')}function TP(n){const e=A.quotes.find(o=>o.id===n);if(!e)return Ce(Pe("Προσφορά","",Ci("quotes")),`<div class="empty">${$t?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"quotes");const t=nt(e),s=e.customer||{},i=e.lines||[],r=i.reduce((o,a)=>o+P(a.qty)*P(a.price)*(1-P(a.disc)/100),0);return Ce(Pe(`#${e.number||"—"}`,ra[t],Ci("quotes")),`<div class="card"><div class="fld"><label>Πελάτης</label><a class="v" href="#/c/${encodeURIComponent($e(s.name)||"_none")}">${oe(s.name)} ›</a></div>
    <div class="fld" style="margin:0"><label>Θέμα</label><div class="v">${oe(e.subject)}</div></div></div>
    <div class="h">Κατάσταση</div>
    <div class="card pad"><div class="seg four">${Object.keys(ra).map(o=>`<button data-st="${o}" class="${o===t?"on":""}">${ra[o]}</button>`).join("")}</div>
    ${Ge.stAsk&&Ge.stAsk.id===e.id?`<div class="ask"><b>Αλλαγή σε «${oe(oa[Ge.stAsk.st])}»;</b>${CS(e,Ge.stAsk.st).map(o=>`<div>• ${oe(o)}</div>`).join("")}
      <div class="actions"><button class="btn b2" data-stno>Άκυρο</button><button class="btn b1" data-stok>Ναι, αλλαγή</button></div></div>`:""}</div>
    <div class="h">Είδη (${i.length})</div>
    <div class="card">${i.map(o=>`<div class="item"><div class="t"><b>${oe(o.desc)}</b><span>${P(o.qty)} × ${Go(o.price)}${P(o.disc)?` · −${P(o.disc)}%`:""}</span></div><div class="amt">${Go(P(o.qty)*P(o.price)*(1-P(o.disc)/100))}</div></div>`).join("")||'<div class="empty">Χωρίς είδη</div>'}</div>
    <div class="card"><div class="tot"><span>Καθαρό</span><span>${Go(r)}</span></div>
    <div class="tot big"><span>Σύνολο${e.vatMode==="off"?" (χωρίς ΦΠΑ)":" με ΦΠΑ"}</span><span>${Go(e.total)}</span></div></div>${fP()}`,null,`<div class="bar"><a class="btn b2" href="#/edit/${encodeURIComponent(e.id)}">✏️ Επεξεργασία</a><button class="btn b2" data-qappt="${oe(e.id)}">📅 Ραντεβού</button><button class="btn b1" data-sdq="${oe(e.id)}">📤 PDF</button></div>`)}function AP(){const n=$e(Ge.cq),e=Zt().filter(t=>!n||$e(t.name).includes(n)).sort((t,s)=>(s.last||0)-(t.last||0));return Ce(Pe("Πελάτες",`${e.length}`),`<input class="search" id="cq" placeholder="🔍 Αναζήτηση πελάτη" value="${oe(Ge.cq)}">
    <div class="card">${e.map(t=>`<a class="row" href="#/c/${encodeURIComponent(t.k)}"><div class="av">${oe(Xv(t.name))}</div>
      <div class="t"><b>${oe(t.name)}</b><span>${t.quotes.length} προσφορές${t.info.phone?" · "+oe(t.info.phone):""}</span></div>
      <div class="r">${t.owed>0?`<div class="amt bad">${Pi(t.owed)}</div><span class="muted">χρωστάει</span>`:""}</div></a>`).join("")||`<div class="empty">${$t?"Κανένας πελάτης":"Φόρτωση…"}</div>`}</div>`,"custs",'<a class="fab" href="#/ce/new">＋</a>')}function SP(n){const e=Zt().find(i=>i.k===n);if(!e)return Ce(Pe("Πελάτης","",Ci("custs")),`<div class="empty">${$t?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"custs");const t=e.info,s=t.phone.replace(/\s/g,"");return Ce(Pe(e.name,[t.address,t.phone].filter(Boolean).join(" · "),Ci("custs"),s?`<a class="ib" href="tel:${oe(s)}">📞</a>`:""),`<div class="kpis"><div class="kpi"><b>${Pi(e.won)}</b><span>Δεκτές προσφορές</span></div><div class="kpi"><b class="${e.owed>0?"bad":""}">${Pi(e.owed)}</b><span>Υπόλοιπο</span></div></div>
    <div class="actions">${s?`<a class="btn b2" href="viber://chat?number=${oe(s.startsWith("+")?s:"+30"+s)}">💬 Viber</a>`:""}
    ${t.address?`<a class="btn b2" href="https://maps.google.com/?q=${encodeURIComponent(t.address)}">🗺️ Οδηγίες</a>`:""}
    ${t.email?`<a class="btn b2" href="mailto:${oe(t.email)}">✉️ Email</a>`:""}</div>
    <div class="actions"><a class="btn b2" href="#/ce/${encodeURIComponent(e.k)}">✏️ Στοιχεία</a><button class="btn b2" data-newq="${oe(e.k)}">＋ Προσφορά</button><button class="btn b2" data-newt="${oe(e.k)}">＋ Εργασία</button></div>
    ${e.rec&&e.rec.notes?`<div class="card pad note">${oe(e.rec.notes)}</div>`:""}
    <div class="h">Προσφορές (${e.quotes.length})</div>
    <div class="card">${e.quotes.sort((i,r)=>(r.ts||0)-(i.ts||0)).map(Zv).join("")||'<div class="empty">Καμία</div>'}</div>
    ${e.mins.length?`<div class="h">Παλιές εγκαταστάσεις (${e.mins.length})</div>`:""}
    <div class="h">Τιμολόγια & φωτογραφίες</div><div class="card">${e.quotes.filter(i=>nt(i)==="done").map(i=>`<a class="row" href="#/files/${encodeURIComponent(i.id)}"><div class="av">📷</div><div class="t"><b>#${oe(i.number||"—")} ${oe(i.subject||"")}</b><span>${Ri(i).length} τιμολόγια · ${Xr(i).length} φωτογραφίες</span></div></a>`).join("")||'<div class="empty">Θα εμφανιστούν όταν υπάρχει ολοκληρωμένη εγκατάσταση.</div>'}</div>`,"custs")}const ur=(n,e,t="")=>`<label class="f">${e}<input class="in" data-f="${n}" value="${oe(De.v[n]||"")}" ${t}></label>`,kP=n=>`${De.msg?`<div class="err box">${oe(De.msg)}</div>`:""}`,RP='<div class="bar"><button class="btn b2" data-fa="cancel">Άκυρο</button><button class="btn b1" data-fa="save">💾 Αποθήκευση</button></div>';function PP(n){if(!De||De.kind!=="cust"||De.arg!==n){const e=n!=="new"&&Zt().find(t=>t.k===n);if(n!=="new"&&!e)return Ce(Pe("Πελάτης","",Ci("custs")),`<div class="empty">${$t?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);De={kind:"cust",arg:n,v:e?{name:e.name,...e.info,notes:e.rec&&e.rec.notes||""}:{name:""}}}return`${Pe(n==="new"?"Νέος πελάτης":"Στοιχεία πελάτη","",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${ur("name","Όνομα",'autocomplete="off"')}${ur("phone","Τηλέφωνο",'inputmode="tel"')}${ur("email","Email",'inputmode="email"')}${ur("afm","ΑΦΜ",'inputmode="numeric"')}${ur("address","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${oe(De.v.notes||"")}</textarea></label></div>
    ${n!=="new"&&$e(De.v.name)!==n?'<div class="upd">Η αλλαγή ονόματος θα περάσει και στις προσφορές, στα παραστατικά και στις εισπράξεις του πελάτη.</div>':""}${kP()}</main>${RP}`}function CP(n){if(n==="cancel"){const t=De.arg;return De=null,location.replace(t==="new"?"#/custs":"#/c/"+encodeURIComponent(t))}const e=$S(De.arg==="new"?"":De.arg,De.v);if(!e.ok)return De.msg=e.msg,me();De=null,location.replace("#/c/"+encodeURIComponent(e.k))}const DP=[["📄","Προσφορές","Νέα · Κατάλογος · Αποθηκευμένες · Κατάσταση · Δεκτές & παραγγελίες · Ιστορικό αλλαγών · Διαγραμμένα","#/quotes"],["📒","Λογιστικά","Σύνοψη · Παραστατικά · Πληρωμές · Υπόλοιπα","#/books/sum"],["🛡️","Εγκαταστάσεις","Εγγυήσεις · Συντηρήσεις","#/inst"],["👷","Μεροκάματα","Καταχώρηση · Πληρωμή υπαλλήλου · Υπόλοιπα","#/wages"],["📦","Αποθήκη","Απόθεμα · Κινήσεις · Λίστα παραγγελίας · Εργαλεία που λείπουν","#/stock"],["📨","Μηνύματα ιστοσελίδας","Αιτήματα από τη φόρμα επικοινωνίας","#/msgs"],["🌐","Ιστοσελίδα","Περιεχόμενο · Άρθρα — από το PWA"],["📅","Ημερολόγιο & ειδοποιήσεις","Υπενθυμίσεις · Widget · Χρώματα · Backup · Microsoft To Do","#/cset"],["⚙️","Ρυθμίσεις","Εταιρεία & PDF · Τιμές/αρίθμηση · Τράπεζες · Χρήστες ομάδας · Ειδοποιήσεις · Backup","#/set"]];function $P(){return _e()?Ce(Pe("Μενού",hn?hn.email:""),`<div class="card"><a class="mi" href="#/wages"><div class="ic">👷</div><div class="t"><b>Τα μεροκάματά μου</b><span>Καταχώρηση · Υπόλοιπο · Πληρωμές</span></div></a><a class="mi" href="#/stock"><div class="ic">🧰</div><div class="t"><b>Εργαλεία που λείπουν</b><span>Γράψε ό,τι χρειάζεται να παραγγελθεί</span></div></a><a class="mi" href="#/cset"><div class="ic">📅</div><div class="t"><b>Ημερολόγιο & ειδοποιήσεις</b><span>Υπενθυμίσεις · Widget · Χρώματα</span></div></a></div>${nu()}${Yp()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu"):Ce(Pe("Μενού",hn?hn.email:""),`<div class="card">${DP.map(([n,e,t,s])=>`<a class="mi" href="${s||"#/soon/"+e}"><div class="ic">${n}</div><div class="t"><b>${e}${s?"":' <span class="soon">από το PWA</span>'}</b><span>${t}</span></div></a>`).join("")}</div>
    ${nu()}${Yp()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu")}function VP(n){const e=(ae()&&ae().pubUrl||"").replace(/\/?$/,"/");return Ce(Pe(n,"",'<a class="ib" href="javascript:history.back()">←</a>'),`<div class="card"><div class="empty">🛠️ Το «${oe(n)}» γίνεται προς το παρόν από το PWA και φαίνεται αμέσως εδώ όπου χρειάζεται.${ae()&&ae().pubUrl?`<br><br><a class="btn b1" href="${oe(e)}app/" target="_blank" rel="noopener">Άνοιγμα του PWA</a>`:""}</div></div>`,null)}function me(){if(!hn)return;const[n,e]=location.hash.replace(/^#\//,"").split("/").map(decodeURIComponent),t={home:Xp,quotes:EP,q:()=>TP(e),custs:AP,c:()=>SP(e),cal:()=>Cp($t,Pe,Ce,e),agenda:()=>Cp($t,Pe,Ce),t:()=>kk(e,$t,Pe,Ce),cset:()=>Pk(Pe,Ce),wages:()=>oR(Pe,Ce),wage:()=>xv(e,Pe,Ce,!1),stock:()=>dR(Pe,Ce),inst:()=>vR(Pe,Ce),set:()=>FR(Pe,Ce),sn:()=>PR(e,Pe,Ce),msgs:()=>Zk(Pe,Ce),files:()=>Kk(e,Pe,Ce),menu:$P,soon:()=>VP(e)};if(n==="edit")return e_(e);nk(),Object.assign(t,{ce:()=>PP(e),books:()=>HS(e,$t)}),n!=="ce"&&(De=null),n!=="t"&&vk(),n!==Ge.lastR&&(rR(),dP(),xR(),Ge.lastR=n),O.openNext&&(Uv(O.openNext),O.openNext=""),n!=="q"&&(Ge.stAsk=null),n==="files"&&!Ae.st&&wd(me),n!=="files"&&(Ae.st=null,Ae.msg=""),n==="msgs"&&!ft.list&&!ft.busy&&Xk(me),n!=="msgs"&&(ft.list=null),n!=="books"&&FS();const s=scrollY,i=_e()&&!["cal","t","menu","cset","wages","stock"].includes(n)?t.cal:t[n]||Xp;if(Ft.innerHTML=i(),n==="custs"){const o=document.getElementById("cq");o.oninput=()=>{Ge.cq=o.value,me();const a=document.getElementById("cq");a.focus(),a.setSelectionRange(a.value.length,a.value.length)}}const r=document.getElementById("out");r&&(r.onclick=()=>{confirm("Αποσύνδεση; Οι υπενθυμίσεις σε αυτό το κινητό θα σταματήσουν μέχρι να ξανασυνδεθείς.")&&(ye.clearSession(),qa="",sS())}),scrollTo(0,s)}const NP=(n,e)=>e?location.replace(n):location.hash=n;Ft.addEventListener("change",n=>{Yk(n.target,me)||NR(n.target)||zR(n.target,me)||Ok(n.target,me,wt)||ER(n.target,me)||XS(n.target,me)});Ft.addEventListener("keydown",n=>Mk(n,me,wt));Ft.addEventListener("touchstart",n=>Dv(n,me),{passive:!0});Ft.addEventListener("touchend",n=>Dv(n,me),{passive:!0});Ft.addEventListener("click",n=>{if(Nk(n.target,me,wt)||Jk(n.target,me,wt)||eR(n.target,me)||Wv(n.target,me,wt)||BR(n.target,me,wt)||gP(n.target,me,wt)||wR(n.target,me,wt)||JS(n.target,NP,me,wt))return;const e=n.target.closest("[data-up],[data-qf],[data-st],[data-stok],[data-stno],[data-fa],[data-newq],[data-newt],[data-hnew],[data-qappt]");if(!e)return;const t=e.dataset,s=decodeURIComponent(location.hash.split("/")[2]||"");if(t.up){t.up==="apply"?AS():Ql(!0);return}if(t.hnew!==void 0){ui({kind:t.hnew,date:pe()}),location.hash="#/t/new";return}if(t.qappt){const i=A.quotes.find(o=>o.id===t.qappt),r=i&&i.customer||{};ui({quoteId:t.qappt,cust:r.name||"",tel:r.phone||"",addr:r.address||"",title:"Εγκατάσταση – "+(r.name||""),date:pe()}),location.hash="#/t/new";return}if(t.qf)Ge.qf=t.qf;else if(t.st){const i=A.quotes.find(r=>r.id===s);Ge.stAsk=i&&nt(i)!==t.st?{id:s,st:t.st}:null}else if("stno"in t)Ge.stAsk=null;else if("stok"in t){const i=DS(Ge.stAsk.id,Ge.stAsk.st);Ge.stAsk=null,i.msg&&wt(i.msg)}else{if(t.fa)return De&&CP(t.fa);if(t.newq){const i=Zt().find(r=>r.k===t.newq);i&&sk({name:i.name,...i.info}),location.hash="#/edit/new";return}else if(t.newt){const i=Zt().find(r=>r.k===t.newt);i&&ui({cust:i.name,tel:i.info.phone||"",addr:i.info.address||"",date:pe()}),location.hash="#/t/new";return}}me()});Ft.addEventListener("input",n=>{const e=n.target;jR(e)||xk(e,me)||IR(e,me)||YS(e,me)||De&&e.dataset.f&&(De.v[e.dataset.f]=e.type==="checkbox"?e.checked:e.value,De.msg&&(De.msg=""))});addEventListener("hashchange",()=>{scrollTo(0,0),location.hash.startsWith("#/cset")&&_d(me),me()});function e_(n){const e=scrollY,t=ak(n);if(t===null){Ft.innerHTML=Ce(Pe("Προσφορά","",Ci("quotes")),`<div class="empty">${$t?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);return}Ft.innerHTML=t,ck(Ft,()=>e_(n),s=>location.replace(s?"#/q/"+encodeURIComponent(s):"#/quotes")),scrollTo(0,e)}function wt(n,e){let t=document.getElementById("toast");if(t||(t=document.createElement("div"),t.id="toast",document.body.appendChild(t)),t.textContent=n,e){const s=document.createElement("button");s.textContent=e.label,s.onclick=()=>{t.className="",e.fn()},t.appendChild(s)}t.className="show"+(e?" act":""),clearTimeout(wt.t),wt.t=setTimeout(()=>t.className="",6e3)}iS(n=>wt(n&&n.code==="permission-denied"?"Δεν έχεις δικαίωμα για αυτή την αλλαγή. Δεν αποθηκεύτηκε.":"Η αποθήκευση απέτυχε: "+(n&&(n.code||n.message)||"άγνωστο σφάλμα")));ES(()=>{hn&&!bv()&&!De&&!_v()&&!Rv()&&!Nv()&&!Yv()&&!Hv()&&!qv()&&!$v()&&me()});TS();Ms&&(window.__tm={data:A,hitFind:Kv});let qa="";function xP(){const n=ZA();if(!wn||!n||!Object.keys(A.st).length)return;const e=zn()||{},t={uid:n.uid,email:n.email||"",role:_e()?"team":"owner",empId:Lt(),name:e.name||"",rt:n.refreshToken||"",apiKey:Kl.apiKey,project:Kl.projectId},s=JSON.stringify(t);s!==qa&&(qa=s,ye.setSession(t))}function t_(n){!n||!hn||(n.task?location.hash="#/t/"+encodeURIComponent(n.task):n.isNew&&(ui({date:pe()}),location.hash="#/t/new"))}mo("open",t_);mo("toast",n=>n&&n.text&&wt(n.text));mo("files",()=>{location.hash.startsWith("#/files")&&wd(me)});mo("ms",()=>{location.hash.startsWith("#/cset")&&_d(me)});let Zp=!1,su=!1;XA(()=>{$t=!0,xP(),Fk(),!su&&A.tasks.length&&A.quotes.length&&(su=!0,setTimeout(()=>Ck($t),4e3)),!(bv()||De||_v()||Rv()||Nv()||Yv()||Hv()||qv()||$v())&&me()});document.addEventListener("visibilitychange",()=>{!document.hidden&&hn&&(su=!1,me())});Kr().then(()=>{eS(n=>{if(hn=n,!n){qa="",n_();return}location.hash.startsWith("#/cset")&&_d(me),me(),Zp||(Zp=!0,ye.takeLaunch().then(t_))})});function n_(n="",e=""){Ft.innerHTML=wP(n);const t=document.getElementById("lf");t.e.value=e,document.getElementById("sp").onchange=s=>{t.p.type=s.target.checked?"text":"password"},document.getElementById("lf").onsubmit=s=>{s.preventDefault();const i=s.target;nS(i.e.value.trim(),i.p.value).catch(r=>{const o=r&&r.code||"",l=["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(o)?"Λάθος email ή κωδικός.":o==="auth/network-request-failed"?"Δεν υπάρχει σύνδεση στο internet.":o==="auth/too-many-requests"?"Πολλές προσπάθειες. Δοκίμασε ξανά σε λίγα λεπτά.":"Η σύνδεση μπλοκαρίστηκε.";n_(l+" ["+(o||r&&r.message||"άγνωστο")+"]",i.e.value)})}}export{wp as A,ld as W,Cn as _};
